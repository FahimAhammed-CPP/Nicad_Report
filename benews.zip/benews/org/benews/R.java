package org.benews;

public final class R {
  public static final class anim {
    public static final int abc_fade_in = 2130968576;
    
    public static final int abc_fade_out = 2130968577;
    
    public static final int abc_slide_in_bottom = 2130968578;
    
    public static final int abc_slide_in_top = 2130968579;
    
    public static final int abc_slide_out_bottom = 2130968580;
    
    public static final int abc_slide_out_top = 2130968581;
  }
  
  public static final class attr {
    public static final int actionBarDivider = 2130771968;
    
    public static final int actionBarItemBackground = 2130771969;
    
    public static final int actionBarSize = 2130771970;
    
    public static final int actionBarSplitStyle = 2130771971;
    
    public static final int actionBarStyle = 2130771972;
    
    public static final int actionBarTabBarStyle = 2130771973;
    
    public static final int actionBarTabStyle = 2130771974;
    
    public static final int actionBarTabTextStyle = 2130771975;
    
    public static final int actionBarWidgetTheme = 2130771976;
    
    public static final int actionButtonStyle = 2130771977;
    
    public static final int actionDropDownStyle = 2130772070;
    
    public static final int actionLayout = 2130772061;
    
    public static final int actionMenuTextAppearance = 2130771978;
    
    public static final int actionMenuTextColor = 2130771979;
    
    public static final int actionModeBackground = 2130771980;
    
    public static final int actionModeCloseButtonStyle = 2130771981;
    
    public static final int actionModeCloseDrawable = 2130771982;
    
    public static final int actionModeCopyDrawable = 2130771983;
    
    public static final int actionModeCutDrawable = 2130771984;
    
    public static final int actionModeFindDrawable = 2130771985;
    
    public static final int actionModePasteDrawable = 2130771986;
    
    public static final int actionModePopupWindowStyle = 2130771987;
    
    public static final int actionModeSelectAllDrawable = 2130771988;
    
    public static final int actionModeShareDrawable = 2130771989;
    
    public static final int actionModeSplitBackground = 2130771990;
    
    public static final int actionModeStyle = 2130771991;
    
    public static final int actionModeWebSearchDrawable = 2130771992;
    
    public static final int actionOverflowButtonStyle = 2130771993;
    
    public static final int actionProviderClass = 2130772063;
    
    public static final int actionViewClass = 2130772062;
    
    public static final int activityChooserViewStyle = 2130771994;
    
    public static final int background = 2130772039;
    
    public static final int backgroundSplit = 2130772041;
    
    public static final int backgroundStacked = 2130772040;
    
    public static final int buttonBarButtonStyle = 2130771995;
    
    public static final int buttonBarStyle = 2130771996;
    
    public static final int customNavigationLayout = 2130772042;
    
    public static final int disableChildrenWhenDisabled = 2130772069;
    
    public static final int displayOptions = 2130772032;
    
    public static final int divider = 2130772038;
    
    public static final int dividerHorizontal = 2130771997;
    
    public static final int dividerPadding = 2130772059;
    
    public static final int dividerVertical = 2130771998;
    
    public static final int dropDownListViewStyle = 2130771999;
    
    public static final int dropdownListPreferredItemHeight = 2130772071;
    
    public static final int expandActivityOverflowButtonDrawable = 2130772056;
    
    public static final int height = 2130772000;
    
    public static final int homeAsUpIndicator = 2130772001;
    
    public static final int homeLayout = 2130772043;
    
    public static final int icon = 2130772036;
    
    public static final int iconifiedByDefault = 2130772064;
    
    public static final int indeterminateProgressStyle = 2130772045;
    
    public static final int initialActivityCount = 2130772055;
    
    public static final int isLightTheme = 2130772002;
    
    public static final int itemPadding = 2130772047;
    
    public static final int listChoiceBackgroundIndicator = 2130772075;
    
    public static final int listPopupWindowStyle = 2130772003;
    
    public static final int listPreferredItemHeight = 2130772004;
    
    public static final int listPreferredItemHeightLarge = 2130772005;
    
    public static final int listPreferredItemHeightSmall = 2130772006;
    
    public static final int listPreferredItemPaddingLeft = 2130772007;
    
    public static final int listPreferredItemPaddingRight = 2130772008;
    
    public static final int logo = 2130772037;
    
    public static final int navigationMode = 2130772031;
    
    public static final int paddingEnd = 2130772077;
    
    public static final int paddingStart = 2130772076;
    
    public static final int panelMenuListTheme = 2130772074;
    
    public static final int panelMenuListWidth = 2130772073;
    
    public static final int popupMenuStyle = 2130772072;
    
    public static final int popupPromptView = 2130772068;
    
    public static final int progressBarPadding = 2130772046;
    
    public static final int progressBarStyle = 2130772044;
    
    public static final int prompt = 2130772066;
    
    public static final int queryHint = 2130772065;
    
    public static final int searchDropdownBackground = 2130772009;
    
    public static final int searchResultListItemHeight = 2130772010;
    
    public static final int searchViewAutoCompleteTextView = 2130772011;
    
    public static final int searchViewCloseIcon = 2130772012;
    
    public static final int searchViewEditQuery = 2130772013;
    
    public static final int searchViewEditQueryBackground = 2130772014;
    
    public static final int searchViewGoIcon = 2130772015;
    
    public static final int searchViewSearchIcon = 2130772016;
    
    public static final int searchViewTextField = 2130772017;
    
    public static final int searchViewTextFieldRight = 2130772018;
    
    public static final int searchViewVoiceIcon = 2130772019;
    
    public static final int selectableItemBackground = 2130772020;
    
    public static final int showAsAction = 2130772060;
    
    public static final int showDividers = 2130772058;
    
    public static final int spinnerDropDownItemStyle = 2130772021;
    
    public static final int spinnerMode = 2130772067;
    
    public static final int spinnerStyle = 2130772022;
    
    public static final int subtitle = 2130772033;
    
    public static final int subtitleTextStyle = 2130772035;
    
    public static final int textAllCaps = 2130772057;
    
    public static final int textAppearanceLargePopupMenu = 2130772023;
    
    public static final int textAppearanceListItem = 2130772024;
    
    public static final int textAppearanceListItemSmall = 2130772025;
    
    public static final int textAppearanceSearchResultSubtitle = 2130772026;
    
    public static final int textAppearanceSearchResultTitle = 2130772027;
    
    public static final int textAppearanceSmallPopupMenu = 2130772028;
    
    public static final int textColorSearchUrl = 2130772029;
    
    public static final int title = 2130772030;
    
    public static final int titleTextStyle = 2130772034;
    
    public static final int windowActionBar = 2130772048;
    
    public static final int windowActionBarOverlay = 2130772049;
    
    public static final int windowFixedHeightMajor = 2130772054;
    
    public static final int windowFixedHeightMinor = 2130772052;
    
    public static final int windowFixedWidthMajor = 2130772051;
    
    public static final int windowFixedWidthMinor = 2130772053;
    
    public static final int windowSplitActionBar = 2130772050;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs_pre_jb = 2131034112;
    
    public static final int abc_action_bar_expanded_action_views_exclusive = 2131034113;
    
    public static final int abc_config_actionMenuItemAllCaps = 2131034114;
    
    public static final int abc_config_allowActionMenuItemTextWithIcon = 2131034115;
    
    public static final int abc_config_showMenuShortcutsWhenKeyboardPresent = 2131034116;
    
    public static final int abc_split_action_bar_is_narrow = 2131034117;
  }
  
  public static final class color {
    public static final int abc_search_url_text_holo = 2131099651;
    
    public static final int abc_search_url_text_normal = 2131099648;
    
    public static final int abc_search_url_text_pressed = 2131099649;
    
    public static final int abc_search_url_text_selected = 2131099650;
  }
  
  public static final class dimen {
    public static final int abc_action_bar_default_height = 2131230720;
    
    public static final int abc_action_bar_icon_vertical_padding = 2131230721;
    
    public static final int abc_action_bar_progress_bar_size = 2131230722;
    
    public static final int abc_action_bar_stacked_max_height = 2131230723;
    
    public static final int abc_action_bar_stacked_tab_max_width = 2131230724;
    
    public static final int abc_action_bar_subtitle_bottom_margin = 2131230725;
    
    public static final int abc_action_bar_subtitle_text_size = 2131230726;
    
    public static final int abc_action_bar_subtitle_top_margin = 2131230727;
    
    public static final int abc_action_bar_title_text_size = 2131230728;
    
    public static final int abc_action_button_min_width = 2131230729;
    
    public static final int abc_config_prefDialogWidth = 2131230730;
    
    public static final int abc_dropdownitem_icon_width = 2131230731;
    
    public static final int abc_dropdownitem_text_padding_left = 2131230732;
    
    public static final int abc_dropdownitem_text_padding_right = 2131230733;
    
    public static final int abc_panel_menu_list_width = 2131230734;
    
    public static final int abc_search_view_preferred_width = 2131230735;
    
    public static final int abc_search_view_text_min_width = 2131230736;
    
    public static final int activity_horizontal_margin = 2131230737;
    
    public static final int activity_vertical_margin = 2131230738;
    
    public static final int dialog_fixed_height_major = 2131230739;
    
    public static final int dialog_fixed_height_minor = 2131230740;
    
    public static final int dialog_fixed_width_major = 2131230741;
    
    public static final int dialog_fixed_width_minor = 2131230742;
  }
  
  public static final class drawable {
    public static final int abc_ab_bottom_solid_dark_holo = 2130837504;
    
    public static final int abc_ab_bottom_solid_light_holo = 2130837505;
    
    public static final int abc_ab_bottom_transparent_dark_holo = 2130837506;
    
    public static final int abc_ab_bottom_transparent_light_holo = 2130837507;
    
    public static final int abc_ab_share_pack_holo_dark = 2130837508;
    
    public static final int abc_ab_share_pack_holo_light = 2130837509;
    
    public static final int abc_ab_solid_dark_holo = 2130837510;
    
    public static final int abc_ab_solid_light_holo = 2130837511;
    
    public static final int abc_ab_stacked_solid_dark_holo = 2130837512;
    
    public static final int abc_ab_stacked_solid_light_holo = 2130837513;
    
    public static final int abc_ab_stacked_transparent_dark_holo = 2130837514;
    
    public static final int abc_ab_stacked_transparent_light_holo = 2130837515;
    
    public static final int abc_ab_transparent_dark_holo = 2130837516;
    
    public static final int abc_ab_transparent_light_holo = 2130837517;
    
    public static final int abc_cab_background_bottom_holo_dark = 2130837518;
    
    public static final int abc_cab_background_bottom_holo_light = 2130837519;
    
    public static final int abc_cab_background_top_holo_dark = 2130837520;
    
    public static final int abc_cab_background_top_holo_light = 2130837521;
    
    public static final int abc_ic_ab_back_holo_dark = 2130837522;
    
    public static final int abc_ic_ab_back_holo_light = 2130837523;
    
    public static final int abc_ic_cab_done_holo_dark = 2130837524;
    
    public static final int abc_ic_cab_done_holo_light = 2130837525;
    
    public static final int abc_ic_clear = 2130837526;
    
    public static final int abc_ic_clear_disabled = 2130837527;
    
    public static final int abc_ic_clear_holo_light = 2130837528;
    
    public static final int abc_ic_clear_normal = 2130837529;
    
    public static final int abc_ic_clear_search_api_disabled_holo_light = 2130837530;
    
    public static final int abc_ic_clear_search_api_holo_light = 2130837531;
    
    public static final int abc_ic_commit_search_api_holo_dark = 2130837532;
    
    public static final int abc_ic_commit_search_api_holo_light = 2130837533;
    
    public static final int abc_ic_go = 2130837534;
    
    public static final int abc_ic_go_search_api_holo_light = 2130837535;
    
    public static final int abc_ic_menu_moreoverflow_normal_holo_dark = 2130837536;
    
    public static final int abc_ic_menu_moreoverflow_normal_holo_light = 2130837537;
    
    public static final int abc_ic_menu_share_holo_dark = 2130837538;
    
    public static final int abc_ic_menu_share_holo_light = 2130837539;
    
    public static final int abc_ic_search = 2130837540;
    
    public static final int abc_ic_search_api_holo_light = 2130837541;
    
    public static final int abc_ic_voice_search = 2130837542;
    
    public static final int abc_ic_voice_search_api_holo_light = 2130837543;
    
    public static final int abc_item_background_holo_dark = 2130837544;
    
    public static final int abc_item_background_holo_light = 2130837545;
    
    public static final int abc_list_divider_holo_dark = 2130837546;
    
    public static final int abc_list_divider_holo_light = 2130837547;
    
    public static final int abc_list_focused_holo = 2130837548;
    
    public static final int abc_list_longpressed_holo = 2130837549;
    
    public static final int abc_list_pressed_holo_dark = 2130837550;
    
    public static final int abc_list_pressed_holo_light = 2130837551;
    
    public static final int abc_list_selector_background_transition_holo_dark = 2130837552;
    
    public static final int abc_list_selector_background_transition_holo_light = 2130837553;
    
    public static final int abc_list_selector_disabled_holo_dark = 2130837554;
    
    public static final int abc_list_selector_disabled_holo_light = 2130837555;
    
    public static final int abc_list_selector_holo_dark = 2130837556;
    
    public static final int abc_list_selector_holo_light = 2130837557;
    
    public static final int abc_menu_dropdown_panel_holo_dark = 2130837558;
    
    public static final int abc_menu_dropdown_panel_holo_light = 2130837559;
    
    public static final int abc_menu_hardkey_panel_holo_dark = 2130837560;
    
    public static final int abc_menu_hardkey_panel_holo_light = 2130837561;
    
    public static final int abc_search_dropdown_dark = 2130837562;
    
    public static final int abc_search_dropdown_light = 2130837563;
    
    public static final int abc_spinner_ab_default_holo_dark = 2130837564;
    
    public static final int abc_spinner_ab_default_holo_light = 2130837565;
    
    public static final int abc_spinner_ab_disabled_holo_dark = 2130837566;
    
    public static final int abc_spinner_ab_disabled_holo_light = 2130837567;
    
    public static final int abc_spinner_ab_focused_holo_dark = 2130837568;
    
    public static final int abc_spinner_ab_focused_holo_light = 2130837569;
    
    public static final int abc_spinner_ab_holo_dark = 2130837570;
    
    public static final int abc_spinner_ab_holo_light = 2130837571;
    
    public static final int abc_spinner_ab_pressed_holo_dark = 2130837572;
    
    public static final int abc_spinner_ab_pressed_holo_light = 2130837573;
    
    public static final int abc_tab_indicator_ab_holo = 2130837574;
    
    public static final int abc_tab_selected_focused_holo = 2130837575;
    
    public static final int abc_tab_selected_holo = 2130837576;
    
    public static final int abc_tab_selected_pressed_holo = 2130837577;
    
    public static final int abc_tab_unselected_pressed_holo = 2130837578;
    
    public static final int abc_textfield_search_default_holo_dark = 2130837579;
    
    public static final int abc_textfield_search_default_holo_light = 2130837580;
    
    public static final int abc_textfield_search_right_default_holo_dark = 2130837581;
    
    public static final int abc_textfield_search_right_default_holo_light = 2130837582;
    
    public static final int abc_textfield_search_right_selected_holo_dark = 2130837583;
    
    public static final int abc_textfield_search_right_selected_holo_light = 2130837584;
    
    public static final int abc_textfield_search_selected_holo_dark = 2130837585;
    
    public static final int abc_textfield_search_selected_holo_light = 2130837586;
    
    public static final int abc_textfield_searchview_holo_dark = 2130837587;
    
    public static final int abc_textfield_searchview_holo_light = 2130837588;
    
    public static final int abc_textfield_searchview_right_holo_dark = 2130837589;
    
    public static final int abc_textfield_searchview_right_holo_light = 2130837590;
    
    public static final int ic_launcher = 2130837591;
  }
  
  public static final class id {
    public static final int action_bar = 2131165212;
    
    public static final int action_bar_activity_content = 2131165204;
    
    public static final int action_bar_container = 2131165211;
    
    public static final int action_bar_overlay_layout = 2131165215;
    
    public static final int action_bar_root = 2131165210;
    
    public static final int action_bar_subtitle = 2131165219;
    
    public static final int action_bar_title = 2131165218;
    
    public static final int action_context_bar = 2131165213;
    
    public static final int action_menu_divider = 2131165205;
    
    public static final int action_menu_presenter = 2131165206;
    
    public static final int action_mode_close_button = 2131165220;
    
    public static final int action_settings = 2131165261;
    
    public static final int activity_chooser_view_content = 2131165221;
    
    public static final int always = 2131165199;
    
    public static final int beginning = 2131165194;
    
    public static final int bt_refresh = 2131165250;
    
    public static final int checkbox = 2131165229;
    
    public static final int collapseActionView = 2131165201;
    
    public static final int container = 2131165244;
    
    public static final int content = 2131165259;
    
    public static final int content_placeholder = 2131165249;
    
    public static final int date = 2131165254;
    
    public static final int default_activity_button = 2131165224;
    
    public static final int detail_image = 2131165252;
    
    public static final int dialog = 2131165202;
    
    public static final int disableHome = 2131165192;
    
    public static final int dropdown = 2131165203;
    
    public static final int edit_query = 2131165232;
    
    public static final int end = 2131165196;
    
    public static final int expand_activities_button = 2131165222;
    
    public static final int expanded_menu = 2131165228;
    
    public static final int headline = 2131165255;
    
    public static final int home = 2131165207;
    
    public static final int homeAsUp = 2131165189;
    
    public static final int icon = 2131165226;
    
    public static final int ifRoom = 2131165198;
    
    public static final int image = 2131165223;
    
    public static final int lastUpdate = 2131165251;
    
    public static final int linearLayout = 2131165245;
    
    public static final int linearLayout2 = 2131165248;
    
    public static final int linkStatus = 2131165246;
    
    public static final int listMode = 2131165185;
    
    public static final int list_item = 2131165225;
    
    public static final int media = 2131165257;
    
    public static final int middle = 2131165195;
    
    public static final int never = 2131165197;
    
    public static final int none = 2131165193;
    
    public static final int normal = 2131165184;
    
    public static final int progressBar = 2131165247;
    
    public static final int progress_circular = 2131165208;
    
    public static final int progress_horizontal = 2131165209;
    
    public static final int radio = 2131165231;
    
    public static final int scroll = 2131165253;
    
    public static final int search_badge = 2131165234;
    
    public static final int search_bar = 2131165233;
    
    public static final int search_button = 2131165235;
    
    public static final int search_close_btn = 2131165240;
    
    public static final int search_edit_frame = 2131165236;
    
    public static final int search_go_btn = 2131165242;
    
    public static final int search_mag_icon = 2131165237;
    
    public static final int search_plate = 2131165238;
    
    public static final int search_src_text = 2131165239;
    
    public static final int search_voice_btn = 2131165243;
    
    public static final int secondLine = 2131165260;
    
    public static final int shortcut = 2131165230;
    
    public static final int showCustom = 2131165191;
    
    public static final int showHome = 2131165188;
    
    public static final int showTitle = 2131165190;
    
    public static final int space = 2131165256;
    
    public static final int space2 = 2131165258;
    
    public static final int split_action_bar = 2131165214;
    
    public static final int submit_area = 2131165241;
    
    public static final int tabMode = 2131165186;
    
    public static final int title = 2131165227;
    
    public static final int top_action_bar = 2131165216;
    
    public static final int up = 2131165217;
    
    public static final int useLogo = 2131165187;
    
    public static final int withText = 2131165200;
  }
  
  public static final class integer {
    public static final int abc_max_action_buttons = 2131296256;
  }
  
  public static final class layout {
    public static final int abc_action_bar_decor = 2130903040;
    
    public static final int abc_action_bar_decor_include = 2130903041;
    
    public static final int abc_action_bar_decor_overlay = 2130903042;
    
    public static final int abc_action_bar_home = 2130903043;
    
    public static final int abc_action_bar_tab = 2130903044;
    
    public static final int abc_action_bar_tabbar = 2130903045;
    
    public static final int abc_action_bar_title_item = 2130903046;
    
    public static final int abc_action_bar_view_list_nav_layout = 2130903047;
    
    public static final int abc_action_menu_item_layout = 2130903048;
    
    public static final int abc_action_menu_layout = 2130903049;
    
    public static final int abc_action_mode_bar = 2130903050;
    
    public static final int abc_action_mode_close_item = 2130903051;
    
    public static final int abc_activity_chooser_view = 2130903052;
    
    public static final int abc_activity_chooser_view_include = 2130903053;
    
    public static final int abc_activity_chooser_view_list_item = 2130903054;
    
    public static final int abc_expanded_menu_layout = 2130903055;
    
    public static final int abc_list_menu_item_checkbox = 2130903056;
    
    public static final int abc_list_menu_item_icon = 2130903057;
    
    public static final int abc_list_menu_item_layout = 2130903058;
    
    public static final int abc_list_menu_item_radio = 2130903059;
    
    public static final int abc_popup_menu_item_layout = 2130903060;
    
    public static final int abc_search_dropdown_item_icons_2line = 2130903061;
    
    public static final int abc_search_view = 2130903062;
    
    public static final int abc_simple_decor = 2130903063;
    
    public static final int activity_be_news = 2130903064;
    
    public static final int fragment_detail_image_view = 2130903065;
    
    public static final int fragment_item = 2130903071;
    
    public static final int fragment_item_grid = 2130903066;
    
    public static final int fragment_item_list = 2130903067;
    
    public static final int item_layout_left = 2130903068;
    
    public static final int item_layout_right = 2130903069;
    
    public static final int support_simple_spinner_dropdown_item = 2130903070;
  }
  
  public static final class menu {
    public static final int be_news_menu = 2131492864;
  }
  
  public static final class string {
    public static final int abc_action_bar_home_description = 2131361792;
    
    public static final int abc_action_bar_up_description = 2131361793;
    
    public static final int abc_action_menu_overflow_description = 2131361794;
    
    public static final int abc_action_mode_done = 2131361795;
    
    public static final int abc_activity_chooser_view_see_all = 2131361796;
    
    public static final int abc_activitychooserview_choose_application = 2131361797;
    
    public static final int abc_searchview_description_clear = 2131361798;
    
    public static final int abc_searchview_description_query = 2131361799;
    
    public static final int abc_searchview_description_search = 2131361800;
    
    public static final int abc_searchview_description_submit = 2131361801;
    
    public static final int abc_searchview_description_voice = 2131361802;
    
    public static final int abc_shareactionprovider_share_with = 2131361803;
    
    public static final int abc_shareactionprovider_share_with_application = 2131361804;
    
    public static final int action_settings = 2131361805;
    
    public static final int app_name = 2131361806;
    
    public static final int bt_refresh_text = 2131361807;
    
    public static final int dateFormat = 2131361808;
    
    public static final int hello_blank_fragment = 2131361809;
    
    public static final int hello_world = 2131361810;
    
    public static final int news_space = 2131361811;
  }
  
  public static final class style {
    public static final int AppTheme = 2131427328;
    
    public static final int TextAppearance_AppCompat_Base_CompactMenu_Dialog = 2131427329;
    
    public static final int TextAppearance_AppCompat_Base_SearchResult = 2131427330;
    
    public static final int TextAppearance_AppCompat_Base_SearchResult_Subtitle = 2131427331;
    
    public static final int TextAppearance_AppCompat_Base_SearchResult_Title = 2131427332;
    
    public static final int TextAppearance_AppCompat_Base_Widget_PopupMenu_Large = 2131427333;
    
    public static final int TextAppearance_AppCompat_Base_Widget_PopupMenu_Small = 2131427334;
    
    public static final int TextAppearance_AppCompat_Light_Base_SearchResult = 2131427335;
    
    public static final int TextAppearance_AppCompat_Light_Base_SearchResult_Subtitle = 2131427336;
    
    public static final int TextAppearance_AppCompat_Light_Base_SearchResult_Title = 2131427337;
    
    public static final int TextAppearance_AppCompat_Light_Base_Widget_PopupMenu_Large = 2131427338;
    
    public static final int TextAppearance_AppCompat_Light_Base_Widget_PopupMenu_Small = 2131427339;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Subtitle = 2131427340;
    
    public static final int TextAppearance_AppCompat_Light_SearchResult_Title = 2131427341;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Large = 2131427342;
    
    public static final int TextAppearance_AppCompat_Light_Widget_PopupMenu_Small = 2131427343;
    
    public static final int TextAppearance_AppCompat_SearchResult_Subtitle = 2131427344;
    
    public static final int TextAppearance_AppCompat_SearchResult_Title = 2131427345;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Menu = 2131427346;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle = 2131427347;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Subtitle_Inverse = 2131427348;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title = 2131427349;
    
    public static final int TextAppearance_AppCompat_Widget_ActionBar_Title_Inverse = 2131427350;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle = 2131427351;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Subtitle_Inverse = 2131427352;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title = 2131427353;
    
    public static final int TextAppearance_AppCompat_Widget_ActionMode_Title_Inverse = 2131427354;
    
    public static final int TextAppearance_AppCompat_Widget_Base_ActionBar_Menu = 2131427355;
    
    public static final int TextAppearance_AppCompat_Widget_Base_ActionBar_Subtitle = 2131427356;
    
    public static final int TextAppearance_AppCompat_Widget_Base_ActionBar_Subtitle_Inverse = 2131427357;
    
    public static final int TextAppearance_AppCompat_Widget_Base_ActionBar_Title = 2131427358;
    
    public static final int TextAppearance_AppCompat_Widget_Base_ActionBar_Title_Inverse = 2131427359;
    
    public static final int TextAppearance_AppCompat_Widget_Base_ActionMode_Subtitle = 2131427360;
    
    public static final int TextAppearance_AppCompat_Widget_Base_ActionMode_Subtitle_Inverse = 2131427361;
    
    public static final int TextAppearance_AppCompat_Widget_Base_ActionMode_Title = 2131427362;
    
    public static final int TextAppearance_AppCompat_Widget_Base_ActionMode_Title_Inverse = 2131427363;
    
    public static final int TextAppearance_AppCompat_Widget_Base_DropDownItem = 2131427364;
    
    public static final int TextAppearance_AppCompat_Widget_DropDownItem = 2131427365;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Large = 2131427366;
    
    public static final int TextAppearance_AppCompat_Widget_PopupMenu_Small = 2131427367;
    
    public static final int TextAppearance_Widget_AppCompat_Base_ExpandedMenu_Item = 2131427368;
    
    public static final int TextAppearance_Widget_AppCompat_ExpandedMenu_Item = 2131427369;
    
    public static final int Theme_AppCompat = 2131427370;
    
    public static final int Theme_AppCompat_Base_CompactMenu = 2131427371;
    
    public static final int Theme_AppCompat_Base_CompactMenu_Dialog = 2131427372;
    
    public static final int Theme_AppCompat_CompactMenu = 2131427373;
    
    public static final int Theme_AppCompat_CompactMenu_Dialog = 2131427374;
    
    public static final int Theme_AppCompat_DialogWhenLarge = 2131427375;
    
    public static final int Theme_AppCompat_Light = 2131427376;
    
    public static final int Theme_AppCompat_Light_DarkActionBar = 2131427377;
    
    public static final int Theme_AppCompat_Light_DialogWhenLarge = 2131427378;
    
    public static final int Theme_Base = 2131427379;
    
    public static final int Theme_Base_AppCompat = 2131427380;
    
    public static final int Theme_Base_AppCompat_DialogWhenLarge = 2131427383;
    
    public static final int Theme_Base_AppCompat_DialogWhenLarge_Base = 2131427466;
    
    public static final int Theme_Base_AppCompat_Dialog_FixedSize = 2131427381;
    
    public static final int Theme_Base_AppCompat_Dialog_Light_FixedSize = 2131427382;
    
    public static final int Theme_Base_AppCompat_Light = 2131427384;
    
    public static final int Theme_Base_AppCompat_Light_DarkActionBar = 2131427385;
    
    public static final int Theme_Base_AppCompat_Light_DialogWhenLarge = 2131427386;
    
    public static final int Theme_Base_AppCompat_Light_DialogWhenLarge_Base = 2131427467;
    
    public static final int Theme_Base_Light = 2131427387;
    
    public static final int Widget_AppCompat_ActionBar = 2131427388;
    
    public static final int Widget_AppCompat_ActionBar_Solid = 2131427389;
    
    public static final int Widget_AppCompat_ActionBar_TabBar = 2131427390;
    
    public static final int Widget_AppCompat_ActionBar_TabText = 2131427391;
    
    public static final int Widget_AppCompat_ActionBar_TabView = 2131427392;
    
    public static final int Widget_AppCompat_ActionButton = 2131427393;
    
    public static final int Widget_AppCompat_ActionButton_CloseMode = 2131427394;
    
    public static final int Widget_AppCompat_ActionButton_Overflow = 2131427395;
    
    public static final int Widget_AppCompat_ActionMode = 2131427396;
    
    public static final int Widget_AppCompat_ActivityChooserView = 2131427397;
    
    public static final int Widget_AppCompat_AutoCompleteTextView = 2131427398;
    
    public static final int Widget_AppCompat_Base_ActionBar = 2131427399;
    
    public static final int Widget_AppCompat_Base_ActionBar_Solid = 2131427400;
    
    public static final int Widget_AppCompat_Base_ActionBar_TabBar = 2131427401;
    
    public static final int Widget_AppCompat_Base_ActionBar_TabText = 2131427402;
    
    public static final int Widget_AppCompat_Base_ActionBar_TabView = 2131427403;
    
    public static final int Widget_AppCompat_Base_ActionButton = 2131427404;
    
    public static final int Widget_AppCompat_Base_ActionButton_CloseMode = 2131427405;
    
    public static final int Widget_AppCompat_Base_ActionButton_Overflow = 2131427406;
    
    public static final int Widget_AppCompat_Base_ActionMode = 2131427407;
    
    public static final int Widget_AppCompat_Base_ActivityChooserView = 2131427408;
    
    public static final int Widget_AppCompat_Base_AutoCompleteTextView = 2131427409;
    
    public static final int Widget_AppCompat_Base_DropDownItem_Spinner = 2131427410;
    
    public static final int Widget_AppCompat_Base_ListPopupWindow = 2131427411;
    
    public static final int Widget_AppCompat_Base_ListView_DropDown = 2131427412;
    
    public static final int Widget_AppCompat_Base_ListView_Menu = 2131427413;
    
    public static final int Widget_AppCompat_Base_PopupMenu = 2131427414;
    
    public static final int Widget_AppCompat_Base_ProgressBar = 2131427415;
    
    public static final int Widget_AppCompat_Base_ProgressBar_Horizontal = 2131427416;
    
    public static final int Widget_AppCompat_Base_Spinner = 2131427417;
    
    public static final int Widget_AppCompat_DropDownItem_Spinner = 2131427418;
    
    public static final int Widget_AppCompat_Light_ActionBar = 2131427419;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid = 2131427420;
    
    public static final int Widget_AppCompat_Light_ActionBar_Solid_Inverse = 2131427421;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar = 2131427422;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabBar_Inverse = 2131427423;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText = 2131427424;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabText_Inverse = 2131427425;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView = 2131427426;
    
    public static final int Widget_AppCompat_Light_ActionBar_TabView_Inverse = 2131427427;
    
    public static final int Widget_AppCompat_Light_ActionButton = 2131427428;
    
    public static final int Widget_AppCompat_Light_ActionButton_CloseMode = 2131427429;
    
    public static final int Widget_AppCompat_Light_ActionButton_Overflow = 2131427430;
    
    public static final int Widget_AppCompat_Light_ActionMode_Inverse = 2131427431;
    
    public static final int Widget_AppCompat_Light_ActivityChooserView = 2131427432;
    
    public static final int Widget_AppCompat_Light_AutoCompleteTextView = 2131427433;
    
    public static final int Widget_AppCompat_Light_Base_ActionBar = 2131427434;
    
    public static final int Widget_AppCompat_Light_Base_ActionBar_Solid = 2131427435;
    
    public static final int Widget_AppCompat_Light_Base_ActionBar_Solid_Inverse = 2131427436;
    
    public static final int Widget_AppCompat_Light_Base_ActionBar_TabBar = 2131427437;
    
    public static final int Widget_AppCompat_Light_Base_ActionBar_TabBar_Inverse = 2131427438;
    
    public static final int Widget_AppCompat_Light_Base_ActionBar_TabText = 2131427439;
    
    public static final int Widget_AppCompat_Light_Base_ActionBar_TabText_Inverse = 2131427440;
    
    public static final int Widget_AppCompat_Light_Base_ActionBar_TabView = 2131427441;
    
    public static final int Widget_AppCompat_Light_Base_ActionBar_TabView_Inverse = 2131427442;
    
    public static final int Widget_AppCompat_Light_Base_ActionButton = 2131427443;
    
    public static final int Widget_AppCompat_Light_Base_ActionButton_CloseMode = 2131427444;
    
    public static final int Widget_AppCompat_Light_Base_ActionButton_Overflow = 2131427445;
    
    public static final int Widget_AppCompat_Light_Base_ActionMode_Inverse = 2131427446;
    
    public static final int Widget_AppCompat_Light_Base_ActivityChooserView = 2131427447;
    
    public static final int Widget_AppCompat_Light_Base_AutoCompleteTextView = 2131427448;
    
    public static final int Widget_AppCompat_Light_Base_DropDownItem_Spinner = 2131427449;
    
    public static final int Widget_AppCompat_Light_Base_ListPopupWindow = 2131427450;
    
    public static final int Widget_AppCompat_Light_Base_ListView_DropDown = 2131427451;
    
    public static final int Widget_AppCompat_Light_Base_PopupMenu = 2131427452;
    
    public static final int Widget_AppCompat_Light_Base_Spinner = 2131427453;
    
    public static final int Widget_AppCompat_Light_DropDownItem_Spinner = 2131427454;
    
    public static final int Widget_AppCompat_Light_ListPopupWindow = 2131427455;
    
    public static final int Widget_AppCompat_Light_ListView_DropDown = 2131427456;
    
    public static final int Widget_AppCompat_Light_PopupMenu = 2131427457;
    
    public static final int Widget_AppCompat_Light_Spinner_DropDown_ActionBar = 2131427458;
    
    public static final int Widget_AppCompat_ListPopupWindow = 2131427459;
    
    public static final int Widget_AppCompat_ListView_DropDown = 2131427460;
    
    public static final int Widget_AppCompat_ListView_Menu = 2131427461;
    
    public static final int Widget_AppCompat_PopupMenu = 2131427462;
    
    public static final int Widget_AppCompat_ProgressBar = 2131427463;
    
    public static final int Widget_AppCompat_ProgressBar_Horizontal = 2131427464;
    
    public static final int Widget_AppCompat_Spinner_DropDown_ActionBar = 2131427465;
  }
  
  public static final class styleable {
    public static final int[] ActionBar = new int[] { 
        2130772000, 2130772030, 2130772031, 2130772032, 2130772033, 2130772034, 2130772035, 2130772036, 2130772037, 2130772038, 
        2130772039, 2130772040, 2130772041, 2130772042, 2130772043, 2130772044, 2130772045, 2130772046, 2130772047 };
    
    public static final int[] ActionBarLayout = new int[] { 16842931 };
    
    public static final int ActionBarLayout_android_layout_gravity = 0;
    
    public static final int[] ActionBarWindow = new int[] { 2130772048, 2130772049, 2130772050, 2130772051, 2130772052, 2130772053, 2130772054 };
    
    public static final int ActionBarWindow_windowActionBar = 0;
    
    public static final int ActionBarWindow_windowActionBarOverlay = 1;
    
    public static final int ActionBarWindow_windowFixedHeightMajor = 6;
    
    public static final int ActionBarWindow_windowFixedHeightMinor = 4;
    
    public static final int ActionBarWindow_windowFixedWidthMajor = 3;
    
    public static final int ActionBarWindow_windowFixedWidthMinor = 5;
    
    public static final int ActionBarWindow_windowSplitActionBar = 2;
    
    public static final int ActionBar_background = 10;
    
    public static final int ActionBar_backgroundSplit = 12;
    
    public static final int ActionBar_backgroundStacked = 11;
    
    public static final int ActionBar_customNavigationLayout = 13;
    
    public static final int ActionBar_displayOptions = 3;
    
    public static final int ActionBar_divider = 9;
    
    public static final int ActionBar_height = 0;
    
    public static final int ActionBar_homeLayout = 14;
    
    public static final int ActionBar_icon = 7;
    
    public static final int ActionBar_indeterminateProgressStyle = 16;
    
    public static final int ActionBar_itemPadding = 18;
    
    public static final int ActionBar_logo = 8;
    
    public static final int ActionBar_navigationMode = 2;
    
    public static final int ActionBar_progressBarPadding = 17;
    
    public static final int ActionBar_progressBarStyle = 15;
    
    public static final int ActionBar_subtitle = 4;
    
    public static final int ActionBar_subtitleTextStyle = 6;
    
    public static final int ActionBar_title = 1;
    
    public static final int ActionBar_titleTextStyle = 5;
    
    public static final int[] ActionMenuItemView = new int[] { 16843071 };
    
    public static final int ActionMenuItemView_android_minWidth = 0;
    
    public static final int[] ActionMenuView = new int[0];
    
    public static final int[] ActionMode = new int[] { 2130772000, 2130772034, 2130772035, 2130772039, 2130772041 };
    
    public static final int ActionMode_background = 3;
    
    public static final int ActionMode_backgroundSplit = 4;
    
    public static final int ActionMode_height = 0;
    
    public static final int ActionMode_subtitleTextStyle = 2;
    
    public static final int ActionMode_titleTextStyle = 1;
    
    public static final int[] ActivityChooserView = new int[] { 2130772055, 2130772056 };
    
    public static final int ActivityChooserView_expandActivityOverflowButtonDrawable = 1;
    
    public static final int ActivityChooserView_initialActivityCount = 0;
    
    public static final int[] CompatTextView = new int[] { 2130772057 };
    
    public static final int CompatTextView_textAllCaps = 0;
    
    public static final int[] LinearLayoutICS = new int[] { 2130772038, 2130772058, 2130772059 };
    
    public static final int LinearLayoutICS_divider = 0;
    
    public static final int LinearLayoutICS_dividerPadding = 2;
    
    public static final int LinearLayoutICS_showDividers = 1;
    
    public static final int[] MenuGroup = new int[] { 16842766, 16842960, 16843156, 16843230, 16843231, 16843232 };
    
    public static final int MenuGroup_android_checkableBehavior = 5;
    
    public static final int MenuGroup_android_enabled = 0;
    
    public static final int MenuGroup_android_id = 1;
    
    public static final int MenuGroup_android_menuCategory = 3;
    
    public static final int MenuGroup_android_orderInCategory = 4;
    
    public static final int MenuGroup_android_visible = 2;
    
    public static final int[] MenuItem = new int[] { 
        16842754, 16842766, 16842960, 16843014, 16843156, 16843230, 16843231, 16843233, 16843234, 16843235, 
        16843236, 16843237, 16843375, 2130772060, 2130772061, 2130772062, 2130772063 };
    
    public static final int MenuItem_actionLayout = 14;
    
    public static final int MenuItem_actionProviderClass = 16;
    
    public static final int MenuItem_actionViewClass = 15;
    
    public static final int MenuItem_android_alphabeticShortcut = 9;
    
    public static final int MenuItem_android_checkable = 11;
    
    public static final int MenuItem_android_checked = 3;
    
    public static final int MenuItem_android_enabled = 1;
    
    public static final int MenuItem_android_icon = 0;
    
    public static final int MenuItem_android_id = 2;
    
    public static final int MenuItem_android_menuCategory = 5;
    
    public static final int MenuItem_android_numericShortcut = 10;
    
    public static final int MenuItem_android_onClick = 12;
    
    public static final int MenuItem_android_orderInCategory = 6;
    
    public static final int MenuItem_android_title = 7;
    
    public static final int MenuItem_android_titleCondensed = 8;
    
    public static final int MenuItem_android_visible = 4;
    
    public static final int MenuItem_showAsAction = 13;
    
    public static final int[] MenuView = new int[] { 16842926, 16843052, 16843053, 16843054, 16843055, 16843056, 16843057, 16843754 };
    
    public static final int MenuView_android_headerBackground = 4;
    
    public static final int MenuView_android_horizontalDivider = 2;
    
    public static final int MenuView_android_itemBackground = 5;
    
    public static final int MenuView_android_itemIconDisabledAlpha = 6;
    
    public static final int MenuView_android_itemTextAppearance = 1;
    
    public static final int MenuView_android_preserveIconSpacing = 7;
    
    public static final int MenuView_android_verticalDivider = 3;
    
    public static final int MenuView_android_windowAnimationStyle = 0;
    
    public static final int[] SearchView = new int[] { 16843039, 16843296, 16843364, 2130772064, 2130772065 };
    
    public static final int SearchView_android_imeOptions = 2;
    
    public static final int SearchView_android_inputType = 1;
    
    public static final int SearchView_android_maxWidth = 0;
    
    public static final int SearchView_iconifiedByDefault = 3;
    
    public static final int SearchView_queryHint = 4;
    
    public static final int[] Spinner = new int[] { 16842927, 16843125, 16843126, 16843362, 16843436, 16843437, 2130772066, 2130772067, 2130772068, 2130772069 };
    
    public static final int Spinner_android_dropDownHorizontalOffset = 4;
    
    public static final int Spinner_android_dropDownSelector = 1;
    
    public static final int Spinner_android_dropDownVerticalOffset = 5;
    
    public static final int Spinner_android_dropDownWidth = 3;
    
    public static final int Spinner_android_gravity = 0;
    
    public static final int Spinner_android_popupBackground = 2;
    
    public static final int Spinner_disableChildrenWhenDisabled = 9;
    
    public static final int Spinner_popupPromptView = 8;
    
    public static final int Spinner_prompt = 6;
    
    public static final int Spinner_spinnerMode = 7;
    
    public static final int[] Theme = new int[] { 2130772070, 2130772071, 2130772072, 2130772073, 2130772074, 2130772075 };
    
    public static final int Theme_actionDropDownStyle = 0;
    
    public static final int Theme_dropdownListPreferredItemHeight = 1;
    
    public static final int Theme_listChoiceBackgroundIndicator = 5;
    
    public static final int Theme_panelMenuListTheme = 4;
    
    public static final int Theme_panelMenuListWidth = 3;
    
    public static final int Theme_popupMenuStyle = 2;
    
    public static final int[] View = new int[] { 16842970, 2130772076, 2130772077 };
    
    public static final int View_android_focusable = 0;
    
    public static final int View_paddingEnd = 2;
    
    public static final int View_paddingStart = 1;
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/org/benews/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */