package org.benews;

import android.app.Activity;
import android.content.res.AssetManager;
import android.os.AsyncTask;
import android.util.Log;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import javax.net.SocketFactory;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;

public class BackgroundSocket extends Activity implements Runnable {
  public static final String READY = "upAndRunning";
  
  private static final String TAG = "BackgroundSocket";
  
  static int news_n = 0;
  
  private static SocketAsyncTask runningTask;
  
  private static final String serialFile = ".news";
  
  private static final String serialFileTs = ".ts";
  
  private static boolean serviceRunning = false;
  
  static BackgroundSocket singleton;
  
  HashMap<String, String> args_for_bkg = new HashMap<String, String>();
  
  AssetManager assets;
  
  private Thread coreThread;
  
  private String dumpFolder = null;
  
  private String imei = null;
  
  private long last_timestamp = 0L;
  
  private ArrayList<HashMap<String, String>> list;
  
  ArrayList<NewsUpdateListener> listeners = new ArrayList<NewsUpdateListener>();
  
  private BeNews main = null;
  
  private boolean noData = false;
  
  private boolean run = false;
  
  private File serializeFolder;
  
  private PullIntentService serviceMain;
  
  private SocketFactory sf = null;
  
  private Socket socket;
  
  static {
    news_n = 0;
    runningTask = null;
  }
  
  private void Core() {}
  
  public static void Sleep(int paramInt) {
    long l = (paramInt * 1000);
    try {
      Thread.sleep(l);
    } catch (InterruptedException interruptedException) {
      interruptedException.printStackTrace();
    } 
  }
  
  public static BackgroundSocket newCore(PullIntentService paramPullIntentService) {
    if (singleton == null)
      singleton = new BackgroundSocket(); 
    singleton.serviceMain = paramPullIntentService;
    return singleton;
  }
  
  private boolean runUntilStop(HashMap<String, String> paramHashMap) {
    while (true) {
      if (this.run) {
        try {
          if (paramHashMap.containsKey("date"))
            Long.parseLong(paramHashMap.get("date")); 
        } catch (Exception exception) {}
        if (runningTask == null || !runningTask.isRunning()) {
          runningTask = new SocketAsyncTask(paramHashMap);
          runningTask.execute((Object[])new HashMap[] { paramHashMap });
        } 
        if (runningTask != null && runningTask.isRunning() && ((0L != 0L && 0L == runningTask.getLast_timestamp() && !runningTask.isConnectionError()) || runningTask.noData())) {
          Log.d("BackgroundSocket", " (runUntilStop): No new news waiting ...");
          Sleep(60);
        } 
        Sleep(1);
        continue;
      } 
      return false;
    } 
  }
  
  public static BackgroundSocket self() {
    // Byte code:
    //   0: ldc org/benews/BackgroundSocket
    //   2: monitorenter
    //   3: getstatic org/benews/BackgroundSocket.singleton : Lorg/benews/BackgroundSocket;
    //   6: ifnonnull -> 21
    //   9: new org/benews/BackgroundSocket
    //   12: astore_0
    //   13: aload_0
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: putstatic org/benews/BackgroundSocket.singleton : Lorg/benews/BackgroundSocket;
    //   21: getstatic org/benews/BackgroundSocket.singleton : Lorg/benews/BackgroundSocket;
    //   24: astore_0
    //   25: ldc org/benews/BackgroundSocket
    //   27: monitorexit
    //   28: aload_0
    //   29: areturn
    //   30: astore_0
    //   31: ldc org/benews/BackgroundSocket
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	30	finally
    //   21	25	30	finally
  }
  
  public boolean Start() {
    boolean bool = true;
    if (serviceRunning == true)
      return false; 
    this.coreThread = new Thread(this);
    try {
      setRun(true);
      this.coreThread.start();
      serviceRunning = true;
    } catch (Exception exception) {}
    return bool;
  }
  
  public String getDumpFolder() {
    return this.dumpFolder;
  }
  
  public String getImei() {
    return this.imei;
  }
  
  public ArrayList<HashMap<String, String>> getList() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield list : Ljava/util/ArrayList;
    //   6: ifnonnull -> 66
    //   9: new java/io/File
    //   12: astore_1
    //   13: aload_1
    //   14: aload_0
    //   15: invokevirtual getSerialFile : ()Ljava/lang/String;
    //   18: invokespecial <init> : (Ljava/lang/String;)V
    //   21: aload_1
    //   22: invokevirtual exists : ()Z
    //   25: istore_2
    //   26: iload_2
    //   27: ifeq -> 66
    //   30: new java/io/FileInputStream
    //   33: astore_3
    //   34: aload_3
    //   35: aload_0
    //   36: invokevirtual getSerialFile : ()Ljava/lang/String;
    //   39: invokespecial <init> : (Ljava/lang/String;)V
    //   42: new java/io/ObjectInputStream
    //   45: astore_1
    //   46: aload_1
    //   47: aload_3
    //   48: invokespecial <init> : (Ljava/io/InputStream;)V
    //   51: aload_0
    //   52: aload_1
    //   53: invokevirtual readObject : ()Ljava/lang/Object;
    //   56: checkcast java/util/ArrayList
    //   59: putfield list : Ljava/util/ArrayList;
    //   62: aload_1
    //   63: invokevirtual close : ()V
    //   66: aload_0
    //   67: getfield list : Ljava/util/ArrayList;
    //   70: ifnonnull -> 94
    //   73: ldc 'BackgroundSocket'
    //   75: ldc ' (getList) initializing list'
    //   77: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   80: pop
    //   81: new java/util/ArrayList
    //   84: astore_1
    //   85: aload_1
    //   86: invokespecial <init> : ()V
    //   89: aload_0
    //   90: aload_1
    //   91: putfield list : Ljava/util/ArrayList;
    //   94: new java/io/File
    //   97: astore_1
    //   98: aload_1
    //   99: aload_0
    //   100: invokevirtual getSerialFileTs : ()Ljava/lang/String;
    //   103: invokespecial <init> : (Ljava/lang/String;)V
    //   106: aload_1
    //   107: invokevirtual exists : ()Z
    //   110: istore_2
    //   111: iload_2
    //   112: ifeq -> 154
    //   115: new java/io/FileInputStream
    //   118: astore_3
    //   119: aload_3
    //   120: aload_0
    //   121: invokevirtual getSerialFileTs : ()Ljava/lang/String;
    //   124: invokespecial <init> : (Ljava/lang/String;)V
    //   127: new java/io/ObjectInputStream
    //   130: astore_1
    //   131: aload_1
    //   132: aload_3
    //   133: invokespecial <init> : (Ljava/io/InputStream;)V
    //   136: aload_0
    //   137: aload_1
    //   138: invokevirtual readObject : ()Ljava/lang/Object;
    //   141: checkcast java/lang/Long
    //   144: invokevirtual longValue : ()J
    //   147: putfield last_timestamp : J
    //   150: aload_1
    //   151: invokevirtual close : ()V
    //   154: aload_0
    //   155: getfield list : Ljava/util/ArrayList;
    //   158: astore_1
    //   159: aload_0
    //   160: monitorexit
    //   161: aload_1
    //   162: areturn
    //   163: astore_3
    //   164: new java/lang/StringBuilder
    //   167: astore_1
    //   168: aload_1
    //   169: invokespecial <init> : ()V
    //   172: ldc 'BackgroundSocket'
    //   174: aload_1
    //   175: ldc_w ' (getList):'
    //   178: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: aload_3
    //   182: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   185: invokevirtual toString : ()Ljava/lang/String;
    //   188: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   191: pop
    //   192: aload_3
    //   193: invokevirtual printStackTrace : ()V
    //   196: goto -> 66
    //   199: astore_1
    //   200: aload_0
    //   201: monitorexit
    //   202: aload_1
    //   203: athrow
    //   204: astore_1
    //   205: new java/lang/StringBuilder
    //   208: astore_3
    //   209: aload_3
    //   210: invokespecial <init> : ()V
    //   213: ldc 'BackgroundSocket'
    //   215: aload_3
    //   216: ldc_w ' (getList Ts):'
    //   219: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   222: aload_1
    //   223: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   226: invokevirtual toString : ()Ljava/lang/String;
    //   229: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   232: pop
    //   233: aload_1
    //   234: invokevirtual printStackTrace : ()V
    //   237: goto -> 154
    // Exception table:
    //   from	to	target	type
    //   2	26	199	finally
    //   30	66	163	java/lang/Exception
    //   30	66	199	finally
    //   66	94	199	finally
    //   94	111	199	finally
    //   115	154	204	java/lang/Exception
    //   115	154	199	finally
    //   154	159	199	finally
    //   164	196	199	finally
    //   205	237	199	finally
  }
  
  public String getSerialFile() {
    return this.serializeFolder.getAbsolutePath() + "/" + ".news";
  }
  
  public String getSerialFileTs() {
    return this.serializeFolder.getAbsolutePath() + "/" + ".ts";
  }
  
  public boolean isRunning() {
    return (runningTask == null) ? false : runningTask.isRunning();
  }
  
  public boolean isThreadStarted() {
    return (this.coreThread != null && this.coreThread.isAlive());
  }
  
  public void reset_news() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: lconst_0
    //   4: putfield last_timestamp : J
    //   7: aload_0
    //   8: getfield list : Ljava/util/ArrayList;
    //   11: invokevirtual clear : ()V
    //   14: aload_0
    //   15: invokevirtual serialise : ()V
    //   18: aload_0
    //   19: invokevirtual updateListeners : ()V
    //   22: iconst_1
    //   23: invokestatic Sleep : (I)V
    //   26: ldc 'BackgroundSocket'
    //   28: ldc_w ' (reset_news):Done'
    //   31: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   34: pop
    //   35: aload_0
    //   36: iconst_0
    //   37: putfield noData : Z
    //   40: aload_0
    //   41: getfield args_for_bkg : Ljava/util/HashMap;
    //   44: ldc 'date'
    //   46: ldc_w '0'
    //   49: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   52: pop
    //   53: aload_0
    //   54: monitorexit
    //   55: return
    //   56: astore_1
    //   57: new java/lang/StringBuilder
    //   60: astore_2
    //   61: aload_2
    //   62: invokespecial <init> : ()V
    //   65: ldc 'BackgroundSocket'
    //   67: aload_2
    //   68: ldc_w ' (setStop):'
    //   71: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   74: aload_1
    //   75: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   78: invokevirtual toString : ()Ljava/lang/String;
    //   81: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   84: pop
    //   85: goto -> 18
    //   88: astore_2
    //   89: aload_0
    //   90: monitorexit
    //   91: aload_2
    //   92: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	88	finally
    //   14	18	56	java/lang/Exception
    //   14	18	88	finally
    //   18	53	88	finally
    //   57	85	88	finally
  }
  
  public void run() {
    this.args_for_bkg.put("date", "0");
    this.args_for_bkg.put("checksum", "0");
    getList();
    updateListeners();
    while (true) {
      runUntilStop(this.args_for_bkg);
      Sleep(2);
    } 
  }
  
  public void saveStauts() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual serialise_list : ()V
    //   6: aload_0
    //   7: monitorexit
    //   8: return
    //   9: astore_1
    //   10: new java/lang/StringBuilder
    //   13: astore_2
    //   14: aload_2
    //   15: invokespecial <init> : ()V
    //   18: ldc 'BackgroundSocket'
    //   20: aload_2
    //   21: ldc_w ' (saveStauts):'
    //   24: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   27: aload_1
    //   28: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   31: invokevirtual toString : ()Ljava/lang/String;
    //   34: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   37: pop
    //   38: goto -> 6
    //   41: astore_2
    //   42: aload_0
    //   43: monitorexit
    //   44: aload_2
    //   45: athrow
    // Exception table:
    //   from	to	target	type
    //   2	6	9	java/lang/Exception
    //   2	6	41	finally
    //   10	38	41	finally
  }
  
  public void serialise() throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual serialise_list : ()V
    //   6: aload_0
    //   7: invokevirtual serialise_ts : ()V
    //   10: aload_0
    //   11: monitorexit
    //   12: return
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	13	finally
  }
  
  public void serialise_list() throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/io/FileOutputStream
    //   5: astore_1
    //   6: aload_1
    //   7: aload_0
    //   8: invokevirtual getSerialFile : ()Ljava/lang/String;
    //   11: invokespecial <init> : (Ljava/lang/String;)V
    //   14: new java/io/ObjectOutputStream
    //   17: aload_1
    //   18: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   21: aload_0
    //   22: getfield list : Ljava/util/ArrayList;
    //   25: invokevirtual isEmpty : ()Z
    //   28: ifne -> 64
    //   31: new java/io/FileOutputStream
    //   34: astore_2
    //   35: aload_2
    //   36: aload_0
    //   37: invokevirtual getSerialFile : ()Ljava/lang/String;
    //   40: invokespecial <init> : (Ljava/lang/String;)V
    //   43: new java/io/ObjectOutputStream
    //   46: astore_1
    //   47: aload_1
    //   48: aload_2
    //   49: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   52: aload_1
    //   53: aload_0
    //   54: getfield list : Ljava/util/ArrayList;
    //   57: invokevirtual writeObject : (Ljava/lang/Object;)V
    //   60: aload_1
    //   61: invokevirtual close : ()V
    //   64: aload_0
    //   65: monitorexit
    //   66: return
    //   67: astore_1
    //   68: aload_0
    //   69: monitorexit
    //   70: aload_1
    //   71: athrow
    // Exception table:
    //   from	to	target	type
    //   2	64	67	finally
  }
  
  public void serialise_ts() throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/io/FileOutputStream
    //   5: astore_1
    //   6: aload_1
    //   7: aload_0
    //   8: invokevirtual getSerialFileTs : ()Ljava/lang/String;
    //   11: invokespecial <init> : (Ljava/lang/String;)V
    //   14: new java/io/ObjectOutputStream
    //   17: astore_2
    //   18: aload_2
    //   19: aload_1
    //   20: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   23: new java/lang/Long
    //   26: astore_1
    //   27: aload_1
    //   28: aload_0
    //   29: getfield last_timestamp : J
    //   32: invokespecial <init> : (J)V
    //   35: aload_2
    //   36: aload_1
    //   37: invokevirtual writeObject : (Ljava/lang/Object;)V
    //   40: aload_2
    //   41: invokevirtual close : ()V
    //   44: aload_0
    //   45: monitorexit
    //   46: return
    //   47: astore_2
    //   48: aload_0
    //   49: monitorexit
    //   50: aload_2
    //   51: athrow
    // Exception table:
    //   from	to	target	type
    //   2	44	47	finally
  }
  
  public void setAssets(AssetManager paramAssetManager) {
    this.assets = paramAssetManager;
  }
  
  public void setDumpFolder(String paramString) {
    this.dumpFolder = new String(paramString);
  }
  
  public void setImei(String paramString) {
    this.imei = new String(paramString);
  }
  
  public void setOnNewsUpdateListener(NewsUpdateListener paramNewsUpdateListener) {
    this.listeners.add(paramNewsUpdateListener);
  }
  
  public void setRun(boolean paramBoolean) {
    if (!paramBoolean && this.socket != null)
      (new Thread(new Runnable() {
            public void run() {
              try {
                BackgroundSocket.this.socket.close();
              } catch (Exception exception) {
                exception.printStackTrace();
              } 
            }
          })).start(); 
    this.run = paramBoolean;
  }
  
  public void setSerializeFolder(File paramFile) {
    this.serializeFolder = paramFile;
  }
  
  public void updateListeners() {
    Iterator<NewsUpdateListener> iterator = this.listeners.iterator();
    while (iterator.hasNext())
      ((NewsUpdateListener)iterator.next()).onNewsUpdate(); 
  }
  
  public static interface NewsUpdateListener {
    void onNewsUpdate();
  }
  
  private class SocketAsyncTask extends AsyncTask<HashMap<String, String>, Void, ByteBuffer> {
    private final HashMap<String, String> args;
    
    private boolean connectionError = false;
    
    private boolean running = false;
    
    private SocketAsyncTask(HashMap<String, String> param1HashMap) {
      this.args = param1HashMap;
    }
    
    private Socket createSSLSocket(SocketFactory param1SocketFactory) throws CertificateException, IOException, KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
      SSLSocket sSLSocket = (SSLSocket)param1SocketFactory.createSocket("46.38.48.178", 443);
      HttpsURLConnection.getDefaultHostnameVerifier();
      sSLSocket.startHandshake();
      printServerCertificate(sSLSocket);
      printSocketInfo(sSLSocket);
      return sSLSocket;
    }
    
    private SocketFactory getSocketFactory() throws CertificateException, IOException, KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
      TrustManagerFactory trustManagerFactory;
      null = CertificateFactory.getInstance("X.509");
      InputStream inputStream = BackgroundSocket.this.assets.open("server.crt");
      try {
        Certificate certificate = null.generateCertificate(inputStream);
        PrintStream printStream = System.out;
        StringBuilder stringBuilder = new StringBuilder();
        this();
        printStream.println(stringBuilder.append("ca=").append(((X509Certificate)certificate).getSubjectDN()).toString());
        inputStream.close();
        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
        keyStore.load(null, null);
        keyStore.setCertificateEntry("ca", certificate);
        trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init(keyStore);
        SSLContext sSLContext = SSLContext.getInstance("TLS");
        return sSLContext.getSocketFactory();
      } finally {
        trustManagerFactory.close();
      } 
    }
    
    private void printServerCertificate(SSLSocket param1SSLSocket) {
      try {
        Certificate[] arrayOfCertificate = param1SSLSocket.getSession().getPeerCertificates();
        for (byte b = 0; b < arrayOfCertificate.length; b++) {
          Certificate certificate = arrayOfCertificate[b];
          StringBuilder stringBuilder = new StringBuilder();
          this();
          Log.i("BackgroundSocket", stringBuilder.append("====Certificate:").append(b + 1).append("====").toString());
          stringBuilder = new StringBuilder();
          this();
          Log.i("BackgroundSocket", stringBuilder.append("-Public Key-\n").append(certificate.getPublicKey()).toString());
          stringBuilder = new StringBuilder();
          this();
          Log.i("BackgroundSocket", stringBuilder.append("-Certificate Type-\n ").append(certificate.getType()).toString());
          System.out.println();
        } 
      } catch (SSLPeerUnverifiedException sSLPeerUnverifiedException) {
        Log.i("BackgroundSocket", "Could not verify peer");
        sSLPeerUnverifiedException.printStackTrace();
        System.exit(-1);
      } 
    }
    
    private void printSocketInfo(SSLSocket param1SSLSocket) {
      Log.i("BackgroundSocket", "Socket class: " + param1SSLSocket.getClass());
      Log.i("BackgroundSocket", "   Remote address = " + param1SSLSocket.getInetAddress().toString());
      Log.i("BackgroundSocket", "   Remote port = " + param1SSLSocket.getPort());
      Log.i("BackgroundSocket", "   Local socket address = " + param1SSLSocket.getLocalSocketAddress().toString());
      Log.i("BackgroundSocket", "   Local address = " + param1SSLSocket.getLocalAddress().toString());
      Log.i("BackgroundSocket", "   Local port = " + param1SSLSocket.getLocalPort());
      Log.i("BackgroundSocket", "   Need client authentication = " + param1SSLSocket.getNeedClientAuth());
      SSLSession sSLSession = param1SSLSocket.getSession();
      Log.i("BackgroundSocket", "   Cipher suite = " + sSLSession.getCipherSuite());
      Log.i("BackgroundSocket", "   Protocol = " + sSLSession.getProtocol());
    }
    
    private void publishProgress(int param1Int) {}
    
    protected ByteBuffer doInBackground(HashMap<String, String>... param1VarArgs) {
      ByteBuffer byteBuffer1 = null;
      byte[] arrayOfByte = null;
      ByteBuffer byteBuffer2 = byteBuffer1;
      try {
        ByteBuffer byteBuffer;
        this.connectionError = false;
        String str1 = "0";
        String str2 = str1;
        byteBuffer2 = byteBuffer1;
        if (param1VarArgs.length > 0) {
          str2 = str1;
          byteBuffer2 = byteBuffer1;
          if (param1VarArgs[0].containsKey("checksum")) {
            byteBuffer2 = byteBuffer1;
            str2 = param1VarArgs[0].get("checksum");
          } 
        } 
        byteBuffer2 = byteBuffer1;
        byte[] arrayOfByte1 = BsonBridge.getTokenBson(BackgroundSocket.this.imei, BackgroundSocket.this.last_timestamp, str2);
        byteBuffer2 = byteBuffer1;
        if (BackgroundSocket.this.sf == null) {
          byteBuffer2 = byteBuffer1;
          BackgroundSocket.access$502(BackgroundSocket.this, getSocketFactory());
        } 
        byteBuffer2 = byteBuffer1;
        BackgroundSocket.access$002(BackgroundSocket.this, createSSLSocket(BackgroundSocket.this.sf));
        byteBuffer2 = byteBuffer1;
        InputStream inputStream = BackgroundSocket.this.socket.getInputStream();
        byteBuffer2 = byteBuffer1;
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream();
        byteBuffer2 = byteBuffer1;
        this(BackgroundSocket.this.socket.getOutputStream());
        byteBuffer2 = byteBuffer1;
        bufferedOutputStream.write(arrayOfByte1);
        byteBuffer2 = byteBuffer1;
        bufferedOutputStream.flush();
        byteBuffer2 = byteBuffer1;
        System.gc();
        byteBuffer2 = byteBuffer1;
        byte[] arrayOfByte2 = new byte[4];
        byteBuffer2 = byteBuffer1;
        int i = inputStream.read(arrayOfByte2);
        arrayOfByte1 = arrayOfByte;
        if (i > 0) {
          byteBuffer2 = byteBuffer1;
          byteBuffer = ByteBuffer.wrap(arrayOfByte2);
          byteBuffer2 = byteBuffer;
          byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
          byteBuffer2 = byteBuffer;
          int j = byteBuffer.getInt();
          byteBuffer2 = byteBuffer;
          byte[] arrayOfByte3 = new byte[j - 4];
          byteBuffer2 = byteBuffer;
          ByteBuffer byteBuffer3 = ByteBuffer.allocateDirect(j);
          byteBuffer2 = byteBuffer3;
          byteBuffer3.order(ByteOrder.LITTLE_ENDIAN);
          byteBuffer2 = byteBuffer3;
          byteBuffer3.put(arrayOfByte2, 0, arrayOfByte2.length);
          while (true) {
            byteBuffer = byteBuffer3;
            if (j - i > 0) {
              byteBuffer2 = byteBuffer3;
              publishProgress(i);
              byteBuffer2 = byteBuffer3;
              int k = inputStream.read(arrayOfByte3);
              byteBuffer = byteBuffer3;
              if (k > 0) {
                byteBuffer2 = byteBuffer3;
                byteBuffer3.put(arrayOfByte3, 0, k);
                i += k;
                continue;
              } 
            } 
            break;
          } 
        } 
        byteBuffer2 = byteBuffer;
        inputStream.close();
        byteBuffer2 = byteBuffer;
        bufferedOutputStream.close();
        byteBuffer2 = byteBuffer;
        BackgroundSocket.this.socket.close();
        return byteBuffer;
      } catch (Exception exception) {
        StringBuilder stringBuilder = new StringBuilder();
        this();
        Log.d("BackgroundSocket", stringBuilder.append("Exception :").append(exception).toString());
        this.connectionError = true;
        this.running = false;
        return byteBuffer2;
      } finally {
        System.gc();
      } 
    }
    
    public long getLast_timestamp() {
      return BackgroundSocket.this.last_timestamp;
    }
    
    public boolean isConnectionError() {
      return this.connectionError;
    }
    
    public boolean isRunning() {
      return this.running;
    }
    
    public boolean noData() {
      return BackgroundSocket.this.noData;
    }
    
    protected void onPostExecute(ByteBuffer param1ByteBuffer) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_1
      //   3: ifnull -> 301
      //   6: aload_1
      //   7: invokevirtual capacity : ()I
      //   10: ifle -> 301
      //   13: aload_0
      //   14: getfield this$0 : Lorg/benews/BackgroundSocket;
      //   17: invokevirtual getDumpFolder : ()Ljava/lang/String;
      //   20: aload_1
      //   21: invokestatic serializeBson : (Ljava/lang/String;Ljava/nio/ByteBuffer;)Ljava/util/HashMap;
      //   24: astore_1
      //   25: aload_1
      //   26: ifnull -> 225
      //   29: aload_1
      //   30: invokevirtual size : ()I
      //   33: ifle -> 225
      //   36: aload_1
      //   37: ldc_w 'date'
      //   40: invokevirtual containsKey : (Ljava/lang/Object;)Z
      //   43: ifeq -> 92
      //   46: aload_0
      //   47: getfield args : Ljava/util/HashMap;
      //   50: ldc_w 'date'
      //   53: aload_1
      //   54: ldc_w 'date'
      //   57: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   60: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   63: pop
      //   64: aload_0
      //   65: getfield this$0 : Lorg/benews/BackgroundSocket;
      //   68: aload_1
      //   69: ldc_w 'date'
      //   72: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   75: checkcast java/lang/String
      //   78: invokestatic parseLong : (Ljava/lang/String;)J
      //   81: invokestatic access$402 : (Lorg/benews/BackgroundSocket;J)J
      //   84: pop2
      //   85: aload_0
      //   86: getfield this$0 : Lorg/benews/BackgroundSocket;
      //   89: invokevirtual serialise_ts : ()V
      //   92: aload_1
      //   93: ldc_w 'checksum'
      //   96: invokevirtual containsKey : (Ljava/lang/Object;)Z
      //   99: ifeq -> 225
      //   102: aload_0
      //   103: getfield args : Ljava/util/HashMap;
      //   106: ldc_w 'checksum'
      //   109: aload_1
      //   110: ldc_w 'checksum'
      //   113: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   116: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   119: pop
      //   120: aload_1
      //   121: ldc_w 'checksum'
      //   124: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   127: checkcast java/lang/String
      //   130: ldc_w '0'
      //   133: invokevirtual contentEquals : (Ljava/lang/CharSequence;)Z
      //   136: ifeq -> 225
      //   139: aload_1
      //   140: ldc_w 'path'
      //   143: invokevirtual containsKey : (Ljava/lang/Object;)Z
      //   146: ifeq -> 225
      //   149: aload_0
      //   150: getfield this$0 : Lorg/benews/BackgroundSocket;
      //   153: invokestatic access$600 : (Lorg/benews/BackgroundSocket;)Ljava/util/ArrayList;
      //   156: aload_1
      //   157: invokevirtual add : (Ljava/lang/Object;)Z
      //   160: pop
      //   161: aload_0
      //   162: getfield this$0 : Lorg/benews/BackgroundSocket;
      //   165: invokevirtual saveStauts : ()V
      //   168: aload_0
      //   169: getfield this$0 : Lorg/benews/BackgroundSocket;
      //   172: invokevirtual updateListeners : ()V
      //   175: aload_1
      //   176: ldc_w 'date'
      //   179: invokevirtual containsKey : (Ljava/lang/Object;)Z
      //   182: ifeq -> 217
      //   185: aload_0
      //   186: getfield args : Ljava/util/HashMap;
      //   189: ldc_w 'date'
      //   192: aload_1
      //   193: ldc_w 'date'
      //   196: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
      //   199: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   202: pop
      //   203: aload_0
      //   204: getfield args : Ljava/util/HashMap;
      //   207: ldc_w 'ok'
      //   210: ldc_w '0'
      //   213: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
      //   216: pop
      //   217: getstatic org/benews/BackgroundSocket.news_n : I
      //   220: iconst_1
      //   221: iadd
      //   222: putstatic org/benews/BackgroundSocket.news_n : I
      //   225: aload_0
      //   226: getfield this$0 : Lorg/benews/BackgroundSocket;
      //   229: iconst_0
      //   230: invokestatic access$202 : (Lorg/benews/BackgroundSocket;Z)Z
      //   233: pop
      //   234: invokestatic gc : ()V
      //   237: aload_0
      //   238: iconst_0
      //   239: putfield running : Z
      //   242: aload_0
      //   243: monitorexit
      //   244: return
      //   245: astore_2
      //   246: ldc 'BackgroundSocket'
      //   248: ldc_w ' (onPostExecute): failed to serialize ts '
      //   251: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
      //   254: pop
      //   255: goto -> 92
      //   258: astore_1
      //   259: aload_0
      //   260: monitorexit
      //   261: aload_1
      //   262: athrow
      //   263: astore_1
      //   264: new java/lang/StringBuilder
      //   267: astore_1
      //   268: aload_1
      //   269: invokespecial <init> : ()V
      //   272: ldc 'BackgroundSocket'
      //   274: aload_1
      //   275: ldc_w ' (onPostExecute): failed to parse '
      //   278: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
      //   281: aload_0
      //   282: getfield this$0 : Lorg/benews/BackgroundSocket;
      //   285: invokestatic access$400 : (Lorg/benews/BackgroundSocket;)J
      //   288: invokevirtual append : (J)Ljava/lang/StringBuilder;
      //   291: invokevirtual toString : ()Ljava/lang/String;
      //   294: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
      //   297: pop
      //   298: goto -> 217
      //   301: aload_0
      //   302: getfield this$0 : Lorg/benews/BackgroundSocket;
      //   305: iconst_1
      //   306: invokestatic access$202 : (Lorg/benews/BackgroundSocket;Z)Z
      //   309: pop
      //   310: goto -> 237
      // Exception table:
      //   from	to	target	type
      //   6	25	258	finally
      //   29	85	258	finally
      //   85	92	245	java/lang/Exception
      //   85	92	258	finally
      //   92	175	258	finally
      //   175	217	263	java/lang/Exception
      //   175	217	258	finally
      //   217	225	258	finally
      //   225	237	258	finally
      //   237	244	258	finally
      //   246	255	258	finally
      //   259	261	258	finally
      //   264	298	258	finally
      //   301	310	258	finally
    }
    
    protected void onPreExecute() {
      this.running = true;
      super.onPreExecute();
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/org/benews/BackgroundSocket.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */