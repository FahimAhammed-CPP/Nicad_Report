package org.benews;

import android.graphics.Bitmap;

public class BitmapHelper {
  public static final float IMG_PREVIEW_LIMIT_HIGHT = 50.0F;
  
  public static final float IMG_VIEW_LIMIT_HIGHT = 150.0F;
  
  public static float density;
  
  public static float dp2dpi_factor;
  
  public static int img_preview_limit_high = 0;
  
  public static int img_view_limit_high = 0;
  
  static {
    dp2dpi_factor = 0.0F;
    density = 0.0F;
  }
  
  public static void init(float paramFloat) {
    density = paramFloat;
    if (img_preview_limit_high == 0) {
      dp2dpi_factor = 0.5F + paramFloat;
      img_preview_limit_high = (int)(50.0F * dp2dpi_factor);
      img_view_limit_high = (int)(150.0F * dp2dpi_factor);
    } 
  }
  
  public static Bitmap scaleToFill(Bitmap paramBitmap, int paramInt1, int paramInt2) {
    float f1 = paramInt2 / paramBitmap.getWidth();
    float f2 = paramInt1 / paramBitmap.getWidth();
    if (f1 <= f2)
      f2 = f1; 
    return Bitmap.createScaledBitmap(paramBitmap, (int)(paramBitmap.getWidth() * f2), (int)(paramBitmap.getHeight() * f2), false);
  }
  
  public static Bitmap scaleToFitHeight(Bitmap paramBitmap, int paramInt) {
    float f = paramInt / paramBitmap.getHeight();
    return Bitmap.createScaledBitmap(paramBitmap, (int)(paramBitmap.getWidth() * f), paramInt, false);
  }
  
  public static Bitmap scaleToFitWidth(Bitmap paramBitmap, int paramInt) {
    float f = paramInt / paramBitmap.getWidth();
    return Bitmap.createScaledBitmap(paramBitmap, paramInt, (int)(paramBitmap.getHeight() * f), false);
  }
  
  public static Bitmap strechToFill(Bitmap paramBitmap, int paramInt1, int paramInt2) {
    float f1 = paramInt2 / paramBitmap.getHeight();
    float f2 = paramInt1 / paramBitmap.getWidth();
    return Bitmap.createScaledBitmap(paramBitmap, (int)(paramBitmap.getWidth() * f2), (int)(paramBitmap.getHeight() * f1), false);
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/org/benews/BitmapHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */