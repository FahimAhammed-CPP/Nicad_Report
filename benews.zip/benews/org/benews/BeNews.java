package org.benews;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.util.HashMap;

public class BeNews extends FragmentActivity implements BeNewsFragList.OnFragmentInteractionListener, View.OnClickListener, BackgroundSocket.NewsUpdateListener {
  private static final String TAG = "BeNews";
  
  private static Context context;
  
  private static ProgressBar pb = null;
  
  ArrayAdapter<HashMap<String, String>> listAdapter;
  
  private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
      public void onReceive(Context param1Context, Intent param1Intent) {
        String str = param1Intent.getStringExtra("message");
        Log.d("receiver", "Got message: " + str);
        BeNews.this.finishOnStart();
      }
    };
  
  boolean toUpdate = false;
  
  public static Context getAppContext() {
    return context;
  }
  
  public void finishOnStart() {
    BackgroundSocket backgroundSocket = BackgroundSocket.self();
    BeNewsFragList beNewsFragList = new BeNewsFragList();
    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
    fragmentTransaction.replace(2131165249, beNewsFragList);
    fragmentTransaction.commit();
    this.listAdapter = new BeNewsArrayAdapter((Context)this, backgroundSocket.getList());
    beNewsFragList.setListAdapter((ListAdapter)this.listAdapter);
    ((Button)findViewById(2131165250)).setOnClickListener(this);
    pb = (ProgressBar)findViewById(2131165247);
    pb.setProgress(0);
    pb.setMax(100);
    backgroundSocket.setOnNewsUpdateListener(this);
    setToUpdate(true);
  }
  
  public boolean isToUpdate() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield toUpdate : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public void onBackPressed() {
    if (getSupportFragmentManager().findFragmentById(2131165252) != null) {
      getSupportFragmentManager().popBackStack("DETAILS", 1);
      return;
    } 
    super.onBackPressed();
  }
  
  public void onClick(View paramView) {
    Button button = (Button)paramView;
    final BackgroundSocket sucker = BackgroundSocket.self();
    button.setEnabled(false);
    backgroundSocket.setRun(false);
    (new Thread(new Runnable() {
          public void run() {
            int i = 0;
            BeNews.this.setProgressBar(0);
            while (sucker.isRunning()) {
              BackgroundSocket.Sleep(1);
              int j = i + 1;
              i = j;
              if (j <= 100) {
                BeNews.this.setProgressBar(j);
                i = j;
              } 
            } 
            sucker.reset_news();
          }
        })).start();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    if (this.listAdapter != null)
      this.listAdapter.notifyDataSetChanged(); 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903064);
    BitmapHelper.init((getResources().getDisplayMetrics()).density);
    context = getApplicationContext();
    Intent intent = new Intent(context, PullIntentService.class);
    context.startService(intent);
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131492864, paramMenu);
    return true;
  }
  
  public void onItemPress(int paramInt) {
    try {
      Object object = this.listAdapter.getItem(paramInt);
      String str = object.toString();
      StringBuilder stringBuilder = new StringBuilder();
      this();
      Toast.makeText((Context)this, stringBuilder.append("You selected: ").append(str).toString(), 0).show();
      if (BackgroundSocket.self() != null) {
        DetailFragView detailFragView = DetailFragView.newInstance((HashMap<String, String>)object);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(2131165249, detailFragView);
        fragmentTransaction.addToBackStack("DETAILS");
        fragmentTransaction.commit();
      } 
    } catch (Exception exception) {
      Log.d("BeNews", "Exception:" + exception);
    } 
  }
  
  public void onNewsUpdate() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_1
    //   4: invokevirtual setToUpdate : (Z)V
    //   7: aload_0
    //   8: ldc 2131165250
    //   10: invokevirtual findViewById : (I)Landroid/view/View;
    //   13: checkcast android/widget/Button
    //   16: astore_1
    //   17: new org/benews/BeNews$1
    //   20: astore_2
    //   21: aload_2
    //   22: aload_0
    //   23: aload_1
    //   24: invokespecial <init> : (Lorg/benews/BeNews;Landroid/widget/Button;)V
    //   27: aload_0
    //   28: aload_2
    //   29: invokevirtual runOnUiThread : (Ljava/lang/Runnable;)V
    //   32: aload_0
    //   33: monitorexit
    //   34: return
    //   35: astore_2
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_2
    //   39: athrow
    // Exception table:
    //   from	to	target	type
    //   2	32	35	finally
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem) {
    return (paramMenuItem.getItemId() == 2131165261) ? true : super.onOptionsItemSelected(paramMenuItem);
  }
  
  protected void onPause() {
    super.onPause();
    LocalBroadcastManager.getInstance((Context)this).unregisterReceiver(this.mMessageReceiver);
    super.onPause();
  }
  
  protected void onResume() {
    super.onResume();
    LocalBroadcastManager.getInstance((Context)this).registerReceiver(this.mMessageReceiver, new IntentFilter(new IntentFilter("upAndRunning")));
  }
  
  protected void onStart() {
    super.onStart();
    if (BackgroundSocket.self().isThreadStarted())
      finishOnStart(); 
  }
  
  protected void onStop() {
    super.onStop();
  }
  
  public void setProgressBar(int paramInt) {
    if (pb != null)
      pb.setProgress(paramInt); 
  }
  
  public void setToUpdate(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iload_1
    //   4: putfield toUpdate : Z
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_2
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_2
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/org/benews/BeNews.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */