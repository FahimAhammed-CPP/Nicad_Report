package org.benews;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

public class BeNewsArrayAdapter extends ArrayAdapter<HashMap<String, String>> {
  public static final String HASH_FIELD_CHECKSUM = "checksum";
  
  public static final String HASH_FIELD_CONTENT = "content";
  
  public static final String HASH_FIELD_DATE = "date";
  
  public static final String HASH_FIELD_HEADLINE = "headline";
  
  public static final String HASH_FIELD_PATH = "path";
  
  public static final String HASH_FIELD_TITLE = "title";
  
  public static final String HASH_FIELD_TYPE = "type";
  
  private static final int LEFT_ALIGNED_VIEW = 0;
  
  private static final int RIGHT_ALIGNED_VIEW = 1;
  
  public static final String TAG = "BeNewsArrayAdapter";
  
  public static final String TYPE_AUDIO_DIR = "audio";
  
  public static final String TYPE_HTML_DIR = "html";
  
  public static final String TYPE_IMG_DIR = "img";
  
  public static final String TYPE_TEXT_DIR = "text";
  
  public static final String TYPE_VIDEO_DIR = "video";
  
  public static final SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy hh:mm");
  
  private final Context context;
  
  private final ArrayList<HashMap<String, String>> list;
  
  public BeNewsArrayAdapter(Context paramContext, ArrayList<HashMap<String, String>> paramArrayList) {
    super(paramContext, 2130903069, paramArrayList);
    this.list = paramArrayList;
    this.context = paramContext;
  }
  
  private ViewHolderItem getCachedView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, int paramInt) {
    switch (paramInt) {
      default:
        return new ViewHolderItem(paramLayoutInflater.inflate(2130903069, paramViewGroup, false));
      case 0:
        break;
    } 
    return new ViewHolderItem(paramLayoutInflater.inflate(2130903068, paramViewGroup, false));
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    // Byte code:
    //   0: iload_1
    //   1: iconst_2
    //   2: irem
    //   3: ifne -> 285
    //   6: aload_0
    //   7: aload_0
    //   8: getfield context : Landroid/content/Context;
    //   11: ldc 'layout_inflater'
    //   13: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   16: checkcast android/view/LayoutInflater
    //   19: aload_3
    //   20: iconst_1
    //   21: invokespecial getCachedView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;I)Lorg/benews/BeNewsArrayAdapter$ViewHolderItem;
    //   24: astore_2
    //   25: aload_0
    //   26: getfield list : Ljava/util/ArrayList;
    //   29: ifnull -> 278
    //   32: aload_0
    //   33: getfield list : Ljava/util/ArrayList;
    //   36: iload_1
    //   37: invokevirtual get : (I)Ljava/lang/Object;
    //   40: checkcast java/util/HashMap
    //   43: astore #4
    //   45: aload #4
    //   47: ldc 'path'
    //   49: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   52: checkcast java/lang/String
    //   55: astore_3
    //   56: aload #4
    //   58: ldc 'type'
    //   60: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   63: checkcast java/lang/String
    //   66: astore #5
    //   68: aload_3
    //   69: ifnull -> 278
    //   72: aload #5
    //   74: ifnull -> 278
    //   77: aload #5
    //   79: ldc 'img'
    //   81: invokevirtual equals : (Ljava/lang/Object;)Z
    //   84: ifeq -> 171
    //   87: new java/io/File
    //   90: astore #5
    //   92: aload #5
    //   94: aload_3
    //   95: invokespecial <init> : (Ljava/lang/String;)V
    //   98: aload #5
    //   100: invokevirtual exists : ()Z
    //   103: ifeq -> 325
    //   106: aload #5
    //   108: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   111: invokestatic decodeFile : (Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   114: astore #5
    //   116: aload #5
    //   118: ifnull -> 171
    //   121: getstatic org/benews/BitmapHelper.img_preview_limit_high : I
    //   124: ifne -> 307
    //   127: bipush #100
    //   129: istore_1
    //   130: aload #5
    //   132: astore_3
    //   133: aload #5
    //   135: invokevirtual getHeight : ()I
    //   138: iload_1
    //   139: if_icmple -> 163
    //   142: getstatic org/benews/BitmapHelper.dp2dpi_factor : F
    //   145: fconst_0
    //   146: fcmpl
    //   147: ifne -> 314
    //   150: ldc 48.0
    //   152: fstore #6
    //   154: aload #5
    //   156: fload #6
    //   158: f2i
    //   159: invokestatic scaleToFitHeight : (Landroid/graphics/Bitmap;I)Landroid/graphics/Bitmap;
    //   162: astore_3
    //   163: aload_2
    //   164: getfield imageView : Landroid/widget/ImageView;
    //   167: aload_3
    //   168: invokevirtual setImageBitmap : (Landroid/graphics/Bitmap;)V
    //   171: aload #4
    //   173: ldc 'title'
    //   175: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   178: ifeq -> 198
    //   181: aload_2
    //   182: getfield title : Landroid/widget/TextView;
    //   185: aload #4
    //   187: ldc 'title'
    //   189: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   192: checkcast java/lang/CharSequence
    //   195: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   198: aload #4
    //   200: ldc 'headline'
    //   202: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   205: ifeq -> 225
    //   208: aload_2
    //   209: getfield secondLine : Landroid/widget/TextView;
    //   212: aload #4
    //   214: ldc 'headline'
    //   216: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   219: checkcast java/lang/CharSequence
    //   222: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   225: aload #4
    //   227: ldc 'date'
    //   229: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   232: ifeq -> 278
    //   235: new java/util/Date
    //   238: astore_3
    //   239: aload_3
    //   240: invokespecial <init> : ()V
    //   243: aload_3
    //   244: ldc2_w 1000
    //   247: aload #4
    //   249: ldc 'date'
    //   251: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   254: checkcast java/lang/String
    //   257: invokestatic parseLong : (Ljava/lang/String;)J
    //   260: lmul
    //   261: invokevirtual setTime : (J)V
    //   264: aload_2
    //   265: getfield date : Landroid/widget/TextView;
    //   268: getstatic org/benews/BeNewsArrayAdapter.dateFormatter : Ljava/text/SimpleDateFormat;
    //   271: aload_3
    //   272: invokevirtual format : (Ljava/util/Date;)Ljava/lang/String;
    //   275: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   278: aload_2
    //   279: getfield view : Landroid/view/View;
    //   282: astore_2
    //   283: aload_2
    //   284: areturn
    //   285: aload_0
    //   286: aload_0
    //   287: getfield context : Landroid/content/Context;
    //   290: ldc 'layout_inflater'
    //   292: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   295: checkcast android/view/LayoutInflater
    //   298: aload_3
    //   299: iconst_0
    //   300: invokespecial getCachedView : (Landroid/view/LayoutInflater;Landroid/view/ViewGroup;I)Lorg/benews/BeNewsArrayAdapter$ViewHolderItem;
    //   303: astore_2
    //   304: goto -> 25
    //   307: getstatic org/benews/BitmapHelper.img_preview_limit_high : I
    //   310: istore_1
    //   311: goto -> 130
    //   314: ldc 48.0
    //   316: getstatic org/benews/BitmapHelper.dp2dpi_factor : F
    //   319: fmul
    //   320: fstore #6
    //   322: goto -> 154
    //   325: aload_0
    //   326: getfield list : Ljava/util/ArrayList;
    //   329: aload #4
    //   331: invokevirtual contains : (Ljava/lang/Object;)Z
    //   334: ifeq -> 351
    //   337: aload_0
    //   338: getfield list : Ljava/util/ArrayList;
    //   341: aload #4
    //   343: invokevirtual remove : (Ljava/lang/Object;)Z
    //   346: pop
    //   347: aload_0
    //   348: invokevirtual notifyDataSetChanged : ()V
    //   351: aload_2
    //   352: getfield view : Landroid/view/View;
    //   355: astore_3
    //   356: aload_3
    //   357: astore_2
    //   358: goto -> 283
    //   361: astore_3
    //   362: aload_0
    //   363: getfield list : Ljava/util/ArrayList;
    //   366: aload #4
    //   368: invokevirtual contains : (Ljava/lang/Object;)Z
    //   371: ifeq -> 388
    //   374: aload_0
    //   375: getfield list : Ljava/util/ArrayList;
    //   378: aload #4
    //   380: invokevirtual remove : (Ljava/lang/Object;)Z
    //   383: pop
    //   384: aload_0
    //   385: invokevirtual notifyDataSetChanged : ()V
    //   388: ldc 'BeNewsArrayAdapter'
    //   390: new java/lang/StringBuilder
    //   393: dup
    //   394: invokespecial <init> : ()V
    //   397: ldc ' (getView):'
    //   399: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   402: aload_3
    //   403: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   406: invokevirtual toString : ()Ljava/lang/String;
    //   409: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   412: pop
    //   413: aload_2
    //   414: getfield view : Landroid/view/View;
    //   417: astore_2
    //   418: goto -> 283
    //   421: astore_3
    //   422: ldc 'BeNewsArrayAdapter'
    //   424: new java/lang/StringBuilder
    //   427: dup
    //   428: invokespecial <init> : ()V
    //   431: ldc 'Invalid date '
    //   433: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   436: aload #4
    //   438: ldc 'date'
    //   440: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   443: checkcast java/lang/String
    //   446: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   449: invokevirtual toString : ()Ljava/lang/String;
    //   452: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   455: pop
    //   456: aload_2
    //   457: getfield date : Landroid/widget/TextView;
    //   460: ldc '--/--/----'
    //   462: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   465: goto -> 278
    // Exception table:
    //   from	to	target	type
    //   87	116	361	java/lang/Exception
    //   121	127	361	java/lang/Exception
    //   133	150	361	java/lang/Exception
    //   154	163	361	java/lang/Exception
    //   163	171	361	java/lang/Exception
    //   235	278	421	java/lang/Exception
    //   307	311	361	java/lang/Exception
    //   314	322	361	java/lang/Exception
    //   325	351	361	java/lang/Exception
    //   351	356	361	java/lang/Exception
  }
  
  private class ViewHolderItem {
    TextView date;
    
    ImageView imageView;
    
    TextView secondLine;
    
    TextView title;
    
    View view;
    
    public ViewHolderItem(View param1View) {
      this.view = param1View;
      this.title = (TextView)this.view.findViewById(2131165227);
      this.secondLine = (TextView)this.view.findViewById(2131165260);
      this.imageView = (ImageView)this.view.findViewById(2131165226);
      this.date = (TextView)this.view.findViewById(2131165254);
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/org/benews/BeNewsArrayAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */