package org.benews;

import android.os.Bundle;
import android.support.annotation.Nullable;

public class DetailFragViewImage extends DetailFragView {
  private final String TAG = "DetailFragViewImage";
  
  public void onActivityCreated(@Nullable Bundle paramBundle) {
    // Byte code:
    //   0: ldc 200.0
    //   2: fstore_2
    //   3: aload_0
    //   4: aload_1
    //   5: invokespecial onActivityCreated : (Landroid/os/Bundle;)V
    //   8: aload_0
    //   9: getfield item_path : Ljava/lang/String;
    //   12: ifnull -> 281
    //   15: aload_0
    //   16: getfield item_type : Ljava/lang/String;
    //   19: ifnull -> 281
    //   22: aload_0
    //   23: getfield item_type : Ljava/lang/String;
    //   26: ldc 'img'
    //   28: invokevirtual equals : (Ljava/lang/Object;)Z
    //   31: ifeq -> 143
    //   34: new java/io/File
    //   37: dup
    //   38: aload_0
    //   39: getfield item_path : Ljava/lang/String;
    //   42: invokespecial <init> : (Ljava/lang/String;)V
    //   45: astore_1
    //   46: aload_1
    //   47: invokevirtual exists : ()Z
    //   50: ifeq -> 143
    //   53: aload_1
    //   54: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   57: invokestatic decodeFile : (Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   60: astore_3
    //   61: aload_3
    //   62: ifnull -> 143
    //   65: aload_0
    //   66: getfield media : Landroid/view/View;
    //   69: checkcast android/widget/ImageView
    //   72: astore #4
    //   74: getstatic org/benews/BitmapHelper.img_view_limit_high : I
    //   77: ifne -> 282
    //   80: ldc 600.0
    //   82: fstore #5
    //   84: getstatic org/benews/BitmapHelper.dp2dpi_factor : F
    //   87: fstore #6
    //   89: aload_3
    //   90: invokevirtual getHeight : ()I
    //   93: istore #7
    //   95: iload #7
    //   97: i2f
    //   98: fload #5
    //   100: fcmpl
    //   101: ifgt -> 118
    //   104: aload_3
    //   105: astore_1
    //   106: iload #7
    //   108: i2f
    //   109: ldc 60.0
    //   111: fload #6
    //   113: fmul
    //   114: fcmpg
    //   115: ifge -> 137
    //   118: getstatic org/benews/BitmapHelper.dp2dpi_factor : F
    //   121: fconst_0
    //   122: fcmpl
    //   123: ifne -> 291
    //   126: fload_2
    //   127: fstore #5
    //   129: aload_3
    //   130: fload #5
    //   132: f2i
    //   133: invokestatic scaleToFitHeight : (Landroid/graphics/Bitmap;I)Landroid/graphics/Bitmap;
    //   136: astore_1
    //   137: aload #4
    //   139: aload_1
    //   140: invokevirtual setImageBitmap : (Landroid/graphics/Bitmap;)V
    //   143: aload_0
    //   144: getfield item_title : Ljava/lang/String;
    //   147: ifnull -> 171
    //   150: aload_0
    //   151: getfield title : Landroid/view/View;
    //   154: ifnull -> 171
    //   157: aload_0
    //   158: getfield title : Landroid/view/View;
    //   161: checkcast android/widget/TextView
    //   164: aload_0
    //   165: getfield item_title : Ljava/lang/String;
    //   168: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   171: aload_0
    //   172: getfield item_headline : Ljava/lang/String;
    //   175: ifnull -> 199
    //   178: aload_0
    //   179: getfield headline : Landroid/view/View;
    //   182: ifnull -> 199
    //   185: aload_0
    //   186: getfield headline : Landroid/view/View;
    //   189: checkcast android/widget/TextView
    //   192: aload_0
    //   193: getfield item_headline : Ljava/lang/String;
    //   196: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   199: aload_0
    //   200: getfield item_content : Ljava/lang/String;
    //   203: ifnull -> 227
    //   206: aload_0
    //   207: getfield content : Landroid/view/View;
    //   210: ifnull -> 227
    //   213: aload_0
    //   214: getfield content : Landroid/view/View;
    //   217: checkcast android/widget/TextView
    //   220: aload_0
    //   221: getfield item_content : Ljava/lang/String;
    //   224: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   227: aload_0
    //   228: getfield item_date : Ljava/lang/String;
    //   231: ifnull -> 281
    //   234: aload_0
    //   235: getfield date : Landroid/view/View;
    //   238: ifnull -> 281
    //   241: new java/util/Date
    //   244: astore_1
    //   245: aload_1
    //   246: invokespecial <init> : ()V
    //   249: aload_1
    //   250: ldc2_w 1000
    //   253: aload_0
    //   254: getfield item_date : Ljava/lang/String;
    //   257: invokestatic parseLong : (Ljava/lang/String;)J
    //   260: lmul
    //   261: invokevirtual setTime : (J)V
    //   264: aload_0
    //   265: getfield date : Landroid/view/View;
    //   268: checkcast android/widget/TextView
    //   271: getstatic org/benews/BeNewsArrayAdapter.dateFormatter : Ljava/text/SimpleDateFormat;
    //   274: aload_1
    //   275: invokevirtual format : (Ljava/util/Date;)Ljava/lang/String;
    //   278: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   281: return
    //   282: getstatic org/benews/BitmapHelper.img_view_limit_high : I
    //   285: i2f
    //   286: fstore #5
    //   288: goto -> 84
    //   291: getstatic org/benews/BitmapHelper.dp2dpi_factor : F
    //   294: fstore #5
    //   296: ldc 200.0
    //   298: fload #5
    //   300: fmul
    //   301: fstore #5
    //   303: goto -> 129
    //   306: astore_1
    //   307: ldc 'DetailFragViewImage'
    //   309: new java/lang/StringBuilder
    //   312: dup
    //   313: invokespecial <init> : ()V
    //   316: ldc ' (onActivityCreated):'
    //   318: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   321: aload_1
    //   322: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   325: invokevirtual toString : ()Ljava/lang/String;
    //   328: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   331: pop
    //   332: goto -> 143
    //   335: astore_1
    //   336: ldc 'DetailFragViewImage'
    //   338: new java/lang/StringBuilder
    //   341: dup
    //   342: invokespecial <init> : ()V
    //   345: ldc 'Invalid date '
    //   347: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   350: aload_0
    //   351: getfield item_date : Ljava/lang/String;
    //   354: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   357: invokevirtual toString : ()Ljava/lang/String;
    //   360: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   363: pop
    //   364: aload_0
    //   365: getfield date : Landroid/view/View;
    //   368: checkcast android/widget/TextView
    //   371: ldc '--/--/----'
    //   373: invokevirtual setText : (Ljava/lang/CharSequence;)V
    //   376: goto -> 281
    // Exception table:
    //   from	to	target	type
    //   53	61	306	java/lang/Exception
    //   65	80	306	java/lang/Exception
    //   84	95	306	java/lang/Exception
    //   118	126	306	java/lang/Exception
    //   129	137	306	java/lang/Exception
    //   137	143	306	java/lang/Exception
    //   241	281	335	java/lang/Exception
    //   282	288	306	java/lang/Exception
    //   291	296	306	java/lang/Exception
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/org/benews/DetailFragViewImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */