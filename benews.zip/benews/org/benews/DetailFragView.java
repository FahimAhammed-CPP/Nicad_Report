package org.benews;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.HashMap;

public class DetailFragView extends Fragment {
  public static final String str_layout = "layoutId";
  
  protected View content;
  
  protected View date;
  
  protected View headline;
  
  protected String item_content;
  
  protected String item_date;
  
  protected String item_headline;
  
  protected String item_path;
  
  protected String item_title;
  
  protected String item_type;
  
  protected int layoutId = 0;
  
  protected View media;
  
  protected View title;
  
  protected View view = null;
  
  public static DetailFragView newInstance(HashMap<String, String> paramHashMap) {
    DetailFragView detailFragView;
    Bundle bundle = new Bundle();
    for (String str1 : paramHashMap.keySet())
      bundle.putCharArray(str1, ((String)paramHashMap.get(str1)).toCharArray()); 
    String str = paramHashMap.get("type");
    paramHashMap = null;
    if (str != null)
      if (str.equals("img")) {
        detailFragView = new DetailFragViewImage();
        bundle.putInt("layoutId", 2130903065);
      } else {
        detailFragView = new DetailFragView();
      }  
    if (detailFragView != null)
      detailFragView.setArguments(bundle); 
    return detailFragView;
  }
  
  public void onActivityCreated(@Nullable Bundle paramBundle) {
    super.onActivityCreated(paramBundle);
  }
  
  public void onAttach(Activity paramActivity) {
    super.onAttach(paramActivity);
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    onCreate(paramBundle);
    if (getArguments() != null) {
      if (getArguments().getCharArray("path") != null)
        this.item_path = String.valueOf(getArguments().getCharArray("path")); 
      if (getArguments().getCharArray("type") != null)
        this.item_type = String.valueOf(getArguments().getCharArray("type")); 
      if (getArguments().getCharArray("date") != null)
        this.item_date = String.valueOf(getArguments().getCharArray("date")); 
      if (getArguments().getCharArray("title") != null)
        this.item_title = String.valueOf(getArguments().getCharArray("title")); 
      if (getArguments().getCharArray("headline") != null)
        this.item_headline = String.valueOf(getArguments().getCharArray("headline")); 
      if (getArguments().getCharArray("content") != null)
        this.item_content = String.valueOf(getArguments().getCharArray("content")); 
      this.layoutId = getArguments().getInt("layoutId");
    } 
    this.view = paramLayoutInflater.inflate(this.layoutId, paramViewGroup, false);
    this.media = this.view.findViewById(2131165257);
    this.title = this.view.findViewById(2131165227);
    this.headline = this.view.findViewById(2131165255);
    this.content = this.view.findViewById(2131165259);
    this.date = this.view.findViewById(2131165254);
    return this.view;
  }
  
  public void onDetach() {
    super.onDetach();
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/org/benews/DetailFragView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */