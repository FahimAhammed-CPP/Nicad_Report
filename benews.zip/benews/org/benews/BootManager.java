package org.benews;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootManager extends BroadcastReceiver {
  public void onReceive(Context paramContext, Intent paramIntent) {
    paramContext.startService(new Intent(paramContext, PullIntentService.class));
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/org/benews/BootManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */