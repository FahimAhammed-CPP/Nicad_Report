package org.benews;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.TextView;

public class BeNewsFragList extends Fragment implements AdapterView.OnItemClickListener {
  private ListAdapter mAdapter;
  
  private AbsListView mListView;
  
  private OnFragmentInteractionListener mListener;
  
  public void onActivityCreated(@Nullable Bundle paramBundle) {
    super.onActivityCreated(paramBundle);
  }
  
  public void onAttach(Activity paramActivity) {
    super.onAttach(paramActivity);
    try {
      this.mListener = (OnFragmentInteractionListener)paramActivity;
      return;
    } catch (ClassCastException classCastException) {
      throw new ClassCastException(paramActivity.toString() + " must implement OnFragmentInteractionListener");
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle) {
    View view = paramLayoutInflater.inflate(2130903067, paramViewGroup, false);
    this.mListView = (AbsListView)view.findViewById(16908298);
    if (this.mAdapter != null && this.mListView.getAdapter() != this.mAdapter) {
      this.mListView.setAdapter((Adapter)this.mAdapter);
      this.mListView.setOnItemClickListener(this);
    } 
    return view;
  }
  
  public void onDetach() {
    super.onDetach();
    this.mListener = null;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    if (this.mListener != null)
      this.mListener.onItemPress(paramInt); 
  }
  
  public void setEmptyText(CharSequence paramCharSequence) {
    View view = this.mListView.getEmptyView();
    if (paramCharSequence instanceof TextView)
      ((TextView)view).setText(paramCharSequence); 
  }
  
  public void setListAdapter(ListAdapter paramListAdapter) {
    this.mAdapter = paramListAdapter;
    if (paramListAdapter != null && this.mListView != null) {
      this.mListView.setAdapter((Adapter)this.mAdapter);
      this.mListView.setOnItemClickListener(this);
    } 
  }
  
  public static interface OnFragmentInteractionListener {
    void onItemPress(int param1Int);
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/org/benews/BeNewsFragList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */