package org.benews;

import android.util.Log;
import java.nio.ByteBuffer;
import java.util.HashMap;

public class BsonBridge {
  public static final int BSON_TYPE_TEXT = 0;
  
  public static final String TAG = "BsonBridge";
  
  static {
    System.loadLibrary("bson");
  }
  
  public static native byte[] getToken(String paramString1, long paramLong, String paramString2);
  
  public static byte[] getTokenBson(String paramString1, long paramLong, String paramString2) {
    Log.d("BsonBridge", "getToken called\n");
    return getToken(paramString1, paramLong, paramString2);
  }
  
  public static native HashMap<String, String> serialize(String paramString, ByteBuffer paramByteBuffer);
  
  public static HashMap<String, String> serializeBson(String paramString, ByteBuffer paramByteBuffer) {
    Log.d("BsonBridge", "serialize called\n");
    return serialize(paramString, paramByteBuffer);
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/org/benews/BsonBridge.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */