package android.support.v4.text;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import java.util.Locale;

public class TextUtilsCompat {
  private static String ARAB_SCRIPT_SUBTAG;
  
  private static String HEBR_SCRIPT_SUBTAG;
  
  public static final Locale ROOT = new Locale("", "");
  
  static {
    ARAB_SCRIPT_SUBTAG = "Arab";
    HEBR_SCRIPT_SUBTAG = "Hebr";
  }
  
  private static int getLayoutDirectionFromFirstChar(Locale paramLocale) {
    boolean bool = false;
    switch (Character.getDirectionality(paramLocale.getDisplayName(paramLocale).charAt(0))) {
      default:
        return bool;
      case 1:
      case 2:
        break;
    } 
    bool = true;
  }
  
  public static int getLayoutDirectionFromLocale(@Nullable Locale paramLocale) {
    if (paramLocale != null && !paramLocale.equals(ROOT)) {
      String str = ICUCompat.getScript(ICUCompat.addLikelySubtags(paramLocale.toString()));
      if (str == null)
        return getLayoutDirectionFromFirstChar(paramLocale); 
      if (str.equalsIgnoreCase(ARAB_SCRIPT_SUBTAG) || str.equalsIgnoreCase(HEBR_SCRIPT_SUBTAG))
        return 1; 
    } 
    return 0;
  }
  
  @NonNull
  public static String htmlEncode(@NonNull String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    for (byte b = 0;; b++) {
      if (b < paramString.length()) {
        char c = paramString.charAt(b);
        switch (c) {
          default:
            stringBuilder.append(c);
            b++;
            continue;
          case '<':
            stringBuilder.append("&lt;");
            b++;
            continue;
          case '>':
            stringBuilder.append("&gt;");
            b++;
            continue;
          case '&':
            stringBuilder.append("&amp;");
            b++;
            continue;
          case '\'':
            stringBuilder.append("&#39;");
            b++;
            continue;
          case '"':
            break;
        } 
        stringBuilder.append("&quot;");
      } else {
        break;
      } 
    } 
    return stringBuilder.toString();
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v4/text/TextUtilsCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */