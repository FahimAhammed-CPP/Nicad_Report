package android.support.v4.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;
import java.lang.ref.WeakReference;

public class PagerTitleStrip extends ViewGroup implements ViewPager.Decor {
  private static final int[] ATTRS = new int[] { 16842804, 16842901, 16842904, 16842927 };
  
  private static final PagerTitleStripImpl IMPL;
  
  private static final float SIDE_ALPHA = 0.6F;
  
  private static final String TAG = "PagerTitleStrip";
  
  private static final int[] TEXT_ATTRS = new int[] { 16843660 };
  
  private static final int TEXT_SPACING = 16;
  
  TextView mCurrText;
  
  private int mGravity;
  
  private int mLastKnownCurrentPage = -1;
  
  private float mLastKnownPositionOffset = -1.0F;
  
  TextView mNextText;
  
  private int mNonPrimaryAlpha;
  
  private final PageListener mPageListener = new PageListener();
  
  ViewPager mPager;
  
  TextView mPrevText;
  
  private int mScaledTextSpacing;
  
  int mTextColor;
  
  private boolean mUpdatingPositions;
  
  private boolean mUpdatingText;
  
  private WeakReference<PagerAdapter> mWatchingAdapter;
  
  static {
    if (Build.VERSION.SDK_INT >= 14) {
      IMPL = new PagerTitleStripImplIcs();
      return;
    } 
    IMPL = new PagerTitleStripImplBase();
  }
  
  public PagerTitleStrip(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public PagerTitleStrip(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    TextView textView = new TextView(paramContext);
    this.mPrevText = textView;
    addView((View)textView);
    textView = new TextView(paramContext);
    this.mCurrText = textView;
    addView((View)textView);
    textView = new TextView(paramContext);
    this.mNextText = textView;
    addView((View)textView);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, ATTRS);
    int i = typedArray.getResourceId(0, 0);
    if (i != 0) {
      this.mPrevText.setTextAppearance(paramContext, i);
      this.mCurrText.setTextAppearance(paramContext, i);
      this.mNextText.setTextAppearance(paramContext, i);
    } 
    int j = typedArray.getDimensionPixelSize(1, 0);
    if (j != 0)
      setTextSize(0, j); 
    if (typedArray.hasValue(2)) {
      j = typedArray.getColor(2, 0);
      this.mPrevText.setTextColor(j);
      this.mCurrText.setTextColor(j);
      this.mNextText.setTextColor(j);
    } 
    this.mGravity = typedArray.getInteger(3, 80);
    typedArray.recycle();
    this.mTextColor = this.mCurrText.getTextColors().getDefaultColor();
    setNonPrimaryAlpha(0.6F);
    this.mPrevText.setEllipsize(TextUtils.TruncateAt.END);
    this.mCurrText.setEllipsize(TextUtils.TruncateAt.END);
    this.mNextText.setEllipsize(TextUtils.TruncateAt.END);
    boolean bool = false;
    if (i != 0) {
      typedArray = paramContext.obtainStyledAttributes(i, TEXT_ATTRS);
      bool = typedArray.getBoolean(0, false);
      typedArray.recycle();
    } 
    if (bool) {
      setSingleLineAllCaps(this.mPrevText);
      setSingleLineAllCaps(this.mCurrText);
      setSingleLineAllCaps(this.mNextText);
    } else {
      this.mPrevText.setSingleLine();
      this.mCurrText.setSingleLine();
      this.mNextText.setSingleLine();
    } 
    this.mScaledTextSpacing = (int)(16.0F * (paramContext.getResources().getDisplayMetrics()).density);
  }
  
  private static void setSingleLineAllCaps(TextView paramTextView) {
    IMPL.setSingleLineAllCaps(paramTextView);
  }
  
  int getMinHeight() {
    int i = 0;
    Drawable drawable = getBackground();
    if (drawable != null)
      i = drawable.getIntrinsicHeight(); 
    return i;
  }
  
  public int getTextSpacing() {
    return this.mScaledTextSpacing;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    ViewParent viewParent = getParent();
    if (!(viewParent instanceof ViewPager))
      throw new IllegalStateException("PagerTitleStrip must be a direct child of a ViewPager."); 
    ViewPager viewPager = (ViewPager)viewParent;
    PagerAdapter pagerAdapter = viewPager.getAdapter();
    viewPager.setInternalPageChangeListener(this.mPageListener);
    viewPager.setOnAdapterChangeListener(this.mPageListener);
    this.mPager = viewPager;
    if (this.mWatchingAdapter != null) {
      PagerAdapter pagerAdapter1 = this.mWatchingAdapter.get();
    } else {
      viewPager = null;
    } 
    updateAdapter((PagerAdapter)viewPager, pagerAdapter);
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    if (this.mPager != null) {
      updateAdapter(this.mPager.getAdapter(), (PagerAdapter)null);
      this.mPager.setInternalPageChangeListener(null);
      this.mPager.setOnAdapterChangeListener(null);
      this.mPager = null;
    } 
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    float f = 0.0F;
    if (this.mPager != null) {
      if (this.mLastKnownPositionOffset >= 0.0F)
        f = this.mLastKnownPositionOffset; 
      updateTextPositions(this.mLastKnownCurrentPage, f, true);
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (i != 1073741824)
      throw new IllegalStateException("Must measure with an exact width"); 
    int k = getMinHeight();
    int m = getPaddingTop() + getPaddingBottom();
    int n = View.MeasureSpec.makeMeasureSpec((int)(paramInt1 * 0.8F), -2147483648);
    i = View.MeasureSpec.makeMeasureSpec(paramInt2 - m, -2147483648);
    this.mPrevText.measure(n, i);
    this.mCurrText.measure(n, i);
    this.mNextText.measure(n, i);
    if (j == 1073741824) {
      setMeasuredDimension(paramInt1, paramInt2);
      return;
    } 
    setMeasuredDimension(paramInt1, Math.max(k, this.mCurrText.getMeasuredHeight() + m));
  }
  
  public void requestLayout() {
    if (!this.mUpdatingText)
      super.requestLayout(); 
  }
  
  public void setGravity(int paramInt) {
    this.mGravity = paramInt;
    requestLayout();
  }
  
  public void setNonPrimaryAlpha(float paramFloat) {
    this.mNonPrimaryAlpha = (int)(255.0F * paramFloat) & 0xFF;
    int i = this.mNonPrimaryAlpha << 24 | this.mTextColor & 0xFFFFFF;
    this.mPrevText.setTextColor(i);
    this.mNextText.setTextColor(i);
  }
  
  public void setTextColor(int paramInt) {
    this.mTextColor = paramInt;
    this.mCurrText.setTextColor(paramInt);
    paramInt = this.mNonPrimaryAlpha << 24 | this.mTextColor & 0xFFFFFF;
    this.mPrevText.setTextColor(paramInt);
    this.mNextText.setTextColor(paramInt);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    this.mPrevText.setTextSize(paramInt, paramFloat);
    this.mCurrText.setTextSize(paramInt, paramFloat);
    this.mNextText.setTextSize(paramInt, paramFloat);
  }
  
  public void setTextSpacing(int paramInt) {
    this.mScaledTextSpacing = paramInt;
    requestLayout();
  }
  
  void updateAdapter(PagerAdapter paramPagerAdapter1, PagerAdapter paramPagerAdapter2) {
    if (paramPagerAdapter1 != null) {
      paramPagerAdapter1.unregisterDataSetObserver(this.mPageListener);
      this.mWatchingAdapter = null;
    } 
    if (paramPagerAdapter2 != null) {
      paramPagerAdapter2.registerDataSetObserver(this.mPageListener);
      this.mWatchingAdapter = new WeakReference<PagerAdapter>(paramPagerAdapter2);
    } 
    if (this.mPager != null) {
      this.mLastKnownCurrentPage = -1;
      this.mLastKnownPositionOffset = -1.0F;
      updateText(this.mPager.getCurrentItem(), paramPagerAdapter2);
      requestLayout();
    } 
  }
  
  void updateText(int paramInt, PagerAdapter paramPagerAdapter) {
    CharSequence charSequence2;
    if (paramPagerAdapter != null) {
      i = paramPagerAdapter.getCount();
    } else {
      i = 0;
    } 
    this.mUpdatingText = true;
    CharSequence charSequence1 = null;
    CharSequence charSequence3 = charSequence1;
    if (paramInt >= 1) {
      charSequence3 = charSequence1;
      if (paramPagerAdapter != null)
        charSequence3 = paramPagerAdapter.getPageTitle(paramInt - 1); 
    } 
    this.mPrevText.setText(charSequence3);
    TextView textView1 = this.mCurrText;
    if (paramPagerAdapter != null && paramInt < i) {
      charSequence3 = paramPagerAdapter.getPageTitle(paramInt);
    } else {
      charSequence3 = null;
    } 
    textView1.setText(charSequence3);
    textView1 = null;
    TextView textView2 = textView1;
    if (paramInt + 1 < i) {
      textView2 = textView1;
      if (paramPagerAdapter != null)
        charSequence2 = paramPagerAdapter.getPageTitle(paramInt + 1); 
    } 
    this.mNextText.setText(charSequence2);
    int j = getWidth();
    int k = getPaddingLeft();
    int m = getPaddingRight();
    int n = getHeight();
    int i = getPaddingTop();
    int i1 = getPaddingBottom();
    m = View.MeasureSpec.makeMeasureSpec((int)((j - k - m) * 0.8F), -2147483648);
    i = View.MeasureSpec.makeMeasureSpec(n - i - i1, -2147483648);
    this.mPrevText.measure(m, i);
    this.mCurrText.measure(m, i);
    this.mNextText.measure(m, i);
    this.mLastKnownCurrentPage = paramInt;
    if (!this.mUpdatingPositions)
      updateTextPositions(paramInt, this.mLastKnownPositionOffset, false); 
    this.mUpdatingText = false;
  }
  
  void updateTextPositions(int paramInt, float paramFloat, boolean paramBoolean) {
    if (paramInt != this.mLastKnownCurrentPage) {
      updateText(paramInt, this.mPager.getAdapter());
    } else if (!paramBoolean && paramFloat == this.mLastKnownPositionOffset) {
      return;
    } 
    this.mUpdatingPositions = true;
    int i = this.mPrevText.getMeasuredWidth();
    int j = this.mCurrText.getMeasuredWidth();
    int k = this.mNextText.getMeasuredWidth();
    int m = j / 2;
    int n = getWidth();
    int i1 = getHeight();
    int i2 = getPaddingLeft();
    int i3 = getPaddingRight();
    paramInt = getPaddingTop();
    int i4 = getPaddingBottom();
    int i5 = i3 + m;
    float f1 = paramFloat + 0.5F;
    float f2 = f1;
    if (f1 > 1.0F)
      f2 = f1 - 1.0F; 
    m = n - i5 - (int)((n - i2 + m - i5) * f2) - j / 2;
    i5 = m + j;
    int i6 = this.mPrevText.getBaseline();
    j = this.mCurrText.getBaseline();
    int i7 = this.mNextText.getBaseline();
    int i8 = Math.max(Math.max(i6, j), i7);
    i6 = i8 - i6;
    j = i8 - j;
    i8 -= i7;
    int i9 = this.mPrevText.getMeasuredHeight();
    int i10 = this.mCurrText.getMeasuredHeight();
    i7 = this.mNextText.getMeasuredHeight();
    i7 = Math.max(Math.max(i6 + i9, j + i10), i8 + i7);
    switch (this.mGravity & 0x70) {
      default:
        i4 = paramInt + i6;
        j = paramInt + j;
        paramInt += i8;
        this.mCurrText.layout(m, j, i5, this.mCurrText.getMeasuredHeight() + j);
        j = Math.min(i2, m - this.mScaledTextSpacing - i);
        this.mPrevText.layout(j, i4, j + i, this.mPrevText.getMeasuredHeight() + i4);
        j = Math.max(n - i3 - k, this.mScaledTextSpacing + i5);
        this.mNextText.layout(j, paramInt, j + k, this.mNextText.getMeasuredHeight() + paramInt);
        this.mLastKnownPositionOffset = paramFloat;
        this.mUpdatingPositions = false;
        return;
      case 16:
        paramInt = (i1 - paramInt - i4 - i7) / 2;
        i4 = paramInt + i6;
        j = paramInt + j;
        paramInt += i8;
        this.mCurrText.layout(m, j, i5, this.mCurrText.getMeasuredHeight() + j);
        j = Math.min(i2, m - this.mScaledTextSpacing - i);
        this.mPrevText.layout(j, i4, j + i, this.mPrevText.getMeasuredHeight() + i4);
        j = Math.max(n - i3 - k, this.mScaledTextSpacing + i5);
        this.mNextText.layout(j, paramInt, j + k, this.mNextText.getMeasuredHeight() + paramInt);
        this.mLastKnownPositionOffset = paramFloat;
        this.mUpdatingPositions = false;
        return;
      case 80:
        break;
    } 
    paramInt = i1 - i4 - i7;
    i4 = paramInt + i6;
    j = paramInt + j;
    paramInt += i8;
    this.mCurrText.layout(m, j, i5, this.mCurrText.getMeasuredHeight() + j);
    j = Math.min(i2, m - this.mScaledTextSpacing - i);
    this.mPrevText.layout(j, i4, j + i, this.mPrevText.getMeasuredHeight() + i4);
    j = Math.max(n - i3 - k, this.mScaledTextSpacing + i5);
    this.mNextText.layout(j, paramInt, j + k, this.mNextText.getMeasuredHeight() + paramInt);
    this.mLastKnownPositionOffset = paramFloat;
    this.mUpdatingPositions = false;
  }
  
  private class PageListener extends DataSetObserver implements ViewPager.OnPageChangeListener, ViewPager.OnAdapterChangeListener {
    private int mScrollState;
    
    private PageListener() {}
    
    public void onAdapterChanged(PagerAdapter param1PagerAdapter1, PagerAdapter param1PagerAdapter2) {
      PagerTitleStrip.this.updateAdapter(param1PagerAdapter1, param1PagerAdapter2);
    }
    
    public void onChanged() {
      float f = 0.0F;
      PagerTitleStrip.this.updateText(PagerTitleStrip.this.mPager.getCurrentItem(), PagerTitleStrip.this.mPager.getAdapter());
      if (PagerTitleStrip.this.mLastKnownPositionOffset >= 0.0F)
        f = PagerTitleStrip.this.mLastKnownPositionOffset; 
      PagerTitleStrip.this.updateTextPositions(PagerTitleStrip.this.mPager.getCurrentItem(), f, true);
    }
    
    public void onPageScrollStateChanged(int param1Int) {
      this.mScrollState = param1Int;
    }
    
    public void onPageScrolled(int param1Int1, float param1Float, int param1Int2) {
      param1Int2 = param1Int1;
      if (param1Float > 0.5F)
        param1Int2 = param1Int1 + 1; 
      PagerTitleStrip.this.updateTextPositions(param1Int2, param1Float, false);
    }
    
    public void onPageSelected(int param1Int) {
      float f = 0.0F;
      if (this.mScrollState == 0) {
        PagerTitleStrip.this.updateText(PagerTitleStrip.this.mPager.getCurrentItem(), PagerTitleStrip.this.mPager.getAdapter());
        if (PagerTitleStrip.this.mLastKnownPositionOffset >= 0.0F)
          f = PagerTitleStrip.this.mLastKnownPositionOffset; 
        PagerTitleStrip.this.updateTextPositions(PagerTitleStrip.this.mPager.getCurrentItem(), f, true);
      } 
    }
  }
  
  static interface PagerTitleStripImpl {
    void setSingleLineAllCaps(TextView param1TextView);
  }
  
  static class PagerTitleStripImplBase implements PagerTitleStripImpl {
    public void setSingleLineAllCaps(TextView param1TextView) {
      param1TextView.setSingleLine();
    }
  }
  
  static class PagerTitleStripImplIcs implements PagerTitleStripImpl {
    public void setSingleLineAllCaps(TextView param1TextView) {
      PagerTitleStripIcs.setSingleLineAllCaps(param1TextView);
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v4/view/PagerTitleStrip.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */