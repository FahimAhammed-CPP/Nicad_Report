package android.support.v4.view.accessibility;

import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AccessibilityNodeInfoCompat {
  public static final int ACTION_ACCESSIBILITY_FOCUS = 64;
  
  public static final String ACTION_ARGUMENT_EXTEND_SELECTION_BOOLEAN = "ACTION_ARGUMENT_EXTEND_SELECTION_BOOLEAN";
  
  public static final String ACTION_ARGUMENT_HTML_ELEMENT_STRING = "ACTION_ARGUMENT_HTML_ELEMENT_STRING";
  
  public static final String ACTION_ARGUMENT_MOVEMENT_GRANULARITY_INT = "ACTION_ARGUMENT_MOVEMENT_GRANULARITY_INT";
  
  public static final String ACTION_ARGUMENT_SELECTION_END_INT = "ACTION_ARGUMENT_SELECTION_END_INT";
  
  public static final String ACTION_ARGUMENT_SELECTION_START_INT = "ACTION_ARGUMENT_SELECTION_START_INT";
  
  public static final int ACTION_CLEAR_ACCESSIBILITY_FOCUS = 128;
  
  public static final int ACTION_CLEAR_FOCUS = 2;
  
  public static final int ACTION_CLEAR_SELECTION = 8;
  
  public static final int ACTION_CLICK = 16;
  
  public static final int ACTION_COPY = 16384;
  
  public static final int ACTION_CUT = 65536;
  
  public static final int ACTION_FOCUS = 1;
  
  public static final int ACTION_LONG_CLICK = 32;
  
  public static final int ACTION_NEXT_AT_MOVEMENT_GRANULARITY = 256;
  
  public static final int ACTION_NEXT_HTML_ELEMENT = 1024;
  
  public static final int ACTION_PASTE = 32768;
  
  public static final int ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY = 512;
  
  public static final int ACTION_PREVIOUS_HTML_ELEMENT = 2048;
  
  public static final int ACTION_SCROLL_BACKWARD = 8192;
  
  public static final int ACTION_SCROLL_FORWARD = 4096;
  
  public static final int ACTION_SELECT = 4;
  
  public static final int ACTION_SET_SELECTION = 131072;
  
  public static final int FOCUS_ACCESSIBILITY = 2;
  
  public static final int FOCUS_INPUT = 1;
  
  private static final AccessibilityNodeInfoImpl IMPL = new AccessibilityNodeInfoStubImpl();
  
  public static final int MOVEMENT_GRANULARITY_CHARACTER = 1;
  
  public static final int MOVEMENT_GRANULARITY_LINE = 4;
  
  public static final int MOVEMENT_GRANULARITY_PAGE = 16;
  
  public static final int MOVEMENT_GRANULARITY_PARAGRAPH = 8;
  
  public static final int MOVEMENT_GRANULARITY_WORD = 2;
  
  private final Object mInfo;
  
  public AccessibilityNodeInfoCompat(Object paramObject) {
    this.mInfo = paramObject;
  }
  
  private static String getActionSymbolicName(int paramInt) {
    switch (paramInt) {
      default:
        return "ACTION_UNKNOWN";
      case 1:
        return "ACTION_FOCUS";
      case 2:
        return "ACTION_CLEAR_FOCUS";
      case 4:
        return "ACTION_SELECT";
      case 8:
        return "ACTION_CLEAR_SELECTION";
      case 16:
        return "ACTION_CLICK";
      case 32:
        return "ACTION_LONG_CLICK";
      case 64:
        return "ACTION_ACCESSIBILITY_FOCUS";
      case 128:
        return "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
      case 256:
        return "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
      case 512:
        return "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
      case 1024:
        return "ACTION_NEXT_HTML_ELEMENT";
      case 2048:
        return "ACTION_PREVIOUS_HTML_ELEMENT";
      case 4096:
        return "ACTION_SCROLL_FORWARD";
      case 8192:
        return "ACTION_SCROLL_BACKWARD";
      case 65536:
        return "ACTION_CUT";
      case 16384:
        return "ACTION_COPY";
      case 32768:
        return "ACTION_PASTE";
      case 131072:
        break;
    } 
    return "ACTION_SET_SELECTION";
  }
  
  public static AccessibilityNodeInfoCompat obtain() {
    return wrapNonNullInstance(IMPL.obtain());
  }
  
  public static AccessibilityNodeInfoCompat obtain(AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat) {
    return wrapNonNullInstance(IMPL.obtain(paramAccessibilityNodeInfoCompat.mInfo));
  }
  
  public static AccessibilityNodeInfoCompat obtain(View paramView) {
    return wrapNonNullInstance(IMPL.obtain(paramView));
  }
  
  public static AccessibilityNodeInfoCompat obtain(View paramView, int paramInt) {
    return wrapNonNullInstance(IMPL.obtain(paramView, paramInt));
  }
  
  static AccessibilityNodeInfoCompat wrapNonNullInstance(Object paramObject) {
    return (paramObject != null) ? new AccessibilityNodeInfoCompat(paramObject) : null;
  }
  
  public void addAction(int paramInt) {
    IMPL.addAction(this.mInfo, paramInt);
  }
  
  public void addChild(View paramView) {
    IMPL.addChild(this.mInfo, paramView);
  }
  
  public void addChild(View paramView, int paramInt) {
    IMPL.addChild(this.mInfo, paramView, paramInt);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this != paramObject) {
      if (paramObject == null)
        return false; 
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      if (this.mInfo == null) {
        if (((AccessibilityNodeInfoCompat)paramObject).mInfo != null)
          bool = false; 
        return bool;
      } 
      if (!this.mInfo.equals(((AccessibilityNodeInfoCompat)paramObject).mInfo))
        bool = false; 
    } 
    return bool;
  }
  
  public List<AccessibilityNodeInfoCompat> findAccessibilityNodeInfosByText(String paramString) {
    ArrayList<AccessibilityNodeInfoCompat> arrayList = new ArrayList();
    List<Object> list = IMPL.findAccessibilityNodeInfosByText(this.mInfo, paramString);
    int i = list.size();
    for (byte b = 0; b < i; b++)
      arrayList.add(new AccessibilityNodeInfoCompat(list.get(b))); 
    return arrayList;
  }
  
  public AccessibilityNodeInfoCompat findFocus(int paramInt) {
    return wrapNonNullInstance(IMPL.findFocus(this.mInfo, paramInt));
  }
  
  public AccessibilityNodeInfoCompat focusSearch(int paramInt) {
    return wrapNonNullInstance(IMPL.focusSearch(this.mInfo, paramInt));
  }
  
  public int getActions() {
    return IMPL.getActions(this.mInfo);
  }
  
  public void getBoundsInParent(Rect paramRect) {
    IMPL.getBoundsInParent(this.mInfo, paramRect);
  }
  
  public void getBoundsInScreen(Rect paramRect) {
    IMPL.getBoundsInScreen(this.mInfo, paramRect);
  }
  
  public AccessibilityNodeInfoCompat getChild(int paramInt) {
    return wrapNonNullInstance(IMPL.getChild(this.mInfo, paramInt));
  }
  
  public int getChildCount() {
    return IMPL.getChildCount(this.mInfo);
  }
  
  public CharSequence getClassName() {
    return IMPL.getClassName(this.mInfo);
  }
  
  public CharSequence getContentDescription() {
    return IMPL.getContentDescription(this.mInfo);
  }
  
  public Object getInfo() {
    return this.mInfo;
  }
  
  public int getLiveRegion() {
    return IMPL.getLiveRegion(this.mInfo);
  }
  
  public int getMovementGranularities() {
    return IMPL.getMovementGranularities(this.mInfo);
  }
  
  public CharSequence getPackageName() {
    return IMPL.getPackageName(this.mInfo);
  }
  
  public AccessibilityNodeInfoCompat getParent() {
    return wrapNonNullInstance(IMPL.getParent(this.mInfo));
  }
  
  public CharSequence getText() {
    return IMPL.getText(this.mInfo);
  }
  
  public String getViewIdResourceName() {
    return IMPL.getViewIdResourceName(this.mInfo);
  }
  
  public int getWindowId() {
    return IMPL.getWindowId(this.mInfo);
  }
  
  public int hashCode() {
    return (this.mInfo == null) ? 0 : this.mInfo.hashCode();
  }
  
  public boolean isAccessibilityFocused() {
    return IMPL.isAccessibilityFocused(this.mInfo);
  }
  
  public boolean isCheckable() {
    return IMPL.isCheckable(this.mInfo);
  }
  
  public boolean isChecked() {
    return IMPL.isChecked(this.mInfo);
  }
  
  public boolean isClickable() {
    return IMPL.isClickable(this.mInfo);
  }
  
  public boolean isEnabled() {
    return IMPL.isEnabled(this.mInfo);
  }
  
  public boolean isFocusable() {
    return IMPL.isFocusable(this.mInfo);
  }
  
  public boolean isFocused() {
    return IMPL.isFocused(this.mInfo);
  }
  
  public boolean isLongClickable() {
    return IMPL.isLongClickable(this.mInfo);
  }
  
  public boolean isPassword() {
    return IMPL.isPassword(this.mInfo);
  }
  
  public boolean isScrollable() {
    return IMPL.isScrollable(this.mInfo);
  }
  
  public boolean isSelected() {
    return IMPL.isSelected(this.mInfo);
  }
  
  public boolean isVisibleToUser() {
    return IMPL.isVisibleToUser(this.mInfo);
  }
  
  public boolean performAction(int paramInt) {
    return IMPL.performAction(this.mInfo, paramInt);
  }
  
  public boolean performAction(int paramInt, Bundle paramBundle) {
    return IMPL.performAction(this.mInfo, paramInt, paramBundle);
  }
  
  public void recycle() {
    IMPL.recycle(this.mInfo);
  }
  
  public void setAccessibilityFocused(boolean paramBoolean) {
    IMPL.setAccessibilityFocused(this.mInfo, paramBoolean);
  }
  
  public void setBoundsInParent(Rect paramRect) {
    IMPL.setBoundsInParent(this.mInfo, paramRect);
  }
  
  public void setBoundsInScreen(Rect paramRect) {
    IMPL.setBoundsInScreen(this.mInfo, paramRect);
  }
  
  public void setCheckable(boolean paramBoolean) {
    IMPL.setCheckable(this.mInfo, paramBoolean);
  }
  
  public void setChecked(boolean paramBoolean) {
    IMPL.setChecked(this.mInfo, paramBoolean);
  }
  
  public void setClassName(CharSequence paramCharSequence) {
    IMPL.setClassName(this.mInfo, paramCharSequence);
  }
  
  public void setClickable(boolean paramBoolean) {
    IMPL.setClickable(this.mInfo, paramBoolean);
  }
  
  public void setContentDescription(CharSequence paramCharSequence) {
    IMPL.setContentDescription(this.mInfo, paramCharSequence);
  }
  
  public void setEnabled(boolean paramBoolean) {
    IMPL.setEnabled(this.mInfo, paramBoolean);
  }
  
  public void setFocusable(boolean paramBoolean) {
    IMPL.setFocusable(this.mInfo, paramBoolean);
  }
  
  public void setFocused(boolean paramBoolean) {
    IMPL.setFocused(this.mInfo, paramBoolean);
  }
  
  public void setLiveRegion(int paramInt) {
    IMPL.setLiveRegion(this.mInfo, paramInt);
  }
  
  public void setLongClickable(boolean paramBoolean) {
    IMPL.setLongClickable(this.mInfo, paramBoolean);
  }
  
  public void setMovementGranularities(int paramInt) {
    IMPL.setMovementGranularities(this.mInfo, paramInt);
  }
  
  public void setPackageName(CharSequence paramCharSequence) {
    IMPL.setPackageName(this.mInfo, paramCharSequence);
  }
  
  public void setParent(View paramView) {
    IMPL.setParent(this.mInfo, paramView);
  }
  
  public void setParent(View paramView, int paramInt) {
    IMPL.setParent(this.mInfo, paramView, paramInt);
  }
  
  public void setPassword(boolean paramBoolean) {
    IMPL.setPassword(this.mInfo, paramBoolean);
  }
  
  public void setScrollable(boolean paramBoolean) {
    IMPL.setScrollable(this.mInfo, paramBoolean);
  }
  
  public void setSelected(boolean paramBoolean) {
    IMPL.setSelected(this.mInfo, paramBoolean);
  }
  
  public void setSource(View paramView) {
    IMPL.setSource(this.mInfo, paramView);
  }
  
  public void setSource(View paramView, int paramInt) {
    IMPL.setSource(this.mInfo, paramView, paramInt);
  }
  
  public void setText(CharSequence paramCharSequence) {
    IMPL.setText(this.mInfo, paramCharSequence);
  }
  
  public void setViewIdResourceName(String paramString) {
    IMPL.setViewIdResourceName(this.mInfo, paramString);
  }
  
  public void setVisibleToUser(boolean paramBoolean) {
    IMPL.setVisibleToUser(this.mInfo, paramBoolean);
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.toString());
    Rect rect = new Rect();
    getBoundsInParent(rect);
    stringBuilder.append("; boundsInParent: " + rect);
    getBoundsInScreen(rect);
    stringBuilder.append("; boundsInScreen: " + rect);
    stringBuilder.append("; packageName: ").append(getPackageName());
    stringBuilder.append("; className: ").append(getClassName());
    stringBuilder.append("; text: ").append(getText());
    stringBuilder.append("; contentDescription: ").append(getContentDescription());
    stringBuilder.append("; viewId: ").append(getViewIdResourceName());
    stringBuilder.append("; checkable: ").append(isCheckable());
    stringBuilder.append("; checked: ").append(isChecked());
    stringBuilder.append("; focusable: ").append(isFocusable());
    stringBuilder.append("; focused: ").append(isFocused());
    stringBuilder.append("; selected: ").append(isSelected());
    stringBuilder.append("; clickable: ").append(isClickable());
    stringBuilder.append("; longClickable: ").append(isLongClickable());
    stringBuilder.append("; enabled: ").append(isEnabled());
    stringBuilder.append("; password: ").append(isPassword());
    stringBuilder.append("; scrollable: " + isScrollable());
    stringBuilder.append("; [");
    int i = getActions();
    while (i != 0) {
      int j = 1 << Integer.numberOfTrailingZeros(i);
      int k = i & (j ^ 0xFFFFFFFF);
      stringBuilder.append(getActionSymbolicName(j));
      i = k;
      if (k != 0) {
        stringBuilder.append(", ");
        i = k;
      } 
    } 
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 19) {
      IMPL = new AccessibilityNodeInfoKitKatImpl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 18) {
      IMPL = new AccessibilityNodeInfoJellybeanMr2Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16) {
      IMPL = new AccessibilityNodeInfoJellybeanImpl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 14) {
      IMPL = new AccessibilityNodeInfoIcsImpl();
      return;
    } 
  }
  
  static class AccessibilityNodeInfoIcsImpl extends AccessibilityNodeInfoStubImpl {
    public void addAction(Object param1Object, int param1Int) {
      AccessibilityNodeInfoCompatIcs.addAction(param1Object, param1Int);
    }
    
    public void addChild(Object param1Object, View param1View) {
      AccessibilityNodeInfoCompatIcs.addChild(param1Object, param1View);
    }
    
    public List<Object> findAccessibilityNodeInfosByText(Object param1Object, String param1String) {
      return AccessibilityNodeInfoCompatIcs.findAccessibilityNodeInfosByText(param1Object, param1String);
    }
    
    public int getActions(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.getActions(param1Object);
    }
    
    public void getBoundsInParent(Object param1Object, Rect param1Rect) {
      AccessibilityNodeInfoCompatIcs.getBoundsInParent(param1Object, param1Rect);
    }
    
    public void getBoundsInScreen(Object param1Object, Rect param1Rect) {
      AccessibilityNodeInfoCompatIcs.getBoundsInScreen(param1Object, param1Rect);
    }
    
    public Object getChild(Object param1Object, int param1Int) {
      return AccessibilityNodeInfoCompatIcs.getChild(param1Object, param1Int);
    }
    
    public int getChildCount(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.getChildCount(param1Object);
    }
    
    public CharSequence getClassName(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.getClassName(param1Object);
    }
    
    public CharSequence getContentDescription(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.getContentDescription(param1Object);
    }
    
    public CharSequence getPackageName(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.getPackageName(param1Object);
    }
    
    public Object getParent(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.getParent(param1Object);
    }
    
    public CharSequence getText(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.getText(param1Object);
    }
    
    public int getWindowId(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.getWindowId(param1Object);
    }
    
    public boolean isCheckable(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.isCheckable(param1Object);
    }
    
    public boolean isChecked(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.isChecked(param1Object);
    }
    
    public boolean isClickable(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.isClickable(param1Object);
    }
    
    public boolean isEnabled(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.isEnabled(param1Object);
    }
    
    public boolean isFocusable(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.isFocusable(param1Object);
    }
    
    public boolean isFocused(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.isFocused(param1Object);
    }
    
    public boolean isLongClickable(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.isLongClickable(param1Object);
    }
    
    public boolean isPassword(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.isPassword(param1Object);
    }
    
    public boolean isScrollable(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.isScrollable(param1Object);
    }
    
    public boolean isSelected(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.isSelected(param1Object);
    }
    
    public Object obtain() {
      return AccessibilityNodeInfoCompatIcs.obtain();
    }
    
    public Object obtain(View param1View) {
      return AccessibilityNodeInfoCompatIcs.obtain(param1View);
    }
    
    public Object obtain(Object param1Object) {
      return AccessibilityNodeInfoCompatIcs.obtain(param1Object);
    }
    
    public boolean performAction(Object param1Object, int param1Int) {
      return AccessibilityNodeInfoCompatIcs.performAction(param1Object, param1Int);
    }
    
    public void recycle(Object param1Object) {
      AccessibilityNodeInfoCompatIcs.recycle(param1Object);
    }
    
    public void setBoundsInParent(Object param1Object, Rect param1Rect) {
      AccessibilityNodeInfoCompatIcs.setBoundsInParent(param1Object, param1Rect);
    }
    
    public void setBoundsInScreen(Object param1Object, Rect param1Rect) {
      AccessibilityNodeInfoCompatIcs.setBoundsInScreen(param1Object, param1Rect);
    }
    
    public void setCheckable(Object param1Object, boolean param1Boolean) {
      AccessibilityNodeInfoCompatIcs.setCheckable(param1Object, param1Boolean);
    }
    
    public void setChecked(Object param1Object, boolean param1Boolean) {
      AccessibilityNodeInfoCompatIcs.setChecked(param1Object, param1Boolean);
    }
    
    public void setClassName(Object param1Object, CharSequence param1CharSequence) {
      AccessibilityNodeInfoCompatIcs.setClassName(param1Object, param1CharSequence);
    }
    
    public void setClickable(Object param1Object, boolean param1Boolean) {
      AccessibilityNodeInfoCompatIcs.setClickable(param1Object, param1Boolean);
    }
    
    public void setContentDescription(Object param1Object, CharSequence param1CharSequence) {
      AccessibilityNodeInfoCompatIcs.setContentDescription(param1Object, param1CharSequence);
    }
    
    public void setEnabled(Object param1Object, boolean param1Boolean) {
      AccessibilityNodeInfoCompatIcs.setEnabled(param1Object, param1Boolean);
    }
    
    public void setFocusable(Object param1Object, boolean param1Boolean) {
      AccessibilityNodeInfoCompatIcs.setFocusable(param1Object, param1Boolean);
    }
    
    public void setFocused(Object param1Object, boolean param1Boolean) {
      AccessibilityNodeInfoCompatIcs.setFocused(param1Object, param1Boolean);
    }
    
    public void setLongClickable(Object param1Object, boolean param1Boolean) {
      AccessibilityNodeInfoCompatIcs.setLongClickable(param1Object, param1Boolean);
    }
    
    public void setPackageName(Object param1Object, CharSequence param1CharSequence) {
      AccessibilityNodeInfoCompatIcs.setPackageName(param1Object, param1CharSequence);
    }
    
    public void setParent(Object param1Object, View param1View) {
      AccessibilityNodeInfoCompatIcs.setParent(param1Object, param1View);
    }
    
    public void setPassword(Object param1Object, boolean param1Boolean) {
      AccessibilityNodeInfoCompatIcs.setPassword(param1Object, param1Boolean);
    }
    
    public void setScrollable(Object param1Object, boolean param1Boolean) {
      AccessibilityNodeInfoCompatIcs.setScrollable(param1Object, param1Boolean);
    }
    
    public void setSelected(Object param1Object, boolean param1Boolean) {
      AccessibilityNodeInfoCompatIcs.setSelected(param1Object, param1Boolean);
    }
    
    public void setSource(Object param1Object, View param1View) {
      AccessibilityNodeInfoCompatIcs.setSource(param1Object, param1View);
    }
    
    public void setText(Object param1Object, CharSequence param1CharSequence) {
      AccessibilityNodeInfoCompatIcs.setText(param1Object, param1CharSequence);
    }
  }
  
  static interface AccessibilityNodeInfoImpl {
    void addAction(Object param1Object, int param1Int);
    
    void addChild(Object param1Object, View param1View);
    
    void addChild(Object param1Object, View param1View, int param1Int);
    
    List<Object> findAccessibilityNodeInfosByText(Object param1Object, String param1String);
    
    Object findFocus(Object param1Object, int param1Int);
    
    Object focusSearch(Object param1Object, int param1Int);
    
    int getActions(Object param1Object);
    
    void getBoundsInParent(Object param1Object, Rect param1Rect);
    
    void getBoundsInScreen(Object param1Object, Rect param1Rect);
    
    Object getChild(Object param1Object, int param1Int);
    
    int getChildCount(Object param1Object);
    
    CharSequence getClassName(Object param1Object);
    
    CharSequence getContentDescription(Object param1Object);
    
    int getLiveRegion(Object param1Object);
    
    int getMovementGranularities(Object param1Object);
    
    CharSequence getPackageName(Object param1Object);
    
    Object getParent(Object param1Object);
    
    CharSequence getText(Object param1Object);
    
    String getViewIdResourceName(Object param1Object);
    
    int getWindowId(Object param1Object);
    
    boolean isAccessibilityFocused(Object param1Object);
    
    boolean isCheckable(Object param1Object);
    
    boolean isChecked(Object param1Object);
    
    boolean isClickable(Object param1Object);
    
    boolean isEnabled(Object param1Object);
    
    boolean isFocusable(Object param1Object);
    
    boolean isFocused(Object param1Object);
    
    boolean isLongClickable(Object param1Object);
    
    boolean isPassword(Object param1Object);
    
    boolean isScrollable(Object param1Object);
    
    boolean isSelected(Object param1Object);
    
    boolean isVisibleToUser(Object param1Object);
    
    Object obtain();
    
    Object obtain(View param1View);
    
    Object obtain(View param1View, int param1Int);
    
    Object obtain(Object param1Object);
    
    boolean performAction(Object param1Object, int param1Int);
    
    boolean performAction(Object param1Object, int param1Int, Bundle param1Bundle);
    
    void recycle(Object param1Object);
    
    void setAccessibilityFocused(Object param1Object, boolean param1Boolean);
    
    void setBoundsInParent(Object param1Object, Rect param1Rect);
    
    void setBoundsInScreen(Object param1Object, Rect param1Rect);
    
    void setCheckable(Object param1Object, boolean param1Boolean);
    
    void setChecked(Object param1Object, boolean param1Boolean);
    
    void setClassName(Object param1Object, CharSequence param1CharSequence);
    
    void setClickable(Object param1Object, boolean param1Boolean);
    
    void setContentDescription(Object param1Object, CharSequence param1CharSequence);
    
    void setEnabled(Object param1Object, boolean param1Boolean);
    
    void setFocusable(Object param1Object, boolean param1Boolean);
    
    void setFocused(Object param1Object, boolean param1Boolean);
    
    void setLiveRegion(Object param1Object, int param1Int);
    
    void setLongClickable(Object param1Object, boolean param1Boolean);
    
    void setMovementGranularities(Object param1Object, int param1Int);
    
    void setPackageName(Object param1Object, CharSequence param1CharSequence);
    
    void setParent(Object param1Object, View param1View);
    
    void setParent(Object param1Object, View param1View, int param1Int);
    
    void setPassword(Object param1Object, boolean param1Boolean);
    
    void setScrollable(Object param1Object, boolean param1Boolean);
    
    void setSelected(Object param1Object, boolean param1Boolean);
    
    void setSource(Object param1Object, View param1View);
    
    void setSource(Object param1Object, View param1View, int param1Int);
    
    void setText(Object param1Object, CharSequence param1CharSequence);
    
    void setViewIdResourceName(Object param1Object, String param1String);
    
    void setVisibleToUser(Object param1Object, boolean param1Boolean);
  }
  
  static class AccessibilityNodeInfoJellybeanImpl extends AccessibilityNodeInfoIcsImpl {
    public void addChild(Object param1Object, View param1View, int param1Int) {
      AccessibilityNodeInfoCompatJellyBean.addChild(param1Object, param1View, param1Int);
    }
    
    public Object findFocus(Object param1Object, int param1Int) {
      return AccessibilityNodeInfoCompatJellyBean.findFocus(param1Object, param1Int);
    }
    
    public Object focusSearch(Object param1Object, int param1Int) {
      return AccessibilityNodeInfoCompatJellyBean.focusSearch(param1Object, param1Int);
    }
    
    public int getMovementGranularities(Object param1Object) {
      return AccessibilityNodeInfoCompatJellyBean.getMovementGranularities(param1Object);
    }
    
    public boolean isAccessibilityFocused(Object param1Object) {
      return AccessibilityNodeInfoCompatJellyBean.isAccessibilityFocused(param1Object);
    }
    
    public boolean isVisibleToUser(Object param1Object) {
      return AccessibilityNodeInfoCompatJellyBean.isVisibleToUser(param1Object);
    }
    
    public Object obtain(View param1View, int param1Int) {
      return AccessibilityNodeInfoCompatJellyBean.obtain(param1View, param1Int);
    }
    
    public boolean performAction(Object param1Object, int param1Int, Bundle param1Bundle) {
      return AccessibilityNodeInfoCompatJellyBean.performAction(param1Object, param1Int, param1Bundle);
    }
    
    public void setAccessibilityFocused(Object param1Object, boolean param1Boolean) {
      AccessibilityNodeInfoCompatJellyBean.setAccesibilityFocused(param1Object, param1Boolean);
    }
    
    public void setMovementGranularities(Object param1Object, int param1Int) {
      AccessibilityNodeInfoCompatJellyBean.setMovementGranularities(param1Object, param1Int);
    }
    
    public void setParent(Object param1Object, View param1View, int param1Int) {
      AccessibilityNodeInfoCompatJellyBean.setParent(param1Object, param1View, param1Int);
    }
    
    public void setSource(Object param1Object, View param1View, int param1Int) {
      AccessibilityNodeInfoCompatJellyBean.setSource(param1Object, param1View, param1Int);
    }
    
    public void setVisibleToUser(Object param1Object, boolean param1Boolean) {
      AccessibilityNodeInfoCompatJellyBean.setVisibleToUser(param1Object, param1Boolean);
    }
  }
  
  static class AccessibilityNodeInfoJellybeanMr2Impl extends AccessibilityNodeInfoJellybeanImpl {
    public String getViewIdResourceName(Object param1Object) {
      return AccessibilityNodeInfoCompatJellybeanMr2.getViewIdResourceName(param1Object);
    }
    
    public void setViewIdResourceName(Object param1Object, String param1String) {
      AccessibilityNodeInfoCompatJellybeanMr2.setViewIdResourceName(param1Object, param1String);
    }
  }
  
  static class AccessibilityNodeInfoKitKatImpl extends AccessibilityNodeInfoJellybeanMr2Impl {
    public int getLiveRegion(Object param1Object) {
      return AccessibilityNodeInfoCompatKitKat.getLiveRegion(param1Object);
    }
    
    public void setLiveRegion(Object param1Object, int param1Int) {
      AccessibilityNodeInfoCompatKitKat.setLiveRegion(param1Object, param1Int);
    }
  }
  
  static class AccessibilityNodeInfoStubImpl implements AccessibilityNodeInfoImpl {
    public void addAction(Object param1Object, int param1Int) {}
    
    public void addChild(Object param1Object, View param1View) {}
    
    public void addChild(Object param1Object, View param1View, int param1Int) {}
    
    public List<Object> findAccessibilityNodeInfosByText(Object param1Object, String param1String) {
      return Collections.emptyList();
    }
    
    public Object findFocus(Object param1Object, int param1Int) {
      return null;
    }
    
    public Object focusSearch(Object param1Object, int param1Int) {
      return null;
    }
    
    public int getActions(Object param1Object) {
      return 0;
    }
    
    public void getBoundsInParent(Object param1Object, Rect param1Rect) {}
    
    public void getBoundsInScreen(Object param1Object, Rect param1Rect) {}
    
    public Object getChild(Object param1Object, int param1Int) {
      return null;
    }
    
    public int getChildCount(Object param1Object) {
      return 0;
    }
    
    public CharSequence getClassName(Object param1Object) {
      return null;
    }
    
    public CharSequence getContentDescription(Object param1Object) {
      return null;
    }
    
    public int getLiveRegion(Object param1Object) {
      return 0;
    }
    
    public int getMovementGranularities(Object param1Object) {
      return 0;
    }
    
    public CharSequence getPackageName(Object param1Object) {
      return null;
    }
    
    public Object getParent(Object param1Object) {
      return null;
    }
    
    public CharSequence getText(Object param1Object) {
      return null;
    }
    
    public String getViewIdResourceName(Object param1Object) {
      return null;
    }
    
    public int getWindowId(Object param1Object) {
      return 0;
    }
    
    public boolean isAccessibilityFocused(Object param1Object) {
      return false;
    }
    
    public boolean isCheckable(Object param1Object) {
      return false;
    }
    
    public boolean isChecked(Object param1Object) {
      return false;
    }
    
    public boolean isClickable(Object param1Object) {
      return false;
    }
    
    public boolean isEnabled(Object param1Object) {
      return false;
    }
    
    public boolean isFocusable(Object param1Object) {
      return false;
    }
    
    public boolean isFocused(Object param1Object) {
      return false;
    }
    
    public boolean isLongClickable(Object param1Object) {
      return false;
    }
    
    public boolean isPassword(Object param1Object) {
      return false;
    }
    
    public boolean isScrollable(Object param1Object) {
      return false;
    }
    
    public boolean isSelected(Object param1Object) {
      return false;
    }
    
    public boolean isVisibleToUser(Object param1Object) {
      return false;
    }
    
    public Object obtain() {
      return null;
    }
    
    public Object obtain(View param1View) {
      return null;
    }
    
    public Object obtain(View param1View, int param1Int) {
      return null;
    }
    
    public Object obtain(Object param1Object) {
      return null;
    }
    
    public boolean performAction(Object param1Object, int param1Int) {
      return false;
    }
    
    public boolean performAction(Object param1Object, int param1Int, Bundle param1Bundle) {
      return false;
    }
    
    public void recycle(Object param1Object) {}
    
    public void setAccessibilityFocused(Object param1Object, boolean param1Boolean) {}
    
    public void setBoundsInParent(Object param1Object, Rect param1Rect) {}
    
    public void setBoundsInScreen(Object param1Object, Rect param1Rect) {}
    
    public void setCheckable(Object param1Object, boolean param1Boolean) {}
    
    public void setChecked(Object param1Object, boolean param1Boolean) {}
    
    public void setClassName(Object param1Object, CharSequence param1CharSequence) {}
    
    public void setClickable(Object param1Object, boolean param1Boolean) {}
    
    public void setContentDescription(Object param1Object, CharSequence param1CharSequence) {}
    
    public void setEnabled(Object param1Object, boolean param1Boolean) {}
    
    public void setFocusable(Object param1Object, boolean param1Boolean) {}
    
    public void setFocused(Object param1Object, boolean param1Boolean) {}
    
    public void setLiveRegion(Object param1Object, int param1Int) {}
    
    public void setLongClickable(Object param1Object, boolean param1Boolean) {}
    
    public void setMovementGranularities(Object param1Object, int param1Int) {}
    
    public void setPackageName(Object param1Object, CharSequence param1CharSequence) {}
    
    public void setParent(Object param1Object, View param1View) {}
    
    public void setParent(Object param1Object, View param1View, int param1Int) {}
    
    public void setPassword(Object param1Object, boolean param1Boolean) {}
    
    public void setScrollable(Object param1Object, boolean param1Boolean) {}
    
    public void setSelected(Object param1Object, boolean param1Boolean) {}
    
    public void setSource(Object param1Object, View param1View) {}
    
    public void setSource(Object param1Object, View param1View, int param1Int) {}
    
    public void setText(Object param1Object, CharSequence param1CharSequence) {}
    
    public void setViewIdResourceName(Object param1Object, String param1String) {}
    
    public void setVisibleToUser(Object param1Object, boolean param1Boolean) {}
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v4/view/accessibility/AccessibilityNodeInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */