package android.support.v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.annotation.IntDef;
import android.support.annotation.Nullable;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.KeyEventCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewGroupCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;

public class DrawerLayout extends ViewGroup {
  private static final boolean ALLOW_EDGE_LOCK = false;
  
  private static final boolean CHILDREN_DISALLOW_INTERCEPT = true;
  
  private static final int DEFAULT_SCRIM_COLOR = -1728053248;
  
  private static final int[] LAYOUT_ATTRS = new int[] { 16842931 };
  
  public static final int LOCK_MODE_LOCKED_CLOSED = 1;
  
  public static final int LOCK_MODE_LOCKED_OPEN = 2;
  
  public static final int LOCK_MODE_UNLOCKED = 0;
  
  private static final int MIN_DRAWER_MARGIN = 64;
  
  private static final int MIN_FLING_VELOCITY = 400;
  
  private static final int PEEK_DELAY = 160;
  
  public static final int STATE_DRAGGING = 1;
  
  public static final int STATE_IDLE = 0;
  
  public static final int STATE_SETTLING = 2;
  
  private static final String TAG = "DrawerLayout";
  
  private static final float TOUCH_SLOP_SENSITIVITY = 1.0F;
  
  private final ChildAccessibilityDelegate mChildAccessibilityDelegate = new ChildAccessibilityDelegate();
  
  private boolean mChildrenCanceledTouch;
  
  private boolean mDisallowInterceptRequested;
  
  private int mDrawerState;
  
  private boolean mFirstLayout = true;
  
  private boolean mInLayout;
  
  private float mInitialMotionX;
  
  private float mInitialMotionY;
  
  private final ViewDragCallback mLeftCallback;
  
  private final ViewDragHelper mLeftDragger;
  
  private DrawerListener mListener;
  
  private int mLockModeLeft;
  
  private int mLockModeRight;
  
  private int mMinDrawerMargin;
  
  private final ViewDragCallback mRightCallback;
  
  private final ViewDragHelper mRightDragger;
  
  private int mScrimColor = -1728053248;
  
  private float mScrimOpacity;
  
  private Paint mScrimPaint = new Paint();
  
  private Drawable mShadowLeft;
  
  private Drawable mShadowRight;
  
  private CharSequence mTitleLeft;
  
  private CharSequence mTitleRight;
  
  public DrawerLayout(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public DrawerLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public DrawerLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    float f = (getResources().getDisplayMetrics()).density;
    this.mMinDrawerMargin = (int)(64.0F * f + 0.5F);
    f = 400.0F * f;
    this.mLeftCallback = new ViewDragCallback(3);
    this.mRightCallback = new ViewDragCallback(5);
    this.mLeftDragger = ViewDragHelper.create(this, 1.0F, this.mLeftCallback);
    this.mLeftDragger.setEdgeTrackingEnabled(1);
    this.mLeftDragger.setMinVelocity(f);
    this.mLeftCallback.setDragger(this.mLeftDragger);
    this.mRightDragger = ViewDragHelper.create(this, 1.0F, this.mRightCallback);
    this.mRightDragger.setEdgeTrackingEnabled(2);
    this.mRightDragger.setMinVelocity(f);
    this.mRightCallback.setDragger(this.mRightDragger);
    setFocusableInTouchMode(true);
    ViewCompat.setImportantForAccessibility((View)this, 1);
    ViewCompat.setAccessibilityDelegate((View)this, new AccessibilityDelegate());
    ViewGroupCompat.setMotionEventSplittingEnabled(this, false);
  }
  
  private View findVisibleDrawer() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildCount : ()I
    //   4: istore_1
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_2
    //   8: iload_1
    //   9: if_icmpge -> 42
    //   12: aload_0
    //   13: iload_2
    //   14: invokevirtual getChildAt : (I)Landroid/view/View;
    //   17: astore_3
    //   18: aload_0
    //   19: aload_3
    //   20: invokevirtual isDrawerView : (Landroid/view/View;)Z
    //   23: ifeq -> 36
    //   26: aload_0
    //   27: aload_3
    //   28: invokevirtual isDrawerVisible : (Landroid/view/View;)Z
    //   31: ifeq -> 36
    //   34: aload_3
    //   35: areturn
    //   36: iinc #2, 1
    //   39: goto -> 7
    //   42: aconst_null
    //   43: astore_3
    //   44: goto -> 34
  }
  
  static String gravityToString(int paramInt) {
    return ((paramInt & 0x3) == 3) ? "LEFT" : (((paramInt & 0x5) == 5) ? "RIGHT" : Integer.toHexString(paramInt));
  }
  
  private static boolean hasOpaqueBackground(View paramView) {
    boolean bool1 = false;
    Drawable drawable = paramView.getBackground();
    boolean bool2 = bool1;
    if (drawable != null) {
      bool2 = bool1;
      if (drawable.getOpacity() == -1)
        bool2 = true; 
    } 
    return bool2;
  }
  
  private boolean hasPeekingDrawer() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildCount : ()I
    //   4: istore_1
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_2
    //   8: iload_1
    //   9: if_icmpge -> 39
    //   12: aload_0
    //   13: iload_2
    //   14: invokevirtual getChildAt : (I)Landroid/view/View;
    //   17: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   20: checkcast android/support/v4/widget/DrawerLayout$LayoutParams
    //   23: getfield isPeeking : Z
    //   26: ifeq -> 33
    //   29: iconst_1
    //   30: istore_3
    //   31: iload_3
    //   32: ireturn
    //   33: iinc #2, 1
    //   36: goto -> 7
    //   39: iconst_0
    //   40: istore_3
    //   41: goto -> 31
  }
  
  private boolean hasVisibleDrawer() {
    return (findVisibleDrawer() != null);
  }
  
  private static boolean includeChildForAccessibilitiy(View paramView) {
    return (ViewCompat.getImportantForAccessibility(paramView) != 4 && ViewCompat.getImportantForAccessibility(paramView) != 2);
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (paramInt > 0 || (paramInt < 0 && getChildCount() > 0)) {
      ViewCompat.setImportantForAccessibility(paramView, 4);
      ViewCompat.setAccessibilityDelegate(paramView, this.mChildAccessibilityDelegate);
    } else {
      ViewCompat.setImportantForAccessibility(paramView, 1);
    } 
    super.addView(paramView, paramInt, paramLayoutParams);
  }
  
  void cancelChildViewTouch() {
    if (!this.mChildrenCanceledTouch) {
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
      int i = getChildCount();
      for (byte b = 0; b < i; b++)
        getChildAt(b).dispatchTouchEvent(motionEvent); 
      motionEvent.recycle();
      this.mChildrenCanceledTouch = true;
    } 
  }
  
  boolean checkDrawerViewAbsoluteGravity(View paramView, int paramInt) {
    return ((getDrawerViewAbsoluteGravity(paramView) & paramInt) == paramInt);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof LayoutParams && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void closeDrawer(int paramInt) {
    View view = findDrawerWithGravity(paramInt);
    if (view == null)
      throw new IllegalArgumentException("No drawer view found with gravity " + gravityToString(paramInt)); 
    closeDrawer(view);
  }
  
  public void closeDrawer(View paramView) {
    LayoutParams layoutParams;
    if (!isDrawerView(paramView))
      throw new IllegalArgumentException("View " + paramView + " is not a sliding drawer"); 
    if (this.mFirstLayout) {
      layoutParams = (LayoutParams)paramView.getLayoutParams();
      layoutParams.onScreen = 0.0F;
      layoutParams.knownOpen = false;
    } else if (checkDrawerViewAbsoluteGravity((View)layoutParams, 3)) {
      this.mLeftDragger.smoothSlideViewTo((View)layoutParams, -layoutParams.getWidth(), layoutParams.getTop());
    } else {
      this.mRightDragger.smoothSlideViewTo((View)layoutParams, getWidth(), layoutParams.getTop());
    } 
    invalidate();
  }
  
  public void closeDrawers() {
    closeDrawers(false);
  }
  
  void closeDrawers(boolean paramBoolean) {
    boolean bool;
    byte b1 = 0;
    int i = getChildCount();
    byte b2 = 0;
    while (b2 < i) {
      boolean bool1;
      View view = getChildAt(b2);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      int j = b1;
      if (isDrawerView(view))
        if (paramBoolean && !layoutParams.isPeeking) {
          j = b1;
        } else {
          boolean bool2;
          j = view.getWidth();
          if (checkDrawerViewAbsoluteGravity(view, 3)) {
            bool2 = b1 | this.mLeftDragger.smoothSlideViewTo(view, -j, view.getTop());
          } else {
            bool2 |= this.mRightDragger.smoothSlideViewTo(view, getWidth(), view.getTop());
          } 
          layoutParams.isPeeking = false;
          bool1 = bool2;
        }  
      b2++;
      bool = bool1;
    } 
    this.mLeftCallback.removeCallbacks();
    this.mRightCallback.removeCallbacks();
    if (bool)
      invalidate(); 
  }
  
  public void computeScroll() {
    int i = getChildCount();
    float f = 0.0F;
    for (byte b = 0; b < i; b++)
      f = Math.max(f, ((LayoutParams)getChildAt(b).getLayoutParams()).onScreen); 
    this.mScrimOpacity = f;
    if ((this.mLeftDragger.continueSettling(true) | this.mRightDragger.continueSettling(true)) != 0)
      ViewCompat.postInvalidateOnAnimation((View)this); 
  }
  
  void dispatchOnDrawerClosed(View paramView) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (layoutParams.knownOpen) {
      layoutParams.knownOpen = false;
      if (this.mListener != null)
        this.mListener.onDrawerClosed(paramView); 
      View view = getChildAt(0);
      if (view != null)
        ViewCompat.setImportantForAccessibility(view, 1); 
      ViewCompat.setImportantForAccessibility(paramView, 4);
      if (hasWindowFocus()) {
        paramView = getRootView();
        if (paramView != null)
          paramView.sendAccessibilityEvent(32); 
      } 
    } 
  }
  
  void dispatchOnDrawerOpened(View paramView) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (!layoutParams.knownOpen) {
      layoutParams.knownOpen = true;
      if (this.mListener != null)
        this.mListener.onDrawerOpened(paramView); 
      View view = getChildAt(0);
      if (view != null)
        ViewCompat.setImportantForAccessibility(view, 4); 
      ViewCompat.setImportantForAccessibility(paramView, 1);
      sendAccessibilityEvent(32);
      paramView.requestFocus();
    } 
  }
  
  void dispatchOnDrawerSlide(View paramView, float paramFloat) {
    if (this.mListener != null)
      this.mListener.onDrawerSlide(paramView, paramFloat); 
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    int i = getHeight();
    boolean bool1 = isContentView(paramView);
    int j = 0;
    int k = 0;
    int m = getWidth();
    int n = paramCanvas.save();
    int i1 = m;
    if (bool1) {
      int i2 = getChildCount();
      i1 = 0;
      j = k;
      while (i1 < i2) {
        View view = getChildAt(i1);
        k = j;
        int i3 = m;
        if (view != paramView) {
          k = j;
          i3 = m;
          if (view.getVisibility() == 0) {
            k = j;
            i3 = m;
            if (hasOpaqueBackground(view)) {
              k = j;
              i3 = m;
              if (isDrawerView(view))
                if (view.getHeight() < i) {
                  i3 = m;
                  k = j;
                } else if (checkDrawerViewAbsoluteGravity(view, 3)) {
                  int i4 = view.getRight();
                  k = j;
                  i3 = m;
                  if (i4 > j) {
                    k = i4;
                    i3 = m;
                  } 
                } else {
                  int i4 = view.getLeft();
                  k = j;
                  i3 = m;
                  if (i4 < m) {
                    i3 = i4;
                    k = j;
                  } 
                }  
            } 
          } 
        } 
        i1++;
        j = k;
        m = i3;
      } 
      paramCanvas.clipRect(j, 0, m, getHeight());
      i1 = m;
    } 
    boolean bool2 = super.drawChild(paramCanvas, paramView, paramLong);
    paramCanvas.restoreToCount(n);
    if (this.mScrimOpacity > 0.0F && bool1) {
      k = (int)(((this.mScrimColor & 0xFF000000) >>> 24) * this.mScrimOpacity);
      m = this.mScrimColor;
      this.mScrimPaint.setColor(k << 24 | m & 0xFFFFFF);
      paramCanvas.drawRect(j, 0.0F, i1, getHeight(), this.mScrimPaint);
      return bool2;
    } 
    if (this.mShadowLeft != null && checkDrawerViewAbsoluteGravity(paramView, 3)) {
      i1 = this.mShadowLeft.getIntrinsicWidth();
      m = paramView.getRight();
      j = this.mLeftDragger.getEdgeSize();
      float f = Math.max(0.0F, Math.min(m / j, 1.0F));
      this.mShadowLeft.setBounds(m, paramView.getTop(), m + i1, paramView.getBottom());
      this.mShadowLeft.setAlpha((int)(255.0F * f));
      this.mShadowLeft.draw(paramCanvas);
      return bool2;
    } 
    if (this.mShadowRight != null && checkDrawerViewAbsoluteGravity(paramView, 5)) {
      k = this.mShadowRight.getIntrinsicWidth();
      m = paramView.getLeft();
      i1 = getWidth();
      j = this.mRightDragger.getEdgeSize();
      float f = Math.max(0.0F, Math.min((i1 - m) / j, 1.0F));
      this.mShadowRight.setBounds(m - k, paramView.getTop(), m, paramView.getBottom());
      this.mShadowRight.setAlpha((int)(255.0F * f));
      this.mShadowRight.draw(paramCanvas);
    } 
    return bool2;
  }
  
  View findDrawerWithGravity(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: aload_0
    //   2: invokestatic getLayoutDirection : (Landroid/view/View;)I
    //   5: invokestatic getAbsoluteGravity : (II)I
    //   8: istore_2
    //   9: aload_0
    //   10: invokevirtual getChildCount : ()I
    //   13: istore_3
    //   14: iconst_0
    //   15: istore_1
    //   16: iload_1
    //   17: iload_3
    //   18: if_icmpge -> 53
    //   21: aload_0
    //   22: iload_1
    //   23: invokevirtual getChildAt : (I)Landroid/view/View;
    //   26: astore #4
    //   28: aload_0
    //   29: aload #4
    //   31: invokevirtual getDrawerViewAbsoluteGravity : (Landroid/view/View;)I
    //   34: bipush #7
    //   36: iand
    //   37: iload_2
    //   38: bipush #7
    //   40: iand
    //   41: if_icmpne -> 47
    //   44: aload #4
    //   46: areturn
    //   47: iinc #1, 1
    //   50: goto -> 16
    //   53: aconst_null
    //   54: astore #4
    //   56: goto -> 44
  }
  
  View findOpenDrawer() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildCount : ()I
    //   4: istore_1
    //   5: iconst_0
    //   6: istore_2
    //   7: iload_2
    //   8: iload_1
    //   9: if_icmpge -> 39
    //   12: aload_0
    //   13: iload_2
    //   14: invokevirtual getChildAt : (I)Landroid/view/View;
    //   17: astore_3
    //   18: aload_3
    //   19: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   22: checkcast android/support/v4/widget/DrawerLayout$LayoutParams
    //   25: getfield knownOpen : Z
    //   28: ifeq -> 33
    //   31: aload_3
    //   32: areturn
    //   33: iinc #2, 1
    //   36: goto -> 7
    //   39: aconst_null
    //   40: astore_3
    //   41: goto -> 31
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new LayoutParams(-1, -1);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)((paramLayoutParams instanceof LayoutParams) ? new LayoutParams((LayoutParams)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams) : new LayoutParams(paramLayoutParams)));
  }
  
  public int getDrawerLockMode(int paramInt) {
    paramInt = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection((View)this));
    return (paramInt == 3) ? this.mLockModeLeft : ((paramInt == 5) ? this.mLockModeRight : 0);
  }
  
  public int getDrawerLockMode(View paramView) {
    null = getDrawerViewAbsoluteGravity(paramView);
    return (null == 3) ? this.mLockModeLeft : ((null == 5) ? this.mLockModeRight : 0);
  }
  
  @Nullable
  public CharSequence getDrawerTitle(int paramInt) {
    paramInt = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection((View)this));
    return (paramInt == 3) ? this.mTitleLeft : ((paramInt == 5) ? this.mTitleRight : null);
  }
  
  int getDrawerViewAbsoluteGravity(View paramView) {
    return GravityCompat.getAbsoluteGravity(((LayoutParams)paramView.getLayoutParams()).gravity, ViewCompat.getLayoutDirection((View)this));
  }
  
  float getDrawerViewOffset(View paramView) {
    return ((LayoutParams)paramView.getLayoutParams()).onScreen;
  }
  
  boolean isContentView(View paramView) {
    return (((LayoutParams)paramView.getLayoutParams()).gravity == 0);
  }
  
  public boolean isDrawerOpen(int paramInt) {
    View view = findDrawerWithGravity(paramInt);
    return (view != null) ? isDrawerOpen(view) : false;
  }
  
  public boolean isDrawerOpen(View paramView) {
    if (!isDrawerView(paramView))
      throw new IllegalArgumentException("View " + paramView + " is not a drawer"); 
    return ((LayoutParams)paramView.getLayoutParams()).knownOpen;
  }
  
  boolean isDrawerView(View paramView) {
    return ((GravityCompat.getAbsoluteGravity(((LayoutParams)paramView.getLayoutParams()).gravity, ViewCompat.getLayoutDirection(paramView)) & 0x7) != 0);
  }
  
  public boolean isDrawerVisible(int paramInt) {
    View view = findDrawerWithGravity(paramInt);
    return (view != null) ? isDrawerVisible(view) : false;
  }
  
  public boolean isDrawerVisible(View paramView) {
    if (!isDrawerView(paramView))
      throw new IllegalArgumentException("View " + paramView + " is not a drawer"); 
    return (((LayoutParams)paramView.getLayoutParams()).onScreen > 0.0F);
  }
  
  void moveDrawerToOffset(View paramView, float paramFloat) {
    float f = getDrawerViewOffset(paramView);
    int i = paramView.getWidth();
    int j = (int)(i * f);
    j = (int)(i * paramFloat) - j;
    if (!checkDrawerViewAbsoluteGravity(paramView, 3))
      j = -j; 
    paramView.offsetLeftAndRight(j);
    setDrawerViewOffset(paramView, paramFloat);
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.mFirstLayout = true;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.mFirstLayout = true;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_1
    //   3: invokestatic getActionMasked : (Landroid/view/MotionEvent;)I
    //   6: istore_3
    //   7: aload_0
    //   8: getfield mLeftDragger : Landroid/support/v4/widget/ViewDragHelper;
    //   11: aload_1
    //   12: invokevirtual shouldInterceptTouchEvent : (Landroid/view/MotionEvent;)Z
    //   15: istore #4
    //   17: aload_0
    //   18: getfield mRightDragger : Landroid/support/v4/widget/ViewDragHelper;
    //   21: aload_1
    //   22: invokevirtual shouldInterceptTouchEvent : (Landroid/view/MotionEvent;)Z
    //   25: istore #5
    //   27: iconst_0
    //   28: istore #6
    //   30: iconst_0
    //   31: istore #7
    //   33: iload_3
    //   34: tableswitch default -> 64, 0 -> 97, 1 -> 205, 2 -> 171, 3 -> 205
    //   64: iload #7
    //   66: istore_3
    //   67: iload #4
    //   69: iload #5
    //   71: ior
    //   72: ifne -> 93
    //   75: iload_3
    //   76: ifne -> 93
    //   79: aload_0
    //   80: invokespecial hasPeekingDrawer : ()Z
    //   83: ifne -> 93
    //   86: aload_0
    //   87: getfield mChildrenCanceledTouch : Z
    //   90: ifeq -> 95
    //   93: iconst_1
    //   94: istore_2
    //   95: iload_2
    //   96: ireturn
    //   97: aload_1
    //   98: invokevirtual getX : ()F
    //   101: fstore #8
    //   103: aload_1
    //   104: invokevirtual getY : ()F
    //   107: fstore #9
    //   109: aload_0
    //   110: fload #8
    //   112: putfield mInitialMotionX : F
    //   115: aload_0
    //   116: fload #9
    //   118: putfield mInitialMotionY : F
    //   121: iload #6
    //   123: istore_3
    //   124: aload_0
    //   125: getfield mScrimOpacity : F
    //   128: fconst_0
    //   129: fcmpl
    //   130: ifle -> 158
    //   133: iload #6
    //   135: istore_3
    //   136: aload_0
    //   137: aload_0
    //   138: getfield mLeftDragger : Landroid/support/v4/widget/ViewDragHelper;
    //   141: fload #8
    //   143: f2i
    //   144: fload #9
    //   146: f2i
    //   147: invokevirtual findTopChildUnder : (II)Landroid/view/View;
    //   150: invokevirtual isContentView : (Landroid/view/View;)Z
    //   153: ifeq -> 158
    //   156: iconst_1
    //   157: istore_3
    //   158: aload_0
    //   159: iconst_0
    //   160: putfield mDisallowInterceptRequested : Z
    //   163: aload_0
    //   164: iconst_0
    //   165: putfield mChildrenCanceledTouch : Z
    //   168: goto -> 67
    //   171: iload #7
    //   173: istore_3
    //   174: aload_0
    //   175: getfield mLeftDragger : Landroid/support/v4/widget/ViewDragHelper;
    //   178: iconst_3
    //   179: invokevirtual checkTouchSlop : (I)Z
    //   182: ifeq -> 67
    //   185: aload_0
    //   186: getfield mLeftCallback : Landroid/support/v4/widget/DrawerLayout$ViewDragCallback;
    //   189: invokevirtual removeCallbacks : ()V
    //   192: aload_0
    //   193: getfield mRightCallback : Landroid/support/v4/widget/DrawerLayout$ViewDragCallback;
    //   196: invokevirtual removeCallbacks : ()V
    //   199: iload #7
    //   201: istore_3
    //   202: goto -> 67
    //   205: aload_0
    //   206: iconst_1
    //   207: invokevirtual closeDrawers : (Z)V
    //   210: aload_0
    //   211: iconst_0
    //   212: putfield mDisallowInterceptRequested : Z
    //   215: aload_0
    //   216: iconst_0
    //   217: putfield mChildrenCanceledTouch : Z
    //   220: iload #7
    //   222: istore_3
    //   223: goto -> 67
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4 && hasVisibleDrawer()) {
      KeyEventCompat.startTracking(paramKeyEvent);
      return true;
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    View view;
    if (paramInt == 4) {
      view = findVisibleDrawer();
      if (view != null && getDrawerLockMode(view) == 0)
        closeDrawers(); 
      return (view != null);
    } 
    return super.onKeyUp(paramInt, (KeyEvent)view);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_1
    //   2: putfield mInLayout : Z
    //   5: iload #4
    //   7: iload_2
    //   8: isub
    //   9: istore #6
    //   11: aload_0
    //   12: invokevirtual getChildCount : ()I
    //   15: istore #7
    //   17: iconst_0
    //   18: istore #4
    //   20: iload #4
    //   22: iload #7
    //   24: if_icmpge -> 446
    //   27: aload_0
    //   28: iload #4
    //   30: invokevirtual getChildAt : (I)Landroid/view/View;
    //   33: astore #8
    //   35: aload #8
    //   37: invokevirtual getVisibility : ()I
    //   40: bipush #8
    //   42: if_icmpne -> 51
    //   45: iinc #4, 1
    //   48: goto -> 20
    //   51: aload #8
    //   53: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   56: checkcast android/support/v4/widget/DrawerLayout$LayoutParams
    //   59: astore #9
    //   61: aload_0
    //   62: aload #8
    //   64: invokevirtual isContentView : (Landroid/view/View;)Z
    //   67: ifeq -> 110
    //   70: aload #8
    //   72: aload #9
    //   74: getfield leftMargin : I
    //   77: aload #9
    //   79: getfield topMargin : I
    //   82: aload #9
    //   84: getfield leftMargin : I
    //   87: aload #8
    //   89: invokevirtual getMeasuredWidth : ()I
    //   92: iadd
    //   93: aload #9
    //   95: getfield topMargin : I
    //   98: aload #8
    //   100: invokevirtual getMeasuredHeight : ()I
    //   103: iadd
    //   104: invokevirtual layout : (IIII)V
    //   107: goto -> 45
    //   110: aload #8
    //   112: invokevirtual getMeasuredWidth : ()I
    //   115: istore #10
    //   117: aload #8
    //   119: invokevirtual getMeasuredHeight : ()I
    //   122: istore #11
    //   124: aload_0
    //   125: aload #8
    //   127: iconst_3
    //   128: invokevirtual checkDrawerViewAbsoluteGravity : (Landroid/view/View;I)Z
    //   131: ifeq -> 280
    //   134: iload #10
    //   136: ineg
    //   137: iload #10
    //   139: i2f
    //   140: aload #9
    //   142: getfield onScreen : F
    //   145: fmul
    //   146: f2i
    //   147: iadd
    //   148: istore #12
    //   150: iload #10
    //   152: iload #12
    //   154: iadd
    //   155: i2f
    //   156: iload #10
    //   158: i2f
    //   159: fdiv
    //   160: fstore #13
    //   162: fload #13
    //   164: aload #9
    //   166: getfield onScreen : F
    //   169: fcmpl
    //   170: ifeq -> 310
    //   173: iconst_1
    //   174: istore #14
    //   176: aload #9
    //   178: getfield gravity : I
    //   181: bipush #112
    //   183: iand
    //   184: lookupswitch default -> 212, 16 -> 356, 80 -> 316
    //   212: aload #8
    //   214: iload #12
    //   216: aload #9
    //   218: getfield topMargin : I
    //   221: iload #12
    //   223: iload #10
    //   225: iadd
    //   226: aload #9
    //   228: getfield topMargin : I
    //   231: iload #11
    //   233: iadd
    //   234: invokevirtual layout : (IIII)V
    //   237: iload #14
    //   239: ifeq -> 250
    //   242: aload_0
    //   243: aload #8
    //   245: fload #13
    //   247: invokevirtual setDrawerViewOffset : (Landroid/view/View;F)V
    //   250: aload #9
    //   252: getfield onScreen : F
    //   255: fconst_0
    //   256: fcmpl
    //   257: ifle -> 441
    //   260: iconst_0
    //   261: istore_2
    //   262: aload #8
    //   264: invokevirtual getVisibility : ()I
    //   267: iload_2
    //   268: if_icmpeq -> 45
    //   271: aload #8
    //   273: iload_2
    //   274: invokevirtual setVisibility : (I)V
    //   277: goto -> 45
    //   280: iload #6
    //   282: iload #10
    //   284: i2f
    //   285: aload #9
    //   287: getfield onScreen : F
    //   290: fmul
    //   291: f2i
    //   292: isub
    //   293: istore #12
    //   295: iload #6
    //   297: iload #12
    //   299: isub
    //   300: i2f
    //   301: iload #10
    //   303: i2f
    //   304: fdiv
    //   305: fstore #13
    //   307: goto -> 162
    //   310: iconst_0
    //   311: istore #14
    //   313: goto -> 176
    //   316: iload #5
    //   318: iload_3
    //   319: isub
    //   320: istore_2
    //   321: aload #8
    //   323: iload #12
    //   325: iload_2
    //   326: aload #9
    //   328: getfield bottomMargin : I
    //   331: isub
    //   332: aload #8
    //   334: invokevirtual getMeasuredHeight : ()I
    //   337: isub
    //   338: iload #12
    //   340: iload #10
    //   342: iadd
    //   343: iload_2
    //   344: aload #9
    //   346: getfield bottomMargin : I
    //   349: isub
    //   350: invokevirtual layout : (IIII)V
    //   353: goto -> 237
    //   356: iload #5
    //   358: iload_3
    //   359: isub
    //   360: istore #15
    //   362: iload #15
    //   364: iload #11
    //   366: isub
    //   367: iconst_2
    //   368: idiv
    //   369: istore #16
    //   371: iload #16
    //   373: aload #9
    //   375: getfield topMargin : I
    //   378: if_icmpge -> 407
    //   381: aload #9
    //   383: getfield topMargin : I
    //   386: istore_2
    //   387: aload #8
    //   389: iload #12
    //   391: iload_2
    //   392: iload #12
    //   394: iload #10
    //   396: iadd
    //   397: iload_2
    //   398: iload #11
    //   400: iadd
    //   401: invokevirtual layout : (IIII)V
    //   404: goto -> 237
    //   407: iload #16
    //   409: istore_2
    //   410: iload #16
    //   412: iload #11
    //   414: iadd
    //   415: iload #15
    //   417: aload #9
    //   419: getfield bottomMargin : I
    //   422: isub
    //   423: if_icmple -> 387
    //   426: iload #15
    //   428: aload #9
    //   430: getfield bottomMargin : I
    //   433: isub
    //   434: iload #11
    //   436: isub
    //   437: istore_2
    //   438: goto -> 387
    //   441: iconst_4
    //   442: istore_2
    //   443: goto -> 262
    //   446: aload_0
    //   447: iconst_0
    //   448: putfield mInLayout : Z
    //   451: aload_0
    //   452: iconst_0
    //   453: putfield mFirstLayout : Z
    //   456: return
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_1
    //   1: invokestatic getMode : (I)I
    //   4: istore_3
    //   5: iload_2
    //   6: invokestatic getMode : (I)I
    //   9: istore #4
    //   11: iload_1
    //   12: invokestatic getSize : (I)I
    //   15: istore #5
    //   17: iload_2
    //   18: invokestatic getSize : (I)I
    //   21: istore #6
    //   23: iload_3
    //   24: ldc_w 1073741824
    //   27: if_icmpne -> 46
    //   30: iload #6
    //   32: istore #7
    //   34: iload #5
    //   36: istore #8
    //   38: iload #4
    //   40: ldc_w 1073741824
    //   43: if_icmpeq -> 76
    //   46: aload_0
    //   47: invokevirtual isInEditMode : ()Z
    //   50: ifeq -> 161
    //   53: iload_3
    //   54: ldc_w -2147483648
    //   57: if_icmpne -> 124
    //   60: iload #4
    //   62: ldc_w -2147483648
    //   65: if_icmpne -> 136
    //   68: iload #5
    //   70: istore #8
    //   72: iload #6
    //   74: istore #7
    //   76: aload_0
    //   77: iload #8
    //   79: iload #7
    //   81: invokevirtual setMeasuredDimension : (II)V
    //   84: aload_0
    //   85: invokevirtual getChildCount : ()I
    //   88: istore #6
    //   90: iconst_0
    //   91: istore #5
    //   93: iload #5
    //   95: iload #6
    //   97: if_icmpge -> 426
    //   100: aload_0
    //   101: iload #5
    //   103: invokevirtual getChildAt : (I)Landroid/view/View;
    //   106: astore #9
    //   108: aload #9
    //   110: invokevirtual getVisibility : ()I
    //   113: bipush #8
    //   115: if_icmpne -> 172
    //   118: iinc #5, 1
    //   121: goto -> 93
    //   124: iload_3
    //   125: ifne -> 60
    //   128: sipush #300
    //   131: istore #5
    //   133: goto -> 60
    //   136: iload #6
    //   138: istore #7
    //   140: iload #5
    //   142: istore #8
    //   144: iload #4
    //   146: ifne -> 76
    //   149: sipush #300
    //   152: istore #7
    //   154: iload #5
    //   156: istore #8
    //   158: goto -> 76
    //   161: new java/lang/IllegalArgumentException
    //   164: dup
    //   165: ldc_w 'DrawerLayout must be measured with MeasureSpec.EXACTLY.'
    //   168: invokespecial <init> : (Ljava/lang/String;)V
    //   171: athrow
    //   172: aload #9
    //   174: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   177: checkcast android/support/v4/widget/DrawerLayout$LayoutParams
    //   180: astore #10
    //   182: aload_0
    //   183: aload #9
    //   185: invokevirtual isContentView : (Landroid/view/View;)Z
    //   188: ifeq -> 239
    //   191: aload #9
    //   193: iload #8
    //   195: aload #10
    //   197: getfield leftMargin : I
    //   200: isub
    //   201: aload #10
    //   203: getfield rightMargin : I
    //   206: isub
    //   207: ldc_w 1073741824
    //   210: invokestatic makeMeasureSpec : (II)I
    //   213: iload #7
    //   215: aload #10
    //   217: getfield topMargin : I
    //   220: isub
    //   221: aload #10
    //   223: getfield bottomMargin : I
    //   226: isub
    //   227: ldc_w 1073741824
    //   230: invokestatic makeMeasureSpec : (II)I
    //   233: invokevirtual measure : (II)V
    //   236: goto -> 118
    //   239: aload_0
    //   240: aload #9
    //   242: invokevirtual isDrawerView : (Landroid/view/View;)Z
    //   245: ifeq -> 374
    //   248: aload_0
    //   249: aload #9
    //   251: invokevirtual getDrawerViewAbsoluteGravity : (Landroid/view/View;)I
    //   254: bipush #7
    //   256: iand
    //   257: istore #4
    //   259: iconst_0
    //   260: iload #4
    //   262: iand
    //   263: ifeq -> 321
    //   266: new java/lang/IllegalStateException
    //   269: dup
    //   270: new java/lang/StringBuilder
    //   273: dup
    //   274: invokespecial <init> : ()V
    //   277: ldc_w 'Child drawer has absolute gravity '
    //   280: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   283: iload #4
    //   285: invokestatic gravityToString : (I)Ljava/lang/String;
    //   288: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   291: ldc_w ' but this '
    //   294: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   297: ldc 'DrawerLayout'
    //   299: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   302: ldc_w ' already has a '
    //   305: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   308: ldc_w 'drawer view along that edge'
    //   311: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   314: invokevirtual toString : ()Ljava/lang/String;
    //   317: invokespecial <init> : (Ljava/lang/String;)V
    //   320: athrow
    //   321: aload #9
    //   323: iload_1
    //   324: aload_0
    //   325: getfield mMinDrawerMargin : I
    //   328: aload #10
    //   330: getfield leftMargin : I
    //   333: iadd
    //   334: aload #10
    //   336: getfield rightMargin : I
    //   339: iadd
    //   340: aload #10
    //   342: getfield width : I
    //   345: invokestatic getChildMeasureSpec : (III)I
    //   348: iload_2
    //   349: aload #10
    //   351: getfield topMargin : I
    //   354: aload #10
    //   356: getfield bottomMargin : I
    //   359: iadd
    //   360: aload #10
    //   362: getfield height : I
    //   365: invokestatic getChildMeasureSpec : (III)I
    //   368: invokevirtual measure : (II)V
    //   371: goto -> 118
    //   374: new java/lang/IllegalStateException
    //   377: dup
    //   378: new java/lang/StringBuilder
    //   381: dup
    //   382: invokespecial <init> : ()V
    //   385: ldc_w 'Child '
    //   388: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   391: aload #9
    //   393: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   396: ldc_w ' at index '
    //   399: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   402: iload #5
    //   404: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   407: ldc_w ' does not have a valid layout_gravity - must be Gravity.LEFT, '
    //   410: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   413: ldc_w 'Gravity.RIGHT or Gravity.NO_GRAVITY'
    //   416: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   419: invokevirtual toString : ()Ljava/lang/String;
    //   422: invokespecial <init> : (Ljava/lang/String;)V
    //   425: athrow
    //   426: return
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    if (savedState.openDrawerGravity != 0) {
      View view = findDrawerWithGravity(savedState.openDrawerGravity);
      if (view != null)
        openDrawer(view); 
    } 
    setDrawerLockMode(savedState.lockModeLeft, 3);
    setDrawerLockMode(savedState.lockModeRight, 5);
  }
  
  protected Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (isDrawerView(view)) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.knownOpen) {
          savedState.openDrawerGravity = layoutParams.gravity;
          break;
        } 
      } 
    } 
    savedState.lockModeLeft = this.mLockModeLeft;
    savedState.lockModeRight = this.mLockModeRight;
    return (Parcelable)savedState;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    View view;
    float f1;
    float f2;
    boolean bool1;
    boolean bool2;
    this.mLeftDragger.processTouchEvent(paramMotionEvent);
    this.mRightDragger.processTouchEvent(paramMotionEvent);
    switch (paramMotionEvent.getAction() & 0xFF) {
      default:
        return true;
      case 0:
        f1 = paramMotionEvent.getX();
        f2 = paramMotionEvent.getY();
        this.mInitialMotionX = f1;
        this.mInitialMotionY = f2;
        this.mDisallowInterceptRequested = false;
        this.mChildrenCanceledTouch = false;
      case 1:
        f2 = paramMotionEvent.getX();
        f1 = paramMotionEvent.getY();
        bool1 = true;
        view = this.mLeftDragger.findTopChildUnder((int)f2, (int)f1);
        bool2 = bool1;
        if (view != null) {
          bool2 = bool1;
          if (isContentView(view)) {
            f2 -= this.mInitialMotionX;
            f1 -= this.mInitialMotionY;
            int i = this.mLeftDragger.getTouchSlop();
            bool2 = bool1;
            if (f2 * f2 + f1 * f1 < (i * i)) {
              view = findOpenDrawer();
              bool2 = bool1;
              if (view != null)
                if (getDrawerLockMode(view) == 2) {
                  bool2 = true;
                } else {
                  bool2 = false;
                }  
            } 
          } 
        } 
        closeDrawers(bool2);
        this.mDisallowInterceptRequested = false;
      case 3:
        break;
    } 
    closeDrawers(true);
    this.mDisallowInterceptRequested = false;
    this.mChildrenCanceledTouch = false;
  }
  
  public void openDrawer(int paramInt) {
    View view = findDrawerWithGravity(paramInt);
    if (view == null)
      throw new IllegalArgumentException("No drawer view found with gravity " + gravityToString(paramInt)); 
    openDrawer(view);
  }
  
  public void openDrawer(View paramView) {
    LayoutParams layoutParams;
    if (!isDrawerView(paramView))
      throw new IllegalArgumentException("View " + paramView + " is not a sliding drawer"); 
    if (this.mFirstLayout) {
      layoutParams = (LayoutParams)paramView.getLayoutParams();
      layoutParams.onScreen = 1.0F;
      layoutParams.knownOpen = true;
    } else if (checkDrawerViewAbsoluteGravity((View)layoutParams, 3)) {
      this.mLeftDragger.smoothSlideViewTo((View)layoutParams, 0, layoutParams.getTop());
    } else {
      this.mRightDragger.smoothSlideViewTo((View)layoutParams, getWidth() - layoutParams.getWidth(), layoutParams.getTop());
    } 
    invalidate();
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    this.mDisallowInterceptRequested = paramBoolean;
    if (paramBoolean)
      closeDrawers(true); 
  }
  
  public void requestLayout() {
    if (!this.mInLayout)
      super.requestLayout(); 
  }
  
  public void setDrawerListener(DrawerListener paramDrawerListener) {
    this.mListener = paramDrawerListener;
  }
  
  public void setDrawerLockMode(int paramInt) {
    setDrawerLockMode(paramInt, 3);
    setDrawerLockMode(paramInt, 5);
  }
  
  public void setDrawerLockMode(int paramInt1, int paramInt2) {
    paramInt2 = GravityCompat.getAbsoluteGravity(paramInt2, ViewCompat.getLayoutDirection((View)this));
    if (paramInt2 == 3) {
      this.mLockModeLeft = paramInt1;
    } else if (paramInt2 == 5) {
      this.mLockModeRight = paramInt1;
    } 
    if (paramInt1 != 0) {
      ViewDragHelper viewDragHelper;
      if (paramInt2 == 3) {
        viewDragHelper = this.mLeftDragger;
      } else {
        viewDragHelper = this.mRightDragger;
      } 
      viewDragHelper.cancel();
    } 
    switch (paramInt1) {
      default:
        return;
      case 2:
        view = findDrawerWithGravity(paramInt2);
        if (view != null)
          openDrawer(view); 
      case 1:
        break;
    } 
    View view = findDrawerWithGravity(paramInt2);
    if (view != null)
      closeDrawer(view); 
  }
  
  public void setDrawerLockMode(int paramInt, View paramView) {
    if (!isDrawerView(paramView))
      throw new IllegalArgumentException("View " + paramView + " is not a " + "drawer with appropriate layout_gravity"); 
    setDrawerLockMode(paramInt, ((LayoutParams)paramView.getLayoutParams()).gravity);
  }
  
  public void setDrawerShadow(int paramInt1, int paramInt2) {
    setDrawerShadow(getResources().getDrawable(paramInt1), paramInt2);
  }
  
  public void setDrawerShadow(Drawable paramDrawable, int paramInt) {
    paramInt = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection((View)this));
    if ((paramInt & 0x3) == 3) {
      this.mShadowLeft = paramDrawable;
      invalidate();
    } 
    if ((paramInt & 0x5) == 5) {
      this.mShadowRight = paramDrawable;
      invalidate();
    } 
  }
  
  public void setDrawerTitle(int paramInt, CharSequence paramCharSequence) {
    paramInt = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection((View)this));
    if (paramInt == 3) {
      this.mTitleLeft = paramCharSequence;
      return;
    } 
    if (paramInt == 5)
      this.mTitleRight = paramCharSequence; 
  }
  
  void setDrawerViewOffset(View paramView, float paramFloat) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (paramFloat != layoutParams.onScreen) {
      layoutParams.onScreen = paramFloat;
      dispatchOnDrawerSlide(paramView, paramFloat);
    } 
  }
  
  public void setScrimColor(int paramInt) {
    this.mScrimColor = paramInt;
    invalidate();
  }
  
  void updateDrawerState(int paramInt1, int paramInt2, View paramView) {
    paramInt1 = this.mLeftDragger.getViewDragState();
    int i = this.mRightDragger.getViewDragState();
    if (paramInt1 == 1 || i == 1) {
      paramInt1 = 1;
    } else if (paramInt1 == 2 || i == 2) {
      paramInt1 = 2;
    } else {
      paramInt1 = 0;
    } 
    if (paramView != null && paramInt2 == 0) {
      LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
      if (layoutParams.onScreen == 0.0F) {
        dispatchOnDrawerClosed(paramView);
      } else if (layoutParams.onScreen == 1.0F) {
        dispatchOnDrawerOpened(paramView);
      } 
    } 
    if (paramInt1 != this.mDrawerState) {
      this.mDrawerState = paramInt1;
      if (this.mListener != null)
        this.mListener.onDrawerStateChanged(paramInt1); 
    } 
  }
  
  class AccessibilityDelegate extends AccessibilityDelegateCompat {
    private final Rect mTmpRect = new Rect();
    
    private void addChildrenForAccessibility(AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat, ViewGroup param1ViewGroup) {
      int i = param1ViewGroup.getChildCount();
      for (byte b = 0; b < i; b++) {
        View view = param1ViewGroup.getChildAt(b);
        if (DrawerLayout.includeChildForAccessibilitiy(view))
          param1AccessibilityNodeInfoCompat.addChild(view); 
      } 
    }
    
    private void copyNodeInfoNoChildren(AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat1, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat2) {
      Rect rect = this.mTmpRect;
      param1AccessibilityNodeInfoCompat2.getBoundsInParent(rect);
      param1AccessibilityNodeInfoCompat1.setBoundsInParent(rect);
      param1AccessibilityNodeInfoCompat2.getBoundsInScreen(rect);
      param1AccessibilityNodeInfoCompat1.setBoundsInScreen(rect);
      param1AccessibilityNodeInfoCompat1.setVisibleToUser(param1AccessibilityNodeInfoCompat2.isVisibleToUser());
      param1AccessibilityNodeInfoCompat1.setPackageName(param1AccessibilityNodeInfoCompat2.getPackageName());
      param1AccessibilityNodeInfoCompat1.setClassName(param1AccessibilityNodeInfoCompat2.getClassName());
      param1AccessibilityNodeInfoCompat1.setContentDescription(param1AccessibilityNodeInfoCompat2.getContentDescription());
      param1AccessibilityNodeInfoCompat1.setEnabled(param1AccessibilityNodeInfoCompat2.isEnabled());
      param1AccessibilityNodeInfoCompat1.setClickable(param1AccessibilityNodeInfoCompat2.isClickable());
      param1AccessibilityNodeInfoCompat1.setFocusable(param1AccessibilityNodeInfoCompat2.isFocusable());
      param1AccessibilityNodeInfoCompat1.setFocused(param1AccessibilityNodeInfoCompat2.isFocused());
      param1AccessibilityNodeInfoCompat1.setAccessibilityFocused(param1AccessibilityNodeInfoCompat2.isAccessibilityFocused());
      param1AccessibilityNodeInfoCompat1.setSelected(param1AccessibilityNodeInfoCompat2.isSelected());
      param1AccessibilityNodeInfoCompat1.setLongClickable(param1AccessibilityNodeInfoCompat2.isLongClickable());
      param1AccessibilityNodeInfoCompat1.addAction(param1AccessibilityNodeInfoCompat2.getActions());
    }
    
    public boolean dispatchPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      List<CharSequence> list;
      CharSequence charSequence;
      if (param1AccessibilityEvent.getEventType() == 32) {
        list = param1AccessibilityEvent.getText();
        View view = DrawerLayout.this.findVisibleDrawer();
        if (view != null) {
          int i = DrawerLayout.this.getDrawerViewAbsoluteGravity(view);
          charSequence = DrawerLayout.this.getDrawerTitle(i);
          if (charSequence != null)
            list.add(charSequence); 
        } 
        return true;
      } 
      return super.dispatchPopulateAccessibilityEvent((View)list, (AccessibilityEvent)charSequence);
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(DrawerLayout.class.getName());
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      AccessibilityNodeInfoCompat accessibilityNodeInfoCompat = AccessibilityNodeInfoCompat.obtain(param1AccessibilityNodeInfoCompat);
      super.onInitializeAccessibilityNodeInfo(param1View, accessibilityNodeInfoCompat);
      param1AccessibilityNodeInfoCompat.setClassName(DrawerLayout.class.getName());
      param1AccessibilityNodeInfoCompat.setSource(param1View);
      ViewParent viewParent = ViewCompat.getParentForAccessibility(param1View);
      if (viewParent instanceof View)
        param1AccessibilityNodeInfoCompat.setParent((View)viewParent); 
      copyNodeInfoNoChildren(param1AccessibilityNodeInfoCompat, accessibilityNodeInfoCompat);
      accessibilityNodeInfoCompat.recycle();
      addChildrenForAccessibility(param1AccessibilityNodeInfoCompat, (ViewGroup)param1View);
    }
    
    public boolean onRequestSendAccessibilityEvent(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return DrawerLayout.includeChildForAccessibilitiy(param1View) ? super.onRequestSendAccessibilityEvent(param1ViewGroup, param1View, param1AccessibilityEvent) : false;
    }
  }
  
  final class ChildAccessibilityDelegate extends AccessibilityDelegateCompat {
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      super.onInitializeAccessibilityNodeInfo(param1View, param1AccessibilityNodeInfoCompat);
      if (!DrawerLayout.includeChildForAccessibilitiy(param1View))
        param1AccessibilityNodeInfoCompat.setParent(null); 
    }
  }
  
  public static interface DrawerListener {
    void onDrawerClosed(View param1View);
    
    void onDrawerOpened(View param1View);
    
    void onDrawerSlide(View param1View, float param1Float);
    
    void onDrawerStateChanged(int param1Int);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @IntDef({3L, 5L, 8388611L, 8388613L})
  private static @interface EdgeGravity {}
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    public int gravity = 0;
    
    boolean isPeeking;
    
    boolean knownOpen;
    
    float onScreen;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(int param1Int1, int param1Int2, int param1Int3) {
      this(param1Int1, param1Int2);
      this.gravity = param1Int3;
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, DrawerLayout.LAYOUT_ATTRS);
      this.gravity = typedArray.getInt(0, 0);
      typedArray.recycle();
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.gravity = param1LayoutParams.gravity;
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @IntDef({0L, 1L, 2L})
  private static @interface LockMode {}
  
  protected static class SavedState extends View.BaseSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public DrawerLayout.SavedState createFromParcel(Parcel param2Parcel) {
          return new DrawerLayout.SavedState(param2Parcel);
        }
        
        public DrawerLayout.SavedState[] newArray(int param2Int) {
          return new DrawerLayout.SavedState[param2Int];
        }
      };
    
    int lockModeLeft = 0;
    
    int lockModeRight = 0;
    
    int openDrawerGravity = 0;
    
    public SavedState(Parcel param1Parcel) {
      super(param1Parcel);
      this.openDrawerGravity = param1Parcel.readInt();
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.openDrawerGravity);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public DrawerLayout.SavedState createFromParcel(Parcel param1Parcel) {
      return new DrawerLayout.SavedState(param1Parcel);
    }
    
    public DrawerLayout.SavedState[] newArray(int param1Int) {
      return new DrawerLayout.SavedState[param1Int];
    }
  }
  
  public static abstract class SimpleDrawerListener implements DrawerListener {
    public void onDrawerClosed(View param1View) {}
    
    public void onDrawerOpened(View param1View) {}
    
    public void onDrawerSlide(View param1View, float param1Float) {}
    
    public void onDrawerStateChanged(int param1Int) {}
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @IntDef({0L, 1L, 2L})
  private static @interface State {}
  
  private class ViewDragCallback extends ViewDragHelper.Callback {
    private final int mAbsGravity;
    
    private ViewDragHelper mDragger;
    
    private final Runnable mPeekRunnable = new Runnable() {
        public void run() {
          DrawerLayout.ViewDragCallback.this.peekDrawer();
        }
      };
    
    public ViewDragCallback(int param1Int) {
      this.mAbsGravity = param1Int;
    }
    
    private void closeOtherDrawer() {
      byte b = 3;
      if (this.mAbsGravity == 3)
        b = 5; 
      View view = DrawerLayout.this.findDrawerWithGravity(b);
      if (view != null)
        DrawerLayout.this.closeDrawer(view); 
    }
    
    private void peekDrawer() {
      boolean bool;
      View view;
      int i = 0;
      int j = this.mDragger.getEdgeSize();
      if (this.mAbsGravity == 3) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        view = DrawerLayout.this.findDrawerWithGravity(3);
        if (view != null)
          i = -view.getWidth(); 
        i += j;
      } else {
        view = DrawerLayout.this.findDrawerWithGravity(5);
        i = DrawerLayout.this.getWidth() - j;
      } 
      if (view != null && ((bool && view.getLeft() < i) || (!bool && view.getLeft() > i)) && DrawerLayout.this.getDrawerLockMode(view) == 0) {
        DrawerLayout.LayoutParams layoutParams = (DrawerLayout.LayoutParams)view.getLayoutParams();
        this.mDragger.smoothSlideViewTo(view, i, view.getTop());
        layoutParams.isPeeking = true;
        DrawerLayout.this.invalidate();
        closeOtherDrawer();
        DrawerLayout.this.cancelChildViewTouch();
      } 
    }
    
    public int clampViewPositionHorizontal(View param1View, int param1Int1, int param1Int2) {
      if (DrawerLayout.this.checkDrawerViewAbsoluteGravity(param1View, 3))
        return Math.max(-param1View.getWidth(), Math.min(param1Int1, 0)); 
      param1Int2 = DrawerLayout.this.getWidth();
      return Math.max(param1Int2 - param1View.getWidth(), Math.min(param1Int1, param1Int2));
    }
    
    public int clampViewPositionVertical(View param1View, int param1Int1, int param1Int2) {
      return param1View.getTop();
    }
    
    public int getViewHorizontalDragRange(View param1View) {
      return param1View.getWidth();
    }
    
    public void onEdgeDragStarted(int param1Int1, int param1Int2) {
      View view;
      if ((param1Int1 & 0x1) == 1) {
        view = DrawerLayout.this.findDrawerWithGravity(3);
      } else {
        view = DrawerLayout.this.findDrawerWithGravity(5);
      } 
      if (view != null && DrawerLayout.this.getDrawerLockMode(view) == 0)
        this.mDragger.captureChildView(view, param1Int2); 
    }
    
    public boolean onEdgeLock(int param1Int) {
      return false;
    }
    
    public void onEdgeTouched(int param1Int1, int param1Int2) {
      DrawerLayout.this.postDelayed(this.mPeekRunnable, 160L);
    }
    
    public void onViewCaptured(View param1View, int param1Int) {
      ((DrawerLayout.LayoutParams)param1View.getLayoutParams()).isPeeking = false;
      closeOtherDrawer();
    }
    
    public void onViewDragStateChanged(int param1Int) {
      DrawerLayout.this.updateDrawerState(this.mAbsGravity, param1Int, this.mDragger.getCapturedView());
    }
    
    public void onViewPositionChanged(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      float f;
      param1Int2 = param1View.getWidth();
      if (DrawerLayout.this.checkDrawerViewAbsoluteGravity(param1View, 3)) {
        f = (param1Int2 + param1Int1) / param1Int2;
      } else {
        f = (DrawerLayout.this.getWidth() - param1Int1) / param1Int2;
      } 
      DrawerLayout.this.setDrawerViewOffset(param1View, f);
      if (f == 0.0F) {
        param1Int1 = 4;
      } else {
        param1Int1 = 0;
      } 
      param1View.setVisibility(param1Int1);
      DrawerLayout.this.invalidate();
    }
    
    public void onViewReleased(View param1View, float param1Float1, float param1Float2) {
      int j;
      param1Float2 = DrawerLayout.this.getDrawerViewOffset(param1View);
      int i = param1View.getWidth();
      if (DrawerLayout.this.checkDrawerViewAbsoluteGravity(param1View, 3)) {
        if (param1Float1 > 0.0F || (param1Float1 == 0.0F && param1Float2 > 0.5F)) {
          j = 0;
        } else {
          j = -i;
        } 
      } else {
        j = DrawerLayout.this.getWidth();
        if (param1Float1 < 0.0F || (param1Float1 == 0.0F && param1Float2 > 0.5F))
          j -= i; 
      } 
      this.mDragger.settleCapturedViewAt(j, param1View.getTop());
      DrawerLayout.this.invalidate();
    }
    
    public void removeCallbacks() {
      DrawerLayout.this.removeCallbacks(this.mPeekRunnable);
    }
    
    public void setDragger(ViewDragHelper param1ViewDragHelper) {
      this.mDragger = param1ViewDragHelper;
    }
    
    public boolean tryCaptureView(View param1View, int param1Int) {
      return (DrawerLayout.this.isDrawerView(param1View) && DrawerLayout.this.checkDrawerViewAbsoluteGravity(param1View, this.mAbsGravity) && DrawerLayout.this.getDrawerLockMode(param1View) == 0);
    }
  }
  
  class null implements Runnable {
    public void run() {
      this.this$1.peekDrawer();
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v4/widget/DrawerLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */