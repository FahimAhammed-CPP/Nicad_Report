package android.support.v4.content;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import java.io.File;

public class ContextCompat {
  private static final String DIR_ANDROID = "Android";
  
  private static final String DIR_CACHE = "cache";
  
  private static final String DIR_DATA = "data";
  
  private static final String DIR_FILES = "files";
  
  private static final String DIR_OBB = "obb";
  
  private static File buildPath(File paramFile, String... paramVarArgs) {
    int i = paramVarArgs.length;
    for (byte b = 0; b < i; b++) {
      String str = paramVarArgs[b];
      if (paramFile == null) {
        paramFile = new File(str);
      } else if (str != null) {
        paramFile = new File(paramFile, str);
      } 
    } 
    return paramFile;
  }
  
  public static File[] getExternalCacheDirs(Context paramContext) {
    File file;
    int i = Build.VERSION.SDK_INT;
    if (i >= 19)
      return ContextCompatKitKat.getExternalCacheDirs(paramContext); 
    if (i >= 8) {
      file = ContextCompatFroyo.getExternalCacheDir(paramContext);
    } else {
      file = buildPath(Environment.getExternalStorageDirectory(), new String[] { "Android", "data", file.getPackageName(), "cache" });
    } 
    File[] arrayOfFile = new File[1];
    arrayOfFile[0] = file;
    return arrayOfFile;
  }
  
  public static File[] getExternalFilesDirs(Context paramContext, String paramString) {
    File file;
    int i = Build.VERSION.SDK_INT;
    if (i >= 19)
      return ContextCompatKitKat.getExternalFilesDirs(paramContext, paramString); 
    if (i >= 8) {
      file = ContextCompatFroyo.getExternalFilesDir(paramContext, paramString);
    } else {
      file = buildPath(Environment.getExternalStorageDirectory(), new String[] { "Android", "data", file.getPackageName(), "files", paramString });
    } 
    File[] arrayOfFile = new File[1];
    arrayOfFile[0] = file;
    return arrayOfFile;
  }
  
  public static File[] getObbDirs(Context paramContext) {
    File file;
    int i = Build.VERSION.SDK_INT;
    if (i >= 19)
      return ContextCompatKitKat.getObbDirs(paramContext); 
    if (i >= 11) {
      file = ContextCompatHoneycomb.getObbDir(paramContext);
    } else {
      file = buildPath(Environment.getExternalStorageDirectory(), new String[] { "Android", "obb", file.getPackageName() });
    } 
    File[] arrayOfFile = new File[1];
    arrayOfFile[0] = file;
    return arrayOfFile;
  }
  
  public static boolean startActivities(Context paramContext, Intent[] paramArrayOfIntent) {
    return startActivities(paramContext, paramArrayOfIntent, null);
  }
  
  public static boolean startActivities(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle) {
    null = true;
    int i = Build.VERSION.SDK_INT;
    if (i >= 16) {
      ContextCompatJellybean.startActivities(paramContext, paramArrayOfIntent, paramBundle);
      return null;
    } 
    if (i >= 11) {
      ContextCompatHoneycomb.startActivities(paramContext, paramArrayOfIntent);
      return null;
    } 
    return false;
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v4/content/ContextCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */