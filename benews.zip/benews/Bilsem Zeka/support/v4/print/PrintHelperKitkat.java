package android.support.v4.print;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.print.pdf.PrintedPdfDocument;
import android.util.Log;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

class PrintHelperKitkat {
  public static final int COLOR_MODE_COLOR = 2;
  
  public static final int COLOR_MODE_MONOCHROME = 1;
  
  private static final String LOG_TAG = "PrintHelperKitkat";
  
  private static final int MAX_PRINT_SIZE = 3500;
  
  public static final int ORIENTATION_LANDSCAPE = 1;
  
  public static final int ORIENTATION_PORTRAIT = 2;
  
  public static final int SCALE_MODE_FILL = 2;
  
  public static final int SCALE_MODE_FIT = 1;
  
  int mColorMode = 2;
  
  final Context mContext;
  
  BitmapFactory.Options mDecodeOptions = null;
  
  private final Object mLock = new Object();
  
  int mOrientation = 1;
  
  int mScaleMode = 2;
  
  PrintHelperKitkat(Context paramContext) {
    this.mContext = paramContext;
  }
  
  private Matrix getMatrix(int paramInt1, int paramInt2, RectF paramRectF, int paramInt3) {
    Matrix matrix = new Matrix();
    float f = paramRectF.width() / paramInt1;
    if (paramInt3 == 2) {
      f = Math.max(f, paramRectF.height() / paramInt2);
      matrix.postScale(f, f);
      matrix.postTranslate((paramRectF.width() - paramInt1 * f) / 2.0F, (paramRectF.height() - paramInt2 * f) / 2.0F);
      return matrix;
    } 
    f = Math.min(f, paramRectF.height() / paramInt2);
    matrix.postScale(f, f);
    matrix.postTranslate((paramRectF.width() - paramInt1 * f) / 2.0F, (paramRectF.height() - paramInt2 * f) / 2.0F);
    return matrix;
  }
  
  private Bitmap loadBitmap(Uri paramUri, BitmapFactory.Options paramOptions) throws FileNotFoundException {
    if (paramUri == null || this.mContext == null)
      throw new IllegalArgumentException("bad argument to loadBitmap"); 
    InputStream inputStream = null;
    try {
      InputStream inputStream1 = this.mContext.getContentResolver().openInputStream(paramUri);
      inputStream = inputStream1;
      return BitmapFactory.decodeStream(inputStream1, null, paramOptions);
    } finally {
      if (inputStream != null)
        try {
          inputStream.close();
        } catch (IOException iOException) {
          Log.w("PrintHelperKitkat", "close fail ", iOException);
        }  
    } 
  }
  
  private Bitmap loadConstrainedBitmap(Uri paramUri, int paramInt) throws FileNotFoundException {
    BitmapFactory.Options options1 = null;
    if (paramInt <= 0 || paramUri == null || this.mContext == null)
      throw new IllegalArgumentException("bad argument to getScaledBitmap"); 
    BitmapFactory.Options options2 = new BitmapFactory.Options();
    options2.inJustDecodeBounds = true;
    loadBitmap(paramUri, options2);
    int i = options2.outWidth;
    int j = options2.outHeight;
    options2 = options1;
    if (i > 0) {
      if (j <= 0)
        return (Bitmap)options1; 
    } else {
      return (Bitmap)options2;
    } 
    int k = Math.max(i, j);
    int m;
    for (m = 1; k > paramInt; m <<= 1)
      k >>>= 1; 
    options2 = options1;
    if (m > 0) {
      options2 = options1;
      if (Math.min(i, j) / m > 0)
        synchronized (this.mLock) {
          options1 = new BitmapFactory.Options();
          this();
          this.mDecodeOptions = options1;
          this.mDecodeOptions.inMutable = true;
          this.mDecodeOptions.inSampleSize = m;
          options1 = this.mDecodeOptions;
          try {
            null = loadBitmap(paramUri, options1);
            Object object = this.mLock;
          } finally {
            null = null;
            Object object = this.mLock;
          } 
        }  
    } 
    return (Bitmap)options2;
  }
  
  public int getColorMode() {
    return this.mColorMode;
  }
  
  public int getOrientation() {
    return this.mOrientation;
  }
  
  public int getScaleMode() {
    return this.mScaleMode;
  }
  
  public void printBitmap(final String jobName, final Bitmap bitmap) {
    if (bitmap != null) {
      final int fittingMode = this.mScaleMode;
      PrintManager printManager = (PrintManager)this.mContext.getSystemService("print");
      PrintAttributes.MediaSize mediaSize = PrintAttributes.MediaSize.UNKNOWN_PORTRAIT;
      if (bitmap.getWidth() > bitmap.getHeight())
        mediaSize = PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE; 
      PrintAttributes printAttributes = (new PrintAttributes.Builder()).setMediaSize(mediaSize).setColorMode(this.mColorMode).build();
      printManager.print(jobName, new PrintDocumentAdapter() {
            private PrintAttributes mAttributes;
            
            public void onLayout(PrintAttributes param1PrintAttributes1, PrintAttributes param1PrintAttributes2, CancellationSignal param1CancellationSignal, PrintDocumentAdapter.LayoutResultCallback param1LayoutResultCallback, Bundle param1Bundle) {
              boolean bool = true;
              this.mAttributes = param1PrintAttributes2;
              PrintDocumentInfo printDocumentInfo = (new PrintDocumentInfo.Builder(jobName)).setContentType(1).setPageCount(1).build();
              if (param1PrintAttributes2.equals(param1PrintAttributes1))
                bool = false; 
              param1LayoutResultCallback.onLayoutFinished(printDocumentInfo, bool);
            }
            
            public void onWrite(PageRange[] param1ArrayOfPageRange, ParcelFileDescriptor param1ParcelFileDescriptor, CancellationSignal param1CancellationSignal, PrintDocumentAdapter.WriteResultCallback param1WriteResultCallback) {
              PrintedPdfDocument printedPdfDocument = new PrintedPdfDocument(PrintHelperKitkat.this.mContext, this.mAttributes);
              try {
                PdfDocument.Page page = printedPdfDocument.startPage(1);
                RectF rectF = new RectF();
                this(page.getInfo().getContentRect());
                Matrix matrix = PrintHelperKitkat.this.getMatrix(bitmap.getWidth(), bitmap.getHeight(), rectF, fittingMode);
                page.getCanvas().drawBitmap(bitmap, matrix, null);
                printedPdfDocument.finishPage(page);
                try {
                  FileOutputStream fileOutputStream = new FileOutputStream();
                  this(param1ParcelFileDescriptor.getFileDescriptor());
                  printedPdfDocument.writeTo(fileOutputStream);
                  param1WriteResultCallback.onWriteFinished(new PageRange[] { PageRange.ALL_PAGES });
                } catch (IOException iOException1) {}
                return;
              } finally {
                if (iOException != null)
                  iOException.close(); 
                if (param1ParcelFileDescriptor != null)
                  try {
                    param1ParcelFileDescriptor.close();
                  } catch (IOException iOException1) {} 
              } 
            }
          }printAttributes);
    } 
  }
  
  public void printBitmap(final String jobName, final Uri imageFile) throws FileNotFoundException {
    PrintDocumentAdapter printDocumentAdapter = new PrintDocumentAdapter() {
        AsyncTask<Uri, Boolean, Bitmap> loadBitmap;
        
        private PrintAttributes mAttributes;
        
        Bitmap mBitmap = null;
        
        private void cancelLoad() {
          synchronized (PrintHelperKitkat.this.mLock) {
            if (PrintHelperKitkat.this.mDecodeOptions != null) {
              PrintHelperKitkat.this.mDecodeOptions.requestCancelDecode();
              PrintHelperKitkat.this.mDecodeOptions = null;
            } 
            return;
          } 
        }
        
        public void onFinish() {
          super.onFinish();
          cancelLoad();
          this.loadBitmap.cancel(true);
        }
        
        public void onLayout(final PrintAttributes oldPrintAttributes, final PrintAttributes newPrintAttributes, CancellationSignal param1CancellationSignal, final PrintDocumentAdapter.LayoutResultCallback layoutResultCallback, Bundle param1Bundle) {
          final PrintDocumentInfo cancellationSignal;
          boolean bool = true;
          if (param1CancellationSignal.isCanceled()) {
            layoutResultCallback.onLayoutCancelled();
            this.mAttributes = newPrintAttributes;
            return;
          } 
          if (this.mBitmap != null) {
            printDocumentInfo = (new PrintDocumentInfo.Builder(jobName)).setContentType(1).setPageCount(1).build();
            if (newPrintAttributes.equals(oldPrintAttributes))
              bool = false; 
            layoutResultCallback.onLayoutFinished(printDocumentInfo, bool);
            return;
          } 
          this.loadBitmap = new AsyncTask<Uri, Boolean, Bitmap>() {
              protected Bitmap doInBackground(Uri... param2VarArgs) {
                try {
                  Bitmap bitmap = PrintHelperKitkat.this.loadConstrainedBitmap(imageFile, 3500);
                } catch (FileNotFoundException fileNotFoundException) {
                  fileNotFoundException = null;
                } 
                return (Bitmap)fileNotFoundException;
              }
              
              protected void onCancelled(Bitmap param2Bitmap) {
                layoutResultCallback.onLayoutCancelled();
              }
              
              protected void onPostExecute(Bitmap param2Bitmap) {
                boolean bool = true;
                super.onPostExecute(param2Bitmap);
                PrintHelperKitkat.null.this.mBitmap = param2Bitmap;
                if (param2Bitmap != null) {
                  PrintDocumentInfo printDocumentInfo = (new PrintDocumentInfo.Builder(jobName)).setContentType(1).setPageCount(1).build();
                  if (newPrintAttributes.equals(oldPrintAttributes))
                    bool = false; 
                  layoutResultCallback.onLayoutFinished(printDocumentInfo, bool);
                  return;
                } 
                layoutResultCallback.onLayoutFailed(null);
              }
              
              protected void onPreExecute() {
                cancellationSignal.setOnCancelListener(new CancellationSignal.OnCancelListener() {
                      public void onCancel() {
                        PrintHelperKitkat.null.this.cancelLoad();
                        PrintHelperKitkat.null.null.this.cancel(false);
                      }
                    });
              }
            };
          this.loadBitmap.execute((Object[])new Uri[0]);
          this.mAttributes = newPrintAttributes;
        }
        
        public void onWrite(PageRange[] param1ArrayOfPageRange, ParcelFileDescriptor param1ParcelFileDescriptor, CancellationSignal param1CancellationSignal, PrintDocumentAdapter.WriteResultCallback param1WriteResultCallback) {
          PrintedPdfDocument printedPdfDocument = new PrintedPdfDocument(PrintHelperKitkat.this.mContext, this.mAttributes);
          try {
            PdfDocument.Page page = printedPdfDocument.startPage(1);
            RectF rectF = new RectF();
            this(page.getInfo().getContentRect());
            Matrix matrix = PrintHelperKitkat.this.getMatrix(this.mBitmap.getWidth(), this.mBitmap.getHeight(), rectF, fittingMode);
            page.getCanvas().drawBitmap(this.mBitmap, matrix, null);
            printedPdfDocument.finishPage(page);
            try {
              FileOutputStream fileOutputStream = new FileOutputStream();
              this(param1ParcelFileDescriptor.getFileDescriptor());
              printedPdfDocument.writeTo(fileOutputStream);
              param1WriteResultCallback.onWriteFinished(new PageRange[] { PageRange.ALL_PAGES });
            } catch (IOException iOException1) {}
            return;
          } finally {
            if (iOException != null)
              iOException.close(); 
            if (param1ParcelFileDescriptor != null)
              try {
                param1ParcelFileDescriptor.close();
              } catch (IOException iOException1) {} 
          } 
        }
      };
    PrintManager printManager = (PrintManager)this.mContext.getSystemService("print");
    PrintAttributes.Builder builder = new PrintAttributes.Builder();
    builder.setColorMode(this.mColorMode);
    if (this.mOrientation == 1) {
      builder.setMediaSize(PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE);
    } else if (this.mOrientation == 2) {
      builder.setMediaSize(PrintAttributes.MediaSize.UNKNOWN_PORTRAIT);
    } 
    printManager.print(jobName, printDocumentAdapter, builder.build());
  }
  
  public void setColorMode(int paramInt) {
    this.mColorMode = paramInt;
  }
  
  public void setOrientation(int paramInt) {
    this.mOrientation = paramInt;
  }
  
  public void setScaleMode(int paramInt) {
    this.mScaleMode = paramInt;
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v4/print/PrintHelperKitkat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */