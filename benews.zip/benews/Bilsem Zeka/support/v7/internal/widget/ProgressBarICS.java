package android.support.v7.internal.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.Transformation;

public class ProgressBarICS extends View {
  private static final int ANIMATION_RESOLUTION = 200;
  
  private static final int MAX_LEVEL = 10000;
  
  private static final int[] android_R_styleable_ProgressBar = new int[] { 
      16843062, 16843063, 16843064, 16843065, 16843066, 16843067, 16843068, 16843069, 16843070, 16843071, 
      16843039, 16843072, 16843040, 16843073 };
  
  private AlphaAnimation mAnimation;
  
  private int mBehavior;
  
  private Drawable mCurrentDrawable;
  
  private int mDuration;
  
  private boolean mInDrawing;
  
  private boolean mIndeterminate;
  
  private Drawable mIndeterminateDrawable;
  
  private Interpolator mInterpolator;
  
  private long mLastDrawTime;
  
  private int mMax;
  
  int mMaxHeight;
  
  int mMaxWidth;
  
  int mMinHeight;
  
  int mMinWidth;
  
  private boolean mNoInvalidate;
  
  private boolean mOnlyIndeterminate;
  
  private int mProgress;
  
  private Drawable mProgressDrawable;
  
  private RefreshProgressRunnable mRefreshProgressRunnable;
  
  Bitmap mSampleTile;
  
  private int mSecondaryProgress;
  
  private boolean mShouldStartAnimationDrawable;
  
  private Transformation mTransformation;
  
  private long mUiThreadId = Thread.currentThread().getId();
  
  public ProgressBarICS(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1);
    initProgressBar();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, android_R_styleable_ProgressBar, paramInt1, paramInt2);
    this.mNoInvalidate = true;
    setMax(typedArray.getInt(0, this.mMax));
    setProgress(typedArray.getInt(1, this.mProgress));
    setSecondaryProgress(typedArray.getInt(2, this.mSecondaryProgress));
    boolean bool1 = typedArray.getBoolean(3, this.mIndeterminate);
    this.mOnlyIndeterminate = typedArray.getBoolean(4, this.mOnlyIndeterminate);
    Drawable drawable = typedArray.getDrawable(5);
    if (drawable != null)
      setIndeterminateDrawable(tileifyIndeterminate(drawable)); 
    drawable = typedArray.getDrawable(6);
    if (drawable != null)
      setProgressDrawable(tileify(drawable, false)); 
    this.mDuration = typedArray.getInt(7, this.mDuration);
    this.mBehavior = typedArray.getInt(8, this.mBehavior);
    this.mMinWidth = typedArray.getDimensionPixelSize(9, this.mMinWidth);
    this.mMaxWidth = typedArray.getDimensionPixelSize(10, this.mMaxWidth);
    this.mMinHeight = typedArray.getDimensionPixelSize(11, this.mMinHeight);
    this.mMaxHeight = typedArray.getDimensionPixelSize(12, this.mMaxHeight);
    paramInt1 = typedArray.getResourceId(13, 17432587);
    if (paramInt1 > 0)
      setInterpolator(paramContext, paramInt1); 
    typedArray.recycle();
    this.mNoInvalidate = false;
    if (this.mOnlyIndeterminate || bool1)
      bool = true; 
    setIndeterminate(bool);
  }
  
  private void doRefreshProgress(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mMax : I
    //   6: ifle -> 74
    //   9: iload_2
    //   10: i2f
    //   11: aload_0
    //   12: getfield mMax : I
    //   15: i2f
    //   16: fdiv
    //   17: fstore #5
    //   19: aload_0
    //   20: getfield mCurrentDrawable : Landroid/graphics/drawable/Drawable;
    //   23: astore #6
    //   25: aload #6
    //   27: ifnull -> 87
    //   30: aconst_null
    //   31: astore #7
    //   33: aload #6
    //   35: instanceof android/graphics/drawable/LayerDrawable
    //   38: ifeq -> 52
    //   41: aload #6
    //   43: checkcast android/graphics/drawable/LayerDrawable
    //   46: iload_1
    //   47: invokevirtual findDrawableByLayerId : (I)Landroid/graphics/drawable/Drawable;
    //   50: astore #7
    //   52: ldc 10000.0
    //   54: fload #5
    //   56: fmul
    //   57: f2i
    //   58: istore_1
    //   59: aload #7
    //   61: ifnull -> 80
    //   64: aload #7
    //   66: iload_1
    //   67: invokevirtual setLevel : (I)Z
    //   70: pop
    //   71: aload_0
    //   72: monitorexit
    //   73: return
    //   74: fconst_0
    //   75: fstore #5
    //   77: goto -> 19
    //   80: aload #6
    //   82: astore #7
    //   84: goto -> 64
    //   87: aload_0
    //   88: invokevirtual invalidate : ()V
    //   91: goto -> 71
    //   94: astore #7
    //   96: aload_0
    //   97: monitorexit
    //   98: aload #7
    //   100: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	94	finally
    //   19	25	94	finally
    //   33	52	94	finally
    //   64	71	94	finally
    //   87	91	94	finally
  }
  
  private void initProgressBar() {
    this.mMax = 100;
    this.mProgress = 0;
    this.mSecondaryProgress = 0;
    this.mIndeterminate = false;
    this.mOnlyIndeterminate = false;
    this.mDuration = 4000;
    this.mBehavior = 1;
    this.mMinWidth = 24;
    this.mMaxWidth = 48;
    this.mMinHeight = 24;
    this.mMaxHeight = 48;
  }
  
  private void refreshProgress(int paramInt1, int paramInt2, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mUiThreadId : J
    //   6: invokestatic currentThread : ()Ljava/lang/Thread;
    //   9: invokevirtual getId : ()J
    //   12: lcmp
    //   13: ifne -> 27
    //   16: aload_0
    //   17: iload_1
    //   18: iload_2
    //   19: iload_3
    //   20: iconst_1
    //   21: invokespecial doRefreshProgress : (IIZZ)V
    //   24: aload_0
    //   25: monitorexit
    //   26: return
    //   27: aload_0
    //   28: getfield mRefreshProgressRunnable : Landroid/support/v7/internal/widget/ProgressBarICS$RefreshProgressRunnable;
    //   31: ifnull -> 70
    //   34: aload_0
    //   35: getfield mRefreshProgressRunnable : Landroid/support/v7/internal/widget/ProgressBarICS$RefreshProgressRunnable;
    //   38: astore #4
    //   40: aload_0
    //   41: aconst_null
    //   42: putfield mRefreshProgressRunnable : Landroid/support/v7/internal/widget/ProgressBarICS$RefreshProgressRunnable;
    //   45: aload #4
    //   47: iload_1
    //   48: iload_2
    //   49: iload_3
    //   50: invokevirtual setup : (IIZ)V
    //   53: aload_0
    //   54: aload #4
    //   56: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   59: pop
    //   60: goto -> 24
    //   63: astore #4
    //   65: aload_0
    //   66: monitorexit
    //   67: aload #4
    //   69: athrow
    //   70: new android/support/v7/internal/widget/ProgressBarICS$RefreshProgressRunnable
    //   73: dup
    //   74: aload_0
    //   75: iload_1
    //   76: iload_2
    //   77: iload_3
    //   78: invokespecial <init> : (Landroid/support/v7/internal/widget/ProgressBarICS;IIZ)V
    //   81: astore #4
    //   83: goto -> 53
    // Exception table:
    //   from	to	target	type
    //   2	24	63	finally
    //   27	53	63	finally
    //   53	60	63	finally
    //   70	83	63	finally
  }
  
  private Drawable tileify(Drawable paramDrawable, boolean paramBoolean) {
    LayerDrawable layerDrawable;
    ClipDrawable clipDrawable;
    if (paramDrawable instanceof LayerDrawable) {
      LayerDrawable layerDrawable1 = (LayerDrawable)paramDrawable;
      int i = layerDrawable1.getNumberOfLayers();
      Drawable[] arrayOfDrawable = new Drawable[i];
      byte b;
      for (b = 0; b < i; b++) {
        int j = layerDrawable1.getId(b);
        Drawable drawable = layerDrawable1.getDrawable(b);
        if (j == 16908301 || j == 16908303) {
          paramBoolean = true;
        } else {
          paramBoolean = false;
        } 
        arrayOfDrawable[b] = tileify(drawable, paramBoolean);
      } 
      LayerDrawable layerDrawable2 = new LayerDrawable(arrayOfDrawable);
      b = 0;
      while (true) {
        layerDrawable = layerDrawable2;
        if (b < i) {
          layerDrawable2.setId(b, layerDrawable1.getId(b));
          b++;
          continue;
        } 
        break;
      } 
    } else if (layerDrawable instanceof BitmapDrawable) {
      Bitmap bitmap = ((BitmapDrawable)layerDrawable).getBitmap();
      if (this.mSampleTile == null)
        this.mSampleTile = bitmap; 
      ShapeDrawable shapeDrawable2 = new ShapeDrawable(getDrawableShape());
      BitmapShader bitmapShader = new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP);
      shapeDrawable2.getPaint().setShader((Shader)bitmapShader);
      ShapeDrawable shapeDrawable1 = shapeDrawable2;
      if (paramBoolean)
        clipDrawable = new ClipDrawable((Drawable)shapeDrawable2, 3, 1); 
    } 
    return (Drawable)clipDrawable;
  }
  
  private Drawable tileifyIndeterminate(Drawable paramDrawable) {
    AnimationDrawable animationDrawable;
    Drawable drawable = paramDrawable;
    if (paramDrawable instanceof AnimationDrawable) {
      AnimationDrawable animationDrawable1 = (AnimationDrawable)paramDrawable;
      int i = animationDrawable1.getNumberOfFrames();
      animationDrawable = new AnimationDrawable();
      animationDrawable.setOneShot(animationDrawable1.isOneShot());
      for (byte b = 0; b < i; b++) {
        Drawable drawable1 = tileify(animationDrawable1.getFrame(b), true);
        drawable1.setLevel(10000);
        animationDrawable.addFrame(drawable1, animationDrawable1.getDuration(b));
      } 
      animationDrawable.setLevel(10000);
    } 
    return (Drawable)animationDrawable;
  }
  
  private void updateDrawableBounds(int paramInt1, int paramInt2) {
    int i = paramInt1 - getPaddingRight() - getPaddingLeft();
    int j = paramInt2 - getPaddingBottom() - getPaddingTop();
    byte b1 = 0;
    byte b2 = 0;
    int k = j;
    int m = i;
    if (this.mIndeterminateDrawable != null) {
      k = j;
      int n = b2;
      m = i;
      int i1 = b1;
      if (this.mOnlyIndeterminate) {
        k = j;
        n = b2;
        m = i;
        i1 = b1;
        if (!(this.mIndeterminateDrawable instanceof AnimationDrawable)) {
          m = this.mIndeterminateDrawable.getIntrinsicWidth();
          k = this.mIndeterminateDrawable.getIntrinsicHeight();
          float f1 = m / k;
          float f2 = paramInt1 / paramInt2;
          k = j;
          n = b2;
          m = i;
          i1 = b1;
          if (f1 != f2)
            if (f2 > f1) {
              paramInt2 = (int)(paramInt2 * f1);
              n = (paramInt1 - paramInt2) / 2;
              m = n + paramInt2;
              i1 = b1;
              k = j;
            } else {
              paramInt1 = (int)(paramInt1 * 1.0F / f1);
              i1 = (paramInt2 - paramInt1) / 2;
              k = i1 + paramInt1;
              n = b2;
              m = i;
            }  
        } 
      } 
      this.mIndeterminateDrawable.setBounds(n, i1, m, k);
    } 
    if (this.mProgressDrawable != null)
      this.mProgressDrawable.setBounds(0, 0, m, k); 
  }
  
  private void updateDrawableState() {
    int[] arrayOfInt = getDrawableState();
    if (this.mProgressDrawable != null && this.mProgressDrawable.isStateful())
      this.mProgressDrawable.setState(arrayOfInt); 
    if (this.mIndeterminateDrawable != null && this.mIndeterminateDrawable.isStateful())
      this.mIndeterminateDrawable.setState(arrayOfInt); 
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    updateDrawableState();
  }
  
  Shape getDrawableShape() {
    return (Shape)new RoundRectShape(new float[] { 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F }, null, null);
  }
  
  public Drawable getIndeterminateDrawable() {
    return this.mIndeterminateDrawable;
  }
  
  public Interpolator getInterpolator() {
    return this.mInterpolator;
  }
  
  public int getMax() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mMax : I
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public int getProgress() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mIndeterminate : Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifeq -> 17
    //   11: iconst_0
    //   12: istore_2
    //   13: aload_0
    //   14: monitorexit
    //   15: iload_2
    //   16: ireturn
    //   17: aload_0
    //   18: getfield mProgress : I
    //   21: istore_2
    //   22: goto -> 13
    //   25: astore_3
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_3
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	25	finally
    //   17	22	25	finally
  }
  
  public Drawable getProgressDrawable() {
    return this.mProgressDrawable;
  }
  
  public int getSecondaryProgress() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mIndeterminate : Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifeq -> 17
    //   11: iconst_0
    //   12: istore_2
    //   13: aload_0
    //   14: monitorexit
    //   15: iload_2
    //   16: ireturn
    //   17: aload_0
    //   18: getfield mSecondaryProgress : I
    //   21: istore_2
    //   22: goto -> 13
    //   25: astore_3
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_3
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	25	finally
    //   17	22	25	finally
  }
  
  public final void incrementProgressBy(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: getfield mProgress : I
    //   7: iload_1
    //   8: iadd
    //   9: invokevirtual setProgress : (I)V
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: astore_2
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_2
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	15	finally
  }
  
  public final void incrementSecondaryProgressBy(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_0
    //   4: getfield mSecondaryProgress : I
    //   7: iload_1
    //   8: iadd
    //   9: invokevirtual setSecondaryProgress : (I)V
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: astore_2
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_2
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	15	finally
  }
  
  public void invalidateDrawable(Drawable paramDrawable) {
    Rect rect;
    if (!this.mInDrawing) {
      if (verifyDrawable(paramDrawable)) {
        rect = paramDrawable.getBounds();
        int i = getScrollX() + getPaddingLeft();
        int j = getScrollY() + getPaddingTop();
        invalidate(rect.left + i, rect.top + j, rect.right + i, rect.bottom + j);
        return;
      } 
    } else {
      return;
    } 
    super.invalidateDrawable((Drawable)rect);
  }
  
  public boolean isIndeterminate() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mIndeterminate : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (this.mIndeterminate)
      startAnimation(); 
  }
  
  protected void onDetachedFromWindow() {
    if (this.mIndeterminate)
      stopAnimation(); 
    if (this.mRefreshProgressRunnable != null)
      removeCallbacks(this.mRefreshProgressRunnable); 
    super.onDetachedFromWindow();
  }
  
  protected void onDraw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokespecial onDraw : (Landroid/graphics/Canvas;)V
    //   7: aload_0
    //   8: getfield mCurrentDrawable : Landroid/graphics/drawable/Drawable;
    //   11: astore_2
    //   12: aload_2
    //   13: ifnull -> 156
    //   16: aload_1
    //   17: invokevirtual save : ()I
    //   20: pop
    //   21: aload_1
    //   22: aload_0
    //   23: invokevirtual getPaddingLeft : ()I
    //   26: i2f
    //   27: aload_0
    //   28: invokevirtual getPaddingTop : ()I
    //   31: i2f
    //   32: invokevirtual translate : (FF)V
    //   35: aload_0
    //   36: invokevirtual getDrawingTime : ()J
    //   39: lstore_3
    //   40: aload_0
    //   41: getfield mAnimation : Landroid/view/animation/AlphaAnimation;
    //   44: ifnull -> 119
    //   47: aload_0
    //   48: getfield mAnimation : Landroid/view/animation/AlphaAnimation;
    //   51: lload_3
    //   52: aload_0
    //   53: getfield mTransformation : Landroid/view/animation/Transformation;
    //   56: invokevirtual getTransformation : (JLandroid/view/animation/Transformation;)Z
    //   59: pop
    //   60: aload_0
    //   61: getfield mTransformation : Landroid/view/animation/Transformation;
    //   64: invokevirtual getAlpha : ()F
    //   67: fstore #5
    //   69: aload_0
    //   70: iconst_1
    //   71: putfield mInDrawing : Z
    //   74: aload_2
    //   75: ldc 10000.0
    //   77: fload #5
    //   79: fmul
    //   80: f2i
    //   81: invokevirtual setLevel : (I)Z
    //   84: pop
    //   85: aload_0
    //   86: iconst_0
    //   87: putfield mInDrawing : Z
    //   90: invokestatic uptimeMillis : ()J
    //   93: aload_0
    //   94: getfield mLastDrawTime : J
    //   97: lsub
    //   98: ldc2_w 200
    //   101: lcmp
    //   102: iflt -> 119
    //   105: aload_0
    //   106: invokestatic uptimeMillis : ()J
    //   109: putfield mLastDrawTime : J
    //   112: aload_0
    //   113: ldc2_w 200
    //   116: invokevirtual postInvalidateDelayed : (J)V
    //   119: aload_2
    //   120: aload_1
    //   121: invokevirtual draw : (Landroid/graphics/Canvas;)V
    //   124: aload_1
    //   125: invokevirtual restore : ()V
    //   128: aload_0
    //   129: getfield mShouldStartAnimationDrawable : Z
    //   132: ifeq -> 156
    //   135: aload_2
    //   136: instanceof android/graphics/drawable/Animatable
    //   139: ifeq -> 156
    //   142: aload_2
    //   143: checkcast android/graphics/drawable/Animatable
    //   146: invokeinterface start : ()V
    //   151: aload_0
    //   152: iconst_0
    //   153: putfield mShouldStartAnimationDrawable : Z
    //   156: aload_0
    //   157: monitorexit
    //   158: return
    //   159: astore_1
    //   160: aload_0
    //   161: iconst_0
    //   162: putfield mInDrawing : Z
    //   165: aload_1
    //   166: athrow
    //   167: astore_1
    //   168: aload_0
    //   169: monitorexit
    //   170: aload_1
    //   171: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	167	finally
    //   16	69	167	finally
    //   69	85	159	finally
    //   85	119	167	finally
    //   119	156	167	finally
    //   160	167	167	finally
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mCurrentDrawable : Landroid/graphics/drawable/Drawable;
    //   6: astore_3
    //   7: iconst_0
    //   8: istore #4
    //   10: iconst_0
    //   11: istore #5
    //   13: aload_3
    //   14: ifnull -> 57
    //   17: aload_0
    //   18: getfield mMinWidth : I
    //   21: aload_0
    //   22: getfield mMaxWidth : I
    //   25: aload_3
    //   26: invokevirtual getIntrinsicWidth : ()I
    //   29: invokestatic min : (II)I
    //   32: invokestatic max : (II)I
    //   35: istore #4
    //   37: aload_0
    //   38: getfield mMinHeight : I
    //   41: aload_0
    //   42: getfield mMaxHeight : I
    //   45: aload_3
    //   46: invokevirtual getIntrinsicHeight : ()I
    //   49: invokestatic min : (II)I
    //   52: invokestatic max : (II)I
    //   55: istore #5
    //   57: aload_0
    //   58: invokespecial updateDrawableState : ()V
    //   61: aload_0
    //   62: invokevirtual getPaddingLeft : ()I
    //   65: istore #6
    //   67: aload_0
    //   68: invokevirtual getPaddingRight : ()I
    //   71: istore #7
    //   73: aload_0
    //   74: invokevirtual getPaddingTop : ()I
    //   77: istore #8
    //   79: aload_0
    //   80: invokevirtual getPaddingBottom : ()I
    //   83: istore #9
    //   85: aload_0
    //   86: iload #4
    //   88: iload #6
    //   90: iload #7
    //   92: iadd
    //   93: iadd
    //   94: iload_1
    //   95: invokestatic resolveSize : (II)I
    //   98: iload #5
    //   100: iload #8
    //   102: iload #9
    //   104: iadd
    //   105: iadd
    //   106: iload_2
    //   107: invokestatic resolveSize : (II)I
    //   110: invokevirtual setMeasuredDimension : (II)V
    //   113: aload_0
    //   114: monitorexit
    //   115: return
    //   116: astore_3
    //   117: aload_0
    //   118: monitorexit
    //   119: aload_3
    //   120: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	116	finally
    //   17	57	116	finally
    //   57	113	116	finally
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    setProgress(savedState.progress);
    setSecondaryProgress(savedState.secondaryProgress);
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    savedState.progress = this.mProgress;
    savedState.secondaryProgress = this.mSecondaryProgress;
    return (Parcelable)savedState;
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    updateDrawableBounds(paramInt1, paramInt2);
  }
  
  protected void onVisibilityChanged(View paramView, int paramInt) {
    super.onVisibilityChanged(paramView, paramInt);
    if (this.mIndeterminate) {
      if (paramInt == 8 || paramInt == 4) {
        stopAnimation();
        return;
      } 
    } else {
      return;
    } 
    startAnimation();
  }
  
  public void postInvalidate() {
    if (!this.mNoInvalidate)
      super.postInvalidate(); 
  }
  
  public void setIndeterminate(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mOnlyIndeterminate : Z
    //   6: ifeq -> 16
    //   9: aload_0
    //   10: getfield mIndeterminate : Z
    //   13: ifne -> 45
    //   16: iload_1
    //   17: aload_0
    //   18: getfield mIndeterminate : Z
    //   21: if_icmpeq -> 45
    //   24: aload_0
    //   25: iload_1
    //   26: putfield mIndeterminate : Z
    //   29: iload_1
    //   30: ifeq -> 48
    //   33: aload_0
    //   34: aload_0
    //   35: getfield mIndeterminateDrawable : Landroid/graphics/drawable/Drawable;
    //   38: putfield mCurrentDrawable : Landroid/graphics/drawable/Drawable;
    //   41: aload_0
    //   42: invokevirtual startAnimation : ()V
    //   45: aload_0
    //   46: monitorexit
    //   47: return
    //   48: aload_0
    //   49: aload_0
    //   50: getfield mProgressDrawable : Landroid/graphics/drawable/Drawable;
    //   53: putfield mCurrentDrawable : Landroid/graphics/drawable/Drawable;
    //   56: aload_0
    //   57: invokevirtual stopAnimation : ()V
    //   60: goto -> 45
    //   63: astore_2
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_2
    //   67: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	63	finally
    //   16	29	63	finally
    //   33	45	63	finally
    //   48	60	63	finally
  }
  
  public void setIndeterminateDrawable(Drawable paramDrawable) {
    if (paramDrawable != null)
      paramDrawable.setCallback((Drawable.Callback)this); 
    this.mIndeterminateDrawable = paramDrawable;
    if (this.mIndeterminate) {
      this.mCurrentDrawable = paramDrawable;
      postInvalidate();
    } 
  }
  
  public void setInterpolator(Context paramContext, int paramInt) {
    setInterpolator(AnimationUtils.loadInterpolator(paramContext, paramInt));
  }
  
  public void setInterpolator(Interpolator paramInterpolator) {
    this.mInterpolator = paramInterpolator;
  }
  
  public void setMax(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iload_1
    //   3: istore_2
    //   4: iload_1
    //   5: ifge -> 10
    //   8: iconst_0
    //   9: istore_2
    //   10: iload_2
    //   11: aload_0
    //   12: getfield mMax : I
    //   15: if_icmpeq -> 51
    //   18: aload_0
    //   19: iload_2
    //   20: putfield mMax : I
    //   23: aload_0
    //   24: invokevirtual postInvalidate : ()V
    //   27: aload_0
    //   28: getfield mProgress : I
    //   31: iload_2
    //   32: if_icmple -> 40
    //   35: aload_0
    //   36: iload_2
    //   37: putfield mProgress : I
    //   40: aload_0
    //   41: ldc 16908301
    //   43: aload_0
    //   44: getfield mProgress : I
    //   47: iconst_0
    //   48: invokespecial refreshProgress : (IIZ)V
    //   51: aload_0
    //   52: monitorexit
    //   53: return
    //   54: astore_3
    //   55: aload_0
    //   56: monitorexit
    //   57: aload_3
    //   58: athrow
    // Exception table:
    //   from	to	target	type
    //   10	40	54	finally
    //   40	51	54	finally
  }
  
  public void setProgress(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iload_1
    //   4: iconst_0
    //   5: invokevirtual setProgress : (IZ)V
    //   8: aload_0
    //   9: monitorexit
    //   10: return
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	11	finally
  }
  
  void setProgress(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mIndeterminate : Z
    //   6: istore_3
    //   7: iload_3
    //   8: ifeq -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: iload_1
    //   15: istore #4
    //   17: iload_1
    //   18: ifge -> 24
    //   21: iconst_0
    //   22: istore #4
    //   24: iload #4
    //   26: istore_1
    //   27: iload #4
    //   29: aload_0
    //   30: getfield mMax : I
    //   33: if_icmple -> 41
    //   36: aload_0
    //   37: getfield mMax : I
    //   40: istore_1
    //   41: iload_1
    //   42: aload_0
    //   43: getfield mProgress : I
    //   46: if_icmpeq -> 11
    //   49: aload_0
    //   50: iload_1
    //   51: putfield mProgress : I
    //   54: aload_0
    //   55: ldc 16908301
    //   57: aload_0
    //   58: getfield mProgress : I
    //   61: iload_2
    //   62: invokespecial refreshProgress : (IIZ)V
    //   65: goto -> 11
    //   68: astore #5
    //   70: aload_0
    //   71: monitorexit
    //   72: aload #5
    //   74: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	68	finally
    //   27	41	68	finally
    //   41	65	68	finally
  }
  
  public void setProgressDrawable(Drawable paramDrawable) {
    boolean bool;
    if (this.mProgressDrawable != null && paramDrawable != this.mProgressDrawable) {
      this.mProgressDrawable.setCallback(null);
      bool = true;
    } else {
      bool = false;
    } 
    if (paramDrawable != null) {
      paramDrawable.setCallback((Drawable.Callback)this);
      int i = paramDrawable.getMinimumHeight();
      if (this.mMaxHeight < i) {
        this.mMaxHeight = i;
        requestLayout();
      } 
    } 
    this.mProgressDrawable = paramDrawable;
    if (!this.mIndeterminate) {
      this.mCurrentDrawable = paramDrawable;
      postInvalidate();
    } 
    if (bool) {
      updateDrawableBounds(getWidth(), getHeight());
      updateDrawableState();
      doRefreshProgress(16908301, this.mProgress, false, false);
      doRefreshProgress(16908303, this.mSecondaryProgress, false, false);
    } 
  }
  
  public void setSecondaryProgress(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mIndeterminate : Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifeq -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: iload_1
    //   15: istore_3
    //   16: iload_1
    //   17: ifge -> 22
    //   20: iconst_0
    //   21: istore_3
    //   22: iload_3
    //   23: istore_1
    //   24: iload_3
    //   25: aload_0
    //   26: getfield mMax : I
    //   29: if_icmple -> 37
    //   32: aload_0
    //   33: getfield mMax : I
    //   36: istore_1
    //   37: iload_1
    //   38: aload_0
    //   39: getfield mSecondaryProgress : I
    //   42: if_icmpeq -> 11
    //   45: aload_0
    //   46: iload_1
    //   47: putfield mSecondaryProgress : I
    //   50: aload_0
    //   51: ldc 16908303
    //   53: aload_0
    //   54: getfield mSecondaryProgress : I
    //   57: iconst_0
    //   58: invokespecial refreshProgress : (IIZ)V
    //   61: goto -> 11
    //   64: astore #4
    //   66: aload_0
    //   67: monitorexit
    //   68: aload #4
    //   70: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	64	finally
    //   24	37	64	finally
    //   37	61	64	finally
  }
  
  public void setVisibility(int paramInt) {
    if (getVisibility() != paramInt) {
      super.setVisibility(paramInt);
      if (this.mIndeterminate) {
        if (paramInt == 8 || paramInt == 4) {
          stopAnimation();
          return;
        } 
      } else {
        return;
      } 
    } else {
      return;
    } 
    startAnimation();
  }
  
  void startAnimation() {
    if (getVisibility() == 0) {
      if (this.mIndeterminateDrawable instanceof Animatable) {
        this.mShouldStartAnimationDrawable = true;
        this.mAnimation = null;
      } else {
        if (this.mInterpolator == null)
          this.mInterpolator = (Interpolator)new LinearInterpolator(); 
        this.mTransformation = new Transformation();
        this.mAnimation = new AlphaAnimation(0.0F, 1.0F);
        this.mAnimation.setRepeatMode(this.mBehavior);
        this.mAnimation.setRepeatCount(-1);
        this.mAnimation.setDuration(this.mDuration);
        this.mAnimation.setInterpolator(this.mInterpolator);
        this.mAnimation.setStartTime(-1L);
      } 
      postInvalidate();
    } 
  }
  
  void stopAnimation() {
    this.mAnimation = null;
    this.mTransformation = null;
    if (this.mIndeterminateDrawable instanceof Animatable) {
      ((Animatable)this.mIndeterminateDrawable).stop();
      this.mShouldStartAnimationDrawable = false;
    } 
    postInvalidate();
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable) {
    return (paramDrawable == this.mProgressDrawable || paramDrawable == this.mIndeterminateDrawable || super.verifyDrawable(paramDrawable));
  }
  
  private class RefreshProgressRunnable implements Runnable {
    private boolean mFromUser;
    
    private int mId;
    
    private int mProgress;
    
    RefreshProgressRunnable(int param1Int1, int param1Int2, boolean param1Boolean) {
      this.mId = param1Int1;
      this.mProgress = param1Int2;
      this.mFromUser = param1Boolean;
    }
    
    public void run() {
      ProgressBarICS.this.doRefreshProgress(this.mId, this.mProgress, this.mFromUser, true);
      ProgressBarICS.access$102(ProgressBarICS.this, this);
    }
    
    public void setup(int param1Int1, int param1Int2, boolean param1Boolean) {
      this.mId = param1Int1;
      this.mProgress = param1Int2;
      this.mFromUser = param1Boolean;
    }
  }
  
  static class SavedState extends View.BaseSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public ProgressBarICS.SavedState createFromParcel(Parcel param2Parcel) {
          return new ProgressBarICS.SavedState(param2Parcel);
        }
        
        public ProgressBarICS.SavedState[] newArray(int param2Int) {
          return new ProgressBarICS.SavedState[param2Int];
        }
      };
    
    int progress;
    
    int secondaryProgress;
    
    private SavedState(Parcel param1Parcel) {
      super(param1Parcel);
      this.progress = param1Parcel.readInt();
      this.secondaryProgress = param1Parcel.readInt();
    }
    
    SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.progress);
      param1Parcel.writeInt(this.secondaryProgress);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public ProgressBarICS.SavedState createFromParcel(Parcel param1Parcel) {
      return new ProgressBarICS.SavedState(param1Parcel);
    }
    
    public ProgressBarICS.SavedState[] newArray(int param1Int) {
      return new ProgressBarICS.SavedState[param1Int];
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/widget/ProgressBarICS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */