package android.support.v7.internal.widget;

import android.content.Context;
import android.database.DataSetObserver;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.View;
import android.view.ViewDebug.CapturedViewProperty;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Adapter;
import android.widget.AdapterView;

abstract class AdapterViewICS<T extends Adapter> extends ViewGroup {
  public static final int INVALID_POSITION = -1;
  
  public static final long INVALID_ROW_ID = -9223372036854775808L;
  
  static final int ITEM_VIEW_TYPE_HEADER_OR_FOOTER = -2;
  
  static final int ITEM_VIEW_TYPE_IGNORE = -1;
  
  static final int SYNC_FIRST_POSITION = 1;
  
  static final int SYNC_MAX_DURATION_MILLIS = 100;
  
  static final int SYNC_SELECTED_POSITION = 0;
  
  boolean mBlockLayoutRequests = false;
  
  boolean mDataChanged;
  
  private boolean mDesiredFocusableInTouchModeState;
  
  private boolean mDesiredFocusableState;
  
  private View mEmptyView;
  
  @ExportedProperty(category = "scrolling")
  int mFirstPosition = 0;
  
  boolean mInLayout = false;
  
  @ExportedProperty(category = "list")
  int mItemCount;
  
  private int mLayoutHeight;
  
  boolean mNeedSync = false;
  
  @ExportedProperty(category = "list")
  int mNextSelectedPosition = -1;
  
  long mNextSelectedRowId = Long.MIN_VALUE;
  
  int mOldItemCount;
  
  int mOldSelectedPosition = -1;
  
  long mOldSelectedRowId = Long.MIN_VALUE;
  
  OnItemClickListener mOnItemClickListener;
  
  OnItemLongClickListener mOnItemLongClickListener;
  
  OnItemSelectedListener mOnItemSelectedListener;
  
  @ExportedProperty(category = "list")
  int mSelectedPosition = -1;
  
  long mSelectedRowId = Long.MIN_VALUE;
  
  private SelectionNotifier mSelectionNotifier;
  
  int mSpecificTop;
  
  long mSyncHeight;
  
  int mSyncMode;
  
  int mSyncPosition;
  
  long mSyncRowId = Long.MIN_VALUE;
  
  AdapterViewICS(Context paramContext) {
    super(paramContext);
  }
  
  AdapterViewICS(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  AdapterViewICS(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  private void fireOnSelected() {
    if (this.mOnItemSelectedListener != null) {
      int i = getSelectedItemPosition();
      if (i >= 0) {
        View view = getSelectedView();
        this.mOnItemSelectedListener.onItemSelected(this, view, i, getAdapter().getItemId(i));
        return;
      } 
      this.mOnItemSelectedListener.onNothingSelected(this);
    } 
  }
  
  private void updateEmptyStatus(boolean paramBoolean) {
    if (isInFilterMode())
      paramBoolean = false; 
    if (paramBoolean) {
      if (this.mEmptyView != null) {
        this.mEmptyView.setVisibility(0);
        setVisibility(8);
      } else {
        setVisibility(0);
      } 
      if (this.mDataChanged)
        onLayout(false, getLeft(), getTop(), getRight(), getBottom()); 
      return;
    } 
    if (this.mEmptyView != null)
      this.mEmptyView.setVisibility(8); 
    setVisibility(0);
  }
  
  public void addView(View paramView) {
    throw new UnsupportedOperationException("addView(View) is not supported in AdapterView");
  }
  
  public void addView(View paramView, int paramInt) {
    throw new UnsupportedOperationException("addView(View, int) is not supported in AdapterView");
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    throw new UnsupportedOperationException("addView(View, int, LayoutParams) is not supported in AdapterView");
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    throw new UnsupportedOperationException("addView(View, LayoutParams) is not supported in AdapterView");
  }
  
  protected boolean canAnimate() {
    return (super.canAnimate() && this.mItemCount > 0);
  }
  
  void checkFocus() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: invokevirtual getAdapter : ()Landroid/widget/Adapter;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnull -> 20
    //   11: aload_2
    //   12: invokeinterface getCount : ()I
    //   17: ifne -> 108
    //   20: iconst_1
    //   21: istore_3
    //   22: iload_3
    //   23: ifeq -> 33
    //   26: aload_0
    //   27: invokevirtual isInFilterMode : ()Z
    //   30: ifeq -> 113
    //   33: iconst_1
    //   34: istore_3
    //   35: iload_3
    //   36: ifeq -> 118
    //   39: aload_0
    //   40: getfield mDesiredFocusableInTouchModeState : Z
    //   43: ifeq -> 118
    //   46: iconst_1
    //   47: istore #4
    //   49: aload_0
    //   50: iload #4
    //   52: invokespecial setFocusableInTouchMode : (Z)V
    //   55: iload_3
    //   56: ifeq -> 124
    //   59: aload_0
    //   60: getfield mDesiredFocusableState : Z
    //   63: ifeq -> 124
    //   66: iconst_1
    //   67: istore #4
    //   69: aload_0
    //   70: iload #4
    //   72: invokespecial setFocusable : (Z)V
    //   75: aload_0
    //   76: getfield mEmptyView : Landroid/view/View;
    //   79: ifnull -> 107
    //   82: aload_2
    //   83: ifnull -> 98
    //   86: iload_1
    //   87: istore #4
    //   89: aload_2
    //   90: invokeinterface isEmpty : ()Z
    //   95: ifeq -> 101
    //   98: iconst_1
    //   99: istore #4
    //   101: aload_0
    //   102: iload #4
    //   104: invokespecial updateEmptyStatus : (Z)V
    //   107: return
    //   108: iconst_0
    //   109: istore_3
    //   110: goto -> 22
    //   113: iconst_0
    //   114: istore_3
    //   115: goto -> 35
    //   118: iconst_0
    //   119: istore #4
    //   121: goto -> 49
    //   124: iconst_0
    //   125: istore #4
    //   127: goto -> 69
  }
  
  void checkSelectionChanged() {
    if (this.mSelectedPosition != this.mOldSelectedPosition || this.mSelectedRowId != this.mOldSelectedRowId) {
      selectionChanged();
      this.mOldSelectedPosition = this.mSelectedPosition;
      this.mOldSelectedRowId = this.mSelectedRowId;
    } 
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    View view = getSelectedView();
    return (view != null && view.getVisibility() == 0 && view.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent));
  }
  
  protected void dispatchRestoreInstanceState(SparseArray<Parcelable> paramSparseArray) {
    dispatchThawSelfOnly(paramSparseArray);
  }
  
  protected void dispatchSaveInstanceState(SparseArray<Parcelable> paramSparseArray) {
    dispatchFreezeSelfOnly(paramSparseArray);
  }
  
  int findSyncPosition() {
    int i = this.mItemCount;
    if (i == 0)
      return -1; 
    long l1 = this.mSyncRowId;
    int j = this.mSyncPosition;
    if (l1 == Long.MIN_VALUE)
      return -1; 
    int k = Math.min(i - 1, Math.max(0, j));
    long l2 = SystemClock.uptimeMillis();
    int m = k;
    int n = k;
    boolean bool = false;
    T t = getAdapter();
    if (t == null)
      return -1; 
    while (true) {
      if (SystemClock.uptimeMillis() <= l2 + 100L) {
        j = k;
        if (t.getItemId(k) != l1) {
          boolean bool1;
          if (n == i - 1) {
            j = 1;
          } else {
            j = 0;
          } 
          if (m == 0) {
            bool1 = true;
          } else {
            bool1 = false;
          } 
          if (j == 0 || !bool1) {
            if (bool1 || (bool && j == 0)) {
              k = ++n;
              bool = false;
              continue;
            } 
            if (j != 0 || (!bool && !bool1)) {
              k = --m;
              bool = true;
            } 
            continue;
          } 
        } else {
          return j;
        } 
      } 
      return -1;
    } 
  }
  
  public abstract T getAdapter();
  
  @CapturedViewProperty
  public int getCount() {
    return this.mItemCount;
  }
  
  public View getEmptyView() {
    return this.mEmptyView;
  }
  
  public int getFirstVisiblePosition() {
    return this.mFirstPosition;
  }
  
  public Object getItemAtPosition(int paramInt) {
    null = getAdapter();
    return (null == null || paramInt < 0) ? null : null.getItem(paramInt);
  }
  
  public long getItemIdAtPosition(int paramInt) {
    T t = getAdapter();
    return (t == null || paramInt < 0) ? Long.MIN_VALUE : t.getItemId(paramInt);
  }
  
  public int getLastVisiblePosition() {
    return this.mFirstPosition + getChildCount() - 1;
  }
  
  public final OnItemClickListener getOnItemClickListener() {
    return this.mOnItemClickListener;
  }
  
  public final OnItemLongClickListener getOnItemLongClickListener() {
    return this.mOnItemLongClickListener;
  }
  
  public final OnItemSelectedListener getOnItemSelectedListener() {
    return this.mOnItemSelectedListener;
  }
  
  public int getPositionForView(View paramView) {
    byte b2;
    byte b1 = -1;
    try {
      while (true) {
        View view = (View)paramView.getParent();
        boolean bool = view.equals(this);
        if (!bool) {
          paramView = view;
          continue;
        } 
        int i = getChildCount();
        byte b = 0;
        while (true) {
          b2 = b1;
          if (b < i) {
            if (getChildAt(b).equals(paramView))
              return this.mFirstPosition + b; 
            b++;
            continue;
          } 
          return b2;
        } 
        break;
      } 
    } catch (ClassCastException classCastException) {
      b2 = b1;
    } 
    return b2;
  }
  
  public Object getSelectedItem() {
    null = getAdapter();
    int i = getSelectedItemPosition();
    return (null != null && null.getCount() > 0 && i >= 0) ? null.getItem(i) : null;
  }
  
  @CapturedViewProperty
  public long getSelectedItemId() {
    return this.mNextSelectedRowId;
  }
  
  @CapturedViewProperty
  public int getSelectedItemPosition() {
    return this.mNextSelectedPosition;
  }
  
  public abstract View getSelectedView();
  
  void handleDataChanged() {
    int i = this.mItemCount;
    int j = 0;
    int k = 0;
    if (i > 0) {
      int m = k;
      if (this.mNeedSync) {
        this.mNeedSync = false;
        j = findSyncPosition();
        m = k;
        if (j >= 0) {
          m = k;
          if (lookForSelectablePosition(j, true) == j) {
            setNextSelectedPositionInt(j);
            m = 1;
          } 
        } 
      } 
      j = m;
      if (!m) {
        k = getSelectedItemPosition();
        j = k;
        if (k >= i)
          j = i - 1; 
        k = j;
        if (j < 0)
          k = 0; 
        j = lookForSelectablePosition(k, true);
        i = j;
        if (j < 0)
          i = lookForSelectablePosition(k, false); 
        j = m;
        if (i >= 0) {
          setNextSelectedPositionInt(i);
          checkSelectionChanged();
          j = 1;
        } 
      } 
    } 
    if (j == 0) {
      this.mSelectedPosition = -1;
      this.mSelectedRowId = Long.MIN_VALUE;
      this.mNextSelectedPosition = -1;
      this.mNextSelectedRowId = Long.MIN_VALUE;
      this.mNeedSync = false;
      checkSelectionChanged();
    } 
  }
  
  boolean isInFilterMode() {
    return false;
  }
  
  int lookForSelectablePosition(int paramInt, boolean paramBoolean) {
    return paramInt;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.mSelectionNotifier);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mLayoutHeight = getHeight();
  }
  
  public boolean performItemClick(View paramView, int paramInt, long paramLong) {
    boolean bool = false;
    if (this.mOnItemClickListener != null) {
      playSoundEffect(0);
      if (paramView != null)
        paramView.sendAccessibilityEvent(1); 
      this.mOnItemClickListener.onItemClick(this, paramView, paramInt, paramLong);
      bool = true;
    } 
    return bool;
  }
  
  void rememberSyncState() {
    if (getChildCount() > 0) {
      this.mNeedSync = true;
      this.mSyncHeight = this.mLayoutHeight;
      if (this.mSelectedPosition >= 0) {
        View view1 = getChildAt(this.mSelectedPosition - this.mFirstPosition);
        this.mSyncRowId = this.mNextSelectedRowId;
        this.mSyncPosition = this.mNextSelectedPosition;
        if (view1 != null)
          this.mSpecificTop = view1.getTop(); 
        this.mSyncMode = 0;
        return;
      } 
    } else {
      return;
    } 
    View view = getChildAt(0);
    T t = getAdapter();
    if (this.mFirstPosition >= 0 && this.mFirstPosition < t.getCount()) {
      this.mSyncRowId = t.getItemId(this.mFirstPosition);
    } else {
      this.mSyncRowId = -1L;
    } 
    this.mSyncPosition = this.mFirstPosition;
    if (view != null)
      this.mSpecificTop = view.getTop(); 
    this.mSyncMode = 1;
  }
  
  public void removeAllViews() {
    throw new UnsupportedOperationException("removeAllViews() is not supported in AdapterView");
  }
  
  public void removeView(View paramView) {
    throw new UnsupportedOperationException("removeView(View) is not supported in AdapterView");
  }
  
  public void removeViewAt(int paramInt) {
    throw new UnsupportedOperationException("removeViewAt(int) is not supported in AdapterView");
  }
  
  void selectionChanged() {
    if (this.mOnItemSelectedListener != null)
      if (this.mInLayout || this.mBlockLayoutRequests) {
        if (this.mSelectionNotifier == null)
          this.mSelectionNotifier = new SelectionNotifier(); 
        post(this.mSelectionNotifier);
      } else {
        fireOnSelected();
      }  
    if (this.mSelectedPosition != -1 && isShown() && !isInTouchMode())
      sendAccessibilityEvent(4); 
  }
  
  public abstract void setAdapter(T paramT);
  
  public void setEmptyView(View paramView) {
    boolean bool;
    this.mEmptyView = paramView;
    paramView = (View)getAdapter();
    if (paramView == null || paramView.isEmpty()) {
      bool = true;
    } else {
      bool = false;
    } 
    updateEmptyStatus(bool);
  }
  
  public void setFocusable(boolean paramBoolean) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: aload_0
    //   3: invokevirtual getAdapter : ()Landroid/widget/Adapter;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnull -> 20
    //   11: aload_3
    //   12: invokeinterface getCount : ()I
    //   17: ifne -> 63
    //   20: iconst_1
    //   21: istore #4
    //   23: aload_0
    //   24: iload_1
    //   25: putfield mDesiredFocusableState : Z
    //   28: iload_1
    //   29: ifne -> 37
    //   32: aload_0
    //   33: iconst_0
    //   34: putfield mDesiredFocusableInTouchModeState : Z
    //   37: iload_1
    //   38: ifeq -> 69
    //   41: iload_2
    //   42: istore_1
    //   43: iload #4
    //   45: ifeq -> 57
    //   48: aload_0
    //   49: invokevirtual isInFilterMode : ()Z
    //   52: ifeq -> 69
    //   55: iload_2
    //   56: istore_1
    //   57: aload_0
    //   58: iload_1
    //   59: invokespecial setFocusable : (Z)V
    //   62: return
    //   63: iconst_0
    //   64: istore #4
    //   66: goto -> 23
    //   69: iconst_0
    //   70: istore_1
    //   71: goto -> 57
  }
  
  public void setFocusableInTouchMode(boolean paramBoolean) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: aload_0
    //   3: invokevirtual getAdapter : ()Landroid/widget/Adapter;
    //   6: astore_3
    //   7: aload_3
    //   8: ifnull -> 20
    //   11: aload_3
    //   12: invokeinterface getCount : ()I
    //   17: ifne -> 63
    //   20: iconst_1
    //   21: istore #4
    //   23: aload_0
    //   24: iload_1
    //   25: putfield mDesiredFocusableInTouchModeState : Z
    //   28: iload_1
    //   29: ifeq -> 37
    //   32: aload_0
    //   33: iconst_1
    //   34: putfield mDesiredFocusableState : Z
    //   37: iload_1
    //   38: ifeq -> 69
    //   41: iload_2
    //   42: istore_1
    //   43: iload #4
    //   45: ifeq -> 57
    //   48: aload_0
    //   49: invokevirtual isInFilterMode : ()Z
    //   52: ifeq -> 69
    //   55: iload_2
    //   56: istore_1
    //   57: aload_0
    //   58: iload_1
    //   59: invokespecial setFocusableInTouchMode : (Z)V
    //   62: return
    //   63: iconst_0
    //   64: istore #4
    //   66: goto -> 23
    //   69: iconst_0
    //   70: istore_1
    //   71: goto -> 57
  }
  
  void setNextSelectedPositionInt(int paramInt) {
    this.mNextSelectedPosition = paramInt;
    this.mNextSelectedRowId = getItemIdAtPosition(paramInt);
    if (this.mNeedSync && this.mSyncMode == 0 && paramInt >= 0) {
      this.mSyncPosition = paramInt;
      this.mSyncRowId = this.mNextSelectedRowId;
    } 
  }
  
  public void setOnClickListener(View.OnClickListener paramOnClickListener) {
    throw new RuntimeException("Don't call setOnClickListener for an AdapterView. You probably want setOnItemClickListener instead");
  }
  
  public void setOnItemClickListener(OnItemClickListener paramOnItemClickListener) {
    this.mOnItemClickListener = paramOnItemClickListener;
  }
  
  public void setOnItemLongClickListener(OnItemLongClickListener paramOnItemLongClickListener) {
    if (!isLongClickable())
      setLongClickable(true); 
    this.mOnItemLongClickListener = paramOnItemLongClickListener;
  }
  
  public void setOnItemSelectedListener(OnItemSelectedListener paramOnItemSelectedListener) {
    this.mOnItemSelectedListener = paramOnItemSelectedListener;
  }
  
  void setSelectedPositionInt(int paramInt) {
    this.mSelectedPosition = paramInt;
    this.mSelectedRowId = getItemIdAtPosition(paramInt);
  }
  
  public abstract void setSelection(int paramInt);
  
  public static class AdapterContextMenuInfo implements ContextMenu.ContextMenuInfo {
    public long id;
    
    public int position;
    
    public View targetView;
    
    public AdapterContextMenuInfo(View param1View, int param1Int, long param1Long) {
      this.targetView = param1View;
      this.position = param1Int;
      this.id = param1Long;
    }
  }
  
  class AdapterDataSetObserver extends DataSetObserver {
    private Parcelable mInstanceState = null;
    
    public void clearSavedState() {
      this.mInstanceState = null;
    }
    
    public void onChanged() {
      AdapterViewICS.this.mDataChanged = true;
      AdapterViewICS.this.mOldItemCount = AdapterViewICS.this.mItemCount;
      AdapterViewICS.this.mItemCount = AdapterViewICS.this.getAdapter().getCount();
      if (AdapterViewICS.this.getAdapter().hasStableIds() && this.mInstanceState != null && AdapterViewICS.this.mOldItemCount == 0 && AdapterViewICS.this.mItemCount > 0) {
        AdapterViewICS.this.onRestoreInstanceState(this.mInstanceState);
        this.mInstanceState = null;
      } else {
        AdapterViewICS.this.rememberSyncState();
      } 
      AdapterViewICS.this.checkFocus();
      AdapterViewICS.this.requestLayout();
    }
    
    public void onInvalidated() {
      AdapterViewICS.this.mDataChanged = true;
      if (AdapterViewICS.this.getAdapter().hasStableIds())
        this.mInstanceState = AdapterViewICS.this.onSaveInstanceState(); 
      AdapterViewICS.this.mOldItemCount = AdapterViewICS.this.mItemCount;
      AdapterViewICS.this.mItemCount = 0;
      AdapterViewICS.this.mSelectedPosition = -1;
      AdapterViewICS.this.mSelectedRowId = Long.MIN_VALUE;
      AdapterViewICS.this.mNextSelectedPosition = -1;
      AdapterViewICS.this.mNextSelectedRowId = Long.MIN_VALUE;
      AdapterViewICS.this.mNeedSync = false;
      AdapterViewICS.this.checkFocus();
      AdapterViewICS.this.requestLayout();
    }
  }
  
  public static interface OnItemClickListener {
    void onItemClick(AdapterViewICS<?> param1AdapterViewICS, View param1View, int param1Int, long param1Long);
  }
  
  class OnItemClickListenerWrapper implements AdapterView.OnItemClickListener {
    private final AdapterViewICS.OnItemClickListener mWrappedListener;
    
    public OnItemClickListenerWrapper(AdapterViewICS.OnItemClickListener param1OnItemClickListener) {
      this.mWrappedListener = param1OnItemClickListener;
    }
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.mWrappedListener.onItemClick(AdapterViewICS.this, param1View, param1Int, param1Long);
    }
  }
  
  public static interface OnItemLongClickListener {
    boolean onItemLongClick(AdapterViewICS<?> param1AdapterViewICS, View param1View, int param1Int, long param1Long);
  }
  
  public static interface OnItemSelectedListener {
    void onItemSelected(AdapterViewICS<?> param1AdapterViewICS, View param1View, int param1Int, long param1Long);
    
    void onNothingSelected(AdapterViewICS<?> param1AdapterViewICS);
  }
  
  private class SelectionNotifier implements Runnable {
    private SelectionNotifier() {}
    
    public void run() {
      if (AdapterViewICS.this.mDataChanged) {
        if (AdapterViewICS.this.getAdapter() != null)
          AdapterViewICS.this.post(this); 
        return;
      } 
      AdapterViewICS.this.fireOnSelected();
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/widget/AdapterViewICS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */