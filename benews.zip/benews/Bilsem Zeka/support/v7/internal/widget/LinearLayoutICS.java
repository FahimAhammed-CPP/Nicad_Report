package android.support.v7.internal.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.support.v7.appcompat.R;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

public class LinearLayoutICS extends LinearLayout {
  private static final int SHOW_DIVIDER_BEGINNING = 1;
  
  private static final int SHOW_DIVIDER_END = 4;
  
  private static final int SHOW_DIVIDER_MIDDLE = 2;
  
  private static final int SHOW_DIVIDER_NONE = 0;
  
  private final Drawable mDivider;
  
  private final int mDividerHeight;
  
  private final int mDividerPadding;
  
  private final int mDividerWidth;
  
  private final int mShowDividers;
  
  public LinearLayoutICS(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.LinearLayoutICS);
    this.mDivider = typedArray.getDrawable(0);
    if (this.mDivider != null) {
      this.mDividerWidth = this.mDivider.getIntrinsicWidth();
      this.mDividerHeight = this.mDivider.getIntrinsicHeight();
    } else {
      this.mDividerWidth = 0;
      this.mDividerHeight = 0;
    } 
    this.mShowDividers = typedArray.getInt(1, 0);
    this.mDividerPadding = typedArray.getDimensionPixelSize(2, 0);
    typedArray.recycle();
    if (this.mDivider != null)
      bool = false; 
    setWillNotDraw(bool);
  }
  
  void drawSupportDividersHorizontal(Canvas paramCanvas) {
    int i = getChildCount();
    int j;
    for (j = 0; j < i; j++) {
      View view = getChildAt(j);
      if (view != null && view.getVisibility() != 8 && hasSupportDividerBeforeChildAt(j)) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        drawSupportVerticalDivider(paramCanvas, view.getLeft() - layoutParams.leftMargin);
      } 
    } 
    if (hasSupportDividerBeforeChildAt(i)) {
      View view = getChildAt(i - 1);
      if (view == null) {
        j = getWidth() - getPaddingRight() - this.mDividerWidth;
      } else {
        j = view.getRight();
      } 
      drawSupportVerticalDivider(paramCanvas, j);
    } 
  }
  
  void drawSupportDividersVertical(Canvas paramCanvas) {
    int i = getChildCount();
    int j;
    for (j = 0; j < i; j++) {
      View view = getChildAt(j);
      if (view != null && view.getVisibility() != 8 && hasSupportDividerBeforeChildAt(j)) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        drawSupportHorizontalDivider(paramCanvas, view.getTop() - layoutParams.topMargin);
      } 
    } 
    if (hasSupportDividerBeforeChildAt(i)) {
      View view = getChildAt(i - 1);
      if (view == null) {
        j = getHeight() - getPaddingBottom() - this.mDividerHeight;
      } else {
        j = view.getBottom();
      } 
      drawSupportHorizontalDivider(paramCanvas, j);
    } 
  }
  
  void drawSupportHorizontalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(getPaddingLeft() + this.mDividerPadding, paramInt, getWidth() - getPaddingRight() - this.mDividerPadding, this.mDividerHeight + paramInt);
    this.mDivider.draw(paramCanvas);
  }
  
  void drawSupportVerticalDivider(Canvas paramCanvas, int paramInt) {
    this.mDivider.setBounds(paramInt, getPaddingTop() + this.mDividerPadding, this.mDividerWidth + paramInt, getHeight() - getPaddingBottom() - this.mDividerPadding);
    this.mDivider.draw(paramCanvas);
  }
  
  public int getSupportDividerWidth() {
    return this.mDividerWidth;
  }
  
  protected boolean hasSupportDividerBeforeChildAt(int paramInt) {
    null = true;
    if (paramInt == 0) {
      if ((this.mShowDividers & 0x1) == 0)
        null = false; 
      return null;
    } 
    if (paramInt == getChildCount()) {
      if ((this.mShowDividers & 0x4) == 0)
        null = false; 
      return null;
    } 
    if ((this.mShowDividers & 0x2) != 0) {
      boolean bool = false;
      paramInt--;
      while (true) {
        null = bool;
        if (paramInt >= 0) {
          if (getChildAt(paramInt).getVisibility() != 8)
            return true; 
          paramInt--;
          continue;
        } 
        return null;
      } 
    } 
    return false;
  }
  
  protected void measureChildWithMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mDivider != null) {
      int i = indexOfChild(paramView);
      int j = getChildCount();
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)paramView.getLayoutParams();
      if (getOrientation() == 1) {
        if (hasSupportDividerBeforeChildAt(i)) {
          layoutParams.topMargin = this.mDividerHeight;
        } else if (i == j - 1 && hasSupportDividerBeforeChildAt(j)) {
          layoutParams.bottomMargin = this.mDividerHeight;
        } 
      } else if (hasSupportDividerBeforeChildAt(i)) {
        layoutParams.leftMargin = this.mDividerWidth;
      } else if (i == j - 1 && hasSupportDividerBeforeChildAt(j)) {
        layoutParams.rightMargin = this.mDividerWidth;
      } 
    } 
    super.measureChildWithMargins(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  protected void onDraw(Canvas paramCanvas) {
    if (this.mDivider != null) {
      if (getOrientation() == 1) {
        drawSupportDividersVertical(paramCanvas);
        return;
      } 
      drawSupportDividersHorizontal(paramCanvas);
    } 
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/widget/LinearLayoutICS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */