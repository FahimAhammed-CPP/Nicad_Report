package android.support.v7.internal.widget;

import android.content.Context;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.v7.appcompat.R;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import java.util.Locale;

public class ListPopupWindow {
  private static final boolean DEBUG = false;
  
  private static final int EXPAND_LIST_TIMEOUT = 250;
  
  public static final int FILL_PARENT = -1;
  
  public static final int INPUT_METHOD_FROM_FOCUSABLE = 0;
  
  public static final int INPUT_METHOD_NEEDED = 1;
  
  public static final int INPUT_METHOD_NOT_NEEDED = 2;
  
  public static final int POSITION_PROMPT_ABOVE = 0;
  
  public static final int POSITION_PROMPT_BELOW = 1;
  
  private static final String TAG = "ListPopupWindow";
  
  public static final int WRAP_CONTENT = -2;
  
  private ListAdapter mAdapter;
  
  private Context mContext;
  
  private boolean mDropDownAlwaysVisible = false;
  
  private View mDropDownAnchorView;
  
  private int mDropDownHeight = -2;
  
  private int mDropDownHorizontalOffset;
  
  private DropDownListView mDropDownList;
  
  private Drawable mDropDownListHighlight;
  
  private int mDropDownVerticalOffset;
  
  private boolean mDropDownVerticalOffsetSet;
  
  private int mDropDownWidth = -2;
  
  private boolean mForceIgnoreOutsideTouch = false;
  
  private Handler mHandler = new Handler();
  
  private final ListSelectorHider mHideSelector = new ListSelectorHider();
  
  private AdapterView.OnItemClickListener mItemClickListener;
  
  private AdapterView.OnItemSelectedListener mItemSelectedListener;
  
  private int mLayoutDirection;
  
  int mListItemExpandMaximum = Integer.MAX_VALUE;
  
  private boolean mModal;
  
  private DataSetObserver mObserver;
  
  private PopupWindow mPopup;
  
  private int mPromptPosition = 0;
  
  private View mPromptView;
  
  private final ResizePopupRunnable mResizePopupRunnable = new ResizePopupRunnable();
  
  private final PopupScrollListener mScrollListener = new PopupScrollListener();
  
  private Runnable mShowDropDownRunnable;
  
  private Rect mTempRect = new Rect();
  
  private final PopupTouchInterceptor mTouchInterceptor = new PopupTouchInterceptor();
  
  public ListPopupWindow(Context paramContext) {
    this(paramContext, null, R.attr.listPopupWindowStyle);
  }
  
  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, R.attr.listPopupWindowStyle);
  }
  
  public ListPopupWindow(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this.mContext = paramContext;
    this.mPopup = new PopupWindow(paramContext, paramAttributeSet, paramInt);
    this.mPopup.setInputMethodMode(1);
    Locale locale = (this.mContext.getResources().getConfiguration()).locale;
  }
  
  private int buildDropDown() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: iconst_0
    //   3: istore_2
    //   4: aload_0
    //   5: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   8: ifnonnull -> 472
    //   11: aload_0
    //   12: getfield mContext : Landroid/content/Context;
    //   15: astore_3
    //   16: aload_0
    //   17: new android/support/v7/internal/widget/ListPopupWindow$1
    //   20: dup
    //   21: aload_0
    //   22: invokespecial <init> : (Landroid/support/v7/internal/widget/ListPopupWindow;)V
    //   25: putfield mShowDropDownRunnable : Ljava/lang/Runnable;
    //   28: aload_0
    //   29: getfield mModal : Z
    //   32: ifne -> 430
    //   35: iconst_1
    //   36: istore #4
    //   38: aload_0
    //   39: new android/support/v7/internal/widget/ListPopupWindow$DropDownListView
    //   42: dup
    //   43: aload_3
    //   44: iload #4
    //   46: invokespecial <init> : (Landroid/content/Context;Z)V
    //   49: putfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   52: aload_0
    //   53: getfield mDropDownListHighlight : Landroid/graphics/drawable/Drawable;
    //   56: ifnull -> 70
    //   59: aload_0
    //   60: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   63: aload_0
    //   64: getfield mDropDownListHighlight : Landroid/graphics/drawable/Drawable;
    //   67: invokevirtual setSelector : (Landroid/graphics/drawable/Drawable;)V
    //   70: aload_0
    //   71: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   74: aload_0
    //   75: getfield mAdapter : Landroid/widget/ListAdapter;
    //   78: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   81: aload_0
    //   82: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   85: aload_0
    //   86: getfield mItemClickListener : Landroid/widget/AdapterView$OnItemClickListener;
    //   89: invokevirtual setOnItemClickListener : (Landroid/widget/AdapterView$OnItemClickListener;)V
    //   92: aload_0
    //   93: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   96: iconst_1
    //   97: invokevirtual setFocusable : (Z)V
    //   100: aload_0
    //   101: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   104: iconst_1
    //   105: invokevirtual setFocusableInTouchMode : (Z)V
    //   108: aload_0
    //   109: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   112: new android/support/v7/internal/widget/ListPopupWindow$2
    //   115: dup
    //   116: aload_0
    //   117: invokespecial <init> : (Landroid/support/v7/internal/widget/ListPopupWindow;)V
    //   120: invokevirtual setOnItemSelectedListener : (Landroid/widget/AdapterView$OnItemSelectedListener;)V
    //   123: aload_0
    //   124: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   127: aload_0
    //   128: getfield mScrollListener : Landroid/support/v7/internal/widget/ListPopupWindow$PopupScrollListener;
    //   131: invokevirtual setOnScrollListener : (Landroid/widget/AbsListView$OnScrollListener;)V
    //   134: aload_0
    //   135: getfield mItemSelectedListener : Landroid/widget/AdapterView$OnItemSelectedListener;
    //   138: ifnull -> 152
    //   141: aload_0
    //   142: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   145: aload_0
    //   146: getfield mItemSelectedListener : Landroid/widget/AdapterView$OnItemSelectedListener;
    //   149: invokevirtual setOnItemSelectedListener : (Landroid/widget/AdapterView$OnItemSelectedListener;)V
    //   152: aload_0
    //   153: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   156: astore #5
    //   158: aload_0
    //   159: getfield mPromptView : Landroid/view/View;
    //   162: astore #6
    //   164: aload #5
    //   166: astore #7
    //   168: aload #6
    //   170: ifnull -> 300
    //   173: new android/widget/LinearLayout
    //   176: dup
    //   177: aload_3
    //   178: invokespecial <init> : (Landroid/content/Context;)V
    //   181: astore #7
    //   183: aload #7
    //   185: iconst_1
    //   186: invokevirtual setOrientation : (I)V
    //   189: new android/widget/LinearLayout$LayoutParams
    //   192: dup
    //   193: iconst_m1
    //   194: iconst_0
    //   195: fconst_1
    //   196: invokespecial <init> : (IIF)V
    //   199: astore_3
    //   200: aload_0
    //   201: getfield mPromptPosition : I
    //   204: tableswitch default -> 228, 0 -> 454, 1 -> 436
    //   228: ldc 'ListPopupWindow'
    //   230: new java/lang/StringBuilder
    //   233: dup
    //   234: invokespecial <init> : ()V
    //   237: ldc 'Invalid hint position '
    //   239: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   242: aload_0
    //   243: getfield mPromptPosition : I
    //   246: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   249: invokevirtual toString : ()Ljava/lang/String;
    //   252: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   255: pop
    //   256: aload #6
    //   258: aload_0
    //   259: getfield mDropDownWidth : I
    //   262: ldc_w -2147483648
    //   265: invokestatic makeMeasureSpec : (II)I
    //   268: iconst_0
    //   269: invokevirtual measure : (II)V
    //   272: aload #6
    //   274: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   277: checkcast android/widget/LinearLayout$LayoutParams
    //   280: astore #5
    //   282: aload #6
    //   284: invokevirtual getMeasuredHeight : ()I
    //   287: aload #5
    //   289: getfield topMargin : I
    //   292: iadd
    //   293: aload #5
    //   295: getfield bottomMargin : I
    //   298: iadd
    //   299: istore_2
    //   300: aload_0
    //   301: getfield mPopup : Landroid/widget/PopupWindow;
    //   304: aload #7
    //   306: invokevirtual setContentView : (Landroid/view/View;)V
    //   309: iconst_0
    //   310: istore #8
    //   312: aload_0
    //   313: getfield mPopup : Landroid/widget/PopupWindow;
    //   316: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   319: astore #7
    //   321: aload #7
    //   323: ifnull -> 528
    //   326: aload #7
    //   328: aload_0
    //   329: getfield mTempRect : Landroid/graphics/Rect;
    //   332: invokevirtual getPadding : (Landroid/graphics/Rect;)Z
    //   335: pop
    //   336: aload_0
    //   337: getfield mTempRect : Landroid/graphics/Rect;
    //   340: getfield top : I
    //   343: aload_0
    //   344: getfield mTempRect : Landroid/graphics/Rect;
    //   347: getfield bottom : I
    //   350: iadd
    //   351: istore_1
    //   352: iload_1
    //   353: istore #8
    //   355: aload_0
    //   356: getfield mDropDownVerticalOffsetSet : Z
    //   359: ifne -> 377
    //   362: aload_0
    //   363: aload_0
    //   364: getfield mTempRect : Landroid/graphics/Rect;
    //   367: getfield top : I
    //   370: ineg
    //   371: putfield mDropDownVerticalOffset : I
    //   374: iload_1
    //   375: istore #8
    //   377: aload_0
    //   378: getfield mPopup : Landroid/widget/PopupWindow;
    //   381: invokevirtual getInputMethodMode : ()I
    //   384: iconst_2
    //   385: if_icmpne -> 538
    //   388: iconst_1
    //   389: istore #4
    //   391: aload_0
    //   392: aload_0
    //   393: invokevirtual getAnchorView : ()Landroid/view/View;
    //   396: aload_0
    //   397: getfield mDropDownVerticalOffset : I
    //   400: iload #4
    //   402: invokevirtual getMaxAvailableHeight : (Landroid/view/View;IZ)I
    //   405: istore #9
    //   407: aload_0
    //   408: getfield mDropDownAlwaysVisible : Z
    //   411: ifne -> 422
    //   414: aload_0
    //   415: getfield mDropDownHeight : I
    //   418: iconst_m1
    //   419: if_icmpne -> 544
    //   422: iload #9
    //   424: iload #8
    //   426: iadd
    //   427: istore_2
    //   428: iload_2
    //   429: ireturn
    //   430: iconst_0
    //   431: istore #4
    //   433: goto -> 38
    //   436: aload #7
    //   438: aload #5
    //   440: aload_3
    //   441: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   444: aload #7
    //   446: aload #6
    //   448: invokevirtual addView : (Landroid/view/View;)V
    //   451: goto -> 256
    //   454: aload #7
    //   456: aload #6
    //   458: invokevirtual addView : (Landroid/view/View;)V
    //   461: aload #7
    //   463: aload #5
    //   465: aload_3
    //   466: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   469: goto -> 256
    //   472: aload_0
    //   473: getfield mPopup : Landroid/widget/PopupWindow;
    //   476: invokevirtual getContentView : ()Landroid/view/View;
    //   479: checkcast android/view/ViewGroup
    //   482: astore #7
    //   484: aload_0
    //   485: getfield mPromptView : Landroid/view/View;
    //   488: astore #7
    //   490: iload_1
    //   491: istore_2
    //   492: aload #7
    //   494: ifnull -> 309
    //   497: aload #7
    //   499: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   502: checkcast android/widget/LinearLayout$LayoutParams
    //   505: astore #5
    //   507: aload #7
    //   509: invokevirtual getMeasuredHeight : ()I
    //   512: aload #5
    //   514: getfield topMargin : I
    //   517: iadd
    //   518: aload #5
    //   520: getfield bottomMargin : I
    //   523: iadd
    //   524: istore_2
    //   525: goto -> 309
    //   528: aload_0
    //   529: getfield mTempRect : Landroid/graphics/Rect;
    //   532: invokevirtual setEmpty : ()V
    //   535: goto -> 377
    //   538: iconst_0
    //   539: istore #4
    //   541: goto -> 391
    //   544: aload_0
    //   545: getfield mDropDownWidth : I
    //   548: tableswitch default -> 572, -2 -> 620, -1 -> 659
    //   572: aload_0
    //   573: getfield mDropDownWidth : I
    //   576: ldc_w 1073741824
    //   579: invokestatic makeMeasureSpec : (II)I
    //   582: istore_1
    //   583: aload_0
    //   584: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   587: iload_1
    //   588: iconst_0
    //   589: iconst_m1
    //   590: iload #9
    //   592: iload_2
    //   593: isub
    //   594: iconst_m1
    //   595: invokevirtual measureHeightOfChildrenCompat : (IIIII)I
    //   598: istore #9
    //   600: iload_2
    //   601: istore_1
    //   602: iload #9
    //   604: ifle -> 612
    //   607: iload_2
    //   608: iload #8
    //   610: iadd
    //   611: istore_1
    //   612: iload #9
    //   614: iload_1
    //   615: iadd
    //   616: istore_2
    //   617: goto -> 428
    //   620: aload_0
    //   621: getfield mContext : Landroid/content/Context;
    //   624: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   627: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   630: getfield widthPixels : I
    //   633: aload_0
    //   634: getfield mTempRect : Landroid/graphics/Rect;
    //   637: getfield left : I
    //   640: aload_0
    //   641: getfield mTempRect : Landroid/graphics/Rect;
    //   644: getfield right : I
    //   647: iadd
    //   648: isub
    //   649: ldc_w -2147483648
    //   652: invokestatic makeMeasureSpec : (II)I
    //   655: istore_1
    //   656: goto -> 583
    //   659: aload_0
    //   660: getfield mContext : Landroid/content/Context;
    //   663: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   666: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   669: getfield widthPixels : I
    //   672: aload_0
    //   673: getfield mTempRect : Landroid/graphics/Rect;
    //   676: getfield left : I
    //   679: aload_0
    //   680: getfield mTempRect : Landroid/graphics/Rect;
    //   683: getfield right : I
    //   686: iadd
    //   687: isub
    //   688: ldc_w 1073741824
    //   691: invokestatic makeMeasureSpec : (II)I
    //   694: istore_1
    //   695: goto -> 583
  }
  
  private void removePromptView() {
    if (this.mPromptView != null) {
      ViewParent viewParent = this.mPromptView.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(this.mPromptView); 
    } 
  }
  
  public void clearListSelection() {
    DropDownListView dropDownListView = this.mDropDownList;
    if (dropDownListView != null) {
      DropDownListView.access$502(dropDownListView, true);
      dropDownListView.requestLayout();
    } 
  }
  
  public void dismiss() {
    this.mPopup.dismiss();
    removePromptView();
    this.mPopup.setContentView(null);
    this.mDropDownList = null;
    this.mHandler.removeCallbacks(this.mResizePopupRunnable);
  }
  
  public View getAnchorView() {
    return this.mDropDownAnchorView;
  }
  
  public int getAnimationStyle() {
    return this.mPopup.getAnimationStyle();
  }
  
  public Drawable getBackground() {
    return this.mPopup.getBackground();
  }
  
  public int getHeight() {
    return this.mDropDownHeight;
  }
  
  public int getHorizontalOffset() {
    return this.mDropDownHorizontalOffset;
  }
  
  public int getInputMethodMode() {
    return this.mPopup.getInputMethodMode();
  }
  
  public ListView getListView() {
    return this.mDropDownList;
  }
  
  public int getMaxAvailableHeight(View paramView, int paramInt, boolean paramBoolean) {
    Rect rect = new Rect();
    paramView.getWindowVisibleDisplayFrame(rect);
    int[] arrayOfInt = new int[2];
    paramView.getLocationOnScreen(arrayOfInt);
    int i = rect.bottom;
    if (paramBoolean)
      i = (paramView.getContext().getResources().getDisplayMetrics()).heightPixels; 
    i = Math.max(i - arrayOfInt[1] + paramView.getHeight() - paramInt, arrayOfInt[1] - rect.top + paramInt);
    paramInt = i;
    if (this.mPopup.getBackground() != null) {
      this.mPopup.getBackground().getPadding(this.mTempRect);
      paramInt = i - this.mTempRect.top + this.mTempRect.bottom;
    } 
    return paramInt;
  }
  
  public int getPromptPosition() {
    return this.mPromptPosition;
  }
  
  public Object getSelectedItem() {
    return !isShowing() ? null : this.mDropDownList.getSelectedItem();
  }
  
  public long getSelectedItemId() {
    return !isShowing() ? Long.MIN_VALUE : this.mDropDownList.getSelectedItemId();
  }
  
  public int getSelectedItemPosition() {
    return !isShowing() ? -1 : this.mDropDownList.getSelectedItemPosition();
  }
  
  public View getSelectedView() {
    return !isShowing() ? null : this.mDropDownList.getSelectedView();
  }
  
  public int getSoftInputMode() {
    return this.mPopup.getSoftInputMode();
  }
  
  public int getVerticalOffset() {
    return !this.mDropDownVerticalOffsetSet ? 0 : this.mDropDownVerticalOffset;
  }
  
  public int getWidth() {
    return this.mDropDownWidth;
  }
  
  public boolean isDropDownAlwaysVisible() {
    return this.mDropDownAlwaysVisible;
  }
  
  public boolean isInputMethodNotNeeded() {
    return (this.mPopup.getInputMethodMode() == 2);
  }
  
  public boolean isModal() {
    return this.mModal;
  }
  
  public boolean isShowing() {
    return this.mPopup.isShowing();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_3
    //   2: aload_0
    //   3: invokevirtual isShowing : ()Z
    //   6: ifeq -> 292
    //   9: iload_1
    //   10: bipush #62
    //   12: if_icmpeq -> 292
    //   15: aload_0
    //   16: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   19: invokevirtual getSelectedItemPosition : ()I
    //   22: ifge -> 37
    //   25: iload_1
    //   26: bipush #66
    //   28: if_icmpeq -> 292
    //   31: iload_1
    //   32: bipush #23
    //   34: if_icmpeq -> 292
    //   37: aload_0
    //   38: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   41: invokevirtual getSelectedItemPosition : ()I
    //   44: istore #4
    //   46: aload_0
    //   47: getfield mPopup : Landroid/widget/PopupWindow;
    //   50: invokevirtual isAboveAnchor : ()Z
    //   53: ifne -> 166
    //   56: iconst_1
    //   57: istore #5
    //   59: aload_0
    //   60: getfield mAdapter : Landroid/widget/ListAdapter;
    //   63: astore #6
    //   65: ldc 2147483647
    //   67: istore #7
    //   69: ldc_w -2147483648
    //   72: istore #8
    //   74: aload #6
    //   76: ifnull -> 112
    //   79: aload #6
    //   81: invokeinterface areAllItemsEnabled : ()Z
    //   86: istore #9
    //   88: iload #9
    //   90: ifeq -> 172
    //   93: iconst_0
    //   94: istore #7
    //   96: iload #9
    //   98: ifeq -> 186
    //   101: aload #6
    //   103: invokeinterface getCount : ()I
    //   108: iconst_1
    //   109: isub
    //   110: istore #8
    //   112: iload #5
    //   114: ifeq -> 130
    //   117: iload_1
    //   118: bipush #19
    //   120: if_icmpne -> 130
    //   123: iload #4
    //   125: iload #7
    //   127: if_icmple -> 148
    //   130: iload #5
    //   132: ifne -> 208
    //   135: iload_1
    //   136: bipush #20
    //   138: if_icmpne -> 208
    //   141: iload #4
    //   143: iload #8
    //   145: if_icmplt -> 208
    //   148: aload_0
    //   149: invokevirtual clearListSelection : ()V
    //   152: aload_0
    //   153: getfield mPopup : Landroid/widget/PopupWindow;
    //   156: iconst_1
    //   157: invokevirtual setInputMethodMode : (I)V
    //   160: aload_0
    //   161: invokevirtual show : ()V
    //   164: iload_3
    //   165: ireturn
    //   166: iconst_0
    //   167: istore #5
    //   169: goto -> 59
    //   172: aload_0
    //   173: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   176: iconst_0
    //   177: iconst_1
    //   178: invokestatic access$600 : (Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;IZ)I
    //   181: istore #7
    //   183: goto -> 96
    //   186: aload_0
    //   187: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   190: aload #6
    //   192: invokeinterface getCount : ()I
    //   197: iconst_1
    //   198: isub
    //   199: iconst_0
    //   200: invokestatic access$600 : (Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;IZ)I
    //   203: istore #8
    //   205: goto -> 112
    //   208: aload_0
    //   209: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   212: iconst_0
    //   213: invokestatic access$502 : (Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;Z)Z
    //   216: pop
    //   217: aload_0
    //   218: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   221: iload_1
    //   222: aload_2
    //   223: invokevirtual onKeyDown : (ILandroid/view/KeyEvent;)Z
    //   226: ifeq -> 297
    //   229: aload_0
    //   230: getfield mPopup : Landroid/widget/PopupWindow;
    //   233: iconst_2
    //   234: invokevirtual setInputMethodMode : (I)V
    //   237: aload_0
    //   238: getfield mDropDownList : Landroid/support/v7/internal/widget/ListPopupWindow$DropDownListView;
    //   241: invokevirtual requestFocusFromTouch : ()Z
    //   244: pop
    //   245: aload_0
    //   246: invokevirtual show : ()V
    //   249: iload_1
    //   250: lookupswitch default -> 292, 19 -> 164, 20 -> 164, 23 -> 164, 66 -> 164
    //   292: iconst_0
    //   293: istore_3
    //   294: goto -> 164
    //   297: iload #5
    //   299: ifeq -> 318
    //   302: iload_1
    //   303: bipush #20
    //   305: if_icmpne -> 318
    //   308: iload #4
    //   310: iload #8
    //   312: if_icmpne -> 292
    //   315: goto -> 164
    //   318: iload #5
    //   320: ifne -> 292
    //   323: iload_1
    //   324: bipush #19
    //   326: if_icmpne -> 292
    //   329: iload #4
    //   331: iload #7
    //   333: if_icmpne -> 292
    //   336: goto -> 164
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    if (isShowing() && this.mDropDownList.getSelectedItemPosition() >= 0) {
      boolean bool = this.mDropDownList.onKeyUp(paramInt, paramKeyEvent);
      null = bool;
      if (bool) {
        switch (paramInt) {
          default:
            return bool;
          case 23:
          case 66:
            break;
        } 
      } else {
        return null;
      } 
      dismiss();
      return bool;
    } 
    return false;
  }
  
  public boolean performItemClick(int paramInt) {
    if (isShowing()) {
      if (this.mItemClickListener != null) {
        DropDownListView dropDownListView = this.mDropDownList;
        View view = dropDownListView.getChildAt(paramInt - dropDownListView.getFirstVisiblePosition());
        ListAdapter listAdapter = dropDownListView.getAdapter();
        this.mItemClickListener.onItemClick((AdapterView)dropDownListView, view, paramInt, listAdapter.getItemId(paramInt));
      } 
      return true;
    } 
    return false;
  }
  
  public void postShow() {
    this.mHandler.post(this.mShowDropDownRunnable);
  }
  
  public void setAdapter(ListAdapter paramListAdapter) {
    if (this.mObserver == null) {
      this.mObserver = new PopupDataSetObserver();
    } else if (this.mAdapter != null) {
      this.mAdapter.unregisterDataSetObserver(this.mObserver);
    } 
    this.mAdapter = paramListAdapter;
    if (this.mAdapter != null)
      paramListAdapter.registerDataSetObserver(this.mObserver); 
    if (this.mDropDownList != null)
      this.mDropDownList.setAdapter(this.mAdapter); 
  }
  
  public void setAnchorView(View paramView) {
    this.mDropDownAnchorView = paramView;
  }
  
  public void setAnimationStyle(int paramInt) {
    this.mPopup.setAnimationStyle(paramInt);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    this.mPopup.setBackgroundDrawable(paramDrawable);
  }
  
  public void setContentWidth(int paramInt) {
    Drawable drawable = this.mPopup.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.mTempRect);
      this.mDropDownWidth = this.mTempRect.left + this.mTempRect.right + paramInt;
      return;
    } 
    setWidth(paramInt);
  }
  
  public void setDropDownAlwaysVisible(boolean paramBoolean) {
    this.mDropDownAlwaysVisible = paramBoolean;
  }
  
  public void setForceIgnoreOutsideTouch(boolean paramBoolean) {
    this.mForceIgnoreOutsideTouch = paramBoolean;
  }
  
  public void setHeight(int paramInt) {
    this.mDropDownHeight = paramInt;
  }
  
  public void setHorizontalOffset(int paramInt) {
    this.mDropDownHorizontalOffset = paramInt;
  }
  
  public void setInputMethodMode(int paramInt) {
    this.mPopup.setInputMethodMode(paramInt);
  }
  
  void setListItemExpandMax(int paramInt) {
    this.mListItemExpandMaximum = paramInt;
  }
  
  public void setListSelector(Drawable paramDrawable) {
    this.mDropDownListHighlight = paramDrawable;
  }
  
  public void setModal(boolean paramBoolean) {
    this.mModal = true;
    this.mPopup.setFocusable(paramBoolean);
  }
  
  public void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.mPopup.setOnDismissListener(paramOnDismissListener);
  }
  
  public void setOnItemClickListener(AdapterView.OnItemClickListener paramOnItemClickListener) {
    this.mItemClickListener = paramOnItemClickListener;
  }
  
  public void setOnItemSelectedListener(AdapterView.OnItemSelectedListener paramOnItemSelectedListener) {
    this.mItemSelectedListener = paramOnItemSelectedListener;
  }
  
  public void setPromptPosition(int paramInt) {
    this.mPromptPosition = paramInt;
  }
  
  public void setPromptView(View paramView) {
    boolean bool = isShowing();
    if (bool)
      removePromptView(); 
    this.mPromptView = paramView;
    if (bool)
      show(); 
  }
  
  public void setSelection(int paramInt) {
    DropDownListView dropDownListView = this.mDropDownList;
    if (isShowing() && dropDownListView != null) {
      DropDownListView.access$502(dropDownListView, false);
      dropDownListView.setSelection(paramInt);
      if (dropDownListView.getChoiceMode() != 0)
        dropDownListView.setItemChecked(paramInt, true); 
    } 
  }
  
  public void setSoftInputMode(int paramInt) {
    this.mPopup.setSoftInputMode(paramInt);
  }
  
  public void setVerticalOffset(int paramInt) {
    this.mDropDownVerticalOffset = paramInt;
    this.mDropDownVerticalOffsetSet = true;
  }
  
  public void setWidth(int paramInt) {
    this.mDropDownWidth = paramInt;
  }
  
  public void show() {
    boolean bool1 = true;
    boolean bool2 = false;
    byte b = -1;
    int i = buildDropDown();
    int j = 0;
    boolean bool3 = false;
    boolean bool = isInputMethodNotNeeded();
    if (this.mPopup.isShowing()) {
      if (this.mDropDownWidth == -1) {
        j = -1;
      } else if (this.mDropDownWidth == -2) {
        j = getAnchorView().getWidth();
      } else {
        j = this.mDropDownWidth;
      } 
      if (this.mDropDownHeight == -1) {
        if (!bool)
          i = -1; 
        if (bool) {
          PopupWindow popupWindow2 = this.mPopup;
          if (this.mDropDownWidth != -1)
            b = 0; 
          popupWindow2.setWindowLayoutMode(b, 0);
        } else {
          PopupWindow popupWindow2 = this.mPopup;
          if (this.mDropDownWidth == -1) {
            b = -1;
          } else {
            b = 0;
          } 
          popupWindow2.setWindowLayoutMode(b, -1);
        } 
      } else if (this.mDropDownHeight != -2) {
        i = this.mDropDownHeight;
      } 
      PopupWindow popupWindow1 = this.mPopup;
      bool1 = bool2;
      if (!this.mForceIgnoreOutsideTouch) {
        bool1 = bool2;
        if (!this.mDropDownAlwaysVisible)
          bool1 = true; 
      } 
      popupWindow1.setOutsideTouchable(bool1);
      this.mPopup.update(getAnchorView(), this.mDropDownHorizontalOffset, this.mDropDownVerticalOffset, j, i);
      return;
    } 
    if (this.mDropDownWidth == -1) {
      j = -1;
    } else if (this.mDropDownWidth == -2) {
      this.mPopup.setWidth(getAnchorView().getWidth());
    } else {
      this.mPopup.setWidth(this.mDropDownWidth);
    } 
    if (this.mDropDownHeight == -1) {
      i = -1;
    } else if (this.mDropDownHeight == -2) {
      this.mPopup.setHeight(i);
      i = bool3;
    } else {
      this.mPopup.setHeight(this.mDropDownHeight);
      i = bool3;
    } 
    this.mPopup.setWindowLayoutMode(j, i);
    PopupWindow popupWindow = this.mPopup;
    if (this.mForceIgnoreOutsideTouch || this.mDropDownAlwaysVisible)
      bool1 = false; 
    popupWindow.setOutsideTouchable(bool1);
    this.mPopup.setTouchInterceptor(this.mTouchInterceptor);
    this.mPopup.showAsDropDown(getAnchorView(), this.mDropDownHorizontalOffset, this.mDropDownVerticalOffset);
    this.mDropDownList.setSelection(-1);
    if (!this.mModal || this.mDropDownList.isInTouchMode())
      clearListSelection(); 
    if (!this.mModal)
      this.mHandler.post(this.mHideSelector); 
  }
  
  private static class DropDownListView extends ListView {
    public static final int INVALID_POSITION = -1;
    
    static final int NO_POSITION = -1;
    
    private static final String TAG = "ListPopupWindow.DropDownListView";
    
    private boolean mHijackFocus;
    
    private boolean mListSelectionHidden;
    
    public DropDownListView(Context param1Context, boolean param1Boolean) {
      super(param1Context, null, R.attr.dropDownListViewStyle);
      this.mHijackFocus = param1Boolean;
      setCacheColorHint(0);
    }
    
    private int lookForSelectablePosition(int param1Int, boolean param1Boolean) {
      byte b = -1;
      ListAdapter listAdapter = getAdapter();
      int i = b;
      if (listAdapter != null) {
        if (isInTouchMode())
          return b; 
      } else {
        return i;
      } 
      int j = listAdapter.getCount();
      if (!getAdapter().areAllItemsEnabled()) {
        if (param1Boolean) {
          i = Math.max(0, param1Int);
          while (true) {
            param1Int = i;
            if (i < j) {
              param1Int = i;
              if (!listAdapter.isEnabled(i)) {
                i++;
                continue;
              } 
            } 
            break;
          } 
        } else {
          i = Math.min(param1Int, j - 1);
          while (true) {
            param1Int = i;
            if (i >= 0) {
              param1Int = i;
              if (!listAdapter.isEnabled(i)) {
                i--;
                continue;
              } 
            } 
            break;
          } 
        } 
        i = b;
        if (param1Int >= 0) {
          i = b;
          if (param1Int < j)
            i = param1Int; 
        } 
        return i;
      } 
      i = b;
      if (param1Int >= 0) {
        i = b;
        if (param1Int < j)
          i = param1Int; 
      } 
      return i;
    }
    
    public boolean hasFocus() {
      return (this.mHijackFocus || super.hasFocus());
    }
    
    public boolean hasWindowFocus() {
      return (this.mHijackFocus || super.hasWindowFocus());
    }
    
    public boolean isFocused() {
      return (this.mHijackFocus || super.isFocused());
    }
    
    public boolean isInTouchMode() {
      return ((this.mHijackFocus && this.mListSelectionHidden) || super.isInTouchMode());
    }
    
    final int measureHeightOfChildrenCompat(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
      // Byte code:
      //   0: aload_0
      //   1: invokevirtual getListPaddingTop : ()I
      //   4: istore_2
      //   5: aload_0
      //   6: invokevirtual getListPaddingBottom : ()I
      //   9: istore_3
      //   10: aload_0
      //   11: invokevirtual getListPaddingLeft : ()I
      //   14: pop
      //   15: aload_0
      //   16: invokevirtual getListPaddingRight : ()I
      //   19: pop
      //   20: aload_0
      //   21: invokevirtual getDividerHeight : ()I
      //   24: istore #6
      //   26: aload_0
      //   27: invokevirtual getDivider : ()Landroid/graphics/drawable/Drawable;
      //   30: astore #7
      //   32: aload_0
      //   33: invokevirtual getAdapter : ()Landroid/widget/ListAdapter;
      //   36: astore #8
      //   38: aload #8
      //   40: ifnonnull -> 49
      //   43: iload_2
      //   44: iload_3
      //   45: iadd
      //   46: istore_1
      //   47: iload_1
      //   48: ireturn
      //   49: iload_2
      //   50: iload_3
      //   51: iadd
      //   52: istore_2
      //   53: iload #6
      //   55: ifle -> 232
      //   58: aload #7
      //   60: ifnull -> 232
      //   63: iconst_0
      //   64: istore_3
      //   65: aconst_null
      //   66: astore #7
      //   68: iconst_0
      //   69: istore #9
      //   71: aload #8
      //   73: invokeinterface getCount : ()I
      //   78: istore #10
      //   80: iconst_0
      //   81: istore #11
      //   83: iload #11
      //   85: iload #10
      //   87: if_icmpge -> 282
      //   90: aload #8
      //   92: iload #11
      //   94: invokeinterface getItemViewType : (I)I
      //   99: istore #12
      //   101: iload #9
      //   103: istore #13
      //   105: iload #12
      //   107: iload #9
      //   109: if_icmpeq -> 119
      //   112: aconst_null
      //   113: astore #7
      //   115: iload #12
      //   117: istore #13
      //   119: aload #8
      //   121: iload #11
      //   123: aload #7
      //   125: aload_0
      //   126: invokeinterface getView : (ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
      //   131: astore #7
      //   133: aload #7
      //   135: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
      //   138: astore #14
      //   140: aload #14
      //   142: ifnull -> 238
      //   145: aload #14
      //   147: getfield height : I
      //   150: ifle -> 238
      //   153: aload #14
      //   155: getfield height : I
      //   158: ldc 1073741824
      //   160: invokestatic makeMeasureSpec : (II)I
      //   163: istore #9
      //   165: aload #7
      //   167: iload_1
      //   168: iload #9
      //   170: invokevirtual measure : (II)V
      //   173: iload_2
      //   174: istore #9
      //   176: iload #11
      //   178: ifle -> 187
      //   181: iload_2
      //   182: iload #6
      //   184: iadd
      //   185: istore #9
      //   187: iload #9
      //   189: aload #7
      //   191: invokevirtual getMeasuredHeight : ()I
      //   194: iadd
      //   195: istore_2
      //   196: iload_2
      //   197: iload #4
      //   199: if_icmplt -> 248
      //   202: iload #5
      //   204: iflt -> 226
      //   207: iload #11
      //   209: iload #5
      //   211: if_icmple -> 226
      //   214: iload_3
      //   215: ifle -> 226
      //   218: iload_3
      //   219: istore_1
      //   220: iload_2
      //   221: iload #4
      //   223: if_icmpne -> 47
      //   226: iload #4
      //   228: istore_1
      //   229: goto -> 47
      //   232: iconst_0
      //   233: istore #6
      //   235: goto -> 63
      //   238: iconst_0
      //   239: iconst_0
      //   240: invokestatic makeMeasureSpec : (II)I
      //   243: istore #9
      //   245: goto -> 165
      //   248: iload_3
      //   249: istore #9
      //   251: iload #5
      //   253: iflt -> 269
      //   256: iload_3
      //   257: istore #9
      //   259: iload #11
      //   261: iload #5
      //   263: if_icmplt -> 269
      //   266: iload_2
      //   267: istore #9
      //   269: iinc #11, 1
      //   272: iload #9
      //   274: istore_3
      //   275: iload #13
      //   277: istore #9
      //   279: goto -> 83
      //   282: iload_2
      //   283: istore_1
      //   284: goto -> 47
    }
  }
  
  private class ListSelectorHider implements Runnable {
    private ListSelectorHider() {}
    
    public void run() {
      ListPopupWindow.this.clearListSelection();
    }
  }
  
  private class PopupDataSetObserver extends DataSetObserver {
    private PopupDataSetObserver() {}
    
    public void onChanged() {
      if (ListPopupWindow.this.isShowing())
        ListPopupWindow.this.show(); 
    }
    
    public void onInvalidated() {
      ListPopupWindow.this.dismiss();
    }
  }
  
  private class PopupScrollListener implements AbsListView.OnScrollListener {
    private PopupScrollListener() {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {
      if (param1Int == 1 && !ListPopupWindow.this.isInputMethodNotNeeded() && ListPopupWindow.this.mPopup.getContentView() != null) {
        ListPopupWindow.this.mHandler.removeCallbacks(ListPopupWindow.this.mResizePopupRunnable);
        ListPopupWindow.this.mResizePopupRunnable.run();
      } 
    }
  }
  
  private class PopupTouchInterceptor implements View.OnTouchListener {
    private PopupTouchInterceptor() {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int i = param1MotionEvent.getAction();
      int j = (int)param1MotionEvent.getX();
      int k = (int)param1MotionEvent.getY();
      if (i == 0 && ListPopupWindow.this.mPopup != null && ListPopupWindow.this.mPopup.isShowing() && j >= 0 && j < ListPopupWindow.this.mPopup.getWidth() && k >= 0 && k < ListPopupWindow.this.mPopup.getHeight()) {
        ListPopupWindow.this.mHandler.postDelayed(ListPopupWindow.this.mResizePopupRunnable, 250L);
        return false;
      } 
      if (i == 1)
        ListPopupWindow.this.mHandler.removeCallbacks(ListPopupWindow.this.mResizePopupRunnable); 
      return false;
    }
  }
  
  private class ResizePopupRunnable implements Runnable {
    private ResizePopupRunnable() {}
    
    public void run() {
      if (ListPopupWindow.this.mDropDownList != null && ListPopupWindow.this.mDropDownList.getCount() > ListPopupWindow.this.mDropDownList.getChildCount() && ListPopupWindow.this.mDropDownList.getChildCount() <= ListPopupWindow.this.mListItemExpandMaximum) {
        ListPopupWindow.this.mPopup.setInputMethodMode(2);
        ListPopupWindow.this.show();
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/widget/ListPopupWindow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */