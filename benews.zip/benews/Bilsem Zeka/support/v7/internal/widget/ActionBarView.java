package android.support.v7.internal.widget;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.internal.view.SupportMenu;
import android.support.v4.internal.view.SupportMenuItem;
import android.support.v7.app.ActionBar;
import android.support.v7.appcompat.R;
import android.support.v7.internal.view.menu.ActionMenuItem;
import android.support.v7.internal.view.menu.ActionMenuPresenter;
import android.support.v7.internal.view.menu.ActionMenuView;
import android.support.v7.internal.view.menu.MenuBuilder;
import android.support.v7.internal.view.menu.MenuItemImpl;
import android.support.v7.internal.view.menu.MenuPresenter;
import android.support.v7.internal.view.menu.MenuView;
import android.support.v7.internal.view.menu.SubMenuBuilder;
import android.support.v7.view.CollapsibleActionView;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.accessibility.AccessibilityEvent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class ActionBarView extends AbsActionBarView {
  private static final int DEFAULT_CUSTOM_GRAVITY = 19;
  
  public static final int DISPLAY_DEFAULT = 0;
  
  private static final int DISPLAY_RELAYOUT_MASK = 31;
  
  private static final String TAG = "ActionBarView";
  
  private ActionBar.OnNavigationListener mCallback;
  
  private Context mContext;
  
  private ActionBarContextView mContextView;
  
  private View mCustomNavView;
  
  private int mDisplayOptions = -1;
  
  View mExpandedActionView;
  
  private final View.OnClickListener mExpandedActionViewUpListener = new View.OnClickListener() {
      public void onClick(View param1View) {
        MenuItemImpl menuItemImpl = ActionBarView.this.mExpandedMenuPresenter.mCurrentExpandedItem;
        if (menuItemImpl != null)
          menuItemImpl.collapseActionView(); 
      }
    };
  
  private HomeView mExpandedHomeLayout;
  
  private ExpandedActionViewMenuPresenter mExpandedMenuPresenter;
  
  private HomeView mHomeLayout;
  
  private Drawable mIcon;
  
  private boolean mIncludeTabs;
  
  private int mIndeterminateProgressStyle;
  
  private ProgressBarICS mIndeterminateProgressView;
  
  private boolean mIsCollapsable;
  
  private boolean mIsCollapsed;
  
  private int mItemPadding;
  
  private LinearLayout mListNavLayout;
  
  private Drawable mLogo;
  
  private ActionMenuItem mLogoNavItem;
  
  private final AdapterViewICS.OnItemSelectedListener mNavItemSelectedListener = new AdapterViewICS.OnItemSelectedListener() {
      public void onItemSelected(AdapterViewICS<?> param1AdapterViewICS, View param1View, int param1Int, long param1Long) {
        if (ActionBarView.this.mCallback != null)
          ActionBarView.this.mCallback.onNavigationItemSelected(param1Int, param1Long); 
      }
      
      public void onNothingSelected(AdapterViewICS<?> param1AdapterViewICS) {}
    };
  
  private int mNavigationMode;
  
  private MenuBuilder mOptionsMenu;
  
  private int mProgressBarPadding;
  
  private int mProgressStyle;
  
  private ProgressBarICS mProgressView;
  
  private SpinnerICS mSpinner;
  
  private SpinnerAdapter mSpinnerAdapter;
  
  private CharSequence mSubtitle;
  
  private int mSubtitleStyleRes;
  
  private TextView mSubtitleView;
  
  private ScrollingTabContainerView mTabScrollView;
  
  private Runnable mTabSelector;
  
  private CharSequence mTitle;
  
  private LinearLayout mTitleLayout;
  
  private int mTitleStyleRes;
  
  private View mTitleUpView;
  
  private TextView mTitleView;
  
  private final View.OnClickListener mUpClickListener = new View.OnClickListener() {
      public void onClick(View param1View) {
        ActionBarView.this.mWindowCallback.onMenuItemSelected(0, (MenuItem)ActionBarView.this.mLogoNavItem);
      }
    };
  
  private boolean mUserTitle;
  
  Window.Callback mWindowCallback;
  
  public ActionBarView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.mContext = paramContext;
    setBackgroundResource(0);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.ActionBar, R.attr.actionBarStyle, 0);
    ApplicationInfo applicationInfo = paramContext.getApplicationInfo();
    PackageManager packageManager = paramContext.getPackageManager();
    this.mNavigationMode = typedArray.getInt(2, 0);
    this.mTitle = typedArray.getText(1);
    this.mSubtitle = typedArray.getText(4);
    this.mLogo = typedArray.getDrawable(8);
    if (this.mLogo == null && Build.VERSION.SDK_INT >= 9) {
      if (paramContext instanceof Activity)
        try {
          this.mLogo = packageManager.getActivityLogo(((Activity)paramContext).getComponentName());
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
          Log.e("ActionBarView", "Activity component name not found!", (Throwable)nameNotFoundException);
        }  
      if (this.mLogo == null)
        this.mLogo = applicationInfo.loadLogo(packageManager); 
    } 
    this.mIcon = typedArray.getDrawable(7);
    if (this.mIcon == null) {
      if (paramContext instanceof Activity)
        try {
          this.mIcon = packageManager.getActivityIcon(((Activity)paramContext).getComponentName());
        } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
          Log.e("ActionBarView", "Activity component name not found!", (Throwable)nameNotFoundException);
        }  
      if (this.mIcon == null)
        this.mIcon = applicationInfo.loadIcon(packageManager); 
    } 
    LayoutInflater layoutInflater = LayoutInflater.from(paramContext);
    int i = typedArray.getResourceId(14, R.layout.abc_action_bar_home);
    this.mHomeLayout = (HomeView)layoutInflater.inflate(i, this, false);
    this.mExpandedHomeLayout = (HomeView)layoutInflater.inflate(i, this, false);
    this.mExpandedHomeLayout.setUp(true);
    this.mExpandedHomeLayout.setOnClickListener(this.mExpandedActionViewUpListener);
    this.mExpandedHomeLayout.setContentDescription(getResources().getText(R.string.abc_action_bar_up_description));
    this.mTitleStyleRes = typedArray.getResourceId(5, 0);
    this.mSubtitleStyleRes = typedArray.getResourceId(6, 0);
    this.mProgressStyle = typedArray.getResourceId(15, 0);
    this.mIndeterminateProgressStyle = typedArray.getResourceId(16, 0);
    this.mProgressBarPadding = typedArray.getDimensionPixelOffset(17, 0);
    this.mItemPadding = typedArray.getDimensionPixelOffset(18, 0);
    setDisplayOptions(typedArray.getInt(3, 0));
    i = typedArray.getResourceId(13, 0);
    if (i != 0) {
      this.mCustomNavView = layoutInflater.inflate(i, this, false);
      this.mNavigationMode = 0;
      setDisplayOptions(this.mDisplayOptions | 0x10);
    } 
    this.mContentHeight = typedArray.getLayoutDimension(0, 0);
    typedArray.recycle();
    this.mLogoNavItem = new ActionMenuItem(paramContext, 0, 16908332, 0, 0, this.mTitle);
    this.mHomeLayout.setOnClickListener(this.mUpClickListener);
    this.mHomeLayout.setClickable(true);
    this.mHomeLayout.setFocusable(true);
  }
  
  private void configPresenters(MenuBuilder paramMenuBuilder) {
    if (paramMenuBuilder != null) {
      paramMenuBuilder.addMenuPresenter((MenuPresenter)this.mActionMenuPresenter);
      paramMenuBuilder.addMenuPresenter(this.mExpandedMenuPresenter);
    } else {
      this.mActionMenuPresenter.initForMenu(this.mContext, null);
      this.mExpandedMenuPresenter.initForMenu(this.mContext, null);
    } 
    this.mActionMenuPresenter.updateMenuView(true);
    this.mExpandedMenuPresenter.updateMenuView(true);
  }
  
  private void initTitle() {
    boolean bool = true;
    if (this.mTitleLayout == null) {
      boolean bool1;
      boolean bool2;
      byte b;
      this.mTitleLayout = (LinearLayout)LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this, false);
      this.mTitleView = (TextView)this.mTitleLayout.findViewById(R.id.action_bar_title);
      this.mSubtitleView = (TextView)this.mTitleLayout.findViewById(R.id.action_bar_subtitle);
      this.mTitleUpView = this.mTitleLayout.findViewById(R.id.up);
      this.mTitleLayout.setOnClickListener(this.mUpClickListener);
      if (this.mTitleStyleRes != 0)
        this.mTitleView.setTextAppearance(this.mContext, this.mTitleStyleRes); 
      if (this.mTitle != null)
        this.mTitleView.setText(this.mTitle); 
      if (this.mSubtitleStyleRes != 0)
        this.mSubtitleView.setTextAppearance(this.mContext, this.mSubtitleStyleRes); 
      if (this.mSubtitle != null) {
        this.mSubtitleView.setText(this.mSubtitle);
        this.mSubtitleView.setVisibility(0);
      } 
      if ((this.mDisplayOptions & 0x4) != 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if ((this.mDisplayOptions & 0x2) != 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      View view = this.mTitleUpView;
      if (!bool2) {
        if (bool1) {
          b = 0;
        } else {
          b = 4;
        } 
      } else {
        b = 8;
      } 
      view.setVisibility(b);
      LinearLayout linearLayout = this.mTitleLayout;
      if (!bool1 || bool2)
        bool = false; 
      linearLayout.setEnabled(bool);
    } 
    addView((View)this.mTitleLayout);
    if (this.mExpandedActionView != null || (TextUtils.isEmpty(this.mTitle) && TextUtils.isEmpty(this.mSubtitle)))
      this.mTitleLayout.setVisibility(8); 
  }
  
  private void setTitleImpl(CharSequence paramCharSequence) {
    byte b = 0;
    this.mTitle = paramCharSequence;
    if (this.mTitleView != null) {
      byte b1;
      this.mTitleView.setText(paramCharSequence);
      if (this.mExpandedActionView == null && (this.mDisplayOptions & 0x8) != 0 && (!TextUtils.isEmpty(this.mTitle) || !TextUtils.isEmpty(this.mSubtitle))) {
        b1 = 1;
      } else {
        b1 = 0;
      } 
      LinearLayout linearLayout = this.mTitleLayout;
      if (b1) {
        b1 = b;
      } else {
        b1 = 8;
      } 
      linearLayout.setVisibility(b1);
    } 
    if (this.mLogoNavItem != null)
      this.mLogoNavItem.setTitle(paramCharSequence); 
  }
  
  public void collapseActionView() {
    MenuItemImpl menuItemImpl;
    if (this.mExpandedMenuPresenter == null) {
      menuItemImpl = null;
    } else {
      menuItemImpl = this.mExpandedMenuPresenter.mCurrentExpandedItem;
    } 
    if (menuItemImpl != null)
      menuItemImpl.collapseActionView(); 
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new ActionBar.LayoutParams(19);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new ActionBar.LayoutParams(getContext(), paramAttributeSet);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    ViewGroup.LayoutParams layoutParams = paramLayoutParams;
    if (paramLayoutParams == null)
      layoutParams = generateDefaultLayoutParams(); 
    return layoutParams;
  }
  
  public View getCustomNavigationView() {
    return this.mCustomNavView;
  }
  
  public int getDisplayOptions() {
    return this.mDisplayOptions;
  }
  
  public SpinnerAdapter getDropdownAdapter() {
    return this.mSpinnerAdapter;
  }
  
  public int getDropdownSelectedPosition() {
    return this.mSpinner.getSelectedItemPosition();
  }
  
  public int getNavigationMode() {
    return this.mNavigationMode;
  }
  
  public CharSequence getSubtitle() {
    return this.mSubtitle;
  }
  
  public CharSequence getTitle() {
    return this.mTitle;
  }
  
  public boolean hasEmbeddedTabs() {
    return this.mIncludeTabs;
  }
  
  public boolean hasExpandedActionView() {
    return (this.mExpandedMenuPresenter != null && this.mExpandedMenuPresenter.mCurrentExpandedItem != null);
  }
  
  public void initIndeterminateProgress() {
    this.mIndeterminateProgressView = new ProgressBarICS(this.mContext, null, 0, this.mIndeterminateProgressStyle);
    this.mIndeterminateProgressView.setId(R.id.progress_circular);
    this.mIndeterminateProgressView.setVisibility(8);
    addView(this.mIndeterminateProgressView);
  }
  
  public void initProgress() {
    this.mProgressView = new ProgressBarICS(this.mContext, null, 0, this.mProgressStyle);
    this.mProgressView.setId(R.id.progress_horizontal);
    this.mProgressView.setMax(10000);
    this.mProgressView.setVisibility(8);
    addView(this.mProgressView);
  }
  
  public boolean isCollapsed() {
    return this.mIsCollapsed;
  }
  
  public boolean isSplitActionBar() {
    return this.mSplitActionBar;
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.mTitleView = null;
    this.mSubtitleView = null;
    this.mTitleUpView = null;
    if (this.mTitleLayout != null && this.mTitleLayout.getParent() == this)
      removeView((View)this.mTitleLayout); 
    this.mTitleLayout = null;
    if ((this.mDisplayOptions & 0x8) != 0)
      initTitle(); 
    if (this.mTabScrollView != null && this.mIncludeTabs) {
      ViewGroup.LayoutParams layoutParams = this.mTabScrollView.getLayoutParams();
      if (layoutParams != null) {
        layoutParams.width = -2;
        layoutParams.height = -1;
      } 
      this.mTabScrollView.setAllowCollapse(true);
    } 
    if (this.mProgressView != null) {
      removeView(this.mProgressView);
      initProgress();
    } 
    if (this.mIndeterminateProgressView != null) {
      removeView(this.mIndeterminateProgressView);
      initIndeterminateProgress();
    } 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.mTabSelector);
    if (this.mActionMenuPresenter != null) {
      this.mActionMenuPresenter.hideOverflowMenu();
      this.mActionMenuPresenter.hideSubMenus();
    } 
  }
  
  protected void onFinishInflate() {
    super.onFinishInflate();
    addView((View)this.mHomeLayout);
    if (this.mCustomNavView != null && (this.mDisplayOptions & 0x10) != 0) {
      ViewParent viewParent = this.mCustomNavView.getParent();
      if (viewParent != this) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(this.mCustomNavView); 
        addView(this.mCustomNavView);
      } 
    } 
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getPaddingLeft : ()I
    //   4: istore #6
    //   6: aload_0
    //   7: invokevirtual getPaddingTop : ()I
    //   10: istore #7
    //   12: iload #5
    //   14: iload_3
    //   15: isub
    //   16: aload_0
    //   17: invokevirtual getPaddingTop : ()I
    //   20: isub
    //   21: aload_0
    //   22: invokevirtual getPaddingBottom : ()I
    //   25: isub
    //   26: istore #8
    //   28: iload #8
    //   30: ifgt -> 34
    //   33: return
    //   34: aload_0
    //   35: getfield mExpandedActionView : Landroid/view/View;
    //   38: ifnull -> 625
    //   41: aload_0
    //   42: getfield mExpandedHomeLayout : Landroid/support/v7/internal/widget/ActionBarView$HomeView;
    //   45: astore #9
    //   47: iload #6
    //   49: istore #10
    //   51: aload #9
    //   53: invokevirtual getVisibility : ()I
    //   56: bipush #8
    //   58: if_icmpeq -> 88
    //   61: aload #9
    //   63: invokevirtual getLeftOffset : ()I
    //   66: istore_3
    //   67: iload #6
    //   69: aload_0
    //   70: aload #9
    //   72: iload #6
    //   74: iload_3
    //   75: iadd
    //   76: iload #7
    //   78: iload #8
    //   80: invokevirtual positionChild : (Landroid/view/View;III)I
    //   83: iload_3
    //   84: iadd
    //   85: iadd
    //   86: istore #10
    //   88: iload #10
    //   90: istore_3
    //   91: aload_0
    //   92: getfield mExpandedActionView : Landroid/view/View;
    //   95: ifnonnull -> 195
    //   98: aload_0
    //   99: getfield mTitleLayout : Landroid/widget/LinearLayout;
    //   102: ifnull -> 634
    //   105: aload_0
    //   106: getfield mTitleLayout : Landroid/widget/LinearLayout;
    //   109: invokevirtual getVisibility : ()I
    //   112: bipush #8
    //   114: if_icmpeq -> 634
    //   117: aload_0
    //   118: getfield mDisplayOptions : I
    //   121: bipush #8
    //   123: iand
    //   124: ifeq -> 634
    //   127: iconst_1
    //   128: istore #6
    //   130: iload #10
    //   132: istore #5
    //   134: iload #6
    //   136: ifeq -> 158
    //   139: iload #10
    //   141: aload_0
    //   142: aload_0
    //   143: getfield mTitleLayout : Landroid/widget/LinearLayout;
    //   146: iload #10
    //   148: iload #7
    //   150: iload #8
    //   152: invokevirtual positionChild : (Landroid/view/View;III)I
    //   155: iadd
    //   156: istore #5
    //   158: iload #5
    //   160: istore_3
    //   161: aload_0
    //   162: getfield mNavigationMode : I
    //   165: tableswitch default -> 192, 0 -> 195, 1 -> 640, 2 -> 690
    //   192: iload #5
    //   194: istore_3
    //   195: iload #4
    //   197: iload_2
    //   198: isub
    //   199: aload_0
    //   200: invokevirtual getPaddingRight : ()I
    //   203: isub
    //   204: istore_2
    //   205: iload_2
    //   206: istore #4
    //   208: aload_0
    //   209: getfield mMenuView : Landroid/support/v7/internal/view/menu/ActionMenuView;
    //   212: ifnull -> 254
    //   215: iload_2
    //   216: istore #4
    //   218: aload_0
    //   219: getfield mMenuView : Landroid/support/v7/internal/view/menu/ActionMenuView;
    //   222: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   225: aload_0
    //   226: if_acmpne -> 254
    //   229: aload_0
    //   230: aload_0
    //   231: getfield mMenuView : Landroid/support/v7/internal/view/menu/ActionMenuView;
    //   234: iload_2
    //   235: iload #7
    //   237: iload #8
    //   239: invokevirtual positionChildInverse : (Landroid/view/View;III)I
    //   242: pop
    //   243: iload_2
    //   244: aload_0
    //   245: getfield mMenuView : Landroid/support/v7/internal/view/menu/ActionMenuView;
    //   248: invokevirtual getMeasuredWidth : ()I
    //   251: isub
    //   252: istore #4
    //   254: iload #4
    //   256: istore_2
    //   257: aload_0
    //   258: getfield mIndeterminateProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   261: ifnull -> 305
    //   264: iload #4
    //   266: istore_2
    //   267: aload_0
    //   268: getfield mIndeterminateProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   271: invokevirtual getVisibility : ()I
    //   274: bipush #8
    //   276: if_icmpeq -> 305
    //   279: aload_0
    //   280: aload_0
    //   281: getfield mIndeterminateProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   284: iload #4
    //   286: iload #7
    //   288: iload #8
    //   290: invokevirtual positionChildInverse : (Landroid/view/View;III)I
    //   293: pop
    //   294: iload #4
    //   296: aload_0
    //   297: getfield mIndeterminateProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   300: invokevirtual getMeasuredWidth : ()I
    //   303: isub
    //   304: istore_2
    //   305: aconst_null
    //   306: astore #11
    //   308: aload_0
    //   309: getfield mExpandedActionView : Landroid/view/View;
    //   312: ifnull -> 740
    //   315: aload_0
    //   316: getfield mExpandedActionView : Landroid/view/View;
    //   319: astore #9
    //   321: aload #9
    //   323: ifnull -> 572
    //   326: aload #9
    //   328: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   331: astore #11
    //   333: aload #11
    //   335: instanceof android/support/v7/app/ActionBar$LayoutParams
    //   338: ifeq -> 774
    //   341: aload #11
    //   343: checkcast android/support/v7/app/ActionBar$LayoutParams
    //   346: astore #11
    //   348: aload #11
    //   350: ifnull -> 780
    //   353: aload #11
    //   355: getfield gravity : I
    //   358: istore #5
    //   360: aload #9
    //   362: invokevirtual getMeasuredWidth : ()I
    //   365: istore #12
    //   367: iconst_0
    //   368: istore #10
    //   370: iconst_0
    //   371: istore #6
    //   373: iload_2
    //   374: istore #7
    //   376: iload_3
    //   377: istore #4
    //   379: aload #11
    //   381: ifnull -> 416
    //   384: iload_3
    //   385: aload #11
    //   387: getfield leftMargin : I
    //   390: iadd
    //   391: istore #4
    //   393: iload_2
    //   394: aload #11
    //   396: getfield rightMargin : I
    //   399: isub
    //   400: istore #7
    //   402: aload #11
    //   404: getfield topMargin : I
    //   407: istore #10
    //   409: aload #11
    //   411: getfield bottomMargin : I
    //   414: istore #6
    //   416: iload #5
    //   418: bipush #7
    //   420: iand
    //   421: istore_3
    //   422: iload_3
    //   423: iconst_1
    //   424: if_icmpne -> 801
    //   427: aload_0
    //   428: invokevirtual getWidth : ()I
    //   431: iload #12
    //   433: isub
    //   434: iconst_2
    //   435: idiv
    //   436: istore_2
    //   437: iload_2
    //   438: iload #4
    //   440: if_icmpge -> 787
    //   443: iconst_3
    //   444: istore_3
    //   445: iconst_0
    //   446: istore #8
    //   448: iload #8
    //   450: istore_2
    //   451: iload_3
    //   452: tableswitch default -> 488, 1 -> 812, 2 -> 491, 3 -> 825, 4 -> 491, 5 -> 831
    //   488: iload #8
    //   490: istore_2
    //   491: iload #5
    //   493: bipush #112
    //   495: iand
    //   496: istore_3
    //   497: iload #5
    //   499: iconst_m1
    //   500: if_icmpne -> 506
    //   503: bipush #16
    //   505: istore_3
    //   506: iconst_0
    //   507: istore #4
    //   509: iload_3
    //   510: lookupswitch default -> 544, 16 -> 840, 48 -> 868, 80 -> 879
    //   544: iload #4
    //   546: istore_3
    //   547: aload #9
    //   549: invokevirtual getMeasuredWidth : ()I
    //   552: istore #4
    //   554: aload #9
    //   556: iload_2
    //   557: iload_3
    //   558: iload_2
    //   559: iload #4
    //   561: iadd
    //   562: aload #9
    //   564: invokevirtual getMeasuredHeight : ()I
    //   567: iload_3
    //   568: iadd
    //   569: invokevirtual layout : (IIII)V
    //   572: aload_0
    //   573: getfield mProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   576: ifnull -> 33
    //   579: aload_0
    //   580: getfield mProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   583: invokevirtual bringToFront : ()V
    //   586: aload_0
    //   587: getfield mProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   590: invokevirtual getMeasuredHeight : ()I
    //   593: iconst_2
    //   594: idiv
    //   595: istore_2
    //   596: aload_0
    //   597: getfield mProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   600: aload_0
    //   601: getfield mProgressBarPadding : I
    //   604: iload_2
    //   605: ineg
    //   606: aload_0
    //   607: getfield mProgressBarPadding : I
    //   610: aload_0
    //   611: getfield mProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   614: invokevirtual getMeasuredWidth : ()I
    //   617: iadd
    //   618: iload_2
    //   619: invokevirtual layout : (IIII)V
    //   622: goto -> 33
    //   625: aload_0
    //   626: getfield mHomeLayout : Landroid/support/v7/internal/widget/ActionBarView$HomeView;
    //   629: astore #9
    //   631: goto -> 47
    //   634: iconst_0
    //   635: istore #6
    //   637: goto -> 130
    //   640: iload #5
    //   642: istore_3
    //   643: aload_0
    //   644: getfield mListNavLayout : Landroid/widget/LinearLayout;
    //   647: ifnull -> 195
    //   650: iload #5
    //   652: istore_3
    //   653: iload #6
    //   655: ifeq -> 666
    //   658: iload #5
    //   660: aload_0
    //   661: getfield mItemPadding : I
    //   664: iadd
    //   665: istore_3
    //   666: iload_3
    //   667: aload_0
    //   668: aload_0
    //   669: getfield mListNavLayout : Landroid/widget/LinearLayout;
    //   672: iload_3
    //   673: iload #7
    //   675: iload #8
    //   677: invokevirtual positionChild : (Landroid/view/View;III)I
    //   680: aload_0
    //   681: getfield mItemPadding : I
    //   684: iadd
    //   685: iadd
    //   686: istore_3
    //   687: goto -> 195
    //   690: iload #5
    //   692: istore_3
    //   693: aload_0
    //   694: getfield mTabScrollView : Landroid/support/v7/internal/widget/ScrollingTabContainerView;
    //   697: ifnull -> 195
    //   700: iload #5
    //   702: istore_3
    //   703: iload #6
    //   705: ifeq -> 716
    //   708: iload #5
    //   710: aload_0
    //   711: getfield mItemPadding : I
    //   714: iadd
    //   715: istore_3
    //   716: iload_3
    //   717: aload_0
    //   718: aload_0
    //   719: getfield mTabScrollView : Landroid/support/v7/internal/widget/ScrollingTabContainerView;
    //   722: iload_3
    //   723: iload #7
    //   725: iload #8
    //   727: invokevirtual positionChild : (Landroid/view/View;III)I
    //   730: aload_0
    //   731: getfield mItemPadding : I
    //   734: iadd
    //   735: iadd
    //   736: istore_3
    //   737: goto -> 195
    //   740: aload #11
    //   742: astore #9
    //   744: aload_0
    //   745: getfield mDisplayOptions : I
    //   748: bipush #16
    //   750: iand
    //   751: ifeq -> 321
    //   754: aload #11
    //   756: astore #9
    //   758: aload_0
    //   759: getfield mCustomNavView : Landroid/view/View;
    //   762: ifnull -> 321
    //   765: aload_0
    //   766: getfield mCustomNavView : Landroid/view/View;
    //   769: astore #9
    //   771: goto -> 321
    //   774: aconst_null
    //   775: astore #11
    //   777: goto -> 348
    //   780: bipush #19
    //   782: istore #5
    //   784: goto -> 360
    //   787: iload_2
    //   788: iload #12
    //   790: iadd
    //   791: iload #7
    //   793: if_icmple -> 445
    //   796: iconst_5
    //   797: istore_3
    //   798: goto -> 445
    //   801: iload #5
    //   803: iconst_m1
    //   804: if_icmpne -> 445
    //   807: iconst_3
    //   808: istore_3
    //   809: goto -> 445
    //   812: aload_0
    //   813: invokevirtual getWidth : ()I
    //   816: iload #12
    //   818: isub
    //   819: iconst_2
    //   820: idiv
    //   821: istore_2
    //   822: goto -> 491
    //   825: iload #4
    //   827: istore_2
    //   828: goto -> 491
    //   831: iload #7
    //   833: iload #12
    //   835: isub
    //   836: istore_2
    //   837: goto -> 491
    //   840: aload_0
    //   841: invokevirtual getPaddingTop : ()I
    //   844: istore_3
    //   845: aload_0
    //   846: invokevirtual getHeight : ()I
    //   849: aload_0
    //   850: invokevirtual getPaddingBottom : ()I
    //   853: isub
    //   854: iload_3
    //   855: isub
    //   856: aload #9
    //   858: invokevirtual getMeasuredHeight : ()I
    //   861: isub
    //   862: iconst_2
    //   863: idiv
    //   864: istore_3
    //   865: goto -> 547
    //   868: aload_0
    //   869: invokevirtual getPaddingTop : ()I
    //   872: iload #10
    //   874: iadd
    //   875: istore_3
    //   876: goto -> 547
    //   879: aload_0
    //   880: invokevirtual getHeight : ()I
    //   883: aload_0
    //   884: invokevirtual getPaddingBottom : ()I
    //   887: isub
    //   888: aload #9
    //   890: invokevirtual getMeasuredHeight : ()I
    //   893: isub
    //   894: iload #6
    //   896: isub
    //   897: istore_3
    //   898: goto -> 547
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildCount : ()I
    //   4: istore_3
    //   5: aload_0
    //   6: getfield mIsCollapsable : Z
    //   9: ifeq -> 102
    //   12: iconst_0
    //   13: istore #4
    //   15: iconst_0
    //   16: istore #5
    //   18: iload #5
    //   20: iload_3
    //   21: if_icmpge -> 85
    //   24: aload_0
    //   25: iload #5
    //   27: invokevirtual getChildAt : (I)Landroid/view/View;
    //   30: astore #6
    //   32: iload #4
    //   34: istore #7
    //   36: aload #6
    //   38: invokevirtual getVisibility : ()I
    //   41: bipush #8
    //   43: if_icmpeq -> 75
    //   46: aload #6
    //   48: aload_0
    //   49: getfield mMenuView : Landroid/support/v7/internal/view/menu/ActionMenuView;
    //   52: if_acmpne -> 69
    //   55: iload #4
    //   57: istore #7
    //   59: aload_0
    //   60: getfield mMenuView : Landroid/support/v7/internal/view/menu/ActionMenuView;
    //   63: invokevirtual getChildCount : ()I
    //   66: ifeq -> 75
    //   69: iload #4
    //   71: iconst_1
    //   72: iadd
    //   73: istore #7
    //   75: iinc #5, 1
    //   78: iload #7
    //   80: istore #4
    //   82: goto -> 18
    //   85: iload #4
    //   87: ifne -> 102
    //   90: aload_0
    //   91: iconst_0
    //   92: iconst_0
    //   93: invokevirtual setMeasuredDimension : (II)V
    //   96: aload_0
    //   97: iconst_1
    //   98: putfield mIsCollapsed : Z
    //   101: return
    //   102: aload_0
    //   103: iconst_0
    //   104: putfield mIsCollapsed : Z
    //   107: iload_1
    //   108: invokestatic getMode : (I)I
    //   111: ldc_w 1073741824
    //   114: if_icmpeq -> 157
    //   117: new java/lang/IllegalStateException
    //   120: dup
    //   121: new java/lang/StringBuilder
    //   124: dup
    //   125: invokespecial <init> : ()V
    //   128: aload_0
    //   129: invokevirtual getClass : ()Ljava/lang/Class;
    //   132: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   135: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   138: ldc_w ' can only be used '
    //   141: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   144: ldc_w 'with android:layout_width="MATCH_PARENT" (or fill_parent)'
    //   147: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: invokevirtual toString : ()Ljava/lang/String;
    //   153: invokespecial <init> : (Ljava/lang/String;)V
    //   156: athrow
    //   157: iload_2
    //   158: invokestatic getMode : (I)I
    //   161: ldc_w -2147483648
    //   164: if_icmpeq -> 207
    //   167: new java/lang/IllegalStateException
    //   170: dup
    //   171: new java/lang/StringBuilder
    //   174: dup
    //   175: invokespecial <init> : ()V
    //   178: aload_0
    //   179: invokevirtual getClass : ()Ljava/lang/Class;
    //   182: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   185: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   188: ldc_w ' can only be used '
    //   191: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   194: ldc_w 'with android:layout_height="wrap_content"'
    //   197: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   200: invokevirtual toString : ()Ljava/lang/String;
    //   203: invokespecial <init> : (Ljava/lang/String;)V
    //   206: athrow
    //   207: iload_1
    //   208: invokestatic getSize : (I)I
    //   211: istore #8
    //   213: aload_0
    //   214: getfield mContentHeight : I
    //   217: ifle -> 928
    //   220: aload_0
    //   221: getfield mContentHeight : I
    //   224: istore #4
    //   226: aload_0
    //   227: invokevirtual getPaddingTop : ()I
    //   230: aload_0
    //   231: invokevirtual getPaddingBottom : ()I
    //   234: iadd
    //   235: istore #9
    //   237: aload_0
    //   238: invokevirtual getPaddingLeft : ()I
    //   241: istore_1
    //   242: aload_0
    //   243: invokevirtual getPaddingRight : ()I
    //   246: istore_2
    //   247: iload #4
    //   249: iload #9
    //   251: isub
    //   252: istore #10
    //   254: iload #10
    //   256: ldc_w -2147483648
    //   259: invokestatic makeMeasureSpec : (II)I
    //   262: istore #11
    //   264: iload #8
    //   266: iload_1
    //   267: isub
    //   268: iload_2
    //   269: isub
    //   270: istore_2
    //   271: iload_2
    //   272: iconst_2
    //   273: idiv
    //   274: istore #5
    //   276: iload #5
    //   278: istore #12
    //   280: aload_0
    //   281: getfield mExpandedActionView : Landroid/view/View;
    //   284: ifnull -> 937
    //   287: aload_0
    //   288: getfield mExpandedHomeLayout : Landroid/support/v7/internal/widget/ActionBarView$HomeView;
    //   291: astore #6
    //   293: iload_2
    //   294: istore #7
    //   296: aload #6
    //   298: invokevirtual getVisibility : ()I
    //   301: bipush #8
    //   303: if_icmpeq -> 374
    //   306: aload #6
    //   308: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   311: astore #13
    //   313: aload #13
    //   315: getfield width : I
    //   318: ifge -> 946
    //   321: iload_2
    //   322: ldc_w -2147483648
    //   325: invokestatic makeMeasureSpec : (II)I
    //   328: istore_1
    //   329: aload #6
    //   331: iload_1
    //   332: iload #10
    //   334: ldc_w 1073741824
    //   337: invokestatic makeMeasureSpec : (II)I
    //   340: invokevirtual measure : (II)V
    //   343: aload #6
    //   345: invokevirtual getMeasuredWidth : ()I
    //   348: aload #6
    //   350: invokevirtual getLeftOffset : ()I
    //   353: iadd
    //   354: istore_1
    //   355: iconst_0
    //   356: iload_2
    //   357: iload_1
    //   358: isub
    //   359: invokestatic max : (II)I
    //   362: istore #7
    //   364: iconst_0
    //   365: iload #7
    //   367: iload_1
    //   368: isub
    //   369: invokestatic max : (II)I
    //   372: istore #5
    //   374: iload #7
    //   376: istore_2
    //   377: iload #12
    //   379: istore_1
    //   380: aload_0
    //   381: getfield mMenuView : Landroid/support/v7/internal/view/menu/ActionMenuView;
    //   384: ifnull -> 433
    //   387: iload #7
    //   389: istore_2
    //   390: iload #12
    //   392: istore_1
    //   393: aload_0
    //   394: getfield mMenuView : Landroid/support/v7/internal/view/menu/ActionMenuView;
    //   397: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   400: aload_0
    //   401: if_acmpne -> 433
    //   404: aload_0
    //   405: aload_0
    //   406: getfield mMenuView : Landroid/support/v7/internal/view/menu/ActionMenuView;
    //   409: iload #7
    //   411: iload #11
    //   413: iconst_0
    //   414: invokevirtual measureChildView : (Landroid/view/View;III)I
    //   417: istore_2
    //   418: iconst_0
    //   419: iload #12
    //   421: aload_0
    //   422: getfield mMenuView : Landroid/support/v7/internal/view/menu/ActionMenuView;
    //   425: invokevirtual getMeasuredWidth : ()I
    //   428: isub
    //   429: invokestatic max : (II)I
    //   432: istore_1
    //   433: iload_2
    //   434: istore #7
    //   436: iload_1
    //   437: istore #12
    //   439: aload_0
    //   440: getfield mIndeterminateProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   443: ifnull -> 493
    //   446: iload_2
    //   447: istore #7
    //   449: iload_1
    //   450: istore #12
    //   452: aload_0
    //   453: getfield mIndeterminateProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   456: invokevirtual getVisibility : ()I
    //   459: bipush #8
    //   461: if_icmpeq -> 493
    //   464: aload_0
    //   465: aload_0
    //   466: getfield mIndeterminateProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   469: iload_2
    //   470: iload #11
    //   472: iconst_0
    //   473: invokevirtual measureChildView : (Landroid/view/View;III)I
    //   476: istore #7
    //   478: iconst_0
    //   479: iload_1
    //   480: aload_0
    //   481: getfield mIndeterminateProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   484: invokevirtual getMeasuredWidth : ()I
    //   487: isub
    //   488: invokestatic max : (II)I
    //   491: istore #12
    //   493: aload_0
    //   494: getfield mTitleLayout : Landroid/widget/LinearLayout;
    //   497: ifnull -> 961
    //   500: aload_0
    //   501: getfield mTitleLayout : Landroid/widget/LinearLayout;
    //   504: invokevirtual getVisibility : ()I
    //   507: bipush #8
    //   509: if_icmpeq -> 961
    //   512: aload_0
    //   513: getfield mDisplayOptions : I
    //   516: bipush #8
    //   518: iand
    //   519: ifeq -> 961
    //   522: iconst_1
    //   523: istore #11
    //   525: iload #7
    //   527: istore_1
    //   528: iload #5
    //   530: istore_2
    //   531: aload_0
    //   532: getfield mExpandedActionView : Landroid/view/View;
    //   535: ifnonnull -> 570
    //   538: aload_0
    //   539: getfield mNavigationMode : I
    //   542: tableswitch default -> 564, 1 -> 967, 2 -> 1072
    //   564: iload #5
    //   566: istore_2
    //   567: iload #7
    //   569: istore_1
    //   570: aconst_null
    //   571: astore #13
    //   573: aload_0
    //   574: getfield mExpandedActionView : Landroid/view/View;
    //   577: ifnull -> 1177
    //   580: aload_0
    //   581: getfield mExpandedActionView : Landroid/view/View;
    //   584: astore #6
    //   586: iload_1
    //   587: istore #5
    //   589: aload #6
    //   591: ifnull -> 828
    //   594: aload_0
    //   595: aload #6
    //   597: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   600: invokevirtual generateLayoutParams : (Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    //   603: astore #14
    //   605: aload #14
    //   607: instanceof android/support/v7/app/ActionBar$LayoutParams
    //   610: ifeq -> 1211
    //   613: aload #14
    //   615: checkcast android/support/v7/app/ActionBar$LayoutParams
    //   618: astore #13
    //   620: iconst_0
    //   621: istore #7
    //   623: iconst_0
    //   624: istore #15
    //   626: aload #13
    //   628: ifnull -> 657
    //   631: aload #13
    //   633: getfield leftMargin : I
    //   636: aload #13
    //   638: getfield rightMargin : I
    //   641: iadd
    //   642: istore #7
    //   644: aload #13
    //   646: getfield topMargin : I
    //   649: aload #13
    //   651: getfield bottomMargin : I
    //   654: iadd
    //   655: istore #15
    //   657: aload_0
    //   658: getfield mContentHeight : I
    //   661: ifgt -> 1217
    //   664: ldc_w -2147483648
    //   667: istore #5
    //   669: iload #10
    //   671: istore #16
    //   673: aload #14
    //   675: getfield height : I
    //   678: iflt -> 693
    //   681: aload #14
    //   683: getfield height : I
    //   686: iload #10
    //   688: invokestatic min : (II)I
    //   691: istore #16
    //   693: iconst_0
    //   694: iload #16
    //   696: iload #15
    //   698: isub
    //   699: invokestatic max : (II)I
    //   702: istore #17
    //   704: aload #14
    //   706: getfield width : I
    //   709: bipush #-2
    //   711: if_icmpeq -> 1243
    //   714: ldc_w 1073741824
    //   717: istore #15
    //   719: aload #14
    //   721: getfield width : I
    //   724: iflt -> 1251
    //   727: aload #14
    //   729: getfield width : I
    //   732: iload_1
    //   733: invokestatic min : (II)I
    //   736: istore #16
    //   738: iconst_0
    //   739: iload #16
    //   741: iload #7
    //   743: isub
    //   744: invokestatic max : (II)I
    //   747: istore #18
    //   749: aload #13
    //   751: ifnull -> 1257
    //   754: aload #13
    //   756: getfield gravity : I
    //   759: istore #10
    //   761: iload #18
    //   763: istore #16
    //   765: iload #10
    //   767: bipush #7
    //   769: iand
    //   770: iconst_1
    //   771: if_icmpne -> 797
    //   774: iload #18
    //   776: istore #16
    //   778: aload #14
    //   780: getfield width : I
    //   783: iconst_m1
    //   784: if_icmpne -> 797
    //   787: iload_2
    //   788: iload #12
    //   790: invokestatic min : (II)I
    //   793: iconst_2
    //   794: imul
    //   795: istore #16
    //   797: aload #6
    //   799: iload #16
    //   801: iload #15
    //   803: invokestatic makeMeasureSpec : (II)I
    //   806: iload #17
    //   808: iload #5
    //   810: invokestatic makeMeasureSpec : (II)I
    //   813: invokevirtual measure : (II)V
    //   816: iload_1
    //   817: aload #6
    //   819: invokevirtual getMeasuredWidth : ()I
    //   822: iload #7
    //   824: iadd
    //   825: isub
    //   826: istore #5
    //   828: aload_0
    //   829: getfield mExpandedActionView : Landroid/view/View;
    //   832: ifnonnull -> 876
    //   835: iload #11
    //   837: ifeq -> 876
    //   840: aload_0
    //   841: aload_0
    //   842: getfield mTitleLayout : Landroid/widget/LinearLayout;
    //   845: iload #5
    //   847: aload_0
    //   848: getfield mContentHeight : I
    //   851: ldc_w 1073741824
    //   854: invokestatic makeMeasureSpec : (II)I
    //   857: iconst_0
    //   858: invokevirtual measureChildView : (Landroid/view/View;III)I
    //   861: pop
    //   862: iconst_0
    //   863: iload_2
    //   864: aload_0
    //   865: getfield mTitleLayout : Landroid/widget/LinearLayout;
    //   868: invokevirtual getMeasuredWidth : ()I
    //   871: isub
    //   872: invokestatic max : (II)I
    //   875: pop
    //   876: aload_0
    //   877: getfield mContentHeight : I
    //   880: ifgt -> 1344
    //   883: iconst_0
    //   884: istore #5
    //   886: iconst_0
    //   887: istore_2
    //   888: iload_2
    //   889: iload_3
    //   890: if_icmpge -> 1264
    //   893: aload_0
    //   894: iload_2
    //   895: invokevirtual getChildAt : (I)Landroid/view/View;
    //   898: invokevirtual getMeasuredHeight : ()I
    //   901: iload #9
    //   903: iadd
    //   904: istore #7
    //   906: iload #5
    //   908: istore_1
    //   909: iload #7
    //   911: iload #5
    //   913: if_icmple -> 919
    //   916: iload #7
    //   918: istore_1
    //   919: iinc #2, 1
    //   922: iload_1
    //   923: istore #5
    //   925: goto -> 888
    //   928: iload_2
    //   929: invokestatic getSize : (I)I
    //   932: istore #4
    //   934: goto -> 226
    //   937: aload_0
    //   938: getfield mHomeLayout : Landroid/support/v7/internal/widget/ActionBarView$HomeView;
    //   941: astore #6
    //   943: goto -> 293
    //   946: aload #13
    //   948: getfield width : I
    //   951: ldc_w 1073741824
    //   954: invokestatic makeMeasureSpec : (II)I
    //   957: istore_1
    //   958: goto -> 329
    //   961: iconst_0
    //   962: istore #11
    //   964: goto -> 525
    //   967: iload #7
    //   969: istore_1
    //   970: iload #5
    //   972: istore_2
    //   973: aload_0
    //   974: getfield mListNavLayout : Landroid/widget/LinearLayout;
    //   977: ifnull -> 570
    //   980: iload #11
    //   982: ifeq -> 1064
    //   985: aload_0
    //   986: getfield mItemPadding : I
    //   989: iconst_2
    //   990: imul
    //   991: istore_1
    //   992: iconst_0
    //   993: iload #7
    //   995: iload_1
    //   996: isub
    //   997: invokestatic max : (II)I
    //   1000: istore_2
    //   1001: iconst_0
    //   1002: iload #5
    //   1004: iload_1
    //   1005: isub
    //   1006: invokestatic max : (II)I
    //   1009: istore #7
    //   1011: aload_0
    //   1012: getfield mListNavLayout : Landroid/widget/LinearLayout;
    //   1015: iload_2
    //   1016: ldc_w -2147483648
    //   1019: invokestatic makeMeasureSpec : (II)I
    //   1022: iload #10
    //   1024: ldc_w 1073741824
    //   1027: invokestatic makeMeasureSpec : (II)I
    //   1030: invokevirtual measure : (II)V
    //   1033: aload_0
    //   1034: getfield mListNavLayout : Landroid/widget/LinearLayout;
    //   1037: invokevirtual getMeasuredWidth : ()I
    //   1040: istore #5
    //   1042: iconst_0
    //   1043: iload_2
    //   1044: iload #5
    //   1046: isub
    //   1047: invokestatic max : (II)I
    //   1050: istore_1
    //   1051: iconst_0
    //   1052: iload #7
    //   1054: iload #5
    //   1056: isub
    //   1057: invokestatic max : (II)I
    //   1060: istore_2
    //   1061: goto -> 570
    //   1064: aload_0
    //   1065: getfield mItemPadding : I
    //   1068: istore_1
    //   1069: goto -> 992
    //   1072: iload #7
    //   1074: istore_1
    //   1075: iload #5
    //   1077: istore_2
    //   1078: aload_0
    //   1079: getfield mTabScrollView : Landroid/support/v7/internal/widget/ScrollingTabContainerView;
    //   1082: ifnull -> 570
    //   1085: iload #11
    //   1087: ifeq -> 1169
    //   1090: aload_0
    //   1091: getfield mItemPadding : I
    //   1094: iconst_2
    //   1095: imul
    //   1096: istore_1
    //   1097: iconst_0
    //   1098: iload #7
    //   1100: iload_1
    //   1101: isub
    //   1102: invokestatic max : (II)I
    //   1105: istore_2
    //   1106: iconst_0
    //   1107: iload #5
    //   1109: iload_1
    //   1110: isub
    //   1111: invokestatic max : (II)I
    //   1114: istore #5
    //   1116: aload_0
    //   1117: getfield mTabScrollView : Landroid/support/v7/internal/widget/ScrollingTabContainerView;
    //   1120: iload_2
    //   1121: ldc_w -2147483648
    //   1124: invokestatic makeMeasureSpec : (II)I
    //   1127: iload #10
    //   1129: ldc_w 1073741824
    //   1132: invokestatic makeMeasureSpec : (II)I
    //   1135: invokevirtual measure : (II)V
    //   1138: aload_0
    //   1139: getfield mTabScrollView : Landroid/support/v7/internal/widget/ScrollingTabContainerView;
    //   1142: invokevirtual getMeasuredWidth : ()I
    //   1145: istore #7
    //   1147: iconst_0
    //   1148: iload_2
    //   1149: iload #7
    //   1151: isub
    //   1152: invokestatic max : (II)I
    //   1155: istore_1
    //   1156: iconst_0
    //   1157: iload #5
    //   1159: iload #7
    //   1161: isub
    //   1162: invokestatic max : (II)I
    //   1165: istore_2
    //   1166: goto -> 570
    //   1169: aload_0
    //   1170: getfield mItemPadding : I
    //   1173: istore_1
    //   1174: goto -> 1097
    //   1177: aload #13
    //   1179: astore #6
    //   1181: aload_0
    //   1182: getfield mDisplayOptions : I
    //   1185: bipush #16
    //   1187: iand
    //   1188: ifeq -> 586
    //   1191: aload #13
    //   1193: astore #6
    //   1195: aload_0
    //   1196: getfield mCustomNavView : Landroid/view/View;
    //   1199: ifnull -> 586
    //   1202: aload_0
    //   1203: getfield mCustomNavView : Landroid/view/View;
    //   1206: astore #6
    //   1208: goto -> 586
    //   1211: aconst_null
    //   1212: astore #13
    //   1214: goto -> 620
    //   1217: aload #14
    //   1219: getfield height : I
    //   1222: bipush #-2
    //   1224: if_icmpeq -> 1235
    //   1227: ldc_w 1073741824
    //   1230: istore #5
    //   1232: goto -> 669
    //   1235: ldc_w -2147483648
    //   1238: istore #5
    //   1240: goto -> 1232
    //   1243: ldc_w -2147483648
    //   1246: istore #15
    //   1248: goto -> 719
    //   1251: iload_1
    //   1252: istore #16
    //   1254: goto -> 738
    //   1257: bipush #19
    //   1259: istore #10
    //   1261: goto -> 761
    //   1264: aload_0
    //   1265: iload #8
    //   1267: iload #5
    //   1269: invokevirtual setMeasuredDimension : (II)V
    //   1272: aload_0
    //   1273: getfield mContextView : Landroid/support/v7/internal/widget/ActionBarContextView;
    //   1276: ifnull -> 1290
    //   1279: aload_0
    //   1280: getfield mContextView : Landroid/support/v7/internal/widget/ActionBarContextView;
    //   1283: aload_0
    //   1284: invokevirtual getMeasuredHeight : ()I
    //   1287: invokevirtual setContentHeight : (I)V
    //   1290: aload_0
    //   1291: getfield mProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   1294: ifnull -> 101
    //   1297: aload_0
    //   1298: getfield mProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   1301: invokevirtual getVisibility : ()I
    //   1304: bipush #8
    //   1306: if_icmpeq -> 101
    //   1309: aload_0
    //   1310: getfield mProgressView : Landroid/support/v7/internal/widget/ProgressBarICS;
    //   1313: iload #8
    //   1315: aload_0
    //   1316: getfield mProgressBarPadding : I
    //   1319: iconst_2
    //   1320: imul
    //   1321: isub
    //   1322: ldc_w 1073741824
    //   1325: invokestatic makeMeasureSpec : (II)I
    //   1328: aload_0
    //   1329: invokevirtual getMeasuredHeight : ()I
    //   1332: ldc_w -2147483648
    //   1335: invokestatic makeMeasureSpec : (II)I
    //   1338: invokevirtual measure : (II)V
    //   1341: goto -> 101
    //   1344: aload_0
    //   1345: iload #8
    //   1347: iload #4
    //   1349: invokevirtual setMeasuredDimension : (II)V
    //   1352: goto -> 1272
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    if (savedState.expandedMenuItemId != 0 && this.mExpandedMenuPresenter != null && this.mOptionsMenu != null) {
      SupportMenuItem supportMenuItem = (SupportMenuItem)this.mOptionsMenu.findItem(savedState.expandedMenuItemId);
      if (supportMenuItem != null)
        supportMenuItem.expandActionView(); 
    } 
    if (savedState.isOverflowOpen)
      postShowOverflowMenu(); 
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    if (this.mExpandedMenuPresenter != null && this.mExpandedMenuPresenter.mCurrentExpandedItem != null)
      savedState.expandedMenuItemId = this.mExpandedMenuPresenter.mCurrentExpandedItem.getItemId(); 
    savedState.isOverflowOpen = isOverflowMenuShowing();
    return (Parcelable)savedState;
  }
  
  public void setCallback(ActionBar.OnNavigationListener paramOnNavigationListener) {
    this.mCallback = paramOnNavigationListener;
  }
  
  public void setCollapsable(boolean paramBoolean) {
    this.mIsCollapsable = paramBoolean;
  }
  
  public void setContextView(ActionBarContextView paramActionBarContextView) {
    this.mContextView = paramActionBarContextView;
  }
  
  public void setCustomNavigationView(View paramView) {
    boolean bool;
    if ((this.mDisplayOptions & 0x10) != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (this.mCustomNavView != null && bool)
      removeView(this.mCustomNavView); 
    this.mCustomNavView = paramView;
    if (this.mCustomNavView != null && bool)
      addView(this.mCustomNavView); 
  }
  
  public void setDisplayOptions(int paramInt) {
    byte b = 8;
    int i = -1;
    boolean bool = true;
    if (this.mDisplayOptions != -1)
      i = paramInt ^ this.mDisplayOptions; 
    this.mDisplayOptions = paramInt;
    if ((i & 0x1F) != 0) {
      boolean bool1;
      byte b1;
      if ((paramInt & 0x2) != 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1 && this.mExpandedActionView == null) {
        b1 = 0;
      } else {
        b1 = 8;
      } 
      this.mHomeLayout.setVisibility(b1);
      if ((i & 0x4) != 0) {
        boolean bool2;
        if ((paramInt & 0x4) != 0) {
          bool2 = true;
        } else {
          bool2 = false;
        } 
        this.mHomeLayout.setUp(bool2);
        if (bool2)
          setHomeButtonEnabled(true); 
      } 
      if ((i & 0x1) != 0) {
        Drawable drawable;
        if (this.mLogo != null && (paramInt & 0x1) != 0) {
          b1 = 1;
        } else {
          b1 = 0;
        } 
        HomeView homeView = this.mHomeLayout;
        if (b1 != 0) {
          drawable = this.mLogo;
        } else {
          drawable = this.mIcon;
        } 
        homeView.setIcon(drawable);
      } 
      if ((i & 0x8) != 0)
        if ((paramInt & 0x8) != 0) {
          initTitle();
        } else {
          removeView((View)this.mTitleLayout);
        }  
      if (this.mTitleLayout != null && (i & 0x6) != 0) {
        boolean bool2;
        boolean bool3;
        if ((this.mDisplayOptions & 0x4) != 0) {
          bool3 = true;
        } else {
          bool3 = false;
        } 
        View view = this.mTitleUpView;
        b1 = b;
        if (!bool1)
          if (bool3) {
            b1 = 0;
          } else {
            b1 = 4;
          }  
        view.setVisibility(b1);
        LinearLayout linearLayout = this.mTitleLayout;
        if (!bool1 && bool3) {
          bool2 = bool;
        } else {
          bool2 = false;
        } 
        linearLayout.setEnabled(bool2);
      } 
      if ((i & 0x10) != 0 && this.mCustomNavView != null)
        if ((paramInt & 0x10) != 0) {
          addView(this.mCustomNavView);
        } else {
          removeView(this.mCustomNavView);
        }  
      requestLayout();
    } else {
      invalidate();
    } 
    if (!this.mHomeLayout.isEnabled()) {
      this.mHomeLayout.setContentDescription(null);
      return;
    } 
    if ((paramInt & 0x4) != 0) {
      this.mHomeLayout.setContentDescription(this.mContext.getResources().getText(R.string.abc_action_bar_up_description));
      return;
    } 
    this.mHomeLayout.setContentDescription(this.mContext.getResources().getText(R.string.abc_action_bar_home_description));
  }
  
  public void setDropdownAdapter(SpinnerAdapter paramSpinnerAdapter) {
    this.mSpinnerAdapter = paramSpinnerAdapter;
    if (this.mSpinner != null)
      this.mSpinner.setAdapter(paramSpinnerAdapter); 
  }
  
  public void setDropdownSelectedPosition(int paramInt) {
    this.mSpinner.setSelection(paramInt);
  }
  
  public void setEmbeddedTabView(ScrollingTabContainerView paramScrollingTabContainerView) {
    boolean bool;
    if (this.mTabScrollView != null)
      removeView((View)this.mTabScrollView); 
    this.mTabScrollView = paramScrollingTabContainerView;
    if (paramScrollingTabContainerView != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.mIncludeTabs = bool;
    if (this.mIncludeTabs && this.mNavigationMode == 2) {
      addView((View)this.mTabScrollView);
      ViewGroup.LayoutParams layoutParams = this.mTabScrollView.getLayoutParams();
      layoutParams.width = -2;
      layoutParams.height = -1;
      paramScrollingTabContainerView.setAllowCollapse(true);
    } 
  }
  
  public void setHomeAsUpIndicator(int paramInt) {
    this.mHomeLayout.setUpIndicator(paramInt);
  }
  
  public void setHomeAsUpIndicator(Drawable paramDrawable) {
    this.mHomeLayout.setUpIndicator(paramDrawable);
  }
  
  public void setHomeButtonEnabled(boolean paramBoolean) {
    this.mHomeLayout.setEnabled(paramBoolean);
    this.mHomeLayout.setFocusable(paramBoolean);
    if (!paramBoolean) {
      this.mHomeLayout.setContentDescription(null);
      return;
    } 
    if ((this.mDisplayOptions & 0x4) != 0) {
      this.mHomeLayout.setContentDescription(this.mContext.getResources().getText(R.string.abc_action_bar_up_description));
      return;
    } 
    this.mHomeLayout.setContentDescription(this.mContext.getResources().getText(R.string.abc_action_bar_home_description));
  }
  
  public void setIcon(int paramInt) {
    setIcon(this.mContext.getResources().getDrawable(paramInt));
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.mIcon = paramDrawable;
    if (paramDrawable != null && ((this.mDisplayOptions & 0x1) == 0 || this.mLogo == null))
      this.mHomeLayout.setIcon(paramDrawable); 
    if (this.mExpandedActionView != null)
      this.mExpandedHomeLayout.setIcon(this.mIcon.getConstantState().newDrawable(getResources())); 
  }
  
  public void setLogo(int paramInt) {
    setLogo(this.mContext.getResources().getDrawable(paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    this.mLogo = paramDrawable;
    if (paramDrawable != null && (this.mDisplayOptions & 0x1) != 0)
      this.mHomeLayout.setIcon(paramDrawable); 
  }
  
  public void setMenu(SupportMenu paramSupportMenu, MenuPresenter.Callback paramCallback) {
    if (paramSupportMenu != this.mOptionsMenu) {
      ActionMenuView actionMenuView;
      ViewGroup viewGroup;
      if (this.mOptionsMenu != null) {
        this.mOptionsMenu.removeMenuPresenter((MenuPresenter)this.mActionMenuPresenter);
        this.mOptionsMenu.removeMenuPresenter(this.mExpandedMenuPresenter);
      } 
      MenuBuilder menuBuilder = (MenuBuilder)paramSupportMenu;
      this.mOptionsMenu = menuBuilder;
      if (this.mMenuView != null) {
        ViewGroup viewGroup1 = (ViewGroup)this.mMenuView.getParent();
        if (viewGroup1 != null)
          viewGroup1.removeView((View)this.mMenuView); 
      } 
      if (this.mActionMenuPresenter == null) {
        this.mActionMenuPresenter = new ActionMenuPresenter(this.mContext);
        this.mActionMenuPresenter.setCallback(paramCallback);
        this.mActionMenuPresenter.setId(R.id.action_menu_presenter);
        this.mExpandedMenuPresenter = new ExpandedActionViewMenuPresenter();
      } 
      ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
      if (!this.mSplitActionBar) {
        this.mActionMenuPresenter.setExpandedActionViewsExclusive(getResources().getBoolean(R.bool.abc_action_bar_expanded_action_views_exclusive));
        configPresenters(menuBuilder);
        actionMenuView = (ActionMenuView)this.mActionMenuPresenter.getMenuView(this);
        actionMenuView.initialize(menuBuilder);
        viewGroup = (ViewGroup)actionMenuView.getParent();
        if (viewGroup != null && viewGroup != this)
          viewGroup.removeView((View)actionMenuView); 
        addView((View)actionMenuView, layoutParams);
      } else {
        this.mActionMenuPresenter.setExpandedActionViewsExclusive(false);
        this.mActionMenuPresenter.setWidthLimit((getContext().getResources().getDisplayMetrics()).widthPixels, true);
        this.mActionMenuPresenter.setItemLimit(2147483647);
        layoutParams.width = -1;
        configPresenters((MenuBuilder)viewGroup);
        actionMenuView = (ActionMenuView)this.mActionMenuPresenter.getMenuView(this);
        if (this.mSplitView != null) {
          viewGroup = (ViewGroup)actionMenuView.getParent();
          if (viewGroup != null && viewGroup != this.mSplitView)
            viewGroup.removeView((View)actionMenuView); 
          actionMenuView.setVisibility(getAnimatedVisibility());
          this.mSplitView.addView((View)actionMenuView, layoutParams);
        } else {
          actionMenuView.setLayoutParams(layoutParams);
        } 
      } 
      this.mMenuView = actionMenuView;
    } 
  }
  
  public void setNavigationMode(int paramInt) {
    int i = this.mNavigationMode;
    if (paramInt != i) {
      switch (i) {
        default:
          switch (paramInt) {
            default:
              this.mNavigationMode = paramInt;
              requestLayout();
              return;
            case 1:
              if (this.mSpinner == null) {
                this.mSpinner = new SpinnerICS(this.mContext, null, R.attr.actionDropDownStyle);
                this.mListNavLayout = (LinearLayout)LayoutInflater.from(this.mContext).inflate(R.layout.abc_action_bar_view_list_nav_layout, null);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
                layoutParams.gravity = 17;
                this.mListNavLayout.addView((View)this.mSpinner, (ViewGroup.LayoutParams)layoutParams);
              } 
              if (this.mSpinner.getAdapter() != this.mSpinnerAdapter)
                this.mSpinner.setAdapter(this.mSpinnerAdapter); 
              this.mSpinner.setOnItemSelectedListener(this.mNavItemSelectedListener);
              addView((View)this.mListNavLayout);
            case 2:
              break;
          } 
          break;
        case 1:
          if (this.mListNavLayout != null)
            removeView((View)this.mListNavLayout); 
        case 2:
          if (this.mTabScrollView != null && this.mIncludeTabs)
            removeView((View)this.mTabScrollView); 
      } 
    } else {
      return;
    } 
    if (this.mTabScrollView != null && this.mIncludeTabs)
      addView((View)this.mTabScrollView); 
  }
  
  public void setSplitActionBar(boolean paramBoolean) {
    if (this.mSplitActionBar != paramBoolean) {
      if (this.mMenuView != null) {
        ViewGroup viewGroup = (ViewGroup)this.mMenuView.getParent();
        if (viewGroup != null)
          viewGroup.removeView((View)this.mMenuView); 
        if (paramBoolean) {
          if (this.mSplitView != null)
            this.mSplitView.addView((View)this.mMenuView); 
          (this.mMenuView.getLayoutParams()).width = -1;
        } else {
          addView((View)this.mMenuView);
          (this.mMenuView.getLayoutParams()).width = -2;
        } 
        this.mMenuView.requestLayout();
      } 
      if (this.mSplitView != null) {
        byte b;
        ActionBarContainer actionBarContainer = this.mSplitView;
        if (paramBoolean) {
          b = 0;
        } else {
          b = 8;
        } 
        actionBarContainer.setVisibility(b);
      } 
      if (this.mActionMenuPresenter != null)
        if (!paramBoolean) {
          this.mActionMenuPresenter.setExpandedActionViewsExclusive(getResources().getBoolean(R.bool.abc_action_bar_expanded_action_views_exclusive));
        } else {
          this.mActionMenuPresenter.setExpandedActionViewsExclusive(false);
          this.mActionMenuPresenter.setWidthLimit((getContext().getResources().getDisplayMetrics()).widthPixels, true);
          this.mActionMenuPresenter.setItemLimit(2147483647);
        }  
      super.setSplitActionBar(paramBoolean);
    } 
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    boolean bool = false;
    this.mSubtitle = paramCharSequence;
    if (this.mSubtitleView != null) {
      byte b;
      this.mSubtitleView.setText(paramCharSequence);
      TextView textView = this.mSubtitleView;
      if (paramCharSequence != null) {
        b = 0;
      } else {
        b = 8;
      } 
      textView.setVisibility(b);
      if (this.mExpandedActionView == null && (this.mDisplayOptions & 0x8) != 0 && (!TextUtils.isEmpty(this.mTitle) || !TextUtils.isEmpty(this.mSubtitle))) {
        b = 1;
      } else {
        b = 0;
      } 
      LinearLayout linearLayout = this.mTitleLayout;
      if (b != 0) {
        b = bool;
      } else {
        b = 8;
      } 
      linearLayout.setVisibility(b);
    } 
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.mUserTitle = true;
    setTitleImpl(paramCharSequence);
  }
  
  public void setWindowCallback(Window.Callback paramCallback) {
    this.mWindowCallback = paramCallback;
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    if (!this.mUserTitle)
      setTitleImpl(paramCharSequence); 
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  private class ExpandedActionViewMenuPresenter implements MenuPresenter {
    MenuItemImpl mCurrentExpandedItem;
    
    MenuBuilder mMenu;
    
    private ExpandedActionViewMenuPresenter() {}
    
    public boolean collapseItemActionView(MenuBuilder param1MenuBuilder, MenuItemImpl param1MenuItemImpl) {
      if (ActionBarView.this.mExpandedActionView instanceof CollapsibleActionView)
        ((CollapsibleActionView)ActionBarView.this.mExpandedActionView).onActionViewCollapsed(); 
      ActionBarView.this.removeView(ActionBarView.this.mExpandedActionView);
      ActionBarView.this.removeView((View)ActionBarView.this.mExpandedHomeLayout);
      ActionBarView.this.mExpandedActionView = null;
      if ((ActionBarView.this.mDisplayOptions & 0x2) != 0)
        ActionBarView.this.mHomeLayout.setVisibility(0); 
      if ((ActionBarView.this.mDisplayOptions & 0x8) != 0)
        if (ActionBarView.this.mTitleLayout == null) {
          ActionBarView.this.initTitle();
        } else {
          ActionBarView.this.mTitleLayout.setVisibility(0);
        }  
      if (ActionBarView.this.mTabScrollView != null && ActionBarView.this.mNavigationMode == 2)
        ActionBarView.this.mTabScrollView.setVisibility(0); 
      if (ActionBarView.this.mSpinner != null && ActionBarView.this.mNavigationMode == 1)
        ActionBarView.this.mSpinner.setVisibility(0); 
      if (ActionBarView.this.mCustomNavView != null && (ActionBarView.this.mDisplayOptions & 0x10) != 0)
        ActionBarView.this.mCustomNavView.setVisibility(0); 
      ActionBarView.this.mExpandedHomeLayout.setIcon((Drawable)null);
      this.mCurrentExpandedItem = null;
      ActionBarView.this.requestLayout();
      param1MenuItemImpl.setActionViewExpanded(false);
      return true;
    }
    
    public boolean expandItemActionView(MenuBuilder param1MenuBuilder, MenuItemImpl param1MenuItemImpl) {
      ActionBarView.this.mExpandedActionView = param1MenuItemImpl.getActionView();
      ActionBarView.this.mExpandedHomeLayout.setIcon(ActionBarView.this.mIcon.getConstantState().newDrawable(ActionBarView.this.getResources()));
      this.mCurrentExpandedItem = param1MenuItemImpl;
      if (ActionBarView.this.mExpandedActionView.getParent() != ActionBarView.this)
        ActionBarView.this.addView(ActionBarView.this.mExpandedActionView); 
      if (ActionBarView.this.mExpandedHomeLayout.getParent() != ActionBarView.this)
        ActionBarView.this.addView((View)ActionBarView.this.mExpandedHomeLayout); 
      ActionBarView.this.mHomeLayout.setVisibility(8);
      if (ActionBarView.this.mTitleLayout != null)
        ActionBarView.this.mTitleLayout.setVisibility(8); 
      if (ActionBarView.this.mTabScrollView != null)
        ActionBarView.this.mTabScrollView.setVisibility(8); 
      if (ActionBarView.this.mSpinner != null)
        ActionBarView.this.mSpinner.setVisibility(8); 
      if (ActionBarView.this.mCustomNavView != null)
        ActionBarView.this.mCustomNavView.setVisibility(8); 
      ActionBarView.this.requestLayout();
      param1MenuItemImpl.setActionViewExpanded(true);
      if (ActionBarView.this.mExpandedActionView instanceof CollapsibleActionView)
        ((CollapsibleActionView)ActionBarView.this.mExpandedActionView).onActionViewExpanded(); 
      return true;
    }
    
    public boolean flagActionItems() {
      return false;
    }
    
    public int getId() {
      return 0;
    }
    
    public MenuView getMenuView(ViewGroup param1ViewGroup) {
      return null;
    }
    
    public void initForMenu(Context param1Context, MenuBuilder param1MenuBuilder) {
      if (this.mMenu != null && this.mCurrentExpandedItem != null)
        this.mMenu.collapseItemActionView(this.mCurrentExpandedItem); 
      this.mMenu = param1MenuBuilder;
    }
    
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {}
    
    public void onRestoreInstanceState(Parcelable param1Parcelable) {}
    
    public Parcelable onSaveInstanceState() {
      return null;
    }
    
    public boolean onSubMenuSelected(SubMenuBuilder param1SubMenuBuilder) {
      return false;
    }
    
    public void setCallback(MenuPresenter.Callback param1Callback) {}
    
    public void updateMenuView(boolean param1Boolean) {
      boolean bool;
      if (this.mCurrentExpandedItem != null) {
        boolean bool1 = false;
        bool = bool1;
        if (this.mMenu != null) {
          int i = this.mMenu.size();
          byte b = 0;
          while (true) {
            bool = bool1;
            if (b < i)
              if ((SupportMenuItem)this.mMenu.getItem(b) == this.mCurrentExpandedItem) {
                bool = true;
              } else {
                b++;
                continue;
              }  
            if (!bool)
              collapseItemActionView(this.mMenu, this.mCurrentExpandedItem); 
            return;
          } 
        } 
      } else {
        return;
      } 
      if (!bool)
        collapseItemActionView(this.mMenu, this.mCurrentExpandedItem); 
    }
  }
  
  private static class HomeView extends FrameLayout {
    private Drawable mDefaultUpIndicator;
    
    private ImageView mIconView;
    
    private int mUpIndicatorRes;
    
    private ImageView mUpView;
    
    private int mUpWidth;
    
    public HomeView(Context param1Context) {
      this(param1Context, (AttributeSet)null);
    }
    
    public HomeView(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      CharSequence charSequence = getContentDescription();
      if (!TextUtils.isEmpty(charSequence))
        param1AccessibilityEvent.getText().add(charSequence); 
      return true;
    }
    
    public int getLeftOffset() {
      return (this.mUpView.getVisibility() == 8) ? this.mUpWidth : 0;
    }
    
    protected void onConfigurationChanged(Configuration param1Configuration) {
      super.onConfigurationChanged(param1Configuration);
      if (this.mUpIndicatorRes != 0)
        setUpIndicator(this.mUpIndicatorRes); 
    }
    
    protected void onFinishInflate() {
      this.mUpView = (ImageView)findViewById(R.id.up);
      this.mIconView = (ImageView)findViewById(R.id.home);
      this.mDefaultUpIndicator = this.mUpView.getDrawable();
    }
    
    protected void onLayout(boolean param1Boolean, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      int i = (param1Int4 - param1Int2) / 2;
      param1Int4 = 0;
      param1Int2 = param1Int1;
      if (this.mUpView.getVisibility() != 8) {
        FrameLayout.LayoutParams layoutParams1 = (FrameLayout.LayoutParams)this.mUpView.getLayoutParams();
        int k = this.mUpView.getMeasuredHeight();
        param1Int2 = this.mUpView.getMeasuredWidth();
        param1Int4 = i - k / 2;
        this.mUpView.layout(0, param1Int4, param1Int2, param1Int4 + k);
        param1Int4 = layoutParams1.leftMargin + param1Int2 + layoutParams1.rightMargin;
        param1Int2 = param1Int1 + param1Int4;
      } 
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)this.mIconView.getLayoutParams();
      param1Int1 = this.mIconView.getMeasuredHeight();
      int j = this.mIconView.getMeasuredWidth();
      param1Int2 = (param1Int3 - param1Int2) / 2;
      param1Int2 = param1Int4 + Math.max(layoutParams.leftMargin, param1Int2 - j / 2);
      param1Int3 = Math.max(layoutParams.topMargin, i - param1Int1 / 2);
      this.mIconView.layout(param1Int2, param1Int3, param1Int2 + j, param1Int3 + param1Int1);
    }
    
    protected void onMeasure(int param1Int1, int param1Int2) {
      measureChildWithMargins((View)this.mUpView, param1Int1, 0, param1Int2, 0);
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)this.mUpView.getLayoutParams();
      this.mUpWidth = layoutParams.leftMargin + this.mUpView.getMeasuredWidth() + layoutParams.rightMargin;
      if (this.mUpView.getVisibility() == 8) {
        i = 0;
      } else {
        i = this.mUpWidth;
      } 
      int j = layoutParams.topMargin;
      int k = this.mUpView.getMeasuredHeight();
      int m = layoutParams.bottomMargin;
      measureChildWithMargins((View)this.mIconView, param1Int1, i, param1Int2, 0);
      layoutParams = (FrameLayout.LayoutParams)this.mIconView.getLayoutParams();
      int n = i + layoutParams.leftMargin + this.mIconView.getMeasuredWidth() + layoutParams.rightMargin;
      int i = Math.max(j + k + m, layoutParams.topMargin + this.mIconView.getMeasuredHeight() + layoutParams.bottomMargin);
      k = View.MeasureSpec.getMode(param1Int1);
      m = View.MeasureSpec.getMode(param1Int2);
      param1Int1 = View.MeasureSpec.getSize(param1Int1);
      param1Int2 = View.MeasureSpec.getSize(param1Int2);
      switch (k) {
        default:
          param1Int1 = n;
        case -2147483648:
          param1Int1 = Math.min(n, param1Int1);
        case 1073741824:
          switch (m) {
            default:
              param1Int2 = i;
              break;
            case -2147483648:
            case 1073741824:
              break;
          } 
          setMeasuredDimension(param1Int1, param1Int2);
          return;
      } 
      param1Int2 = Math.min(i, param1Int2);
      setMeasuredDimension(param1Int1, param1Int2);
    }
    
    public void setIcon(Drawable param1Drawable) {
      this.mIconView.setImageDrawable(param1Drawable);
    }
    
    public void setUp(boolean param1Boolean) {
      byte b;
      ImageView imageView = this.mUpView;
      if (param1Boolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    }
    
    public void setUpIndicator(int param1Int) {
      Drawable drawable;
      this.mUpIndicatorRes = param1Int;
      ImageView imageView = this.mUpView;
      if (param1Int != 0) {
        drawable = getResources().getDrawable(param1Int);
      } else {
        drawable = this.mDefaultUpIndicator;
      } 
      imageView.setImageDrawable(drawable);
    }
    
    public void setUpIndicator(Drawable param1Drawable) {
      ImageView imageView = this.mUpView;
      if (param1Drawable == null)
        param1Drawable = this.mDefaultUpIndicator; 
      imageView.setImageDrawable(param1Drawable);
      this.mUpIndicatorRes = 0;
    }
  }
  
  static class SavedState extends View.BaseSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public ActionBarView.SavedState createFromParcel(Parcel param2Parcel) {
          return new ActionBarView.SavedState(param2Parcel);
        }
        
        public ActionBarView.SavedState[] newArray(int param2Int) {
          return new ActionBarView.SavedState[param2Int];
        }
      };
    
    int expandedMenuItemId;
    
    boolean isOverflowOpen;
    
    private SavedState(Parcel param1Parcel) {
      super(param1Parcel);
      boolean bool;
      this.expandedMenuItemId = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.isOverflowOpen = bool;
    }
    
    SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.expandedMenuItemId);
      if (this.isOverflowOpen) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      param1Parcel.writeInt(param1Int);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public ActionBarView.SavedState createFromParcel(Parcel param1Parcel) {
      return new ActionBarView.SavedState(param1Parcel);
    }
    
    public ActionBarView.SavedState[] newArray(int param1Int) {
      return new ActionBarView.SavedState[param1Int];
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/widget/ActionBarView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */