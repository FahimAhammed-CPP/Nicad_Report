package android.support.v7.internal.widget;

import android.content.Context;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.SpinnerAdapter;

abstract class AbsSpinnerICS extends AdapterViewICS<SpinnerAdapter> {
  SpinnerAdapter mAdapter;
  
  boolean mBlockLayoutRequests;
  
  private DataSetObserver mDataSetObserver;
  
  int mHeightMeasureSpec;
  
  final RecycleBin mRecycler = new RecycleBin();
  
  int mSelectionBottomPadding = 0;
  
  int mSelectionLeftPadding = 0;
  
  int mSelectionRightPadding = 0;
  
  int mSelectionTopPadding = 0;
  
  final Rect mSpinnerPadding = new Rect();
  
  private Rect mTouchFrame;
  
  int mWidthMeasureSpec;
  
  AbsSpinnerICS(Context paramContext) {
    super(paramContext);
    initAbsSpinner();
  }
  
  AbsSpinnerICS(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  AbsSpinnerICS(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    initAbsSpinner();
  }
  
  private void initAbsSpinner() {
    setFocusable(true);
    setWillNotDraw(false);
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return new ViewGroup.LayoutParams(-1, -2);
  }
  
  public SpinnerAdapter getAdapter() {
    return this.mAdapter;
  }
  
  int getChildHeight(View paramView) {
    return paramView.getMeasuredHeight();
  }
  
  int getChildWidth(View paramView) {
    return paramView.getMeasuredWidth();
  }
  
  public int getCount() {
    return this.mItemCount;
  }
  
  public View getSelectedView() {
    return (this.mItemCount > 0 && this.mSelectedPosition >= 0) ? getChildAt(this.mSelectedPosition - this.mFirstPosition) : null;
  }
  
  abstract void layout(int paramInt, boolean paramBoolean);
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = getPaddingLeft();
    int k = getPaddingTop();
    int m = getPaddingRight();
    int n = getPaddingBottom();
    Rect rect = this.mSpinnerPadding;
    if (j <= this.mSelectionLeftPadding)
      j = this.mSelectionLeftPadding; 
    rect.left = j;
    rect = this.mSpinnerPadding;
    if (k > this.mSelectionTopPadding) {
      j = k;
    } else {
      j = this.mSelectionTopPadding;
    } 
    rect.top = j;
    rect = this.mSpinnerPadding;
    if (m > this.mSelectionRightPadding) {
      j = m;
    } else {
      j = this.mSelectionRightPadding;
    } 
    rect.right = j;
    rect = this.mSpinnerPadding;
    if (n > this.mSelectionBottomPadding) {
      j = n;
    } else {
      j = this.mSelectionBottomPadding;
    } 
    rect.bottom = j;
    if (this.mDataChanged)
      handleDataChanged(); 
    k = 0;
    boolean bool1 = false;
    boolean bool2 = true;
    int i1 = getSelectedItemPosition();
    m = bool2;
    n = k;
    j = bool1;
    if (i1 >= 0) {
      m = bool2;
      n = k;
      j = bool1;
      if (this.mAdapter != null) {
        m = bool2;
        n = k;
        j = bool1;
        if (i1 < this.mAdapter.getCount()) {
          View view2 = this.mRecycler.get(i1);
          View view1 = view2;
          if (view2 == null)
            view1 = this.mAdapter.getView(i1, null, this); 
          if (view1 != null)
            this.mRecycler.put(i1, view1); 
          m = bool2;
          n = k;
          j = bool1;
          if (view1 != null) {
            if (view1.getLayoutParams() == null) {
              this.mBlockLayoutRequests = true;
              view1.setLayoutParams(generateDefaultLayoutParams());
              this.mBlockLayoutRequests = false;
            } 
            measureChild(view1, paramInt1, paramInt2);
            n = getChildHeight(view1) + this.mSpinnerPadding.top + this.mSpinnerPadding.bottom;
            j = getChildWidth(view1) + this.mSpinnerPadding.left + this.mSpinnerPadding.right;
            m = 0;
          } 
        } 
      } 
    } 
    k = n;
    n = j;
    if (m != 0) {
      m = this.mSpinnerPadding.top + this.mSpinnerPadding.bottom;
      k = m;
      n = j;
      if (i == 0) {
        n = this.mSpinnerPadding.left + this.mSpinnerPadding.right;
        k = m;
      } 
    } 
    m = Math.max(k, getSuggestedMinimumHeight());
    j = Math.max(n, getSuggestedMinimumWidth());
    n = resolveSize(m, paramInt2);
    setMeasuredDimension(resolveSize(j, paramInt1), n);
    this.mHeightMeasureSpec = paramInt2;
    this.mWidthMeasureSpec = paramInt1;
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    if (savedState.selectedId >= 0L) {
      this.mDataChanged = true;
      this.mNeedSync = true;
      this.mSyncRowId = savedState.selectedId;
      this.mSyncPosition = savedState.position;
      this.mSyncMode = 0;
      requestLayout();
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    savedState.selectedId = getSelectedItemId();
    if (savedState.selectedId >= 0L) {
      savedState.position = getSelectedItemPosition();
      return (Parcelable)savedState;
    } 
    savedState.position = -1;
    return (Parcelable)savedState;
  }
  
  public int pointToPosition(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTouchFrame : Landroid/graphics/Rect;
    //   4: astore_3
    //   5: aload_3
    //   6: astore #4
    //   8: aload_3
    //   9: ifnonnull -> 29
    //   12: aload_0
    //   13: new android/graphics/Rect
    //   16: dup
    //   17: invokespecial <init> : ()V
    //   20: putfield mTouchFrame : Landroid/graphics/Rect;
    //   23: aload_0
    //   24: getfield mTouchFrame : Landroid/graphics/Rect;
    //   27: astore #4
    //   29: aload_0
    //   30: invokevirtual getChildCount : ()I
    //   33: iconst_1
    //   34: isub
    //   35: istore #5
    //   37: iload #5
    //   39: iflt -> 88
    //   42: aload_0
    //   43: iload #5
    //   45: invokevirtual getChildAt : (I)Landroid/view/View;
    //   48: astore_3
    //   49: aload_3
    //   50: invokevirtual getVisibility : ()I
    //   53: ifne -> 82
    //   56: aload_3
    //   57: aload #4
    //   59: invokevirtual getHitRect : (Landroid/graphics/Rect;)V
    //   62: aload #4
    //   64: iload_1
    //   65: iload_2
    //   66: invokevirtual contains : (II)Z
    //   69: ifeq -> 82
    //   72: aload_0
    //   73: getfield mFirstPosition : I
    //   76: iload #5
    //   78: iadd
    //   79: istore_1
    //   80: iload_1
    //   81: ireturn
    //   82: iinc #5, -1
    //   85: goto -> 37
    //   88: iconst_m1
    //   89: istore_1
    //   90: goto -> 80
  }
  
  void recycleAllViews() {
    int i = getChildCount();
    RecycleBin recycleBin = this.mRecycler;
    int j = this.mFirstPosition;
    for (byte b = 0; b < i; b++)
      recycleBin.put(j + b, getChildAt(b)); 
  }
  
  public void requestLayout() {
    if (!this.mBlockLayoutRequests)
      super.requestLayout(); 
  }
  
  void resetList() {
    this.mDataChanged = false;
    this.mNeedSync = false;
    removeAllViewsInLayout();
    this.mOldSelectedPosition = -1;
    this.mOldSelectedRowId = Long.MIN_VALUE;
    setSelectedPositionInt(-1);
    setNextSelectedPositionInt(-1);
    invalidate();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    byte b = -1;
    if (this.mAdapter != null) {
      this.mAdapter.unregisterDataSetObserver(this.mDataSetObserver);
      resetList();
    } 
    this.mAdapter = paramSpinnerAdapter;
    this.mOldSelectedPosition = -1;
    this.mOldSelectedRowId = Long.MIN_VALUE;
    if (this.mAdapter != null) {
      this.mOldItemCount = this.mItemCount;
      this.mItemCount = this.mAdapter.getCount();
      checkFocus();
      this.mDataSetObserver = new AdapterViewICS.AdapterDataSetObserver(this);
      this.mAdapter.registerDataSetObserver(this.mDataSetObserver);
      if (this.mItemCount > 0)
        b = 0; 
      setSelectedPositionInt(b);
      setNextSelectedPositionInt(b);
      if (this.mItemCount == 0)
        checkSelectionChanged(); 
    } else {
      checkFocus();
      resetList();
      checkSelectionChanged();
    } 
    requestLayout();
  }
  
  public void setSelection(int paramInt) {
    setNextSelectedPositionInt(paramInt);
    requestLayout();
    invalidate();
  }
  
  public void setSelection(int paramInt, boolean paramBoolean) {
    if (paramBoolean && this.mFirstPosition <= paramInt && paramInt <= this.mFirstPosition + getChildCount() - 1) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    setSelectionInt(paramInt, paramBoolean);
  }
  
  void setSelectionInt(int paramInt, boolean paramBoolean) {
    if (paramInt != this.mOldSelectedPosition) {
      this.mBlockLayoutRequests = true;
      int i = this.mSelectedPosition;
      setNextSelectedPositionInt(paramInt);
      layout(paramInt - i, paramBoolean);
      this.mBlockLayoutRequests = false;
    } 
  }
  
  class RecycleBin {
    private final SparseArray<View> mScrapHeap = new SparseArray();
    
    void clear() {
      SparseArray<View> sparseArray = this.mScrapHeap;
      int i = sparseArray.size();
      for (byte b = 0; b < i; b++) {
        View view = (View)sparseArray.valueAt(b);
        if (view != null)
          AbsSpinnerICS.this.removeDetachedView(view, true); 
      } 
      sparseArray.clear();
    }
    
    View get(int param1Int) {
      View view = (View)this.mScrapHeap.get(param1Int);
      if (view != null)
        this.mScrapHeap.delete(param1Int); 
      return view;
    }
    
    public void put(int param1Int, View param1View) {
      this.mScrapHeap.put(param1Int, param1View);
    }
  }
  
  static class SavedState extends View.BaseSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public AbsSpinnerICS.SavedState createFromParcel(Parcel param2Parcel) {
          return new AbsSpinnerICS.SavedState(param2Parcel);
        }
        
        public AbsSpinnerICS.SavedState[] newArray(int param2Int) {
          return new AbsSpinnerICS.SavedState[param2Int];
        }
      };
    
    int position;
    
    long selectedId;
    
    private SavedState(Parcel param1Parcel) {
      super(param1Parcel);
      this.selectedId = param1Parcel.readLong();
      this.position = param1Parcel.readInt();
    }
    
    SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      return "AbsSpinner.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " selectedId=" + this.selectedId + " position=" + this.position + "}";
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeLong(this.selectedId);
      param1Parcel.writeInt(this.position);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public AbsSpinnerICS.SavedState createFromParcel(Parcel param1Parcel) {
      return new AbsSpinnerICS.SavedState(param1Parcel);
    }
    
    public AbsSpinnerICS.SavedState[] newArray(int param1Int) {
      return new AbsSpinnerICS.SavedState[param1Int];
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/widget/AbsSpinnerICS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */