package android.support.v7.internal.widget;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v7.appcompat.R;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ListAdapter;
import android.widget.SpinnerAdapter;

class SpinnerICS extends AbsSpinnerICS implements DialogInterface.OnClickListener {
  private static final int MAX_ITEMS_MEASURED = 15;
  
  static final int MODE_DIALOG = 0;
  
  static final int MODE_DROPDOWN = 1;
  
  private static final int MODE_THEME = -1;
  
  private static final String TAG = "Spinner";
  
  int mDropDownWidth;
  
  private int mGravity;
  
  private SpinnerPopup mPopup;
  
  private DropDownAdapter mTempAdapter;
  
  private Rect mTempRect = new Rect();
  
  SpinnerICS(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  SpinnerICS(Context paramContext, int paramInt) {
    this(paramContext, (AttributeSet)null, R.attr.spinnerStyle, paramInt);
  }
  
  SpinnerICS(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, R.attr.spinnerStyle);
  }
  
  SpinnerICS(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, -1);
  }
  
  SpinnerICS(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    super(paramContext, paramAttributeSet, paramInt1);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.Spinner, paramInt1, 0);
    int i = paramInt2;
    if (paramInt2 == -1)
      i = typedArray.getInt(7, 0); 
    switch (i) {
      default:
        this.mGravity = typedArray.getInt(0, 17);
        this.mPopup.setPromptText(typedArray.getString(6));
        typedArray.recycle();
        if (this.mTempAdapter != null) {
          this.mPopup.setAdapter(this.mTempAdapter);
          this.mTempAdapter = null;
        } 
        return;
      case 0:
        this.mPopup = new DialogPopup();
      case 1:
        break;
    } 
    DropdownPopup dropdownPopup = new DropdownPopup(paramContext, paramAttributeSet, paramInt1);
    this.mDropDownWidth = typedArray.getLayoutDimension(3, -2);
    dropdownPopup.setBackgroundDrawable(typedArray.getDrawable(2));
    paramInt1 = typedArray.getDimensionPixelOffset(5, 0);
    if (paramInt1 != 0)
      dropdownPopup.setVerticalOffset(paramInt1); 
    paramInt1 = typedArray.getDimensionPixelOffset(4, 0);
    if (paramInt1 != 0)
      dropdownPopup.setHorizontalOffset(paramInt1); 
    this.mPopup = dropdownPopup;
  }
  
  private View makeAndAddView(int paramInt) {
    if (!this.mDataChanged) {
      View view1 = this.mRecycler.get(paramInt);
      if (view1 != null) {
        setUpChild(view1);
        return view1;
      } 
    } 
    View view = this.mAdapter.getView(paramInt, null, this);
    setUpChild(view);
    return view;
  }
  
  private void setUpChild(View paramView) {
    ViewGroup.LayoutParams layoutParams1 = paramView.getLayoutParams();
    ViewGroup.LayoutParams layoutParams2 = layoutParams1;
    if (layoutParams1 == null)
      layoutParams2 = generateDefaultLayoutParams(); 
    addViewInLayout(paramView, 0, layoutParams2);
    paramView.setSelected(hasFocus());
    int i = ViewGroup.getChildMeasureSpec(this.mHeightMeasureSpec, this.mSpinnerPadding.top + this.mSpinnerPadding.bottom, layoutParams2.height);
    paramView.measure(ViewGroup.getChildMeasureSpec(this.mWidthMeasureSpec, this.mSpinnerPadding.left + this.mSpinnerPadding.right, layoutParams2.width), i);
    i = this.mSpinnerPadding.top + (getMeasuredHeight() - this.mSpinnerPadding.bottom - this.mSpinnerPadding.top - paramView.getMeasuredHeight()) / 2;
    int j = paramView.getMeasuredHeight();
    paramView.layout(0, i, 0 + paramView.getMeasuredWidth(), i + j);
  }
  
  public int getBaseline() {
    View view2;
    byte b = -1;
    View view1 = null;
    if (getChildCount() > 0) {
      view2 = getChildAt(0);
    } else {
      view2 = view1;
      if (this.mAdapter != null) {
        view2 = view1;
        if (this.mAdapter.getCount() > 0) {
          view2 = makeAndAddView(0);
          this.mRecycler.put(0, view2);
          removeAllViewsInLayout();
        } 
      } 
    } 
    int i = b;
    if (view2 != null) {
      int j = view2.getBaseline();
      i = b;
      if (j >= 0)
        i = view2.getTop() + j; 
    } 
    return i;
  }
  
  public CharSequence getPrompt() {
    return this.mPopup.getHintText();
  }
  
  void layout(int paramInt, boolean paramBoolean) {
    int i = this.mSpinnerPadding.left;
    int j = getRight() - getLeft() - this.mSpinnerPadding.left - this.mSpinnerPadding.right;
    if (this.mDataChanged)
      handleDataChanged(); 
    if (this.mItemCount == 0) {
      resetList();
      return;
    } 
    if (this.mNextSelectedPosition >= 0)
      setSelectedPositionInt(this.mNextSelectedPosition); 
    recycleAllViews();
    removeAllViewsInLayout();
    this.mFirstPosition = this.mSelectedPosition;
    View view = makeAndAddView(this.mSelectedPosition);
    int k = view.getMeasuredWidth();
    paramInt = i;
    switch (this.mGravity & 0x7) {
      default:
        view.offsetLeftAndRight(paramInt);
        this.mRecycler.clear();
        invalidate();
        checkSelectionChanged();
        this.mDataChanged = false;
        this.mNeedSync = false;
        setNextSelectedPositionInt(this.mSelectedPosition);
        return;
      case 1:
        paramInt = j / 2 + i - k / 2;
      case 5:
        break;
    } 
    paramInt = i + j - k;
  }
  
  int measureContentWidth(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable) {
    if (paramSpinnerAdapter == null)
      return 0; 
    int j = 0;
    View view = null;
    int k = 0;
    int m = View.MeasureSpec.makeMeasureSpec(0, 0);
    int n = View.MeasureSpec.makeMeasureSpec(0, 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i1 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int i2 = Math.max(0, i - 15 - i1 - i);
    while (i2 < i1) {
      int i3 = paramSpinnerAdapter.getItemViewType(i2);
      i = k;
      if (i3 != k) {
        i = i3;
        view = null;
      } 
      view = paramSpinnerAdapter.getView(i2, view, this);
      if (view.getLayoutParams() == null)
        view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
      view.measure(m, n);
      j = Math.max(j, view.getMeasuredWidth());
      i2++;
      k = i;
    } 
    i = j;
    if (paramDrawable != null) {
      paramDrawable.getPadding(this.mTempRect);
      i = j + this.mTempRect.left + this.mTempRect.right;
    } 
    return i;
  }
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt) {
    setSelection(paramInt);
    paramDialogInterface.dismiss();
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    if (this.mPopup != null && this.mPopup.isShowing())
      this.mPopup.dismiss(); 
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    this.mInLayout = true;
    layout(0, false);
    this.mInLayout = false;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.mPopup != null && View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), measureContentWidth(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight()); 
  }
  
  public boolean performClick() {
    boolean bool1 = super.performClick();
    boolean bool2 = bool1;
    if (!bool1) {
      bool1 = true;
      bool2 = bool1;
      if (!this.mPopup.isShowing()) {
        this.mPopup.show();
        bool2 = bool1;
      } 
    } 
    return bool2;
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    super.setAdapter(paramSpinnerAdapter);
    if (this.mPopup != null) {
      this.mPopup.setAdapter(new DropDownAdapter(paramSpinnerAdapter));
      return;
    } 
    this.mTempAdapter = new DropDownAdapter(paramSpinnerAdapter);
  }
  
  public void setGravity(int paramInt) {
    if (this.mGravity != paramInt) {
      int i = paramInt;
      if ((paramInt & 0x7) == 0)
        i = paramInt | 0x3; 
      this.mGravity = i;
      requestLayout();
    } 
  }
  
  public void setOnItemClickListener(AdapterViewICS.OnItemClickListener paramOnItemClickListener) {
    throw new RuntimeException("setOnItemClickListener cannot be used with a spinner.");
  }
  
  void setOnItemClickListenerInt(AdapterViewICS.OnItemClickListener paramOnItemClickListener) {
    super.setOnItemClickListener(paramOnItemClickListener);
  }
  
  public void setPrompt(CharSequence paramCharSequence) {
    this.mPopup.setPromptText(paramCharSequence);
  }
  
  public void setPromptId(int paramInt) {
    setPrompt(getContext().getText(paramInt));
  }
  
  private class DialogPopup implements SpinnerPopup, DialogInterface.OnClickListener {
    private ListAdapter mListAdapter;
    
    private AlertDialog mPopup;
    
    private CharSequence mPrompt;
    
    private DialogPopup() {}
    
    public void dismiss() {
      this.mPopup.dismiss();
      this.mPopup = null;
    }
    
    public CharSequence getHintText() {
      return this.mPrompt;
    }
    
    public boolean isShowing() {
      return (this.mPopup != null) ? this.mPopup.isShowing() : false;
    }
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      SpinnerICS.this.setSelection(param1Int);
      if (SpinnerICS.this.mOnItemClickListener != null)
        SpinnerICS.this.performItemClick((View)null, param1Int, this.mListAdapter.getItemId(param1Int)); 
      dismiss();
    }
    
    public void setAdapter(ListAdapter param1ListAdapter) {
      this.mListAdapter = param1ListAdapter;
    }
    
    public void setPromptText(CharSequence param1CharSequence) {
      this.mPrompt = param1CharSequence;
    }
    
    public void show() {
      AlertDialog.Builder builder = new AlertDialog.Builder(SpinnerICS.this.getContext());
      if (this.mPrompt != null)
        builder.setTitle(this.mPrompt); 
      this.mPopup = builder.setSingleChoiceItems(this.mListAdapter, SpinnerICS.this.getSelectedItemPosition(), this).show();
    }
  }
  
  private static class DropDownAdapter implements ListAdapter, SpinnerAdapter {
    private SpinnerAdapter mAdapter;
    
    private ListAdapter mListAdapter;
    
    public DropDownAdapter(SpinnerAdapter param1SpinnerAdapter) {
      this.mAdapter = param1SpinnerAdapter;
      if (param1SpinnerAdapter instanceof ListAdapter)
        this.mListAdapter = (ListAdapter)param1SpinnerAdapter; 
    }
    
    public boolean areAllItemsEnabled() {
      ListAdapter listAdapter = this.mListAdapter;
      return (listAdapter != null) ? listAdapter.areAllItemsEnabled() : true;
    }
    
    public int getCount() {
      return (this.mAdapter == null) ? 0 : this.mAdapter.getCount();
    }
    
    public View getDropDownView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      return (this.mAdapter == null) ? null : this.mAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public Object getItem(int param1Int) {
      return (this.mAdapter == null) ? null : this.mAdapter.getItem(param1Int);
    }
    
    public long getItemId(int param1Int) {
      return (this.mAdapter == null) ? -1L : this.mAdapter.getItemId(param1Int);
    }
    
    public int getItemViewType(int param1Int) {
      return 0;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      return getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public int getViewTypeCount() {
      return 1;
    }
    
    public boolean hasStableIds() {
      return (this.mAdapter != null && this.mAdapter.hasStableIds());
    }
    
    public boolean isEmpty() {
      return (getCount() == 0);
    }
    
    public boolean isEnabled(int param1Int) {
      ListAdapter listAdapter = this.mListAdapter;
      return (listAdapter != null) ? listAdapter.isEnabled(param1Int) : true;
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      if (this.mAdapter != null)
        this.mAdapter.registerDataSetObserver(param1DataSetObserver); 
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      if (this.mAdapter != null)
        this.mAdapter.unregisterDataSetObserver(param1DataSetObserver); 
    }
  }
  
  private class DropdownPopup extends ListPopupWindow implements SpinnerPopup {
    private ListAdapter mAdapter;
    
    private CharSequence mHintText;
    
    public DropdownPopup(Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int);
      setAnchorView((View)SpinnerICS.this);
      setModal(true);
      setPromptPosition(0);
      setOnItemClickListener(new AdapterViewICS.OnItemClickListenerWrapper(SpinnerICS.this, new AdapterViewICS.OnItemClickListener() {
              public void onItemClick(AdapterViewICS param2AdapterViewICS, View param2View, int param2Int, long param2Long) {
                SpinnerICS.this.setSelection(param2Int);
                if (SpinnerICS.this.mOnItemClickListener != null)
                  SpinnerICS.this.performItemClick(param2View, param2Int, SpinnerICS.DropdownPopup.this.mAdapter.getItemId(param2Int)); 
                SpinnerICS.DropdownPopup.this.dismiss();
              }
            }));
    }
    
    public CharSequence getHintText() {
      return this.mHintText;
    }
    
    public void setAdapter(ListAdapter param1ListAdapter) {
      super.setAdapter(param1ListAdapter);
      this.mAdapter = param1ListAdapter;
    }
    
    public void setPromptText(CharSequence param1CharSequence) {
      this.mHintText = param1CharSequence;
    }
    
    public void show() {
      int i = SpinnerICS.this.getPaddingLeft();
      if (SpinnerICS.this.mDropDownWidth == -2) {
        int k = SpinnerICS.this.getWidth();
        int m = SpinnerICS.this.getPaddingRight();
        setContentWidth(Math.max(SpinnerICS.this.measureContentWidth((SpinnerAdapter)this.mAdapter, getBackground()), k - i - m));
      } else if (SpinnerICS.this.mDropDownWidth == -1) {
        setContentWidth(SpinnerICS.this.getWidth() - i - SpinnerICS.this.getPaddingRight());
      } else {
        setContentWidth(SpinnerICS.this.mDropDownWidth);
      } 
      Drawable drawable = getBackground();
      int j = 0;
      if (drawable != null) {
        drawable.getPadding(SpinnerICS.this.mTempRect);
        j = -SpinnerICS.this.mTempRect.left;
      } 
      setHorizontalOffset(j + i);
      setInputMethodMode(2);
      super.show();
      getListView().setChoiceMode(1);
      setSelection(SpinnerICS.this.getSelectedItemPosition());
    }
  }
  
  class null implements AdapterViewICS.OnItemClickListener {
    public void onItemClick(AdapterViewICS param1AdapterViewICS, View param1View, int param1Int, long param1Long) {
      SpinnerICS.this.setSelection(param1Int);
      if (SpinnerICS.this.mOnItemClickListener != null)
        SpinnerICS.this.performItemClick(param1View, param1Int, this.this$1.mAdapter.getItemId(param1Int)); 
      this.this$1.dismiss();
    }
  }
  
  private static interface SpinnerPopup {
    void dismiss();
    
    CharSequence getHintText();
    
    boolean isShowing();
    
    void setAdapter(ListAdapter param1ListAdapter);
    
    void setPromptText(CharSequence param1CharSequence);
    
    void show();
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/widget/SpinnerICS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */