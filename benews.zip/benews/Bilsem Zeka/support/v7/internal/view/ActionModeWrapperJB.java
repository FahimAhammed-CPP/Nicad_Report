package android.support.v7.internal.view;

import android.content.Context;
import android.support.v7.view.ActionMode;
import android.view.ActionMode;

public class ActionModeWrapperJB extends ActionModeWrapper {
  public ActionModeWrapperJB(Context paramContext, ActionMode paramActionMode) {
    super(paramContext, paramActionMode);
  }
  
  public boolean getTitleOptionalHint() {
    return this.mWrappedObject.getTitleOptionalHint();
  }
  
  public boolean isTitleOptional() {
    return this.mWrappedObject.isTitleOptional();
  }
  
  public void setTitleOptionalHint(boolean paramBoolean) {
    this.mWrappedObject.setTitleOptionalHint(paramBoolean);
  }
  
  public static class CallbackWrapper extends ActionModeWrapper.CallbackWrapper {
    public CallbackWrapper(Context param1Context, ActionMode.Callback param1Callback) {
      super(param1Context, param1Callback);
    }
    
    protected ActionModeWrapper createActionModeWrapper(Context param1Context, ActionMode param1ActionMode) {
      return new ActionModeWrapperJB(param1Context, param1ActionMode);
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/view/ActionModeWrapperJB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */