package android.support.v7.internal.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.support.v4.view.ActionProvider;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.appcompat.R;
import android.support.v7.internal.view.menu.MenuItemImpl;
import android.support.v7.internal.view.menu.MenuItemWrapperICS;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import java.io.IOException;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class SupportMenuInflater extends MenuInflater {
  private static final Class<?>[] ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE;
  
  private static final Class<?>[] ACTION_VIEW_CONSTRUCTOR_SIGNATURE = new Class[] { Context.class };
  
  private static final String LOG_TAG = "SupportMenuInflater";
  
  private static final int NO_ID = 0;
  
  private static final String XML_GROUP = "group";
  
  private static final String XML_ITEM = "item";
  
  private static final String XML_MENU = "menu";
  
  private final Object[] mActionProviderConstructorArguments;
  
  private final Object[] mActionViewConstructorArguments;
  
  private Context mContext;
  
  private Object mRealOwner;
  
  static {
    ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE = ACTION_VIEW_CONSTRUCTOR_SIGNATURE;
  }
  
  public SupportMenuInflater(Context paramContext) {
    super(paramContext);
    this.mContext = paramContext;
    this.mRealOwner = paramContext;
    this.mActionViewConstructorArguments = new Object[] { paramContext };
    this.mActionProviderConstructorArguments = this.mActionViewConstructorArguments;
  }
  
  private void parseMenu(XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Menu paramMenu) throws XmlPullParserException, IOException {
    // Byte code:
    //   0: new android/support/v7/internal/view/SupportMenuInflater$MenuState
    //   3: dup
    //   4: aload_0
    //   5: aload_3
    //   6: invokespecial <init> : (Landroid/support/v7/internal/view/SupportMenuInflater;Landroid/view/Menu;)V
    //   9: astore #4
    //   11: aload_1
    //   12: invokeinterface getEventType : ()I
    //   17: istore #5
    //   19: iconst_0
    //   20: istore #6
    //   22: aconst_null
    //   23: astore #7
    //   25: iload #5
    //   27: iconst_2
    //   28: if_icmpne -> 156
    //   31: aload_1
    //   32: invokeinterface getName : ()Ljava/lang/String;
    //   37: astore_3
    //   38: aload_3
    //   39: ldc 'menu'
    //   41: invokevirtual equals : (Ljava/lang/Object;)Z
    //   44: ifeq -> 129
    //   47: aload_1
    //   48: invokeinterface next : ()I
    //   53: istore #8
    //   55: iconst_0
    //   56: istore #5
    //   58: iload #8
    //   60: istore #9
    //   62: iload #5
    //   64: ifne -> 497
    //   67: iload #9
    //   69: tableswitch default -> 96, 1 -> 487, 2 -> 177, 3 -> 302
    //   96: aload #7
    //   98: astore_3
    //   99: iload #5
    //   101: istore #10
    //   103: iload #6
    //   105: istore #8
    //   107: aload_1
    //   108: invokeinterface next : ()I
    //   113: istore #9
    //   115: iload #8
    //   117: istore #6
    //   119: iload #10
    //   121: istore #5
    //   123: aload_3
    //   124: astore #7
    //   126: goto -> 62
    //   129: new java/lang/RuntimeException
    //   132: dup
    //   133: new java/lang/StringBuilder
    //   136: dup
    //   137: invokespecial <init> : ()V
    //   140: ldc 'Expecting menu, got '
    //   142: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: aload_3
    //   146: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   149: invokevirtual toString : ()Ljava/lang/String;
    //   152: invokespecial <init> : (Ljava/lang/String;)V
    //   155: athrow
    //   156: aload_1
    //   157: invokeinterface next : ()I
    //   162: istore #8
    //   164: iload #8
    //   166: istore #5
    //   168: iload #8
    //   170: iconst_1
    //   171: if_icmpne -> 25
    //   174: goto -> 55
    //   177: iload #6
    //   179: istore #8
    //   181: iload #5
    //   183: istore #10
    //   185: aload #7
    //   187: astore_3
    //   188: iload #6
    //   190: ifne -> 107
    //   193: aload_1
    //   194: invokeinterface getName : ()Ljava/lang/String;
    //   199: astore_3
    //   200: aload_3
    //   201: ldc 'group'
    //   203: invokevirtual equals : (Ljava/lang/Object;)Z
    //   206: ifeq -> 229
    //   209: aload #4
    //   211: aload_2
    //   212: invokevirtual readGroup : (Landroid/util/AttributeSet;)V
    //   215: iload #6
    //   217: istore #8
    //   219: iload #5
    //   221: istore #10
    //   223: aload #7
    //   225: astore_3
    //   226: goto -> 107
    //   229: aload_3
    //   230: ldc 'item'
    //   232: invokevirtual equals : (Ljava/lang/Object;)Z
    //   235: ifeq -> 258
    //   238: aload #4
    //   240: aload_2
    //   241: invokevirtual readItem : (Landroid/util/AttributeSet;)V
    //   244: iload #6
    //   246: istore #8
    //   248: iload #5
    //   250: istore #10
    //   252: aload #7
    //   254: astore_3
    //   255: goto -> 107
    //   258: aload_3
    //   259: ldc 'menu'
    //   261: invokevirtual equals : (Ljava/lang/Object;)Z
    //   264: ifeq -> 292
    //   267: aload_0
    //   268: aload_1
    //   269: aload_2
    //   270: aload #4
    //   272: invokevirtual addSubMenuItem : ()Landroid/view/SubMenu;
    //   275: invokespecial parseMenu : (Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/view/Menu;)V
    //   278: iload #6
    //   280: istore #8
    //   282: iload #5
    //   284: istore #10
    //   286: aload #7
    //   288: astore_3
    //   289: goto -> 107
    //   292: iconst_1
    //   293: istore #8
    //   295: iload #5
    //   297: istore #10
    //   299: goto -> 107
    //   302: aload_1
    //   303: invokeinterface getName : ()Ljava/lang/String;
    //   308: astore #11
    //   310: iload #6
    //   312: ifeq -> 337
    //   315: aload #11
    //   317: aload #7
    //   319: invokevirtual equals : (Ljava/lang/Object;)Z
    //   322: ifeq -> 337
    //   325: iconst_0
    //   326: istore #8
    //   328: aconst_null
    //   329: astore_3
    //   330: iload #5
    //   332: istore #10
    //   334: goto -> 107
    //   337: aload #11
    //   339: ldc 'group'
    //   341: invokevirtual equals : (Ljava/lang/Object;)Z
    //   344: ifeq -> 366
    //   347: aload #4
    //   349: invokevirtual resetGroup : ()V
    //   352: iload #6
    //   354: istore #8
    //   356: iload #5
    //   358: istore #10
    //   360: aload #7
    //   362: astore_3
    //   363: goto -> 107
    //   366: aload #11
    //   368: ldc 'item'
    //   370: invokevirtual equals : (Ljava/lang/Object;)Z
    //   373: ifeq -> 453
    //   376: iload #6
    //   378: istore #8
    //   380: iload #5
    //   382: istore #10
    //   384: aload #7
    //   386: astore_3
    //   387: aload #4
    //   389: invokevirtual hasAddedItem : ()Z
    //   392: ifne -> 107
    //   395: aload #4
    //   397: invokestatic access$000 : (Landroid/support/v7/internal/view/SupportMenuInflater$MenuState;)Landroid/support/v4/view/ActionProvider;
    //   400: ifnull -> 434
    //   403: aload #4
    //   405: invokestatic access$000 : (Landroid/support/v7/internal/view/SupportMenuInflater$MenuState;)Landroid/support/v4/view/ActionProvider;
    //   408: invokevirtual hasSubMenu : ()Z
    //   411: ifeq -> 434
    //   414: aload #4
    //   416: invokevirtual addSubMenuItem : ()Landroid/view/SubMenu;
    //   419: pop
    //   420: iload #6
    //   422: istore #8
    //   424: iload #5
    //   426: istore #10
    //   428: aload #7
    //   430: astore_3
    //   431: goto -> 107
    //   434: aload #4
    //   436: invokevirtual addItem : ()V
    //   439: iload #6
    //   441: istore #8
    //   443: iload #5
    //   445: istore #10
    //   447: aload #7
    //   449: astore_3
    //   450: goto -> 107
    //   453: iload #6
    //   455: istore #8
    //   457: iload #5
    //   459: istore #10
    //   461: aload #7
    //   463: astore_3
    //   464: aload #11
    //   466: ldc 'menu'
    //   468: invokevirtual equals : (Ljava/lang/Object;)Z
    //   471: ifeq -> 107
    //   474: iconst_1
    //   475: istore #10
    //   477: iload #6
    //   479: istore #8
    //   481: aload #7
    //   483: astore_3
    //   484: goto -> 107
    //   487: new java/lang/RuntimeException
    //   490: dup
    //   491: ldc 'Unexpected end of document'
    //   493: invokespecial <init> : (Ljava/lang/String;)V
    //   496: athrow
    //   497: return
  }
  
  public void inflate(int paramInt, Menu paramMenu) {
    XmlPullParserException xmlPullParserException1;
    if (!(paramMenu instanceof android.support.v4.internal.view.SupportMenu)) {
      super.inflate(paramInt, paramMenu);
      return;
    } 
    XmlResourceParser xmlResourceParser1 = null;
    XmlResourceParser xmlResourceParser2 = null;
    XmlResourceParser xmlResourceParser3 = null;
    try {
      XmlResourceParser xmlResourceParser = this.mContext.getResources().getLayout(paramInt);
      xmlResourceParser3 = xmlResourceParser;
      xmlResourceParser1 = xmlResourceParser;
      xmlResourceParser2 = xmlResourceParser;
      parseMenu((XmlPullParser)xmlResourceParser, Xml.asAttributeSet((XmlPullParser)xmlResourceParser), paramMenu);
      return;
    } catch (XmlPullParserException xmlPullParserException2) {
      xmlResourceParser1 = xmlResourceParser3;
      InflateException inflateException = new InflateException();
      xmlResourceParser1 = xmlResourceParser3;
      this("Error inflating menu XML", (Throwable)xmlPullParserException2);
      xmlResourceParser1 = xmlResourceParser3;
      throw inflateException;
    } catch (IOException iOException) {
      xmlPullParserException1 = xmlPullParserException2;
      InflateException inflateException = new InflateException();
      xmlPullParserException1 = xmlPullParserException2;
      this("Error inflating menu XML", iOException);
      xmlPullParserException1 = xmlPullParserException2;
      throw inflateException;
    } finally {
      if (xmlPullParserException1 != null)
        xmlPullParserException1.close(); 
    } 
  }
  
  private static class InflatedOnMenuItemClickListener implements MenuItem.OnMenuItemClickListener {
    private static final Class<?>[] PARAM_TYPES = new Class[] { MenuItem.class };
    
    private Method mMethod;
    
    private Object mRealOwner;
    
    public InflatedOnMenuItemClickListener(Object param1Object, String param1String) {
      this.mRealOwner = param1Object;
      Class<?> clazz = param1Object.getClass();
      try {
        this.mMethod = clazz.getMethod(param1String, PARAM_TYPES);
        return;
      } catch (Exception exception) {
        InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + param1String + " in class " + clazz.getName());
        inflateException.initCause(exception);
        throw inflateException;
      } 
    }
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      boolean bool = true;
      try {
        if (this.mMethod.getReturnType() == boolean.class)
          return ((Boolean)this.mMethod.invoke(this.mRealOwner, new Object[] { param1MenuItem })).booleanValue(); 
        this.mMethod.invoke(this.mRealOwner, new Object[] { param1MenuItem });
        return bool;
      } catch (Exception exception) {
        throw new RuntimeException(exception);
      } 
    }
  }
  
  private class MenuState {
    private static final int defaultGroupId = 0;
    
    private static final int defaultItemCategory = 0;
    
    private static final int defaultItemCheckable = 0;
    
    private static final boolean defaultItemChecked = false;
    
    private static final boolean defaultItemEnabled = true;
    
    private static final int defaultItemId = 0;
    
    private static final int defaultItemOrder = 0;
    
    private static final boolean defaultItemVisible = true;
    
    private int groupCategory;
    
    private int groupCheckable;
    
    private boolean groupEnabled;
    
    private int groupId;
    
    private int groupOrder;
    
    private boolean groupVisible;
    
    private ActionProvider itemActionProvider;
    
    private String itemActionProviderClassName;
    
    private String itemActionViewClassName;
    
    private int itemActionViewLayout;
    
    private boolean itemAdded;
    
    private char itemAlphabeticShortcut;
    
    private int itemCategoryOrder;
    
    private int itemCheckable;
    
    private boolean itemChecked;
    
    private boolean itemEnabled;
    
    private int itemIconResId;
    
    private int itemId;
    
    private String itemListenerMethodName;
    
    private char itemNumericShortcut;
    
    private int itemShowAsAction;
    
    private CharSequence itemTitle;
    
    private CharSequence itemTitleCondensed;
    
    private boolean itemVisible;
    
    private Menu menu;
    
    public MenuState(Menu param1Menu) {
      this.menu = param1Menu;
      resetGroup();
    }
    
    private char getShortcut(String param1String) {
      char c = Character.MIN_VALUE;
      if (param1String == null)
        return c; 
      c = param1String.charAt(0);
      return c;
    }
    
    private <T> T newInstance(String param1String, Class<?>[] param1ArrayOfClass, Object[] param1ArrayOfObject) {
      Class<?>[] arrayOfClass;
      try {
        param1ArrayOfClass = SupportMenuInflater.this.mContext.getClassLoader().loadClass(param1String).getConstructor(param1ArrayOfClass).newInstance(param1ArrayOfObject);
        arrayOfClass = param1ArrayOfClass;
      } catch (Exception exception) {
        Log.w("SupportMenuInflater", "Cannot instantiate class: " + arrayOfClass, exception);
        arrayOfClass = null;
      } 
      return (T)arrayOfClass;
    }
    
    private void setItem(MenuItem param1MenuItem) {
      boolean bool1;
      MenuItem menuItem = param1MenuItem.setChecked(this.itemChecked).setVisible(this.itemVisible).setEnabled(this.itemEnabled);
      if (this.itemCheckable >= 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      menuItem.setCheckable(bool1).setTitleCondensed(this.itemTitleCondensed).setIcon(this.itemIconResId).setAlphabeticShortcut(this.itemAlphabeticShortcut).setNumericShortcut(this.itemNumericShortcut);
      if (this.itemShowAsAction >= 0)
        MenuItemCompat.setShowAsAction(param1MenuItem, this.itemShowAsAction); 
      if (this.itemListenerMethodName != null) {
        if (SupportMenuInflater.this.mContext.isRestricted())
          throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context"); 
        param1MenuItem.setOnMenuItemClickListener(new SupportMenuInflater.InflatedOnMenuItemClickListener(SupportMenuInflater.this.mRealOwner, this.itemListenerMethodName));
      } 
      if (param1MenuItem instanceof MenuItemImpl)
        MenuItemImpl menuItemImpl = (MenuItemImpl)param1MenuItem; 
      if (this.itemCheckable >= 2)
        if (param1MenuItem instanceof MenuItemImpl) {
          ((MenuItemImpl)param1MenuItem).setExclusiveCheckable(true);
        } else if (param1MenuItem instanceof MenuItemWrapperICS) {
          ((MenuItemWrapperICS)param1MenuItem).setExclusiveCheckable(true);
        }  
      boolean bool2 = false;
      if (this.itemActionViewClassName != null) {
        MenuItemCompat.setActionView(param1MenuItem, newInstance(this.itemActionViewClassName, SupportMenuInflater.ACTION_VIEW_CONSTRUCTOR_SIGNATURE, SupportMenuInflater.this.mActionViewConstructorArguments));
        bool2 = true;
      } 
      if (this.itemActionViewLayout > 0)
        if (!bool2) {
          MenuItemCompat.setActionView(param1MenuItem, this.itemActionViewLayout);
        } else {
          Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
        }  
      if (this.itemActionProvider != null)
        MenuItemCompat.setActionProvider(param1MenuItem, this.itemActionProvider); 
    }
    
    public void addItem() {
      this.itemAdded = true;
      setItem(this.menu.add(this.groupId, this.itemId, this.itemCategoryOrder, this.itemTitle));
    }
    
    public SubMenu addSubMenuItem() {
      this.itemAdded = true;
      SubMenu subMenu = this.menu.addSubMenu(this.groupId, this.itemId, this.itemCategoryOrder, this.itemTitle);
      setItem(subMenu.getItem());
      return subMenu;
    }
    
    public boolean hasAddedItem() {
      return this.itemAdded;
    }
    
    public void readGroup(AttributeSet param1AttributeSet) {
      TypedArray typedArray = SupportMenuInflater.this.mContext.obtainStyledAttributes(param1AttributeSet, R.styleable.MenuGroup);
      this.groupId = typedArray.getResourceId(1, 0);
      this.groupCategory = typedArray.getInt(3, 0);
      this.groupOrder = typedArray.getInt(4, 0);
      this.groupCheckable = typedArray.getInt(5, 0);
      this.groupVisible = typedArray.getBoolean(2, true);
      this.groupEnabled = typedArray.getBoolean(0, true);
      typedArray.recycle();
    }
    
    public void readItem(AttributeSet param1AttributeSet) {
      boolean bool;
      TypedArray typedArray = SupportMenuInflater.this.mContext.obtainStyledAttributes(param1AttributeSet, R.styleable.MenuItem);
      this.itemId = typedArray.getResourceId(2, 0);
      this.itemCategoryOrder = 0xFFFF0000 & typedArray.getInt(5, this.groupCategory) | 0xFFFF & typedArray.getInt(6, this.groupOrder);
      this.itemTitle = typedArray.getText(7);
      this.itemTitleCondensed = typedArray.getText(8);
      this.itemIconResId = typedArray.getResourceId(0, 0);
      this.itemAlphabeticShortcut = getShortcut(typedArray.getString(9));
      this.itemNumericShortcut = getShortcut(typedArray.getString(10));
      if (typedArray.hasValue(11)) {
        if (typedArray.getBoolean(11, false)) {
          bool = true;
        } else {
          bool = false;
        } 
        this.itemCheckable = bool;
      } else {
        this.itemCheckable = this.groupCheckable;
      } 
      this.itemChecked = typedArray.getBoolean(3, false);
      this.itemVisible = typedArray.getBoolean(4, this.groupVisible);
      this.itemEnabled = typedArray.getBoolean(1, this.groupEnabled);
      this.itemShowAsAction = typedArray.getInt(13, -1);
      this.itemListenerMethodName = typedArray.getString(12);
      this.itemActionViewLayout = typedArray.getResourceId(14, 0);
      this.itemActionViewClassName = typedArray.getString(15);
      this.itemActionProviderClassName = typedArray.getString(16);
      if (this.itemActionProviderClassName != null) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool && this.itemActionViewLayout == 0 && this.itemActionViewClassName == null) {
        this.itemActionProvider = newInstance(this.itemActionProviderClassName, SupportMenuInflater.ACTION_PROVIDER_CONSTRUCTOR_SIGNATURE, SupportMenuInflater.this.mActionProviderConstructorArguments);
      } else {
        if (bool)
          Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified."); 
        this.itemActionProvider = null;
      } 
      typedArray.recycle();
      this.itemAdded = false;
    }
    
    public void resetGroup() {
      this.groupId = 0;
      this.groupCategory = 0;
      this.groupOrder = 0;
      this.groupCheckable = 0;
      this.groupVisible = true;
      this.groupEnabled = true;
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/view/SupportMenuInflater.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */