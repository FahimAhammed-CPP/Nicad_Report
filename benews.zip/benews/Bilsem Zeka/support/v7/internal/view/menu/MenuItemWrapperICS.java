package android.support.v7.internal.view.menu;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v4.internal.view.SupportMenuItem;
import android.support.v4.view.ActionProvider;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.view.CollapsibleActionView;
import android.util.Log;
import android.view.ActionProvider;
import android.view.CollapsibleActionView;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.FrameLayout;
import java.lang.reflect.Method;

public class MenuItemWrapperICS extends BaseMenuWrapper<MenuItem> implements SupportMenuItem {
  static final String LOG_TAG = "MenuItemWrapper";
  
  private final boolean mEmulateProviderVisibilityOverride;
  
  private boolean mLastRequestVisible;
  
  private Method mSetExclusiveCheckableMethod;
  
  MenuItemWrapperICS(MenuItem paramMenuItem) {
    this(paramMenuItem, true);
  }
  
  MenuItemWrapperICS(MenuItem paramMenuItem, boolean paramBoolean) {
    super(paramMenuItem);
    this.mLastRequestVisible = paramMenuItem.isVisible();
    this.mEmulateProviderVisibilityOverride = paramBoolean;
  }
  
  final boolean checkActionProviderOverrideVisibility() {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (this.mLastRequestVisible) {
      ActionProvider actionProvider = getSupportActionProvider();
      bool2 = bool1;
      if (actionProvider != null) {
        bool2 = bool1;
        if (actionProvider.overridesItemVisibility()) {
          bool2 = bool1;
          if (!actionProvider.isVisible()) {
            wrappedSetVisible(false);
            bool2 = true;
          } 
        } 
      } 
    } 
    return bool2;
  }
  
  public boolean collapseActionView() {
    return this.mWrappedObject.collapseActionView();
  }
  
  ActionProviderWrapper createActionProviderWrapper(ActionProvider paramActionProvider) {
    return new ActionProviderWrapper(paramActionProvider);
  }
  
  public boolean expandActionView() {
    return this.mWrappedObject.expandActionView();
  }
  
  public ActionProvider getActionProvider() {
    return this.mWrappedObject.getActionProvider();
  }
  
  public View getActionView() {
    View view1 = this.mWrappedObject.getActionView();
    View view2 = view1;
    if (view1 instanceof CollapsibleActionViewWrapper)
      view2 = ((CollapsibleActionViewWrapper)view1).getWrappedView(); 
    return view2;
  }
  
  public char getAlphabeticShortcut() {
    return this.mWrappedObject.getAlphabeticShortcut();
  }
  
  public int getGroupId() {
    return this.mWrappedObject.getGroupId();
  }
  
  public Drawable getIcon() {
    return this.mWrappedObject.getIcon();
  }
  
  public Intent getIntent() {
    return this.mWrappedObject.getIntent();
  }
  
  public int getItemId() {
    return this.mWrappedObject.getItemId();
  }
  
  public ContextMenu.ContextMenuInfo getMenuInfo() {
    return this.mWrappedObject.getMenuInfo();
  }
  
  public char getNumericShortcut() {
    return this.mWrappedObject.getNumericShortcut();
  }
  
  public int getOrder() {
    return this.mWrappedObject.getOrder();
  }
  
  public SubMenu getSubMenu() {
    return getSubMenuWrapper(this.mWrappedObject.getSubMenu());
  }
  
  public ActionProvider getSupportActionProvider() {
    null = (ActionProviderWrapper)this.mWrappedObject.getActionProvider();
    return (null != null) ? null.mInner : null;
  }
  
  public CharSequence getTitle() {
    return this.mWrappedObject.getTitle();
  }
  
  public CharSequence getTitleCondensed() {
    return this.mWrappedObject.getTitleCondensed();
  }
  
  public boolean hasSubMenu() {
    return this.mWrappedObject.hasSubMenu();
  }
  
  public boolean isActionViewExpanded() {
    return this.mWrappedObject.isActionViewExpanded();
  }
  
  public boolean isCheckable() {
    return this.mWrappedObject.isCheckable();
  }
  
  public boolean isChecked() {
    return this.mWrappedObject.isChecked();
  }
  
  public boolean isEnabled() {
    return this.mWrappedObject.isEnabled();
  }
  
  public boolean isVisible() {
    return this.mWrappedObject.isVisible();
  }
  
  public MenuItem setActionProvider(ActionProvider paramActionProvider) {
    this.mWrappedObject.setActionProvider(paramActionProvider);
    if (paramActionProvider != null && this.mEmulateProviderVisibilityOverride)
      checkActionProviderOverrideVisibility(); 
    return (MenuItem)this;
  }
  
  public MenuItem setActionView(int paramInt) {
    this.mWrappedObject.setActionView(paramInt);
    View view = this.mWrappedObject.getActionView();
    if (view instanceof CollapsibleActionView)
      this.mWrappedObject.setActionView((View)new CollapsibleActionViewWrapper(view)); 
    return (MenuItem)this;
  }
  
  public MenuItem setActionView(View paramView) {
    CollapsibleActionViewWrapper collapsibleActionViewWrapper;
    View view = paramView;
    if (paramView instanceof CollapsibleActionView)
      collapsibleActionViewWrapper = new CollapsibleActionViewWrapper(paramView); 
    this.mWrappedObject.setActionView((View)collapsibleActionViewWrapper);
    return (MenuItem)this;
  }
  
  public MenuItem setAlphabeticShortcut(char paramChar) {
    this.mWrappedObject.setAlphabeticShortcut(paramChar);
    return (MenuItem)this;
  }
  
  public MenuItem setCheckable(boolean paramBoolean) {
    this.mWrappedObject.setCheckable(paramBoolean);
    return (MenuItem)this;
  }
  
  public MenuItem setChecked(boolean paramBoolean) {
    this.mWrappedObject.setChecked(paramBoolean);
    return (MenuItem)this;
  }
  
  public MenuItem setEnabled(boolean paramBoolean) {
    this.mWrappedObject.setEnabled(paramBoolean);
    return (MenuItem)this;
  }
  
  public void setExclusiveCheckable(boolean paramBoolean) {
    try {
      if (this.mSetExclusiveCheckableMethod == null)
        this.mSetExclusiveCheckableMethod = this.mWrappedObject.getClass().getDeclaredMethod("setExclusiveCheckable", new Class[] { boolean.class }); 
      this.mSetExclusiveCheckableMethod.invoke(this.mWrappedObject, new Object[] { Boolean.valueOf(paramBoolean) });
    } catch (Exception exception) {
      Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", exception);
    } 
  }
  
  public MenuItem setIcon(int paramInt) {
    this.mWrappedObject.setIcon(paramInt);
    return (MenuItem)this;
  }
  
  public MenuItem setIcon(Drawable paramDrawable) {
    this.mWrappedObject.setIcon(paramDrawable);
    return (MenuItem)this;
  }
  
  public MenuItem setIntent(Intent paramIntent) {
    this.mWrappedObject.setIntent(paramIntent);
    return (MenuItem)this;
  }
  
  public MenuItem setNumericShortcut(char paramChar) {
    this.mWrappedObject.setNumericShortcut(paramChar);
    return (MenuItem)this;
  }
  
  public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener paramOnActionExpandListener) {
    this.mWrappedObject.setOnActionExpandListener(paramOnActionExpandListener);
    return (MenuItem)this;
  }
  
  public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener paramOnMenuItemClickListener) {
    MenuItem menuItem = this.mWrappedObject;
    if (paramOnMenuItemClickListener != null) {
      paramOnMenuItemClickListener = new OnMenuItemClickListenerWrapper(paramOnMenuItemClickListener);
      menuItem.setOnMenuItemClickListener(paramOnMenuItemClickListener);
      return (MenuItem)this;
    } 
    paramOnMenuItemClickListener = null;
    menuItem.setOnMenuItemClickListener(paramOnMenuItemClickListener);
    return (MenuItem)this;
  }
  
  public MenuItem setShortcut(char paramChar1, char paramChar2) {
    this.mWrappedObject.setShortcut(paramChar1, paramChar2);
    return (MenuItem)this;
  }
  
  public void setShowAsAction(int paramInt) {
    this.mWrappedObject.setShowAsAction(paramInt);
  }
  
  public MenuItem setShowAsActionFlags(int paramInt) {
    this.mWrappedObject.setShowAsActionFlags(paramInt);
    return (MenuItem)this;
  }
  
  public SupportMenuItem setSupportActionProvider(ActionProvider paramActionProvider) {
    MenuItem menuItem = this.mWrappedObject;
    if (paramActionProvider != null) {
      ActionProviderWrapper actionProviderWrapper = createActionProviderWrapper(paramActionProvider);
      menuItem.setActionProvider(actionProviderWrapper);
      return this;
    } 
    paramActionProvider = null;
    menuItem.setActionProvider((ActionProvider)paramActionProvider);
    return this;
  }
  
  public SupportMenuItem setSupportOnActionExpandListener(MenuItemCompat.OnActionExpandListener paramOnActionExpandListener) {
    MenuItem menuItem = this.mWrappedObject;
    if (paramOnActionExpandListener != null) {
      OnActionExpandListenerWrapper onActionExpandListenerWrapper = new OnActionExpandListenerWrapper(paramOnActionExpandListener);
      menuItem.setOnActionExpandListener(onActionExpandListenerWrapper);
      return null;
    } 
    paramOnActionExpandListener = null;
    menuItem.setOnActionExpandListener((MenuItem.OnActionExpandListener)paramOnActionExpandListener);
    return null;
  }
  
  public MenuItem setTitle(int paramInt) {
    this.mWrappedObject.setTitle(paramInt);
    return (MenuItem)this;
  }
  
  public MenuItem setTitle(CharSequence paramCharSequence) {
    this.mWrappedObject.setTitle(paramCharSequence);
    return (MenuItem)this;
  }
  
  public MenuItem setTitleCondensed(CharSequence paramCharSequence) {
    this.mWrappedObject.setTitleCondensed(paramCharSequence);
    return (MenuItem)this;
  }
  
  public MenuItem setVisible(boolean paramBoolean) {
    if (this.mEmulateProviderVisibilityOverride) {
      this.mLastRequestVisible = paramBoolean;
      if (checkActionProviderOverrideVisibility())
        return (MenuItem)this; 
    } 
    return wrappedSetVisible(paramBoolean);
  }
  
  final MenuItem wrappedSetVisible(boolean paramBoolean) {
    return this.mWrappedObject.setVisible(paramBoolean);
  }
  
  class ActionProviderWrapper extends ActionProvider {
    final ActionProvider mInner;
    
    public ActionProviderWrapper(ActionProvider param1ActionProvider) {
      super(param1ActionProvider.getContext());
      this.mInner = param1ActionProvider;
      if (MenuItemWrapperICS.this.mEmulateProviderVisibilityOverride)
        this.mInner.setVisibilityListener(new ActionProvider.VisibilityListener() {
              public void onActionProviderVisibilityChanged(boolean param2Boolean) {
                if (MenuItemWrapperICS.ActionProviderWrapper.this.mInner.overridesItemVisibility() && MenuItemWrapperICS.this.mLastRequestVisible)
                  MenuItemWrapperICS.this.wrappedSetVisible(param2Boolean); 
              }
            }); 
    }
    
    public boolean hasSubMenu() {
      return this.mInner.hasSubMenu();
    }
    
    public View onCreateActionView() {
      if (MenuItemWrapperICS.this.mEmulateProviderVisibilityOverride)
        MenuItemWrapperICS.this.checkActionProviderOverrideVisibility(); 
      return this.mInner.onCreateActionView();
    }
    
    public boolean onPerformDefaultAction() {
      return this.mInner.onPerformDefaultAction();
    }
    
    public void onPrepareSubMenu(SubMenu param1SubMenu) {
      this.mInner.onPrepareSubMenu(MenuItemWrapperICS.this.getSubMenuWrapper(param1SubMenu));
    }
  }
  
  class null implements ActionProvider.VisibilityListener {
    public void onActionProviderVisibilityChanged(boolean param1Boolean) {
      if (this.this$1.mInner.overridesItemVisibility() && MenuItemWrapperICS.this.mLastRequestVisible)
        MenuItemWrapperICS.this.wrappedSetVisible(param1Boolean); 
    }
  }
  
  static class CollapsibleActionViewWrapper extends FrameLayout implements CollapsibleActionView {
    final CollapsibleActionView mWrappedView;
    
    CollapsibleActionViewWrapper(View param1View) {
      super(param1View.getContext());
      this.mWrappedView = (CollapsibleActionView)param1View;
      addView(param1View);
    }
    
    View getWrappedView() {
      return (View)this.mWrappedView;
    }
    
    public void onActionViewCollapsed() {
      this.mWrappedView.onActionViewCollapsed();
    }
    
    public void onActionViewExpanded() {
      this.mWrappedView.onActionViewExpanded();
    }
  }
  
  private class OnActionExpandListenerWrapper extends BaseWrapper<MenuItemCompat.OnActionExpandListener> implements MenuItem.OnActionExpandListener {
    OnActionExpandListenerWrapper(MenuItemCompat.OnActionExpandListener param1OnActionExpandListener) {
      super(param1OnActionExpandListener);
    }
    
    public boolean onMenuItemActionCollapse(MenuItem param1MenuItem) {
      return this.mWrappedObject.onMenuItemActionCollapse((MenuItem)MenuItemWrapperICS.this.getMenuItemWrapper(param1MenuItem));
    }
    
    public boolean onMenuItemActionExpand(MenuItem param1MenuItem) {
      return this.mWrappedObject.onMenuItemActionExpand((MenuItem)MenuItemWrapperICS.this.getMenuItemWrapper(param1MenuItem));
    }
  }
  
  private class OnMenuItemClickListenerWrapper extends BaseWrapper<MenuItem.OnMenuItemClickListener> implements MenuItem.OnMenuItemClickListener {
    OnMenuItemClickListenerWrapper(MenuItem.OnMenuItemClickListener param1OnMenuItemClickListener) {
      super(param1OnMenuItemClickListener);
    }
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      return this.mWrappedObject.onMenuItemClick((MenuItem)MenuItemWrapperICS.this.getMenuItemWrapper(param1MenuItem));
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/view/menu/MenuItemWrapperICS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */