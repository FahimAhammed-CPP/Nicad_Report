package android.support.v7.internal.view.menu;

import android.support.v4.internal.view.SupportMenuItem;
import android.support.v4.internal.view.SupportSubMenu;
import android.view.MenuItem;
import android.view.SubMenu;
import java.util.HashMap;
import java.util.Iterator;

abstract class BaseMenuWrapper<T> extends BaseWrapper<T> {
  private HashMap<MenuItem, SupportMenuItem> mMenuItems;
  
  private HashMap<SubMenu, SubMenu> mSubMenus;
  
  BaseMenuWrapper(T paramT) {
    super(paramT);
  }
  
  final SupportMenuItem getMenuItemWrapper(MenuItem paramMenuItem) {
    if (paramMenuItem != null) {
      if (this.mMenuItems == null)
        this.mMenuItems = new HashMap<MenuItem, SupportMenuItem>(); 
      SupportMenuItem supportMenuItem1 = this.mMenuItems.get(paramMenuItem);
      SupportMenuItem supportMenuItem2 = supportMenuItem1;
      if (supportMenuItem1 == null) {
        supportMenuItem2 = MenuWrapperFactory.createSupportMenuItemWrapper(paramMenuItem);
        this.mMenuItems.put(paramMenuItem, supportMenuItem2);
      } 
      return supportMenuItem2;
    } 
    return null;
  }
  
  final SubMenu getSubMenuWrapper(SubMenu paramSubMenu) {
    if (paramSubMenu != null) {
      SupportSubMenu supportSubMenu;
      if (this.mSubMenus == null)
        this.mSubMenus = new HashMap<SubMenu, SubMenu>(); 
      SubMenu subMenu1 = this.mSubMenus.get(paramSubMenu);
      SubMenu subMenu2 = subMenu1;
      if (subMenu1 == null) {
        supportSubMenu = MenuWrapperFactory.createSupportSubMenuWrapper(paramSubMenu);
        this.mSubMenus.put(paramSubMenu, supportSubMenu);
      } 
      return (SubMenu)supportSubMenu;
    } 
    return null;
  }
  
  final void internalClear() {
    if (this.mMenuItems != null)
      this.mMenuItems.clear(); 
    if (this.mSubMenus != null)
      this.mSubMenus.clear(); 
  }
  
  final void internalRemoveGroup(int paramInt) {
    if (this.mMenuItems != null) {
      Iterator<MenuItem> iterator = this.mMenuItems.keySet().iterator();
      while (true) {
        if (iterator.hasNext()) {
          if (paramInt == ((MenuItem)iterator.next()).getGroupId())
            iterator.remove(); 
          continue;
        } 
        return;
      } 
    } 
  }
  
  final void internalRemoveItem(int paramInt) {
    if (this.mMenuItems != null) {
      Iterator<MenuItem> iterator = this.mMenuItems.keySet().iterator();
      while (true) {
        if (iterator.hasNext()) {
          if (paramInt == ((MenuItem)iterator.next()).getItemId()) {
            iterator.remove();
            return;
          } 
          continue;
        } 
        return;
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/view/menu/BaseMenuWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */