package android.support.v7.internal.view.menu;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v4.view.ActionProvider;
import android.support.v7.appcompat.R;
import android.support.v7.internal.view.ActionBarPolicy;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import java.util.ArrayList;

public class ActionMenuPresenter extends BaseMenuPresenter implements ActionProvider.SubUiVisibilityListener {
  private static final String TAG = "ActionMenuPresenter";
  
  private final SparseBooleanArray mActionButtonGroups = new SparseBooleanArray();
  
  private ActionButtonSubmenu mActionButtonPopup;
  
  private int mActionItemWidthLimit;
  
  private boolean mExpandedActionViewsExclusive;
  
  private int mMaxItems;
  
  private boolean mMaxItemsSet;
  
  private int mMinCellSize;
  
  int mOpenSubMenuId;
  
  private View mOverflowButton;
  
  private OverflowPopup mOverflowPopup;
  
  final PopupPresenterCallback mPopupPresenterCallback = new PopupPresenterCallback();
  
  private OpenOverflowRunnable mPostedOpenRunnable;
  
  private boolean mReserveOverflow;
  
  private boolean mReserveOverflowSet;
  
  private View mScrapActionButtonView;
  
  private boolean mStrictWidthLimit;
  
  private int mWidthLimit;
  
  private boolean mWidthLimitSet;
  
  public ActionMenuPresenter(Context paramContext) {
    super(paramContext, R.layout.abc_action_menu_layout, R.layout.abc_action_menu_item_layout);
  }
  
  private View findViewForItem(MenuItem paramMenuItem) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mMenuView : Landroid/support/v7/internal/view/menu/MenuView;
    //   4: checkcast android/view/ViewGroup
    //   7: astore_2
    //   8: aload_2
    //   9: ifnonnull -> 16
    //   12: aconst_null
    //   13: astore_3
    //   14: aload_3
    //   15: areturn
    //   16: aload_2
    //   17: invokevirtual getChildCount : ()I
    //   20: istore #4
    //   22: iconst_0
    //   23: istore #5
    //   25: iload #5
    //   27: iload #4
    //   29: if_icmpge -> 71
    //   32: aload_2
    //   33: iload #5
    //   35: invokevirtual getChildAt : (I)Landroid/view/View;
    //   38: astore #6
    //   40: aload #6
    //   42: instanceof android/support/v7/internal/view/menu/MenuView$ItemView
    //   45: ifeq -> 65
    //   48: aload #6
    //   50: astore_3
    //   51: aload #6
    //   53: checkcast android/support/v7/internal/view/menu/MenuView$ItemView
    //   56: invokeinterface getItemData : ()Landroid/support/v7/internal/view/menu/MenuItemImpl;
    //   61: aload_1
    //   62: if_acmpeq -> 14
    //   65: iinc #5, 1
    //   68: goto -> 25
    //   71: aconst_null
    //   72: astore_3
    //   73: goto -> 14
  }
  
  public void bindItemView(MenuItemImpl paramMenuItemImpl, MenuView.ItemView paramItemView) {
    paramItemView.initialize(paramMenuItemImpl, 0);
    ActionMenuView actionMenuView = (ActionMenuView)this.mMenuView;
    ((ActionMenuItemView)paramItemView).setItemInvoker(actionMenuView);
  }
  
  public boolean dismissPopupMenus() {
    return hideOverflowMenu() | hideSubMenus();
  }
  
  public boolean filterLeftoverView(ViewGroup paramViewGroup, int paramInt) {
    return (paramViewGroup.getChildAt(paramInt) == this.mOverflowButton) ? false : super.filterLeftoverView(paramViewGroup, paramInt);
  }
  
  public boolean flagActionItems() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mMenu : Landroid/support/v7/internal/view/menu/MenuBuilder;
    //   4: invokevirtual getVisibleItems : ()Ljava/util/ArrayList;
    //   7: astore_1
    //   8: aload_1
    //   9: invokevirtual size : ()I
    //   12: istore_2
    //   13: aload_0
    //   14: getfield mMaxItems : I
    //   17: istore_3
    //   18: aload_0
    //   19: getfield mActionItemWidthLimit : I
    //   22: istore #4
    //   24: iconst_0
    //   25: iconst_0
    //   26: invokestatic makeMeasureSpec : (II)I
    //   29: istore #5
    //   31: aload_0
    //   32: getfield mMenuView : Landroid/support/v7/internal/view/menu/MenuView;
    //   35: checkcast android/view/ViewGroup
    //   38: astore #6
    //   40: iconst_0
    //   41: istore #7
    //   43: iconst_0
    //   44: istore #8
    //   46: iconst_0
    //   47: istore #9
    //   49: iconst_0
    //   50: istore #10
    //   52: iconst_0
    //   53: istore #11
    //   55: iload #11
    //   57: iload_2
    //   58: if_icmpge -> 136
    //   61: aload_1
    //   62: iload #11
    //   64: invokevirtual get : (I)Ljava/lang/Object;
    //   67: checkcast android/support/v7/internal/view/menu/MenuItemImpl
    //   70: astore #12
    //   72: aload #12
    //   74: invokevirtual requiresActionButton : ()Z
    //   77: ifeq -> 116
    //   80: iinc #7, 1
    //   83: iload_3
    //   84: istore #13
    //   86: aload_0
    //   87: getfield mExpandedActionViewsExclusive : Z
    //   90: ifeq -> 107
    //   93: iload_3
    //   94: istore #13
    //   96: aload #12
    //   98: invokevirtual isActionViewExpanded : ()Z
    //   101: ifeq -> 107
    //   104: iconst_0
    //   105: istore #13
    //   107: iinc #11, 1
    //   110: iload #13
    //   112: istore_3
    //   113: goto -> 55
    //   116: aload #12
    //   118: invokevirtual requestsActionButton : ()Z
    //   121: ifeq -> 130
    //   124: iinc #8, 1
    //   127: goto -> 83
    //   130: iconst_1
    //   131: istore #10
    //   133: goto -> 83
    //   136: iload_3
    //   137: istore #11
    //   139: aload_0
    //   140: getfield mReserveOverflow : Z
    //   143: ifeq -> 168
    //   146: iload #10
    //   148: ifne -> 163
    //   151: iload_3
    //   152: istore #11
    //   154: iload #7
    //   156: iload #8
    //   158: iadd
    //   159: iload_3
    //   160: if_icmple -> 168
    //   163: iload_3
    //   164: iconst_1
    //   165: isub
    //   166: istore #11
    //   168: iload #11
    //   170: iload #7
    //   172: isub
    //   173: istore #11
    //   175: aload_0
    //   176: getfield mActionButtonGroups : Landroid/util/SparseBooleanArray;
    //   179: astore #14
    //   181: aload #14
    //   183: invokevirtual clear : ()V
    //   186: iconst_0
    //   187: istore #15
    //   189: iconst_0
    //   190: istore #7
    //   192: aload_0
    //   193: getfield mStrictWidthLimit : Z
    //   196: ifeq -> 227
    //   199: iload #4
    //   201: aload_0
    //   202: getfield mMinCellSize : I
    //   205: idiv
    //   206: istore #7
    //   208: aload_0
    //   209: getfield mMinCellSize : I
    //   212: istore_3
    //   213: aload_0
    //   214: getfield mMinCellSize : I
    //   217: iload #4
    //   219: iload_3
    //   220: irem
    //   221: iload #7
    //   223: idiv
    //   224: iadd
    //   225: istore #15
    //   227: iconst_0
    //   228: istore_3
    //   229: iload #4
    //   231: istore #8
    //   233: iload_3
    //   234: istore #4
    //   236: iload #9
    //   238: istore_3
    //   239: iload #4
    //   241: iload_2
    //   242: if_icmpge -> 796
    //   245: aload_1
    //   246: iload #4
    //   248: invokevirtual get : (I)Ljava/lang/Object;
    //   251: checkcast android/support/v7/internal/view/menu/MenuItemImpl
    //   254: astore #12
    //   256: aload #12
    //   258: invokevirtual requiresActionButton : ()Z
    //   261: ifeq -> 404
    //   264: aload_0
    //   265: aload #12
    //   267: aload_0
    //   268: getfield mScrapActionButtonView : Landroid/view/View;
    //   271: aload #6
    //   273: invokevirtual getItemView : (Landroid/support/v7/internal/view/menu/MenuItemImpl;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   276: astore #16
    //   278: aload_0
    //   279: getfield mScrapActionButtonView : Landroid/view/View;
    //   282: ifnonnull -> 291
    //   285: aload_0
    //   286: aload #16
    //   288: putfield mScrapActionButtonView : Landroid/view/View;
    //   291: aload_0
    //   292: getfield mStrictWidthLimit : Z
    //   295: ifeq -> 392
    //   298: iload #7
    //   300: aload #16
    //   302: iload #15
    //   304: iload #7
    //   306: iload #5
    //   308: iconst_0
    //   309: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   312: isub
    //   313: istore #7
    //   315: aload #16
    //   317: invokevirtual getMeasuredWidth : ()I
    //   320: istore #9
    //   322: iload #8
    //   324: iload #9
    //   326: isub
    //   327: istore #10
    //   329: iload_3
    //   330: istore #13
    //   332: iload_3
    //   333: ifne -> 340
    //   336: iload #9
    //   338: istore #13
    //   340: aload #12
    //   342: invokevirtual getGroupId : ()I
    //   345: istore_3
    //   346: iload_3
    //   347: ifeq -> 357
    //   350: aload #14
    //   352: iload_3
    //   353: iconst_1
    //   354: invokevirtual put : (IZ)V
    //   357: aload #12
    //   359: iconst_1
    //   360: invokevirtual setIsActionButton : (Z)V
    //   363: iload #11
    //   365: istore #17
    //   367: iload #7
    //   369: istore #9
    //   371: iinc #4, 1
    //   374: iload #9
    //   376: istore #7
    //   378: iload #13
    //   380: istore_3
    //   381: iload #17
    //   383: istore #11
    //   385: iload #10
    //   387: istore #8
    //   389: goto -> 239
    //   392: aload #16
    //   394: iload #5
    //   396: iload #5
    //   398: invokevirtual measure : (II)V
    //   401: goto -> 315
    //   404: iload #7
    //   406: istore #9
    //   408: iload_3
    //   409: istore #13
    //   411: iload #11
    //   413: istore #17
    //   415: iload #8
    //   417: istore #10
    //   419: aload #12
    //   421: invokevirtual requestsActionButton : ()Z
    //   424: ifeq -> 371
    //   427: aload #12
    //   429: invokevirtual getGroupId : ()I
    //   432: istore #17
    //   434: aload #14
    //   436: iload #17
    //   438: invokevirtual get : (I)Z
    //   441: istore #18
    //   443: iload #11
    //   445: ifgt -> 453
    //   448: iload #18
    //   450: ifeq -> 661
    //   453: iload #8
    //   455: ifle -> 661
    //   458: aload_0
    //   459: getfield mStrictWidthLimit : Z
    //   462: ifeq -> 470
    //   465: iload #7
    //   467: ifle -> 661
    //   470: iconst_1
    //   471: istore #19
    //   473: iload #7
    //   475: istore #9
    //   477: iload_3
    //   478: istore #13
    //   480: iload #19
    //   482: istore #20
    //   484: iload #8
    //   486: istore #10
    //   488: iload #19
    //   490: ifeq -> 613
    //   493: aload_0
    //   494: aload #12
    //   496: aload_0
    //   497: getfield mScrapActionButtonView : Landroid/view/View;
    //   500: aload #6
    //   502: invokevirtual getItemView : (Landroid/support/v7/internal/view/menu/MenuItemImpl;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   505: astore #16
    //   507: aload_0
    //   508: getfield mScrapActionButtonView : Landroid/view/View;
    //   511: ifnonnull -> 520
    //   514: aload_0
    //   515: aload #16
    //   517: putfield mScrapActionButtonView : Landroid/view/View;
    //   520: aload_0
    //   521: getfield mStrictWidthLimit : Z
    //   524: ifeq -> 667
    //   527: aload #16
    //   529: iload #15
    //   531: iload #7
    //   533: iload #5
    //   535: iconst_0
    //   536: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   539: istore #13
    //   541: iload #7
    //   543: iload #13
    //   545: isub
    //   546: istore #10
    //   548: iload #10
    //   550: istore #7
    //   552: iload #13
    //   554: ifne -> 564
    //   557: iconst_0
    //   558: istore #19
    //   560: iload #10
    //   562: istore #7
    //   564: aload #16
    //   566: invokevirtual getMeasuredWidth : ()I
    //   569: istore #9
    //   571: iload #8
    //   573: iload #9
    //   575: isub
    //   576: istore #10
    //   578: iload_3
    //   579: istore #13
    //   581: iload_3
    //   582: ifne -> 589
    //   585: iload #9
    //   587: istore #13
    //   589: aload_0
    //   590: getfield mStrictWidthLimit : Z
    //   593: ifeq -> 684
    //   596: iload #10
    //   598: iflt -> 679
    //   601: iconst_1
    //   602: istore_3
    //   603: iload #19
    //   605: iload_3
    //   606: iand
    //   607: istore #20
    //   609: iload #7
    //   611: istore #9
    //   613: iload #20
    //   615: ifeq -> 712
    //   618: iload #17
    //   620: ifeq -> 712
    //   623: aload #14
    //   625: iload #17
    //   627: iconst_1
    //   628: invokevirtual put : (IZ)V
    //   631: iload #11
    //   633: istore_3
    //   634: iload_3
    //   635: istore #7
    //   637: iload #20
    //   639: ifeq -> 647
    //   642: iload_3
    //   643: iconst_1
    //   644: isub
    //   645: istore #7
    //   647: aload #12
    //   649: iload #20
    //   651: invokevirtual setIsActionButton : (Z)V
    //   654: iload #7
    //   656: istore #17
    //   658: goto -> 371
    //   661: iconst_0
    //   662: istore #19
    //   664: goto -> 473
    //   667: aload #16
    //   669: iload #5
    //   671: iload #5
    //   673: invokevirtual measure : (II)V
    //   676: goto -> 564
    //   679: iconst_0
    //   680: istore_3
    //   681: goto -> 603
    //   684: iload #10
    //   686: iload #13
    //   688: iadd
    //   689: ifle -> 707
    //   692: iconst_1
    //   693: istore_3
    //   694: iload #19
    //   696: iload_3
    //   697: iand
    //   698: istore #20
    //   700: iload #7
    //   702: istore #9
    //   704: goto -> 613
    //   707: iconst_0
    //   708: istore_3
    //   709: goto -> 694
    //   712: iload #11
    //   714: istore_3
    //   715: iload #18
    //   717: ifeq -> 634
    //   720: aload #14
    //   722: iload #17
    //   724: iconst_0
    //   725: invokevirtual put : (IZ)V
    //   728: iconst_0
    //   729: istore #7
    //   731: iload #11
    //   733: istore_3
    //   734: iload #7
    //   736: iload #4
    //   738: if_icmpge -> 634
    //   741: aload_1
    //   742: iload #7
    //   744: invokevirtual get : (I)Ljava/lang/Object;
    //   747: checkcast android/support/v7/internal/view/menu/MenuItemImpl
    //   750: astore #16
    //   752: iload #11
    //   754: istore_3
    //   755: aload #16
    //   757: invokevirtual getGroupId : ()I
    //   760: iload #17
    //   762: if_icmpne -> 787
    //   765: iload #11
    //   767: istore_3
    //   768: aload #16
    //   770: invokevirtual isActionButton : ()Z
    //   773: ifeq -> 781
    //   776: iload #11
    //   778: iconst_1
    //   779: iadd
    //   780: istore_3
    //   781: aload #16
    //   783: iconst_0
    //   784: invokevirtual setIsActionButton : (Z)V
    //   787: iinc #7, 1
    //   790: iload_3
    //   791: istore #11
    //   793: goto -> 731
    //   796: iconst_1
    //   797: ireturn
  }
  
  public View getItemView(MenuItemImpl paramMenuItemImpl, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramMenuItemImpl.getActionView();
    if (view == null || paramMenuItemImpl.hasCollapsibleActionView()) {
      view = paramView;
      if (!(paramView instanceof ActionMenuItemView))
        view = null; 
      view = super.getItemView(paramMenuItemImpl, view, paramViewGroup);
    } 
    if (paramMenuItemImpl.isActionViewExpanded()) {
      bool = true;
    } else {
      bool = false;
    } 
    view.setVisibility(bool);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.generateLayoutParams(layoutParams)); 
    return view;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup) {
    MenuView menuView = super.getMenuView(paramViewGroup);
    ((ActionMenuView)menuView).setPresenter(this);
    return menuView;
  }
  
  public boolean hideOverflowMenu() {
    if (this.mPostedOpenRunnable != null && this.mMenuView != null) {
      ((View)this.mMenuView).removeCallbacks(this.mPostedOpenRunnable);
      this.mPostedOpenRunnable = null;
      return true;
    } 
    OverflowPopup overflowPopup = this.mOverflowPopup;
    if (overflowPopup != null) {
      overflowPopup.dismiss();
      return true;
    } 
    return false;
  }
  
  public boolean hideSubMenus() {
    if (this.mActionButtonPopup != null) {
      this.mActionButtonPopup.dismiss();
      return true;
    } 
    return false;
  }
  
  public void initForMenu(Context paramContext, MenuBuilder paramMenuBuilder) {
    super.initForMenu(paramContext, paramMenuBuilder);
    Resources resources = paramContext.getResources();
    ActionBarPolicy actionBarPolicy = ActionBarPolicy.get(paramContext);
    if (!this.mReserveOverflowSet)
      this.mReserveOverflow = actionBarPolicy.showsOverflowMenuButton(); 
    if (!this.mWidthLimitSet)
      this.mWidthLimit = actionBarPolicy.getEmbeddedMenuWidthLimit(); 
    if (!this.mMaxItemsSet)
      this.mMaxItems = actionBarPolicy.getMaxActionButtons(); 
    int i = this.mWidthLimit;
    if (this.mReserveOverflow) {
      if (this.mOverflowButton == null) {
        this.mOverflowButton = (View)new OverflowMenuButton(this.mSystemContext);
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.mOverflowButton.measure(j, j);
      } 
      i -= this.mOverflowButton.getMeasuredWidth();
    } else {
      this.mOverflowButton = null;
    } 
    this.mActionItemWidthLimit = i;
    this.mMinCellSize = (int)(56.0F * (resources.getDisplayMetrics()).density);
    this.mScrapActionButtonView = null;
  }
  
  public boolean isOverflowMenuShowing() {
    return (this.mOverflowPopup != null && this.mOverflowPopup.isShowing());
  }
  
  public boolean isOverflowReserved() {
    return this.mReserveOverflow;
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    dismissPopupMenus();
    super.onCloseMenu(paramMenuBuilder, paramBoolean);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    if (!this.mMaxItemsSet)
      this.mMaxItems = this.mContext.getResources().getInteger(R.integer.abc_max_action_buttons); 
    if (this.mMenu != null)
      this.mMenu.onItemsChanged(true); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    paramParcelable = paramParcelable;
    if (((SavedState)paramParcelable).openSubMenuId > 0) {
      MenuItem menuItem = this.mMenu.findItem(((SavedState)paramParcelable).openSubMenuId);
      if (menuItem != null)
        onSubMenuSelected((SubMenuBuilder)menuItem.getSubMenu()); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState();
    savedState.openSubMenuId = this.mOpenSubMenuId;
    return savedState;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder) {
    boolean bool = false;
    if (paramSubMenuBuilder.hasVisibleItems()) {
      SubMenuBuilder subMenuBuilder;
      for (subMenuBuilder = paramSubMenuBuilder; subMenuBuilder.getParentMenu() != this.mMenu; subMenuBuilder = (SubMenuBuilder)subMenuBuilder.getParentMenu());
      if (findViewForItem(subMenuBuilder.getItem()) == null)
        if (this.mOverflowButton != null) {
          View view = this.mOverflowButton;
        } else {
          return bool;
        }  
      this.mOpenSubMenuId = paramSubMenuBuilder.getItem().getItemId();
      this.mActionButtonPopup = new ActionButtonSubmenu(paramSubMenuBuilder);
      this.mActionButtonPopup.show(null);
      super.onSubMenuSelected(paramSubMenuBuilder);
      bool = true;
    } 
    return bool;
  }
  
  public void onSubUiVisibilityChanged(boolean paramBoolean) {
    if (paramBoolean) {
      super.onSubMenuSelected(null);
      return;
    } 
    this.mMenu.close(false);
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.mExpandedActionViewsExclusive = paramBoolean;
  }
  
  public void setItemLimit(int paramInt) {
    this.mMaxItems = paramInt;
    this.mMaxItemsSet = true;
  }
  
  public void setReserveOverflow(boolean paramBoolean) {
    this.mReserveOverflow = paramBoolean;
    this.mReserveOverflowSet = true;
  }
  
  public void setWidthLimit(int paramInt, boolean paramBoolean) {
    this.mWidthLimit = paramInt;
    this.mStrictWidthLimit = paramBoolean;
    this.mWidthLimitSet = true;
  }
  
  public boolean shouldIncludeItem(int paramInt, MenuItemImpl paramMenuItemImpl) {
    return paramMenuItemImpl.isActionButton();
  }
  
  public boolean showOverflowMenu() {
    null = true;
    if (this.mReserveOverflow && !isOverflowMenuShowing() && this.mMenu != null && this.mMenuView != null && this.mPostedOpenRunnable == null) {
      this.mPostedOpenRunnable = new OpenOverflowRunnable(new OverflowPopup(this.mContext, this.mMenu, this.mOverflowButton, true));
      ((View)this.mMenuView).post(this.mPostedOpenRunnable);
      super.onSubMenuSelected(null);
      return null;
    } 
    return false;
  }
  
  public void updateMenuView(boolean paramBoolean) {
    super.updateMenuView(paramBoolean);
    if (this.mMenuView != null) {
      ArrayList<MenuItemImpl> arrayList;
      if (this.mMenu != null) {
        ArrayList<MenuItemImpl> arrayList1 = this.mMenu.getActionItems();
        int j = arrayList1.size();
        for (byte b1 = 0; b1 < j; b1++) {
          arrayList = (ArrayList<MenuItemImpl>)((MenuItemImpl)arrayList1.get(b1)).getSupportActionProvider();
          if (arrayList != null)
            arrayList.setSubUiVisibilityListener(this); 
        } 
      } 
      if (this.mMenu != null) {
        arrayList = this.mMenu.getNonActionItems();
      } else {
        arrayList = null;
      } 
      byte b = 0;
      int i = b;
      if (this.mReserveOverflow) {
        i = b;
        if (arrayList != null) {
          i = arrayList.size();
          if (i == 1) {
            if (!((MenuItemImpl)arrayList.get(0)).isActionViewExpanded()) {
              i = 1;
            } else {
              i = 0;
            } 
          } else if (i > 0) {
            i = 1;
          } else {
            i = 0;
          } 
        } 
      } 
      if (i != 0) {
        if (this.mOverflowButton == null)
          this.mOverflowButton = (View)new OverflowMenuButton(this.mSystemContext); 
        ViewGroup viewGroup = (ViewGroup)this.mOverflowButton.getParent();
        if (viewGroup != this.mMenuView) {
          if (viewGroup != null)
            viewGroup.removeView(this.mOverflowButton); 
          ActionMenuView actionMenuView = (ActionMenuView)this.mMenuView;
          actionMenuView.addView(this.mOverflowButton, (ViewGroup.LayoutParams)actionMenuView.generateOverflowButtonLayoutParams());
        } 
      } else if (this.mOverflowButton != null && this.mOverflowButton.getParent() == this.mMenuView) {
        ((ViewGroup)this.mMenuView).removeView(this.mOverflowButton);
      } 
      ((ActionMenuView)this.mMenuView).setOverflowReserved(this.mReserveOverflow);
    } 
  }
  
  private class ActionButtonSubmenu extends MenuDialogHelper {
    public ActionButtonSubmenu(SubMenuBuilder param1SubMenuBuilder) {
      super(param1SubMenuBuilder);
      ActionMenuPresenter.this.setCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
    }
    
    public void onDismiss(DialogInterface param1DialogInterface) {
      super.onDismiss(param1DialogInterface);
      ActionMenuPresenter.access$202(ActionMenuPresenter.this, (ActionButtonSubmenu)null);
      ActionMenuPresenter.this.mOpenSubMenuId = 0;
    }
  }
  
  private class OpenOverflowRunnable implements Runnable {
    private ActionMenuPresenter.OverflowPopup mPopup;
    
    public OpenOverflowRunnable(ActionMenuPresenter.OverflowPopup param1OverflowPopup) {
      this.mPopup = param1OverflowPopup;
    }
    
    public void run() {
      ActionMenuPresenter.this.mMenu.changeMenuMode();
      View view = (View)ActionMenuPresenter.this.mMenuView;
      if (view != null && view.getWindowToken() != null && this.mPopup.tryShow())
        ActionMenuPresenter.access$102(ActionMenuPresenter.this, this.mPopup); 
      ActionMenuPresenter.access$302(ActionMenuPresenter.this, (OpenOverflowRunnable)null);
    }
  }
  
  private class OverflowMenuButton extends ImageButton implements ActionMenuView.ActionMenuChildView {
    public OverflowMenuButton(Context param1Context) {
      super(param1Context, null, R.attr.actionOverflowButtonStyle);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
    }
    
    public boolean needsDividerAfter() {
      return false;
    }
    
    public boolean needsDividerBefore() {
      return false;
    }
    
    public boolean performClick() {
      if (!super.performClick()) {
        playSoundEffect(0);
        ActionMenuPresenter.this.showOverflowMenu();
      } 
      return true;
    }
  }
  
  private class OverflowPopup extends MenuPopupHelper {
    public OverflowPopup(Context param1Context, MenuBuilder param1MenuBuilder, View param1View, boolean param1Boolean) {
      super(param1Context, param1MenuBuilder, param1View, param1Boolean);
      setCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
    }
    
    public void onDismiss() {
      super.onDismiss();
      ActionMenuPresenter.this.mMenu.close();
      ActionMenuPresenter.access$102(ActionMenuPresenter.this, (OverflowPopup)null);
    }
  }
  
  private class PopupPresenterCallback implements MenuPresenter.Callback {
    private PopupPresenterCallback() {}
    
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {
      if (param1MenuBuilder instanceof SubMenuBuilder)
        ((SubMenuBuilder)param1MenuBuilder).getRootMenu().close(false); 
    }
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      if (param1MenuBuilder != null)
        ActionMenuPresenter.this.mOpenSubMenuId = ((SubMenuBuilder)param1MenuBuilder).getItem().getItemId(); 
      return false;
    }
  }
  
  private static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public ActionMenuPresenter.SavedState createFromParcel(Parcel param2Parcel) {
          return new ActionMenuPresenter.SavedState(param2Parcel);
        }
        
        public ActionMenuPresenter.SavedState[] newArray(int param2Int) {
          return new ActionMenuPresenter.SavedState[param2Int];
        }
      };
    
    public int openSubMenuId;
    
    SavedState() {}
    
    SavedState(Parcel param1Parcel) {
      this.openSubMenuId = param1Parcel.readInt();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.openSubMenuId);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public ActionMenuPresenter.SavedState createFromParcel(Parcel param1Parcel) {
      return new ActionMenuPresenter.SavedState(param1Parcel);
    }
    
    public ActionMenuPresenter.SavedState[] newArray(int param1Int) {
      return new ActionMenuPresenter.SavedState[param1Int];
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/view/menu/ActionMenuPresenter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */