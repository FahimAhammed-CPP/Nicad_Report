package android.support.v7.internal.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Build;
import android.support.v7.appcompat.R;
import android.support.v7.internal.widget.LinearLayoutICS;
import android.util.AttributeSet;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;

public class ActionMenuView extends LinearLayoutICS implements MenuBuilder.ItemInvoker, MenuView {
  static final int GENERATED_ITEM_PADDING = 4;
  
  static final int MIN_CELL_SIZE = 56;
  
  private static final String TAG = "ActionMenuView";
  
  private boolean mFormatItems;
  
  private int mFormatItemsWidth;
  
  private int mGeneratedItemPadding;
  
  private int mMaxItemHeight;
  
  private int mMeasuredExtraWidth;
  
  private MenuBuilder mMenu;
  
  private int mMinCellSize;
  
  private ActionMenuPresenter mPresenter;
  
  private boolean mReserveOverflow;
  
  public ActionMenuView(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public ActionMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setBaselineAligned(false);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.mMinCellSize = (int)(56.0F * f);
    this.mGeneratedItemPadding = (int)(4.0F * f);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.ActionBar, R.attr.actionBarStyle, 0);
    this.mMaxItemHeight = typedArray.getDimensionPixelSize(0, 0);
    typedArray.recycle();
  }
  
  static int measureChildForCells(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast android/support/v7/internal/view/menu/ActionMenuView$LayoutParams
    //   7: astore #5
    //   9: iload_3
    //   10: invokestatic getSize : (I)I
    //   13: iload #4
    //   15: isub
    //   16: iload_3
    //   17: invokestatic getMode : (I)I
    //   20: invokestatic makeMeasureSpec : (II)I
    //   23: istore #6
    //   25: aload_0
    //   26: instanceof android/support/v7/internal/view/menu/ActionMenuItemView
    //   29: ifeq -> 176
    //   32: aload_0
    //   33: checkcast android/support/v7/internal/view/menu/ActionMenuItemView
    //   36: astore #7
    //   38: aload #7
    //   40: ifnull -> 182
    //   43: aload #7
    //   45: invokevirtual hasText : ()Z
    //   48: ifeq -> 182
    //   51: iconst_1
    //   52: istore #4
    //   54: iconst_0
    //   55: istore #8
    //   57: iload #8
    //   59: istore_3
    //   60: iload_2
    //   61: ifle -> 131
    //   64: iload #4
    //   66: ifeq -> 77
    //   69: iload #8
    //   71: istore_3
    //   72: iload_2
    //   73: iconst_2
    //   74: if_icmplt -> 131
    //   77: aload_0
    //   78: iload_1
    //   79: iload_2
    //   80: imul
    //   81: ldc -2147483648
    //   83: invokestatic makeMeasureSpec : (II)I
    //   86: iload #6
    //   88: invokevirtual measure : (II)V
    //   91: aload_0
    //   92: invokevirtual getMeasuredWidth : ()I
    //   95: istore #8
    //   97: iload #8
    //   99: iload_1
    //   100: idiv
    //   101: istore_3
    //   102: iload_3
    //   103: istore_2
    //   104: iload #8
    //   106: iload_1
    //   107: irem
    //   108: ifeq -> 115
    //   111: iload_3
    //   112: iconst_1
    //   113: iadd
    //   114: istore_2
    //   115: iload_2
    //   116: istore_3
    //   117: iload #4
    //   119: ifeq -> 131
    //   122: iload_2
    //   123: istore_3
    //   124: iload_2
    //   125: iconst_2
    //   126: if_icmpge -> 131
    //   129: iconst_2
    //   130: istore_3
    //   131: aload #5
    //   133: getfield isOverflowButton : Z
    //   136: ifne -> 188
    //   139: iload #4
    //   141: ifeq -> 188
    //   144: iconst_1
    //   145: istore #9
    //   147: aload #5
    //   149: iload #9
    //   151: putfield expandable : Z
    //   154: aload #5
    //   156: iload_3
    //   157: putfield cellsUsed : I
    //   160: aload_0
    //   161: iload_3
    //   162: iload_1
    //   163: imul
    //   164: ldc 1073741824
    //   166: invokestatic makeMeasureSpec : (II)I
    //   169: iload #6
    //   171: invokevirtual measure : (II)V
    //   174: iload_3
    //   175: ireturn
    //   176: aconst_null
    //   177: astore #7
    //   179: goto -> 38
    //   182: iconst_0
    //   183: istore #4
    //   185: goto -> 54
    //   188: iconst_0
    //   189: istore #9
    //   191: goto -> 147
  }
  
  private void onMeasureExactFormat(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_2
    //   1: invokestatic getMode : (I)I
    //   4: istore_3
    //   5: iload_1
    //   6: invokestatic getSize : (I)I
    //   9: istore_1
    //   10: iload_2
    //   11: invokestatic getSize : (I)I
    //   14: istore #4
    //   16: aload_0
    //   17: invokevirtual getPaddingLeft : ()I
    //   20: istore #5
    //   22: aload_0
    //   23: invokevirtual getPaddingRight : ()I
    //   26: istore_2
    //   27: aload_0
    //   28: invokevirtual getPaddingTop : ()I
    //   31: aload_0
    //   32: invokevirtual getPaddingBottom : ()I
    //   35: iadd
    //   36: istore #6
    //   38: iload_3
    //   39: ldc 1073741824
    //   41: if_icmpne -> 89
    //   44: iload #4
    //   46: iload #6
    //   48: isub
    //   49: ldc 1073741824
    //   51: invokestatic makeMeasureSpec : (II)I
    //   54: istore #7
    //   56: iload_1
    //   57: iload #5
    //   59: iload_2
    //   60: iadd
    //   61: isub
    //   62: istore #8
    //   64: iload #8
    //   66: aload_0
    //   67: getfield mMinCellSize : I
    //   70: idiv
    //   71: istore_2
    //   72: aload_0
    //   73: getfield mMinCellSize : I
    //   76: istore_1
    //   77: iload_2
    //   78: ifne -> 111
    //   81: aload_0
    //   82: iload #8
    //   84: iconst_0
    //   85: invokevirtual setMeasuredDimension : (II)V
    //   88: return
    //   89: aload_0
    //   90: getfield mMaxItemHeight : I
    //   93: iload #4
    //   95: iload #6
    //   97: isub
    //   98: invokestatic min : (II)I
    //   101: ldc -2147483648
    //   103: invokestatic makeMeasureSpec : (II)I
    //   106: istore #7
    //   108: goto -> 56
    //   111: aload_0
    //   112: getfield mMinCellSize : I
    //   115: iload #8
    //   117: iload_1
    //   118: irem
    //   119: iload_2
    //   120: idiv
    //   121: iadd
    //   122: istore #9
    //   124: iconst_0
    //   125: istore #5
    //   127: iconst_0
    //   128: istore #10
    //   130: iconst_0
    //   131: istore #11
    //   133: iconst_0
    //   134: istore #12
    //   136: iconst_0
    //   137: istore #13
    //   139: lconst_0
    //   140: lstore #14
    //   142: aload_0
    //   143: invokevirtual getChildCount : ()I
    //   146: istore #16
    //   148: iconst_0
    //   149: istore #17
    //   151: iload #17
    //   153: iload #16
    //   155: if_icmpge -> 459
    //   158: aload_0
    //   159: iload #17
    //   161: invokevirtual getChildAt : (I)Landroid/view/View;
    //   164: astore #18
    //   166: aload #18
    //   168: invokevirtual getVisibility : ()I
    //   171: bipush #8
    //   173: if_icmpne -> 198
    //   176: lload #14
    //   178: lstore #19
    //   180: iload #13
    //   182: istore #21
    //   184: iinc #17, 1
    //   187: iload #21
    //   189: istore #13
    //   191: lload #19
    //   193: lstore #14
    //   195: goto -> 151
    //   198: aload #18
    //   200: instanceof android/support/v7/internal/view/menu/ActionMenuItemView
    //   203: istore #22
    //   205: iload #12
    //   207: iconst_1
    //   208: iadd
    //   209: istore #23
    //   211: iload #22
    //   213: ifeq -> 231
    //   216: aload #18
    //   218: aload_0
    //   219: getfield mGeneratedItemPadding : I
    //   222: iconst_0
    //   223: aload_0
    //   224: getfield mGeneratedItemPadding : I
    //   227: iconst_0
    //   228: invokevirtual setPadding : (IIII)V
    //   231: aload #18
    //   233: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   236: checkcast android/support/v7/internal/view/menu/ActionMenuView$LayoutParams
    //   239: astore #24
    //   241: aload #24
    //   243: iconst_0
    //   244: putfield expanded : Z
    //   247: aload #24
    //   249: iconst_0
    //   250: putfield extraPixels : I
    //   253: aload #24
    //   255: iconst_0
    //   256: putfield cellsUsed : I
    //   259: aload #24
    //   261: iconst_0
    //   262: putfield expandable : Z
    //   265: aload #24
    //   267: iconst_0
    //   268: putfield leftMargin : I
    //   271: aload #24
    //   273: iconst_0
    //   274: putfield rightMargin : I
    //   277: iload #22
    //   279: ifeq -> 448
    //   282: aload #18
    //   284: checkcast android/support/v7/internal/view/menu/ActionMenuItemView
    //   287: invokevirtual hasText : ()Z
    //   290: ifeq -> 448
    //   293: iconst_1
    //   294: istore #22
    //   296: aload #24
    //   298: iload #22
    //   300: putfield preventEdgeOffset : Z
    //   303: aload #24
    //   305: getfield isOverflowButton : Z
    //   308: ifeq -> 454
    //   311: iconst_1
    //   312: istore_1
    //   313: aload #18
    //   315: iload #9
    //   317: iload_1
    //   318: iload #7
    //   320: iload #6
    //   322: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   325: istore #25
    //   327: iload #10
    //   329: iload #25
    //   331: invokestatic max : (II)I
    //   334: istore #26
    //   336: iload #11
    //   338: istore_1
    //   339: aload #24
    //   341: getfield expandable : Z
    //   344: ifeq -> 352
    //   347: iload #11
    //   349: iconst_1
    //   350: iadd
    //   351: istore_1
    //   352: aload #24
    //   354: getfield isOverflowButton : Z
    //   357: ifeq -> 363
    //   360: iconst_1
    //   361: istore #13
    //   363: iload_2
    //   364: iload #25
    //   366: isub
    //   367: istore #27
    //   369: iload #5
    //   371: aload #18
    //   373: invokevirtual getMeasuredHeight : ()I
    //   376: invokestatic max : (II)I
    //   379: istore #28
    //   381: iload #27
    //   383: istore_2
    //   384: iload_1
    //   385: istore #11
    //   387: iload #13
    //   389: istore #21
    //   391: iload #26
    //   393: istore #10
    //   395: iload #28
    //   397: istore #5
    //   399: lload #14
    //   401: lstore #19
    //   403: iload #23
    //   405: istore #12
    //   407: iload #25
    //   409: iconst_1
    //   410: if_icmpne -> 184
    //   413: lload #14
    //   415: iconst_1
    //   416: iload #17
    //   418: ishl
    //   419: i2l
    //   420: lor
    //   421: lstore #19
    //   423: iload #27
    //   425: istore_2
    //   426: iload_1
    //   427: istore #11
    //   429: iload #13
    //   431: istore #21
    //   433: iload #26
    //   435: istore #10
    //   437: iload #28
    //   439: istore #5
    //   441: iload #23
    //   443: istore #12
    //   445: goto -> 184
    //   448: iconst_0
    //   449: istore #22
    //   451: goto -> 296
    //   454: iload_2
    //   455: istore_1
    //   456: goto -> 313
    //   459: iload #13
    //   461: ifeq -> 564
    //   464: iload #12
    //   466: iconst_2
    //   467: if_icmpne -> 564
    //   470: iconst_1
    //   471: istore #21
    //   473: iconst_0
    //   474: istore_1
    //   475: lload #14
    //   477: lstore #19
    //   479: iload #11
    //   481: ifle -> 662
    //   484: lload #14
    //   486: lstore #19
    //   488: iload_2
    //   489: ifle -> 662
    //   492: ldc 2147483647
    //   494: istore #23
    //   496: lconst_0
    //   497: lstore #29
    //   499: iconst_0
    //   500: istore #28
    //   502: iconst_0
    //   503: istore #27
    //   505: iload #27
    //   507: iload #16
    //   509: if_icmpge -> 645
    //   512: aload_0
    //   513: iload #27
    //   515: invokevirtual getChildAt : (I)Landroid/view/View;
    //   518: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   521: checkcast android/support/v7/internal/view/menu/ActionMenuView$LayoutParams
    //   524: astore #18
    //   526: aload #18
    //   528: getfield expandable : Z
    //   531: ifne -> 570
    //   534: iload #28
    //   536: istore #17
    //   538: lload #29
    //   540: lstore #19
    //   542: iload #23
    //   544: istore #26
    //   546: iinc #27, 1
    //   549: iload #26
    //   551: istore #23
    //   553: lload #19
    //   555: lstore #29
    //   557: iload #17
    //   559: istore #28
    //   561: goto -> 505
    //   564: iconst_0
    //   565: istore #21
    //   567: goto -> 473
    //   570: aload #18
    //   572: getfield cellsUsed : I
    //   575: iload #23
    //   577: if_icmpge -> 600
    //   580: aload #18
    //   582: getfield cellsUsed : I
    //   585: istore #26
    //   587: iconst_1
    //   588: iload #27
    //   590: ishl
    //   591: i2l
    //   592: lstore #19
    //   594: iconst_1
    //   595: istore #17
    //   597: goto -> 546
    //   600: iload #23
    //   602: istore #26
    //   604: lload #29
    //   606: lstore #19
    //   608: iload #28
    //   610: istore #17
    //   612: aload #18
    //   614: getfield cellsUsed : I
    //   617: iload #23
    //   619: if_icmpne -> 546
    //   622: lload #29
    //   624: iconst_1
    //   625: iload #27
    //   627: ishl
    //   628: i2l
    //   629: lor
    //   630: lstore #19
    //   632: iload #28
    //   634: iconst_1
    //   635: iadd
    //   636: istore #17
    //   638: iload #23
    //   640: istore #26
    //   642: goto -> 546
    //   645: lload #14
    //   647: lload #29
    //   649: lor
    //   650: lstore #14
    //   652: iload #28
    //   654: iload_2
    //   655: if_icmple -> 883
    //   658: lload #14
    //   660: lstore #19
    //   662: iload #13
    //   664: ifne -> 1035
    //   667: iload #12
    //   669: iconst_1
    //   670: if_icmpne -> 1035
    //   673: iconst_1
    //   674: istore #17
    //   676: iload_2
    //   677: istore #13
    //   679: iload_1
    //   680: istore #11
    //   682: iload_2
    //   683: ifle -> 1195
    //   686: iload_2
    //   687: istore #13
    //   689: iload_1
    //   690: istore #11
    //   692: lload #19
    //   694: lconst_0
    //   695: lcmp
    //   696: ifeq -> 1195
    //   699: iload_2
    //   700: iload #12
    //   702: iconst_1
    //   703: isub
    //   704: if_icmplt -> 724
    //   707: iload #17
    //   709: ifne -> 724
    //   712: iload_2
    //   713: istore #13
    //   715: iload_1
    //   716: istore #11
    //   718: iload #10
    //   720: iconst_1
    //   721: if_icmple -> 1195
    //   724: lload #19
    //   726: invokestatic bitCount : (J)I
    //   729: i2f
    //   730: fstore #31
    //   732: fload #31
    //   734: fstore #32
    //   736: iload #17
    //   738: ifne -> 832
    //   741: fload #31
    //   743: fstore #33
    //   745: lconst_1
    //   746: lload #19
    //   748: land
    //   749: lconst_0
    //   750: lcmp
    //   751: ifeq -> 782
    //   754: fload #31
    //   756: fstore #33
    //   758: aload_0
    //   759: iconst_0
    //   760: invokevirtual getChildAt : (I)Landroid/view/View;
    //   763: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   766: checkcast android/support/v7/internal/view/menu/ActionMenuView$LayoutParams
    //   769: getfield preventEdgeOffset : Z
    //   772: ifne -> 782
    //   775: fload #31
    //   777: ldc 0.5
    //   779: fsub
    //   780: fstore #33
    //   782: fload #33
    //   784: fstore #32
    //   786: iconst_1
    //   787: iload #16
    //   789: iconst_1
    //   790: isub
    //   791: ishl
    //   792: i2l
    //   793: lload #19
    //   795: land
    //   796: lconst_0
    //   797: lcmp
    //   798: ifeq -> 832
    //   801: fload #33
    //   803: fstore #32
    //   805: aload_0
    //   806: iload #16
    //   808: iconst_1
    //   809: isub
    //   810: invokevirtual getChildAt : (I)Landroid/view/View;
    //   813: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   816: checkcast android/support/v7/internal/view/menu/ActionMenuView$LayoutParams
    //   819: getfield preventEdgeOffset : Z
    //   822: ifne -> 832
    //   825: fload #33
    //   827: ldc 0.5
    //   829: fsub
    //   830: fstore #32
    //   832: fload #32
    //   834: fconst_0
    //   835: fcmpl
    //   836: ifle -> 1041
    //   839: iload_2
    //   840: iload #9
    //   842: imul
    //   843: i2f
    //   844: fload #32
    //   846: fdiv
    //   847: f2i
    //   848: istore #13
    //   850: iconst_0
    //   851: istore #11
    //   853: iload #11
    //   855: iload #16
    //   857: if_icmpge -> 1189
    //   860: iconst_1
    //   861: iload #11
    //   863: ishl
    //   864: i2l
    //   865: lload #19
    //   867: land
    //   868: lconst_0
    //   869: lcmp
    //   870: ifne -> 1047
    //   873: iload_1
    //   874: istore_2
    //   875: iinc #11, 1
    //   878: iload_2
    //   879: istore_1
    //   880: goto -> 853
    //   883: iconst_0
    //   884: istore_1
    //   885: iload_1
    //   886: iload #16
    //   888: if_icmpge -> 1030
    //   891: aload_0
    //   892: iload_1
    //   893: invokevirtual getChildAt : (I)Landroid/view/View;
    //   896: astore #18
    //   898: aload #18
    //   900: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   903: checkcast android/support/v7/internal/view/menu/ActionMenuView$LayoutParams
    //   906: astore #24
    //   908: iconst_1
    //   909: iload_1
    //   910: ishl
    //   911: i2l
    //   912: lload #29
    //   914: land
    //   915: lconst_0
    //   916: lcmp
    //   917: ifne -> 964
    //   920: iload_2
    //   921: istore #17
    //   923: lload #14
    //   925: lstore #19
    //   927: aload #24
    //   929: getfield cellsUsed : I
    //   932: iload #23
    //   934: iconst_1
    //   935: iadd
    //   936: if_icmpne -> 951
    //   939: lload #14
    //   941: iconst_1
    //   942: iload_1
    //   943: ishl
    //   944: i2l
    //   945: lor
    //   946: lstore #19
    //   948: iload_2
    //   949: istore #17
    //   951: iinc #1, 1
    //   954: iload #17
    //   956: istore_2
    //   957: lload #19
    //   959: lstore #14
    //   961: goto -> 885
    //   964: iload #21
    //   966: ifeq -> 1000
    //   969: aload #24
    //   971: getfield preventEdgeOffset : Z
    //   974: ifeq -> 1000
    //   977: iload_2
    //   978: iconst_1
    //   979: if_icmpne -> 1000
    //   982: aload #18
    //   984: aload_0
    //   985: getfield mGeneratedItemPadding : I
    //   988: iload #9
    //   990: iadd
    //   991: iconst_0
    //   992: aload_0
    //   993: getfield mGeneratedItemPadding : I
    //   996: iconst_0
    //   997: invokevirtual setPadding : (IIII)V
    //   1000: aload #24
    //   1002: aload #24
    //   1004: getfield cellsUsed : I
    //   1007: iconst_1
    //   1008: iadd
    //   1009: putfield cellsUsed : I
    //   1012: aload #24
    //   1014: iconst_1
    //   1015: putfield expanded : Z
    //   1018: iload_2
    //   1019: iconst_1
    //   1020: isub
    //   1021: istore #17
    //   1023: lload #14
    //   1025: lstore #19
    //   1027: goto -> 951
    //   1030: iconst_1
    //   1031: istore_1
    //   1032: goto -> 475
    //   1035: iconst_0
    //   1036: istore #17
    //   1038: goto -> 676
    //   1041: iconst_0
    //   1042: istore #13
    //   1044: goto -> 850
    //   1047: aload_0
    //   1048: iload #11
    //   1050: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1053: astore #18
    //   1055: aload #18
    //   1057: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1060: checkcast android/support/v7/internal/view/menu/ActionMenuView$LayoutParams
    //   1063: astore #24
    //   1065: aload #18
    //   1067: instanceof android/support/v7/internal/view/menu/ActionMenuItemView
    //   1070: ifeq -> 1114
    //   1073: aload #24
    //   1075: iload #13
    //   1077: putfield extraPixels : I
    //   1080: aload #24
    //   1082: iconst_1
    //   1083: putfield expanded : Z
    //   1086: iload #11
    //   1088: ifne -> 1109
    //   1091: aload #24
    //   1093: getfield preventEdgeOffset : Z
    //   1096: ifne -> 1109
    //   1099: aload #24
    //   1101: iload #13
    //   1103: ineg
    //   1104: iconst_2
    //   1105: idiv
    //   1106: putfield leftMargin : I
    //   1109: iconst_1
    //   1110: istore_2
    //   1111: goto -> 875
    //   1114: aload #24
    //   1116: getfield isOverflowButton : Z
    //   1119: ifeq -> 1150
    //   1122: aload #24
    //   1124: iload #13
    //   1126: putfield extraPixels : I
    //   1129: aload #24
    //   1131: iconst_1
    //   1132: putfield expanded : Z
    //   1135: aload #24
    //   1137: iload #13
    //   1139: ineg
    //   1140: iconst_2
    //   1141: idiv
    //   1142: putfield rightMargin : I
    //   1145: iconst_1
    //   1146: istore_2
    //   1147: goto -> 875
    //   1150: iload #11
    //   1152: ifeq -> 1164
    //   1155: aload #24
    //   1157: iload #13
    //   1159: iconst_2
    //   1160: idiv
    //   1161: putfield leftMargin : I
    //   1164: iload_1
    //   1165: istore_2
    //   1166: iload #11
    //   1168: iload #16
    //   1170: iconst_1
    //   1171: isub
    //   1172: if_icmpeq -> 875
    //   1175: aload #24
    //   1177: iload #13
    //   1179: iconst_2
    //   1180: idiv
    //   1181: putfield rightMargin : I
    //   1184: iload_1
    //   1185: istore_2
    //   1186: goto -> 875
    //   1189: iconst_0
    //   1190: istore #13
    //   1192: iload_1
    //   1193: istore #11
    //   1195: iload #11
    //   1197: ifeq -> 1268
    //   1200: iconst_0
    //   1201: istore_1
    //   1202: iload_1
    //   1203: iload #16
    //   1205: if_icmpge -> 1268
    //   1208: aload_0
    //   1209: iload_1
    //   1210: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1213: astore #24
    //   1215: aload #24
    //   1217: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1220: checkcast android/support/v7/internal/view/menu/ActionMenuView$LayoutParams
    //   1223: astore #18
    //   1225: aload #18
    //   1227: getfield expanded : Z
    //   1230: ifne -> 1239
    //   1233: iinc #1, 1
    //   1236: goto -> 1202
    //   1239: aload #24
    //   1241: aload #18
    //   1243: getfield cellsUsed : I
    //   1246: iload #9
    //   1248: imul
    //   1249: aload #18
    //   1251: getfield extraPixels : I
    //   1254: iadd
    //   1255: ldc 1073741824
    //   1257: invokestatic makeMeasureSpec : (II)I
    //   1260: iload #7
    //   1262: invokevirtual measure : (II)V
    //   1265: goto -> 1233
    //   1268: iload #4
    //   1270: istore_1
    //   1271: iload_3
    //   1272: ldc 1073741824
    //   1274: if_icmpeq -> 1280
    //   1277: iload #5
    //   1279: istore_1
    //   1280: aload_0
    //   1281: iload #8
    //   1283: iload_1
    //   1284: invokevirtual setMeasuredDimension : (II)V
    //   1287: aload_0
    //   1288: iload #13
    //   1290: iload #9
    //   1292: imul
    //   1293: putfield mMeasuredExtraWidth : I
    //   1296: goto -> 88
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams != null && paramLayoutParams instanceof LayoutParams);
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return false;
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    LayoutParams layoutParams = new LayoutParams(-2, -2);
    layoutParams.gravity = 16;
    return layoutParams;
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    if (paramLayoutParams instanceof LayoutParams) {
      LayoutParams layoutParams2 = new LayoutParams((LayoutParams)paramLayoutParams);
      LayoutParams layoutParams1 = layoutParams2;
      if (layoutParams2.gravity <= 0) {
        layoutParams2.gravity = 16;
        layoutParams1 = layoutParams2;
      } 
      return layoutParams1;
    } 
    return generateDefaultLayoutParams();
  }
  
  public LayoutParams generateOverflowButtonLayoutParams() {
    LayoutParams layoutParams = generateDefaultLayoutParams();
    layoutParams.isOverflowButton = true;
    return layoutParams;
  }
  
  public int getWindowAnimations() {
    return 0;
  }
  
  protected boolean hasSupportDividerBeforeChildAt(int paramInt) {
    boolean bool;
    View view1 = getChildAt(paramInt - 1);
    View view2 = getChildAt(paramInt);
    int i = 0;
    int j = i;
    if (paramInt < getChildCount()) {
      j = i;
      if (view1 instanceof ActionMenuChildView)
        j = false | ((ActionMenuChildView)view1).needsDividerAfter(); 
    } 
    i = j;
    if (paramInt > 0) {
      i = j;
      if (view2 instanceof ActionMenuChildView)
        bool = j | ((ActionMenuChildView)view2).needsDividerBefore(); 
    } 
    return bool;
  }
  
  public void initialize(MenuBuilder paramMenuBuilder) {
    this.mMenu = paramMenuBuilder;
  }
  
  public boolean invokeItem(MenuItemImpl paramMenuItemImpl) {
    return this.mMenu.performItemAction((MenuItem)paramMenuItemImpl, 0);
  }
  
  public boolean isExpandedFormat() {
    return this.mFormatItems;
  }
  
  public boolean isOverflowReserved() {
    return this.mReserveOverflow;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    if (Build.VERSION.SDK_INT >= 8)
      super.onConfigurationChanged(paramConfiguration); 
    this.mPresenter.updateMenuView(false);
    if (this.mPresenter != null && this.mPresenter.isOverflowMenuShowing()) {
      this.mPresenter.hideOverflowMenu();
      this.mPresenter.showOverflowMenu();
    } 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.mPresenter.dismissPopupMenus();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!this.mFormatItems) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    int i = getChildCount();
    int j = (paramInt2 + paramInt4) / 2;
    int k = getSupportDividerWidth();
    int m = 0;
    paramInt4 = 0;
    paramInt2 = paramInt3 - paramInt1 - getPaddingRight() - getPaddingLeft();
    int n = 0;
    int i1;
    for (i1 = 0; i1 < i; i1++) {
      View view = getChildAt(i1);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.isOverflowButton) {
          int i2 = view.getMeasuredWidth();
          n = i2;
          if (hasSupportDividerBeforeChildAt(i1))
            n = i2 + k; 
          int i3 = view.getMeasuredHeight();
          i2 = getWidth() - getPaddingRight() - layoutParams.rightMargin;
          int i4 = j - i3 / 2;
          view.layout(i2 - n, i4, i2, i4 + i3);
          paramInt2 -= n;
          n = 1;
        } else {
          int i2 = view.getMeasuredWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
          m += i2;
          i2 = paramInt2 - i2;
          paramInt2 = m;
          if (hasSupportDividerBeforeChildAt(i1))
            paramInt2 = m + k; 
          paramInt4++;
          m = paramInt2;
          paramInt2 = i2;
        } 
      } 
    } 
    if (i == 1 && n == 0) {
      View view = getChildAt(0);
      paramInt2 = view.getMeasuredWidth();
      paramInt4 = view.getMeasuredHeight();
      paramInt1 = (paramInt3 - paramInt1) / 2 - paramInt2 / 2;
      paramInt3 = j - paramInt4 / 2;
      view.layout(paramInt1, paramInt3, paramInt1 + paramInt2, paramInt3 + paramInt4);
      return;
    } 
    if (n != 0) {
      paramInt1 = 0;
    } else {
      paramInt1 = 1;
    } 
    paramInt1 = paramInt4 - paramInt1;
    if (paramInt1 > 0) {
      paramInt1 = paramInt2 / paramInt1;
    } else {
      paramInt1 = 0;
    } 
    paramInt4 = Math.max(0, paramInt1);
    paramInt2 = getPaddingLeft();
    paramInt1 = 0;
    while (true) {
      if (paramInt1 < i) {
        View view = getChildAt(paramInt1);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        paramInt3 = paramInt2;
        if (view.getVisibility() != 8)
          if (layoutParams.isOverflowButton) {
            paramInt3 = paramInt2;
          } else {
            paramInt2 += layoutParams.leftMargin;
            paramInt3 = view.getMeasuredWidth();
            i1 = view.getMeasuredHeight();
            m = j - i1 / 2;
            view.layout(paramInt2, m, paramInt2 + paramInt3, m + i1);
            paramInt3 = paramInt2 + layoutParams.rightMargin + paramInt3 + paramInt4;
          }  
        paramInt1++;
        paramInt2 = paramInt3;
        continue;
      } 
      return;
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool1;
    boolean bool = this.mFormatItems;
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.mFormatItems = bool1;
    if (bool != this.mFormatItems)
      this.mFormatItemsWidth = 0; 
    int i = View.MeasureSpec.getMode(paramInt1);
    if (this.mFormatItems && this.mMenu != null && i != this.mFormatItemsWidth) {
      this.mFormatItemsWidth = i;
      this.mMenu.onItemsChanged(true);
    } 
    if (this.mFormatItems) {
      onMeasureExactFormat(paramInt1, paramInt2);
      return;
    } 
    int j = getChildCount();
    for (i = 0; i < j; i++) {
      LayoutParams layoutParams = (LayoutParams)getChildAt(i).getLayoutParams();
      layoutParams.rightMargin = 0;
      layoutParams.leftMargin = 0;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setOverflowReserved(boolean paramBoolean) {
    this.mReserveOverflow = paramBoolean;
  }
  
  public void setPresenter(ActionMenuPresenter paramActionMenuPresenter) {
    this.mPresenter = paramActionMenuPresenter;
  }
  
  public static interface ActionMenuChildView {
    boolean needsDividerAfter();
    
    boolean needsDividerBefore();
  }
  
  public static class LayoutParams extends LinearLayout.LayoutParams {
    @ExportedProperty
    public int cellsUsed;
    
    @ExportedProperty
    public boolean expandable;
    
    public boolean expanded;
    
    @ExportedProperty
    public int extraPixels;
    
    @ExportedProperty
    public boolean isOverflowButton;
    
    @ExportedProperty
    public boolean preventEdgeOffset;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.isOverflowButton = false;
    }
    
    public LayoutParams(int param1Int1, int param1Int2, boolean param1Boolean) {
      super(param1Int1, param1Int2);
      this.isOverflowButton = param1Boolean;
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.isOverflowButton = param1LayoutParams.isOverflowButton;
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/internal/view/menu/ActionMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */