package android.support.v7.view;

public interface CollapsibleActionView {
  void onActionViewCollapsed();
  
  void onActionViewExpanded();
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/view/CollapsibleActionView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */