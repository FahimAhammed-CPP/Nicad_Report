package android.support.v7.widget;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.support.v4.view.ActionProvider;
import android.support.v7.appcompat.R;
import android.support.v7.internal.widget.ActivityChooserModel;
import android.support.v7.internal.widget.ActivityChooserView;
import android.util.TypedValue;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

public class ShareActionProvider extends ActionProvider {
  private static final int DEFAULT_INITIAL_ACTIVITY_COUNT = 4;
  
  public static final String DEFAULT_SHARE_HISTORY_FILE_NAME = "share_history.xml";
  
  private final Context mContext;
  
  private int mMaxShownActivityCount = 4;
  
  private ActivityChooserModel.OnChooseActivityListener mOnChooseActivityListener;
  
  private final ShareMenuItemOnMenuItemClickListener mOnMenuItemClickListener = new ShareMenuItemOnMenuItemClickListener();
  
  private OnShareTargetSelectedListener mOnShareTargetSelectedListener;
  
  private String mShareHistoryFileName = "share_history.xml";
  
  public ShareActionProvider(Context paramContext) {
    super(paramContext);
    this.mContext = paramContext;
  }
  
  private void setActivityChooserPolicyIfNeeded() {
    if (this.mOnShareTargetSelectedListener != null) {
      if (this.mOnChooseActivityListener == null)
        this.mOnChooseActivityListener = new ShareActivityChooserModelPolicy(); 
      ActivityChooserModel.get(this.mContext, this.mShareHistoryFileName).setOnChooseActivityListener(this.mOnChooseActivityListener);
    } 
  }
  
  public boolean hasSubMenu() {
    return true;
  }
  
  public View onCreateActionView() {
    ActivityChooserModel activityChooserModel = ActivityChooserModel.get(this.mContext, this.mShareHistoryFileName);
    ActivityChooserView activityChooserView = new ActivityChooserView(this.mContext);
    activityChooserView.setActivityChooserModel(activityChooserModel);
    TypedValue typedValue = new TypedValue();
    this.mContext.getTheme().resolveAttribute(R.attr.actionModeShareDrawable, typedValue, true);
    activityChooserView.setExpandActivityOverflowButtonDrawable(this.mContext.getResources().getDrawable(typedValue.resourceId));
    activityChooserView.setProvider(this);
    activityChooserView.setDefaultActionButtonContentDescription(R.string.abc_shareactionprovider_share_with_application);
    activityChooserView.setExpandActivityOverflowButtonContentDescription(R.string.abc_shareactionprovider_share_with);
    return (View)activityChooserView;
  }
  
  public void onPrepareSubMenu(SubMenu paramSubMenu) {
    paramSubMenu.clear();
    ActivityChooserModel activityChooserModel = ActivityChooserModel.get(this.mContext, this.mShareHistoryFileName);
    PackageManager packageManager = this.mContext.getPackageManager();
    int i = activityChooserModel.getActivityCount();
    int j = Math.min(i, this.mMaxShownActivityCount);
    byte b;
    for (b = 0; b < j; b++) {
      ResolveInfo resolveInfo = activityChooserModel.getActivity(b);
      paramSubMenu.add(0, b, b, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setOnMenuItemClickListener(this.mOnMenuItemClickListener);
    } 
    if (j < i) {
      paramSubMenu = paramSubMenu.addSubMenu(0, j, j, this.mContext.getString(R.string.abc_activity_chooser_view_see_all));
      for (b = 0; b < i; b++) {
        ResolveInfo resolveInfo = activityChooserModel.getActivity(b);
        paramSubMenu.add(0, b, b, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setOnMenuItemClickListener(this.mOnMenuItemClickListener);
      } 
    } 
  }
  
  public void setOnShareTargetSelectedListener(OnShareTargetSelectedListener paramOnShareTargetSelectedListener) {
    this.mOnShareTargetSelectedListener = paramOnShareTargetSelectedListener;
    setActivityChooserPolicyIfNeeded();
  }
  
  public void setShareHistoryFileName(String paramString) {
    this.mShareHistoryFileName = paramString;
    setActivityChooserPolicyIfNeeded();
  }
  
  public void setShareIntent(Intent paramIntent) {
    ActivityChooserModel.get(this.mContext, this.mShareHistoryFileName).setIntent(paramIntent);
  }
  
  public static interface OnShareTargetSelectedListener {
    boolean onShareTargetSelected(ShareActionProvider param1ShareActionProvider, Intent param1Intent);
  }
  
  private class ShareActivityChooserModelPolicy implements ActivityChooserModel.OnChooseActivityListener {
    private ShareActivityChooserModelPolicy() {}
    
    public boolean onChooseActivity(ActivityChooserModel param1ActivityChooserModel, Intent param1Intent) {
      if (ShareActionProvider.this.mOnShareTargetSelectedListener != null)
        ShareActionProvider.this.mOnShareTargetSelectedListener.onShareTargetSelected(ShareActionProvider.this, param1Intent); 
      return false;
    }
  }
  
  private class ShareMenuItemOnMenuItemClickListener implements MenuItem.OnMenuItemClickListener {
    private ShareMenuItemOnMenuItemClickListener() {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      Intent intent = ActivityChooserModel.get(ShareActionProvider.this.mContext, ShareActionProvider.this.mShareHistoryFileName).chooseActivity(param1MenuItem.getItemId());
      if (intent != null) {
        intent.addFlags(524288);
        ShareActionProvider.this.mContext.startActivity(intent);
      } 
      return true;
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/widget/ShareActionProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */