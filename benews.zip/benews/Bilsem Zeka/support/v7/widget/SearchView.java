package android.support.v7.widget;

import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.support.v4.view.KeyEventCompat;
import android.support.v4.widget.CursorAdapter;
import android.support.v7.appcompat.R;
import android.support.v7.view.CollapsibleActionView;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

public class SearchView extends LinearLayout implements CollapsibleActionView {
  private static final boolean DBG = false;
  
  static final AutoCompleteTextViewReflector HIDDEN_METHOD_INVOKER = new AutoCompleteTextViewReflector();
  
  private static final String IME_OPTION_NO_MICROPHONE = "nm";
  
  private static final String LOG_TAG = "SearchView";
  
  private Bundle mAppSearchData;
  
  private boolean mClearingFocus;
  
  private ImageView mCloseButton;
  
  private int mCollapsedImeOptions;
  
  private View mDropDownAnchor;
  
  private boolean mExpandedInActionView;
  
  private boolean mIconified;
  
  private boolean mIconifiedByDefault;
  
  private int mMaxWidth;
  
  private CharSequence mOldQueryText;
  
  private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
      public void onClick(View param1View) {
        if (param1View == SearchView.this.mSearchButton) {
          SearchView.this.onSearchClicked();
          return;
        } 
        if (param1View == SearchView.this.mCloseButton) {
          SearchView.this.onCloseClicked();
          return;
        } 
        if (param1View == SearchView.this.mSubmitButton) {
          SearchView.this.onSubmitQuery();
          return;
        } 
        if (param1View == SearchView.this.mVoiceButton) {
          SearchView.this.onVoiceClicked();
          return;
        } 
        if (param1View == SearchView.this.mQueryTextView)
          SearchView.this.forceSuggestionQuery(); 
      }
    };
  
  private OnCloseListener mOnCloseListener;
  
  private final TextView.OnEditorActionListener mOnEditorActionListener = new TextView.OnEditorActionListener() {
      public boolean onEditorAction(TextView param1TextView, int param1Int, KeyEvent param1KeyEvent) {
        SearchView.this.onSubmitQuery();
        return true;
      }
    };
  
  private final AdapterView.OnItemClickListener mOnItemClickListener = new AdapterView.OnItemClickListener() {
      public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
        SearchView.this.onItemClicked(param1Int, 0, (String)null);
      }
    };
  
  private final AdapterView.OnItemSelectedListener mOnItemSelectedListener = new AdapterView.OnItemSelectedListener() {
      public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
        SearchView.this.onItemSelected(param1Int);
      }
      
      public void onNothingSelected(AdapterView<?> param1AdapterView) {}
    };
  
  private OnQueryTextListener mOnQueryChangeListener;
  
  private View.OnFocusChangeListener mOnQueryTextFocusChangeListener;
  
  private View.OnClickListener mOnSearchClickListener;
  
  private OnSuggestionListener mOnSuggestionListener;
  
  private final WeakHashMap<String, Drawable.ConstantState> mOutsideDrawablesCache = new WeakHashMap<String, Drawable.ConstantState>();
  
  private CharSequence mQueryHint;
  
  private boolean mQueryRefinement;
  
  private SearchAutoComplete mQueryTextView;
  
  private Runnable mReleaseCursorRunnable = new Runnable() {
      public void run() {
        if (SearchView.this.mSuggestionsAdapter != null && SearchView.this.mSuggestionsAdapter instanceof SuggestionsAdapter)
          SearchView.this.mSuggestionsAdapter.changeCursor(null); 
      }
    };
  
  private View mSearchButton;
  
  private View mSearchEditFrame;
  
  private ImageView mSearchHintIcon;
  
  private View mSearchPlate;
  
  private SearchableInfo mSearchable;
  
  private Runnable mShowImeRunnable = new Runnable() {
      public void run() {
        InputMethodManager inputMethodManager = (InputMethodManager)SearchView.this.getContext().getSystemService("input_method");
        if (inputMethodManager != null)
          SearchView.HIDDEN_METHOD_INVOKER.showSoftInputUnchecked(inputMethodManager, (View)SearchView.this, 0); 
      }
    };
  
  private View mSubmitArea;
  
  private View mSubmitButton;
  
  private boolean mSubmitButtonEnabled;
  
  private CursorAdapter mSuggestionsAdapter;
  
  View.OnKeyListener mTextKeyListener = new View.OnKeyListener() {
      public boolean onKey(View param1View, int param1Int, KeyEvent param1KeyEvent) {
        boolean bool1 = false;
        if (SearchView.this.mSearchable == null)
          return bool1; 
        if (SearchView.this.mQueryTextView.isPopupShowing() && SearchView.this.mQueryTextView.getListSelection() != -1)
          return SearchView.this.onSuggestionsKey(param1View, param1Int, param1KeyEvent); 
        boolean bool2 = bool1;
        if (!SearchView.this.mQueryTextView.isEmpty()) {
          bool2 = bool1;
          if (KeyEventCompat.hasNoModifiers(param1KeyEvent)) {
            bool2 = bool1;
            if (param1KeyEvent.getAction() == 1) {
              bool2 = bool1;
              if (param1Int == 66) {
                param1View.cancelLongPress();
                SearchView.this.launchQuerySearch(0, (String)null, SearchView.this.mQueryTextView.getText().toString());
                bool2 = true;
              } 
            } 
          } 
        } 
        return bool2;
      }
    };
  
  private TextWatcher mTextWatcher = new TextWatcher() {
      public void afterTextChanged(Editable param1Editable) {}
      
      public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
      
      public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {
        SearchView.this.onTextChanged(param1CharSequence);
      }
    };
  
  private Runnable mUpdateDrawableStateRunnable = new Runnable() {
      public void run() {
        SearchView.this.updateFocusedState();
      }
    };
  
  private CharSequence mUserQuery;
  
  private final Intent mVoiceAppSearchIntent;
  
  private View mVoiceButton;
  
  private boolean mVoiceButtonEnabled;
  
  private final Intent mVoiceWebSearchIntent;
  
  public SearchView(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public SearchView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    ((LayoutInflater)paramContext.getSystemService("layout_inflater")).inflate(R.layout.abc_search_view, (ViewGroup)this, true);
    this.mSearchButton = findViewById(R.id.search_button);
    this.mQueryTextView = (SearchAutoComplete)findViewById(R.id.search_src_text);
    this.mQueryTextView.setSearchView(this);
    this.mSearchEditFrame = findViewById(R.id.search_edit_frame);
    this.mSearchPlate = findViewById(R.id.search_plate);
    this.mSubmitArea = findViewById(R.id.submit_area);
    this.mSubmitButton = findViewById(R.id.search_go_btn);
    this.mCloseButton = (ImageView)findViewById(R.id.search_close_btn);
    this.mVoiceButton = findViewById(R.id.search_voice_btn);
    this.mSearchHintIcon = (ImageView)findViewById(R.id.search_mag_icon);
    this.mSearchButton.setOnClickListener(this.mOnClickListener);
    this.mCloseButton.setOnClickListener(this.mOnClickListener);
    this.mSubmitButton.setOnClickListener(this.mOnClickListener);
    this.mVoiceButton.setOnClickListener(this.mOnClickListener);
    this.mQueryTextView.setOnClickListener(this.mOnClickListener);
    this.mQueryTextView.addTextChangedListener(this.mTextWatcher);
    this.mQueryTextView.setOnEditorActionListener(this.mOnEditorActionListener);
    this.mQueryTextView.setOnItemClickListener(this.mOnItemClickListener);
    this.mQueryTextView.setOnItemSelectedListener(this.mOnItemSelectedListener);
    this.mQueryTextView.setOnKeyListener(this.mTextKeyListener);
    this.mQueryTextView.setOnFocusChangeListener(new View.OnFocusChangeListener() {
          public void onFocusChange(View param1View, boolean param1Boolean) {
            if (SearchView.this.mOnQueryTextFocusChangeListener != null)
              SearchView.this.mOnQueryTextFocusChangeListener.onFocusChange((View)SearchView.this, param1Boolean); 
          }
        });
    TypedArray typedArray2 = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.SearchView, 0, 0);
    setIconifiedByDefault(typedArray2.getBoolean(3, true));
    int i = typedArray2.getDimensionPixelSize(0, -1);
    if (i != -1)
      setMaxWidth(i); 
    CharSequence charSequence = typedArray2.getText(4);
    if (!TextUtils.isEmpty(charSequence))
      setQueryHint(charSequence); 
    i = typedArray2.getInt(2, -1);
    if (i != -1)
      setImeOptions(i); 
    i = typedArray2.getInt(1, -1);
    if (i != -1)
      setInputType(i); 
    typedArray2.recycle();
    TypedArray typedArray1 = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.View, 0, 0);
    boolean bool = typedArray1.getBoolean(0, true);
    typedArray1.recycle();
    setFocusable(bool);
    this.mVoiceWebSearchIntent = new Intent("android.speech.action.WEB_SEARCH");
    this.mVoiceWebSearchIntent.addFlags(268435456);
    this.mVoiceWebSearchIntent.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
    this.mVoiceAppSearchIntent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
    this.mVoiceAppSearchIntent.addFlags(268435456);
    this.mDropDownAnchor = findViewById(this.mQueryTextView.getDropDownAnchor());
    if (this.mDropDownAnchor != null)
      if (Build.VERSION.SDK_INT >= 11) {
        addOnLayoutChangeListenerToDropDownAnchorSDK11();
      } else {
        addOnLayoutChangeListenerToDropDownAnchorBase();
      }  
    updateViewsVisibility(this.mIconifiedByDefault);
    updateQueryHint();
  }
  
  private void addOnLayoutChangeListenerToDropDownAnchorBase() {
    this.mDropDownAnchor.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
          public void onGlobalLayout() {
            SearchView.this.adjustDropDownSizeAndPosition();
          }
        });
  }
  
  private void addOnLayoutChangeListenerToDropDownAnchorSDK11() {
    this.mDropDownAnchor.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
          public void onLayoutChange(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, int param1Int7, int param1Int8) {
            SearchView.this.adjustDropDownSizeAndPosition();
          }
        });
  }
  
  private void adjustDropDownSizeAndPosition() {
    if (this.mDropDownAnchor.getWidth() > 1) {
      byte b;
      Resources resources = getContext().getResources();
      int i = this.mSearchPlate.getPaddingLeft();
      Rect rect = new Rect();
      if (this.mIconifiedByDefault) {
        b = resources.getDimensionPixelSize(R.dimen.abc_dropdownitem_icon_width) + resources.getDimensionPixelSize(R.dimen.abc_dropdownitem_text_padding_left);
      } else {
        b = 0;
      } 
      this.mQueryTextView.getDropDownBackground().getPadding(rect);
      int j = rect.left;
      this.mQueryTextView.setDropDownHorizontalOffset(i - j + b);
      j = this.mDropDownAnchor.getWidth();
      int k = rect.left;
      int m = rect.right;
      this.mQueryTextView.setDropDownWidth(j + k + m + b - i);
    } 
  }
  
  private Intent createIntent(String paramString1, Uri paramUri, String paramString2, String paramString3, int paramInt, String paramString4) {
    Intent intent = new Intent(paramString1);
    intent.addFlags(268435456);
    if (paramUri != null)
      intent.setData(paramUri); 
    intent.putExtra("user_query", this.mUserQuery);
    if (paramString3 != null)
      intent.putExtra("query", paramString3); 
    if (paramString2 != null)
      intent.putExtra("intent_extra_data_key", paramString2); 
    if (this.mAppSearchData != null)
      intent.putExtra("app_data", this.mAppSearchData); 
    if (paramInt != 0) {
      intent.putExtra("action_key", paramInt);
      intent.putExtra("action_msg", paramString4);
    } 
    intent.setComponent(this.mSearchable.getSearchActivity());
    return intent;
  }
  
  private Intent createIntentFromSuggestion(Cursor paramCursor, int paramInt, String paramString) {
    Intent intent;
    try {
      Uri uri;
      String str1 = SuggestionsAdapter.getColumnString(paramCursor, "suggest_intent_action");
      String str2 = str1;
      if (str1 == null)
        str2 = this.mSearchable.getSuggestIntentAction(); 
      str1 = str2;
      if (str2 == null)
        str1 = "android.intent.action.SEARCH"; 
      String str3 = SuggestionsAdapter.getColumnString(paramCursor, "suggest_intent_data");
      str2 = str3;
      if (str3 == null)
        str2 = this.mSearchable.getSuggestIntentData(); 
      str3 = str2;
      if (str2 != null) {
        String str = SuggestionsAdapter.getColumnString(paramCursor, "suggest_intent_data_id");
        str3 = str2;
        if (str != null) {
          StringBuilder stringBuilder = new StringBuilder();
          this();
          str3 = stringBuilder.append(str2).append("/").append(Uri.encode(str)).toString();
        } 
      } 
      if (str3 == null) {
        str2 = null;
      } else {
        uri = Uri.parse(str3);
      } 
      str3 = SuggestionsAdapter.getColumnString(paramCursor, "suggest_intent_query");
      Intent intent1 = createIntent(str1, uri, SuggestionsAdapter.getColumnString(paramCursor, "suggest_intent_extra_data"), str3, paramInt, paramString);
      intent = intent1;
    } catch (RuntimeException runtimeException) {}
    return intent;
  }
  
  private Intent createVoiceAppSearchIntent(Intent paramIntent, SearchableInfo paramSearchableInfo) {
    String str2;
    ComponentName componentName = paramSearchableInfo.getSearchActivity();
    Intent intent1 = new Intent("android.intent.action.SEARCH");
    intent1.setComponent(componentName);
    PendingIntent pendingIntent = PendingIntent.getActivity(getContext(), 0, intent1, 1073741824);
    Bundle bundle = new Bundle();
    if (this.mAppSearchData != null)
      bundle.putParcelable("app_data", (Parcelable)this.mAppSearchData); 
    Intent intent2 = new Intent(paramIntent);
    String str1 = "free_form";
    intent1 = null;
    String str3 = null;
    int i = 1;
    Resources resources = getResources();
    if (paramSearchableInfo.getVoiceLanguageModeId() != 0)
      str1 = resources.getString(paramSearchableInfo.getVoiceLanguageModeId()); 
    if (paramSearchableInfo.getVoicePromptTextId() != 0)
      str2 = resources.getString(paramSearchableInfo.getVoicePromptTextId()); 
    if (paramSearchableInfo.getVoiceLanguageId() != 0)
      str3 = resources.getString(paramSearchableInfo.getVoiceLanguageId()); 
    if (paramSearchableInfo.getVoiceMaxResults() != 0)
      i = paramSearchableInfo.getVoiceMaxResults(); 
    intent2.putExtra("android.speech.extra.LANGUAGE_MODEL", str1);
    intent2.putExtra("android.speech.extra.PROMPT", str2);
    intent2.putExtra("android.speech.extra.LANGUAGE", str3);
    intent2.putExtra("android.speech.extra.MAX_RESULTS", i);
    if (componentName == null) {
      str1 = null;
      intent2.putExtra("calling_package", str1);
      intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", (Parcelable)pendingIntent);
      intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
      return intent2;
    } 
    str1 = componentName.flattenToShortString();
    intent2.putExtra("calling_package", str1);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", (Parcelable)pendingIntent);
    intent2.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
    return intent2;
  }
  
  private Intent createVoiceWebSearchIntent(Intent paramIntent, SearchableInfo paramSearchableInfo) {
    Intent intent = new Intent(paramIntent);
    ComponentName componentName = paramSearchableInfo.getSearchActivity();
    if (componentName == null) {
      componentName = null;
      intent.putExtra("calling_package", (String)componentName);
      return intent;
    } 
    String str = componentName.flattenToShortString();
    intent.putExtra("calling_package", str);
    return intent;
  }
  
  private void dismissSuggestions() {
    this.mQueryTextView.dismissDropDown();
  }
  
  private void forceSuggestionQuery() {
    HIDDEN_METHOD_INVOKER.doBeforeTextChanged(this.mQueryTextView);
    HIDDEN_METHOD_INVOKER.doAfterTextChanged(this.mQueryTextView);
  }
  
  private CharSequence getDecoratedHint(CharSequence paramCharSequence) {
    SpannableStringBuilder spannableStringBuilder;
    if (this.mIconifiedByDefault) {
      SpannableStringBuilder spannableStringBuilder1 = new SpannableStringBuilder("   ");
      spannableStringBuilder1.append(paramCharSequence);
      Drawable drawable = getContext().getResources().getDrawable(getSearchIconId());
      int i = (int)(this.mQueryTextView.getTextSize() * 1.25D);
      drawable.setBounds(0, 0, i, i);
      spannableStringBuilder1.setSpan(new ImageSpan(drawable), 1, 2, 33);
      spannableStringBuilder = spannableStringBuilder1;
    } 
    return (CharSequence)spannableStringBuilder;
  }
  
  private int getPreferredWidth() {
    return getContext().getResources().getDimensionPixelSize(R.dimen.abc_search_view_preferred_width);
  }
  
  private int getSearchIconId() {
    TypedValue typedValue = new TypedValue();
    getContext().getTheme().resolveAttribute(R.attr.searchViewSearchIcon, typedValue, true);
    return typedValue.resourceId;
  }
  
  private boolean hasVoiceSearch() {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (this.mSearchable != null) {
      bool2 = bool1;
      if (this.mSearchable.getVoiceSearchEnabled()) {
        Intent intent = null;
        if (this.mSearchable.getVoiceSearchLaunchWebSearch()) {
          intent = this.mVoiceWebSearchIntent;
        } else if (this.mSearchable.getVoiceSearchLaunchRecognizer()) {
          intent = this.mVoiceAppSearchIntent;
        } 
        bool2 = bool1;
        if (intent != null) {
          bool2 = bool1;
          if (getContext().getPackageManager().resolveActivity(intent, 65536) != null)
            bool2 = true; 
        } 
      } 
    } 
    return bool2;
  }
  
  static boolean isLandscapeMode(Context paramContext) {
    return ((paramContext.getResources().getConfiguration()).orientation == 2);
  }
  
  private boolean isSubmitAreaEnabled() {
    return ((this.mSubmitButtonEnabled || this.mVoiceButtonEnabled) && !isIconified());
  }
  
  private void launchIntent(Intent paramIntent) {
    if (paramIntent != null)
      try {
        getContext().startActivity(paramIntent);
      } catch (RuntimeException runtimeException) {
        Log.e("SearchView", "Failed launch activity: " + paramIntent, runtimeException);
      }  
  }
  
  private void launchQuerySearch(int paramInt, String paramString1, String paramString2) {
    Intent intent = createIntent("android.intent.action.SEARCH", (Uri)null, (String)null, paramString2, paramInt, paramString1);
    getContext().startActivity(intent);
  }
  
  private boolean launchSuggestion(int paramInt1, int paramInt2, String paramString) {
    Cursor cursor = this.mSuggestionsAdapter.getCursor();
    if (cursor != null && cursor.moveToPosition(paramInt1)) {
      launchIntent(createIntentFromSuggestion(cursor, paramInt2, paramString));
      return true;
    } 
    return false;
  }
  
  private void onCloseClicked() {
    if (TextUtils.isEmpty((CharSequence)this.mQueryTextView.getText())) {
      if (this.mIconifiedByDefault && (this.mOnCloseListener == null || !this.mOnCloseListener.onClose())) {
        clearFocus();
        updateViewsVisibility(true);
      } 
      return;
    } 
    this.mQueryTextView.setText("");
    this.mQueryTextView.requestFocus();
    setImeVisibility(true);
  }
  
  private boolean onItemClicked(int paramInt1, int paramInt2, String paramString) {
    boolean bool = false;
    if (this.mOnSuggestionListener == null || !this.mOnSuggestionListener.onSuggestionClick(paramInt1)) {
      launchSuggestion(paramInt1, 0, (String)null);
      setImeVisibility(false);
      dismissSuggestions();
      bool = true;
    } 
    return bool;
  }
  
  private boolean onItemSelected(int paramInt) {
    if (this.mOnSuggestionListener == null || !this.mOnSuggestionListener.onSuggestionSelect(paramInt)) {
      rewriteQueryFromSuggestion(paramInt);
      return true;
    } 
    return false;
  }
  
  private void onSearchClicked() {
    updateViewsVisibility(false);
    this.mQueryTextView.requestFocus();
    setImeVisibility(true);
    if (this.mOnSearchClickListener != null)
      this.mOnSearchClickListener.onClick((View)this); 
  }
  
  private void onSubmitQuery() {
    Editable editable = this.mQueryTextView.getText();
    if (editable != null && TextUtils.getTrimmedLength((CharSequence)editable) > 0 && (this.mOnQueryChangeListener == null || !this.mOnQueryChangeListener.onQueryTextSubmit(editable.toString()))) {
      if (this.mSearchable != null) {
        launchQuerySearch(0, (String)null, editable.toString());
        setImeVisibility(false);
      } 
      dismissSuggestions();
    } 
  }
  
  private boolean onSuggestionsKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    boolean bool1 = false;
    if (this.mSearchable == null)
      return bool1; 
    boolean bool2 = bool1;
    if (this.mSuggestionsAdapter != null) {
      bool2 = bool1;
      if (paramKeyEvent.getAction() == 0) {
        bool2 = bool1;
        if (KeyEventCompat.hasNoModifiers(paramKeyEvent)) {
          if (paramInt == 66 || paramInt == 84 || paramInt == 61)
            return onItemClicked(this.mQueryTextView.getListSelection(), 0, (String)null); 
          if (paramInt == 21 || paramInt == 22) {
            if (paramInt == 21) {
              paramInt = 0;
            } else {
              paramInt = this.mQueryTextView.length();
            } 
            this.mQueryTextView.setSelection(paramInt);
            this.mQueryTextView.setListSelection(0);
            this.mQueryTextView.clearListSelection();
            HIDDEN_METHOD_INVOKER.ensureImeVisible(this.mQueryTextView, true);
            return true;
          } 
          bool2 = bool1;
          if (paramInt == 19) {
            bool2 = bool1;
            if (this.mQueryTextView.getListSelection() == 0)
              bool2 = bool1; 
          } 
        } 
      } 
    } 
    return bool2;
  }
  
  private void onTextChanged(CharSequence paramCharSequence) {
    boolean bool2;
    boolean bool1 = true;
    Editable editable = this.mQueryTextView.getText();
    this.mUserQuery = (CharSequence)editable;
    if (!TextUtils.isEmpty((CharSequence)editable)) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    updateSubmitButton(bool2);
    if (!bool2) {
      bool2 = bool1;
    } else {
      bool2 = false;
    } 
    updateVoiceButton(bool2);
    updateCloseButton();
    updateSubmitArea();
    if (this.mOnQueryChangeListener != null && !TextUtils.equals(paramCharSequence, this.mOldQueryText))
      this.mOnQueryChangeListener.onQueryTextChange(paramCharSequence.toString()); 
    this.mOldQueryText = paramCharSequence.toString();
  }
  
  private void onVoiceClicked() {
    if (this.mSearchable != null) {
      SearchableInfo searchableInfo = this.mSearchable;
      try {
        if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
          Intent intent = createVoiceWebSearchIntent(this.mVoiceWebSearchIntent, searchableInfo);
          getContext().startActivity(intent);
          return;
        } 
      } catch (ActivityNotFoundException activityNotFoundException) {
        Log.w("SearchView", "Could not find voice search activity");
        return;
      } 
      if (activityNotFoundException.getVoiceSearchLaunchRecognizer()) {
        Intent intent = createVoiceAppSearchIntent(this.mVoiceAppSearchIntent, (SearchableInfo)activityNotFoundException);
        getContext().startActivity(intent);
      } 
    } 
  }
  
  private void postUpdateFocusedState() {
    post(this.mUpdateDrawableStateRunnable);
  }
  
  private void rewriteQueryFromSuggestion(int paramInt) {
    Editable editable = this.mQueryTextView.getText();
    Cursor cursor = this.mSuggestionsAdapter.getCursor();
    if (cursor != null) {
      if (cursor.moveToPosition(paramInt)) {
        CharSequence charSequence = this.mSuggestionsAdapter.convertToString(cursor);
        if (charSequence != null) {
          setQuery(charSequence);
          return;
        } 
        setQuery((CharSequence)editable);
        return;
      } 
      setQuery((CharSequence)editable);
    } 
  }
  
  private void setImeVisibility(boolean paramBoolean) {
    if (paramBoolean) {
      post(this.mShowImeRunnable);
      return;
    } 
    removeCallbacks(this.mShowImeRunnable);
    InputMethodManager inputMethodManager = (InputMethodManager)getContext().getSystemService("input_method");
    if (inputMethodManager != null)
      inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0); 
  }
  
  private void setQuery(CharSequence paramCharSequence) {
    int i;
    this.mQueryTextView.setText(paramCharSequence);
    SearchAutoComplete searchAutoComplete = this.mQueryTextView;
    if (TextUtils.isEmpty(paramCharSequence)) {
      i = 0;
    } else {
      i = paramCharSequence.length();
    } 
    searchAutoComplete.setSelection(i);
  }
  
  private void updateCloseButton() {
    boolean bool;
    int[] arrayOfInt;
    byte b1 = 1;
    byte b2 = 0;
    if (!TextUtils.isEmpty((CharSequence)this.mQueryTextView.getText())) {
      bool = true;
    } else {
      bool = false;
    } 
    byte b3 = b1;
    if (!bool)
      if (this.mIconifiedByDefault && !this.mExpandedInActionView) {
        b3 = b1;
      } else {
        b3 = 0;
      }  
    ImageView imageView = this.mCloseButton;
    if (b3) {
      b3 = b2;
    } else {
      b3 = 8;
    } 
    imageView.setVisibility(b3);
    Drawable drawable = this.mCloseButton.getDrawable();
    if (bool) {
      arrayOfInt = ENABLED_STATE_SET;
    } else {
      arrayOfInt = EMPTY_STATE_SET;
    } 
    drawable.setState(arrayOfInt);
  }
  
  private void updateFocusedState() {
    int[] arrayOfInt;
    boolean bool = this.mQueryTextView.hasFocus();
    Drawable drawable = this.mSearchPlate.getBackground();
    if (bool) {
      arrayOfInt = FOCUSED_STATE_SET;
    } else {
      arrayOfInt = EMPTY_STATE_SET;
    } 
    drawable.setState(arrayOfInt);
    drawable = this.mSubmitArea.getBackground();
    if (bool) {
      arrayOfInt = FOCUSED_STATE_SET;
    } else {
      arrayOfInt = EMPTY_STATE_SET;
    } 
    drawable.setState(arrayOfInt);
    invalidate();
  }
  
  private void updateQueryHint() {
    if (this.mQueryHint != null) {
      this.mQueryTextView.setHint(getDecoratedHint(this.mQueryHint));
      return;
    } 
    if (this.mSearchable != null) {
      String str = null;
      int i = this.mSearchable.getHintId();
      if (i != 0)
        str = getContext().getString(i); 
      if (str != null)
        this.mQueryTextView.setHint(getDecoratedHint(str)); 
      return;
    } 
    this.mQueryTextView.setHint(getDecoratedHint(""));
  }
  
  private void updateSearchAutoComplete() {
    boolean bool = true;
    this.mQueryTextView.setThreshold(this.mSearchable.getSuggestThreshold());
    this.mQueryTextView.setImeOptions(this.mSearchable.getImeOptions());
    int i = this.mSearchable.getInputType();
    int j = i;
    if ((i & 0xF) == 1) {
      i &= 0xFFFEFFFF;
      j = i;
      if (this.mSearchable.getSuggestAuthority() != null)
        j = i | 0x10000 | 0x80000; 
    } 
    this.mQueryTextView.setInputType(j);
    if (this.mSuggestionsAdapter != null)
      this.mSuggestionsAdapter.changeCursor(null); 
    if (this.mSearchable.getSuggestAuthority() != null) {
      this.mSuggestionsAdapter = (CursorAdapter)new SuggestionsAdapter(getContext(), this, this.mSearchable, this.mOutsideDrawablesCache);
      this.mQueryTextView.setAdapter((ListAdapter)this.mSuggestionsAdapter);
      SuggestionsAdapter suggestionsAdapter = (SuggestionsAdapter)this.mSuggestionsAdapter;
      j = bool;
      if (this.mQueryRefinement)
        j = 2; 
      suggestionsAdapter.setQueryRefinement(j);
    } 
  }
  
  private void updateSubmitArea() {
    // Byte code:
    //   0: bipush #8
    //   2: istore_1
    //   3: iload_1
    //   4: istore_2
    //   5: aload_0
    //   6: invokespecial isSubmitAreaEnabled : ()Z
    //   9: ifeq -> 36
    //   12: aload_0
    //   13: getfield mSubmitButton : Landroid/view/View;
    //   16: invokevirtual getVisibility : ()I
    //   19: ifeq -> 34
    //   22: iload_1
    //   23: istore_2
    //   24: aload_0
    //   25: getfield mVoiceButton : Landroid/view/View;
    //   28: invokevirtual getVisibility : ()I
    //   31: ifne -> 36
    //   34: iconst_0
    //   35: istore_2
    //   36: aload_0
    //   37: getfield mSubmitArea : Landroid/view/View;
    //   40: iload_2
    //   41: invokevirtual setVisibility : (I)V
    //   44: return
  }
  
  private void updateSubmitButton(boolean paramBoolean) {
    // Byte code:
    //   0: bipush #8
    //   2: istore_2
    //   3: iload_2
    //   4: istore_3
    //   5: aload_0
    //   6: getfield mSubmitButtonEnabled : Z
    //   9: ifeq -> 45
    //   12: iload_2
    //   13: istore_3
    //   14: aload_0
    //   15: invokespecial isSubmitAreaEnabled : ()Z
    //   18: ifeq -> 45
    //   21: iload_2
    //   22: istore_3
    //   23: aload_0
    //   24: invokevirtual hasFocus : ()Z
    //   27: ifeq -> 45
    //   30: iload_1
    //   31: ifne -> 43
    //   34: iload_2
    //   35: istore_3
    //   36: aload_0
    //   37: getfield mVoiceButtonEnabled : Z
    //   40: ifne -> 45
    //   43: iconst_0
    //   44: istore_3
    //   45: aload_0
    //   46: getfield mSubmitButton : Landroid/view/View;
    //   49: iload_3
    //   50: invokevirtual setVisibility : (I)V
    //   53: return
  }
  
  private void updateViewsVisibility(boolean paramBoolean) {
    byte b2;
    boolean bool2;
    boolean bool1 = true;
    byte b1 = 8;
    this.mIconified = paramBoolean;
    if (paramBoolean) {
      b2 = 0;
    } else {
      b2 = 8;
    } 
    if (!TextUtils.isEmpty((CharSequence)this.mQueryTextView.getText())) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    this.mSearchButton.setVisibility(b2);
    updateSubmitButton(bool2);
    View view = this.mSearchEditFrame;
    if (paramBoolean) {
      b2 = 8;
    } else {
      b2 = 0;
    } 
    view.setVisibility(b2);
    ImageView imageView = this.mSearchHintIcon;
    if (this.mIconifiedByDefault) {
      b2 = b1;
    } else {
      b2 = 0;
    } 
    imageView.setVisibility(b2);
    updateCloseButton();
    if (!bool2) {
      paramBoolean = bool1;
    } else {
      paramBoolean = false;
    } 
    updateVoiceButton(paramBoolean);
    updateSubmitArea();
  }
  
  private void updateVoiceButton(boolean paramBoolean) {
    byte b1 = 8;
    byte b2 = b1;
    if (this.mVoiceButtonEnabled) {
      b2 = b1;
      if (!isIconified()) {
        b2 = b1;
        if (paramBoolean) {
          b2 = 0;
          this.mSubmitButton.setVisibility(8);
        } 
      } 
    } 
    this.mVoiceButton.setVisibility(b2);
  }
  
  public void clearFocus() {
    this.mClearingFocus = true;
    setImeVisibility(false);
    super.clearFocus();
    this.mQueryTextView.clearFocus();
    this.mClearingFocus = false;
  }
  
  public int getImeOptions() {
    return this.mQueryTextView.getImeOptions();
  }
  
  public int getInputType() {
    return this.mQueryTextView.getInputType();
  }
  
  public int getMaxWidth() {
    return this.mMaxWidth;
  }
  
  public CharSequence getQuery() {
    return (CharSequence)this.mQueryTextView.getText();
  }
  
  public CharSequence getQueryHint() {
    if (this.mQueryHint != null)
      return this.mQueryHint; 
    if (this.mSearchable != null) {
      String str = null;
      int i = this.mSearchable.getHintId();
      if (i != 0)
        str = getContext().getString(i); 
      return str;
    } 
    return null;
  }
  
  public CursorAdapter getSuggestionsAdapter() {
    return this.mSuggestionsAdapter;
  }
  
  public boolean isIconfiedByDefault() {
    return this.mIconifiedByDefault;
  }
  
  public boolean isIconified() {
    return this.mIconified;
  }
  
  public boolean isQueryRefinementEnabled() {
    return this.mQueryRefinement;
  }
  
  public boolean isSubmitButtonEnabled() {
    return this.mSubmitButtonEnabled;
  }
  
  public void onActionViewCollapsed() {
    clearFocus();
    updateViewsVisibility(true);
    this.mQueryTextView.setImeOptions(this.mCollapsedImeOptions);
    this.mExpandedInActionView = false;
  }
  
  public void onActionViewExpanded() {
    if (!this.mExpandedInActionView) {
      this.mExpandedInActionView = true;
      this.mCollapsedImeOptions = this.mQueryTextView.getImeOptions();
      this.mQueryTextView.setImeOptions(this.mCollapsedImeOptions | 0x2000000);
      this.mQueryTextView.setText("");
      setIconified(false);
    } 
  }
  
  protected void onDetachedFromWindow() {
    removeCallbacks(this.mUpdateDrawableStateRunnable);
    post(this.mReleaseCursorRunnable);
    super.onDetachedFromWindow();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return (this.mSearchable == null) ? false : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (isIconified()) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = View.MeasureSpec.getSize(paramInt1);
    switch (i) {
      default:
        paramInt1 = j;
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2);
        return;
      case -2147483648:
        if (this.mMaxWidth > 0) {
          paramInt1 = Math.min(this.mMaxWidth, j);
        } else {
          paramInt1 = Math.min(getPreferredWidth(), j);
        } 
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2);
        return;
      case 1073741824:
        paramInt1 = j;
        if (this.mMaxWidth > 0)
          paramInt1 = Math.min(this.mMaxWidth, j); 
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2);
        return;
      case 0:
        break;
    } 
    if (this.mMaxWidth > 0) {
      paramInt1 = this.mMaxWidth;
    } else {
      paramInt1 = getPreferredWidth();
    } 
    super.onMeasure(View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824), paramInt2);
  }
  
  void onQueryRefine(CharSequence paramCharSequence) {
    setQuery(paramCharSequence);
  }
  
  void onTextFocusChanged() {
    updateViewsVisibility(isIconified());
    postUpdateFocusedState();
    if (this.mQueryTextView.hasFocus())
      forceSuggestionQuery(); 
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    super.onWindowFocusChanged(paramBoolean);
    postUpdateFocusedState();
  }
  
  public boolean requestFocus(int paramInt, Rect paramRect) {
    if (this.mClearingFocus)
      return false; 
    if (!isFocusable())
      return false; 
    if (!isIconified()) {
      boolean bool2 = this.mQueryTextView.requestFocus(paramInt, paramRect);
      boolean bool1 = bool2;
      if (bool2) {
        updateViewsVisibility(false);
        bool1 = bool2;
      } 
      return bool1;
    } 
    return super.requestFocus(paramInt, paramRect);
  }
  
  public void setAppSearchData(Bundle paramBundle) {
    this.mAppSearchData = paramBundle;
  }
  
  public void setIconified(boolean paramBoolean) {
    if (paramBoolean) {
      onCloseClicked();
      return;
    } 
    onSearchClicked();
  }
  
  public void setIconifiedByDefault(boolean paramBoolean) {
    if (this.mIconifiedByDefault != paramBoolean) {
      this.mIconifiedByDefault = paramBoolean;
      updateViewsVisibility(paramBoolean);
      updateQueryHint();
    } 
  }
  
  public void setImeOptions(int paramInt) {
    this.mQueryTextView.setImeOptions(paramInt);
  }
  
  public void setInputType(int paramInt) {
    this.mQueryTextView.setInputType(paramInt);
  }
  
  public void setMaxWidth(int paramInt) {
    this.mMaxWidth = paramInt;
    requestLayout();
  }
  
  public void setOnCloseListener(OnCloseListener paramOnCloseListener) {
    this.mOnCloseListener = paramOnCloseListener;
  }
  
  public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener paramOnFocusChangeListener) {
    this.mOnQueryTextFocusChangeListener = paramOnFocusChangeListener;
  }
  
  public void setOnQueryTextListener(OnQueryTextListener paramOnQueryTextListener) {
    this.mOnQueryChangeListener = paramOnQueryTextListener;
  }
  
  public void setOnSearchClickListener(View.OnClickListener paramOnClickListener) {
    this.mOnSearchClickListener = paramOnClickListener;
  }
  
  public void setOnSuggestionListener(OnSuggestionListener paramOnSuggestionListener) {
    this.mOnSuggestionListener = paramOnSuggestionListener;
  }
  
  public void setQuery(CharSequence paramCharSequence, boolean paramBoolean) {
    this.mQueryTextView.setText(paramCharSequence);
    if (paramCharSequence != null) {
      this.mQueryTextView.setSelection(this.mQueryTextView.length());
      this.mUserQuery = paramCharSequence;
    } 
    if (paramBoolean && !TextUtils.isEmpty(paramCharSequence))
      onSubmitQuery(); 
  }
  
  public void setQueryHint(CharSequence paramCharSequence) {
    this.mQueryHint = paramCharSequence;
    updateQueryHint();
  }
  
  public void setQueryRefinementEnabled(boolean paramBoolean) {
    this.mQueryRefinement = paramBoolean;
    if (this.mSuggestionsAdapter instanceof SuggestionsAdapter) {
      boolean bool;
      SuggestionsAdapter suggestionsAdapter = (SuggestionsAdapter)this.mSuggestionsAdapter;
      if (paramBoolean) {
        bool = true;
      } else {
        bool = true;
      } 
      suggestionsAdapter.setQueryRefinement(bool);
    } 
  }
  
  public void setSearchableInfo(SearchableInfo paramSearchableInfo) {
    this.mSearchable = paramSearchableInfo;
    if (this.mSearchable != null) {
      updateSearchAutoComplete();
      updateQueryHint();
    } 
    this.mVoiceButtonEnabled = hasVoiceSearch();
    if (this.mVoiceButtonEnabled)
      this.mQueryTextView.setPrivateImeOptions("nm"); 
    updateViewsVisibility(isIconified());
  }
  
  public void setSubmitButtonEnabled(boolean paramBoolean) {
    this.mSubmitButtonEnabled = paramBoolean;
    updateViewsVisibility(isIconified());
  }
  
  public void setSuggestionsAdapter(CursorAdapter paramCursorAdapter) {
    this.mSuggestionsAdapter = paramCursorAdapter;
    this.mQueryTextView.setAdapter((ListAdapter)this.mSuggestionsAdapter);
  }
  
  private static class AutoCompleteTextViewReflector {
    private Method doAfterTextChanged;
    
    private Method doBeforeTextChanged;
    
    private Method ensureImeVisible;
    
    private Method showSoftInputUnchecked;
    
    AutoCompleteTextViewReflector() {
      try {
        this.doBeforeTextChanged = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
        this.doBeforeTextChanged.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {}
      try {
        this.doAfterTextChanged = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
        this.doAfterTextChanged.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {}
      try {
        this.ensureImeVisible = AutoCompleteTextView.class.getMethod("ensureImeVisible", new Class[] { boolean.class });
        this.ensureImeVisible.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {}
      try {
        this.showSoftInputUnchecked = InputMethodManager.class.getMethod("showSoftInputUnchecked", new Class[] { int.class, ResultReceiver.class });
        this.showSoftInputUnchecked.setAccessible(true);
      } catch (NoSuchMethodException noSuchMethodException) {}
    }
    
    void doAfterTextChanged(AutoCompleteTextView param1AutoCompleteTextView) {
      if (this.doAfterTextChanged != null)
        try {
          this.doAfterTextChanged.invoke(param1AutoCompleteTextView, new Object[0]);
        } catch (Exception exception) {} 
    }
    
    void doBeforeTextChanged(AutoCompleteTextView param1AutoCompleteTextView) {
      if (this.doBeforeTextChanged != null)
        try {
          this.doBeforeTextChanged.invoke(param1AutoCompleteTextView, new Object[0]);
        } catch (Exception exception) {} 
    }
    
    void ensureImeVisible(AutoCompleteTextView param1AutoCompleteTextView, boolean param1Boolean) {
      if (this.ensureImeVisible != null)
        try {
          this.ensureImeVisible.invoke(param1AutoCompleteTextView, new Object[] { Boolean.valueOf(param1Boolean) });
        } catch (Exception exception) {} 
    }
    
    void showSoftInputUnchecked(InputMethodManager param1InputMethodManager, View param1View, int param1Int) {
      if (this.showSoftInputUnchecked != null)
        try {
          this.showSoftInputUnchecked.invoke(param1InputMethodManager, new Object[] { Integer.valueOf(param1Int), null });
          return;
        } catch (Exception exception) {} 
      param1InputMethodManager.showSoftInput(param1View, param1Int);
    }
  }
  
  public static interface OnCloseListener {
    boolean onClose();
  }
  
  public static interface OnQueryTextListener {
    boolean onQueryTextChange(String param1String);
    
    boolean onQueryTextSubmit(String param1String);
  }
  
  public static interface OnSuggestionListener {
    boolean onSuggestionClick(int param1Int);
    
    boolean onSuggestionSelect(int param1Int);
  }
  
  public static class SearchAutoComplete extends AutoCompleteTextView {
    private SearchView mSearchView;
    
    private int mThreshold = getThreshold();
    
    public SearchAutoComplete(Context param1Context) {
      super(param1Context);
    }
    
    public SearchAutoComplete(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public SearchAutoComplete(Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int);
    }
    
    private boolean isEmpty() {
      return (TextUtils.getTrimmedLength((CharSequence)getText()) == 0);
    }
    
    public boolean enoughToFilter() {
      return (this.mThreshold <= 0 || super.enoughToFilter());
    }
    
    protected void onFocusChanged(boolean param1Boolean, int param1Int, Rect param1Rect) {
      super.onFocusChanged(param1Boolean, param1Int, param1Rect);
      this.mSearchView.onTextFocusChanged();
    }
    
    public boolean onKeyPreIme(int param1Int, KeyEvent param1KeyEvent) {
      boolean bool = true;
      if (param1Int == 4) {
        if (param1KeyEvent.getAction() == 0 && param1KeyEvent.getRepeatCount() == 0) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          boolean bool1 = bool;
          if (dispatcherState != null) {
            dispatcherState.startTracking(param1KeyEvent, this);
            bool1 = bool;
          } 
          return bool1;
        } 
        if (param1KeyEvent.getAction() == 1) {
          KeyEvent.DispatcherState dispatcherState = getKeyDispatcherState();
          if (dispatcherState != null)
            dispatcherState.handleUpEvent(param1KeyEvent); 
          if (param1KeyEvent.isTracking() && !param1KeyEvent.isCanceled()) {
            this.mSearchView.clearFocus();
            this.mSearchView.setImeVisibility(false);
            return bool;
          } 
        } 
      } 
      return super.onKeyPreIme(param1Int, param1KeyEvent);
    }
    
    public void onWindowFocusChanged(boolean param1Boolean) {
      super.onWindowFocusChanged(param1Boolean);
      if (param1Boolean && this.mSearchView.hasFocus() && getVisibility() == 0) {
        ((InputMethodManager)getContext().getSystemService("input_method")).showSoftInput((View)this, 0);
        if (SearchView.isLandscapeMode(getContext()))
          SearchView.HIDDEN_METHOD_INVOKER.ensureImeVisible(this, true); 
      } 
    }
    
    public void performCompletion() {}
    
    protected void replaceText(CharSequence param1CharSequence) {}
    
    void setSearchView(SearchView param1SearchView) {
      this.mSearchView = param1SearchView;
    }
    
    public void setThreshold(int param1Int) {
      super.setThreshold(param1Int);
      this.mThreshold = param1Int;
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/widget/SearchView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */