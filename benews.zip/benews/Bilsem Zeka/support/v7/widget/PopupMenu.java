package android.support.v7.widget;

import android.content.Context;
import android.support.v7.internal.view.SupportMenuInflater;
import android.support.v7.internal.view.menu.MenuBuilder;
import android.support.v7.internal.view.menu.MenuPopupHelper;
import android.support.v7.internal.view.menu.MenuPresenter;
import android.support.v7.internal.view.menu.SubMenuBuilder;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

public class PopupMenu implements MenuBuilder.Callback, MenuPresenter.Callback {
  private View mAnchor;
  
  private Context mContext;
  
  private OnDismissListener mDismissListener;
  
  private MenuBuilder mMenu;
  
  private OnMenuItemClickListener mMenuItemClickListener;
  
  private MenuPopupHelper mPopup;
  
  public PopupMenu(Context paramContext, View paramView) {
    this.mContext = paramContext;
    this.mMenu = new MenuBuilder(paramContext);
    this.mMenu.setCallback(this);
    this.mAnchor = paramView;
    this.mPopup = new MenuPopupHelper(paramContext, this.mMenu, paramView);
    this.mPopup.setCallback(this);
  }
  
  public void dismiss() {
    this.mPopup.dismiss();
  }
  
  public Menu getMenu() {
    return (Menu)this.mMenu;
  }
  
  public MenuInflater getMenuInflater() {
    return (MenuInflater)new SupportMenuInflater(this.mContext);
  }
  
  public void inflate(int paramInt) {
    getMenuInflater().inflate(paramInt, (Menu)this.mMenu);
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    if (this.mDismissListener != null)
      this.mDismissListener.onDismiss(this); 
  }
  
  public void onCloseSubMenu(SubMenuBuilder paramSubMenuBuilder) {}
  
  public boolean onMenuItemSelected(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem) {
    return (this.mMenuItemClickListener != null) ? this.mMenuItemClickListener.onMenuItemClick(paramMenuItem) : false;
  }
  
  public void onMenuModeChange(MenuBuilder paramMenuBuilder) {}
  
  public boolean onOpenSubMenu(MenuBuilder paramMenuBuilder) {
    boolean bool1 = true;
    if (paramMenuBuilder == null)
      return false; 
    boolean bool2 = bool1;
    if (paramMenuBuilder.hasVisibleItems()) {
      (new MenuPopupHelper(this.mContext, paramMenuBuilder, this.mAnchor)).show();
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public void setOnDismissListener(OnDismissListener paramOnDismissListener) {
    this.mDismissListener = paramOnDismissListener;
  }
  
  public void setOnMenuItemClickListener(OnMenuItemClickListener paramOnMenuItemClickListener) {
    this.mMenuItemClickListener = paramOnMenuItemClickListener;
  }
  
  public void show() {
    this.mPopup.show();
  }
  
  public static interface OnDismissListener {
    void onDismiss(PopupMenu param1PopupMenu);
  }
  
  public static interface OnMenuItemClickListener {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/widget/PopupMenu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */