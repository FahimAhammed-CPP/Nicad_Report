package android.support.v7.app;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v7.internal.view.ActionModeWrapper;
import android.support.v7.internal.view.menu.MenuWrapperFactory;
import android.support.v7.view.ActionMode;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

class ActionBarActivityDelegateICS extends ActionBarActivityDelegate {
  Menu mMenu;
  
  ActionBarActivityDelegateICS(ActionBarActivity paramActionBarActivity) {
    super(paramActionBarActivity);
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    this.mActivity.superAddContentView(paramView, paramLayoutParams);
  }
  
  ActionModeWrapper.CallbackWrapper createActionModeCallbackWrapper(Context paramContext, ActionMode.Callback paramCallback) {
    return new ActionModeWrapper.CallbackWrapper(paramContext, paramCallback);
  }
  
  ActionModeWrapper createActionModeWrapper(Context paramContext, ActionMode paramActionMode) {
    return new ActionModeWrapper(paramContext, paramActionMode);
  }
  
  public ActionBar createSupportActionBar() {
    return new ActionBarImplICS((Activity)this.mActivity, this.mActivity);
  }
  
  Window.Callback createWindowCallbackWrapper(Window.Callback paramCallback) {
    return new WindowCallbackWrapper(paramCallback);
  }
  
  int getHomeAsUpIndicatorAttrId() {
    return 16843531;
  }
  
  public void onActionModeFinished(ActionMode paramActionMode) {
    this.mActivity.onSupportActionModeFinished((ActionMode)createActionModeWrapper(getActionBarThemedContext(), paramActionMode));
  }
  
  public void onActionModeStarted(ActionMode paramActionMode) {
    this.mActivity.onSupportActionModeStarted((ActionMode)createActionModeWrapper(getActionBarThemedContext(), paramActionMode));
  }
  
  public boolean onBackPressed() {
    return false;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {}
  
  public void onContentChanged() {
    this.mActivity.onSupportContentChanged();
  }
  
  public void onCreate(Bundle paramBundle) {
    if ("splitActionBarWhenNarrow".equals(getUiOptionsFromMetadata()))
      this.mActivity.getWindow().setUiOptions(1, 1); 
    super.onCreate(paramBundle);
    if (this.mHasActionBar)
      this.mActivity.requestWindowFeature(8); 
    if (this.mOverlayActionBar)
      this.mActivity.requestWindowFeature(9); 
    Window window = this.mActivity.getWindow();
    window.setCallback(createWindowCallbackWrapper(window.getCallback()));
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    if (paramInt == 0 || paramInt == 8) {
      if (this.mMenu == null)
        this.mMenu = MenuWrapperFactory.createMenuWrapper(paramMenu); 
      return this.mActivity.superOnCreatePanelMenu(paramInt, this.mMenu);
    } 
    return this.mActivity.superOnCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreatePanelView(int paramInt) {
    return null;
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    MenuItem menuItem = paramMenuItem;
    if (paramInt == 0)
      menuItem = MenuWrapperFactory.createMenuItemWrapper(paramMenuItem); 
    return this.mActivity.superOnMenuItemSelected(paramInt, menuItem);
  }
  
  public void onPostResume() {}
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return (paramInt == 0 || paramInt == 8) ? this.mActivity.superOnPreparePanel(paramInt, paramView, this.mMenu) : this.mActivity.superOnPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onStop() {}
  
  public void onTitleChanged(CharSequence paramCharSequence) {}
  
  public void setContentView(int paramInt) {
    this.mActivity.superSetContentView(paramInt);
  }
  
  public void setContentView(View paramView) {
    this.mActivity.superSetContentView(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    this.mActivity.superSetContentView(paramView, paramLayoutParams);
  }
  
  void setSupportProgress(int paramInt) {
    this.mActivity.setProgress(paramInt);
  }
  
  void setSupportProgressBarIndeterminate(boolean paramBoolean) {
    this.mActivity.setProgressBarIndeterminate(paramBoolean);
  }
  
  void setSupportProgressBarIndeterminateVisibility(boolean paramBoolean) {
    this.mActivity.setProgressBarIndeterminateVisibility(paramBoolean);
  }
  
  void setSupportProgressBarVisibility(boolean paramBoolean) {
    this.mActivity.setProgressBarVisibility(paramBoolean);
  }
  
  public ActionMode startSupportActionMode(ActionMode.Callback paramCallback) {
    ActionModeWrapper actionModeWrapper;
    if (paramCallback == null)
      throw new IllegalArgumentException("ActionMode callback can not be null."); 
    Context context = getActionBarThemedContext();
    ActionModeWrapper.CallbackWrapper callbackWrapper = createActionModeCallbackWrapper(context, paramCallback);
    paramCallback = null;
    ActionMode actionMode = this.mActivity.startActionMode((ActionMode.Callback)callbackWrapper);
    if (actionMode != null) {
      actionModeWrapper = createActionModeWrapper(context, actionMode);
      callbackWrapper.setLastStartedActionMode(actionModeWrapper);
    } 
    return (ActionMode)actionModeWrapper;
  }
  
  public void supportInvalidateOptionsMenu() {
    this.mMenu = null;
  }
  
  public boolean supportRequestWindowFeature(int paramInt) {
    return this.mActivity.requestWindowFeature(paramInt);
  }
  
  class WindowCallbackWrapper implements Window.Callback {
    final Window.Callback mWrapped;
    
    public WindowCallbackWrapper(Window.Callback param1Callback) {
      this.mWrapped = param1Callback;
    }
    
    public boolean dispatchGenericMotionEvent(MotionEvent param1MotionEvent) {
      return this.mWrapped.dispatchGenericMotionEvent(param1MotionEvent);
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return this.mWrapped.dispatchKeyEvent(param1KeyEvent);
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return this.mWrapped.dispatchKeyShortcutEvent(param1KeyEvent);
    }
    
    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      return this.mWrapped.dispatchPopulateAccessibilityEvent(param1AccessibilityEvent);
    }
    
    public boolean dispatchTouchEvent(MotionEvent param1MotionEvent) {
      return this.mWrapped.dispatchTouchEvent(param1MotionEvent);
    }
    
    public boolean dispatchTrackballEvent(MotionEvent param1MotionEvent) {
      return this.mWrapped.dispatchTrackballEvent(param1MotionEvent);
    }
    
    public void onActionModeFinished(ActionMode param1ActionMode) {
      this.mWrapped.onActionModeFinished(param1ActionMode);
      ActionBarActivityDelegateICS.this.onActionModeFinished(param1ActionMode);
    }
    
    public void onActionModeStarted(ActionMode param1ActionMode) {
      this.mWrapped.onActionModeStarted(param1ActionMode);
      ActionBarActivityDelegateICS.this.onActionModeStarted(param1ActionMode);
    }
    
    public void onAttachedToWindow() {
      this.mWrapped.onAttachedToWindow();
    }
    
    public void onContentChanged() {
      this.mWrapped.onContentChanged();
    }
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return this.mWrapped.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public View onCreatePanelView(int param1Int) {
      return this.mWrapped.onCreatePanelView(param1Int);
    }
    
    public void onDetachedFromWindow() {
      this.mWrapped.onDetachedFromWindow();
    }
    
    public boolean onMenuItemSelected(int param1Int, MenuItem param1MenuItem) {
      return this.mWrapped.onMenuItemSelected(param1Int, param1MenuItem);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      return this.mWrapped.onMenuOpened(param1Int, param1Menu);
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      this.mWrapped.onPanelClosed(param1Int, param1Menu);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      return this.mWrapped.onPreparePanel(param1Int, param1View, param1Menu);
    }
    
    public boolean onSearchRequested() {
      return this.mWrapped.onSearchRequested();
    }
    
    public void onWindowAttributesChanged(WindowManager.LayoutParams param1LayoutParams) {
      this.mWrapped.onWindowAttributesChanged(param1LayoutParams);
    }
    
    public void onWindowFocusChanged(boolean param1Boolean) {
      this.mWrapped.onWindowFocusChanged(param1Boolean);
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return this.mWrapped.onWindowStartingActionMode(param1Callback);
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/app/ActionBarActivityDelegateICS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */