package android.support.v7.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.NavUtils;
import android.support.v4.app.TaskStackBuilder;
import android.support.v7.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

public class ActionBarActivity extends FragmentActivity implements ActionBar.Callback, TaskStackBuilder.SupportParentable, ActionBarDrawerToggle.DelegateProvider {
  ActionBarActivityDelegate mImpl;
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    this.mImpl.addContentView(paramView, paramLayoutParams);
  }
  
  public final ActionBarDrawerToggle.Delegate getDrawerToggleDelegate() {
    return this.mImpl.getDrawerToggleDelegate();
  }
  
  public MenuInflater getMenuInflater() {
    return this.mImpl.getMenuInflater();
  }
  
  public ActionBar getSupportActionBar() {
    return this.mImpl.getSupportActionBar();
  }
  
  public Intent getSupportParentActivityIntent() {
    return NavUtils.getParentActivityIntent((Activity)this);
  }
  
  public void onBackPressed() {
    if (!this.mImpl.onBackPressed())
      super.onBackPressed(); 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    this.mImpl.onConfigurationChanged(paramConfiguration);
  }
  
  public final void onContentChanged() {
    this.mImpl.onContentChanged();
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.mImpl = ActionBarActivityDelegate.createDelegate(this);
    super.onCreate(paramBundle);
    this.mImpl.onCreate(paramBundle);
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return this.mImpl.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreatePanelView(int paramInt) {
    return (paramInt == 0) ? this.mImpl.onCreatePanelView(paramInt) : super.onCreatePanelView(paramInt);
  }
  
  public void onCreateSupportNavigateUpTaskStack(TaskStackBuilder paramTaskStackBuilder) {
    paramTaskStackBuilder.addParentStack((Activity)this);
  }
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (this.mImpl.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    ActionBar actionBar = getSupportActionBar();
    return (paramMenuItem.getItemId() == 16908332 && actionBar != null && (actionBar.getDisplayOptions() & 0x4) != 0) ? onSupportNavigateUp() : false;
  }
  
  protected void onPostResume() {
    super.onPostResume();
    this.mImpl.onPostResume();
  }
  
  protected boolean onPrepareOptionsPanel(View paramView, Menu paramMenu) {
    return this.mImpl.onPrepareOptionsPanel(paramView, paramMenu);
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return this.mImpl.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onPrepareSupportNavigateUpTaskStack(TaskStackBuilder paramTaskStackBuilder) {}
  
  protected void onStop() {
    super.onStop();
    this.mImpl.onStop();
  }
  
  public void onSupportActionModeFinished(ActionMode paramActionMode) {}
  
  public void onSupportActionModeStarted(ActionMode paramActionMode) {}
  
  public void onSupportContentChanged() {}
  
  public boolean onSupportNavigateUp() {
    Intent intent = getSupportParentActivityIntent();
    if (intent != null) {
      if (supportShouldUpRecreateTask(intent)) {
        TaskStackBuilder taskStackBuilder = TaskStackBuilder.create((Context)this);
        onCreateSupportNavigateUpTaskStack(taskStackBuilder);
        onPrepareSupportNavigateUpTaskStack(taskStackBuilder);
        taskStackBuilder.startActivities();
        try {
          ActivityCompat.finishAffinity((Activity)this);
        } catch (IllegalStateException illegalStateException) {
          finish();
        } 
      } else {
        supportNavigateUpTo((Intent)illegalStateException);
      } 
      return true;
    } 
    return false;
  }
  
  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    this.mImpl.onTitleChanged(paramCharSequence);
  }
  
  public void setContentView(int paramInt) {
    this.mImpl.setContentView(paramInt);
  }
  
  public void setContentView(View paramView) {
    this.mImpl.setContentView(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    this.mImpl.setContentView(paramView, paramLayoutParams);
  }
  
  public void setSupportProgress(int paramInt) {
    this.mImpl.setSupportProgress(paramInt);
  }
  
  public void setSupportProgressBarIndeterminate(boolean paramBoolean) {
    this.mImpl.setSupportProgressBarIndeterminate(paramBoolean);
  }
  
  public void setSupportProgressBarIndeterminateVisibility(boolean paramBoolean) {
    this.mImpl.setSupportProgressBarIndeterminateVisibility(paramBoolean);
  }
  
  public void setSupportProgressBarVisibility(boolean paramBoolean) {
    this.mImpl.setSupportProgressBarVisibility(paramBoolean);
  }
  
  public ActionMode startSupportActionMode(ActionMode.Callback paramCallback) {
    return this.mImpl.startSupportActionMode(paramCallback);
  }
  
  void superAddContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    super.addContentView(paramView, paramLayoutParams);
  }
  
  boolean superOnCreatePanelMenu(int paramInt, Menu paramMenu) {
    return super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  boolean superOnMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem);
  }
  
  boolean superOnPrepareOptionsPanel(View paramView, Menu paramMenu) {
    return super.onPrepareOptionsPanel(paramView, paramMenu);
  }
  
  boolean superOnPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  void superSetContentView(int paramInt) {
    super.setContentView(paramInt);
  }
  
  void superSetContentView(View paramView) {
    super.setContentView(paramView);
  }
  
  void superSetContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    super.setContentView(paramView, paramLayoutParams);
  }
  
  public void supportInvalidateOptionsMenu() {
    if (Build.VERSION.SDK_INT >= 14)
      super.supportInvalidateOptionsMenu(); 
    this.mImpl.supportInvalidateOptionsMenu();
  }
  
  public void supportNavigateUpTo(Intent paramIntent) {
    NavUtils.navigateUpTo((Activity)this, paramIntent);
  }
  
  public boolean supportRequestWindowFeature(int paramInt) {
    return this.mImpl.supportRequestWindowFeature(paramInt);
  }
  
  public boolean supportShouldUpRecreateTask(Intent paramIntent) {
    return NavUtils.shouldUpRecreateTask((Activity)this, paramIntent);
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/app/ActionBarActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */