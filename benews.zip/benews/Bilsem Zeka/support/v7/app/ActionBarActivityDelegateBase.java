package android.support.v7.app;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.internal.view.SupportMenu;
import android.support.v7.appcompat.R;
import android.support.v7.internal.view.menu.ListMenuPresenter;
import android.support.v7.internal.view.menu.MenuBuilder;
import android.support.v7.internal.view.menu.MenuPresenter;
import android.support.v7.internal.view.menu.MenuView;
import android.support.v7.internal.view.menu.MenuWrapperFactory;
import android.support.v7.internal.widget.ActionBarContainer;
import android.support.v7.internal.widget.ActionBarContextView;
import android.support.v7.internal.widget.ActionBarView;
import android.support.v7.internal.widget.ProgressBarICS;
import android.support.v7.view.ActionMode;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;

class ActionBarActivityDelegateBase extends ActionBarActivityDelegate implements MenuPresenter.Callback, MenuBuilder.Callback {
  private static final int[] ACTION_BAR_DRAWABLE_TOGGLE_ATTRS = new int[] { R.attr.homeAsUpIndicator };
  
  private static final String TAG = "ActionBarActivityDelegateBase";
  
  private ActionBarView mActionBarView;
  
  private ActionMode mActionMode;
  
  private boolean mClosingActionMenu;
  
  private boolean mFeatureIndeterminateProgress;
  
  private boolean mFeatureProgress;
  
  private ListMenuPresenter mListMenuPresenter;
  
  private MenuBuilder mMenu;
  
  private Bundle mPanelFrozenActionViewState;
  
  private boolean mPanelIsPrepared;
  
  private boolean mPanelRefreshContent;
  
  private boolean mSubDecorInstalled;
  
  private CharSequence mTitleToSet;
  
  ActionBarActivityDelegateBase(ActionBarActivity paramActionBarActivity) {
    super(paramActionBarActivity);
  }
  
  private void applyFixedSizeWindow() {
    TypedArray typedArray = this.mActivity.obtainStyledAttributes(R.styleable.ActionBarWindow);
    TypedValue typedValue1 = null;
    TypedValue typedValue2 = null;
    TypedValue typedValue3 = null;
    TypedValue typedValue4 = null;
    TypedValue typedValue5 = null;
    TypedValue typedValue6 = null;
    TypedValue typedValue7 = null;
    TypedValue typedValue8 = null;
    if (typedArray.hasValue(3)) {
      typedValue1 = typedValue2;
      if (!false)
        typedValue1 = new TypedValue(); 
      typedArray.getValue(3, typedValue1);
    } 
    if (typedArray.hasValue(5)) {
      typedValue3 = typedValue4;
      if (!false)
        typedValue3 = new TypedValue(); 
      typedArray.getValue(5, typedValue3);
    } 
    if (typedArray.hasValue(6)) {
      typedValue5 = typedValue6;
      if (!false)
        typedValue5 = new TypedValue(); 
      typedArray.getValue(6, typedValue5);
    } 
    if (typedArray.hasValue(4)) {
      typedValue7 = typedValue8;
      if (!false)
        typedValue7 = new TypedValue(); 
      typedArray.getValue(4, typedValue7);
    } 
    DisplayMetrics displayMetrics = this.mActivity.getResources().getDisplayMetrics();
    if (displayMetrics.widthPixels < displayMetrics.heightPixels) {
      i = 1;
    } else {
      i = 0;
    } 
    byte b1 = -1;
    byte b2 = -1;
    if (i)
      typedValue1 = typedValue3; 
    int j = b1;
    if (typedValue1 != null) {
      j = b1;
      if (typedValue1.type != 0)
        if (typedValue1.type == 5) {
          j = (int)typedValue1.getDimension(displayMetrics);
        } else {
          j = b1;
          if (typedValue1.type == 6)
            j = (int)typedValue1.getFraction(displayMetrics.widthPixels, displayMetrics.widthPixels); 
        }  
    } 
    if (!i)
      typedValue5 = typedValue7; 
    int i = b2;
    if (typedValue5 != null) {
      i = b2;
      if (typedValue5.type != 0)
        if (typedValue5.type == 5) {
          i = (int)typedValue5.getDimension(displayMetrics);
        } else {
          i = b2;
          if (typedValue5.type == 6)
            i = (int)typedValue5.getFraction(displayMetrics.heightPixels, displayMetrics.heightPixels); 
        }  
    } 
    if (j != -1 || i != -1)
      this.mActivity.getWindow().setLayout(j, i); 
    typedArray.recycle();
  }
  
  private ProgressBarICS getCircularProgressBar() {
    ProgressBarICS progressBarICS = (ProgressBarICS)this.mActionBarView.findViewById(R.id.progress_circular);
    if (progressBarICS != null)
      progressBarICS.setVisibility(4); 
    return progressBarICS;
  }
  
  private ProgressBarICS getHorizontalProgressBar() {
    ProgressBarICS progressBarICS = (ProgressBarICS)this.mActionBarView.findViewById(R.id.progress_horizontal);
    if (progressBarICS != null)
      progressBarICS.setVisibility(4); 
    return progressBarICS;
  }
  
  private MenuView getListMenuView(Context paramContext, MenuPresenter.Callback paramCallback) {
    if (this.mMenu == null)
      return null; 
    if (this.mListMenuPresenter == null) {
      TypedArray typedArray = paramContext.obtainStyledAttributes(R.styleable.Theme);
      int i = typedArray.getResourceId(4, R.style.Theme_AppCompat_CompactMenu);
      typedArray.recycle();
      this.mListMenuPresenter = new ListMenuPresenter(R.layout.abc_list_menu_item_layout, i);
      this.mListMenuPresenter.setCallback(paramCallback);
      this.mMenu.addMenuPresenter((MenuPresenter)this.mListMenuPresenter);
    } else {
      this.mListMenuPresenter.updateMenuView(false);
    } 
    return this.mListMenuPresenter.getMenuView((ViewGroup)new FrameLayout(paramContext));
  }
  
  private void hideProgressBars(ProgressBarICS paramProgressBarICS1, ProgressBarICS paramProgressBarICS2) {
    if (this.mFeatureIndeterminateProgress && paramProgressBarICS2.getVisibility() == 0)
      paramProgressBarICS2.setVisibility(4); 
    if (this.mFeatureProgress && paramProgressBarICS1.getVisibility() == 0)
      paramProgressBarICS1.setVisibility(4); 
  }
  
  private boolean initializePanelMenu() {
    this.mMenu = new MenuBuilder(getActionBarThemedContext());
    this.mMenu.setCallback(this);
    return true;
  }
  
  private boolean preparePanel() {
    boolean bool = true;
    if (!this.mPanelIsPrepared) {
      if (this.mMenu == null || this.mPanelRefreshContent) {
        if (this.mMenu == null && (!initializePanelMenu() || this.mMenu == null))
          return false; 
        if (this.mActionBarView != null)
          this.mActionBarView.setMenu((SupportMenu)this.mMenu, this); 
        this.mMenu.stopDispatchingItemsChanged();
        if (!this.mActivity.superOnCreatePanelMenu(0, (Menu)this.mMenu)) {
          this.mMenu = null;
          if (this.mActionBarView != null)
            this.mActionBarView.setMenu(null, this); 
          return false;
        } 
        this.mPanelRefreshContent = false;
      } 
      this.mMenu.stopDispatchingItemsChanged();
      if (this.mPanelFrozenActionViewState != null) {
        this.mMenu.restoreActionViewStates(this.mPanelFrozenActionViewState);
        this.mPanelFrozenActionViewState = null;
      } 
      if (!this.mActivity.superOnPreparePanel(0, (View)null, (Menu)this.mMenu)) {
        if (this.mActionBarView != null)
          this.mActionBarView.setMenu(null, this); 
        this.mMenu.startDispatchingItemsChanged();
        return false;
      } 
      this.mMenu.startDispatchingItemsChanged();
      this.mPanelIsPrepared = true;
    } 
    return bool;
  }
  
  private void reopenMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    if (this.mActionBarView != null && this.mActionBarView.isOverflowReserved()) {
      if (!this.mActionBarView.isOverflowMenuShowing() || !paramBoolean) {
        if (this.mActionBarView.getVisibility() == 0)
          this.mActionBarView.showOverflowMenu(); 
        return;
      } 
      this.mActionBarView.hideOverflowMenu();
      return;
    } 
    paramMenuBuilder.close();
  }
  
  private void showProgressBars(ProgressBarICS paramProgressBarICS1, ProgressBarICS paramProgressBarICS2) {
    if (this.mFeatureIndeterminateProgress && paramProgressBarICS2.getVisibility() == 4)
      paramProgressBarICS2.setVisibility(0); 
    if (this.mFeatureProgress && paramProgressBarICS1.getProgress() < 10000)
      paramProgressBarICS1.setVisibility(0); 
  }
  
  private void updateProgressBars(int paramInt) {
    ProgressBarICS progressBarICS1 = getCircularProgressBar();
    ProgressBarICS progressBarICS2 = getHorizontalProgressBar();
    if (paramInt == -1) {
      if (this.mFeatureProgress) {
        paramInt = progressBarICS2.getProgress();
        if (progressBarICS2.isIndeterminate() || paramInt < 10000) {
          paramInt = 0;
        } else {
          paramInt = 4;
        } 
        progressBarICS2.setVisibility(paramInt);
      } 
      if (this.mFeatureIndeterminateProgress)
        progressBarICS1.setVisibility(0); 
      return;
    } 
    if (paramInt == -2) {
      if (this.mFeatureProgress)
        progressBarICS2.setVisibility(8); 
      if (this.mFeatureIndeterminateProgress)
        progressBarICS1.setVisibility(8); 
      return;
    } 
    if (paramInt == -3) {
      progressBarICS2.setIndeterminate(true);
      return;
    } 
    if (paramInt == -4) {
      progressBarICS2.setIndeterminate(false);
      return;
    } 
    if (paramInt >= 0 && paramInt <= 10000) {
      progressBarICS2.setProgress(paramInt + 0);
      if (paramInt < 10000) {
        showProgressBars(progressBarICS2, progressBarICS1);
        return;
      } 
      hideProgressBars(progressBarICS2, progressBarICS1);
    } 
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    ensureSubDecor();
    ((ViewGroup)this.mActivity.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.mActivity.onSupportContentChanged();
  }
  
  public ActionBar createSupportActionBar() {
    ensureSubDecor();
    return new ActionBarImplBase(this.mActivity, this.mActivity);
  }
  
  final void ensureSubDecor() {
    if (!this.mSubDecorInstalled) {
      if (this.mHasActionBar) {
        boolean bool2;
        if (this.mOverlayActionBar) {
          this.mActivity.superSetContentView(R.layout.abc_action_bar_decor_overlay);
        } else {
          this.mActivity.superSetContentView(R.layout.abc_action_bar_decor);
        } 
        this.mActionBarView = (ActionBarView)this.mActivity.findViewById(R.id.action_bar);
        this.mActionBarView.setWindowCallback((Window.Callback)this.mActivity);
        if (this.mFeatureProgress)
          this.mActionBarView.initProgress(); 
        if (this.mFeatureIndeterminateProgress)
          this.mActionBarView.initIndeterminateProgress(); 
        boolean bool1 = "splitActionBarWhenNarrow".equals(getUiOptionsFromMetadata());
        if (bool1) {
          bool2 = this.mActivity.getResources().getBoolean(R.bool.abc_split_action_bar_is_narrow);
        } else {
          TypedArray typedArray = this.mActivity.obtainStyledAttributes(R.styleable.ActionBarWindow);
          bool2 = typedArray.getBoolean(2, false);
          typedArray.recycle();
        } 
        ActionBarContainer actionBarContainer = (ActionBarContainer)this.mActivity.findViewById(R.id.split_action_bar);
        if (actionBarContainer != null) {
          this.mActionBarView.setSplitView(actionBarContainer);
          this.mActionBarView.setSplitActionBar(bool2);
          this.mActionBarView.setSplitWhenNarrow(bool1);
          ActionBarContextView actionBarContextView = (ActionBarContextView)this.mActivity.findViewById(R.id.action_context_bar);
          actionBarContextView.setSplitView(actionBarContainer);
          actionBarContextView.setSplitActionBar(bool2);
          actionBarContextView.setSplitWhenNarrow(bool1);
        } 
      } else {
        this.mActivity.superSetContentView(R.layout.abc_simple_decor);
      } 
      this.mActivity.findViewById(16908290).setId(-1);
      this.mActivity.findViewById(R.id.action_bar_activity_content).setId(16908290);
      if (this.mTitleToSet != null) {
        this.mActionBarView.setWindowTitle(this.mTitleToSet);
        this.mTitleToSet = null;
      } 
      applyFixedSizeWindow();
      this.mSubDecorInstalled = true;
      this.mActivity.getWindow().getDecorView().post(new Runnable() {
            public void run() {
              ActionBarActivityDelegateBase.this.supportInvalidateOptionsMenu();
            }
          });
    } 
  }
  
  int getHomeAsUpIndicatorAttrId() {
    return R.attr.homeAsUpIndicator;
  }
  
  public boolean onBackPressed() {
    null = true;
    if (this.mActionMode != null) {
      this.mActionMode.finish();
      return null;
    } 
    if (this.mActionBarView != null && this.mActionBarView.hasExpandedActionView()) {
      this.mActionBarView.collapseActionView();
      return null;
    } 
    return false;
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    if (!this.mClosingActionMenu) {
      this.mClosingActionMenu = true;
      this.mActivity.closeOptionsMenu();
      this.mActionBarView.dismissPopupMenus();
      this.mClosingActionMenu = false;
    } 
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    if (this.mHasActionBar && this.mSubDecorInstalled)
      ((ActionBarImplBase)getSupportActionBar()).onConfigurationChanged(paramConfiguration); 
  }
  
  public void onContentChanged() {}
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return (paramInt != 0) ? this.mActivity.superOnCreatePanelMenu(paramInt, paramMenu) : false;
  }
  
  public View onCreatePanelView(int paramInt) {
    View view1 = null;
    View view2 = view1;
    if (paramInt == 0) {
      view2 = view1;
      if (preparePanel())
        view2 = (View)getListMenuView((Context)this.mActivity, this); 
    } 
    return view2;
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    MenuItem menuItem = paramMenuItem;
    if (paramInt == 0)
      menuItem = MenuWrapperFactory.createMenuItemWrapper(paramMenuItem); 
    return this.mActivity.superOnMenuItemSelected(paramInt, menuItem);
  }
  
  public boolean onMenuItemSelected(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem) {
    return this.mActivity.onMenuItemSelected(0, paramMenuItem);
  }
  
  public void onMenuModeChange(MenuBuilder paramMenuBuilder) {
    reopenMenu(paramMenuBuilder, true);
  }
  
  public boolean onOpenSubMenu(MenuBuilder paramMenuBuilder) {
    return false;
  }
  
  public void onPostResume() {
    ActionBarImplBase actionBarImplBase = (ActionBarImplBase)getSupportActionBar();
    if (actionBarImplBase != null)
      actionBarImplBase.setShowHideAnimationEnabled(true); 
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return (paramInt != 0) ? this.mActivity.superOnPreparePanel(paramInt, paramView, paramMenu) : false;
  }
  
  public void onStop() {
    ActionBarImplBase actionBarImplBase = (ActionBarImplBase)getSupportActionBar();
    if (actionBarImplBase != null)
      actionBarImplBase.setShowHideAnimationEnabled(false); 
  }
  
  public void onTitleChanged(CharSequence paramCharSequence) {
    if (this.mActionBarView != null) {
      this.mActionBarView.setWindowTitle(paramCharSequence);
      return;
    } 
    this.mTitleToSet = paramCharSequence;
  }
  
  public void setContentView(int paramInt) {
    ensureSubDecor();
    ViewGroup viewGroup = (ViewGroup)this.mActivity.findViewById(16908290);
    viewGroup.removeAllViews();
    this.mActivity.getLayoutInflater().inflate(paramInt, viewGroup);
    this.mActivity.onSupportContentChanged();
  }
  
  public void setContentView(View paramView) {
    ensureSubDecor();
    ViewGroup viewGroup = (ViewGroup)this.mActivity.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.mActivity.onSupportContentChanged();
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    ensureSubDecor();
    ViewGroup viewGroup = (ViewGroup)this.mActivity.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.mActivity.onSupportContentChanged();
  }
  
  void setSupportProgress(int paramInt) {
    updateProgressBars(paramInt + 0);
  }
  
  void setSupportProgressBarIndeterminate(boolean paramBoolean) {
    byte b;
    if (paramBoolean) {
      b = -3;
    } else {
      b = -4;
    } 
    updateProgressBars(b);
  }
  
  void setSupportProgressBarIndeterminateVisibility(boolean paramBoolean) {
    byte b;
    if (paramBoolean) {
      b = -1;
    } else {
      b = -2;
    } 
    updateProgressBars(b);
  }
  
  void setSupportProgressBarVisibility(boolean paramBoolean) {
    byte b;
    if (paramBoolean) {
      b = -1;
    } else {
      b = -2;
    } 
    updateProgressBars(b);
  }
  
  public ActionMode startSupportActionMode(ActionMode.Callback paramCallback) {
    if (paramCallback == null)
      throw new IllegalArgumentException("ActionMode callback can not be null."); 
    if (this.mActionMode != null)
      this.mActionMode.finish(); 
    ActionModeCallbackWrapper actionModeCallbackWrapper = new ActionModeCallbackWrapper(paramCallback);
    ActionBarImplBase actionBarImplBase = (ActionBarImplBase)getSupportActionBar();
    if (actionBarImplBase != null)
      this.mActionMode = actionBarImplBase.startActionMode(actionModeCallbackWrapper); 
    if (this.mActionMode != null)
      this.mActivity.onSupportActionModeStarted(this.mActionMode); 
    return this.mActionMode;
  }
  
  public void supportInvalidateOptionsMenu() {
    if (this.mMenu != null) {
      Bundle bundle = new Bundle();
      this.mMenu.saveActionViewStates(bundle);
      if (bundle.size() > 0)
        this.mPanelFrozenActionViewState = bundle; 
      this.mMenu.stopDispatchingItemsChanged();
      this.mMenu.clear();
    } 
    this.mPanelRefreshContent = true;
    if (this.mActionBarView != null) {
      this.mPanelIsPrepared = false;
      preparePanel();
    } 
  }
  
  public boolean supportRequestWindowFeature(int paramInt) {
    null = true;
    switch (paramInt) {
      default:
        return this.mActivity.requestWindowFeature(paramInt);
      case 8:
        this.mHasActionBar = true;
        return SYNTHETIC_LOCAL_VARIABLE_2;
      case 9:
        this.mOverlayActionBar = true;
        return SYNTHETIC_LOCAL_VARIABLE_2;
      case 2:
        this.mFeatureProgress = true;
        return SYNTHETIC_LOCAL_VARIABLE_2;
      case 5:
        break;
    } 
    this.mFeatureIndeterminateProgress = true;
    return SYNTHETIC_LOCAL_VARIABLE_2;
  }
  
  private class ActionModeCallbackWrapper implements ActionMode.Callback {
    private ActionMode.Callback mWrapped;
    
    public ActionModeCallbackWrapper(ActionMode.Callback param1Callback) {
      this.mWrapped = param1Callback;
    }
    
    public boolean onActionItemClicked(ActionMode param1ActionMode, MenuItem param1MenuItem) {
      return this.mWrapped.onActionItemClicked(param1ActionMode, param1MenuItem);
    }
    
    public boolean onCreateActionMode(ActionMode param1ActionMode, Menu param1Menu) {
      return this.mWrapped.onCreateActionMode(param1ActionMode, param1Menu);
    }
    
    public void onDestroyActionMode(ActionMode param1ActionMode) {
      this.mWrapped.onDestroyActionMode(param1ActionMode);
      ActionBarActivityDelegateBase.this.mActivity.onSupportActionModeFinished(param1ActionMode);
      ActionBarActivityDelegateBase.access$002(ActionBarActivityDelegateBase.this, (ActionMode)null);
    }
    
    public boolean onPrepareActionMode(ActionMode param1ActionMode, Menu param1Menu) {
      return this.mWrapped.onPrepareActionMode(param1ActionMode, param1Menu);
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/app/ActionBarActivityDelegateBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */