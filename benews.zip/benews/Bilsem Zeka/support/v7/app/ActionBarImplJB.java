package android.support.v7.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.SpinnerAdapter;

public class ActionBarImplJB extends ActionBarImplICS {
  public ActionBarImplJB(Activity paramActivity, ActionBar.Callback paramCallback) {
    super(paramActivity, paramCallback, false);
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/app/ActionBarImplJB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */