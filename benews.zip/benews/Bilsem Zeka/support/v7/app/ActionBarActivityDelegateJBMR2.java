package android.support.v7.app;

import android.app.Activity;

class ActionBarActivityDelegateJBMR2 extends ActionBarActivityDelegateJB {
  ActionBarActivityDelegateJBMR2(ActionBarActivity paramActionBarActivity) {
    super(paramActionBarActivity);
  }
  
  public ActionBar createSupportActionBar() {
    return new ActionBarImplJBMR2((Activity)this.mActivity, this.mActivity);
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/app/ActionBarActivityDelegateJBMR2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */