package android.support.v7.app;

import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.appcompat.R;
import android.support.v7.internal.view.ActionBarPolicy;
import android.support.v7.internal.view.SupportMenuInflater;
import android.support.v7.internal.view.menu.MenuBuilder;
import android.support.v7.internal.view.menu.SubMenuBuilder;
import android.support.v7.internal.widget.ActionBarContainer;
import android.support.v7.internal.widget.ActionBarContextView;
import android.support.v7.internal.widget.ActionBarOverlayLayout;
import android.support.v7.internal.widget.ActionBarView;
import android.support.v7.internal.widget.ScrollingTabContainerView;
import android.support.v7.view.ActionMode;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.SpinnerAdapter;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

class ActionBarImplBase extends ActionBar {
  private static final int CONTEXT_DISPLAY_NORMAL = 0;
  
  private static final int CONTEXT_DISPLAY_SPLIT = 1;
  
  private static final int INVALID_POSITION = -1;
  
  ActionModeImpl mActionMode;
  
  private ActionBarView mActionView;
  
  private ActionBarActivity mActivity;
  
  private ActionBar.Callback mCallback;
  
  private ActionBarContainer mContainerView;
  
  private View mContentView;
  
  private Context mContext;
  
  private int mContextDisplayMode;
  
  private ActionBarContextView mContextView;
  
  private int mCurWindowVisibility = 0;
  
  ActionMode mDeferredDestroyActionMode;
  
  ActionMode.Callback mDeferredModeDestroyCallback;
  
  private Dialog mDialog;
  
  private boolean mDisplayHomeAsUpSet;
  
  final Handler mHandler = new Handler();
  
  private boolean mHasEmbeddedTabs;
  
  private boolean mHiddenByApp;
  
  private boolean mHiddenBySystem;
  
  private boolean mLastMenuVisibility;
  
  private ArrayList<ActionBar.OnMenuVisibilityListener> mMenuVisibilityListeners = new ArrayList<ActionBar.OnMenuVisibilityListener>();
  
  private boolean mNowShowing = true;
  
  private ActionBarOverlayLayout mOverlayLayout;
  
  private int mSavedTabPosition = -1;
  
  private TabImpl mSelectedTab;
  
  private boolean mShowHideAnimationEnabled;
  
  private boolean mShowingForMode;
  
  private ActionBarContainer mSplitView;
  
  private ScrollingTabContainerView mTabScrollView;
  
  Runnable mTabSelector;
  
  private ArrayList<TabImpl> mTabs = new ArrayList<TabImpl>();
  
  private Context mThemedContext;
  
  private ViewGroup mTopVisibilityView;
  
  public ActionBarImplBase(ActionBarActivity paramActionBarActivity, ActionBar.Callback paramCallback) {
    this.mActivity = paramActionBarActivity;
    this.mContext = (Context)paramActionBarActivity;
    this.mCallback = paramCallback;
    init(this.mActivity);
  }
  
  private static boolean checkShowingFlags(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    boolean bool = true;
    if (paramBoolean3)
      return bool; 
    if (!paramBoolean1) {
      paramBoolean1 = bool;
      return paramBoolean2 ? false : paramBoolean1;
    } 
    return false;
  }
  
  private void cleanupTabs() {
    if (this.mSelectedTab != null)
      selectTab(null); 
    this.mTabs.clear();
    if (this.mTabScrollView != null)
      this.mTabScrollView.removeAllTabs(); 
    this.mSavedTabPosition = -1;
  }
  
  private void configureTab(ActionBar.Tab paramTab, int paramInt) {
    paramTab = paramTab;
    if (paramTab.getCallback() == null)
      throw new IllegalStateException("Action Bar Tab must have a Callback"); 
    paramTab.setPosition(paramInt);
    this.mTabs.add(paramInt, paramTab);
    int i = this.mTabs.size();
    while (++paramInt < i) {
      ((TabImpl)this.mTabs.get(paramInt)).setPosition(paramInt);
      paramInt++;
    } 
  }
  
  private void ensureTabsExist() {
    if (this.mTabScrollView == null) {
      ScrollingTabContainerView scrollingTabContainerView = new ScrollingTabContainerView(this.mContext);
      if (this.mHasEmbeddedTabs) {
        scrollingTabContainerView.setVisibility(0);
        this.mActionView.setEmbeddedTabView(scrollingTabContainerView);
      } else {
        if (getNavigationMode() == 2) {
          scrollingTabContainerView.setVisibility(0);
        } else {
          scrollingTabContainerView.setVisibility(8);
        } 
        this.mContainerView.setTabContainer(scrollingTabContainerView);
      } 
      this.mTabScrollView = scrollingTabContainerView;
    } 
  }
  
  private void init(ActionBarActivity paramActionBarActivity) {
    boolean bool2;
    boolean bool1 = false;
    this.mOverlayLayout = (ActionBarOverlayLayout)paramActionBarActivity.findViewById(R.id.action_bar_overlay_layout);
    if (this.mOverlayLayout != null)
      this.mOverlayLayout.setActionBar(this); 
    this.mActionView = (ActionBarView)paramActionBarActivity.findViewById(R.id.action_bar);
    this.mContextView = (ActionBarContextView)paramActionBarActivity.findViewById(R.id.action_context_bar);
    this.mContainerView = (ActionBarContainer)paramActionBarActivity.findViewById(R.id.action_bar_container);
    this.mTopVisibilityView = (ViewGroup)paramActionBarActivity.findViewById(R.id.top_action_bar);
    if (this.mTopVisibilityView == null)
      this.mTopVisibilityView = (ViewGroup)this.mContainerView; 
    this.mSplitView = (ActionBarContainer)paramActionBarActivity.findViewById(R.id.split_action_bar);
    if (this.mActionView == null || this.mContextView == null || this.mContainerView == null)
      throw new IllegalStateException(getClass().getSimpleName() + " can only be used " + "with a compatible window decor layout"); 
    this.mActionView.setContextView(this.mContextView);
    if (this.mActionView.isSplitActionBar()) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    this.mContextDisplayMode = bool2;
    if ((this.mActionView.getDisplayOptions() & 0x4) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool2)
      this.mDisplayHomeAsUpSet = true; 
    ActionBarPolicy actionBarPolicy = ActionBarPolicy.get(this.mContext);
    if (actionBarPolicy.enableHomeButtonByDefault() || bool2)
      bool1 = true; 
    setHomeButtonEnabled(bool1);
    setHasEmbeddedTabs(actionBarPolicy.hasEmbeddedTabs());
    setTitle(this.mActivity.getTitle());
  }
  
  private void setHasEmbeddedTabs(boolean paramBoolean) {
    boolean bool2;
    boolean bool1 = true;
    this.mHasEmbeddedTabs = paramBoolean;
    if (!this.mHasEmbeddedTabs) {
      this.mActionView.setEmbeddedTabView(null);
      this.mContainerView.setTabContainer(this.mTabScrollView);
    } else {
      this.mContainerView.setTabContainer(null);
      this.mActionView.setEmbeddedTabView(this.mTabScrollView);
    } 
    if (getNavigationMode() == 2) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (this.mTabScrollView != null)
      if (bool2) {
        this.mTabScrollView.setVisibility(0);
      } else {
        this.mTabScrollView.setVisibility(8);
      }  
    ActionBarView actionBarView = this.mActionView;
    if (!this.mHasEmbeddedTabs && bool2) {
      paramBoolean = bool1;
    } else {
      paramBoolean = false;
    } 
    actionBarView.setCollapsable(paramBoolean);
  }
  
  private void updateVisibility(boolean paramBoolean) {
    if (checkShowingFlags(this.mHiddenByApp, this.mHiddenBySystem, this.mShowingForMode)) {
      if (!this.mNowShowing) {
        this.mNowShowing = true;
        doShow(paramBoolean);
      } 
      return;
    } 
    if (this.mNowShowing) {
      this.mNowShowing = false;
      doHide(paramBoolean);
    } 
  }
  
  public void addOnMenuVisibilityListener(ActionBar.OnMenuVisibilityListener paramOnMenuVisibilityListener) {
    this.mMenuVisibilityListeners.add(paramOnMenuVisibilityListener);
  }
  
  public void addTab(ActionBar.Tab paramTab) {
    addTab(paramTab, this.mTabs.isEmpty());
  }
  
  public void addTab(ActionBar.Tab paramTab, int paramInt) {
    addTab(paramTab, paramInt, this.mTabs.isEmpty());
  }
  
  public void addTab(ActionBar.Tab paramTab, int paramInt, boolean paramBoolean) {
    ensureTabsExist();
    this.mTabScrollView.addTab(paramTab, paramInt, paramBoolean);
    configureTab(paramTab, paramInt);
    if (paramBoolean)
      selectTab(paramTab); 
  }
  
  public void addTab(ActionBar.Tab paramTab, boolean paramBoolean) {
    ensureTabsExist();
    this.mTabScrollView.addTab(paramTab, paramBoolean);
    configureTab(paramTab, this.mTabs.size());
    if (paramBoolean)
      selectTab(paramTab); 
  }
  
  void animateToMode(boolean paramBoolean) {
    byte b2;
    byte b1 = 8;
    if (paramBoolean) {
      showForActionMode();
    } else {
      hideForActionMode();
    } 
    ActionBarView actionBarView = this.mActionView;
    if (paramBoolean) {
      b2 = 4;
    } else {
      b2 = 0;
    } 
    actionBarView.animateToVisibility(b2);
    ActionBarContextView actionBarContextView = this.mContextView;
    if (paramBoolean) {
      b2 = 0;
    } else {
      b2 = 8;
    } 
    actionBarContextView.animateToVisibility(b2);
    if (this.mTabScrollView != null && !this.mActionView.hasEmbeddedTabs() && this.mActionView.isCollapsed()) {
      ScrollingTabContainerView scrollingTabContainerView = this.mTabScrollView;
      if (paramBoolean) {
        b2 = b1;
      } else {
        b2 = 0;
      } 
      scrollingTabContainerView.setVisibility(b2);
    } 
  }
  
  public void doHide(boolean paramBoolean) {
    this.mTopVisibilityView.clearAnimation();
    if (this.mTopVisibilityView.getVisibility() != 8) {
      boolean bool;
      if (isShowHideAnimationEnabled() || paramBoolean) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        Animation animation = AnimationUtils.loadAnimation(this.mContext, R.anim.abc_slide_out_top);
        this.mTopVisibilityView.startAnimation(animation);
      } 
      this.mTopVisibilityView.setVisibility(8);
      if (this.mSplitView != null && this.mSplitView.getVisibility() != 8) {
        if (bool) {
          Animation animation = AnimationUtils.loadAnimation(this.mContext, R.anim.abc_slide_out_bottom);
          this.mSplitView.startAnimation(animation);
        } 
        this.mSplitView.setVisibility(8);
      } 
    } 
  }
  
  public void doShow(boolean paramBoolean) {
    this.mTopVisibilityView.clearAnimation();
    if (this.mTopVisibilityView.getVisibility() != 0) {
      boolean bool;
      if (isShowHideAnimationEnabled() || paramBoolean) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        Animation animation = AnimationUtils.loadAnimation(this.mContext, R.anim.abc_slide_in_top);
        this.mTopVisibilityView.startAnimation(animation);
      } 
      this.mTopVisibilityView.setVisibility(0);
      if (this.mSplitView != null && this.mSplitView.getVisibility() != 0) {
        if (bool) {
          Animation animation = AnimationUtils.loadAnimation(this.mContext, R.anim.abc_slide_in_bottom);
          this.mSplitView.startAnimation(animation);
        } 
        this.mSplitView.setVisibility(0);
      } 
    } 
  }
  
  public View getCustomView() {
    return this.mActionView.getCustomNavigationView();
  }
  
  public int getDisplayOptions() {
    return this.mActionView.getDisplayOptions();
  }
  
  public int getHeight() {
    return this.mContainerView.getHeight();
  }
  
  public int getNavigationItemCount() {
    int i = 0;
    switch (this.mActionView.getNavigationMode()) {
      default:
        return i;
      case 2:
        i = this.mTabs.size();
      case 1:
        break;
    } 
    SpinnerAdapter spinnerAdapter = this.mActionView.getDropdownAdapter();
    if (spinnerAdapter != null)
      i = spinnerAdapter.getCount(); 
  }
  
  public int getNavigationMode() {
    return this.mActionView.getNavigationMode();
  }
  
  public int getSelectedNavigationIndex() {
    int i = -1;
    switch (this.mActionView.getNavigationMode()) {
      default:
        return i;
      case 2:
        if (this.mSelectedTab != null)
          i = this.mSelectedTab.getPosition(); 
      case 1:
        break;
    } 
    i = this.mActionView.getDropdownSelectedPosition();
  }
  
  public ActionBar.Tab getSelectedTab() {
    return this.mSelectedTab;
  }
  
  public CharSequence getSubtitle() {
    return this.mActionView.getSubtitle();
  }
  
  public ActionBar.Tab getTabAt(int paramInt) {
    return this.mTabs.get(paramInt);
  }
  
  public int getTabCount() {
    return this.mTabs.size();
  }
  
  public Context getThemedContext() {
    if (this.mThemedContext == null) {
      TypedValue typedValue = new TypedValue();
      this.mContext.getTheme().resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0) {
        this.mThemedContext = (Context)new ContextThemeWrapper(this.mContext, i);
        return this.mThemedContext;
      } 
    } else {
      return this.mThemedContext;
    } 
    this.mThemedContext = this.mContext;
    return this.mThemedContext;
  }
  
  public CharSequence getTitle() {
    return this.mActionView.getTitle();
  }
  
  public boolean hasNonEmbeddedTabs() {
    return (!this.mHasEmbeddedTabs && getNavigationMode() == 2);
  }
  
  public void hide() {
    if (!this.mHiddenByApp) {
      this.mHiddenByApp = true;
      updateVisibility(false);
    } 
  }
  
  void hideForActionMode() {
    if (this.mShowingForMode) {
      this.mShowingForMode = false;
      updateVisibility(false);
    } 
  }
  
  boolean isShowHideAnimationEnabled() {
    return this.mShowHideAnimationEnabled;
  }
  
  public boolean isShowing() {
    return this.mNowShowing;
  }
  
  public ActionBar.Tab newTab() {
    return new TabImpl();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    setHasEmbeddedTabs(ActionBarPolicy.get(this.mContext).hasEmbeddedTabs());
  }
  
  public void removeAllTabs() {
    cleanupTabs();
  }
  
  public void removeOnMenuVisibilityListener(ActionBar.OnMenuVisibilityListener paramOnMenuVisibilityListener) {
    this.mMenuVisibilityListeners.remove(paramOnMenuVisibilityListener);
  }
  
  public void removeTab(ActionBar.Tab paramTab) {
    removeTabAt(paramTab.getPosition());
  }
  
  public void removeTabAt(int paramInt) {
    if (this.mTabScrollView != null) {
      int i;
      if (this.mSelectedTab != null) {
        i = this.mSelectedTab.getPosition();
      } else {
        i = this.mSavedTabPosition;
      } 
      this.mTabScrollView.removeTabAt(paramInt);
      TabImpl tabImpl = this.mTabs.remove(paramInt);
      if (tabImpl != null)
        tabImpl.setPosition(-1); 
      int j = this.mTabs.size();
      for (int k = paramInt; k < j; k++)
        ((TabImpl)this.mTabs.get(k)).setPosition(k); 
      if (i == paramInt) {
        if (this.mTabs.isEmpty()) {
          tabImpl = null;
        } else {
          tabImpl = this.mTabs.get(Math.max(0, paramInt - 1));
        } 
        selectTab(tabImpl);
      } 
    } 
  }
  
  public void selectTab(ActionBar.Tab paramTab) {
    int i = -1;
    if (getNavigationMode() != 2) {
      if (paramTab != null)
        i = paramTab.getPosition(); 
      this.mSavedTabPosition = i;
      return;
    } 
    FragmentTransaction fragmentTransaction = this.mActivity.getSupportFragmentManager().beginTransaction().disallowAddToBackStack();
    if (this.mSelectedTab == paramTab) {
      if (this.mSelectedTab != null) {
        this.mSelectedTab.getCallback().onTabReselected(this.mSelectedTab, fragmentTransaction);
        this.mTabScrollView.animateToTab(paramTab.getPosition());
      } 
    } else {
      ScrollingTabContainerView scrollingTabContainerView = this.mTabScrollView;
      if (paramTab != null)
        i = paramTab.getPosition(); 
      scrollingTabContainerView.setTabSelected(i);
      if (this.mSelectedTab != null)
        this.mSelectedTab.getCallback().onTabUnselected(this.mSelectedTab, fragmentTransaction); 
      this.mSelectedTab = (TabImpl)paramTab;
      if (this.mSelectedTab != null)
        this.mSelectedTab.getCallback().onTabSelected(this.mSelectedTab, fragmentTransaction); 
    } 
    if (!fragmentTransaction.isEmpty())
      fragmentTransaction.commit(); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    this.mContainerView.setPrimaryBackground(paramDrawable);
  }
  
  public void setCustomView(int paramInt) {
    setCustomView(LayoutInflater.from(getThemedContext()).inflate(paramInt, (ViewGroup)this.mActionView, false));
  }
  
  public void setCustomView(View paramView) {
    this.mActionView.setCustomNavigationView(paramView);
  }
  
  public void setCustomView(View paramView, ActionBar.LayoutParams paramLayoutParams) {
    paramView.setLayoutParams((ViewGroup.LayoutParams)paramLayoutParams);
    this.mActionView.setCustomNavigationView(paramView);
  }
  
  public void setDisplayHomeAsUpEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 4);
  }
  
  public void setDisplayOptions(int paramInt) {
    if ((paramInt & 0x4) != 0)
      this.mDisplayHomeAsUpSet = true; 
    this.mActionView.setDisplayOptions(paramInt);
  }
  
  public void setDisplayOptions(int paramInt1, int paramInt2) {
    int i = this.mActionView.getDisplayOptions();
    if ((paramInt2 & 0x4) != 0)
      this.mDisplayHomeAsUpSet = true; 
    this.mActionView.setDisplayOptions(paramInt1 & paramInt2 | (paramInt2 ^ 0xFFFFFFFF) & i);
  }
  
  public void setDisplayShowCustomEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 16);
  }
  
  public void setDisplayShowHomeEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 2);
  }
  
  public void setDisplayShowTitleEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 8);
  }
  
  public void setDisplayUseLogoEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 1);
  }
  
  public void setHomeAsUpIndicator(int paramInt) {
    this.mActionView.setHomeAsUpIndicator(paramInt);
  }
  
  public void setHomeAsUpIndicator(Drawable paramDrawable) {
    this.mActionView.setHomeAsUpIndicator(paramDrawable);
  }
  
  public void setHomeButtonEnabled(boolean paramBoolean) {
    this.mActionView.setHomeButtonEnabled(paramBoolean);
  }
  
  public void setIcon(int paramInt) {
    this.mActionView.setIcon(paramInt);
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.mActionView.setIcon(paramDrawable);
  }
  
  public void setListNavigationCallbacks(SpinnerAdapter paramSpinnerAdapter, ActionBar.OnNavigationListener paramOnNavigationListener) {
    this.mActionView.setDropdownAdapter(paramSpinnerAdapter);
    this.mActionView.setCallback(paramOnNavigationListener);
  }
  
  public void setLogo(int paramInt) {
    this.mActionView.setLogo(paramInt);
  }
  
  public void setLogo(Drawable paramDrawable) {
    this.mActionView.setLogo(paramDrawable);
  }
  
  public void setNavigationMode(int paramInt) {
    ActionBarView actionBarView;
    boolean bool2;
    boolean bool1 = false;
    switch (this.mActionView.getNavigationMode()) {
      default:
        this.mActionView.setNavigationMode(paramInt);
        switch (paramInt) {
          default:
            actionBarView = this.mActionView;
            bool2 = bool1;
            if (paramInt == 2) {
              bool2 = bool1;
              if (!this.mHasEmbeddedTabs)
                bool2 = true; 
            } 
            actionBarView.setCollapsable(bool2);
            return;
          case 2:
            break;
        } 
        break;
      case 2:
        this.mSavedTabPosition = getSelectedNavigationIndex();
        selectTab(null);
        this.mTabScrollView.setVisibility(8);
    } 
    ensureTabsExist();
    this.mTabScrollView.setVisibility(0);
    if (this.mSavedTabPosition != -1) {
      setSelectedNavigationItem(this.mSavedTabPosition);
      this.mSavedTabPosition = -1;
    } 
  }
  
  public void setSelectedNavigationItem(int paramInt) {
    switch (this.mActionView.getNavigationMode()) {
      default:
        throw new IllegalStateException("setSelectedNavigationIndex not valid for current navigation mode");
      case 2:
        selectTab(this.mTabs.get(paramInt));
        return;
      case 1:
        break;
    } 
    this.mActionView.setDropdownSelectedPosition(paramInt);
  }
  
  public void setShowHideAnimationEnabled(boolean paramBoolean) {
    this.mShowHideAnimationEnabled = paramBoolean;
    if (!paramBoolean) {
      this.mTopVisibilityView.clearAnimation();
      if (this.mSplitView != null)
        this.mSplitView.clearAnimation(); 
    } 
  }
  
  public void setSplitBackgroundDrawable(Drawable paramDrawable) {
    this.mContainerView.setSplitBackground(paramDrawable);
  }
  
  public void setStackedBackgroundDrawable(Drawable paramDrawable) {
    this.mContainerView.setStackedBackground(paramDrawable);
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(this.mContext.getString(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.mActionView.setSubtitle(paramCharSequence);
  }
  
  public void setTitle(int paramInt) {
    setTitle(this.mContext.getString(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.mActionView.setTitle(paramCharSequence);
  }
  
  public void show() {
    if (this.mHiddenByApp) {
      this.mHiddenByApp = false;
      updateVisibility(false);
    } 
  }
  
  void showForActionMode() {
    if (!this.mShowingForMode) {
      this.mShowingForMode = true;
      updateVisibility(false);
    } 
  }
  
  public ActionMode startActionMode(ActionMode.Callback paramCallback) {
    if (this.mActionMode != null)
      this.mActionMode.finish(); 
    this.mContextView.killMode();
    null = new ActionModeImpl(paramCallback);
    if (null.dispatchOnCreate()) {
      null.invalidate();
      this.mContextView.initForMode(null);
      animateToMode(true);
      if (this.mSplitView != null && this.mContextDisplayMode == 1 && this.mSplitView.getVisibility() != 0)
        this.mSplitView.setVisibility(0); 
      this.mContextView.sendAccessibilityEvent(32);
      this.mActionMode = null;
      return null;
    } 
    return null;
  }
  
  class ActionModeImpl extends ActionMode implements MenuBuilder.Callback {
    private ActionMode.Callback mCallback;
    
    private WeakReference<View> mCustomView;
    
    private MenuBuilder mMenu;
    
    public ActionModeImpl(ActionMode.Callback param1Callback) {
      this.mCallback = param1Callback;
      this.mMenu = (new MenuBuilder(ActionBarImplBase.this.getThemedContext())).setDefaultShowAsAction(1);
      this.mMenu.setCallback(this);
    }
    
    public boolean dispatchOnCreate() {
      this.mMenu.stopDispatchingItemsChanged();
      try {
        return this.mCallback.onCreateActionMode(this, (Menu)this.mMenu);
      } finally {
        this.mMenu.startDispatchingItemsChanged();
      } 
    }
    
    public void finish() {
      if (ActionBarImplBase.this.mActionMode == this) {
        if (!ActionBarImplBase.checkShowingFlags(ActionBarImplBase.this.mHiddenByApp, ActionBarImplBase.this.mHiddenBySystem, false)) {
          ActionBarImplBase.this.mDeferredDestroyActionMode = this;
          ActionBarImplBase.this.mDeferredModeDestroyCallback = this.mCallback;
        } else {
          this.mCallback.onDestroyActionMode(this);
        } 
        this.mCallback = null;
        ActionBarImplBase.this.animateToMode(false);
        ActionBarImplBase.this.mContextView.closeMode();
        ActionBarImplBase.this.mActionView.sendAccessibilityEvent(32);
        ActionBarImplBase.this.mActionMode = null;
      } 
    }
    
    public View getCustomView() {
      return (this.mCustomView != null) ? this.mCustomView.get() : null;
    }
    
    public Menu getMenu() {
      return (Menu)this.mMenu;
    }
    
    public MenuInflater getMenuInflater() {
      return (MenuInflater)new SupportMenuInflater(ActionBarImplBase.this.getThemedContext());
    }
    
    public CharSequence getSubtitle() {
      return ActionBarImplBase.this.mContextView.getSubtitle();
    }
    
    public CharSequence getTitle() {
      return ActionBarImplBase.this.mContextView.getTitle();
    }
    
    public void invalidate() {
      this.mMenu.stopDispatchingItemsChanged();
      try {
        this.mCallback.onPrepareActionMode(this, (Menu)this.mMenu);
        return;
      } finally {
        this.mMenu.startDispatchingItemsChanged();
      } 
    }
    
    public boolean isTitleOptional() {
      return ActionBarImplBase.this.mContextView.isTitleOptional();
    }
    
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {}
    
    public void onCloseSubMenu(SubMenuBuilder param1SubMenuBuilder) {}
    
    public boolean onMenuItemSelected(MenuBuilder param1MenuBuilder, MenuItem param1MenuItem) {
      return (this.mCallback != null) ? this.mCallback.onActionItemClicked(this, param1MenuItem) : false;
    }
    
    public void onMenuModeChange(MenuBuilder param1MenuBuilder) {
      if (this.mCallback != null) {
        invalidate();
        ActionBarImplBase.this.mContextView.showOverflowMenu();
      } 
    }
    
    public void onMenuModeChange(Menu param1Menu) {
      if (this.mCallback != null) {
        invalidate();
        ActionBarImplBase.this.mContextView.showOverflowMenu();
      } 
    }
    
    public boolean onSubMenuSelected(SubMenuBuilder param1SubMenuBuilder) {
      boolean bool1 = true;
      if (this.mCallback == null)
        return false; 
      boolean bool2 = bool1;
      if (!param1SubMenuBuilder.hasVisibleItems())
        bool2 = bool1; 
      return bool2;
    }
    
    public void setCustomView(View param1View) {
      ActionBarImplBase.this.mContextView.setCustomView(param1View);
      this.mCustomView = new WeakReference<View>(param1View);
    }
    
    public void setSubtitle(int param1Int) {
      setSubtitle(ActionBarImplBase.this.mContext.getResources().getString(param1Int));
    }
    
    public void setSubtitle(CharSequence param1CharSequence) {
      ActionBarImplBase.this.mContextView.setSubtitle(param1CharSequence);
    }
    
    public void setTitle(int param1Int) {
      setTitle(ActionBarImplBase.this.mContext.getResources().getString(param1Int));
    }
    
    public void setTitle(CharSequence param1CharSequence) {
      ActionBarImplBase.this.mContextView.setTitle(param1CharSequence);
    }
    
    public void setTitleOptionalHint(boolean param1Boolean) {
      super.setTitleOptionalHint(param1Boolean);
      ActionBarImplBase.this.mContextView.setTitleOptional(param1Boolean);
    }
  }
  
  public class TabImpl extends ActionBar.Tab {
    private ActionBar.TabListener mCallback;
    
    private CharSequence mContentDesc;
    
    private View mCustomView;
    
    private Drawable mIcon;
    
    private int mPosition = -1;
    
    private Object mTag;
    
    private CharSequence mText;
    
    public ActionBar.TabListener getCallback() {
      return this.mCallback;
    }
    
    public CharSequence getContentDescription() {
      return this.mContentDesc;
    }
    
    public View getCustomView() {
      return this.mCustomView;
    }
    
    public Drawable getIcon() {
      return this.mIcon;
    }
    
    public int getPosition() {
      return this.mPosition;
    }
    
    public Object getTag() {
      return this.mTag;
    }
    
    public CharSequence getText() {
      return this.mText;
    }
    
    public void select() {
      ActionBarImplBase.this.selectTab(this);
    }
    
    public ActionBar.Tab setContentDescription(int param1Int) {
      return setContentDescription(ActionBarImplBase.this.mContext.getResources().getText(param1Int));
    }
    
    public ActionBar.Tab setContentDescription(CharSequence param1CharSequence) {
      this.mContentDesc = param1CharSequence;
      if (this.mPosition >= 0)
        ActionBarImplBase.this.mTabScrollView.updateTab(this.mPosition); 
      return this;
    }
    
    public ActionBar.Tab setCustomView(int param1Int) {
      return setCustomView(LayoutInflater.from(ActionBarImplBase.this.getThemedContext()).inflate(param1Int, null));
    }
    
    public ActionBar.Tab setCustomView(View param1View) {
      this.mCustomView = param1View;
      if (this.mPosition >= 0)
        ActionBarImplBase.this.mTabScrollView.updateTab(this.mPosition); 
      return this;
    }
    
    public ActionBar.Tab setIcon(int param1Int) {
      return setIcon(ActionBarImplBase.this.mContext.getResources().getDrawable(param1Int));
    }
    
    public ActionBar.Tab setIcon(Drawable param1Drawable) {
      this.mIcon = param1Drawable;
      if (this.mPosition >= 0)
        ActionBarImplBase.this.mTabScrollView.updateTab(this.mPosition); 
      return this;
    }
    
    public void setPosition(int param1Int) {
      this.mPosition = param1Int;
    }
    
    public ActionBar.Tab setTabListener(ActionBar.TabListener param1TabListener) {
      this.mCallback = param1TabListener;
      return this;
    }
    
    public ActionBar.Tab setTag(Object param1Object) {
      this.mTag = param1Object;
      return this;
    }
    
    public ActionBar.Tab setText(int param1Int) {
      return setText(ActionBarImplBase.this.mContext.getResources().getText(param1Int));
    }
    
    public ActionBar.Tab setText(CharSequence param1CharSequence) {
      this.mText = param1CharSequence;
      if (this.mPosition >= 0)
        ActionBarImplBase.this.mTabScrollView.updateTab(this.mPosition); 
      return this;
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/app/ActionBarImplBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */