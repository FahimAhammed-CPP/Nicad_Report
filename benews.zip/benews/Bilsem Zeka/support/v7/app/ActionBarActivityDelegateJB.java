package android.support.v7.app;

import android.app.Activity;
import android.content.Context;
import android.support.v7.internal.view.ActionModeWrapper;
import android.support.v7.internal.view.ActionModeWrapperJB;
import android.support.v7.view.ActionMode;
import android.view.ActionMode;

class ActionBarActivityDelegateJB extends ActionBarActivityDelegateICS {
  ActionBarActivityDelegateJB(ActionBarActivity paramActionBarActivity) {
    super(paramActionBarActivity);
  }
  
  ActionModeWrapper.CallbackWrapper createActionModeCallbackWrapper(Context paramContext, ActionMode.Callback paramCallback) {
    return (ActionModeWrapper.CallbackWrapper)new ActionModeWrapperJB.CallbackWrapper(paramContext, paramCallback);
  }
  
  ActionModeWrapper createActionModeWrapper(Context paramContext, ActionMode paramActionMode) {
    return (ActionModeWrapper)new ActionModeWrapperJB(paramContext, paramActionMode);
  }
  
  public ActionBar createSupportActionBar() {
    return new ActionBarImplJB((Activity)this.mActivity, this.mActivity);
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/app/ActionBarActivityDelegateJB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */