package android.support.v7.app;

import android.app.ActionBar;
import android.app.Activity;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.v4.app.FragmentTransaction;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SpinnerAdapter;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

class ActionBarImplICS extends ActionBar {
  final ActionBar mActionBar;
  
  FragmentTransaction mActiveTransaction;
  
  final Activity mActivity;
  
  private ArrayList<WeakReference<OnMenuVisibilityListenerWrapper>> mAddedMenuVisWrappers = new ArrayList<WeakReference<OnMenuVisibilityListenerWrapper>>();
  
  final ActionBar.Callback mCallback;
  
  private ImageView mHomeActionView;
  
  public ActionBarImplICS(Activity paramActivity, ActionBar.Callback paramCallback) {
    this(paramActivity, paramCallback, true);
  }
  
  ActionBarImplICS(Activity paramActivity, ActionBar.Callback paramCallback, boolean paramBoolean) {
    this.mActivity = paramActivity;
    this.mCallback = paramCallback;
    this.mActionBar = paramActivity.getActionBar();
    if (paramBoolean && (getDisplayOptions() & 0x4) != 0)
      setHomeButtonEnabled(true); 
  }
  
  private OnMenuVisibilityListenerWrapper findAndRemoveMenuVisWrapper(ActionBar.OnMenuVisibilityListener paramOnMenuVisibilityListener) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: iload_2
    //   3: aload_0
    //   4: getfield mAddedMenuVisWrappers : Ljava/util/ArrayList;
    //   7: invokevirtual size : ()I
    //   10: if_icmpge -> 81
    //   13: aload_0
    //   14: getfield mAddedMenuVisWrappers : Ljava/util/ArrayList;
    //   17: iload_2
    //   18: invokevirtual get : (I)Ljava/lang/Object;
    //   21: checkcast java/lang/ref/WeakReference
    //   24: invokevirtual get : ()Ljava/lang/Object;
    //   27: checkcast android/support/v7/app/ActionBarImplICS$OnMenuVisibilityListenerWrapper
    //   30: astore_3
    //   31: aload_3
    //   32: ifnonnull -> 57
    //   35: aload_0
    //   36: getfield mAddedMenuVisWrappers : Ljava/util/ArrayList;
    //   39: iload_2
    //   40: invokevirtual remove : (I)Ljava/lang/Object;
    //   43: pop
    //   44: iload_2
    //   45: iconst_1
    //   46: isub
    //   47: istore #4
    //   49: iload #4
    //   51: iconst_1
    //   52: iadd
    //   53: istore_2
    //   54: goto -> 2
    //   57: iload_2
    //   58: istore #4
    //   60: aload_3
    //   61: getfield mWrappedListener : Landroid/support/v7/app/ActionBar$OnMenuVisibilityListener;
    //   64: aload_1
    //   65: if_acmpne -> 49
    //   68: aload_0
    //   69: getfield mAddedMenuVisWrappers : Ljava/util/ArrayList;
    //   72: iload_2
    //   73: invokevirtual remove : (I)Ljava/lang/Object;
    //   76: pop
    //   77: aload_3
    //   78: astore_1
    //   79: aload_1
    //   80: areturn
    //   81: aconst_null
    //   82: astore_1
    //   83: goto -> 79
  }
  
  public void addOnMenuVisibilityListener(ActionBar.OnMenuVisibilityListener paramOnMenuVisibilityListener) {
    if (paramOnMenuVisibilityListener != null) {
      OnMenuVisibilityListenerWrapper onMenuVisibilityListenerWrapper = new OnMenuVisibilityListenerWrapper(paramOnMenuVisibilityListener);
      this.mAddedMenuVisWrappers.add(new WeakReference<OnMenuVisibilityListenerWrapper>(onMenuVisibilityListenerWrapper));
      this.mActionBar.addOnMenuVisibilityListener(onMenuVisibilityListenerWrapper);
    } 
  }
  
  public void addTab(ActionBar.Tab paramTab) {
    this.mActionBar.addTab(((TabWrapper)paramTab).mWrappedTab);
  }
  
  public void addTab(ActionBar.Tab paramTab, int paramInt) {
    this.mActionBar.addTab(((TabWrapper)paramTab).mWrappedTab, paramInt);
  }
  
  public void addTab(ActionBar.Tab paramTab, int paramInt, boolean paramBoolean) {
    this.mActionBar.addTab(((TabWrapper)paramTab).mWrappedTab, paramInt, paramBoolean);
  }
  
  public void addTab(ActionBar.Tab paramTab, boolean paramBoolean) {
    this.mActionBar.addTab(((TabWrapper)paramTab).mWrappedTab, paramBoolean);
  }
  
  void commitActiveTransaction() {
    if (this.mActiveTransaction != null && !this.mActiveTransaction.isEmpty())
      this.mActiveTransaction.commit(); 
    this.mActiveTransaction = null;
  }
  
  FragmentTransaction getActiveTransaction() {
    if (this.mActiveTransaction == null)
      this.mActiveTransaction = this.mCallback.getSupportFragmentManager().beginTransaction().disallowAddToBackStack(); 
    return this.mActiveTransaction;
  }
  
  public View getCustomView() {
    return this.mActionBar.getCustomView();
  }
  
  public int getDisplayOptions() {
    return this.mActionBar.getDisplayOptions();
  }
  
  public int getHeight() {
    return this.mActionBar.getHeight();
  }
  
  ImageView getHomeActionView() {
    null = null;
    if (this.mHomeActionView == null) {
      View view1;
      View view2 = this.mActivity.findViewById(16908332);
      if (view2 == null)
        return null; 
      ViewGroup viewGroup = (ViewGroup)view2.getParent();
      if (viewGroup.getChildCount() == 2) {
        view1 = viewGroup.getChildAt(0);
        View view = viewGroup.getChildAt(1);
        if (view1.getId() == 16908332)
          view1 = view; 
        if (view1 instanceof ImageView)
          this.mHomeActionView = (ImageView)view1; 
      } else {
        return (ImageView)view1;
      } 
    } 
    return this.mHomeActionView;
  }
  
  public int getNavigationItemCount() {
    return this.mActionBar.getNavigationItemCount();
  }
  
  public int getNavigationMode() {
    return this.mActionBar.getNavigationMode();
  }
  
  public int getSelectedNavigationIndex() {
    return this.mActionBar.getSelectedNavigationIndex();
  }
  
  public ActionBar.Tab getSelectedTab() {
    return (ActionBar.Tab)this.mActionBar.getSelectedTab().getTag();
  }
  
  public CharSequence getSubtitle() {
    return this.mActionBar.getSubtitle();
  }
  
  public ActionBar.Tab getTabAt(int paramInt) {
    return (ActionBar.Tab)this.mActionBar.getTabAt(paramInt).getTag();
  }
  
  public int getTabCount() {
    return this.mActionBar.getTabCount();
  }
  
  Drawable getThemeDefaultUpIndicator() {
    TypedArray typedArray = this.mActivity.obtainStyledAttributes(new int[] { 16843531 });
    Drawable drawable = typedArray.getDrawable(0);
    typedArray.recycle();
    return drawable;
  }
  
  public Context getThemedContext() {
    return this.mActionBar.getThemedContext();
  }
  
  public CharSequence getTitle() {
    return this.mActionBar.getTitle();
  }
  
  public void hide() {
    this.mActionBar.hide();
  }
  
  public boolean isShowing() {
    return this.mActionBar.isShowing();
  }
  
  public ActionBar.Tab newTab() {
    ActionBar.Tab tab = this.mActionBar.newTab();
    TabWrapper tabWrapper = new TabWrapper(tab);
    tab.setTag(tabWrapper);
    return tabWrapper;
  }
  
  public void removeAllTabs() {
    this.mActionBar.removeAllTabs();
  }
  
  public void removeOnMenuVisibilityListener(ActionBar.OnMenuVisibilityListener paramOnMenuVisibilityListener) {
    OnMenuVisibilityListenerWrapper onMenuVisibilityListenerWrapper = findAndRemoveMenuVisWrapper(paramOnMenuVisibilityListener);
    this.mActionBar.removeOnMenuVisibilityListener(onMenuVisibilityListenerWrapper);
  }
  
  public void removeTab(ActionBar.Tab paramTab) {
    this.mActionBar.removeTab(((TabWrapper)paramTab).mWrappedTab);
  }
  
  public void removeTabAt(int paramInt) {
    this.mActionBar.removeTabAt(paramInt);
  }
  
  public void selectTab(ActionBar.Tab paramTab) {
    this.mActionBar.selectTab(((TabWrapper)paramTab).mWrappedTab);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    this.mActionBar.setBackgroundDrawable(paramDrawable);
  }
  
  public void setCustomView(int paramInt) {
    this.mActionBar.setCustomView(paramInt);
  }
  
  public void setCustomView(View paramView) {
    this.mActionBar.setCustomView(paramView);
  }
  
  public void setCustomView(View paramView, ActionBar.LayoutParams paramLayoutParams) {
    ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams((ViewGroup.LayoutParams)paramLayoutParams);
    layoutParams.gravity = paramLayoutParams.gravity;
    this.mActionBar.setCustomView(paramView, layoutParams);
  }
  
  public void setDisplayHomeAsUpEnabled(boolean paramBoolean) {
    this.mActionBar.setDisplayHomeAsUpEnabled(paramBoolean);
  }
  
  public void setDisplayOptions(int paramInt) {
    this.mActionBar.setDisplayOptions(paramInt);
  }
  
  public void setDisplayOptions(int paramInt1, int paramInt2) {
    this.mActionBar.setDisplayOptions(paramInt1, paramInt2);
  }
  
  public void setDisplayShowCustomEnabled(boolean paramBoolean) {
    this.mActionBar.setDisplayShowCustomEnabled(paramBoolean);
  }
  
  public void setDisplayShowHomeEnabled(boolean paramBoolean) {
    this.mActionBar.setDisplayShowHomeEnabled(paramBoolean);
  }
  
  public void setDisplayShowTitleEnabled(boolean paramBoolean) {
    this.mActionBar.setDisplayShowTitleEnabled(paramBoolean);
  }
  
  public void setDisplayUseLogoEnabled(boolean paramBoolean) {
    this.mActionBar.setDisplayUseLogoEnabled(paramBoolean);
  }
  
  public void setHomeAsUpIndicator(int paramInt) {
    ImageView imageView = getHomeActionView();
    if (imageView != null) {
      if (paramInt != 0) {
        imageView.setImageResource(paramInt);
        return;
      } 
    } else {
      return;
    } 
    imageView.setImageDrawable(getThemeDefaultUpIndicator());
  }
  
  public void setHomeAsUpIndicator(Drawable paramDrawable) {
    ImageView imageView = getHomeActionView();
    if (imageView != null) {
      Drawable drawable = paramDrawable;
      if (paramDrawable == null)
        drawable = getThemeDefaultUpIndicator(); 
      imageView.setImageDrawable(drawable);
    } 
  }
  
  public void setHomeButtonEnabled(boolean paramBoolean) {
    this.mActionBar.setHomeButtonEnabled(paramBoolean);
  }
  
  public void setIcon(int paramInt) {
    this.mActionBar.setIcon(paramInt);
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.mActionBar.setIcon(paramDrawable);
  }
  
  public void setListNavigationCallbacks(SpinnerAdapter paramSpinnerAdapter, ActionBar.OnNavigationListener paramOnNavigationListener) {
    ActionBar actionBar = this.mActionBar;
    if (paramOnNavigationListener != null) {
      OnNavigationListenerWrapper onNavigationListenerWrapper = new OnNavigationListenerWrapper(paramOnNavigationListener);
    } else {
      paramOnNavigationListener = null;
    } 
    actionBar.setListNavigationCallbacks(paramSpinnerAdapter, (ActionBar.OnNavigationListener)paramOnNavigationListener);
  }
  
  public void setLogo(int paramInt) {
    this.mActionBar.setLogo(paramInt);
  }
  
  public void setLogo(Drawable paramDrawable) {
    this.mActionBar.setLogo(paramDrawable);
  }
  
  public void setNavigationMode(int paramInt) {
    this.mActionBar.setNavigationMode(paramInt);
  }
  
  public void setSelectedNavigationItem(int paramInt) {
    this.mActionBar.setSelectedNavigationItem(paramInt);
  }
  
  public void setSplitBackgroundDrawable(Drawable paramDrawable) {
    this.mActionBar.setSplitBackgroundDrawable(paramDrawable);
  }
  
  public void setStackedBackgroundDrawable(Drawable paramDrawable) {
    this.mActionBar.setStackedBackgroundDrawable(paramDrawable);
  }
  
  public void setSubtitle(int paramInt) {
    this.mActionBar.setSubtitle(paramInt);
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.mActionBar.setSubtitle(paramCharSequence);
  }
  
  public void setTitle(int paramInt) {
    this.mActionBar.setTitle(paramInt);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.mActionBar.setTitle(paramCharSequence);
  }
  
  public void show() {
    this.mActionBar.show();
  }
  
  static class OnMenuVisibilityListenerWrapper implements ActionBar.OnMenuVisibilityListener {
    final ActionBar.OnMenuVisibilityListener mWrappedListener;
    
    public OnMenuVisibilityListenerWrapper(ActionBar.OnMenuVisibilityListener param1OnMenuVisibilityListener) {
      this.mWrappedListener = param1OnMenuVisibilityListener;
    }
    
    public void onMenuVisibilityChanged(boolean param1Boolean) {
      this.mWrappedListener.onMenuVisibilityChanged(param1Boolean);
    }
  }
  
  static class OnNavigationListenerWrapper implements ActionBar.OnNavigationListener {
    private final ActionBar.OnNavigationListener mWrappedListener;
    
    public OnNavigationListenerWrapper(ActionBar.OnNavigationListener param1OnNavigationListener) {
      this.mWrappedListener = param1OnNavigationListener;
    }
    
    public boolean onNavigationItemSelected(int param1Int, long param1Long) {
      return this.mWrappedListener.onNavigationItemSelected(param1Int, param1Long);
    }
  }
  
  class TabWrapper extends ActionBar.Tab implements ActionBar.TabListener {
    private CharSequence mContentDescription;
    
    private ActionBar.TabListener mTabListener;
    
    private Object mTag;
    
    final ActionBar.Tab mWrappedTab;
    
    public TabWrapper(ActionBar.Tab param1Tab) {
      this.mWrappedTab = param1Tab;
    }
    
    public CharSequence getContentDescription() {
      return this.mContentDescription;
    }
    
    public View getCustomView() {
      return this.mWrappedTab.getCustomView();
    }
    
    public Drawable getIcon() {
      return this.mWrappedTab.getIcon();
    }
    
    public int getPosition() {
      return this.mWrappedTab.getPosition();
    }
    
    public Object getTag() {
      return this.mTag;
    }
    
    public CharSequence getText() {
      return this.mWrappedTab.getText();
    }
    
    public void onTabReselected(ActionBar.Tab param1Tab, FragmentTransaction param1FragmentTransaction) {
      ActionBar.TabListener tabListener = this.mTabListener;
      if (param1FragmentTransaction != null) {
        FragmentTransaction fragmentTransaction = ActionBarImplICS.this.getActiveTransaction();
      } else {
        param1Tab = null;
      } 
      tabListener.onTabReselected(this, (FragmentTransaction)param1Tab);
      ActionBarImplICS.this.commitActiveTransaction();
    }
    
    public void onTabSelected(ActionBar.Tab param1Tab, FragmentTransaction param1FragmentTransaction) {
      ActionBar.TabListener tabListener = this.mTabListener;
      if (param1FragmentTransaction != null) {
        FragmentTransaction fragmentTransaction = ActionBarImplICS.this.getActiveTransaction();
      } else {
        param1Tab = null;
      } 
      tabListener.onTabSelected(this, (FragmentTransaction)param1Tab);
      ActionBarImplICS.this.commitActiveTransaction();
    }
    
    public void onTabUnselected(ActionBar.Tab param1Tab, FragmentTransaction param1FragmentTransaction) {
      ActionBar.TabListener tabListener = this.mTabListener;
      if (param1FragmentTransaction != null) {
        FragmentTransaction fragmentTransaction = ActionBarImplICS.this.getActiveTransaction();
      } else {
        param1Tab = null;
      } 
      tabListener.onTabUnselected(this, (FragmentTransaction)param1Tab);
    }
    
    public void select() {
      this.mWrappedTab.select();
    }
    
    public ActionBar.Tab setContentDescription(int param1Int) {
      this.mContentDescription = ActionBarImplICS.this.mActivity.getText(param1Int);
      return this;
    }
    
    public ActionBar.Tab setContentDescription(CharSequence param1CharSequence) {
      this.mContentDescription = param1CharSequence;
      return this;
    }
    
    public ActionBar.Tab setCustomView(int param1Int) {
      this.mWrappedTab.setCustomView(param1Int);
      return this;
    }
    
    public ActionBar.Tab setCustomView(View param1View) {
      this.mWrappedTab.setCustomView(param1View);
      return this;
    }
    
    public ActionBar.Tab setIcon(int param1Int) {
      this.mWrappedTab.setIcon(param1Int);
      return this;
    }
    
    public ActionBar.Tab setIcon(Drawable param1Drawable) {
      this.mWrappedTab.setIcon(param1Drawable);
      return this;
    }
    
    public ActionBar.Tab setTabListener(ActionBar.TabListener param1TabListener) {
      this.mTabListener = param1TabListener;
      ActionBar.Tab tab = this.mWrappedTab;
      if (param1TabListener != null) {
        TabWrapper tabWrapper = this;
        tab.setTabListener(tabWrapper);
        return this;
      } 
      param1TabListener = null;
      tab.setTabListener((ActionBar.TabListener)param1TabListener);
      return this;
    }
    
    public ActionBar.Tab setTag(Object param1Object) {
      this.mTag = param1Object;
      return this;
    }
    
    public ActionBar.Tab setText(int param1Int) {
      this.mWrappedTab.setText(param1Int);
      return this;
    }
    
    public ActionBar.Tab setText(CharSequence param1CharSequence) {
      this.mWrappedTab.setText(param1CharSequence);
      return this;
    }
  }
}


/* Location:              /home/fahim/Desktop/benews-dex2jar.jar!/android/support/v7/app/ActionBarImplICS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */