package android.app.job;

import android.annotation.NonNull;
import android.os.Parcelable;
import android.os.PersistableBundle;



/* Location:              C:\soft\dex2jar-2.0\Checkers-dex2jar.jar!\android\app\job\JobParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */