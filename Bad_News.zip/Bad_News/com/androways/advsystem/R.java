package com.androways.advsystem;

public final class R {
  public static final class attr {}
  
  public static final class drawable {
    public static final int ic_launcher = 2130837504;
  }
  
  public static final class layout {
    public static final int main = 2130903040;
  }
  
  public static final class string {
    public static final int app_name = 2130968577;
    
    public static final int hello = 2130968576;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/com/androways/advsystem/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */