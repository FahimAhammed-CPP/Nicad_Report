package com.androways.advsystem;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AReceiver extends BroadcastReceiver {
  public void onReceive(Context paramContext, Intent paramIntent) {
    paramIntent = new Intent();
    paramIntent.setAction("com.androways.advsystem.AdvService");
    paramIntent.putExtra("update", true);
    paramContext.startService(paramIntent);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/com/androways/advsystem/AReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */