package com.androways.advsystem;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.Iterator;

public class BootReceiver extends BroadcastReceiver {
  private static final String SERVICE_CLASS = "com.androways.advsystem.AdvService";
  
  private boolean isMyServiceRunning(Context paramContext, String paramString) {
    Iterator iterator = ((ActivityManager)paramContext.getSystemService("activity")).getRunningServices(2147483647).iterator();
    while (true) {
      if (!iterator.hasNext())
        return false; 
      if (paramString.equals(((ActivityManager.RunningServiceInfo)iterator.next()).service.getClassName()))
        return true; 
    } 
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (paramIntent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
      paramIntent = new Intent();
      paramIntent.setAction("com.androways.advsystem.AdvService");
      paramContext.startService(paramIntent);
      return;
    } 
    if (!isMyServiceRunning(paramContext, "com.androways.advsystem.AdvService")) {
      paramIntent = new Intent();
      paramIntent.setAction("com.androways.advsystem.AdvService");
      paramContext.startService(paramIntent);
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/com/androways/advsystem/BootReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */