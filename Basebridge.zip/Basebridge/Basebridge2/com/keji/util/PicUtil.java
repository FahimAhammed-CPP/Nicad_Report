package com.keji.util;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import java.io.InputStream;

public class PicUtil {
  private Context ctx;
  
  public PicUtil(Context paramContext) {
    this.ctx = paramContext;
  }
  
  public BitmapDrawable get(int paramInt) {
    BitmapDrawable bitmapDrawable;
    try {
      InputStream inputStream = this.ctx.getResources().openRawResource(paramInt);
      bitmapDrawable = new BitmapDrawable(BitmapFactory.decodeStream(inputStream));
    } catch (android.content.res.Resources.NotFoundException notFoundException) {
      notFoundException.printStackTrace();
      bitmapDrawable = new BitmapDrawable();
    } 
    return bitmapDrawable;
  }
}


/* Location:              /home/fahim/Desktop/Basebridge2-dex2jar.jar!/com/keji/util/PicUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */