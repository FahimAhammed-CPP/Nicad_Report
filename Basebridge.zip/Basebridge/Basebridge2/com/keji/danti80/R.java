package com.keji.danti80;

public final class R {
  public static final class attr {}
  
  public static final class drawable {
    public static final int icon = 2130837504;
  }
  
  public static final class id {
    public static final int gallery = 2131099650;
    
    public static final int l = 2131099648;
    
    public static final int switcher = 2131099649;
  }
  
  public static final class layout {
    public static final int main2 = 2130903040;
  }
  
  public static final class raw {
    public static final int p1 = 2130968576;
    
    public static final int p10 = 2130968577;
    
    public static final int p11 = 2130968578;
    
    public static final int p12 = 2130968579;
    
    public static final int p13 = 2130968580;
    
    public static final int p14 = 2130968581;
    
    public static final int p15 = 2130968582;
    
    public static final int p16 = 2130968583;
    
    public static final int p17 = 2130968584;
    
    public static final int p18 = 2130968585;
    
    public static final int p19 = 2130968586;
    
    public static final int p2 = 2130968587;
    
    public static final int p20 = 2130968588;
    
    public static final int p21 = 2130968589;
    
    public static final int p22 = 2130968590;
    
    public static final int p23 = 2130968591;
    
    public static final int p24 = 2130968592;
    
    public static final int p25 = 2130968593;
    
    public static final int p26 = 2130968594;
    
    public static final int p27 = 2130968595;
    
    public static final int p28 = 2130968596;
    
    public static final int p29 = 2130968597;
    
    public static final int p3 = 2130968598;
    
    public static final int p30 = 2130968599;
    
    public static final int p31 = 2130968600;
    
    public static final int p32 = 2130968601;
    
    public static final int p33 = 2130968602;
    
    public static final int p34 = 2130968603;
    
    public static final int p35 = 2130968604;
    
    public static final int p36 = 2130968605;
    
    public static final int p37 = 2130968606;
    
    public static final int p38 = 2130968607;
    
    public static final int p39 = 2130968608;
    
    public static final int p4 = 2130968609;
    
    public static final int p40 = 2130968610;
    
    public static final int p41 = 2130968611;
    
    public static final int p42 = 2130968612;
    
    public static final int p43 = 2130968613;
    
    public static final int p5 = 2130968614;
    
    public static final int p6 = 2130968615;
    
    public static final int p7 = 2130968616;
    
    public static final int p8 = 2130968617;
    
    public static final int p9 = 2130968618;
  }
  
  public static final class string {
    public static final int app_about = 2131034118;
    
    public static final int app_about_msg = 2131034117;
    
    public static final int app_name = 2131034113;
    
    public static final int hello = 2131034112;
    
    public static final int jieshao = 2131034119;
    
    public static final int my_text_no = 2131034116;
    
    public static final int my_text_pre = 2131034115;
    
    public static final int setting = 2131034114;
    
    public static final int str_no = 2131034121;
    
    public static final int str_ok = 2131034120;
  }
}


/* Location:              /home/fahim/Desktop/Basebridge2-dex2jar.jar!/com/keji/danti80/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */