package com.keji.danti80;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.Gallery;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.SpinnerAdapter;
import android.widget.Toast;
import android.widget.ViewSwitcher;
import com.keji.util.PicUtil;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class Background<ResultActivity> extends BaseAActivity implements AdapterView.OnItemSelectedListener, ViewSwitcher.ViewFactory {
  protected static Drawable HippoDrawable;
  
  PicUtil imageGet;
  
  private Context mContext;
  
  private ImageSwitcher mSwitcher;
  
  private int nowid = this.startId;
  
  private int piclength = 29;
  
  private int startId = 2130968576;
  
  private File temp;
  
  private void loadTemp(int paramInt) {
    try {
      InputStream inputStream = getResources().openRawResource(paramInt);
      FileOutputStream fileOutputStream = openFileOutput("atemp.jpg", 1);
      byte[] arrayOfByte = new byte[inputStream.available()];
      inputStream.read(arrayOfByte);
      fileOutputStream.write(arrayOfByte);
      fileOutputStream.close();
      inputStream.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public View makeView() {
    ImageView imageView = new ImageView((Context)this);
    imageView.setBackgroundColor(-16777216);
    imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
    imageView.setLayoutParams((ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-1, -1));
    return (View)imageView;
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (paramInt1 == 123) {
      Bundle bundle = paramIntent.getExtras();
      if (bundle != null) {
        Bitmap bitmap = (Bitmap)bundle.get("data");
        try {
          setWallpaper(bitmap);
        } catch (IOException iOException) {
          iOException.printStackTrace();
        } 
        deleteFile("atemp.jpg");
      } 
    } 
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public void onCreate(Bundle paramBundle) {
    this.imageGet = new PicUtil((Context)this);
    this.temp = new File("/data/data/" + getPackageName() + "/files/atemp.jpg");
    super.onCreate(paramBundle);
    initData(getClass().getName());
    requestWindowFeature(1);
    getWindow().setFlags(1024, 1024);
    setContentView(2130903040);
    Toast.makeText((Context)this, 2131034119, 1).show();
    this.mSwitcher = (ImageSwitcher)findViewById(2131099649);
    this.mSwitcher.setFactory(this);
    this.mSwitcher.setInAnimation(AnimationUtils.loadAnimation((Context)this, 17432576));
    this.mSwitcher.setOutAnimation(AnimationUtils.loadAnimation((Context)this, 17432577));
    this.mSwitcher.setOnLongClickListener(new View.OnLongClickListener() {
          public boolean onLongClick(View param1View) {
            (new AlertDialog.Builder((Context)Background.this)).setTitle(2131034118).setMessage(2131034117).setPositiveButton(2131034120, new DialogInterface.OnClickListener() {
                  public void onClick(DialogInterface param2DialogInterface, int param2Int) {
                    try {
                      Background.null.access$0(Background.null.this).loadTemp((Background.null.access$0(Background.null.this)).nowid);
                      Intent intent = new Intent();
                      this("com.android.camera.action.CROP");
                      intent.setDataAndType(Uri.fromFile((Background.null.access$0(Background.null.this)).temp), "image/*");
                      intent.putExtra("crop", "true");
                      intent.putExtra("aspectX", 1);
                      intent.putExtra("aspectY", 1);
                      intent.putExtra("return-data", true);
                      Background.null.access$0(Background.null.this).startActivityForResult(intent, 123);
                    } catch (Exception exception) {
                      exception.printStackTrace();
                    } 
                  }
                }).setNegativeButton(2131034121, new DialogInterface.OnClickListener() {
                  public void onClick(DialogInterface param2DialogInterface, int param2Int) {}
                }).show();
            return true;
          }
        });
    Gallery gallery = (Gallery)findViewById(2131099650);
    gallery.setAdapter((SpinnerAdapter)new ImageAdapter((Context)this));
    gallery.setOnItemSelectedListener(this);
  }
  
  public void onItemSelected(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.mSwitcher.setImageDrawable((Drawable)this.imageGet.get(this.startId + paramInt));
    this.nowid = this.startId + paramInt;
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4)
      System.exit(0); 
    return true;
  }
  
  public void onNothingSelected(AdapterView paramAdapterView) {}
  
  public class ImageAdapter extends BaseAdapter {
    public ImageAdapter(Context param1Context) {
      Background.this.mContext = param1Context;
    }
    
    public int getCount() {
      return Background.this.piclength;
    }
    
    public Object getItem(int param1Int) {
      return Integer.valueOf(param1Int);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      ImageView imageView = new ImageView(Background.this.mContext);
      imageView.setImageDrawable((Drawable)Background.this.imageGet.get(Background.this.startId + param1Int));
      imageView.setAdjustViewBounds(true);
      imageView.setLayoutParams((ViewGroup.LayoutParams)new Gallery.LayoutParams(-2, -2));
      return (View)imageView;
    }
  }
}


/* Location:              /home/fahim/Desktop/Basebridge2-dex2jar.jar!/com/keji/danti80/Background.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */