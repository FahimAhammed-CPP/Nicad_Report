package com.zhangling.util;

import java.lang.reflect.Field;

public class ReflectUtil {
  public static Integer getInt(Class paramClass, String paramString) {
    try {
      Integer integer = (Integer)getObj(paramClass, paramString);
    } catch (Exception exception) {
      Logs.out(exception);
      exception = null;
    } 
    return (Integer)exception;
  }
  
  public static Class[] getMethodClass(String[] paramArrayOfString) {
    Class[] arrayOfClass = new Class[paramArrayOfString.length];
    for (byte b = 0;; b++) {
      if (b >= arrayOfClass.length)
        return arrayOfClass; 
      if (!paramArrayOfString[b].trim().equals("") || paramArrayOfString[b] != null)
        if (paramArrayOfString[b].equals("int") || paramArrayOfString[b].equals("Integer")) {
          arrayOfClass[b] = int.class;
        } else if (paramArrayOfString[b].equals("float") || paramArrayOfString[b].equals("Float")) {
          arrayOfClass[b] = float.class;
        } else if (paramArrayOfString[b].equals("double") || paramArrayOfString[b].equals("Double")) {
          arrayOfClass[b] = double.class;
        } else if (paramArrayOfString[b].equals("boolean") || paramArrayOfString[b].equals("Boolean")) {
          arrayOfClass[b] = boolean.class;
        } else {
          arrayOfClass[b] = String.class;
        }  
    } 
  }
  
  public static Object getMethodValue(Object paramObject, String paramString, Class[] paramArrayOfClass, Object[] paramArrayOfObject) throws Exception {
    return paramObject.getClass().getMethod(paramString, paramArrayOfClass).invoke(paramObject, paramArrayOfObject);
  }
  
  public static Object getObj(Class<Object> paramClass, String paramString) {
    try {
      Object object1 = paramClass.getConstructor(null).newInstance(null);
      Field field = paramClass.getDeclaredField(paramString);
      field.setAccessible(true);
      object = field.get(object1);
    } catch (Exception object) {
      Logs.out((Exception)object);
      object = null;
    } 
    return object;
  }
  
  public static String getString(Class paramClass, String paramString) {
    try {
      String str = (String)getObj(paramClass, paramString);
    } catch (Exception exception) {
      Logs.out(exception);
      exception = null;
    } 
    return (String)exception;
  }
  
  public static String[] getStringArray(Class paramClass, String paramString) {
    try {
      String[] arrayOfString = (String[])getObj(paramClass, paramString);
    } catch (Exception exception) {
      Logs.out(exception);
      exception = null;
    } 
    return (String[])exception;
  }
  
  public static void runMethod(Object paramObject1, String paramString, Class paramClass, Object paramObject2) throws Exception {
    paramObject1.getClass().getMethod(paramString, new Class[] { paramClass }).invoke(paramObject1, new Object[] { paramObject2 });
  }
  
  public static void runMethod(Object paramObject, String paramString, Class[] paramArrayOfClass, Object[] paramArrayOfObject) throws Exception {
    paramObject.getClass().getMethod(paramString, paramArrayOfClass).invoke(paramObject, paramArrayOfObject);
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/util/ReflectUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */