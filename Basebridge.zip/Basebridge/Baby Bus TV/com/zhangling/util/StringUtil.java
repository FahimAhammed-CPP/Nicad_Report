package com.zhangling.util;

import java.util.Date;

public class StringUtil {
  static String[] teShuZiFu_new;
  
  static String[] teShuZiFu_old = new String[] { "#", "&", "<", ">", " ", "?", "$", "'", "-", "%" };
  
  static {
    teShuZiFu_new = new String[] { "#23", "#26", "#3C", "#3E", "#20", "#3F", "#24", "\\'", "#2D", "#25" };
  }
  
  public static boolean beKong(Object paramObject) {
    return (paramObject == null) ? true : ("".equals(paramObject.toString()));
  }
  
  public static boolean beKong(String paramString) {
    return (paramString == null) ? true : ("".equals(paramString));
  }
  
  public static boolean beKongWith0(String paramString) {
    return (paramString == null) ? true : ("".equals(paramString) ? true : ("0".equals(paramString)));
  }
  
  public static String getDist(long paramLong) {
    return getDist((new Date()).getTime(), paramLong);
  }
  
  public static String getDist(long paramLong1, long paramLong2) {
    String str;
    try {
      paramLong1 = (paramLong1 - paramLong2) / 1000L;
      if (60L > paramLong1) {
        StringBuilder stringBuilder1 = new StringBuilder();
        this(String.valueOf(paramLong1));
        return stringBuilder1.append("秒钟前").toString();
      } 
      paramLong1 /= 60L;
      if (60L > paramLong1) {
        StringBuilder stringBuilder1 = new StringBuilder();
        this(String.valueOf(paramLong1));
        return stringBuilder1.append("分钟前").toString();
      } 
      paramLong1 /= 60L;
      if (24L > paramLong1) {
        StringBuilder stringBuilder1 = new StringBuilder();
        this(String.valueOf(paramLong1));
        return stringBuilder1.append("小时前").toString();
      } 
      paramLong1 /= 24L;
      StringBuilder stringBuilder = new StringBuilder();
      this(String.valueOf(paramLong1));
      str = stringBuilder.append("天前").toString();
    } catch (Exception exception) {
      str = "";
    } 
    return str;
  }
  
  public static String unTihuan(String paramString) {
    for (int i = teShuZiFu_old.length - 1;; i--) {
      if (i < 0)
        return paramString; 
      paramString = paramString.replace(teShuZiFu_new[i], teShuZiFu_old[i]);
    } 
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/util/StringUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */