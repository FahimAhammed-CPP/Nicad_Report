package com.zhangling.util;

import android.content.Context;
import android.widget.Toast;

public class Toasts {
  private static int type = Logs.type;
  
  public static void l(Context paramContext, int paramInt) {
    if (type != 0)
      Toast.makeText(paramContext, paramInt, 1).show(); 
  }
  
  public static void l(Context paramContext, CharSequence paramCharSequence) {
    if (type != 0)
      Toast.makeText(paramContext, paramCharSequence, 1).show(); 
  }
  
  public static void l(Context paramContext, String paramString) {
    if (type != 0)
      Toast.makeText(paramContext, paramString, 1).show(); 
  }
  
  public static void lalert(Context paramContext, CharSequence paramCharSequence) {
    Toast.makeText(paramContext, paramCharSequence, 1).show();
  }
  
  public static void lalert(Context paramContext, String paramString) {
    Toast.makeText(paramContext, paramString, 1).show();
  }
  
  public static void m(Context paramContext, int paramInt) {
    if (type != 0)
      Toast.makeText(paramContext, paramInt, 0).show(); 
  }
  
  public static void m(Context paramContext, CharSequence paramCharSequence) {
    if (type != 0)
      Toast.makeText(paramContext, paramCharSequence, 0).show(); 
  }
  
  public static void m(Context paramContext, String paramString) {
    if (type != 0)
      Toast.makeText(paramContext, paramString, 0).show(); 
  }
  
  public static void malert(Context paramContext, CharSequence paramCharSequence) {
    Toast.makeText(paramContext, paramCharSequence, 0).show();
  }
  
  public static void malert(Context paramContext, String paramString) {
    Toast.makeText(paramContext, paramString, 0).show();
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/util/Toasts.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */