package com.zhangling.util;

public class UserConfig {
  public static final int id = 101960;
  
  public static final String key = "8febbc978766d8cccbbb584f10ee6285bd98ff58e48053f1";
  
  public static final String price = "2.00";
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/util/UserConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */