package com.zhangling.util;

import android.util.Log;
import java.io.PrintStream;
import java.util.Date;

public class Logs {
  public static int tmp_p;
  
  public static int type = 0;
  
  static {
    tmp_p = 1;
  }
  
  public static void out() {
    if (type != 0) {
      if (1 == type)
        System.out.println((new Date()).toString()); 
      if (2 == type)
        Log.v((new Date()).toString(), "========================================"); 
      if (3 == type) {
        System.out.println((new Date()).toString());
        Log.v((new Date()).toString(), "========================================");
      } 
    } 
  }
  
  public static void out(Exception paramException) {
    if (type != 0) {
      if (1 == type) {
        System.out.println(paramException.getMessage());
        return;
      } 
      if (2 == type) {
        paramException.printStackTrace();
        return;
      } 
      if (3 == type) {
        System.out.println(paramException.getMessage());
        paramException.printStackTrace();
      } 
    } 
  }
  
  public static void out(Integer paramInteger) {
    if (type != 0) {
      if (1 == type) {
        System.out.println(paramInteger);
        return;
      } 
      if (2 == type) {
        Log.v(String.valueOf(paramInteger), "===================  " + String.valueOf(paramInteger) + " =====================");
        return;
      } 
      if (3 == type) {
        System.out.println(paramInteger);
        Log.v(String.valueOf(paramInteger), "===================  " + String.valueOf(paramInteger) + " =====================");
      } 
    } 
  }
  
  public static void out(String paramString) {
    if (type != 0) {
      if (1 == type) {
        System.out.println(paramString);
        return;
      } 
      if (2 == type) {
        Log.v(paramString, "====================  " + paramString + "  ====================");
        return;
      } 
      if (3 == type) {
        System.out.println(paramString);
        Log.v(paramString, "====================  " + paramString + "  ====================");
      } 
    } 
  }
  
  public static void out(String paramString1, String paramString2) {
    if (type != 0) {
      if (1 == type) {
        System.out.println(paramString1);
        return;
      } 
      if (2 == type) {
        Log.v(paramString1, paramString2);
        return;
      } 
      if (3 == type) {
        System.out.println(paramString1);
        Log.v(paramString1, paramString2);
      } 
    } 
  }
  
  public static void p() {
    if (type != 0)
      System.out.println((new Date()).toLocaleString()); 
  }
  
  public static void p(int paramInt) {
    if (type != 0)
      System.out.println(paramInt); 
  }
  
  public static void p(Boolean paramBoolean) {
    if (type != 0)
      System.out.println(paramBoolean); 
  }
  
  public static void p(Object paramObject) {
    if (type != 0)
      System.out.println(paramObject); 
  }
  
  public static void p(String paramString) {
    if (type != 0)
      System.out.println(paramString); 
  }
  
  public static void pShow() {
    if (type != 0) {
      if (1 == tmp_p)
        System.out.println(">>> start <<<"); 
      PrintStream printStream = System.out;
      int i = tmp_p;
      tmp_p = i + 1;
      printStream.println(i);
    } 
  }
  
  public static void pShowStart(int paramInt) {
    if (type != 0)
      tmp_p = paramInt; 
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/util/Logs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */