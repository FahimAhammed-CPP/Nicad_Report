package com.zhangling.util;

public class Contants {
  public final class Setings {
    public static final String BACK = "3";
    
    public static final String COLOR = "1";
    
    public static final String SIZE = "2";
    
    public static final String SPEED = "4";
  }
  
  public final class Textdetail {
    public static final int AUTO = 2;
    
    public static final String BACKGROUNDSAV = "book_textdetail_background";
    
    public static final String COLORSAV = "book_textdetail_color";
    
    public static final int RESULT = 111;
    
    public static final int RESULTTYPE = 123;
    
    public static final int SETTING = 3;
    
    public static final int SHOUCANG = 1;
    
    public static final String SPEEDSAV = "book_textdetail_speed";
    
    public static final String TEXTSIZESAV = "book_textdetail_textsize";
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/util/Contants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */