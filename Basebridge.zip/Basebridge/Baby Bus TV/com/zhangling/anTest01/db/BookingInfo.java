package com.zhangling.anTest01.db;

import android.content.Context;
import android.content.SharedPreferences;
import com.zhangling.util.Logs;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class BookingInfo extends BaseSqlManager<HistoryInfo> implements Serializable {
  private static final String[] cols;
  
  private static final String[] colsType;
  
  private static BookingInfo info = null;
  
  private static final String tableName = "BookingInfo";
  
  static {
    cols = new String[] { "biPid", "biCreateTime", "biTime" };
    colsType = new String[] { "INTEGER PRIMARY KEY", "DATETIME", "DATETIME" };
  }
  
  private BookingInfo(Context paramContext) {
    super(paramContext, "BookingInfo", cols, colsType);
  }
  
  public static BookingInfo init(Context paramContext, SharedPreferences paramSharedPreferences, SharedPreferences.Editor paramEditor) {
    if (info != null)
      return info; 
    try {
      boolean bool;
      Logs.pShow();
      BookingInfo bookingInfo2 = new BookingInfo();
      this(paramContext);
      info = bookingInfo2;
      Logs.pShow();
      if (info == null) {
        bool = true;
      } else {
        bool = false;
      } 
      Logs.p(Boolean.valueOf(bool));
      String str = paramSharedPreferences.getString("db_init_BookingInfo", null);
      if (str != null && "1".equals(str))
        return info; 
      paramEditor.putString("db_init_BookingInfo", "1");
      paramEditor.commit();
      BookingInfo bookingInfo1 = info;
    } catch (Exception exception) {
      Logs.out(exception);
      exception = null;
    } 
    return (BookingInfo)exception;
  }
  
  private void initData() {}
  
  public void insertInto(String paramString) {
    String str = getDateTime();
    long l = (new Date()).getTime();
    insert(new String[] { "biPid", "biCreateTime", "biTime" }, new String[] { paramString, str, String.valueOf(l) });
  }
  
  public List<String> queryBooking() {
    return queryBySql("biPid", null, null, null, null, "biCreateTime desc");
  }
  
  public List<List<String>> queryBooking2() {
    return queryBySqls(new String[] { "biPid", "biCreateTime" }, null, null, null, null, "biCreateTime desc");
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest01/db/BookingInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */