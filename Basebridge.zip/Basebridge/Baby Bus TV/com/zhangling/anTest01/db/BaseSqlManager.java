package com.zhangling.anTest01.db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.zhangling.util.Logs;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BaseSqlManager<T extends Serializable> extends SQLiteOpenHelper implements Serializable {
  private static final String DATABASE_NAME = "db.db";
  
  private static final int DATABASE_VERSION = 1;
  
  protected static BaseSqlManager<Serializable> baseSqlManager = null;
  
  protected String[] cols = null;
  
  protected String[] colsType = null;
  
  protected SQLiteDatabase db = null;
  
  protected String tableName = null;
  
  protected BaseSqlManager(Context paramContext, String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2) {
    super(paramContext, "db.db", null, 1);
    this.tableName = paramString;
    this.cols = paramArrayOfString1;
    this.colsType = paramArrayOfString2;
    try {
      this.db = getWritableDatabase();
      createTable();
    } catch (Exception exception) {
      Logs.out(exception);
    } 
  }
  
  protected void createTable() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("CREATE TABLE IF NOT EXISTS ");
    stringBuilder.append(this.tableName);
    int i = this.cols.length;
    stringBuilder.append(" (");
    for (byte b = 0;; b++) {
      if (b >= i) {
        stringBuilder.append(");");
        try {
          this.db.execSQL(stringBuilder.toString());
        } catch (Exception exception) {
          Logs.out(exception);
        } 
        return;
      } 
      exception.append(this.cols[b]);
      exception.append(" ");
      exception.append(this.colsType[b]);
      if (b < i - 1)
        exception.append(", "); 
    } 
  }
  
  protected void dropTable() {
    String str = "DROP TABLE IF EXISTS " + this.tableName;
    try {
      this.db.execSQL(str);
    } catch (Exception exception) {
      Logs.out(exception);
    } 
  }
  
  protected String getDateTime() {
    return (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date());
  }
  
  protected T getInstantion(Context paramContext) {
    if (baseSqlManager != null)
      return (T)baseSqlManager; 
    try {
      BaseSqlManager<Serializable> baseSqlManager2 = new BaseSqlManager();
      this(paramContext, this.tableName, this.cols, this.colsType);
      baseSqlManager = baseSqlManager2;
      BaseSqlManager<Serializable> baseSqlManager1 = baseSqlManager;
    } catch (Exception exception) {
      Logs.out(exception);
      exception = null;
    } 
    return (T)exception;
  }
  
  protected void insert(String[] paramArrayOfString1, String[] paramArrayOfString2) {
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("insert into ");
      stringBuilder.append(this.tableName);
      stringBuilder.append(" (");
      int i = paramArrayOfString1.length;
      for (byte b = 0;; b++) {
        if (b >= i) {
          stringBuilder.append(") values ('");
          for (b = 0;; b++) {
            if (b >= i) {
              stringBuilder.append("');");
              Logs.out(stringBuilder.toString());
              this.db.execSQL(stringBuilder.toString());
              return;
            } 
            stringBuilder.append(paramArrayOfString2[b]);
            if (b < i - 1)
              stringBuilder.append("', '"); 
          } 
          break;
        } 
        stringBuilder.append(paramArrayOfString1[b]);
        if (b < i - 1)
          stringBuilder.append(", "); 
      } 
    } catch (Exception exception) {
      Logs.out(exception);
    } 
  }
  
  protected void insertBySql(String paramString) {
    try {
      this.db.execSQL(paramString);
    } catch (Exception exception) {
      Logs.out(exception);
    } 
  }
  
  public void onCreate(SQLiteDatabase paramSQLiteDatabase) {}
  
  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {}
  
  public List<String> queryAll() {
    return queryBySql_all(null, null, null, null, null, null);
  }
  
  public List<List<String>> queryAll2() {
    return queryBySql_all2(null, null, null, null, null, null);
  }
  
  public List<List<String>> queryAll3() {
    return queryBySql_all2(new String[] { "hiPid", "hiCreateTime" }, null, null, null, null, null);
  }
  
  protected List<String> queryBySql(String paramString1, String paramString2, String[] paramArrayOfString, String paramString3, String paramString4, String paramString5) {
    ArrayList<String> arrayList = new ArrayList();
    StringBuilder stringBuilder = new StringBuilder();
    try {
      String[] arrayOfString = this.cols;
      if (paramString1 != null) {
        arrayOfString = new String[1];
        arrayOfString[0] = paramString1;
      } 
      Cursor cursor = this.db.query(this.tableName, arrayOfString, paramString2, paramArrayOfString, paramString3, null, paramString5);
      Logs.out(Integer.valueOf(cursor.getCount()));
      Logs.out(Integer.valueOf(cursor.getCount()));
      while (true) {
        if (cursor.moveToNext()) {
          stringBuilder.append(cursor.getString(0));
          stringBuilder.append("\n");
          arrayList.add(cursor.getString(0));
          stringBuilder.append("\n");
          stringBuilder.append("\n");
          stringBuilder.append("\n");
          continue;
        } 
        return arrayList;
      } 
    } catch (Exception exception) {
      Logs.out(stringBuilder.toString());
      Logs.out(exception);
    } 
    return arrayList;
  }
  
  protected List<String> queryBySql_all(String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, String paramString3, String paramString4) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #7
    //   9: new java/lang/StringBuilder
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore #8
    //   18: aload_1
    //   19: astore #5
    //   21: aload_1
    //   22: ifnonnull -> 31
    //   25: aload_0
    //   26: getfield cols : [Ljava/lang/String;
    //   29: astore #5
    //   31: aload_0
    //   32: getfield db : Landroid/database/sqlite/SQLiteDatabase;
    //   35: aload_0
    //   36: getfield tableName : Ljava/lang/String;
    //   39: aload #5
    //   41: aload_2
    //   42: aload_3
    //   43: aload #4
    //   45: aconst_null
    //   46: aload #6
    //   48: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   51: astore_1
    //   52: aload_1
    //   53: invokeinterface getCount : ()I
    //   58: pop
    //   59: aload_1
    //   60: invokeinterface moveToFirst : ()Z
    //   65: pop
    //   66: aload_1
    //   67: invokeinterface getPosition : ()I
    //   72: aload_1
    //   73: invokeinterface getCount : ()I
    //   78: if_icmpne -> 84
    //   81: aload #7
    //   83: areturn
    //   84: aload #5
    //   86: arraylength
    //   87: istore #9
    //   89: iconst_0
    //   90: istore #10
    //   92: iload #10
    //   94: iload #9
    //   96: if_icmplt -> 149
    //   99: aload #8
    //   101: ldc '\\n'
    //   103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: pop
    //   107: aload #8
    //   109: ldc '\\n'
    //   111: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   114: pop
    //   115: aload #8
    //   117: ldc '\\n'
    //   119: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   122: pop
    //   123: aload_1
    //   124: invokeinterface moveToNext : ()Z
    //   129: pop
    //   130: goto -> 66
    //   133: astore_1
    //   134: aload #8
    //   136: invokevirtual toString : ()Ljava/lang/String;
    //   139: invokestatic out : (Ljava/lang/String;)V
    //   142: aload_1
    //   143: invokestatic out : (Ljava/lang/Exception;)V
    //   146: goto -> 81
    //   149: aload #8
    //   151: aload_1
    //   152: aload_1
    //   153: aload #5
    //   155: iload #10
    //   157: aaload
    //   158: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   163: invokeinterface getString : (I)Ljava/lang/String;
    //   168: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   171: pop
    //   172: aload #8
    //   174: ldc '\\n'
    //   176: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   179: pop
    //   180: aload #7
    //   182: aload_1
    //   183: aload_1
    //   184: aload #5
    //   186: iload #10
    //   188: aaload
    //   189: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   194: invokeinterface getString : (I)Ljava/lang/String;
    //   199: invokeinterface add : (Ljava/lang/Object;)Z
    //   204: pop
    //   205: iinc #10, 1
    //   208: goto -> 92
    // Exception table:
    //   from	to	target	type
    //   25	31	133	java/lang/Exception
    //   31	66	133	java/lang/Exception
    //   66	81	133	java/lang/Exception
    //   84	89	133	java/lang/Exception
    //   99	130	133	java/lang/Exception
    //   149	205	133	java/lang/Exception
  }
  
  protected List<List<String>> queryBySql_all2(String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, String paramString3, String paramString4) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #7
    //   3: iload #7
    //   5: aload_1
    //   6: arraylength
    //   7: if_icmplt -> 113
    //   10: new java/util/ArrayList
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: astore #8
    //   19: new java/lang/StringBuilder
    //   22: dup
    //   23: invokespecial <init> : ()V
    //   26: astore #9
    //   28: aload_1
    //   29: astore #5
    //   31: aload_1
    //   32: ifnonnull -> 41
    //   35: aload_0
    //   36: getfield cols : [Ljava/lang/String;
    //   39: astore #5
    //   41: aload_0
    //   42: getfield db : Landroid/database/sqlite/SQLiteDatabase;
    //   45: aload_0
    //   46: getfield tableName : Ljava/lang/String;
    //   49: aload #5
    //   51: aload_2
    //   52: aload_3
    //   53: aload #4
    //   55: aconst_null
    //   56: aload #6
    //   58: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   61: astore_1
    //   62: aload_1
    //   63: invokeinterface getCount : ()I
    //   68: pop
    //   69: aload_1
    //   70: invokeinterface moveToFirst : ()Z
    //   75: pop
    //   76: iconst_0
    //   77: istore #7
    //   79: iload #7
    //   81: aload #5
    //   83: arraylength
    //   84: if_icmplt -> 151
    //   87: aload_1
    //   88: invokeinterface getPosition : ()I
    //   93: istore #7
    //   95: aload_1
    //   96: invokeinterface getCount : ()I
    //   101: istore #10
    //   103: iload #7
    //   105: iload #10
    //   107: if_icmpne -> 192
    //   110: aload #8
    //   112: areturn
    //   113: new java/lang/StringBuilder
    //   116: dup
    //   117: ldc 'columns['
    //   119: invokespecial <init> : (Ljava/lang/String;)V
    //   122: iload #7
    //   124: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   127: ldc ']: '
    //   129: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   132: aload_1
    //   133: iload #7
    //   135: aaload
    //   136: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   139: invokevirtual toString : ()Ljava/lang/String;
    //   142: invokestatic p : (Ljava/lang/String;)V
    //   145: iinc #7, 1
    //   148: goto -> 3
    //   151: new java/lang/StringBuilder
    //   154: astore_2
    //   155: aload_2
    //   156: ldc 'columns['
    //   158: invokespecial <init> : (Ljava/lang/String;)V
    //   161: aload_2
    //   162: iload #7
    //   164: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   167: ldc ']: '
    //   169: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: aload #5
    //   174: iload #7
    //   176: aaload
    //   177: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   180: invokevirtual toString : ()Ljava/lang/String;
    //   183: invokestatic p : (Ljava/lang/String;)V
    //   186: iinc #7, 1
    //   189: goto -> 79
    //   192: aload #5
    //   194: arraylength
    //   195: istore #10
    //   197: new java/lang/StringBuilder
    //   200: astore_2
    //   201: aload_2
    //   202: ldc 'length: '
    //   204: invokespecial <init> : (Ljava/lang/String;)V
    //   207: aload_2
    //   208: iload #10
    //   210: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   213: invokevirtual toString : ()Ljava/lang/String;
    //   216: invokestatic p : (Ljava/lang/String;)V
    //   219: new java/util/ArrayList
    //   222: astore_2
    //   223: aload_2
    //   224: invokespecial <init> : ()V
    //   227: iconst_0
    //   228: istore #7
    //   230: iload #7
    //   232: iload #10
    //   234: if_icmplt -> 304
    //   237: aload #8
    //   239: aload_2
    //   240: invokeinterface add : (Ljava/lang/Object;)Z
    //   245: pop
    //   246: aload #9
    //   248: ldc '\\n'
    //   250: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: pop
    //   254: aload #9
    //   256: ldc '\\n'
    //   258: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   261: pop
    //   262: aload #9
    //   264: ldc '\\n'
    //   266: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   269: pop
    //   270: aload_1
    //   271: invokeinterface moveToNext : ()Z
    //   276: pop
    //   277: aload #9
    //   279: invokevirtual toString : ()Ljava/lang/String;
    //   282: invokestatic out : (Ljava/lang/String;)V
    //   285: goto -> 87
    //   288: astore_1
    //   289: aload_1
    //   290: invokestatic out : (Ljava/lang/Exception;)V
    //   293: aload #9
    //   295: invokevirtual toString : ()Ljava/lang/String;
    //   298: invokestatic out : (Ljava/lang/String;)V
    //   301: goto -> 110
    //   304: aload #9
    //   306: aload_1
    //   307: aload_1
    //   308: aload #5
    //   310: iload #7
    //   312: aaload
    //   313: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   318: invokeinterface getString : (I)Ljava/lang/String;
    //   323: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   326: pop
    //   327: aload #9
    //   329: ldc '\\n'
    //   331: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   334: pop
    //   335: aload_2
    //   336: aload_1
    //   337: aload_1
    //   338: aload #5
    //   340: iload #7
    //   342: aaload
    //   343: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   348: invokeinterface getString : (I)Ljava/lang/String;
    //   353: invokeinterface add : (Ljava/lang/Object;)Z
    //   358: pop
    //   359: iinc #7, 1
    //   362: goto -> 230
    // Exception table:
    //   from	to	target	type
    //   35	41	288	java/lang/Exception
    //   41	76	288	java/lang/Exception
    //   79	87	288	java/lang/Exception
    //   87	103	288	java/lang/Exception
    //   151	186	288	java/lang/Exception
    //   192	227	288	java/lang/Exception
    //   237	285	288	java/lang/Exception
    //   304	359	288	java/lang/Exception
  }
  
  protected List<List<String>> queryBySqls(String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2, String paramString3, String paramString4) {
    // Byte code:
    //   0: new java/util/ArrayList
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #7
    //   9: new java/lang/StringBuilder
    //   12: dup
    //   13: invokespecial <init> : ()V
    //   16: astore #8
    //   18: aload_1
    //   19: astore #5
    //   21: aload_1
    //   22: ifnonnull -> 31
    //   25: aload_0
    //   26: getfield cols : [Ljava/lang/String;
    //   29: astore #5
    //   31: aload_0
    //   32: getfield db : Landroid/database/sqlite/SQLiteDatabase;
    //   35: aload_0
    //   36: getfield tableName : Ljava/lang/String;
    //   39: aload #5
    //   41: aload_2
    //   42: aload_3
    //   43: aload #4
    //   45: aconst_null
    //   46: aload #6
    //   48: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   51: astore_1
    //   52: aload_1
    //   53: invokeinterface moveToNext : ()Z
    //   58: ifne -> 64
    //   61: aload #7
    //   63: areturn
    //   64: aload #5
    //   66: arraylength
    //   67: istore #9
    //   69: new java/lang/StringBuilder
    //   72: astore_2
    //   73: aload_2
    //   74: ldc 'length: '
    //   76: invokespecial <init> : (Ljava/lang/String;)V
    //   79: aload_2
    //   80: iload #9
    //   82: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   85: invokevirtual toString : ()Ljava/lang/String;
    //   88: invokestatic p : (Ljava/lang/String;)V
    //   91: new java/util/ArrayList
    //   94: astore_2
    //   95: aload_2
    //   96: invokespecial <init> : ()V
    //   99: iconst_0
    //   100: istore #10
    //   102: iload #10
    //   104: iload #9
    //   106: if_icmplt -> 169
    //   109: aload #7
    //   111: aload_2
    //   112: invokeinterface add : (Ljava/lang/Object;)Z
    //   117: pop
    //   118: aload #8
    //   120: ldc '\\n'
    //   122: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   125: pop
    //   126: aload #8
    //   128: ldc '\\n'
    //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   133: pop
    //   134: aload #8
    //   136: ldc '\\n'
    //   138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   141: pop
    //   142: aload #8
    //   144: invokevirtual toString : ()Ljava/lang/String;
    //   147: invokestatic out : (Ljava/lang/String;)V
    //   150: goto -> 52
    //   153: astore_1
    //   154: aload_1
    //   155: invokestatic out : (Ljava/lang/Exception;)V
    //   158: aload #8
    //   160: invokevirtual toString : ()Ljava/lang/String;
    //   163: invokestatic out : (Ljava/lang/String;)V
    //   166: goto -> 61
    //   169: aload #8
    //   171: aload_1
    //   172: iload #10
    //   174: invokeinterface getString : (I)Ljava/lang/String;
    //   179: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   182: pop
    //   183: aload #8
    //   185: ldc '\\n'
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: pop
    //   191: aload_2
    //   192: aload_1
    //   193: iload #10
    //   195: invokeinterface getString : (I)Ljava/lang/String;
    //   200: invokeinterface add : (Ljava/lang/Object;)Z
    //   205: pop
    //   206: iinc #10, 1
    //   209: goto -> 102
    // Exception table:
    //   from	to	target	type
    //   25	31	153	java/lang/Exception
    //   31	52	153	java/lang/Exception
    //   52	61	153	java/lang/Exception
    //   64	99	153	java/lang/Exception
    //   109	150	153	java/lang/Exception
    //   169	206	153	java/lang/Exception
  }
  
  public void reCreat() {
    try {
      dropTable();
      createTable();
    } catch (Exception exception) {
      Logs.out(exception);
    } 
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest01/db/BaseSqlManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */