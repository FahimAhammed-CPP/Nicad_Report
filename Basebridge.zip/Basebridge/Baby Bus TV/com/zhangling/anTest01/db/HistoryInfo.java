package com.zhangling.anTest01.db;

import android.content.Context;
import android.content.SharedPreferences;
import com.zhangling.util.Logs;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class HistoryInfo extends BaseSqlManager<HistoryInfo> implements Serializable {
  private static final String[] cols;
  
  private static final String[] colsType;
  
  private static HistoryInfo info = null;
  
  private static final String tableName = "HistoryInfo";
  
  static {
    cols = new String[] { "hiId", "hiPid", "hiCreateTime", "hiTime" };
    colsType = new String[] { "INTEGER PRIMARY KEY", "INTEGER", "DATETIME", "DATETIME" };
  }
  
  private HistoryInfo(Context paramContext) {
    super(paramContext, "HistoryInfo", cols, colsType);
  }
  
  public static HistoryInfo init(Context paramContext, SharedPreferences paramSharedPreferences, SharedPreferences.Editor paramEditor) {
    if (info != null)
      return info; 
    try {
      boolean bool;
      Logs.pShow();
      HistoryInfo historyInfo2 = new HistoryInfo();
      this(paramContext);
      info = historyInfo2;
      Logs.pShow();
      if (info == null) {
        bool = true;
      } else {
        bool = false;
      } 
      Logs.p(Boolean.valueOf(bool));
      String str = paramSharedPreferences.getString("db_init_HistoryInfo", null);
      if (str != null && "1".equals(str))
        return info; 
      paramEditor.putString("db_init_HistoryInfo", "1");
      paramEditor.commit();
      HistoryInfo historyInfo1 = info;
    } catch (Exception exception) {
      Logs.out(exception);
      exception = null;
    } 
    return (HistoryInfo)exception;
  }
  
  private void initData() {}
  
  public void insertInto(String paramString) {
    String str = getDateTime();
    long l = (new Date()).getTime();
    insert(new String[] { "hiPid", "hiCreateTime", "hiTime" }, new String[] { paramString, str, String.valueOf(l) });
  }
  
  public List<String> querySome() {
    return queryBySql("count(hiId)", null, null, null, null, null);
  }
  
  public List<List<String>> queryToday() {
    return queryBySqls(new String[] { "hiPid", "hiTime" }, "hiCreateTime >= datetime('now', 'start of day')", null, null, null, "hiCreateTime desc");
  }
  
  public List<List<String>> queryYesterday() {
    return queryBySqls(new String[] { "hiPid", "hiTime" }, "hiCreateTime >= datetime('now', '-1 day', 'start of day') and hiCreateTime < datetime('now', 'start of day')", null, null, null, "hiCreateTime desc");
  }
  
  public List<List<String>> queryYesterdayBefore() {
    return queryBySqls(new String[] { "hiPid", "hiTime" }, "hiCreateTime < datetime('now', '-1 day', 'start of day')", null, null, null, "hiCreateTime desc");
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest01/db/HistoryInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */