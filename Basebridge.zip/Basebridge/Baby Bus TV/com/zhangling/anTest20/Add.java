package com.zhangling.anTest20;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.zhangling.anTest01.db.HistoryInfo;
import com.zhangling.util.Logs;
import com.zhangling.util.ReflectUtil;
import com.zhangling.util.StringUtil;
import java.util.Date;

public class Add extends BaseActivity {
  public static Add add = null;
  
  Button button1 = null;
  
  Button button2 = null;
  
  int index = 0;
  
  TextView textView = null;
  
  TextView textView1 = null;
  
  private int tmp = 0;
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    add = this;
    try {
      this.index = getIntent().getExtras().getInt("index");
    } catch (Exception exception) {
      Logs.out(exception);
    } 
    HistoryInfo.init((Context)this, sp, editor).insertInto(String.valueOf(this.index));
    saveData("book_lastRead_id", this.index);
    saveData("book_lastRead_datetime", (new Date()).getTime());
    LinearLayout linearLayout1 = new LinearLayout((Context)this);
    String str1 = getString(ReflectUtil.getInt(R.string.class, "listView_title_" + this.index).intValue());
    String str2 = getString(ReflectUtil.getInt(R.string.class, "listView_add_" + this.index).intValue());
    setTitle(StringUtil.unTihuan(str1));
    linearLayout1.setOrientation(1);
    linearLayout1.setBackgroundResource(2130837506);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
    this.textView1 = new TextView((Context)this);
    this.textView1.setTextSize(23.0F);
    this.textView1.setGravity(1);
    this.textView = new TextView((Context)this);
    this.textView.setBackgroundColor(0);
    this.textView.setTextSize(19.0F);
    this.textView1.getPaint().setFakeBoldText(true);
    this.textView1.setTextColor(-65536);
    this.textView.setTextColor(-16777216);
    this.textView1.setText(StringUtil.unTihuan(str1));
    this.textView.setText(StringUtil.unTihuan(str2));
    linearLayout1.addView((View)this.textView1, (ViewGroup.LayoutParams)layoutParams);
    linearLayout1.addView((View)this.textView, (ViewGroup.LayoutParams)layoutParams);
    LinearLayout linearLayout2 = new LinearLayout((Context)this);
    linearLayout2.setGravity(1);
    linearLayout2.setOrientation(0);
    layoutParams = new LinearLayout.LayoutParams(-2, -2);
    this.button1 = new Button((Context)this);
    this.button2 = new Button((Context)this);
    this.button1.setText("开始测试");
    this.button1.setWidth(100);
    this.button2.setText("返回");
    this.button2.setWidth(100);
    linearLayout2.addView((View)this.button1, (ViewGroup.LayoutParams)layoutParams);
    linearLayout2.addView((View)this.button2, (ViewGroup.LayoutParams)layoutParams);
    linearLayout1.addView((View)linearLayout2);
    setContentView((View)linearLayout1);
    this.button1.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            Intent intent = new Intent();
            intent.setClass((Context)Add.add, Select.class);
            intent.putExtra("index", Add.add.index);
            Add.add.startActivity(intent);
            Add.add.finish();
          }
        });
    this.button2.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            Add.add.finish();
          }
        });
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/Add.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */