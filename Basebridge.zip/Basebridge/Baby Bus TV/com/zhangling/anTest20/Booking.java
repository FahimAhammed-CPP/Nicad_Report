package com.zhangling.anTest20;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.zhangling.anTest01.db.BookingInfo;
import com.zhangling.util.ReflectUtil;
import com.zhangling.util.Toasts;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Booking extends BaseActivity {
  public static Booking booking = null;
  
  ListView listView = null;
  
  private LayoutInflater mLayoutInflater;
  
  public void initData() {
    List<List<String>> list = BookingInfo.init((Context)this, sp, editor).queryBooking2();
    int i = list.size();
    ArrayList<HashMap<String, Object>> arrayList = new ArrayList();
    byte b = 0;
    while (true) {
      if (b >= i) {
        if (arrayList.size() > 0) {
          MyAdapter myAdapter = new MyAdapter((Context)this, arrayList);
          this.listView.setAdapter((ListAdapter)myAdapter);
          return;
        } 
      } else {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        hashMap.put("id", ((List<String>)list.get(b)).get(0));
        String str1 = getResources().getString(ReflectUtil.getInt(R.string.class, "listView_title_" + (String)((List<String>)list.get(b)).get(0)).intValue());
        String str2 = ((List<String>)list.get(b)).get(1);
        hashMap.put("title", str1);
        hashMap.put("info", str2);
        hashMap.put("img", Integer.valueOf(2130837566));
        hashMap.put("img1", Integer.valueOf(2130837505));
        arrayList.add(hashMap);
        b++;
        continue;
      } 
      Toasts.malert((Context)this, "您暂未收藏");
      return;
    } 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    booking = this;
    this.mLayoutInflater = LayoutInflater.from((Context)this);
    AbsListView.LayoutParams layoutParams = new AbsListView.LayoutParams(-1, -1);
    this.listView = new ListView((Context)this);
    this.listView.setCacheColorHint(0);
    initData();
    this.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
          public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
            TextView textView = (TextView)param1View.findViewById(2131099650);
            try {
              param1Int = Integer.parseInt(textView.getTag().toString());
              Intent intent = new Intent();
              this();
              intent.setClass((Context)Booking.this, Select.class);
              intent.putExtra("index", param1Int);
              intent.putExtra("notSaveDate", "1");
              Booking.this.startActivity(intent);
            } catch (Exception exception) {}
          }
        });
    addContentView((View)this.listView, (ViewGroup.LayoutParams)layoutParams);
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4) {
      Main.sendMsg(0);
      return false;
    } 
    return true;
  }
  
  class MyAdapter extends ArrayAdapter<HashMap<String, Object>> {
    public MyAdapter(Context param1Context, List<HashMap<String, Object>> param1List) {
      super(param1Context, 2130903044, 2131099650, param1List);
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null)
        view = Booking.this.mLayoutInflater.inflate(2130903040, null); 
      ImageView imageView2 = (ImageView)view.findViewById(2131099648);
      TextView textView1 = (TextView)view.findViewById(2131099650);
      TextView textView2 = (TextView)view.findViewById(2131099651);
      ImageView imageView1 = (ImageView)view.findViewById(2131099652);
      HashMap hashMap = (HashMap)getItem(param1Int);
      textView1.setText(hashMap.get("title").toString());
      try {
        textView1.setTag(Integer.valueOf(Integer.parseInt(hashMap.get("id").toString())));
      } catch (Exception exception) {}
      textView2.setText(hashMap.get("info").toString());
      imageView2.setImageResource(2130837566);
      imageView1.setImageResource(2130837505);
      textView1.setTextColor(-65536);
      textView2.setTextColor(-1);
      return view;
    }
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/Booking.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */