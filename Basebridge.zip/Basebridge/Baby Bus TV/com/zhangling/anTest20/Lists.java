package com.zhangling.anTest20;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import com.zhangling.util.Logs;
import com.zhangling.util.StringUtil;
import com.zhangling.util.Toasts;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TimerTask;

public class Lists extends BaseActivity {
  private static final int DIALOG_SINGLE_CHOICE = 5;
  
  public static List<String> al_viewlist_content;
  
  public static List<String> al_viewlist_title;
  
  private static Handler handler;
  
  public static Lists lists = null;
  
  public int book_firstVisibleItem_index = 1;
  
  private int book_last_view_page_index = 1;
  
  EditText editText = null;
  
  ListView list = null;
  
  private LayoutInflater mLayoutInflater;
  
  PopupWindow mPopupWindow = null;
  
  Button next = null;
  
  private int pageIndex = 1;
  
  private int pageSize = 10;
  
  Button pre = null;
  
  private int total = 1;
  
  int viewView_size = 0;
  
  static {
    al_viewlist_title = new ArrayList<String>();
    al_viewlist_content = new ArrayList<String>();
    handler = new Handler() {
        public void handleMessage(Message param1Message) {
          switch (param1Message.what) {
            default:
              return;
            case 1:
              Lists.lists.showPopupWindow();
            case 0:
              break;
          } 
          if (Lists.lists.mPopupWindow.isShowing())
            try {
              Lists.lists.mPopupWindow.dismiss();
            } catch (Exception exception) {
              Logs.out(exception);
            }  
        }
      };
  }
  
  public static void hiddenPop() {
    sendMsg(0);
  }
  
  public static void sendMsg(int paramInt) {
    Message message = new Message();
    message.what = paramInt;
    handler.sendMessage(message);
  }
  
  public static void showPop() {
    lists.showPopupWindow();
  }
  
  private void showPopupWindow() {
    if (this.mLayoutInflater == null)
      this.mLayoutInflater = (LayoutInflater)lists.getSystemService("layout_inflater"); 
    View view = this.mLayoutInflater.inflate(2130903046, null);
    if (this.mPopupWindow == null)
      this.mPopupWindow = new PopupWindow(view, -1, -2); 
    if (this.editText == null)
      this.editText = (EditText)view.findViewById(2131099662); 
    if (this.pre == null)
      this.pre = (Button)view.findViewById(2131099661); 
    if (this.next == null)
      this.next = (Button)view.findViewById(2131099663); 
    this.pre.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            if (1 < Lists.this.pageIndex) {
              Lists lists = Lists.this;
              lists.pageIndex = lists.pageIndex - 1;
              Lists.this.initData();
              return;
            } 
            Toasts.malert((Context)Lists.lists, "已经是第一页了");
          }
        });
    this.next.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            if (Lists.this.pageIndex < Lists.this.total) {
              Lists lists = Lists.this;
              lists.pageIndex = lists.pageIndex + 1;
              Lists.this.initData();
              return;
            } 
            Toasts.malert((Context)Lists.lists, "已经是最后一页了");
          }
        });
    this.editText.setText(String.valueOf(this.pageIndex) + "/" + this.total);
    this.editText.setFocusable(false);
    this.editText.setOnFocusChangeListener(new View.OnFocusChangeListener() {
          public void onFocusChange(View param1View, boolean param1Boolean) {
            Lists.this.showDialog(5);
          }
        });
    this.editText.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            Lists.this.showDialog(5);
          }
        });
    try {
      this.mPopupWindow.showAtLocation((View)lists.list, 80, 0, 0);
    } catch (Exception exception) {}
  }
  
  public void initData() {
    int i = this.pageSize * (this.pageIndex - 1);
    int j = this.pageSize;
    ArrayList<HashMap<String, Object>> arrayList = new ArrayList();
    int k = al_viewlist_title.size();
    for (int m = i;; m++) {
      MyAdapter myAdapter;
      if (m >= i + j || m >= k) {
        BaseActivity.saveData("book_last_view_page_index", this.pageIndex);
        this.list = (ListView)findViewById(2131099656);
        myAdapter = new MyAdapter((Context)this, arrayList);
        this.list.setAdapter((ListAdapter)myAdapter);
        if (this.editText != null)
          this.editText.setText(String.valueOf(this.pageIndex) + "/" + this.total); 
        return;
      } 
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      hashMap.put("title", StringUtil.unTihuan(al_viewlist_title.get(m)));
      hashMap.put("info", StringUtil.unTihuan(((String)al_viewlist_content.get(m)).substring(0, 20)));
      hashMap.put("img", Integer.valueOf(2130837566));
      hashMap.put("img1", Integer.valueOf(2130837505));
      myAdapter.add(hashMap);
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial onCreate : (Landroid/os/Bundle;)V
    //   5: aload_0
    //   6: putstatic com/zhangling/anTest20/Lists.lists : Lcom/zhangling/anTest20/Lists;
    //   9: getstatic com/zhangling/anTest20/Lists.beNoCheckLastRun : Z
    //   12: ifeq -> 19
    //   15: iconst_0
    //   16: putstatic com/zhangling/anTest20/Lists.beNoCheckLastRun : Z
    //   19: aload_0
    //   20: invokevirtual checkLastRun : ()V
    //   23: aload_0
    //   24: ldc_w 2130903042
    //   27: invokevirtual setContentView : (I)V
    //   30: getstatic com/zhangling/anTest20/Lists.sp : Landroid/content/SharedPreferences;
    //   33: ifnonnull -> 40
    //   36: aload_0
    //   37: invokespecial initData : ()V
    //   40: getstatic com/zhangling/anTest20/Lists.sp : Landroid/content/SharedPreferences;
    //   43: ldc_w 'book_firstVisibleItem_index'
    //   46: iconst_1
    //   47: invokeinterface getInt : (Ljava/lang/String;I)I
    //   52: istore_2
    //   53: aload_0
    //   54: aload_0
    //   55: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   58: putfield mLayoutInflater : Landroid/view/LayoutInflater;
    //   61: new com/zhangling/anTest20/R$string
    //   64: dup
    //   65: invokespecial <init> : ()V
    //   68: invokevirtual getClass : ()Ljava/lang/Class;
    //   71: invokevirtual getDeclaredFields : ()[Ljava/lang/reflect/Field;
    //   74: pop
    //   75: aload_0
    //   76: aload_0
    //   77: ldc_w com/zhangling/anTest20/R$string
    //   80: ldc_w 'listView_size'
    //   83: invokestatic getInt : (Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Integer;
    //   86: invokevirtual intValue : ()I
    //   89: invokevirtual getString : (I)Ljava/lang/String;
    //   92: invokestatic parseInt : (Ljava/lang/String;)I
    //   95: putfield viewView_size : I
    //   98: aload_0
    //   99: getfield viewView_size : I
    //   102: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   105: invokestatic out : (Ljava/lang/Integer;)V
    //   108: aload_0
    //   109: getfield viewView_size : I
    //   112: invokestatic p : (I)V
    //   115: aload_0
    //   116: getfield viewView_size : I
    //   119: getstatic com/zhangling/anTest20/Lists.al_viewlist_title : Ljava/util/List;
    //   122: invokeinterface size : ()I
    //   127: if_icmple -> 140
    //   130: iconst_0
    //   131: istore_3
    //   132: iload_3
    //   133: aload_0
    //   134: getfield viewView_size : I
    //   137: if_icmplt -> 298
    //   140: aload_0
    //   141: getstatic com/zhangling/anTest20/Lists.al_viewlist_title : Ljava/util/List;
    //   144: invokeinterface size : ()I
    //   149: aload_0
    //   150: getfield pageSize : I
    //   153: idiv
    //   154: putfield total : I
    //   157: getstatic com/zhangling/anTest20/Lists.al_viewlist_title : Ljava/util/List;
    //   160: invokeinterface size : ()I
    //   165: aload_0
    //   166: getfield pageSize : I
    //   169: irem
    //   170: ifle -> 183
    //   173: aload_0
    //   174: aload_0
    //   175: getfield total : I
    //   178: iconst_1
    //   179: iadd
    //   180: putfield total : I
    //   183: aload_0
    //   184: getstatic com/zhangling/anTest20/Lists.sp : Landroid/content/SharedPreferences;
    //   187: ldc 'book_last_view_page_index'
    //   189: iconst_1
    //   190: invokeinterface getInt : (Ljava/lang/String;I)I
    //   195: putfield book_last_view_page_index : I
    //   198: aload_0
    //   199: aload_0
    //   200: getfield book_last_view_page_index : I
    //   203: putfield pageIndex : I
    //   206: aload_0
    //   207: invokevirtual initData : ()V
    //   210: aload_0
    //   211: getfield list : Landroid/widget/ListView;
    //   214: iconst_0
    //   215: invokevirtual setCacheColorHint : (I)V
    //   218: aload_0
    //   219: getfield list : Landroid/widget/ListView;
    //   222: new com/zhangling/anTest20/Lists$2
    //   225: dup
    //   226: aload_0
    //   227: invokespecial <init> : (Lcom/zhangling/anTest20/Lists;)V
    //   230: invokevirtual setOnScrollListener : (Landroid/widget/AbsListView$OnScrollListener;)V
    //   233: aload_0
    //   234: getfield list : Landroid/widget/ListView;
    //   237: new com/zhangling/anTest20/Lists$3
    //   240: dup
    //   241: aload_0
    //   242: invokespecial <init> : (Lcom/zhangling/anTest20/Lists;)V
    //   245: invokevirtual setOnItemClickListener : (Landroid/widget/AdapterView$OnItemClickListener;)V
    //   248: aload_0
    //   249: iload_2
    //   250: putfield book_firstVisibleItem_index : I
    //   253: iload_2
    //   254: ifle -> 388
    //   257: aload_0
    //   258: getfield list : Landroid/widget/ListView;
    //   261: iload_2
    //   262: iconst_1
    //   263: isub
    //   264: invokevirtual setSelection : (I)V
    //   267: new java/util/Timer
    //   270: dup
    //   271: invokespecial <init> : ()V
    //   274: new com/zhangling/anTest20/Lists$initPopupWindow
    //   277: dup
    //   278: aload_0
    //   279: aconst_null
    //   280: invokespecial <init> : (Lcom/zhangling/anTest20/Lists;Lcom/zhangling/anTest20/Lists$initPopupWindow;)V
    //   283: ldc2_w 1000
    //   286: invokevirtual schedule : (Ljava/util/TimerTask;J)V
    //   289: return
    //   290: astore_1
    //   291: aload_1
    //   292: invokestatic out : (Ljava/lang/Exception;)V
    //   295: goto -> 115
    //   298: aload_0
    //   299: ldc_w com/zhangling/anTest20/R$string
    //   302: new java/lang/StringBuilder
    //   305: dup
    //   306: ldc_w 'listView_title_'
    //   309: invokespecial <init> : (Ljava/lang/String;)V
    //   312: iload_3
    //   313: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   316: invokevirtual toString : ()Ljava/lang/String;
    //   319: invokestatic getInt : (Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Integer;
    //   322: invokevirtual intValue : ()I
    //   325: invokevirtual getString : (I)Ljava/lang/String;
    //   328: astore_1
    //   329: aload_0
    //   330: ldc_w com/zhangling/anTest20/R$string
    //   333: new java/lang/StringBuilder
    //   336: dup
    //   337: ldc_w 'listView_content_'
    //   340: invokespecial <init> : (Ljava/lang/String;)V
    //   343: iload_3
    //   344: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   347: invokevirtual toString : ()Ljava/lang/String;
    //   350: invokestatic getInt : (Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Integer;
    //   353: invokevirtual intValue : ()I
    //   356: invokevirtual getString : (I)Ljava/lang/String;
    //   359: astore #4
    //   361: getstatic com/zhangling/anTest20/Lists.al_viewlist_title : Ljava/util/List;
    //   364: aload_1
    //   365: invokeinterface add : (Ljava/lang/Object;)Z
    //   370: pop
    //   371: getstatic com/zhangling/anTest20/Lists.al_viewlist_content : Ljava/util/List;
    //   374: aload #4
    //   376: invokeinterface add : (Ljava/lang/Object;)Z
    //   381: pop
    //   382: iinc #3, 1
    //   385: goto -> 132
    //   388: aload_0
    //   389: getfield list : Landroid/widget/ListView;
    //   392: iload_2
    //   393: invokevirtual setSelection : (I)V
    //   396: goto -> 267
    // Exception table:
    //   from	to	target	type
    //   75	115	290	java/lang/Exception
  }
  
  protected Dialog onCreateDialog(int paramInt) {
    ArrayList<HashMap<Object, Object>> arrayList = new ArrayList();
    byte b = 0;
    while (true) {
      HashMap<Object, Object> hashMap;
      if (b >= this.total) {
        null = new SimpleAdapter((Context)this, arrayList, 2130903047, new String[] { "ItemText" }, new int[] { 2131099665 });
        switch (paramInt) {
          default:
            return null;
          case 5:
            break;
        } 
      } else {
        hashMap = new HashMap<Object, Object>();
        hashMap.put("ItemText", "第" + (b + 1) + "页");
        arrayList.add(hashMap);
        b++;
        continue;
      } 
      return (Dialog)(new AlertDialog.Builder((Context)lists)).setTitle("请选择分页").setAdapter((ListAdapter)hashMap, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface param1DialogInterface, int param1Int) {
              Lists.this.pageIndex = param1Int + 1;
              Lists.this.initData();
            }
          }).create();
    } 
  }
  
  class MyAdapter extends ArrayAdapter<HashMap<String, Object>> {
    public MyAdapter(Context param1Context, List<HashMap<String, Object>> param1List) {
      super(param1Context, 2130903044, 2131099650, param1List);
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null)
        view = Lists.this.mLayoutInflater.inflate(2130903044, null); 
      ImageView imageView1 = (ImageView)view.findViewById(2131099648);
      TextView textView2 = (TextView)view.findViewById(2131099650);
      TextView textView1 = (TextView)view.findViewById(2131099651);
      ImageView imageView2 = (ImageView)view.findViewById(2131099652);
      HashMap hashMap = (HashMap)getItem(param1Int);
      textView2.setText(hashMap.get("title").toString());
      textView1.setText(hashMap.get("info").toString());
      imageView1.setImageResource(2130837566);
      imageView2.setImageResource(2130837505);
      if (param1Int % 2 == 0) {
        textView2.setTextColor(-65536);
        textView1.setTextColor(-1);
        return view;
      } 
      textView2.setTextColor(-1);
      textView1.setTextColor(-65536);
      return view;
    }
  }
  
  private class initPopupWindow extends TimerTask {
    private initPopupWindow() {}
    
    public void run() {
      Message message = new Message();
      message.what = 1;
      Lists.handler.sendMessage(message);
    }
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/Lists.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */