package com.zhangling.anTest20;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TabHost;
import android.widget.TextView;
import com.zhangling.util.ReflectUtil;

public class Main extends BaseAActivity {
  private static Handler handler;
  
  static Main main = null;
  
  private static TabHost tabHost = null;
  
  static {
    handler = new Handler() {
        public void handleMessage(Message param1Message) {
          super.handleMessage(param1Message);
          switch (param1Message.what) {
            default:
              return;
            case 0:
              break;
          } 
          Main.tabHost.setCurrentTab(0);
        }
      };
  }
  
  public static void sendMsg(int paramInt) {
    Message message = new Message();
    message.what = paramInt;
    handler.sendMessage(message);
  }
  
  public void exitDialog() {}
  
  public void onCreate(Bundle paramBundle) {
    requestWindowFeature(1);
    getWindow().setFlags(1024, 1024);
    requestWindowFeature(1);
    getWindow().setFlags(1024, 1024);
    super.onCreate(paramBundle);
    initData(getClass().getName());
    main = this;
    tabHost = getTabHost();
    tabHost.setBackgroundColor(0);
    tabHost.setBackgroundResource(2130837506);
    tabHost.setup();
    if (Build.VERSION.RELEASE.startsWith("1.5")) {
      tabHost.getTabWidget().setBackgroundColor(-1);
      tabHost.addTab(tabHost.newTabSpec("home").setIndicator("首页", getResources().getDrawable(2130837567)).setContent(new Intent((Context)this, Lists.class)));
      tabHost.addTab(tabHost.newTabSpec("booking").setIndicator("收藏", getResources().getDrawable(2130837568)).setContent(new Intent((Context)this, Booking.class)));
      tabHost.addTab(tabHost.newTabSpec("history").setIndicator("历史", getResources().getDrawable(2130837569)).setContent(new Intent((Context)this, History.class)));
      tabHost.addTab(tabHost.newTabSpec("query").setIndicator("搜索", getResources().getDrawable(2130837570)).setContent(new Intent((Context)this, Query.class)));
    } else {
      RelativeLayout relativeLayout2 = (RelativeLayout)LayoutInflater.from((Context)this).inflate(2130903052, null);
      TextView textView1 = (TextView)relativeLayout2.findViewById(2131099693);
      textView1.setText("主页");
      textView1.setBackgroundColor(-1);
      textView1.setBackgroundDrawable(getResources().getDrawable(2130837567));
      textView1.setTextSize(23.0F);
      textView1.getPaint().setFakeBoldText(true);
      textView1.setTextColor(-65536);
      try {
        TabHost.TabSpec tabSpec = tabHost.newTabSpec("tab1");
        ReflectUtil.runMethod(tabSpec, "setIndicator", View.class, relativeLayout2);
        Intent intent = new Intent();
        this((Context)this, Lists.class);
        tabSpec.setContent(intent);
        tabHost.addTab(tabSpec);
      } catch (Exception exception) {}
      relativeLayout2 = (RelativeLayout)LayoutInflater.from((Context)this).inflate(2130903052, null);
      textView1 = (TextView)relativeLayout2.findViewById(2131099693);
      textView1.setText("收藏");
      textView1.setBackgroundColor(-1);
      textView1.setBackgroundDrawable(getResources().getDrawable(2130837568));
      textView1.setTextSize(23.0F);
      textView1.getPaint().setFakeBoldText(true);
      textView1.setTextColor(-65536);
      try {
        TabHost.TabSpec tabSpec = tabHost.newTabSpec("tab2");
        ReflectUtil.runMethod(tabSpec, "setIndicator", View.class, relativeLayout2);
        Intent intent = new Intent();
        this((Context)this, Booking.class);
        tabSpec.setContent(intent);
        tabHost.addTab(tabSpec);
      } catch (Exception exception) {}
      relativeLayout2 = (RelativeLayout)LayoutInflater.from((Context)this).inflate(2130903052, null);
      textView1 = (TextView)relativeLayout2.findViewById(2131099693);
      textView1.setText("历史");
      textView1.setBackgroundColor(-1);
      textView1.setBackgroundDrawable(getResources().getDrawable(2130837569));
      textView1.setTextSize(23.0F);
      textView1.getPaint().setFakeBoldText(true);
      textView1.setTextColor(-65536);
      try {
        TabHost.TabSpec tabSpec = tabHost.newTabSpec("tab3");
        ReflectUtil.runMethod(tabSpec, "setIndicator", View.class, relativeLayout2);
        Intent intent = new Intent();
        this((Context)this, History.class);
        tabSpec.setContent(intent);
        tabHost.addTab(tabSpec);
      } catch (Exception exception) {}
      RelativeLayout relativeLayout1 = (RelativeLayout)LayoutInflater.from((Context)this).inflate(2130903052, null);
      TextView textView2 = (TextView)relativeLayout1.findViewById(2131099693);
      textView2.setText("搜索");
      textView2.setBackgroundColor(-1);
      textView2.setBackgroundDrawable(getResources().getDrawable(2130837570));
      textView2.setTextSize(23.0F);
      textView2.getPaint().setFakeBoldText(true);
      textView2.setTextColor(-65536);
      try {
        TabHost.TabSpec tabSpec = tabHost.newTabSpec("tab4");
        ReflectUtil.runMethod(tabSpec, "setIndicator", View.class, relativeLayout1);
        Intent intent = new Intent();
        this((Context)this, Query.class);
        tabSpec.setContent(intent);
        tabHost.addTab(tabSpec);
      } catch (Exception exception) {}
    } 
    tabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
          public void onTabChanged(String param1String) {
            int i = Main.tabHost.getCurrentTab();
            if (i == 0) {
              Lists.showPop();
            } else {
              Lists.hiddenPop();
            } 
            if (2 == i && History.history != null)
              History.history.expandableListView(); 
            if (1 == i && Booking.booking != null)
              Booking.booking.initData(); 
          }
        });
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4) {
      sendMsg(0);
      return false;
    } 
    return true;
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/Main.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */