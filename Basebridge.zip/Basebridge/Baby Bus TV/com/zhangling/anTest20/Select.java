package com.zhangling.anTest20;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.zhangling.util.Logs;
import com.zhangling.util.ReflectUtil;
import com.zhangling.util.StringUtil;
import java.util.ArrayList;
import java.util.List;

public class Select extends BaseActivity {
  private static final String[] GENRES;
  
  private static Handler handler;
  
  public static Select select = null;
  
  List<String> al = new ArrayList<String>();
  
  List<String> al_data = new ArrayList<String>();
  
  int index = 0;
  
  ListView listView = null;
  
  private ProgressBar progressBar = null;
  
  int res = 0;
  
  private TextView resultView = null;
  
  TextView textView = null;
  
  private int tmp = 0;
  
  static {
    GENRES = new String[] { "是", "否" };
    handler = new Handler() {
        public void handleMessage(Message param1Message) {
          Select select;
          switch (param1Message.what) {
            default:
              return;
            case 1:
              select = Select.select;
              select.tmp = select.tmp + 1;
              Select.select.loadData();
            case 2:
              break;
          } 
          Select.select.gotoRes();
        }
      };
  }
  
  private void gotoRes() {
    Intent intent = new Intent((Context)select, SelectRes.class);
    byte b = 0;
    if (select.res != 0)
      if (select.al_data.size() == select.res) {
        b = 1;
      } else {
        b = 2;
      }  
    intent.putExtra("res", b);
    intent.putExtra("index", select.index);
    select.startActivity(intent);
    select.finish();
  }
  
  private void loadData() {
    if (this.tmp < this.al_data.size()) {
      String str = this.al_data.get(this.tmp);
      this.textView.setText(StringUtil.unTihuan(str));
      ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>((Context)this, 17367055, GENRES) {
          public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
            CheckedTextView checkedTextView = (CheckedTextView)super.getView(param1Int, param1View, param1ViewGroup);
            checkedTextView.setTextColor(-16777216);
            return (View)checkedTextView;
          }
        };
      this.listView.setAdapter((ListAdapter)arrayAdapter);
      this.progressBar.setProgress(this.tmp);
      this.resultView.setText("当前进度：" + this.tmp + "/" + select.al_data.size());
    } 
  }
  
  public static void sendMsg(int paramInt) {
    Message message = new Message();
    message.what = paramInt;
    handler.sendMessage(message);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    select = this;
    try {
      this.index = getIntent().getExtras().getInt("index");
    } catch (Exception exception) {
      Logs.out(exception);
    } 
    this.listView = new ListView((Context)this);
    wakeLockOn();
    LinearLayout linearLayout1 = new LinearLayout((Context)this);
    setTitle(getString(ReflectUtil.getInt(R.string.class, "listView_title_" + this.index).intValue()));
    linearLayout1.setOrientation(1);
    linearLayout1.setBackgroundResource(2130837506);
    this.listView.setItemsCanFocus(false);
    this.listView.setChoiceMode(1);
    this.listView.setCacheColorHint(0);
    this.textView = new TextView((Context)this);
    this.textView.setBackgroundColor(0);
    this.textView.setTextSize(23.0F);
    this.textView.getPaint().setFakeBoldText(true);
    this.textView.setTextColor(-65536);
    String[] arrayOfString = getString(ReflectUtil.getInt(R.string.class, "listView_content_" + this.index).intValue()).split("-");
    if (this.al_data.size() == 0) {
      byte b = 0;
      while (true) {
        if (b < arrayOfString.length) {
          if (!"".equals(arrayOfString[b].trim()))
            this.al_data.add(arrayOfString[b]); 
          b++;
          continue;
        } 
        this.progressBar = new ProgressBar((Context)this, null, 16842872);
        this.progressBar.setMax(arrayOfString.length);
        this.resultView = new TextView((Context)this);
        this.resultView.setGravity(17);
        this.resultView.setTextColor(-16777216);
        this.resultView.setTextSize(23.0F);
        layoutParams1 = new AbsListView.LayoutParams(-1, -1);
        LinearLayout linearLayout4 = new LinearLayout((Context)this);
        AbsListView.LayoutParams layoutParams5 = new AbsListView.LayoutParams(-1, -2);
        linearLayout4.addView((View)this.textView, (ViewGroup.LayoutParams)layoutParams5);
        this.textView.setGravity(17);
        linearLayout1.addView((View)linearLayout4);
        LinearLayout linearLayout5 = new LinearLayout((Context)this);
        AbsListView.LayoutParams layoutParams4 = new AbsListView.LayoutParams(-1, 230);
        linearLayout5.addView((View)this.listView, (ViewGroup.LayoutParams)layoutParams4);
        linearLayout1.addView((View)linearLayout5);
        linearLayout5 = new LinearLayout((Context)this);
        layoutParams4 = new AbsListView.LayoutParams(-1, 30);
        linearLayout5.addView((View)this.progressBar, (ViewGroup.LayoutParams)layoutParams4);
        linearLayout1.addView((View)linearLayout5);
        linearLayout1.addView((View)this.resultView);
        addContentView((View)linearLayout1, (ViewGroup.LayoutParams)layoutParams1);
        this.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
              public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
                Select select = Select.this;
                select.res += param1Int;
                (new Thread(new Runnable() {
                      public void run() {
                        try {
                          if ((Select.null.access$0(Select.null.this)).tmp < (Select.null.access$0(Select.null.this)).al_data.size() - 1) {
                            Thread.sleep(200L);
                            Select.sendMsg(1);
                            return;
                          } 
                          if ((Select.null.access$0(Select.null.this)).tmp == (Select.null.access$0(Select.null.this)).al_data.size() - 1)
                            Select.sendMsg(2); 
                        } catch (Exception exception) {
                          exception.printStackTrace();
                        } 
                      }
                    })).start();
              }
            });
        loadData();
        return;
      } 
    } 
    this.progressBar = new ProgressBar((Context)this, null, 16842872);
    this.progressBar.setMax(layoutParams1.length);
    this.resultView = new TextView((Context)this);
    this.resultView.setGravity(17);
    this.resultView.setTextColor(-16777216);
    this.resultView.setTextSize(23.0F);
    AbsListView.LayoutParams layoutParams1 = new AbsListView.LayoutParams(-1, -1);
    LinearLayout linearLayout2 = new LinearLayout((Context)this);
    AbsListView.LayoutParams layoutParams3 = new AbsListView.LayoutParams(-1, -2);
    linearLayout2.addView((View)this.textView, (ViewGroup.LayoutParams)layoutParams3);
    this.textView.setGravity(17);
    linearLayout1.addView((View)linearLayout2);
    LinearLayout linearLayout3 = new LinearLayout((Context)this);
    AbsListView.LayoutParams layoutParams2 = new AbsListView.LayoutParams(-1, 230);
    linearLayout3.addView((View)this.listView, (ViewGroup.LayoutParams)layoutParams2);
    linearLayout1.addView((View)linearLayout3);
    linearLayout3 = new LinearLayout((Context)this);
    layoutParams2 = new AbsListView.LayoutParams(-1, 30);
    linearLayout3.addView((View)this.progressBar, (ViewGroup.LayoutParams)layoutParams2);
    linearLayout1.addView((View)linearLayout3);
    linearLayout1.addView((View)this.resultView);
    addContentView((View)linearLayout1, (ViewGroup.LayoutParams)layoutParams1);
    this.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
          public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
            Select select = Select.this;
            select.res += param1Int;
            (new Thread(new Runnable() {
                  public void run() {
                    try {
                      if ((Select.null.access$0(Select.null.this)).tmp < (Select.null.access$0(Select.null.this)).al_data.size() - 1) {
                        Thread.sleep(200L);
                        Select.sendMsg(1);
                        return;
                      } 
                      if ((Select.null.access$0(Select.null.this)).tmp == (Select.null.access$0(Select.null.this)).al_data.size() - 1)
                        Select.sendMsg(2); 
                    } catch (Exception exception) {
                      exception.printStackTrace();
                    } 
                  }
                })).start();
          }
        });
    loadData();
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/Select.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */