package com.zhangling.anTest20;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

public class ColorPickerDialog extends AlertDialog {
  private ColorPickerView colorPickView;
  
  private Context context;
  
  private int mInitialColor;
  
  private OnColorChangedListener mListener;
  
  public ColorPickerDialog(Context paramContext, OnColorChangedListener paramOnColorChangedListener, int paramInt) {
    super(paramContext);
    this.context = paramContext;
    this.mListener = paramOnColorChangedListener;
    this.mInitialColor = paramInt;
  }
  
  public ColorPickerDialog(Context paramContext, OnColorChangedListener paramOnColorChangedListener, String paramString) {
    super(paramContext);
    this.context = paramContext;
    this.mListener = paramOnColorChangedListener;
    this.mInitialColor = Color.parseColor(paramString);
  }
  
  protected void onCreate(Bundle paramBundle) {
    OnColorChangedListener onColorChangedListener = new OnColorChangedListener() {
        public void colorChanged(int param1Int) {
          ColorPickerDialog.this.mListener.colorChanged(param1Int);
        }
      };
    LinearLayout linearLayout = new LinearLayout(this.context);
    linearLayout.setPadding(5, 5, 5, 5);
    linearLayout.setOrientation(1);
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
    layoutParams.gravity = 17;
    this.colorPickView = new ColorPickerView(this.context, onColorChangedListener, this.mInitialColor);
    this.colorPickView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
    linearLayout.addView(this.colorPickView);
    setView((View)linearLayout);
    setTitle("请选择颜色：");
    setButton("确定", new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {
            ColorPickerDialog.this.mListener.colorChanged(ColorPickerDialog.this.colorPickView.mCenterPaint.getColor());
          }
        });
    setButton2("取消", new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {}
        });
    super.onCreate(paramBundle);
  }
  
  private static class ColorPickerView extends View {
    private static final int CENTER_RADIUS = 30;
    
    private static final int CENTER_X = 100;
    
    private static final int CENTER_Y = 100;
    
    private static final float PI = 3.1415925F;
    
    public Paint mCenterPaint;
    
    private final int[] mColors;
    
    private int[] mHSVColors;
    
    private Paint mHSVPaint;
    
    private boolean mHighlightCenter;
    
    private ColorPickerDialog.OnColorChangedListener mListener;
    
    private Paint mPaint;
    
    private boolean mRedrawHSV;
    
    private boolean mTrackingCenter;
    
    ColorPickerView(Context param1Context, ColorPickerDialog.OnColorChangedListener param1OnColorChangedListener, int param1Int) {
      super(param1Context);
      this.mListener = param1OnColorChangedListener;
      this.mColors = new int[] { -65536, -65281, -16776961, -16711681, -16711936, -256, -65536 };
      SweepGradient sweepGradient = new SweepGradient(0.0F, 0.0F, this.mColors, null);
      this.mPaint = new Paint(1);
      this.mPaint.setShader((Shader)sweepGradient);
      this.mPaint.setStyle(Paint.Style.STROKE);
      this.mPaint.setStrokeWidth(55.0F);
      this.mCenterPaint = new Paint(1);
      this.mCenterPaint.setColor(param1Int);
      this.mCenterPaint.setStrokeWidth(5.0F);
      this.mHSVColors = new int[] { -16777216, param1Int, -1 };
      this.mHSVPaint = new Paint(1);
      this.mHSVPaint.setStrokeWidth(10.0F);
      this.mRedrawHSV = true;
    }
    
    private int ave(int param1Int1, int param1Int2, float param1Float) {
      return Math.round((param1Int2 - param1Int1) * param1Float) + param1Int1;
    }
    
    private int interpColor(int[] param1ArrayOfint, float param1Float) {
      if (param1Float <= 0.0F)
        return param1ArrayOfint[0]; 
      if (param1Float >= 1.0F)
        return param1ArrayOfint[param1ArrayOfint.length - 1]; 
      param1Float *= (param1ArrayOfint.length - 1);
      int i = (int)param1Float;
      param1Float -= i;
      null = param1ArrayOfint[i];
      i = param1ArrayOfint[i + 1];
      return Color.argb(ave(Color.alpha(null), Color.alpha(i), param1Float), ave(Color.red(null), Color.red(i), param1Float), ave(Color.green(null), Color.green(i), param1Float), ave(Color.blue(null), Color.blue(i), param1Float));
    }
    
    public int getColor() {
      return this.mCenterPaint.getColor();
    }
    
    protected void onDraw(Canvas param1Canvas) {
      float f = 100.0F - this.mPaint.getStrokeWidth() * 0.5F;
      param1Canvas.translate(100.0F, 100.0F);
      int i = this.mCenterPaint.getColor();
      if (this.mRedrawHSV) {
        this.mHSVColors[1] = i;
        this.mHSVPaint.setShader((Shader)new LinearGradient(-100.0F, 0.0F, 100.0F, 0.0F, this.mHSVColors, null, Shader.TileMode.CLAMP));
      } 
      param1Canvas.drawOval(new RectF(-f, -f, f, f), this.mPaint);
      param1Canvas.drawCircle(0.0F, 0.0F, 30.0F, this.mCenterPaint);
      param1Canvas.drawRect(new RectF(-100.0F, 130.0F, 100.0F, 110.0F), this.mHSVPaint);
      if (this.mTrackingCenter) {
        this.mCenterPaint.setStyle(Paint.Style.STROKE);
        if (this.mHighlightCenter) {
          this.mCenterPaint.setAlpha(255);
        } else {
          this.mCenterPaint.setAlpha(128);
        } 
        param1Canvas.drawCircle(0.0F, 0.0F, this.mCenterPaint.getStrokeWidth() + 30.0F, this.mCenterPaint);
        this.mCenterPaint.setStyle(Paint.Style.FILL);
        this.mCenterPaint.setColor(i);
      } 
      this.mRedrawHSV = true;
    }
    
    protected void onMeasure(int param1Int1, int param1Int2) {
      setMeasuredDimension(200, 250);
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      boolean bool;
      int i;
      int j;
      float f1 = param1MotionEvent.getX() - 100.0F;
      float f2 = param1MotionEvent.getY() - 100.0F;
      if (Math.sqrt((f1 * f1 + f2 * f2)) <= 30.0D) {
        bool = true;
      } else {
        bool = false;
      } 
      switch (param1MotionEvent.getAction()) {
        default:
          return true;
        case 0:
          this.mTrackingCenter = bool;
          if (bool) {
            this.mHighlightCenter = true;
            invalidate();
          } 
        case 2:
          if (this.mTrackingCenter)
            if (this.mHighlightCenter != bool) {
              this.mHighlightCenter = bool;
              invalidate();
            }  
          if (f1 >= -100.0F) {
            i = 1;
          } else {
            i = 0;
          } 
          if (f1 <= 100.0F) {
            j = 1;
          } else {
            j = 0;
          } 
          if ((i & j) != 0 && f2 <= 130.0F && f2 >= 110.0F) {
            if (f1 < 0.0F) {
              j = this.mHSVColors[0];
              i = this.mHSVColors[1];
              f2 = (100.0F + f1) / 100.0F;
            } else {
              j = this.mHSVColors[1];
              i = this.mHSVColors[2];
              f2 = f1 / 100.0F;
            } 
            int k = ave(Color.alpha(j), Color.alpha(i), f2);
            int m = ave(Color.red(j), Color.red(i), f2);
            int n = ave(Color.green(j), Color.green(i), f2);
            i = ave(Color.blue(j), Color.blue(i), f2);
            this.mCenterPaint.setColor(Color.argb(k, m, n, i));
            this.mRedrawHSV = false;
            invalidate();
          } 
          f1 = (float)Math.atan2(f2, f1) / 6.283185F;
          f2 = f1;
          if (f1 < 0.0F)
            f2 = f1 + 1.0F; 
          this.mCenterPaint.setColor(interpColor(this.mColors, f2));
          invalidate();
        case 1:
          break;
      } 
      if (this.mTrackingCenter) {
        if (bool)
          this.mListener.colorChanged(this.mCenterPaint.getColor()); 
        this.mTrackingCenter = false;
        invalidate();
      } 
    }
  }
  
  public static interface OnColorChangedListener {
    void colorChanged(int param1Int);
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/ColorPickerDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */