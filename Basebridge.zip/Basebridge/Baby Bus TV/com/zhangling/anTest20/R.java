package com.zhangling.anTest20;

public final class R {
  public static final class array {
    public static final int Dialog = 2131034112;
    
    public static final int auto = 2131034113;
  }
  
  public static final class attr {}
  
  public static final class drawable {
    public static final int ans_icon_recharge = 2130837504;
    
    public static final int arrow_right = 2130837505;
    
    public static final int background = 2130837506;
    
    public static final int bg_main = 2130837507;
    
    public static final int bga = 2130837508;
    
    public static final int button_n = 2130837509;
    
    public static final int button_p = 2130837510;
    
    public static final int button_select_off_normal = 2130837511;
    
    public static final int button_select_on_normal = 2130837512;
    
    public static final int buttonselector = 2130837513;
    
    public static final int compart = 2130837514;
    
    public static final int divider = 2130837515;
    
    public static final int h1 = 2130837516;
    
    public static final int h2 = 2130837517;
    
    public static final int h3 = 2130837518;
    
    public static final int h4 = 2130837519;
    
    public static final int h5 = 2130837520;
    
    public static final int h6 = 2130837521;
    
    public static final int h7 = 2130837522;
    
    public static final int h8 = 2130837523;
    
    public static final int h9 = 2130837524;
    
    public static final int i1 = 2130837525;
    
    public static final int i2 = 2130837526;
    
    public static final int i3 = 2130837527;
    
    public static final int icon = 2130837528;
    
    public static final int img1 = 2130837529;
    
    public static final int item_bk = 2130837530;
    
    public static final int listbackground = 2130837531;
    
    public static final int lists_pop_button_p = 2130837532;
    
    public static final int lists_pop_divider = 2130837533;
    
    public static final int lits_pop_button_n = 2130837534;
    
    public static final int menu_about = 2130837535;
    
    public static final int menu_add = 2130837536;
    
    public static final int menu_disconnect = 2130837537;
    
    public static final int menu_icon_refresh_status = 2130837538;
    
    public static final int menu_icon_settings_normal = 2130837539;
    
    public static final int minitab = 2130837540;
    
    public static final int p10 = 2130837541;
    
    public static final int p2 = 2130837542;
    
    public static final int p3 = 2130837543;
    
    public static final int p4 = 2130837544;
    
    public static final int p5 = 2130837545;
    
    public static final int p6 = 2130837546;
    
    public static final int p7 = 2130837547;
    
    public static final int p8 = 2130837548;
    
    public static final int p9 = 2130837549;
    
    public static final int picture_frame = 2130837550;
    
    public static final int point = 2130837551;
    
    public static final int sa_icon_point = 2130837552;
    
    public static final int sample_p1 = 2130837553;
    
    public static final int sample_p10 = 2130837554;
    
    public static final int sample_p2 = 2130837555;
    
    public static final int sample_p3 = 2130837556;
    
    public static final int sample_p4 = 2130837557;
    
    public static final int sample_p5 = 2130837558;
    
    public static final int sample_p6 = 2130837559;
    
    public static final int sample_p7 = 2130837560;
    
    public static final int sample_p8 = 2130837561;
    
    public static final int sample_p9 = 2130837562;
    
    public static final int select = 2130837563;
    
    public static final int select_complete = 2130837564;
    
    public static final int shape = 2130837565;
    
    public static final int songimage_bg = 2130837566;
    
    public static final int tab1 = 2130837567;
    
    public static final int tab2 = 2130837568;
    
    public static final int tab3 = 2130837569;
    
    public static final int tab4 = 2130837570;
    
    public static final int textview1 = 2130837571;
    
    public static final int textview2 = 2130837572;
    
    public static final int textview3 = 2130837573;
    
    public static final int textview4 = 2130837574;
  }
  
  public static final class id {
    public static final int ItemText = 2131099665;
    
    public static final int RelativeLayout01 = 2131099664;
    
    public static final int background = 2131099689;
    
    public static final int both = 2131099671;
    
    public static final int button_query = 2131099696;
    
    public static final int cancelautologin = 2131099667;
    
    public static final int consume = 2131099673;
    
    public static final int count = 2131099681;
    
    public static final int dialog = 2131099653;
    
    public static final int editText01 = 2131099659;
    
    public static final int exit = 2131099684;
    
    public static final int gallery = 2131099688;
    
    public static final int guid = 2131099679;
    
    public static final int guidbtn = 2131099680;
    
    public static final int img = 2131099648;
    
    public static final int img1 = 2131099652;
    
    public static final int info = 2131099651;
    
    public static final int l = 2131099686;
    
    public static final int layout = 2131099691;
    
    public static final int listLinearLayout = 2131099655;
    
    public static final int list_radioImg = 2131099657;
    
    public static final int lists_pop_editText = 2131099662;
    
    public static final int lists_pop_nextBtn = 2131099663;
    
    public static final int lists_pop_previousBtn = 2131099661;
    
    public static final int listview01 = 2131099656;
    
    public static final int ll = 2131099649;
    
    public static final int llmainpage2 = 2131099694;
    
    public static final int loading = 2131099669;
    
    public static final int login = 2131099666;
    
    public static final int nextBtn = 2131099658;
    
    public static final int no = 2131099674;
    
    public static final int option_01 = 2131099675;
    
    public static final int option_02 = 2131099676;
    
    public static final int option_03 = 2131099677;
    
    public static final int pay = 2131099682;
    
    public static final int pay_result = 2131099685;
    
    public static final int payresult = 2131099683;
    
    public static final int previousBtn = 2131099660;
    
    public static final int prices = 2131099678;
    
    public static final int recharge = 2131099672;
    
    public static final int recharge_group = 2131099670;
    
    public static final int sc = 2131099690;
    
    public static final int switcher = 2131099687;
    
    public static final int tab_label = 2131099693;
    
    public static final int text1 = 2131099692;
    
    public static final int textView_query = 2131099695;
    
    public static final int title = 2131099650;
    
    public static final int tvname = 2131099654;
    
    public static final int usercenter = 2131099668;
  }
  
  public static final class layout {
    public static final int booking = 2130903040;
    
    public static final int exit_dialog = 2130903041;
    
    public static final int list = 2130903042;
    
    public static final int list1 = 2130903043;
    
    public static final int list_item = 2130903044;
    
    public static final int list_pop = 2130903045;
    
    public static final int lists_pop = 2130903046;
    
    public static final int lists_select_items = 2130903047;
    
    public static final int main = 2130903048;
    
    public static final int main1 = 2130903049;
    
    public static final int main2 = 2130903050;
    
    public static final int mainn = 2130903051;
    
    public static final int minitab = 2130903052;
    
    public static final int query = 2130903053;
  }
  
  public static final class string {
    public static final int app_about = 2130968687;
    
    public static final int app_about_msg = 2130968686;
    
    public static final int app_name = 2130968682;
    
    public static final int body = 2130968690;
    
    public static final int body1 = 2130968691;
    
    public static final int hello = 2130968681;
    
    public static final int listView_add_0 = 2130968577;
    
    public static final int listView_add_1 = 2130968581;
    
    public static final int listView_add_10 = 2130968617;
    
    public static final int listView_add_11 = 2130968621;
    
    public static final int listView_add_12 = 2130968625;
    
    public static final int listView_add_13 = 2130968629;
    
    public static final int listView_add_14 = 2130968633;
    
    public static final int listView_add_15 = 2130968637;
    
    public static final int listView_add_16 = 2130968641;
    
    public static final int listView_add_17 = 2130968645;
    
    public static final int listView_add_18 = 2130968649;
    
    public static final int listView_add_19 = 2130968653;
    
    public static final int listView_add_2 = 2130968585;
    
    public static final int listView_add_20 = 2130968657;
    
    public static final int listView_add_21 = 2130968661;
    
    public static final int listView_add_22 = 2130968665;
    
    public static final int listView_add_23 = 2130968669;
    
    public static final int listView_add_24 = 2130968673;
    
    public static final int listView_add_25 = 2130968677;
    
    public static final int listView_add_3 = 2130968589;
    
    public static final int listView_add_4 = 2130968593;
    
    public static final int listView_add_5 = 2130968597;
    
    public static final int listView_add_6 = 2130968601;
    
    public static final int listView_add_7 = 2130968605;
    
    public static final int listView_add_8 = 2130968609;
    
    public static final int listView_add_9 = 2130968613;
    
    public static final int listView_content_0 = 2130968578;
    
    public static final int listView_content_1 = 2130968582;
    
    public static final int listView_content_10 = 2130968618;
    
    public static final int listView_content_11 = 2130968622;
    
    public static final int listView_content_12 = 2130968626;
    
    public static final int listView_content_13 = 2130968630;
    
    public static final int listView_content_14 = 2130968634;
    
    public static final int listView_content_15 = 2130968638;
    
    public static final int listView_content_16 = 2130968642;
    
    public static final int listView_content_17 = 2130968646;
    
    public static final int listView_content_18 = 2130968650;
    
    public static final int listView_content_19 = 2130968654;
    
    public static final int listView_content_2 = 2130968586;
    
    public static final int listView_content_20 = 2130968658;
    
    public static final int listView_content_21 = 2130968662;
    
    public static final int listView_content_22 = 2130968666;
    
    public static final int listView_content_23 = 2130968670;
    
    public static final int listView_content_24 = 2130968674;
    
    public static final int listView_content_25 = 2130968678;
    
    public static final int listView_content_3 = 2130968590;
    
    public static final int listView_content_4 = 2130968594;
    
    public static final int listView_content_5 = 2130968598;
    
    public static final int listView_content_6 = 2130968602;
    
    public static final int listView_content_7 = 2130968606;
    
    public static final int listView_content_8 = 2130968610;
    
    public static final int listView_content_9 = 2130968614;
    
    public static final int listView_select_res_0 = 2130968579;
    
    public static final int listView_select_res_1 = 2130968583;
    
    public static final int listView_select_res_10 = 2130968619;
    
    public static final int listView_select_res_11 = 2130968623;
    
    public static final int listView_select_res_12 = 2130968627;
    
    public static final int listView_select_res_13 = 2130968631;
    
    public static final int listView_select_res_14 = 2130968635;
    
    public static final int listView_select_res_15 = 2130968639;
    
    public static final int listView_select_res_16 = 2130968643;
    
    public static final int listView_select_res_17 = 2130968647;
    
    public static final int listView_select_res_18 = 2130968651;
    
    public static final int listView_select_res_19 = 2130968655;
    
    public static final int listView_select_res_2 = 2130968587;
    
    public static final int listView_select_res_20 = 2130968659;
    
    public static final int listView_select_res_21 = 2130968663;
    
    public static final int listView_select_res_22 = 2130968667;
    
    public static final int listView_select_res_23 = 2130968671;
    
    public static final int listView_select_res_24 = 2130968675;
    
    public static final int listView_select_res_25 = 2130968679;
    
    public static final int listView_select_res_3 = 2130968591;
    
    public static final int listView_select_res_4 = 2130968595;
    
    public static final int listView_select_res_5 = 2130968599;
    
    public static final int listView_select_res_6 = 2130968603;
    
    public static final int listView_select_res_7 = 2130968607;
    
    public static final int listView_select_res_8 = 2130968611;
    
    public static final int listView_select_res_9 = 2130968615;
    
    public static final int listView_size = 2130968680;
    
    public static final int listView_title_0 = 2130968576;
    
    public static final int listView_title_1 = 2130968580;
    
    public static final int listView_title_10 = 2130968616;
    
    public static final int listView_title_11 = 2130968620;
    
    public static final int listView_title_12 = 2130968624;
    
    public static final int listView_title_13 = 2130968628;
    
    public static final int listView_title_14 = 2130968632;
    
    public static final int listView_title_15 = 2130968636;
    
    public static final int listView_title_16 = 2130968640;
    
    public static final int listView_title_17 = 2130968644;
    
    public static final int listView_title_18 = 2130968648;
    
    public static final int listView_title_19 = 2130968652;
    
    public static final int listView_title_2 = 2130968584;
    
    public static final int listView_title_20 = 2130968656;
    
    public static final int listView_title_21 = 2130968660;
    
    public static final int listView_title_22 = 2130968664;
    
    public static final int listView_title_23 = 2130968668;
    
    public static final int listView_title_24 = 2130968672;
    
    public static final int listView_title_25 = 2130968676;
    
    public static final int listView_title_3 = 2130968588;
    
    public static final int listView_title_4 = 2130968592;
    
    public static final int listView_title_5 = 2130968596;
    
    public static final int listView_title_6 = 2130968600;
    
    public static final int listView_title_7 = 2130968604;
    
    public static final int listView_title_8 = 2130968608;
    
    public static final int listView_title_9 = 2130968612;
    
    public static final int my_text_no = 2130968685;
    
    public static final int my_text_pre = 2130968684;
    
    public static final int setting = 2130968683;
    
    public static final int str_no = 2130968689;
    
    public static final int str_ok = 2130968688;
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */