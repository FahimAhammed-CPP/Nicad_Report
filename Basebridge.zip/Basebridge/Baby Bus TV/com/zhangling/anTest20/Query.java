package com.zhangling.anTest20;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.zhangling.util.Logs;
import com.zhangling.util.StringUtil;
import com.zhangling.util.Toasts;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Query extends BaseActivity {
  Button button = null;
  
  ListView listview = null;
  
  private LayoutInflater mLayoutInflater;
  
  Query query = null;
  
  TextView textView = null;
  
  public void initData() {
    MyAdapter myAdapter;
    ArrayList<HashMap<Object, Object>> arrayList = new ArrayList();
    CharSequence charSequence = this.textView.getText();
    if (!StringUtil.beKong(charSequence)) {
      String str = charSequence.toString();
      int i = Lists.al_viewlist_title.size();
      byte b = 0;
      while (true) {
        if (b < i) {
          HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
          charSequence = Lists.al_viewlist_title.get(b);
          if (-1 < charSequence.indexOf(str)) {
            hashMap.put("title", charSequence);
            hashMap.put("index", Integer.valueOf(b));
            hashMap.put("info", "");
            hashMap.put("img", Integer.valueOf(2130837566));
            hashMap.put("img1", Integer.valueOf(2130837505));
            arrayList.add(hashMap);
          } 
          b++;
          continue;
        } 
        if (arrayList.size() > 0) {
          myAdapter = new MyAdapter((Context)this, (List)arrayList);
          this.listview.setAdapter((ListAdapter)myAdapter);
          return;
        } 
        Toasts.malert((Context)this, "很抱歉，查询为空");
        return;
      } 
    } 
    if (myAdapter.size() > 0) {
      myAdapter = new MyAdapter((Context)this, (List<HashMap<String, Object>>)myAdapter);
      this.listview.setAdapter((ListAdapter)myAdapter);
      return;
    } 
    Toasts.malert((Context)this, "很抱歉，查询为空");
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.query = this;
    setContentView(2130903053);
    this.mLayoutInflater = LayoutInflater.from((Context)this);
    this.textView = (TextView)findViewById(2131099695);
    this.button = (Button)findViewById(2131099696);
    this.button.setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            Query.this.initData();
          }
        });
    this.textView.addTextChangedListener(new TextWatcher() {
          public void afterTextChanged(Editable param1Editable) {
            Query.this.initData();
          }
          
          public void beforeTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
          
          public void onTextChanged(CharSequence param1CharSequence, int param1Int1, int param1Int2, int param1Int3) {}
        });
    this.listview = (ListView)findViewById(2131099656);
    Toasts.lalert((Context)this, "请输入查询的文字");
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4) {
      Main.sendMsg(0);
      return false;
    } 
    return true;
  }
  
  class MyAdapter extends ArrayAdapter<HashMap<String, Object>> {
    public MyAdapter(Context param1Context, List<HashMap<String, Object>> param1List) {
      super(param1Context, 2130903044, 2131099650, param1List);
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null)
        view = Query.this.mLayoutInflater.inflate(2130903044, null); 
      ImageView imageView1 = (ImageView)view.findViewById(2131099648);
      TextView textView1 = (TextView)view.findViewById(2131099650);
      TextView textView2 = (TextView)view.findViewById(2131099651);
      ImageView imageView2 = (ImageView)view.findViewById(2131099652);
      HashMap hashMap = (HashMap)getItem(param1Int);
      textView1.setText(hashMap.get("title").toString());
      textView2.setText(hashMap.get("info").toString());
      imageView1.setImageResource(2130837566);
      imageView2.setImageResource(2130837505);
      if (param1Int % 2 == 0) {
        textView1.setTextColor(-65536);
        textView2.setTextColor(-1);
        view.setTag(hashMap.get("index").toString());
        view.setOnClickListener(new View.OnClickListener() {
              public void onClick(View param2View) {
                try {
                  String str = param2View.getTag().toString();
                  Intent intent = new Intent();
                  this();
                  intent.setClass((Context)Query.MyAdapter.access$0(Query.MyAdapter.this), Add.class);
                  intent.putExtra("index", Integer.parseInt(str));
                  Query.MyAdapter.access$0(Query.MyAdapter.this).startActivity(intent);
                } catch (Exception exception) {
                  Logs.out(exception);
                } 
              }
            });
        return view;
      } 
      textView1.setTextColor(-1);
      textView2.setTextColor(-65536);
      view.setTag(hashMap.get("index").toString());
      view.setOnClickListener(new View.OnClickListener() {
            public void onClick(View param2View) {
              try {
                String str = param2View.getTag().toString();
                Intent intent = new Intent();
                this();
                intent.setClass((Context)Query.MyAdapter.access$0(Query.MyAdapter.this), Add.class);
                intent.putExtra("index", Integer.parseInt(str));
                Query.MyAdapter.access$0(Query.MyAdapter.this).startActivity(intent);
              } catch (Exception exception) {
                Logs.out(exception);
              } 
            }
          });
      return view;
    }
  }
  
  final class null implements View.OnClickListener {
    public void onClick(View param1View) {
      try {
        String str = param1View.getTag().toString();
        Intent intent = new Intent();
        this();
        intent.setClass((Context)Query.MyAdapter.access$0(this.this$1), Add.class);
        intent.putExtra("index", Integer.parseInt(str));
        Query.MyAdapter.access$0(this.this$1).startActivity(intent);
      } catch (Exception exception) {
        Logs.out(exception);
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/Query.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */