package com.zhangling.anTest20;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.zhangling.util.Logs;
import com.zhangling.util.ReflectUtil;
import com.zhangling.util.StringUtil;

public class SelectRes extends Activity {
  String[] data = null;
  
  int index = 0;
  
  int res = 0;
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    try {
      paramBundle = getIntent().getExtras();
      this.res = paramBundle.getInt("res");
      this.index = paramBundle.getInt("index");
      Logs.out(Integer.valueOf(this.res));
      Logs.out(Integer.valueOf(this.index));
    } catch (Exception exception) {
      Logs.out(exception);
    } 
    LinearLayout linearLayout1 = new LinearLayout((Context)this);
    linearLayout1.setOrientation(1);
    linearLayout1.setBackgroundResource(2130837506);
    ImageView imageView = new ImageView((Context)this);
    imageView.setImageResource(2130837564);
    TextView textView = new TextView((Context)this);
    textView.setBackgroundColor(0);
    textView.setTextSize(23.0F);
    textView.getPaint().setFakeBoldText(true);
    textView.setTextColor(-65536);
    LinearLayout linearLayout2 = new LinearLayout((Context)this);
    linearLayout2.addView((View)imageView, (ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, 200));
    linearLayout1.addView((View)linearLayout2);
    linearLayout2 = new LinearLayout((Context)this);
    linearLayout2.addView((View)textView, (ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, -2));
    textView.setGravity(17);
    linearLayout1.addView((View)linearLayout2);
    this.data = getString(ReflectUtil.getInt(R.string.class, "listView_select_res_" + this.index).intValue()).split("-");
    textView.setText(StringUtil.unTihuan(this.data[this.res]));
    addContentView((View)linearLayout1, (ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, -1));
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/SelectRes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */