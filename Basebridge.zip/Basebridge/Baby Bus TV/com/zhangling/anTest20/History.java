package com.zhangling.anTest20;

import android.app.ExpandableListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListAdapter;
import android.widget.TextView;
import com.zhangling.anTest01.db.HistoryInfo;
import com.zhangling.util.Logs;
import com.zhangling.util.ReflectUtil;
import com.zhangling.util.StringUtil;
import java.util.ArrayList;
import java.util.List;

public class History extends ExpandableListActivity {
  public static History history = null;
  
  public void expandableListView() {
    int i = getExpandableListAdapter().getGroupCount();
    for (byte b = 0;; b++) {
      if (b >= i) {
        for (b = 0;; b++) {
          if (b >= i)
            return; 
          getExpandableListView().expandGroup(b);
        } 
        break;
      } 
      getExpandableListView().collapseGroup(b);
    } 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    history = this;
    setListAdapter((ExpandableListAdapter)new demo1((Context)this));
    getExpandableListView().setCacheColorHint(0);
    expandableListView();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4) {
      Main.sendMsg(0);
      return false;
    } 
    return true;
  }
  
  public class demo1 extends BaseExpandableListAdapter {
    List<List<String>> dataListIds = new ArrayList<List<String>>();
    
    private List<String> groupList = new ArrayList<String>();
    
    private String[] groups = new String[] { "今天", "昨天", "昨天之前" };
    
    private Context mContext = null;
    
    public demo1(Context param1Context) {
      this.mContext = param1Context;
      getData();
    }
    
    private List<List<String>> getData() {
      HistoryInfo historyInfo = HistoryInfo.init(this.mContext, BaseActivity.getSp(), BaseActivity.getEditor());
      ArrayList<String> arrayList1 = new ArrayList();
      ArrayList<String> arrayList2 = new ArrayList();
      List<String> list = historyInfo.queryToday();
      int i = list.size();
      for (byte b = 0;; b++) {
        if (b >= i) {
          list = new ArrayList();
          ArrayList<String> arrayList = new ArrayList();
          List list1 = historyInfo.queryYesterday();
          i = list1.size();
          for (b = 0;; b++) {
            StringBuilder stringBuilder1;
            if (b >= i) {
              ArrayList<String> arrayList3 = new ArrayList();
              ArrayList<String> arrayList4 = new ArrayList();
              List<List<String>> list2 = historyInfo.queryYesterdayBefore();
              i = list2.size();
              for (b = 0;; b++) {
                if (b >= i) {
                  ArrayList<ArrayList> arrayList5 = new ArrayList();
                  arrayList5.add(arrayList1);
                  arrayList5.add(list);
                  arrayList5.add(arrayList3);
                  this.dataListIds.clear();
                  this.dataListIds.add(arrayList2);
                  this.dataListIds.add(arrayList);
                  this.dataListIds.add(arrayList4);
                  this.groupList.clear();
                  this.groupList.add(String.valueOf(this.groups[0]) + "(" + arrayList1.size() + ")");
                  this.groupList.add(String.valueOf(this.groups[1]) + "(" + list.size() + ")");
                  this.groupList.add(String.valueOf(this.groups[2]) + "(" + arrayList3.size() + ")");
                  return (List)arrayList5;
                } 
                String str8 = ((List<String>)list2.get(b)).get(0);
                String str9 = History.this.getResources().getString(ReflectUtil.getInt(R.string.class, "listView_title_" + str8).intValue());
                String str7 = ((List<String>)list2.get(b)).get(1);
                stringBuilder1 = new StringBuilder();
                stringBuilder1.append("(");
                stringBuilder1.append(StringUtil.getDist(Long.parseLong(str7)));
                stringBuilder1.append(")");
                stringBuilder1.append(str9);
                arrayList3.add(stringBuilder1.toString());
                arrayList4.add(str8);
              } 
              break;
            } 
            String str5 = ((List<String>)stringBuilder1.get(b)).get(0);
            String str6 = History.this.getResources().getString(ReflectUtil.getInt(R.string.class, "listView_title_" + str5).intValue());
            String str4 = ((List<String>)stringBuilder1.get(b)).get(1);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("(");
            stringBuilder2.append(StringUtil.getDist(Long.parseLong(str4)));
            stringBuilder2.append(")");
            stringBuilder2.append(str6);
            list.add(stringBuilder2.toString());
            arrayList.add(str5);
          } 
          break;
        } 
        String str2 = ((List<String>)list.get(b)).get(0);
        String str3 = History.this.getResources().getString(ReflectUtil.getInt(R.string.class, "listView_title_" + str2).intValue());
        String str1 = ((List<String>)list.get(b)).get(1);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("(");
        stringBuilder.append(StringUtil.getDist(Long.parseLong(str1)));
        stringBuilder.append(")");
        stringBuilder.append(str3);
        arrayList1.add(stringBuilder.toString());
        arrayList2.add(str2);
      } 
    }
    
    public Object getChild(int param1Int1, int param1Int2) {
      return ((List)getData().get(param1Int1)).get(param1Int2);
    }
    
    public long getChildId(int param1Int1, int param1Int2) {
      return 0L;
    }
    
    public View getChildView(int param1Int1, int param1Int2, boolean param1Boolean, View param1View, ViewGroup param1ViewGroup) {
      if (param1View == null) {
        textView = new TextView(this.mContext);
        textView.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, -2));
        textView.setTextSize(24.0F);
        textView.setGravity(19);
        textView.setPadding(45, 5, 5, 5);
        String str1 = ((List<String>)this.dataListIds.get(param1Int1)).get(param1Int2);
        Logs.p("tag: " + str1);
        textView.setTag(str1);
        textView.setTextColor(-16777216);
        textView.setText(((List<String>)getData().get(param1Int1)).get(param1Int2));
        textView.setOnClickListener(new View.OnClickListener() {
              public void onClick(View param2View) {
                Intent intent = new Intent();
                intent.setClass((Context)History.demo1.access$0(History.demo1.this), Add.class);
                intent.putExtra("index", Integer.parseInt(param2View.getTag().toString()));
                intent.putExtra("notSaveDate", "1");
                History.demo1.access$0(History.demo1.this).startActivity(intent);
              }
            });
        return (View)textView;
      } 
      TextView textView = textView;
      textView.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, -2));
      textView.setTextSize(24.0F);
      textView.setGravity(19);
      textView.setPadding(45, 5, 5, 5);
      String str = ((List<String>)this.dataListIds.get(param1Int1)).get(param1Int2);
      Logs.p("tag: " + str);
      textView.setTag(str);
      textView.setTextColor(-16777216);
      textView.setText(((List<String>)getData().get(param1Int1)).get(param1Int2));
      textView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View param2View) {
              Intent intent = new Intent();
              intent.setClass((Context)History.demo1.access$0(History.demo1.this), Add.class);
              intent.putExtra("index", Integer.parseInt(param2View.getTag().toString()));
              intent.putExtra("notSaveDate", "1");
              History.demo1.access$0(History.demo1.this).startActivity(intent);
            }
          });
      return (View)textView;
    }
    
    public int getChildrenCount(int param1Int) {
      return ((List)getData().get(param1Int)).size();
    }
    
    public Object getGroup(int param1Int) {
      return this.groupList.get(param1Int);
    }
    
    public int getGroupCount() {
      return this.groupList.size();
    }
    
    public long getGroupId(int param1Int) {
      return 0L;
    }
    
    public View getGroupView(int param1Int, boolean param1Boolean, View param1View, ViewGroup param1ViewGroup) {
      if (param1View == null) {
        textView = new TextView(this.mContext);
        String str1 = this.groupList.get(param1Int);
        textView.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, 40));
        textView.setTextSize(18.0F);
        textView.setGravity(19);
        textView.setPadding(36, 0, 0, 0);
        textView.setText(str1);
        textView.setTextColor(-16777216);
        return (View)textView;
      } 
      TextView textView = textView;
      String str = this.groupList.get(param1Int);
      textView.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, 40));
      textView.setTextSize(18.0F);
      textView.setGravity(19);
      textView.setPadding(36, 0, 0, 0);
      textView.setText(str);
      textView.setTextColor(-16777216);
      return (View)textView;
    }
    
    public boolean hasStableIds() {
      return false;
    }
    
    public boolean isChildSelectable(int param1Int1, int param1Int2) {
      return false;
    }
  }
  
  final class null implements View.OnClickListener {
    public void onClick(View param1View) {
      Intent intent = new Intent();
      intent.setClass((Context)History.demo1.access$0(this.this$1), Add.class);
      intent.putExtra("index", Integer.parseInt(param1View.getTag().toString()));
      intent.putExtra("notSaveDate", "1");
      History.demo1.access$0(this.this$1).startActivity(intent);
    }
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/History.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */