package com.zhangling.anTest20;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ScrollView;
import android.widget.TextView;
import com.zhangling.anTest01.db.HistoryInfo;
import java.util.List;

public class Test extends Activity {
  public static SharedPreferences.Editor editor;
  
  public static SharedPreferences sp;
  
  public static Test test = null;
  
  private int MODE = 3;
  
  ScrollView scrollView = null;
  
  TextView textView = null;
  
  static {
    sp = null;
    editor = null;
  }
  
  public void initData() {
    this.scrollView = new ScrollView((Context)this);
    StringBuilder stringBuilder = new StringBuilder();
    List<List<String>> list = HistoryInfo.init((Context)this, sp, editor).queryAll3();
    byte b = 0;
    label13: while (true) {
      if (b >= list.size()) {
        this.textView.setText(stringBuilder.toString());
        return;
      } 
      for (byte b1 = 0;; b1++) {
        if (b1 >= ((List)list.get(b)).size()) {
          stringBuilder.append("\n");
          stringBuilder.append("\n");
          b++;
          continue label13;
        } 
        stringBuilder.append(((List<String>)list.get(b)).get(b1));
        stringBuilder.append("\n");
      } 
      break;
    } 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    this.textView = new TextView((Context)this);
    this.textView.setText("测试");
    initData();
    this.scrollView.addView((View)this.textView);
    AbsListView.LayoutParams layoutParams = new AbsListView.LayoutParams(-1, -1);
    addContentView((View)this.scrollView, (ViewGroup.LayoutParams)layoutParams);
    test = this;
    if (sp == null)
      sp = getSharedPreferences(getPackageName(), this.MODE); 
    if (editor == null)
      editor = sp.edit(); 
  }
}


/* Location:              /home/fahim/Desktop/Basebridge3-dex2jar.jar!/com/zhangling/anTest20/Test.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */