package com.tencent.bugly.legu;

import android.content.Context;

public class Bugly {
  public static final String SDK_IS_DEV = "false";
  
  private static boolean a;
  
  public static Context applicationContext;
  
  private static String[] b;
  
  private static String[] c;
  
  public static boolean enable = true;
  
  public static Boolean isDev;
  
  static {
    applicationContext = null;
    b = new String[] { "BuglyCrashModule", "BuglyRqdModule", "BuglyBetaModule" };
    c = new String[] { "BuglyRqdModule", "BuglyCrashModule", "BuglyBetaModule" };
  }
  
  public static String getAppChannel() {
    // Byte code:
    //   0: aconst_null
    //   1: astore_0
    //   2: ldc com/tencent/bugly/legu/Bugly
    //   4: monitorenter
    //   5: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   8: astore_1
    //   9: aload_1
    //   10: ifnonnull -> 18
    //   13: ldc com/tencent/bugly/legu/Bugly
    //   15: monitorexit
    //   16: aload_0
    //   17: areturn
    //   18: aload_1
    //   19: getfield j : Ljava/lang/String;
    //   22: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   25: ifeq -> 86
    //   28: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   31: astore_0
    //   32: aload_0
    //   33: ifnonnull -> 44
    //   36: aload_1
    //   37: getfield j : Ljava/lang/String;
    //   40: astore_0
    //   41: goto -> 13
    //   44: aload_0
    //   45: sipush #556
    //   48: aconst_null
    //   49: iconst_1
    //   50: invokevirtual a : (ILcom/tencent/bugly/legu/proguard/n;Z)Ljava/util/Map;
    //   53: astore_0
    //   54: aload_0
    //   55: ifnull -> 86
    //   58: aload_0
    //   59: ldc 'app_channel'
    //   61: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   66: checkcast [B
    //   69: astore_0
    //   70: aload_0
    //   71: ifnull -> 86
    //   74: new java/lang/String
    //   77: dup
    //   78: aload_0
    //   79: invokespecial <init> : ([B)V
    //   82: astore_0
    //   83: goto -> 13
    //   86: aload_1
    //   87: getfield j : Ljava/lang/String;
    //   90: astore_0
    //   91: goto -> 13
    //   94: astore_0
    //   95: ldc com/tencent/bugly/legu/Bugly
    //   97: monitorexit
    //   98: aload_0
    //   99: athrow
    // Exception table:
    //   from	to	target	type
    //   5	9	94	finally
    //   18	32	94	finally
    //   36	41	94	finally
    //   44	54	94	finally
    //   58	70	94	finally
    //   74	83	94	finally
    //   86	91	94	finally
  }
  
  public static void init(Context paramContext, String paramString, boolean paramBoolean) {
    init(paramContext, paramString, paramBoolean, null);
  }
  
  public static void init(Context paramContext, String paramString, boolean paramBoolean, BuglyStrategy paramBuglyStrategy) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/Bugly
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/Bugly.a : Z
    //   6: istore #4
    //   8: iload #4
    //   10: ifeq -> 17
    //   13: ldc com/tencent/bugly/legu/Bugly
    //   15: monitorexit
    //   16: return
    //   17: iconst_1
    //   18: putstatic com/tencent/bugly/legu/Bugly.a : Z
    //   21: aload_0
    //   22: ifnonnull -> 51
    //   25: aload_0
    //   26: putstatic com/tencent/bugly/legu/Bugly.applicationContext : Landroid/content/Context;
    //   29: aload_0
    //   30: ifnonnull -> 68
    //   33: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   36: ldc 'init arg 'context' should not be null!'
    //   38: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   41: pop
    //   42: goto -> 13
    //   45: astore_0
    //   46: ldc com/tencent/bugly/legu/Bugly
    //   48: monitorexit
    //   49: aload_0
    //   50: athrow
    //   51: aload_0
    //   52: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   55: astore #5
    //   57: aload #5
    //   59: ifnull -> 25
    //   62: aload #5
    //   64: astore_0
    //   65: goto -> 25
    //   68: invokestatic isDev : ()Z
    //   71: ifeq -> 80
    //   74: getstatic com/tencent/bugly/legu/Bugly.c : [Ljava/lang/String;
    //   77: putstatic com/tencent/bugly/legu/Bugly.b : [Ljava/lang/String;
    //   80: getstatic com/tencent/bugly/legu/Bugly.b : [Ljava/lang/String;
    //   83: astore_0
    //   84: aload_0
    //   85: arraylength
    //   86: istore #6
    //   88: iconst_0
    //   89: istore #7
    //   91: iload #7
    //   93: iload #6
    //   95: if_icmpge -> 168
    //   98: aload_0
    //   99: iload #7
    //   101: aaload
    //   102: astore #5
    //   104: aload #5
    //   106: ldc 'BuglyCrashModule'
    //   108: invokevirtual equals : (Ljava/lang/Object;)Z
    //   111: ifeq -> 126
    //   114: invokestatic getInstance : ()Lcom/tencent/bugly/legu/CrashModule;
    //   117: invokestatic a : (Lcom/tencent/bugly/legu/a;)V
    //   120: iinc #7, 1
    //   123: goto -> 91
    //   126: aload #5
    //   128: ldc 'BuglyBetaModule'
    //   130: invokevirtual equals : (Ljava/lang/Object;)Z
    //   133: ifne -> 120
    //   136: aload #5
    //   138: ldc 'BuglyRqdModule'
    //   140: invokevirtual equals : (Ljava/lang/Object;)Z
    //   143: ifne -> 120
    //   146: aload #5
    //   148: ldc 'BuglyFeedbackModule'
    //   150: invokevirtual equals : (Ljava/lang/Object;)Z
    //   153: pop
    //   154: goto -> 120
    //   157: astore #5
    //   159: aload #5
    //   161: invokestatic b : (Ljava/lang/Throwable;)Z
    //   164: pop
    //   165: goto -> 120
    //   168: getstatic com/tencent/bugly/legu/Bugly.enable : Z
    //   171: putstatic com/tencent/bugly/legu/b.a : Z
    //   174: getstatic com/tencent/bugly/legu/Bugly.applicationContext : Landroid/content/Context;
    //   177: aload_1
    //   178: iload_2
    //   179: aload_3
    //   180: invokestatic a : (Landroid/content/Context;Ljava/lang/String;ZLcom/tencent/bugly/legu/BuglyStrategy;)V
    //   183: goto -> 13
    // Exception table:
    //   from	to	target	type
    //   3	8	45	finally
    //   17	21	45	finally
    //   25	29	45	finally
    //   33	42	45	finally
    //   51	57	45	finally
    //   68	80	45	finally
    //   80	88	45	finally
    //   104	120	157	java/lang/Throwable
    //   104	120	45	finally
    //   126	154	157	java/lang/Throwable
    //   126	154	45	finally
    //   159	165	45	finally
    //   168	183	45	finally
  }
  
  public static boolean isDev() {
    if (isDev == null)
      isDev = Boolean.valueOf(Boolean.parseBoolean("false".replace("@", ""))); 
    return isDev.booleanValue();
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/Bugly.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */