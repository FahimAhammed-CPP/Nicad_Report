package com.tencent.bugly.legu;

import android.content.Context;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.proguard.m;
import com.tencent.bugly.legu.proguard.o;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class b {
  public static boolean a = true;
  
  public static boolean b;
  
  public static Map<String, String> c;
  
  private static List<a> d = new ArrayList<a>();
  
  private static o e;
  
  private static m f;
  
  private static boolean g;
  
  static {
    c = null;
  }
  
  public static void a(Context paramContext) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/b
    //   2: monitorenter
    //   3: aload_0
    //   4: aconst_null
    //   5: invokestatic a : (Landroid/content/Context;Lcom/tencent/bugly/legu/BuglyStrategy;)V
    //   8: ldc com/tencent/bugly/legu/b
    //   10: monitorexit
    //   11: return
    //   12: astore_0
    //   13: ldc com/tencent/bugly/legu/b
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	8	12	finally
  }
  
  public static void a(Context paramContext, BuglyStrategy paramBuglyStrategy) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/b
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.g : Z
    //   6: ifeq -> 23
    //   9: ldc '[init] initial Multi-times, ignore this.'
    //   11: iconst_0
    //   12: anewarray java/lang/Object
    //   15: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   18: pop
    //   19: ldc com/tencent/bugly/legu/b
    //   21: monitorexit
    //   22: return
    //   23: aload_0
    //   24: ifnonnull -> 45
    //   27: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   30: ldc '[init] context of init() is null, check it.'
    //   32: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   35: pop
    //   36: goto -> 19
    //   39: astore_0
    //   40: ldc com/tencent/bugly/legu/b
    //   42: monitorexit
    //   43: aload_0
    //   44: athrow
    //   45: aload_0
    //   46: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   49: astore_2
    //   50: aload_2
    //   51: invokestatic a : (Lcom/tencent/bugly/legu/crashreport/common/info/a;)Z
    //   54: ifeq -> 64
    //   57: iconst_0
    //   58: putstatic com/tencent/bugly/legu/b.a : Z
    //   61: goto -> 19
    //   64: aload_2
    //   65: invokevirtual e : ()Ljava/lang/String;
    //   68: astore_3
    //   69: aload_3
    //   70: ifnonnull -> 85
    //   73: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   76: ldc '[init] meta data of BUGLY_APPID in AndroidManifest.xml should be set.'
    //   78: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   81: pop
    //   82: goto -> 19
    //   85: aload_0
    //   86: aload_3
    //   87: aload_2
    //   88: getfield t : Z
    //   91: aload_1
    //   92: invokestatic a : (Landroid/content/Context;Ljava/lang/String;ZLcom/tencent/bugly/legu/BuglyStrategy;)V
    //   95: goto -> 19
    // Exception table:
    //   from	to	target	type
    //   3	19	39	finally
    //   27	36	39	finally
    //   45	61	39	finally
    //   64	69	39	finally
    //   73	82	39	finally
    //   85	95	39	finally
  }
  
  public static void a(Context paramContext, String paramString, boolean paramBoolean, BuglyStrategy paramBuglyStrategy) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/b
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.g : Z
    //   6: ifeq -> 23
    //   9: ldc '[init] initial Multi-times, ignore this.'
    //   11: iconst_0
    //   12: anewarray java/lang/Object
    //   15: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   18: pop
    //   19: ldc com/tencent/bugly/legu/b
    //   21: monitorexit
    //   22: return
    //   23: aload_0
    //   24: ifnonnull -> 45
    //   27: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   30: ldc '[init] context of init() is null, check it.'
    //   32: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   35: pop
    //   36: goto -> 19
    //   39: astore_0
    //   40: ldc com/tencent/bugly/legu/b
    //   42: monitorexit
    //   43: aload_0
    //   44: athrow
    //   45: aload_1
    //   46: ifnonnull -> 61
    //   49: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   52: ldc 'init arg 'crashReportAppID' should not be null!'
    //   54: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   57: pop
    //   58: goto -> 19
    //   61: iconst_1
    //   62: putstatic com/tencent/bugly/legu/b.g : Z
    //   65: iload_2
    //   66: ifeq -> 157
    //   69: iconst_1
    //   70: putstatic com/tencent/bugly/legu/b.b : Z
    //   73: iconst_1
    //   74: putstatic com/tencent/bugly/legu/proguard/w.b : Z
    //   77: ldc 'Bugly debug模式开启，请在发布时把isDebug关闭。 -- Running in debug model for 'isDebug' is enabled. Please disable it when you release.'
    //   79: iconst_0
    //   80: anewarray java/lang/Object
    //   83: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   86: pop
    //   87: ldc '--------------------------------------------------------------------------------------------'
    //   89: iconst_0
    //   90: anewarray java/lang/Object
    //   93: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   96: pop
    //   97: ldc 'Bugly debug模式将有以下行为特性 -- The following list shows the behaviour of debug model: '
    //   99: iconst_0
    //   100: anewarray java/lang/Object
    //   103: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   106: pop
    //   107: ldc '[1] 输出详细的Bugly SDK的Log -- More detailed log of Bugly SDK will be output to logcat;'
    //   109: iconst_0
    //   110: anewarray java/lang/Object
    //   113: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   116: pop
    //   117: ldc '[2] 每一条Crash都会被立即上报 -- Every crash caught by Bugly will be uploaded immediately.'
    //   119: iconst_0
    //   120: anewarray java/lang/Object
    //   123: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   126: pop
    //   127: ldc '[3] 自定义日志将会在Logcat中输出 -- Custom log will be output to logcat.'
    //   129: iconst_0
    //   130: anewarray java/lang/Object
    //   133: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   136: pop
    //   137: ldc '--------------------------------------------------------------------------------------------'
    //   139: iconst_0
    //   140: anewarray java/lang/Object
    //   143: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   146: pop
    //   147: ldc '[init] bugly in debug mode.'
    //   149: iconst_0
    //   150: anewarray java/lang/Object
    //   153: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   156: pop
    //   157: aload_0
    //   158: ifnonnull -> 216
    //   161: aload_0
    //   162: invokestatic a : (Landroid/content/Context;)V
    //   165: aload_0
    //   166: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   169: astore #4
    //   171: aload_0
    //   172: getstatic com/tencent/bugly/legu/b.d : Ljava/util/List;
    //   175: invokestatic a : (Landroid/content/Context;Ljava/util/List;)Lcom/tencent/bugly/legu/proguard/o;
    //   178: putstatic com/tencent/bugly/legu/b.e : Lcom/tencent/bugly/legu/proguard/o;
    //   181: aload_0
    //   182: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/proguard/t;
    //   185: pop
    //   186: aload_0
    //   187: getstatic com/tencent/bugly/legu/b.d : Ljava/util/List;
    //   190: invokestatic a : (Landroid/content/Context;Ljava/util/List;)Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   193: pop
    //   194: aload_0
    //   195: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/proguard/m;
    //   198: putstatic com/tencent/bugly/legu/b.f : Lcom/tencent/bugly/legu/proguard/m;
    //   201: aload #4
    //   203: invokestatic a : (Lcom/tencent/bugly/legu/crashreport/common/info/a;)Z
    //   206: ifeq -> 233
    //   209: iconst_0
    //   210: putstatic com/tencent/bugly/legu/b.a : Z
    //   213: goto -> 19
    //   216: aload_0
    //   217: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   220: astore #5
    //   222: aload #5
    //   224: ifnull -> 161
    //   227: aload #5
    //   229: astore_0
    //   230: goto -> 161
    //   233: new java/lang/StringBuilder
    //   236: astore #5
    //   238: aload #5
    //   240: invokespecial <init> : ()V
    //   243: aload #4
    //   245: invokevirtual getClass : ()Ljava/lang/Class;
    //   248: pop
    //   249: aload #5
    //   251: ldc 'legu crash report start init!'
    //   253: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   256: invokevirtual toString : ()Ljava/lang/String;
    //   259: iconst_0
    //   260: anewarray java/lang/Object
    //   263: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   266: pop
    //   267: ldc '[init] bugly start init...'
    //   269: iconst_0
    //   270: anewarray java/lang/Object
    //   273: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   276: pop
    //   277: aload #4
    //   279: aload_1
    //   280: invokevirtual a : (Ljava/lang/String;)V
    //   283: ldc '[param] setted APPID:%s'
    //   285: iconst_1
    //   286: anewarray java/lang/Object
    //   289: dup
    //   290: iconst_0
    //   291: aload_1
    //   292: aastore
    //   293: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   296: pop
    //   297: aload_3
    //   298: ifnull -> 660
    //   301: aload_3
    //   302: invokevirtual getAppVersion : ()Ljava/lang/String;
    //   305: astore #5
    //   307: aload #5
    //   309: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   312: ifne -> 384
    //   315: aload #5
    //   317: invokevirtual length : ()I
    //   320: bipush #100
    //   322: if_icmple -> 861
    //   325: aload #5
    //   327: iconst_0
    //   328: bipush #100
    //   330: invokevirtual substring : (II)Ljava/lang/String;
    //   333: astore_1
    //   334: ldc 'appVersion %s length is over limit %d substring to %s'
    //   336: iconst_3
    //   337: anewarray java/lang/Object
    //   340: dup
    //   341: iconst_0
    //   342: aload #5
    //   344: aastore
    //   345: dup
    //   346: iconst_1
    //   347: bipush #100
    //   349: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   352: aastore
    //   353: dup
    //   354: iconst_2
    //   355: aload_1
    //   356: aastore
    //   357: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   360: pop
    //   361: aload #4
    //   363: aload_1
    //   364: putfield i : Ljava/lang/String;
    //   367: ldc 'setted APPVERSION:%s'
    //   369: iconst_1
    //   370: anewarray java/lang/Object
    //   373: dup
    //   374: iconst_0
    //   375: aload_3
    //   376: invokevirtual getAppVersion : ()Ljava/lang/String;
    //   379: aastore
    //   380: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   383: pop
    //   384: aload_3
    //   385: invokevirtual isReplaceOldChannel : ()Z
    //   388: ifeq -> 742
    //   391: aload_3
    //   392: invokevirtual getAppChannel : ()Ljava/lang/String;
    //   395: astore_1
    //   396: aload_1
    //   397: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   400: ifne -> 475
    //   403: aload_1
    //   404: invokevirtual length : ()I
    //   407: bipush #100
    //   409: if_icmple -> 858
    //   412: aload_1
    //   413: iconst_0
    //   414: bipush #100
    //   416: invokevirtual substring : (II)Ljava/lang/String;
    //   419: astore #5
    //   421: ldc 'appChannel %s length is over limit %d substring to %s'
    //   423: iconst_3
    //   424: anewarray java/lang/Object
    //   427: dup
    //   428: iconst_0
    //   429: aload_1
    //   430: aastore
    //   431: dup
    //   432: iconst_1
    //   433: bipush #100
    //   435: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   438: aastore
    //   439: dup
    //   440: iconst_2
    //   441: aload #5
    //   443: aastore
    //   444: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   447: pop
    //   448: aload #5
    //   450: astore_1
    //   451: getstatic com/tencent/bugly/legu/b.e : Lcom/tencent/bugly/legu/proguard/o;
    //   454: sipush #556
    //   457: ldc 'app_channel'
    //   459: aload_1
    //   460: invokevirtual getBytes : ()[B
    //   463: aconst_null
    //   464: iconst_0
    //   465: invokevirtual a : (ILjava/lang/String;[BLcom/tencent/bugly/legu/proguard/n;Z)Z
    //   468: pop
    //   469: aload #4
    //   471: aload_1
    //   472: putfield j : Ljava/lang/String;
    //   475: ldc 'setted APPCHANNEL:%s'
    //   477: iconst_1
    //   478: anewarray java/lang/Object
    //   481: dup
    //   482: iconst_0
    //   483: aload #4
    //   485: getfield j : Ljava/lang/String;
    //   488: aastore
    //   489: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   492: pop
    //   493: aload_3
    //   494: invokevirtual getAppPackageName : ()Ljava/lang/String;
    //   497: astore_1
    //   498: aload_1
    //   499: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   502: ifne -> 576
    //   505: aload_1
    //   506: invokevirtual length : ()I
    //   509: bipush #100
    //   511: if_icmple -> 855
    //   514: aload_1
    //   515: iconst_0
    //   516: bipush #100
    //   518: invokevirtual substring : (II)Ljava/lang/String;
    //   521: astore #5
    //   523: ldc 'appPackageName %s length is over limit %d substring to %s'
    //   525: iconst_3
    //   526: anewarray java/lang/Object
    //   529: dup
    //   530: iconst_0
    //   531: aload_1
    //   532: aastore
    //   533: dup
    //   534: iconst_1
    //   535: bipush #100
    //   537: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   540: aastore
    //   541: dup
    //   542: iconst_2
    //   543: aload #5
    //   545: aastore
    //   546: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   549: pop
    //   550: aload #5
    //   552: astore_1
    //   553: aload #4
    //   555: aload_1
    //   556: putfield c : Ljava/lang/String;
    //   559: ldc 'setted PACKAGENAME:%s'
    //   561: iconst_1
    //   562: anewarray java/lang/Object
    //   565: dup
    //   566: iconst_0
    //   567: aload_3
    //   568: invokevirtual getAppPackageName : ()Ljava/lang/String;
    //   571: aastore
    //   572: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   575: pop
    //   576: aload_3
    //   577: invokevirtual getDeviceID : ()Ljava/lang/String;
    //   580: astore #5
    //   582: aload #5
    //   584: ifnull -> 653
    //   587: aload #5
    //   589: invokevirtual length : ()I
    //   592: bipush #100
    //   594: if_icmple -> 849
    //   597: aload #5
    //   599: iconst_0
    //   600: bipush #100
    //   602: invokevirtual substring : (II)Ljava/lang/String;
    //   605: astore_1
    //   606: ldc 'deviceId %s length is over limit %d substring to %s'
    //   608: iconst_3
    //   609: anewarray java/lang/Object
    //   612: dup
    //   613: iconst_0
    //   614: aload #5
    //   616: aastore
    //   617: dup
    //   618: iconst_1
    //   619: bipush #100
    //   621: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   624: aastore
    //   625: dup
    //   626: iconst_2
    //   627: aload_1
    //   628: aastore
    //   629: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   632: pop
    //   633: aload #4
    //   635: aload_1
    //   636: invokevirtual c : (Ljava/lang/String;)V
    //   639: ldc 'setted deviceId :%s'
    //   641: iconst_1
    //   642: anewarray java/lang/Object
    //   645: dup
    //   646: iconst_0
    //   647: aload_1
    //   648: aastore
    //   649: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   652: pop
    //   653: aload_3
    //   654: invokevirtual isBuglyLogUpload : ()Z
    //   657: putstatic com/tencent/bugly/legu/proguard/x.a : Z
    //   660: aload_0
    //   661: aload_3
    //   662: invokestatic a : (Landroid/content/Context;Lcom/tencent/bugly/legu/BuglyStrategy;)V
    //   665: getstatic com/tencent/bugly/legu/b.f : Lcom/tencent/bugly/legu/proguard/m;
    //   668: invokevirtual b : ()I
    //   671: pop
    //   672: iconst_0
    //   673: istore #6
    //   675: getstatic com/tencent/bugly/legu/b.d : Ljava/util/List;
    //   678: invokeinterface size : ()I
    //   683: istore #7
    //   685: iload #6
    //   687: iload #7
    //   689: if_icmpge -> 824
    //   692: getstatic com/tencent/bugly/legu/b.f : Lcom/tencent/bugly/legu/proguard/m;
    //   695: getstatic com/tencent/bugly/legu/b.d : Ljava/util/List;
    //   698: iload #6
    //   700: invokeinterface get : (I)Ljava/lang/Object;
    //   705: checkcast com/tencent/bugly/legu/a
    //   708: getfield id : I
    //   711: invokevirtual a : (I)Z
    //   714: ifeq -> 736
    //   717: getstatic com/tencent/bugly/legu/b.d : Ljava/util/List;
    //   720: iload #6
    //   722: invokeinterface get : (I)Ljava/lang/Object;
    //   727: checkcast com/tencent/bugly/legu/a
    //   730: aload_0
    //   731: iload_2
    //   732: aload_3
    //   733: invokevirtual init : (Landroid/content/Context;ZLcom/tencent/bugly/legu/BuglyStrategy;)V
    //   736: iinc #6, 1
    //   739: goto -> 675
    //   742: getstatic com/tencent/bugly/legu/b.e : Lcom/tencent/bugly/legu/proguard/o;
    //   745: sipush #556
    //   748: aconst_null
    //   749: iconst_1
    //   750: invokevirtual a : (ILcom/tencent/bugly/legu/proguard/n;Z)Ljava/util/Map;
    //   753: astore_1
    //   754: aload_1
    //   755: ifnull -> 475
    //   758: aload_1
    //   759: ldc 'app_channel'
    //   761: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   766: checkcast [B
    //   769: astore #5
    //   771: aload #5
    //   773: ifnull -> 475
    //   776: new java/lang/String
    //   779: astore_1
    //   780: aload_1
    //   781: aload #5
    //   783: invokespecial <init> : ([B)V
    //   786: aload #4
    //   788: aload_1
    //   789: putfield j : Ljava/lang/String;
    //   792: goto -> 475
    //   795: astore_1
    //   796: getstatic com/tencent/bugly/legu/b.b : Z
    //   799: ifeq -> 493
    //   802: aload_1
    //   803: invokevirtual printStackTrace : ()V
    //   806: goto -> 493
    //   809: astore_1
    //   810: aload_1
    //   811: invokestatic a : (Ljava/lang/Throwable;)Z
    //   814: ifne -> 736
    //   817: aload_1
    //   818: invokevirtual printStackTrace : ()V
    //   821: goto -> 736
    //   824: ldc_w 'crash report inited!'
    //   827: iconst_0
    //   828: anewarray java/lang/Object
    //   831: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   834: pop
    //   835: ldc_w '[init] bugly init finished.'
    //   838: iconst_0
    //   839: anewarray java/lang/Object
    //   842: invokestatic b : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   845: pop
    //   846: goto -> 19
    //   849: aload #5
    //   851: astore_1
    //   852: goto -> 633
    //   855: goto -> 553
    //   858: goto -> 451
    //   861: aload #5
    //   863: astore_1
    //   864: goto -> 361
    // Exception table:
    //   from	to	target	type
    //   3	19	39	finally
    //   27	36	39	finally
    //   49	58	39	finally
    //   61	65	39	finally
    //   69	157	39	finally
    //   161	213	39	finally
    //   216	222	39	finally
    //   233	297	39	finally
    //   301	361	39	finally
    //   361	384	39	finally
    //   384	448	795	java/lang/Exception
    //   384	448	39	finally
    //   451	475	795	java/lang/Exception
    //   451	475	39	finally
    //   475	493	795	java/lang/Exception
    //   475	493	39	finally
    //   493	550	39	finally
    //   553	576	39	finally
    //   576	582	39	finally
    //   587	633	39	finally
    //   633	653	39	finally
    //   653	660	39	finally
    //   660	672	39	finally
    //   675	685	39	finally
    //   692	736	809	java/lang/Throwable
    //   692	736	39	finally
    //   742	754	795	java/lang/Exception
    //   742	754	39	finally
    //   758	771	795	java/lang/Exception
    //   758	771	39	finally
    //   776	792	795	java/lang/Exception
    //   776	792	39	finally
    //   796	806	39	finally
    //   810	821	39	finally
    //   824	846	39	finally
  }
  
  public static void a(a parama) {
    if (!d.contains(parama))
      d.add(parama); 
  }
  
  private static boolean a(a parama) {
    String str;
    List list = parama.m;
    parama.getClass();
    if ("legu".equals("")) {
      str = "bugly";
    } else {
      str.getClass();
      str = "legu";
    } 
    return (list != null && list.contains(str));
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */