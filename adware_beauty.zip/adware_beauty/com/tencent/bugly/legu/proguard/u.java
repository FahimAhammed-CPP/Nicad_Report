package com.tencent.bugly.legu.proguard;

import android.content.Context;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.common.strategy.a;

public final class u implements Runnable {
  private int a;
  
  private int b;
  
  private final Context c;
  
  private final int d;
  
  private final byte[] e;
  
  private final a f;
  
  private final a g;
  
  private final r h;
  
  private final t i;
  
  private final int j;
  
  private final s k;
  
  private final s l;
  
  private String m;
  
  private int n;
  
  private long o;
  
  private long p;
  
  private boolean q;
  
  public u(Context paramContext, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, String paramString, s params, boolean paramBoolean) {
    this(paramContext, paramInt1, paramInt2, paramArrayOfbyte, paramString, params, paramBoolean, 5, 60000);
  }
  
  private u(Context paramContext, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, String paramString, s params, boolean paramBoolean, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: iconst_3
    //   6: putfield a : I
    //   9: aload_0
    //   10: sipush #30000
    //   13: putfield b : I
    //   16: aload_0
    //   17: ldc ''
    //   19: putfield m : Ljava/lang/String;
    //   22: aload_0
    //   23: iconst_0
    //   24: putfield n : I
    //   27: aload_0
    //   28: lconst_0
    //   29: putfield o : J
    //   32: aload_0
    //   33: lconst_0
    //   34: putfield p : J
    //   37: aload_0
    //   38: iconst_1
    //   39: putfield q : Z
    //   42: aload_0
    //   43: aload_1
    //   44: putfield c : Landroid/content/Context;
    //   47: aload_0
    //   48: aload_1
    //   49: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   52: putfield f : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   55: aload_0
    //   56: aload #4
    //   58: putfield e : [B
    //   61: aload_0
    //   62: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   65: putfield g : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   68: aload_0
    //   69: aload_1
    //   70: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/proguard/r;
    //   73: putfield h : Lcom/tencent/bugly/legu/proguard/r;
    //   76: aload_0
    //   77: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/t;
    //   80: putfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   83: aload_0
    //   84: iload_2
    //   85: putfield j : I
    //   88: aload_0
    //   89: aload #5
    //   91: putfield m : Ljava/lang/String;
    //   94: aload_0
    //   95: aload #6
    //   97: putfield k : Lcom/tencent/bugly/legu/proguard/s;
    //   100: aload_0
    //   101: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   104: astore_1
    //   105: aload_0
    //   106: aconst_null
    //   107: putfield l : Lcom/tencent/bugly/legu/proguard/s;
    //   110: aload_0
    //   111: iload #7
    //   113: putfield q : Z
    //   116: iload_3
    //   117: istore_2
    //   118: iload #7
    //   120: ifeq -> 162
    //   123: iload_3
    //   124: lookupswitch default -> 160, 510 -> 186, 630 -> 179, 640 -> 186
    //   160: iload_3
    //   161: istore_2
    //   162: aload_0
    //   163: iload_2
    //   164: putfield d : I
    //   167: aload_0
    //   168: iconst_5
    //   169: putfield a : I
    //   172: aload_0
    //   173: ldc 60000
    //   175: putfield b : I
    //   178: return
    //   179: sipush #830
    //   182: istore_2
    //   183: goto -> 162
    //   186: sipush #840
    //   189: istore_2
    //   190: goto -> 162
  }
  
  public u(Context paramContext, int paramInt, am paramam, String paramString, s params, boolean paramBoolean) {
    this(paramContext, paramInt, paramam.g, a.a(paramam), paramString, params, paramBoolean);
  }
  
  private void a(an paraman, boolean paramBoolean, int paramInt1, String paramString, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : I
    //   4: lookupswitch default -> 48, 630 -> 197, 640 -> 203, 830 -> 197, 840 -> 203
    //   48: aload_0
    //   49: getfield d : I
    //   52: invokestatic valueOf : (I)Ljava/lang/String;
    //   55: astore_1
    //   56: iload_2
    //   57: ifeq -> 209
    //   60: ldc '[upload] success: %s'
    //   62: iconst_1
    //   63: anewarray java/lang/Object
    //   66: dup
    //   67: iconst_0
    //   68: aload_1
    //   69: aastore
    //   70: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   73: pop
    //   74: aload_0
    //   75: getfield o : J
    //   78: aload_0
    //   79: getfield p : J
    //   82: ladd
    //   83: lconst_0
    //   84: lcmp
    //   85: ifle -> 124
    //   88: aload_0
    //   89: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   92: invokevirtual b : ()J
    //   95: lstore #6
    //   97: aload_0
    //   98: getfield o : J
    //   101: lstore #8
    //   103: aload_0
    //   104: getfield p : J
    //   107: lstore #10
    //   109: aload_0
    //   110: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   113: lload #6
    //   115: lload #8
    //   117: ladd
    //   118: lload #10
    //   120: ladd
    //   121: invokevirtual a : (J)V
    //   124: aload_0
    //   125: getfield k : Lcom/tencent/bugly/legu/proguard/s;
    //   128: ifnull -> 160
    //   131: aload_0
    //   132: getfield k : Lcom/tencent/bugly/legu/proguard/s;
    //   135: astore_1
    //   136: aload_0
    //   137: getfield d : I
    //   140: istore_3
    //   141: aload_0
    //   142: getfield o : J
    //   145: lstore #10
    //   147: aload_0
    //   148: getfield p : J
    //   151: lstore #10
    //   153: aload_1
    //   154: iload_2
    //   155: invokeinterface a : (Z)V
    //   160: aload_0
    //   161: getfield l : Lcom/tencent/bugly/legu/proguard/s;
    //   164: ifnull -> 196
    //   167: aload_0
    //   168: getfield l : Lcom/tencent/bugly/legu/proguard/s;
    //   171: astore_1
    //   172: aload_0
    //   173: getfield d : I
    //   176: istore_3
    //   177: aload_0
    //   178: getfield o : J
    //   181: lstore #10
    //   183: aload_0
    //   184: getfield p : J
    //   187: lstore #10
    //   189: aload_1
    //   190: iload_2
    //   191: invokeinterface a : (Z)V
    //   196: return
    //   197: ldc 'crash'
    //   199: astore_1
    //   200: goto -> 56
    //   203: ldc 'userinfo'
    //   205: astore_1
    //   206: goto -> 56
    //   209: ldc '[upload] fail! %s %d %s'
    //   211: iconst_3
    //   212: anewarray java/lang/Object
    //   215: dup
    //   216: iconst_0
    //   217: aload_1
    //   218: aastore
    //   219: dup
    //   220: iconst_1
    //   221: iload_3
    //   222: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   225: aastore
    //   226: dup
    //   227: iconst_2
    //   228: aload #4
    //   230: aastore
    //   231: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   234: pop
    //   235: aload_0
    //   236: getfield q : Z
    //   239: ifeq -> 74
    //   242: aload_0
    //   243: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   246: iload #5
    //   248: aconst_null
    //   249: invokevirtual a : (ILcom/tencent/bugly/legu/proguard/an;)V
    //   252: goto -> 74
  }
  
  private static boolean a(an paraman, a parama, a parama1) {
    boolean bool;
    if (paraman == null) {
      w.d("resp == null!", new Object[0]);
      return false;
    } 
    if (paraman.a != 0) {
      w.e("resp result error %d", new Object[] { Byte.valueOf(paraman.a) });
      return false;
    } 
    try {
      int i;
      String str = paraman.d;
      if (str != null && str.trim().length() > 0) {
        i = 0;
      } else {
        i = 1;
      } 
      if (!i && a.a().h() != paraman.d) {
        o.a().a(a.a, "key_ip", paraman.d.getBytes("UTF-8"), (n)null, true);
        parama.d(paraman.d);
      } 
      str = paraman.g;
      if (str != null && str.trim().length() > 0) {
        i = 0;
      } else {
        i = 1;
      } 
      if (!i && a.a().i() != paraman.g) {
        o.a().a(a.a, "key_imei", paraman.g.getBytes("UTF-8"), (n)null, true);
        parama.e(paraman.g);
      } 
      parama.h = paraman.e;
      if (paraman.b == 510) {
        if (paraman.c == null) {
          w.e("remote data is miss! %d", new Object[] { Integer.valueOf(paraman.b) });
          return false;
        } 
        ap ap = a.<ap>a(paraman.c, ap.class);
        if (ap == null) {
          w.e("remote data is error! %d", new Object[] { Integer.valueOf(paraman.b) });
          return false;
        } 
        boolean bool2 = ap.a;
        boolean bool1 = ap.c;
        boolean bool3 = ap.b;
        if (ap.g == null) {
          i = -1;
        } else {
          i = ap.g.size();
        } 
        w.c("en:%b qu:%b uin:%b vm:%d", new Object[] { Boolean.valueOf(bool2), Boolean.valueOf(bool1), Boolean.valueOf(bool3), Integer.valueOf(i) });
        parama1.a(ap);
      } 
      bool = true;
    } catch (Throwable throwable) {}
    return bool;
  }
  
  public final void a(long paramLong) {
    this.n++;
    this.o += paramLong;
  }
  
  public final void b(long paramLong) {
    this.p += paramLong;
  }
  
  public final void run() {
    // Byte code:
    //   0: aload_0
    //   1: getfield e : [B
    //   4: astore_1
    //   5: aload_0
    //   6: iconst_0
    //   7: putfield n : I
    //   10: aload_0
    //   11: lconst_0
    //   12: putfield o : J
    //   15: aload_0
    //   16: lconst_0
    //   17: putfield p : J
    //   20: aload_0
    //   21: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   24: aload_0
    //   25: getfield j : I
    //   28: invokestatic currentTimeMillis : ()J
    //   31: invokevirtual a : (IJ)V
    //   34: aload_0
    //   35: getfield k : Lcom/tencent/bugly/legu/proguard/s;
    //   38: ifnull -> 51
    //   41: aload_0
    //   42: getfield k : Lcom/tencent/bugly/legu/proguard/s;
    //   45: astore_2
    //   46: aload_0
    //   47: getfield d : I
    //   50: istore_3
    //   51: aload_0
    //   52: getfield l : Lcom/tencent/bugly/legu/proguard/s;
    //   55: ifnull -> 68
    //   58: aload_0
    //   59: getfield l : Lcom/tencent/bugly/legu/proguard/s;
    //   62: astore_2
    //   63: aload_0
    //   64: getfield d : I
    //   67: istore_3
    //   68: aload_0
    //   69: getfield c : Landroid/content/Context;
    //   72: invokestatic e : (Landroid/content/Context;)Ljava/lang/String;
    //   75: ifnonnull -> 90
    //   78: aload_0
    //   79: aconst_null
    //   80: iconst_0
    //   81: iconst_0
    //   82: ldc_w 'network is not availiable!'
    //   85: iconst_0
    //   86: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   89: return
    //   90: aload_1
    //   91: ifnull -> 99
    //   94: aload_1
    //   95: arraylength
    //   96: ifne -> 128
    //   99: aload_0
    //   100: aconst_null
    //   101: iconst_0
    //   102: iconst_0
    //   103: ldc_w '[upload] fail, request package is empty!'
    //   106: iconst_0
    //   107: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   110: goto -> 89
    //   113: astore_2
    //   114: aload_2
    //   115: invokestatic a : (Ljava/lang/Throwable;)Z
    //   118: ifne -> 89
    //   121: aload_2
    //   122: invokevirtual printStackTrace : ()V
    //   125: goto -> 89
    //   128: aload_0
    //   129: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   132: invokevirtual b : ()J
    //   135: lstore #4
    //   137: aload_1
    //   138: arraylength
    //   139: i2l
    //   140: lload #4
    //   142: ladd
    //   143: ldc2_w 2097152
    //   146: lcmp
    //   147: iflt -> 216
    //   150: ldc_w 'up too much wait to next time ! %d %d '
    //   153: iconst_2
    //   154: anewarray java/lang/Object
    //   157: dup
    //   158: iconst_0
    //   159: lload #4
    //   161: invokestatic valueOf : (J)Ljava/lang/Long;
    //   164: aastore
    //   165: dup
    //   166: iconst_1
    //   167: ldc2_w 2097152
    //   170: invokestatic valueOf : (J)Ljava/lang/Long;
    //   173: aastore
    //   174: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   177: pop
    //   178: new java/lang/StringBuilder
    //   181: astore_2
    //   182: aload_2
    //   183: ldc_w '[upload] fail, over net consume: '
    //   186: invokespecial <init> : (Ljava/lang/String;)V
    //   189: aload_0
    //   190: aconst_null
    //   191: iconst_0
    //   192: iconst_0
    //   193: aload_2
    //   194: ldc2_w 2048
    //   197: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   200: ldc_w 'K'
    //   203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: invokevirtual toString : ()Ljava/lang/String;
    //   209: iconst_0
    //   210: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   213: goto -> 89
    //   216: ldc_w 'do upload task %d'
    //   219: iconst_1
    //   220: anewarray java/lang/Object
    //   223: dup
    //   224: iconst_0
    //   225: aload_0
    //   226: getfield d : I
    //   229: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   232: aastore
    //   233: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   236: pop
    //   237: aload_0
    //   238: getfield c : Landroid/content/Context;
    //   241: ifnull -> 269
    //   244: aload_1
    //   245: ifnull -> 269
    //   248: aload_0
    //   249: getfield f : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   252: ifnull -> 269
    //   255: aload_0
    //   256: getfield g : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   259: ifnull -> 269
    //   262: aload_0
    //   263: getfield h : Lcom/tencent/bugly/legu/proguard/r;
    //   266: ifnonnull -> 283
    //   269: aload_0
    //   270: aconst_null
    //   271: iconst_0
    //   272: iconst_0
    //   273: ldc_w '[upload] fail, illegal access error!'
    //   276: iconst_0
    //   277: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   280: goto -> 89
    //   283: aload_0
    //   284: getfield g : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   287: invokevirtual c : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   290: astore #6
    //   292: aload #6
    //   294: ifnonnull -> 311
    //   297: aload_0
    //   298: aconst_null
    //   299: iconst_0
    //   300: iconst_0
    //   301: ldc_w '[upload] fail, illegal local strategy!'
    //   304: iconst_0
    //   305: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   308: goto -> 89
    //   311: new java/util/HashMap
    //   314: astore #7
    //   316: aload #7
    //   318: invokespecial <init> : ()V
    //   321: aload #7
    //   323: ldc_w 'prodId'
    //   326: aload_0
    //   327: getfield f : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   330: invokevirtual e : ()Ljava/lang/String;
    //   333: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   338: pop
    //   339: aload #7
    //   341: ldc_w 'bundleId'
    //   344: aload_0
    //   345: getfield f : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   348: getfield c : Ljava/lang/String;
    //   351: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   356: pop
    //   357: aload #7
    //   359: ldc_w 'appVer'
    //   362: aload_0
    //   363: getfield f : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   366: getfield i : Ljava/lang/String;
    //   369: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   374: pop
    //   375: aload_1
    //   376: astore_2
    //   377: aload_0
    //   378: getfield q : Z
    //   381: ifeq -> 537
    //   384: aload #7
    //   386: ldc_w 'cmd'
    //   389: aload_0
    //   390: getfield d : I
    //   393: invokestatic toString : (I)Ljava/lang/String;
    //   396: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   401: pop
    //   402: aload #7
    //   404: ldc_w 'platformId'
    //   407: iconst_1
    //   408: invokestatic toString : (B)Ljava/lang/String;
    //   411: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   416: pop
    //   417: aload_0
    //   418: getfield f : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   421: invokevirtual getClass : ()Ljava/lang/Class;
    //   424: pop
    //   425: aload #7
    //   427: ldc_w 'sdkVer'
    //   430: ldc_w '2.1.9'
    //   433: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   438: pop
    //   439: aload #7
    //   441: ldc_w 'strategylastUpdateTime'
    //   444: aload #6
    //   446: getfield l : J
    //   449: invokestatic toString : (J)Ljava/lang/String;
    //   452: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   457: pop
    //   458: aload_0
    //   459: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   462: aload #7
    //   464: invokevirtual a : (Ljava/util/Map;)Z
    //   467: ifne -> 484
    //   470: aload_0
    //   471: aconst_null
    //   472: iconst_0
    //   473: iconst_0
    //   474: ldc_w '[upload] fail, failed to add security info to HTTP headers'
    //   477: iconst_0
    //   478: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   481: goto -> 89
    //   484: aload_1
    //   485: iconst_2
    //   486: invokestatic a : ([BI)[B
    //   489: astore_2
    //   490: aload_2
    //   491: ifnonnull -> 508
    //   494: aload_0
    //   495: aconst_null
    //   496: iconst_0
    //   497: iconst_0
    //   498: ldc_w '[upload] fail, failed to zip request body'
    //   501: iconst_0
    //   502: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   505: goto -> 89
    //   508: aload_0
    //   509: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   512: aload_2
    //   513: invokevirtual a : ([B)[B
    //   516: astore_1
    //   517: aload_1
    //   518: astore_2
    //   519: aload_1
    //   520: ifnonnull -> 537
    //   523: aload_0
    //   524: aconst_null
    //   525: iconst_0
    //   526: iconst_0
    //   527: ldc_w '[upload] fail, failed to encrypt request body'
    //   530: iconst_0
    //   531: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   534: goto -> 89
    //   537: iconst_m1
    //   538: istore #8
    //   540: iconst_0
    //   541: istore_3
    //   542: iconst_0
    //   543: istore #9
    //   545: iload_3
    //   546: aload_0
    //   547: getfield a : I
    //   550: if_icmpge -> 1409
    //   553: iload_3
    //   554: iconst_1
    //   555: iadd
    //   556: istore #9
    //   558: iload_3
    //   559: ifeq -> 595
    //   562: ldc_w 'failed to upload last time, wait and try(%d) again'
    //   565: iconst_1
    //   566: anewarray java/lang/Object
    //   569: dup
    //   570: iconst_0
    //   571: iload #9
    //   573: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   576: aastore
    //   577: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   580: pop
    //   581: aload_0
    //   582: getfield b : I
    //   585: istore_3
    //   586: iload_3
    //   587: i2l
    //   588: lstore #4
    //   590: lload #4
    //   592: invokestatic sleep : (J)V
    //   595: ldc_w 'send %d'
    //   598: iconst_1
    //   599: anewarray java/lang/Object
    //   602: dup
    //   603: iconst_0
    //   604: aload_2
    //   605: arraylength
    //   606: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   609: aastore
    //   610: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   613: pop
    //   614: aload_0
    //   615: getfield m : Ljava/lang/String;
    //   618: astore_1
    //   619: aload_1
    //   620: ifnull -> 775
    //   623: aload_1
    //   624: invokevirtual trim : ()Ljava/lang/String;
    //   627: invokevirtual length : ()I
    //   630: ifle -> 775
    //   633: iconst_0
    //   634: istore_3
    //   635: iload_3
    //   636: ifeq -> 665
    //   639: aload_0
    //   640: getfield q : Z
    //   643: ifeq -> 792
    //   646: aload_0
    //   647: getfield d : I
    //   650: sipush #830
    //   653: if_icmpne -> 780
    //   656: aload_0
    //   657: aload #6
    //   659: getfield o : Ljava/lang/String;
    //   662: putfield m : Ljava/lang/String;
    //   665: ldc_w 'do upload to %s with cmd %d (pid=%d | tid=%d)'
    //   668: iconst_4
    //   669: anewarray java/lang/Object
    //   672: dup
    //   673: iconst_0
    //   674: aload_0
    //   675: getfield m : Ljava/lang/String;
    //   678: aastore
    //   679: dup
    //   680: iconst_1
    //   681: aload_0
    //   682: getfield d : I
    //   685: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   688: aastore
    //   689: dup
    //   690: iconst_2
    //   691: invokestatic myPid : ()I
    //   694: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   697: aastore
    //   698: dup
    //   699: iconst_3
    //   700: invokestatic myTid : ()I
    //   703: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   706: aastore
    //   707: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   710: pop
    //   711: aload_0
    //   712: getfield h : Lcom/tencent/bugly/legu/proguard/r;
    //   715: aload_0
    //   716: getfield m : Ljava/lang/String;
    //   719: aload_2
    //   720: aload_0
    //   721: aload #7
    //   723: invokevirtual a : (Ljava/lang/String;[BLcom/tencent/bugly/legu/proguard/u;Ljava/util/Map;)[B
    //   726: astore_1
    //   727: aload_1
    //   728: ifnonnull -> 804
    //   731: ldc_w 'try upload fail! %d %s'
    //   734: iconst_2
    //   735: anewarray java/lang/Object
    //   738: dup
    //   739: iconst_0
    //   740: aload_0
    //   741: getfield d : I
    //   744: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   747: aastore
    //   748: dup
    //   749: iconst_1
    //   750: ldc_w 'upload fail, no response!'
    //   753: aastore
    //   754: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   757: pop
    //   758: iload #9
    //   760: istore_3
    //   761: iconst_1
    //   762: istore #9
    //   764: goto -> 545
    //   767: astore_1
    //   768: aload_1
    //   769: invokevirtual printStackTrace : ()V
    //   772: goto -> 595
    //   775: iconst_1
    //   776: istore_3
    //   777: goto -> 635
    //   780: aload_0
    //   781: aload #6
    //   783: getfield n : Ljava/lang/String;
    //   786: putfield m : Ljava/lang/String;
    //   789: goto -> 665
    //   792: aload_0
    //   793: aload #6
    //   795: getfield p : Ljava/lang/String;
    //   798: putfield m : Ljava/lang/String;
    //   801: goto -> 665
    //   804: aload_0
    //   805: getfield h : Lcom/tencent/bugly/legu/proguard/r;
    //   808: getfield a : Ljava/util/Map;
    //   811: astore #10
    //   813: iload #8
    //   815: istore #11
    //   817: aload_0
    //   818: getfield q : Z
    //   821: ifeq -> 1192
    //   824: aload #10
    //   826: ifnull -> 852
    //   829: aload #10
    //   831: invokeinterface size : ()I
    //   836: ifeq -> 852
    //   839: aload #10
    //   841: ldc_w 'status'
    //   844: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   849: ifne -> 917
    //   852: ldc_w 'no headers from server, just try again (pid=%d | tid=%d)'
    //   855: iconst_2
    //   856: anewarray java/lang/Object
    //   859: dup
    //   860: iconst_0
    //   861: invokestatic myPid : ()I
    //   864: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   867: aastore
    //   868: dup
    //   869: iconst_1
    //   870: invokestatic myTid : ()I
    //   873: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   876: aastore
    //   877: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   880: pop
    //   881: ldc_w 'try upload fail! %d %s'
    //   884: iconst_2
    //   885: anewarray java/lang/Object
    //   888: dup
    //   889: iconst_0
    //   890: aload_0
    //   891: getfield d : I
    //   894: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   897: aastore
    //   898: dup
    //   899: iconst_1
    //   900: ldc_w 'upload fail, no status header'
    //   903: aastore
    //   904: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   907: pop
    //   908: iload #9
    //   910: istore_3
    //   911: iconst_1
    //   912: istore #9
    //   914: goto -> 545
    //   917: aload #10
    //   919: ldc_w 'status'
    //   922: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   927: checkcast java/lang/String
    //   930: invokestatic parseInt : (Ljava/lang/String;)I
    //   933: istore_3
    //   934: iload_3
    //   935: istore #8
    //   937: ldc_w 'status from server is %d (pid=%d | tid=%d)'
    //   940: iconst_3
    //   941: anewarray java/lang/Object
    //   944: dup
    //   945: iconst_0
    //   946: iload_3
    //   947: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   950: aastore
    //   951: dup
    //   952: iconst_1
    //   953: invokestatic myPid : ()I
    //   956: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   959: aastore
    //   960: dup
    //   961: iconst_2
    //   962: invokestatic myTid : ()I
    //   965: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   968: aastore
    //   969: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   972: pop
    //   973: iload_3
    //   974: istore #11
    //   976: iload_3
    //   977: ifeq -> 1192
    //   980: iload_3
    //   981: iconst_2
    //   982: if_icmpne -> 1159
    //   985: aload_0
    //   986: getfield o : J
    //   989: aload_0
    //   990: getfield p : J
    //   993: ladd
    //   994: lconst_0
    //   995: lcmp
    //   996: ifle -> 1035
    //   999: aload_0
    //   1000: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   1003: invokevirtual b : ()J
    //   1006: lstore #12
    //   1008: aload_0
    //   1009: getfield o : J
    //   1012: lstore #14
    //   1014: aload_0
    //   1015: getfield p : J
    //   1018: lstore #4
    //   1020: aload_0
    //   1021: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   1024: lload #12
    //   1026: lload #14
    //   1028: ladd
    //   1029: lload #4
    //   1031: ladd
    //   1032: invokevirtual a : (J)V
    //   1035: aload_0
    //   1036: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   1039: iload_3
    //   1040: aconst_null
    //   1041: invokevirtual a : (ILcom/tencent/bugly/legu/proguard/an;)V
    //   1044: ldc_w 'Session ID is invalid, will try again immediately (pid=%d | tid=%d)'
    //   1047: iconst_2
    //   1048: anewarray java/lang/Object
    //   1051: dup
    //   1052: iconst_0
    //   1053: invokestatic myPid : ()I
    //   1056: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1059: aastore
    //   1060: dup
    //   1061: iconst_1
    //   1062: invokestatic myTid : ()I
    //   1065: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1068: aastore
    //   1069: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1072: pop
    //   1073: aload_0
    //   1074: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   1077: aload_0
    //   1078: getfield j : I
    //   1081: aload_0
    //   1082: getfield d : I
    //   1085: aload_0
    //   1086: getfield e : [B
    //   1089: aconst_null
    //   1090: aload_0
    //   1091: getfield l : Lcom/tencent/bugly/legu/proguard/s;
    //   1094: invokevirtual a : (II[BLjava/lang/String;Lcom/tencent/bugly/legu/proguard/s;)V
    //   1097: goto -> 89
    //   1100: astore_1
    //   1101: new java/lang/StringBuilder
    //   1104: astore_1
    //   1105: aload_1
    //   1106: ldc_w 'upload fail, format of status header is invalid: '
    //   1109: invokespecial <init> : (Ljava/lang/String;)V
    //   1112: aload_1
    //   1113: iload #8
    //   1115: invokestatic toString : (I)Ljava/lang/String;
    //   1118: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1121: invokevirtual toString : ()Ljava/lang/String;
    //   1124: astore_1
    //   1125: ldc_w 'try upload fail! %d %s'
    //   1128: iconst_2
    //   1129: anewarray java/lang/Object
    //   1132: dup
    //   1133: iconst_0
    //   1134: aload_0
    //   1135: getfield d : I
    //   1138: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1141: aastore
    //   1142: dup
    //   1143: iconst_1
    //   1144: aload_1
    //   1145: aastore
    //   1146: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1149: pop
    //   1150: iload #9
    //   1152: istore_3
    //   1153: iconst_1
    //   1154: istore #9
    //   1156: goto -> 545
    //   1159: new java/lang/StringBuilder
    //   1162: astore_2
    //   1163: aload_2
    //   1164: ldc_w 'upload fail, status: '
    //   1167: invokespecial <init> : (Ljava/lang/String;)V
    //   1170: aload_0
    //   1171: aconst_null
    //   1172: iconst_0
    //   1173: iconst_1
    //   1174: aload_2
    //   1175: iload_3
    //   1176: invokestatic toString : (I)Ljava/lang/String;
    //   1179: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1182: invokevirtual toString : ()Ljava/lang/String;
    //   1185: iload_3
    //   1186: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   1189: goto -> 89
    //   1192: ldc_w 'recv %d'
    //   1195: iconst_1
    //   1196: anewarray java/lang/Object
    //   1199: dup
    //   1200: iconst_0
    //   1201: aload_1
    //   1202: arraylength
    //   1203: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1206: aastore
    //   1207: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1210: pop
    //   1211: aload_0
    //   1212: getfield q : Z
    //   1215: ifeq -> 1271
    //   1218: aload_0
    //   1219: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   1222: aload_1
    //   1223: invokevirtual b : ([B)[B
    //   1226: astore_2
    //   1227: aload_2
    //   1228: ifnonnull -> 1245
    //   1231: aload_0
    //   1232: aconst_null
    //   1233: iconst_0
    //   1234: iconst_1
    //   1235: ldc_w 'upload fail, failed to decrypt response from server'
    //   1238: iconst_0
    //   1239: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   1242: goto -> 89
    //   1245: aload_2
    //   1246: iconst_2
    //   1247: invokestatic b : ([BI)[B
    //   1250: astore_1
    //   1251: aload_1
    //   1252: astore_2
    //   1253: aload_1
    //   1254: ifnonnull -> 1273
    //   1257: aload_0
    //   1258: aconst_null
    //   1259: iconst_0
    //   1260: iconst_1
    //   1261: ldc_w 'upload fail, failed to unzip(gzip) response from server'
    //   1264: iconst_0
    //   1265: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   1268: goto -> 89
    //   1271: aload_1
    //   1272: astore_2
    //   1273: aload_2
    //   1274: aload_0
    //   1275: getfield q : Z
    //   1278: invokestatic a : ([BZ)Lcom/tencent/bugly/legu/proguard/an;
    //   1281: astore_2
    //   1282: aload_2
    //   1283: ifnonnull -> 1300
    //   1286: aload_0
    //   1287: aconst_null
    //   1288: iconst_0
    //   1289: iconst_1
    //   1290: ldc_w 'upload fail, resp null!'
    //   1293: iconst_0
    //   1294: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   1297: goto -> 89
    //   1300: aload_0
    //   1301: getfield q : Z
    //   1304: ifeq -> 1317
    //   1307: aload_0
    //   1308: getfield i : Lcom/tencent/bugly/legu/proguard/t;
    //   1311: iload #11
    //   1313: aload_2
    //   1314: invokevirtual a : (ILcom/tencent/bugly/legu/proguard/an;)V
    //   1317: aload_2
    //   1318: getfield b : I
    //   1321: istore #9
    //   1323: aload_2
    //   1324: getfield c : [B
    //   1327: ifnonnull -> 1388
    //   1330: iconst_0
    //   1331: istore_3
    //   1332: ldc_w 'response %d %d'
    //   1335: iconst_2
    //   1336: anewarray java/lang/Object
    //   1339: dup
    //   1340: iconst_0
    //   1341: iload #9
    //   1343: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1346: aastore
    //   1347: dup
    //   1348: iconst_1
    //   1349: iload_3
    //   1350: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   1353: aastore
    //   1354: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1357: pop
    //   1358: aload_2
    //   1359: aload_0
    //   1360: getfield f : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   1363: aload_0
    //   1364: getfield g : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   1367: invokestatic a : (Lcom/tencent/bugly/legu/proguard/an;Lcom/tencent/bugly/legu/crashreport/common/info/a;Lcom/tencent/bugly/legu/crashreport/common/strategy/a;)Z
    //   1370: ifne -> 1397
    //   1373: aload_0
    //   1374: aload_2
    //   1375: iconst_0
    //   1376: iconst_2
    //   1377: aload_2
    //   1378: getfield f : Ljava/lang/String;
    //   1381: iconst_0
    //   1382: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   1385: goto -> 89
    //   1388: aload_2
    //   1389: getfield c : [B
    //   1392: arraylength
    //   1393: istore_3
    //   1394: goto -> 1332
    //   1397: aload_0
    //   1398: aload_2
    //   1399: iconst_1
    //   1400: iconst_2
    //   1401: aconst_null
    //   1402: iconst_0
    //   1403: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   1406: goto -> 89
    //   1409: aload_0
    //   1410: aconst_null
    //   1411: iconst_0
    //   1412: iload #9
    //   1414: ldc_w 'try OT Fail!'
    //   1417: iconst_0
    //   1418: invokespecial a : (Lcom/tencent/bugly/legu/proguard/an;ZILjava/lang/String;I)V
    //   1421: goto -> 89
    // Exception table:
    //   from	to	target	type
    //   0	51	113	java/lang/Throwable
    //   51	68	113	java/lang/Throwable
    //   68	89	113	java/lang/Throwable
    //   94	99	113	java/lang/Throwable
    //   99	110	113	java/lang/Throwable
    //   128	213	113	java/lang/Throwable
    //   216	244	113	java/lang/Throwable
    //   248	269	113	java/lang/Throwable
    //   269	280	113	java/lang/Throwable
    //   283	292	113	java/lang/Throwable
    //   297	308	113	java/lang/Throwable
    //   311	375	113	java/lang/Throwable
    //   377	481	113	java/lang/Throwable
    //   484	490	113	java/lang/Throwable
    //   494	505	113	java/lang/Throwable
    //   508	517	113	java/lang/Throwable
    //   523	534	113	java/lang/Throwable
    //   545	553	113	java/lang/Throwable
    //   562	586	113	java/lang/Throwable
    //   590	595	767	java/lang/InterruptedException
    //   590	595	113	java/lang/Throwable
    //   595	619	113	java/lang/Throwable
    //   623	633	113	java/lang/Throwable
    //   639	665	113	java/lang/Throwable
    //   665	727	113	java/lang/Throwable
    //   731	758	113	java/lang/Throwable
    //   768	772	113	java/lang/Throwable
    //   780	789	113	java/lang/Throwable
    //   792	801	113	java/lang/Throwable
    //   804	813	113	java/lang/Throwable
    //   817	824	113	java/lang/Throwable
    //   829	852	113	java/lang/Throwable
    //   852	908	113	java/lang/Throwable
    //   917	934	1100	java/lang/Throwable
    //   937	973	1100	java/lang/Throwable
    //   985	1035	113	java/lang/Throwable
    //   1035	1097	113	java/lang/Throwable
    //   1101	1150	113	java/lang/Throwable
    //   1159	1189	113	java/lang/Throwable
    //   1192	1227	113	java/lang/Throwable
    //   1231	1242	113	java/lang/Throwable
    //   1245	1251	113	java/lang/Throwable
    //   1257	1268	113	java/lang/Throwable
    //   1273	1282	113	java/lang/Throwable
    //   1286	1297	113	java/lang/Throwable
    //   1300	1317	113	java/lang/Throwable
    //   1317	1330	113	java/lang/Throwable
    //   1332	1385	113	java/lang/Throwable
    //   1388	1394	113	java/lang/Throwable
    //   1397	1406	113	java/lang/Throwable
    //   1409	1421	113	java/lang/Throwable
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */