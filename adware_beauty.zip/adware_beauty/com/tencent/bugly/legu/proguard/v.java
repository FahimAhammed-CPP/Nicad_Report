package com.tencent.bugly.legu.proguard;

import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public final class v {
  private static v a;
  
  private ScheduledExecutorService b = null;
  
  private ThreadPoolExecutor c = null;
  
  private ThreadPoolExecutor d = null;
  
  protected v() {
    ThreadFactory threadFactory = new ThreadFactory(this) {
        public final Thread newThread(Runnable param1Runnable) {
          param1Runnable = new Thread(param1Runnable);
          param1Runnable.setName("BUGLY_THREAD");
          return (Thread)param1Runnable;
        }
      };
    this.b = Executors.newScheduledThreadPool(3, threadFactory);
    this.c = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>(100), threadFactory);
    this.d = new ThreadPoolExecutor(2, 2147483647, 10L, TimeUnit.SECONDS, new LinkedBlockingQueue<Runnable>(), threadFactory);
    if (this.b == null || this.b.isShutdown())
      w.d("ScheduledExecutorService is not valiable!", new Object[0]); 
    if (this.c == null || this.c.isShutdown())
      w.d("QueueExecutorService is not valiable!", new Object[0]); 
    if (this.d == null || this.d.isShutdown())
      w.d("ploadExecutorService is not valiable!", new Object[0]); 
  }
  
  public static v a() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/proguard/v
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/proguard/v.a : Lcom/tencent/bugly/legu/proguard/v;
    //   6: ifnonnull -> 21
    //   9: new com/tencent/bugly/legu/proguard/v
    //   12: astore_0
    //   13: aload_0
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: putstatic com/tencent/bugly/legu/proguard/v.a : Lcom/tencent/bugly/legu/proguard/v;
    //   21: getstatic com/tencent/bugly/legu/proguard/v.a : Lcom/tencent/bugly/legu/proguard/v;
    //   24: astore_0
    //   25: ldc com/tencent/bugly/legu/proguard/v
    //   27: monitorexit
    //   28: aload_0
    //   29: areturn
    //   30: astore_0
    //   31: ldc com/tencent/bugly/legu/proguard/v
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	30	finally
    //   21	25	30	finally
  }
  
  private boolean c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   6: ifnull -> 63
    //   9: aload_0
    //   10: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   13: invokeinterface isShutdown : ()Z
    //   18: ifne -> 63
    //   21: aload_0
    //   22: getfield c : Ljava/util/concurrent/ThreadPoolExecutor;
    //   25: ifnull -> 63
    //   28: aload_0
    //   29: getfield c : Ljava/util/concurrent/ThreadPoolExecutor;
    //   32: invokevirtual isShutdown : ()Z
    //   35: ifne -> 63
    //   38: aload_0
    //   39: getfield d : Ljava/util/concurrent/ThreadPoolExecutor;
    //   42: ifnull -> 63
    //   45: aload_0
    //   46: getfield d : Ljava/util/concurrent/ThreadPoolExecutor;
    //   49: invokevirtual isShutdown : ()Z
    //   52: istore_1
    //   53: iload_1
    //   54: ifne -> 63
    //   57: iconst_1
    //   58: istore_1
    //   59: aload_0
    //   60: monitorexit
    //   61: iload_1
    //   62: ireturn
    //   63: iconst_0
    //   64: istore_1
    //   65: goto -> 59
    //   68: astore_2
    //   69: aload_0
    //   70: monitorexit
    //   71: aload_2
    //   72: athrow
    // Exception table:
    //   from	to	target	type
    //   2	53	68	finally
  }
  
  public final boolean a(Runnable paramRunnable) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: invokespecial c : ()Z
    //   8: ifne -> 34
    //   11: iload_2
    //   12: istore_3
    //   13: getstatic com/tencent/bugly/legu/b.b : Z
    //   16: ifeq -> 30
    //   19: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   22: ldc 'queue handler was closed , should not post task!'
    //   24: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   27: pop
    //   28: iload_2
    //   29: istore_3
    //   30: aload_0
    //   31: monitorexit
    //   32: iload_3
    //   33: ireturn
    //   34: aload_1
    //   35: ifnonnull -> 65
    //   38: iload_2
    //   39: istore_3
    //   40: getstatic com/tencent/bugly/legu/b.b : Z
    //   43: ifeq -> 30
    //   46: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   49: ldc 'queue task is null'
    //   51: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   54: pop
    //   55: iload_2
    //   56: istore_3
    //   57: goto -> 30
    //   60: astore_1
    //   61: aload_0
    //   62: monitorexit
    //   63: aload_1
    //   64: athrow
    //   65: aload_0
    //   66: getfield c : Ljava/util/concurrent/ThreadPoolExecutor;
    //   69: aload_1
    //   70: invokevirtual submit : (Ljava/lang/Runnable;)Ljava/util/concurrent/Future;
    //   73: pop
    //   74: iconst_1
    //   75: istore_3
    //   76: goto -> 30
    //   79: astore_1
    //   80: iload_2
    //   81: istore_3
    //   82: getstatic com/tencent/bugly/legu/b.b : Z
    //   85: ifeq -> 30
    //   88: aload_1
    //   89: invokevirtual printStackTrace : ()V
    //   92: iload_2
    //   93: istore_3
    //   94: goto -> 30
    // Exception table:
    //   from	to	target	type
    //   4	11	60	finally
    //   13	28	60	finally
    //   40	55	60	finally
    //   65	74	79	java/lang/Throwable
    //   65	74	60	finally
    //   82	92	60	finally
  }
  
  public final boolean a(Runnable paramRunnable, long paramLong) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #4
    //   3: aload_0
    //   4: monitorenter
    //   5: aload_0
    //   6: invokespecial c : ()Z
    //   9: ifne -> 31
    //   12: ldc 'async handler was closed , should not post task!'
    //   14: iconst_0
    //   15: anewarray java/lang/Object
    //   18: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   21: pop
    //   22: iload #4
    //   24: istore #5
    //   26: aload_0
    //   27: monitorexit
    //   28: iload #5
    //   30: ireturn
    //   31: aload_1
    //   32: ifnonnull -> 57
    //   35: ldc 'async task == null'
    //   37: iconst_0
    //   38: anewarray java/lang/Object
    //   41: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   44: pop
    //   45: iload #4
    //   47: istore #5
    //   49: goto -> 26
    //   52: astore_1
    //   53: aload_0
    //   54: monitorexit
    //   55: aload_1
    //   56: athrow
    //   57: lload_2
    //   58: lconst_0
    //   59: lcmp
    //   60: ifle -> 111
    //   63: ldc 'delay %d task %s'
    //   65: iconst_2
    //   66: anewarray java/lang/Object
    //   69: dup
    //   70: iconst_0
    //   71: lload_2
    //   72: invokestatic valueOf : (J)Ljava/lang/Long;
    //   75: aastore
    //   76: dup
    //   77: iconst_1
    //   78: aload_1
    //   79: invokevirtual getClass : ()Ljava/lang/Class;
    //   82: invokevirtual getName : ()Ljava/lang/String;
    //   85: aastore
    //   86: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   89: pop
    //   90: aload_0
    //   91: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   94: aload_1
    //   95: lload_2
    //   96: getstatic java/util/concurrent/TimeUnit.MILLISECONDS : Ljava/util/concurrent/TimeUnit;
    //   99: invokeinterface schedule : (Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;
    //   104: pop
    //   105: iconst_1
    //   106: istore #5
    //   108: goto -> 26
    //   111: lconst_0
    //   112: lstore_2
    //   113: goto -> 63
    //   116: astore_1
    //   117: iload #4
    //   119: istore #5
    //   121: getstatic com/tencent/bugly/legu/b.b : Z
    //   124: ifeq -> 26
    //   127: aload_1
    //   128: invokevirtual printStackTrace : ()V
    //   131: iload #4
    //   133: istore #5
    //   135: goto -> 26
    // Exception table:
    //   from	to	target	type
    //   5	22	52	finally
    //   35	45	52	finally
    //   63	90	52	finally
    //   90	105	116	java/lang/Throwable
    //   90	105	52	finally
    //   121	131	52	finally
  }
  
  public final void b() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   6: ifnull -> 41
    //   9: aload_0
    //   10: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   13: invokeinterface isShutdown : ()Z
    //   18: ifne -> 41
    //   21: ldc 'close async handler'
    //   23: iconst_0
    //   24: anewarray java/lang/Object
    //   27: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   30: pop
    //   31: aload_0
    //   32: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   35: invokeinterface shutdownNow : ()Ljava/util/List;
    //   40: pop
    //   41: aload_0
    //   42: getfield c : Ljava/util/concurrent/ThreadPoolExecutor;
    //   45: ifnull -> 76
    //   48: aload_0
    //   49: getfield c : Ljava/util/concurrent/ThreadPoolExecutor;
    //   52: invokevirtual isShutdown : ()Z
    //   55: ifne -> 76
    //   58: ldc 'close async queue handler'
    //   60: iconst_0
    //   61: anewarray java/lang/Object
    //   64: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   67: pop
    //   68: aload_0
    //   69: getfield c : Ljava/util/concurrent/ThreadPoolExecutor;
    //   72: invokevirtual shutdownNow : ()Ljava/util/List;
    //   75: pop
    //   76: aload_0
    //   77: getfield d : Ljava/util/concurrent/ThreadPoolExecutor;
    //   80: ifnull -> 111
    //   83: aload_0
    //   84: getfield d : Ljava/util/concurrent/ThreadPoolExecutor;
    //   87: invokevirtual isShutdown : ()Z
    //   90: ifne -> 111
    //   93: ldc 'close async upload handler'
    //   95: iconst_0
    //   96: anewarray java/lang/Object
    //   99: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   102: pop
    //   103: aload_0
    //   104: getfield d : Ljava/util/concurrent/ThreadPoolExecutor;
    //   107: invokevirtual shutdownNow : ()Ljava/util/List;
    //   110: pop
    //   111: aload_0
    //   112: monitorexit
    //   113: return
    //   114: astore_1
    //   115: aload_0
    //   116: monitorexit
    //   117: aload_1
    //   118: athrow
    // Exception table:
    //   from	to	target	type
    //   2	41	114	finally
    //   41	76	114	finally
    //   76	111	114	finally
  }
  
  public final boolean b(Runnable paramRunnable) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: invokespecial c : ()Z
    //   8: ifne -> 27
    //   11: ldc 'async handler was closed , should not post task!'
    //   13: iconst_0
    //   14: anewarray java/lang/Object
    //   17: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   20: pop
    //   21: iload_2
    //   22: istore_3
    //   23: aload_0
    //   24: monitorexit
    //   25: iload_3
    //   26: ireturn
    //   27: aload_1
    //   28: ifnonnull -> 51
    //   31: ldc 'async task == null'
    //   33: iconst_0
    //   34: anewarray java/lang/Object
    //   37: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   40: pop
    //   41: iload_2
    //   42: istore_3
    //   43: goto -> 23
    //   46: astore_1
    //   47: aload_0
    //   48: monitorexit
    //   49: aload_1
    //   50: athrow
    //   51: ldc 'normal task %s'
    //   53: iconst_1
    //   54: anewarray java/lang/Object
    //   57: dup
    //   58: iconst_0
    //   59: aload_1
    //   60: invokevirtual getClass : ()Ljava/lang/Class;
    //   63: invokevirtual getName : ()Ljava/lang/String;
    //   66: aastore
    //   67: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   70: pop
    //   71: aload_0
    //   72: getfield b : Ljava/util/concurrent/ScheduledExecutorService;
    //   75: aload_1
    //   76: invokeinterface execute : (Ljava/lang/Runnable;)V
    //   81: iconst_1
    //   82: istore_3
    //   83: goto -> 23
    //   86: astore_1
    //   87: iload_2
    //   88: istore_3
    //   89: getstatic com/tencent/bugly/legu/b.b : Z
    //   92: ifeq -> 23
    //   95: aload_1
    //   96: invokevirtual printStackTrace : ()V
    //   99: iload_2
    //   100: istore_3
    //   101: goto -> 23
    // Exception table:
    //   from	to	target	type
    //   4	21	46	finally
    //   31	41	46	finally
    //   51	71	46	finally
    //   71	81	86	java/lang/Throwable
    //   71	81	46	finally
    //   89	99	46	finally
  }
  
  public final boolean c(Runnable paramRunnable) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: invokespecial c : ()Z
    //   8: ifne -> 34
    //   11: iload_2
    //   12: istore_3
    //   13: getstatic com/tencent/bugly/legu/b.b : Z
    //   16: ifeq -> 30
    //   19: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   22: ldc 'queue handler was closed , should not post task!'
    //   24: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   27: pop
    //   28: iload_2
    //   29: istore_3
    //   30: aload_0
    //   31: monitorexit
    //   32: iload_3
    //   33: ireturn
    //   34: aload_1
    //   35: ifnonnull -> 65
    //   38: iload_2
    //   39: istore_3
    //   40: getstatic com/tencent/bugly/legu/b.b : Z
    //   43: ifeq -> 30
    //   46: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   49: ldc 'queue task is null'
    //   51: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   54: pop
    //   55: iload_2
    //   56: istore_3
    //   57: goto -> 30
    //   60: astore_1
    //   61: aload_0
    //   62: monitorexit
    //   63: aload_1
    //   64: athrow
    //   65: aload_0
    //   66: getfield d : Ljava/util/concurrent/ThreadPoolExecutor;
    //   69: aload_1
    //   70: invokevirtual submit : (Ljava/lang/Runnable;)Ljava/util/concurrent/Future;
    //   73: pop
    //   74: iconst_1
    //   75: istore_3
    //   76: goto -> 30
    //   79: astore_1
    //   80: iload_2
    //   81: istore_3
    //   82: getstatic com/tencent/bugly/legu/b.b : Z
    //   85: ifeq -> 30
    //   88: aload_1
    //   89: invokevirtual printStackTrace : ()V
    //   92: iload_2
    //   93: istore_3
    //   94: goto -> 30
    // Exception table:
    //   from	to	target	type
    //   4	11	60	finally
    //   13	28	60	finally
    //   40	55	60	finally
    //   65	74	79	java/lang/Throwable
    //   65	74	60	finally
    //   82	92	60	finally
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */