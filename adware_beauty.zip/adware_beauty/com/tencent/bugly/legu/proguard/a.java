package com.tencent.bugly.legu.proguard;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Process;
import android.os.StatFs;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import com.tencent.bugly.legu.crashreport.biz.UserInfoBean;
import com.tencent.bugly.legu.crashreport.common.info.AppInfo;
import com.tencent.bugly.legu.crashreport.common.info.PlugInBean;
import com.tencent.bugly.legu.crashreport.common.strategy.StrategyBean;
import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class a {
  protected HashMap<String, HashMap<String, byte[]>> a = new HashMap<String, HashMap<String, byte[]>>();
  
  protected String b;
  
  h c;
  
  private HashMap<String, Object> d;
  
  a() {
    new HashMap<Object, Object>();
    this.d = new HashMap<String, Object>();
    this.b = "GBK";
    this.c = new h();
  }
  
  public static am a(Context paramContext, int paramInt, byte[] paramArrayOfbyte) {
    com.tencent.bugly.legu.crashreport.common.info.a a1 = com.tencent.bugly.legu.crashreport.common.info.a.a();
    StrategyBean strategyBean = com.tencent.bugly.legu.crashreport.common.strategy.a.a().c();
    if (a1 == null || strategyBean == null) {
      w.e("illigle access to create req pkg!", new Object[0]);
      return null;
    } 
    try {
      am am = new am();
      this();
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{com/tencent/bugly/legu/crashreport/common/info/a}, name=null} */
      try {
        am.a = 1;
        am.b = a1.e();
        am.c = a1.c;
        am.d = a1.i;
        am.e = a1.j;
        a1.getClass();
        am.f = "2.1.9";
        am.g = paramInt;
        byte[] arrayOfByte = paramArrayOfbyte;
        if (paramArrayOfbyte == null)
          arrayOfByte = "".getBytes(); 
        am.h = arrayOfByte;
        am.i = a1.f;
        am.j = a1.g;
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        this();
        am.k = (Map)hashMap;
        am.l = a1.d();
        am.m = strategyBean.l;
        am.o = a1.g();
        am.p = e(paramContext);
        am.q = System.currentTimeMillis();
        StringBuilder stringBuilder1 = new StringBuilder();
        this();
        am.r = stringBuilder1.append(a1.j()).toString();
        am.s = a1.i();
        stringBuilder1 = new StringBuilder();
        this();
        am.t = stringBuilder1.append(a1.l()).toString();
        am.u = a1.k();
        stringBuilder1 = new StringBuilder();
        this();
        am.v = stringBuilder1.append(a1.m()).toString();
        am.w = am.p;
        a1.getClass();
        am.n = "com.tencent.bugly";
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{com/tencent/bugly/legu/crashreport/common/info/a}, name=null} */
        Map<String, String> map = am.k;
        StringBuilder stringBuilder2 = new StringBuilder();
        this();
        map.put("F11", stringBuilder2.append(a1.y).toString());
        map = am.k;
        stringBuilder2 = new StringBuilder();
        this();
        map.put("F12", stringBuilder2.append(a1.x).toString());
        am am1 = am;
      } finally {}
    } catch (Throwable throwable) {}
    return (am)throwable;
  }
  
  public static an a(byte[] paramArrayOfbyte, boolean paramBoolean) {
    if (paramArrayOfbyte != null)
      try {
        d d = new d();
        this();
        d.p();
        d.a("utf-8");
        d.a(paramArrayOfbyte);
        an an1 = new an();
        this();
        an1 = d.b("detail", an1);
        if (an.class.isInstance(an1)) {
          an1 = an.class.cast(an1);
        } else {
          an1 = null;
        } 
        an an2 = an1;
        if (!paramBoolean) {
          an2 = an1;
          if (an1 != null) {
            an2 = an1;
            if (an1.c != null) {
              an2 = an1;
              if (an1.c.length > 0) {
                w.c("resp buf %d", new Object[] { Integer.valueOf(an1.c.length) });
                an1.c = a(an1.c, 2, 1, StrategyBean.a);
                an2 = an1;
                if (an1.c == null) {
                  w.e("resp sbuffer error!", new Object[0]);
                  an2 = null;
                } 
              } 
            } 
          } 
        } 
        return an2;
      } catch (Throwable throwable) {
        if (!w.b(throwable))
          throwable.printStackTrace(); 
      }  
    return null;
  }
  
  public static aq a(UserInfoBean paramUserInfoBean) {
    // Byte code:
    //   0: aload_0
    //   1: ifnonnull -> 8
    //   4: aconst_null
    //   5: astore_0
    //   6: aload_0
    //   7: areturn
    //   8: new com/tencent/bugly/legu/proguard/aq
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: astore_1
    //   16: aload_1
    //   17: aload_0
    //   18: getfield e : J
    //   21: putfield a : J
    //   24: aload_1
    //   25: aload_0
    //   26: getfield j : Ljava/lang/String;
    //   29: putfield e : Ljava/lang/String;
    //   32: aload_1
    //   33: aload_0
    //   34: getfield c : Ljava/lang/String;
    //   37: putfield d : Ljava/lang/String;
    //   40: aload_1
    //   41: aload_0
    //   42: getfield d : Ljava/lang/String;
    //   45: putfield c : Ljava/lang/String;
    //   48: aload_1
    //   49: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   52: invokevirtual h : ()Ljava/lang/String;
    //   55: putfield g : Ljava/lang/String;
    //   58: aload_0
    //   59: getfield o : I
    //   62: iconst_1
    //   63: if_icmpne -> 321
    //   66: iconst_1
    //   67: istore_2
    //   68: aload_1
    //   69: iload_2
    //   70: putfield h : Z
    //   73: aload_0
    //   74: getfield b : I
    //   77: tableswitch default -> 108, 1 -> 326, 2 -> 344, 3 -> 335, 4 -> 353
    //   108: aload_0
    //   109: getfield b : I
    //   112: bipush #10
    //   114: if_icmplt -> 362
    //   117: aload_0
    //   118: getfield b : I
    //   121: bipush #20
    //   123: if_icmpge -> 362
    //   126: aload_1
    //   127: aload_0
    //   128: getfield b : I
    //   131: i2b
    //   132: i2b
    //   133: putfield b : B
    //   136: aload_1
    //   137: new java/util/HashMap
    //   140: dup
    //   141: invokespecial <init> : ()V
    //   144: putfield f : Ljava/util/Map;
    //   147: aload_0
    //   148: getfield p : I
    //   151: iflt -> 184
    //   154: aload_1
    //   155: getfield f : Ljava/util/Map;
    //   158: ldc_w 'C01'
    //   161: new java/lang/StringBuilder
    //   164: dup
    //   165: invokespecial <init> : ()V
    //   168: aload_0
    //   169: getfield p : I
    //   172: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   175: invokevirtual toString : ()Ljava/lang/String;
    //   178: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   183: pop
    //   184: aload_0
    //   185: getfield q : I
    //   188: iflt -> 221
    //   191: aload_1
    //   192: getfield f : Ljava/util/Map;
    //   195: ldc_w 'C02'
    //   198: new java/lang/StringBuilder
    //   201: dup
    //   202: invokespecial <init> : ()V
    //   205: aload_0
    //   206: getfield q : I
    //   209: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   212: invokevirtual toString : ()Ljava/lang/String;
    //   215: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   220: pop
    //   221: aload_0
    //   222: getfield r : Ljava/util/Map;
    //   225: ifnull -> 388
    //   228: aload_0
    //   229: getfield r : Ljava/util/Map;
    //   232: invokeinterface size : ()I
    //   237: ifle -> 388
    //   240: aload_0
    //   241: getfield r : Ljava/util/Map;
    //   244: invokeinterface entrySet : ()Ljava/util/Set;
    //   249: invokeinterface iterator : ()Ljava/util/Iterator;
    //   254: astore_3
    //   255: aload_3
    //   256: invokeinterface hasNext : ()Z
    //   261: ifeq -> 388
    //   264: aload_3
    //   265: invokeinterface next : ()Ljava/lang/Object;
    //   270: checkcast java/util/Map$Entry
    //   273: astore #4
    //   275: aload_1
    //   276: getfield f : Ljava/util/Map;
    //   279: new java/lang/StringBuilder
    //   282: dup
    //   283: ldc_w 'C03_'
    //   286: invokespecial <init> : (Ljava/lang/String;)V
    //   289: aload #4
    //   291: invokeinterface getKey : ()Ljava/lang/Object;
    //   296: checkcast java/lang/String
    //   299: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   302: invokevirtual toString : ()Ljava/lang/String;
    //   305: aload #4
    //   307: invokeinterface getValue : ()Ljava/lang/Object;
    //   312: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   317: pop
    //   318: goto -> 255
    //   321: iconst_0
    //   322: istore_2
    //   323: goto -> 68
    //   326: aload_1
    //   327: iconst_1
    //   328: i2b
    //   329: putfield b : B
    //   332: goto -> 136
    //   335: aload_1
    //   336: iconst_2
    //   337: i2b
    //   338: putfield b : B
    //   341: goto -> 136
    //   344: aload_1
    //   345: iconst_4
    //   346: i2b
    //   347: putfield b : B
    //   350: goto -> 136
    //   353: aload_1
    //   354: iconst_3
    //   355: i2b
    //   356: putfield b : B
    //   359: goto -> 136
    //   362: ldc_w 'unknown uinfo type %d '
    //   365: iconst_1
    //   366: anewarray java/lang/Object
    //   369: dup
    //   370: iconst_0
    //   371: aload_0
    //   372: getfield b : I
    //   375: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   378: aastore
    //   379: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   382: pop
    //   383: aconst_null
    //   384: astore_0
    //   385: goto -> 6
    //   388: aload_0
    //   389: getfield s : Ljava/util/Map;
    //   392: ifnull -> 488
    //   395: aload_0
    //   396: getfield s : Ljava/util/Map;
    //   399: invokeinterface size : ()I
    //   404: ifle -> 488
    //   407: aload_0
    //   408: getfield s : Ljava/util/Map;
    //   411: invokeinterface entrySet : ()Ljava/util/Set;
    //   416: invokeinterface iterator : ()Ljava/util/Iterator;
    //   421: astore_3
    //   422: aload_3
    //   423: invokeinterface hasNext : ()Z
    //   428: ifeq -> 488
    //   431: aload_3
    //   432: invokeinterface next : ()Ljava/lang/Object;
    //   437: checkcast java/util/Map$Entry
    //   440: astore #4
    //   442: aload_1
    //   443: getfield f : Ljava/util/Map;
    //   446: new java/lang/StringBuilder
    //   449: dup
    //   450: ldc_w 'C04_'
    //   453: invokespecial <init> : (Ljava/lang/String;)V
    //   456: aload #4
    //   458: invokeinterface getKey : ()Ljava/lang/Object;
    //   463: checkcast java/lang/String
    //   466: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   469: invokevirtual toString : ()Ljava/lang/String;
    //   472: aload #4
    //   474: invokeinterface getValue : ()Ljava/lang/Object;
    //   479: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   484: pop
    //   485: goto -> 422
    //   488: aload_1
    //   489: getfield f : Ljava/util/Map;
    //   492: astore_3
    //   493: new java/lang/StringBuilder
    //   496: dup
    //   497: invokespecial <init> : ()V
    //   500: astore #4
    //   502: aload_0
    //   503: getfield l : Z
    //   506: ifne -> 751
    //   509: iconst_1
    //   510: istore_2
    //   511: aload_3
    //   512: ldc_w 'A36'
    //   515: aload #4
    //   517: iload_2
    //   518: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   521: invokevirtual toString : ()Ljava/lang/String;
    //   524: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   529: pop
    //   530: aload_1
    //   531: getfield f : Ljava/util/Map;
    //   534: ldc_w 'F02'
    //   537: new java/lang/StringBuilder
    //   540: dup
    //   541: invokespecial <init> : ()V
    //   544: aload_0
    //   545: getfield g : J
    //   548: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   551: invokevirtual toString : ()Ljava/lang/String;
    //   554: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   559: pop
    //   560: aload_1
    //   561: getfield f : Ljava/util/Map;
    //   564: ldc_w 'F03'
    //   567: new java/lang/StringBuilder
    //   570: dup
    //   571: invokespecial <init> : ()V
    //   574: aload_0
    //   575: getfield h : J
    //   578: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   581: invokevirtual toString : ()Ljava/lang/String;
    //   584: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   589: pop
    //   590: aload_1
    //   591: getfield f : Ljava/util/Map;
    //   594: ldc_w 'F04'
    //   597: new java/lang/StringBuilder
    //   600: dup
    //   601: invokespecial <init> : ()V
    //   604: aload_0
    //   605: getfield j : Ljava/lang/String;
    //   608: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   611: invokevirtual toString : ()Ljava/lang/String;
    //   614: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   619: pop
    //   620: aload_1
    //   621: getfield f : Ljava/util/Map;
    //   624: ldc_w 'F05'
    //   627: new java/lang/StringBuilder
    //   630: dup
    //   631: invokespecial <init> : ()V
    //   634: aload_0
    //   635: getfield i : J
    //   638: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   641: invokevirtual toString : ()Ljava/lang/String;
    //   644: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   649: pop
    //   650: aload_1
    //   651: getfield f : Ljava/util/Map;
    //   654: ldc_w 'F06'
    //   657: new java/lang/StringBuilder
    //   660: dup
    //   661: invokespecial <init> : ()V
    //   664: aload_0
    //   665: getfield m : Ljava/lang/String;
    //   668: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   671: invokevirtual toString : ()Ljava/lang/String;
    //   674: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   679: pop
    //   680: aload_1
    //   681: getfield f : Ljava/util/Map;
    //   684: ldc_w 'F10'
    //   687: new java/lang/StringBuilder
    //   690: dup
    //   691: invokespecial <init> : ()V
    //   694: aload_0
    //   695: getfield k : J
    //   698: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   701: invokevirtual toString : ()Ljava/lang/String;
    //   704: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   709: pop
    //   710: ldc_w 'summary type %d vm:%d'
    //   713: iconst_2
    //   714: anewarray java/lang/Object
    //   717: dup
    //   718: iconst_0
    //   719: aload_1
    //   720: getfield b : B
    //   723: invokestatic valueOf : (B)Ljava/lang/Byte;
    //   726: aastore
    //   727: dup
    //   728: iconst_1
    //   729: aload_1
    //   730: getfield f : Ljava/util/Map;
    //   733: invokeinterface size : ()I
    //   738: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   741: aastore
    //   742: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   745: pop
    //   746: aload_1
    //   747: astore_0
    //   748: goto -> 6
    //   751: iconst_0
    //   752: istore_2
    //   753: goto -> 511
  }
  
  public static ar a(List<UserInfoBean> paramList, int paramInt) {
    if (paramList == null || paramList.size() == 0)
      return null; 
    com.tencent.bugly.legu.crashreport.common.info.a a1 = com.tencent.bugly.legu.crashreport.common.info.a.a();
    ar ar = new ar();
    ar.b = a1.d;
    ar.c = a1.g();
    ArrayList<aq> arrayList = new ArrayList();
    Iterator<UserInfoBean> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      aq aq = a(iterator.next());
      if (aq != null)
        arrayList.add(aq); 
    } 
    ar.d = arrayList;
    ar.e = new HashMap<String, String>();
    ar.e.put("A7", a1.e);
    ar.e.put("A6", a1.r());
    ar.e.put("A5", a1.q());
    ar.e.put("A2", a1.o());
    ar.e.put("A1", a1.o());
    ar.e.put("A24", a1.g);
    ar.e.put("A17", a1.p());
    ar.e.put("A15", a1.t());
    ar.e.put("A13", a1.u());
    ar.e.put("F08", a1.u);
    ar.e.put("F09", a1.v);
    null = a1.A();
    if (null != null && null.size() > 0)
      for (Map.Entry entry : null.entrySet())
        ar.e.put("C04_" + (String)entry.getKey(), (String)entry.getValue());  
    switch (paramInt) {
      default:
        w.e("unknown up type %d ", new Object[] { Integer.valueOf(paramInt) });
        return null;
      case 1:
        ar.a = (byte)1;
        return ar;
      case 2:
        break;
    } 
    ar.a = (byte)2;
    return ar;
  }
  
  public static <T extends j> T a(byte[] paramArrayOfbyte, Class<T> paramClass) {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length <= 0)
      return null; 
    try {
      j j2 = (j)paramClass.newInstance();
      h h1 = new h();
      this(paramArrayOfbyte);
      h1.a("utf-8");
      j2.a(h1);
      j j1 = j2;
    } catch (Throwable throwable) {}
    return (T)throwable;
  }
  
  public static Object a(String paramString1, String paramString2, Object paramObject, Class<?>[] paramArrayOfClass, Object[] paramArrayOfObject) {
    Object object;
    paramObject = null;
    try {
      Method method = Class.forName(paramString1).getDeclaredMethod(paramString2, paramArrayOfClass);
      method.setAccessible(true);
      object = method.invoke(null, paramArrayOfObject);
    } catch (Exception exception) {
      object = paramObject;
    } 
    return object;
  }
  
  public static <T> T a(byte[] paramArrayOfbyte, Parcelable.Creator<T> paramCreator) {
    Parcel parcel = Parcel.obtain();
    parcel.unmarshall(paramArrayOfbyte, 0, paramArrayOfbyte.length);
    parcel.setDataPosition(0);
    try {
      Object object2 = paramCreator.createFromParcel(parcel);
      Object object1 = object2;
      return (T)object1;
    } catch (Throwable null) {
      null.printStackTrace();
      return null;
    } finally {
      if (parcel != null)
        parcel.recycle(); 
    } 
  }
  
  public static String a(Context paramContext) {
    if (!AppInfo.a(paramContext, "android.permission.READ_PHONE_STATE")) {
      w.d("no READ_PHONE_STATE permission to get IMEI", new Object[0]);
      return "null";
    } 
    if (paramContext == null)
      return null; 
    try {
      String str2 = ((TelephonyManager)paramContext.getSystemService("phone")).getDeviceId();
      String str1 = str2;
      if (str2 != null)
        try {
          str1 = str2.toLowerCase();
        } catch (Throwable throwable1) {
          String str = str2;
        }  
    } catch (Throwable throwable) {
      throwable = null;
    } 
    return (String)throwable;
  }
  
  public static String a(Context paramContext, int paramInt, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: ldc_w 'android.permission.READ_LOGS'
    //   4: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Z
    //   7: ifne -> 25
    //   10: ldc_w 'no read_log permission!'
    //   13: iconst_0
    //   14: anewarray java/lang/Object
    //   17: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   20: pop
    //   21: aconst_null
    //   22: astore_2
    //   23: aload_2
    //   24: areturn
    //   25: aload_2
    //   26: ifnonnull -> 267
    //   29: iconst_4
    //   30: anewarray java/lang/String
    //   33: astore_0
    //   34: aload_0
    //   35: iconst_0
    //   36: ldc_w 'logcat'
    //   39: aastore
    //   40: aload_0
    //   41: iconst_1
    //   42: ldc_w '-d'
    //   45: aastore
    //   46: aload_0
    //   47: iconst_2
    //   48: ldc_w '-v'
    //   51: aastore
    //   52: aload_0
    //   53: iconst_3
    //   54: ldc_w 'threadtime'
    //   57: aastore
    //   58: aconst_null
    //   59: astore_2
    //   60: aconst_null
    //   61: astore_3
    //   62: new java/lang/StringBuilder
    //   65: dup
    //   66: invokespecial <init> : ()V
    //   69: astore #4
    //   71: invokestatic getRuntime : ()Ljava/lang/Runtime;
    //   74: aload_0
    //   75: invokevirtual exec : ([Ljava/lang/String;)Ljava/lang/Process;
    //   78: astore_0
    //   79: new java/io/BufferedReader
    //   82: astore_2
    //   83: new java/io/InputStreamReader
    //   86: astore #5
    //   88: aload #5
    //   90: aload_0
    //   91: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   94: invokespecial <init> : (Ljava/io/InputStream;)V
    //   97: aload_2
    //   98: aload #5
    //   100: invokespecial <init> : (Ljava/io/Reader;)V
    //   103: aload_2
    //   104: invokevirtual readLine : ()Ljava/lang/String;
    //   107: astore #5
    //   109: aload #5
    //   111: ifnull -> 310
    //   114: aload #4
    //   116: aload #5
    //   118: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   121: ldc_w '\\n'
    //   124: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   127: pop
    //   128: iload_1
    //   129: ifle -> 103
    //   132: aload #4
    //   134: invokevirtual length : ()I
    //   137: iload_1
    //   138: if_icmple -> 103
    //   141: aload #4
    //   143: iconst_0
    //   144: aload #4
    //   146: invokevirtual length : ()I
    //   149: iload_1
    //   150: isub
    //   151: invokevirtual delete : (II)Ljava/lang/StringBuilder;
    //   154: pop
    //   155: goto -> 103
    //   158: astore #5
    //   160: aload_0
    //   161: astore_2
    //   162: aload #5
    //   164: invokestatic a : (Ljava/lang/Throwable;)Z
    //   167: ifne -> 177
    //   170: aload_0
    //   171: astore_2
    //   172: aload #5
    //   174: invokevirtual printStackTrace : ()V
    //   177: aload_0
    //   178: astore_2
    //   179: new java/lang/StringBuilder
    //   182: astore_3
    //   183: aload_0
    //   184: astore_2
    //   185: aload_3
    //   186: ldc_w '\\n[error:'
    //   189: invokespecial <init> : (Ljava/lang/String;)V
    //   192: aload_0
    //   193: astore_2
    //   194: aload #4
    //   196: aload_3
    //   197: aload #5
    //   199: invokevirtual toString : ()Ljava/lang/String;
    //   202: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   205: ldc_w ']'
    //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: invokevirtual toString : ()Ljava/lang/String;
    //   214: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   217: invokevirtual toString : ()Ljava/lang/String;
    //   220: astore #5
    //   222: aload #5
    //   224: astore_2
    //   225: aload_0
    //   226: ifnull -> 23
    //   229: aload_0
    //   230: invokevirtual getOutputStream : ()Ljava/io/OutputStream;
    //   233: invokevirtual close : ()V
    //   236: aload_0
    //   237: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   240: invokevirtual close : ()V
    //   243: aload_0
    //   244: invokevirtual getErrorStream : ()Ljava/io/InputStream;
    //   247: invokevirtual close : ()V
    //   250: aload #5
    //   252: astore_2
    //   253: goto -> 23
    //   256: astore_0
    //   257: aload_0
    //   258: invokevirtual printStackTrace : ()V
    //   261: aload #5
    //   263: astore_2
    //   264: goto -> 23
    //   267: bipush #6
    //   269: anewarray java/lang/String
    //   272: astore_0
    //   273: aload_0
    //   274: iconst_0
    //   275: ldc_w 'logcat'
    //   278: aastore
    //   279: aload_0
    //   280: iconst_1
    //   281: ldc_w '-d'
    //   284: aastore
    //   285: aload_0
    //   286: iconst_2
    //   287: ldc_w '-v'
    //   290: aastore
    //   291: aload_0
    //   292: iconst_3
    //   293: ldc_w 'threadtime'
    //   296: aastore
    //   297: aload_0
    //   298: iconst_4
    //   299: ldc_w '-s'
    //   302: aastore
    //   303: aload_0
    //   304: iconst_5
    //   305: aload_2
    //   306: aastore
    //   307: goto -> 58
    //   310: aload #4
    //   312: invokevirtual toString : ()Ljava/lang/String;
    //   315: astore #5
    //   317: aload #5
    //   319: astore_2
    //   320: aload_0
    //   321: ifnull -> 23
    //   324: aload_0
    //   325: invokevirtual getOutputStream : ()Ljava/io/OutputStream;
    //   328: invokevirtual close : ()V
    //   331: aload_0
    //   332: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   335: invokevirtual close : ()V
    //   338: aload_0
    //   339: invokevirtual getErrorStream : ()Ljava/io/InputStream;
    //   342: invokevirtual close : ()V
    //   345: aload #5
    //   347: astore_2
    //   348: goto -> 23
    //   351: astore_0
    //   352: aload_0
    //   353: invokevirtual printStackTrace : ()V
    //   356: aload #5
    //   358: astore_2
    //   359: goto -> 23
    //   362: astore_2
    //   363: aload_2
    //   364: invokevirtual printStackTrace : ()V
    //   367: goto -> 331
    //   370: astore_2
    //   371: aload_2
    //   372: invokevirtual printStackTrace : ()V
    //   375: goto -> 338
    //   378: astore_2
    //   379: aload_2
    //   380: invokevirtual printStackTrace : ()V
    //   383: goto -> 236
    //   386: astore_2
    //   387: aload_2
    //   388: invokevirtual printStackTrace : ()V
    //   391: goto -> 243
    //   394: astore_0
    //   395: aload_2
    //   396: ifnull -> 420
    //   399: aload_2
    //   400: invokevirtual getOutputStream : ()Ljava/io/OutputStream;
    //   403: invokevirtual close : ()V
    //   406: aload_2
    //   407: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   410: invokevirtual close : ()V
    //   413: aload_2
    //   414: invokevirtual getErrorStream : ()Ljava/io/InputStream;
    //   417: invokevirtual close : ()V
    //   420: aload_0
    //   421: athrow
    //   422: astore #5
    //   424: aload #5
    //   426: invokevirtual printStackTrace : ()V
    //   429: goto -> 406
    //   432: astore #5
    //   434: aload #5
    //   436: invokevirtual printStackTrace : ()V
    //   439: goto -> 413
    //   442: astore_2
    //   443: aload_2
    //   444: invokevirtual printStackTrace : ()V
    //   447: goto -> 420
    //   450: astore_2
    //   451: aload_0
    //   452: astore #5
    //   454: aload_2
    //   455: astore_0
    //   456: aload #5
    //   458: astore_2
    //   459: goto -> 395
    //   462: astore #5
    //   464: aload_3
    //   465: astore_0
    //   466: goto -> 160
    // Exception table:
    //   from	to	target	type
    //   71	79	462	java/lang/Throwable
    //   71	79	394	finally
    //   79	103	158	java/lang/Throwable
    //   79	103	450	finally
    //   103	109	158	java/lang/Throwable
    //   103	109	450	finally
    //   114	128	158	java/lang/Throwable
    //   114	128	450	finally
    //   132	155	158	java/lang/Throwable
    //   132	155	450	finally
    //   162	170	394	finally
    //   172	177	394	finally
    //   179	183	394	finally
    //   185	192	394	finally
    //   194	222	394	finally
    //   229	236	378	java/io/IOException
    //   236	243	386	java/io/IOException
    //   243	250	256	java/io/IOException
    //   310	317	158	java/lang/Throwable
    //   310	317	450	finally
    //   324	331	362	java/io/IOException
    //   331	338	370	java/io/IOException
    //   338	345	351	java/io/IOException
    //   399	406	422	java/io/IOException
    //   406	413	432	java/io/IOException
    //   413	420	442	java/io/IOException
  }
  
  public static String a(Context paramContext, String paramString) {
    if (paramString == null || paramString.trim().equals(""))
      return ""; 
    ArrayList<String> arrayList = a(paramContext, new String[] { "/system/bin/sh", "-c", "getprop " + paramString });
    return (arrayList != null && arrayList.size() > 0) ? arrayList.get(0) : "fail";
  }
  
  public static String a(Throwable paramThrowable) {
    if (paramThrowable == null)
      return ""; 
    try {
      StringWriter stringWriter = new StringWriter();
      this();
      PrintWriter printWriter = new PrintWriter();
      this(stringWriter);
      paramThrowable.printStackTrace(printWriter);
      String str = stringWriter.getBuffer().toString();
    } catch (Throwable throwable) {}
    return (String)throwable;
  }
  
  public static String a(ArrayList<String> paramArrayList) {
    StringBuffer stringBuffer = new StringBuffer();
    byte b;
    for (b = 0; b < paramArrayList.size(); b++) {
      String str2;
      String str1 = paramArrayList.get(b);
      if (str1.equals("java.lang.Integer") || str1.equals("int")) {
        str2 = "int32";
      } else if (str1.equals("java.lang.Boolean") || str1.equals("boolean")) {
        str2 = "bool";
      } else if (str1.equals("java.lang.Byte") || str1.equals("byte")) {
        str2 = "char";
      } else if (str1.equals("java.lang.Double") || str1.equals("double")) {
        str2 = "double";
      } else if (str1.equals("java.lang.Float") || str1.equals("float")) {
        str2 = "float";
      } else if (str1.equals("java.lang.Long") || str1.equals("long")) {
        str2 = "int64";
      } else if (str1.equals("java.lang.Short") || str1.equals("short")) {
        str2 = "short";
      } else {
        if (str1.equals("java.lang.Character"))
          throw new IllegalArgumentException("can not support java.lang.Character"); 
        if (str1.equals("java.lang.String")) {
          str2 = "string";
        } else if (str1.equals("java.util.List")) {
          str2 = "list";
        } else {
          str2 = str1;
          if (str1.equals("java.util.Map"))
            str2 = "map"; 
        } 
      } 
      paramArrayList.set(b, str2);
    } 
    Collections.reverse(paramArrayList);
    for (b = 0; b < paramArrayList.size(); b++) {
      String str = paramArrayList.get(b);
      if (str.equals("list")) {
        paramArrayList.set(b - 1, "<" + (String)paramArrayList.get(b - 1));
        paramArrayList.set(0, (String)paramArrayList.get(0) + ">");
      } else if (str.equals("map")) {
        paramArrayList.set(b - 1, "<" + (String)paramArrayList.get(b - 1) + ",");
        paramArrayList.set(0, (String)paramArrayList.get(0) + ">");
      } else if (str.equals("Array")) {
        paramArrayList.set(b - 1, "<" + (String)paramArrayList.get(b - 1));
        paramArrayList.set(0, (String)paramArrayList.get(0) + ">");
      } 
    } 
    Collections.reverse(paramArrayList);
    Iterator<String> iterator = paramArrayList.iterator();
    while (iterator.hasNext())
      stringBuffer.append(iterator.next()); 
    return stringBuffer.toString();
  }
  
  public static String a(Date paramDate) {
    String str;
    if (paramDate == null)
      return null; 
    try {
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
      this("yyyy-MM-dd HH:mm:ss", Locale.US);
      str = simpleDateFormat.format(paramDate);
    } catch (Exception exception) {
      str = (new Date()).toString();
    } 
    return str;
  }
  
  public static ArrayList<String> a(Context paramContext, String[] paramArrayOfString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: new java/util/ArrayList
    //   5: dup
    //   6: invokespecial <init> : ()V
    //   9: astore_3
    //   10: aload_0
    //   11: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   14: invokevirtual D : ()Z
    //   17: ifeq -> 45
    //   20: new java/util/ArrayList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: astore_0
    //   28: aload_0
    //   29: new java/lang/String
    //   32: dup
    //   33: ldc_w 'unknown(low memory)'
    //   36: invokespecial <init> : (Ljava/lang/String;)V
    //   39: invokevirtual add : (Ljava/lang/Object;)Z
    //   42: pop
    //   43: aload_0
    //   44: areturn
    //   45: invokestatic getRuntime : ()Ljava/lang/Runtime;
    //   48: aload_1
    //   49: invokevirtual exec : ([Ljava/lang/String;)Ljava/lang/Process;
    //   52: astore_0
    //   53: new java/io/BufferedReader
    //   56: astore_1
    //   57: new java/io/InputStreamReader
    //   60: astore #4
    //   62: aload #4
    //   64: aload_0
    //   65: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   68: invokespecial <init> : (Ljava/io/InputStream;)V
    //   71: aload_1
    //   72: aload #4
    //   74: invokespecial <init> : (Ljava/io/Reader;)V
    //   77: aload_1
    //   78: invokevirtual readLine : ()Ljava/lang/String;
    //   81: astore #4
    //   83: aload #4
    //   85: ifnull -> 143
    //   88: aload_3
    //   89: aload #4
    //   91: invokevirtual add : (Ljava/lang/Object;)Z
    //   94: pop
    //   95: goto -> 77
    //   98: astore_3
    //   99: aconst_null
    //   100: astore_0
    //   101: aload_0
    //   102: astore_2
    //   103: aload_1
    //   104: astore #4
    //   106: aload_3
    //   107: invokestatic a : (Ljava/lang/Throwable;)Z
    //   110: ifne -> 122
    //   113: aload_0
    //   114: astore_2
    //   115: aload_1
    //   116: astore #4
    //   118: aload_3
    //   119: invokevirtual printStackTrace : ()V
    //   122: aload_1
    //   123: ifnull -> 130
    //   126: aload_1
    //   127: invokevirtual close : ()V
    //   130: aload_0
    //   131: ifnull -> 138
    //   134: aload_0
    //   135: invokevirtual close : ()V
    //   138: aconst_null
    //   139: astore_0
    //   140: goto -> 43
    //   143: new java/io/InputStreamReader
    //   146: astore #4
    //   148: aload #4
    //   150: aload_0
    //   151: invokevirtual getErrorStream : ()Ljava/io/InputStream;
    //   154: invokespecial <init> : (Ljava/io/InputStream;)V
    //   157: new java/io/BufferedReader
    //   160: dup
    //   161: aload #4
    //   163: invokespecial <init> : (Ljava/io/Reader;)V
    //   166: astore_0
    //   167: aload_0
    //   168: astore_2
    //   169: aload_1
    //   170: astore #4
    //   172: aload_0
    //   173: invokevirtual readLine : ()Ljava/lang/String;
    //   176: astore #5
    //   178: aload #5
    //   180: ifnull -> 202
    //   183: aload_0
    //   184: astore_2
    //   185: aload_1
    //   186: astore #4
    //   188: aload_3
    //   189: aload #5
    //   191: invokevirtual add : (Ljava/lang/Object;)Z
    //   194: pop
    //   195: goto -> 167
    //   198: astore_3
    //   199: goto -> 101
    //   202: aload_1
    //   203: invokevirtual close : ()V
    //   206: aload_0
    //   207: invokevirtual close : ()V
    //   210: aload_3
    //   211: astore_0
    //   212: goto -> 43
    //   215: astore_0
    //   216: aload_0
    //   217: invokevirtual printStackTrace : ()V
    //   220: aload_3
    //   221: astore_0
    //   222: goto -> 43
    //   225: astore_1
    //   226: aload_1
    //   227: invokevirtual printStackTrace : ()V
    //   230: goto -> 206
    //   233: astore_1
    //   234: aload_1
    //   235: invokevirtual printStackTrace : ()V
    //   238: goto -> 130
    //   241: astore_0
    //   242: aload_0
    //   243: invokevirtual printStackTrace : ()V
    //   246: goto -> 138
    //   249: astore_0
    //   250: aconst_null
    //   251: astore_1
    //   252: aload_1
    //   253: ifnull -> 260
    //   256: aload_1
    //   257: invokevirtual close : ()V
    //   260: aload_2
    //   261: ifnull -> 268
    //   264: aload_2
    //   265: invokevirtual close : ()V
    //   268: aload_0
    //   269: athrow
    //   270: astore_1
    //   271: aload_1
    //   272: invokevirtual printStackTrace : ()V
    //   275: goto -> 260
    //   278: astore_1
    //   279: aload_1
    //   280: invokevirtual printStackTrace : ()V
    //   283: goto -> 268
    //   286: astore_0
    //   287: goto -> 252
    //   290: astore_0
    //   291: aload #4
    //   293: astore_1
    //   294: goto -> 252
    //   297: astore_3
    //   298: aconst_null
    //   299: astore_0
    //   300: aconst_null
    //   301: astore_1
    //   302: goto -> 101
    // Exception table:
    //   from	to	target	type
    //   45	77	297	java/lang/Throwable
    //   45	77	249	finally
    //   77	83	98	java/lang/Throwable
    //   77	83	286	finally
    //   88	95	98	java/lang/Throwable
    //   88	95	286	finally
    //   106	113	290	finally
    //   118	122	290	finally
    //   126	130	233	java/io/IOException
    //   134	138	241	java/io/IOException
    //   143	167	98	java/lang/Throwable
    //   143	167	286	finally
    //   172	178	198	java/lang/Throwable
    //   172	178	290	finally
    //   188	195	198	java/lang/Throwable
    //   188	195	290	finally
    //   202	206	225	java/io/IOException
    //   206	210	215	java/io/IOException
    //   256	260	270	java/io/IOException
    //   264	268	278	java/io/IOException
  }
  
  public static Map<String, String> a(int paramInt, boolean paramBoolean) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(12);
    Map<Thread, StackTraceElement[]> map = Thread.getAllStackTraces();
    if (map == null)
      return null; 
    Thread.currentThread().getId();
    StringBuilder stringBuilder = new StringBuilder();
    Iterator<Map.Entry> iterator = map.entrySet().iterator();
    label23: while (true) {
      if (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        stringBuilder.setLength(0);
        if (entry.getValue() != null && ((StackTraceElement[])entry.getValue()).length != 0) {
          StackTraceElement[] arrayOfStackTraceElement = (StackTraceElement[])entry.getValue();
          int i = arrayOfStackTraceElement.length;
          byte b = 0;
          while (true) {
            if (b < i) {
              StackTraceElement stackTraceElement = arrayOfStackTraceElement[b];
              if (paramInt > 0 && stringBuilder.length() >= paramInt) {
                stringBuilder.append("\n[Stack over limit size :" + paramInt + " , has been cutted !]");
              } else {
                stringBuilder.append(stackTraceElement.toString()).append("\n");
                b++;
                continue;
              } 
            } 
            hashMap.put(((Thread)entry.getKey()).getName() + "(" + ((Thread)entry.getKey()).getId() + ")", stringBuilder.toString());
            continue label23;
          } 
          break;
        } 
        continue;
      } 
      return (Map)hashMap;
    } 
  }
  
  public static Map<String, PlugInBean> a(Parcel paramParcel) {
    Bundle bundle = null;
    null = paramParcel.readBundle();
    if (null == null)
      return (Map<String, PlugInBean>)bundle; 
    ArrayList<String> arrayList1 = new ArrayList();
    ArrayList<PlugInBean> arrayList = new ArrayList();
    int i = ((Integer)null.get("pluginNum")).intValue();
    byte b;
    for (b = 0; b < i; b++)
      arrayList1.add(null.getString("pluginKey" + b)); 
    for (b = 0; b < i; b++) {
      String str1 = null.getString("pluginVal" + b + "plugInId");
      String str2 = null.getString("pluginVal" + b + "plugInUUID");
      arrayList.add(new PlugInBean(str1, null.getString("pluginVal" + b + "plugInVersion"), str2));
    } 
    if (arrayList1.size() == arrayList.size()) {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>(arrayList1.size());
      b = 0;
      while (true) {
        if (b < arrayList1.size()) {
          hashMap.put(arrayList1.get(b), PlugInBean.class.cast(arrayList.get(b)));
          b++;
          continue;
        } 
        return (Map)hashMap;
      } 
    } 
    w.e("map plugin parcel error!", new Object[0]);
    return null;
  }
  
  public static void a(Parcel paramParcel, Map<String, PlugInBean> paramMap) {
    boolean bool = false;
    if (paramMap == null || paramMap == null || paramMap.size() <= 0) {
      paramParcel.writeBundle(null);
      return;
    } 
    int i = paramMap.size();
    ArrayList<String> arrayList = new ArrayList(i);
    ArrayList arrayList1 = new ArrayList(i);
    for (Map.Entry<String, PlugInBean> entry : paramMap.entrySet()) {
      arrayList.add(entry.getKey());
      arrayList1.add(entry.getValue());
    } 
    Bundle bundle = new Bundle();
    bundle.putInt("pluginNum", arrayList.size());
    byte b = 0;
    while (true) {
      i = bool;
      if (b < arrayList.size()) {
        bundle.putString("pluginKey" + b, arrayList.get(b));
        b++;
        continue;
      } 
      break;
    } 
    while (i < arrayList.size()) {
      bundle.putString("pluginVal" + i + "plugInId", ((PlugInBean)arrayList1.get(i)).a);
      bundle.putString("pluginVal" + i + "plugInUUID", ((PlugInBean)arrayList1.get(i)).c);
      bundle.putString("pluginVal" + i + "plugInVersion", ((PlugInBean)arrayList1.get(i)).b);
      i++;
    } 
    paramParcel.writeBundle(bundle);
  }
  
  private void a(ArrayList<String> paramArrayList, Object paramObject) {
    if (paramObject.getClass().isArray()) {
      if (!paramObject.getClass().getComponentType().toString().equals("byte"))
        throw new IllegalArgumentException("only byte[] is supported"); 
      if (Array.getLength(paramObject) > 0) {
        paramArrayList.add("java.util.List");
        a(paramArrayList, Array.get(paramObject, 0));
        return;
      } 
      paramArrayList.add("Array");
      paramArrayList.add("?");
      return;
    } 
    if (paramObject instanceof Array)
      throw new IllegalArgumentException("can not support Array, please use List"); 
    if (paramObject instanceof List) {
      paramArrayList.add("java.util.List");
      paramObject = paramObject;
      if (paramObject.size() > 0) {
        a(paramArrayList, paramObject.get(0));
        return;
      } 
      paramArrayList.add("?");
      return;
    } 
    if (paramObject instanceof Map) {
      paramArrayList.add("java.util.Map");
      Map map = (Map)paramObject;
      if (map.size() > 0) {
        paramObject = map.keySet().iterator().next();
        map = (Map)map.get(paramObject);
        paramArrayList.add(paramObject.getClass().getName());
        a(paramArrayList, map);
        return;
      } 
      paramArrayList.add("?");
      paramArrayList.add("?");
      return;
    } 
    paramArrayList.add(paramObject.getClass().getName());
  }
  
  public static boolean a(Context paramContext, String paramString, long paramLong) {
    boolean bool2;
    boolean bool1 = false;
    w.c("[Util] try to lock file:%s (pid=%d | tid=%d)", new Object[] { paramString, Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      String str = stringBuilder.append(paramContext.getFilesDir()).append(File.separator).append(paramString).toString();
      File file = new File();
      this(str);
      if (file.exists()) {
        if (System.currentTimeMillis() - file.lastModified() < paramLong)
          return bool1; 
        w.c("[Util] lock file(%s) is expired, unlock it", new Object[] { paramString });
        b(paramContext, paramString);
      } 
      bool2 = bool1;
      if (file.createNewFile()) {
        w.c("[Util] successfully locked file:%s (pid=%d | tid=%d)", new Object[] { paramString, Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
        bool2 = true;
      } 
    } catch (Throwable throwable) {
      w.a(throwable);
      bool2 = bool1;
    } 
    return bool2;
  }
  
  public static boolean a(File paramFile1, File paramFile2, int paramInt) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: iconst_0
    //   3: istore #4
    //   5: ldc_w 'rqdp{  ZF start}'
    //   8: iconst_0
    //   9: anewarray java/lang/Object
    //   12: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   15: pop
    //   16: aload_0
    //   17: ifnull -> 32
    //   20: aload_1
    //   21: ifnull -> 32
    //   24: aload_0
    //   25: aload_1
    //   26: invokevirtual equals : (Ljava/lang/Object;)Z
    //   29: ifeq -> 50
    //   32: ldc_w 'rqdp{  err ZF 1R!}'
    //   35: iconst_0
    //   36: anewarray java/lang/Object
    //   39: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   42: pop
    //   43: iload #4
    //   45: istore #5
    //   47: iload #5
    //   49: ireturn
    //   50: aload_0
    //   51: invokevirtual exists : ()Z
    //   54: ifeq -> 64
    //   57: aload_0
    //   58: invokevirtual canRead : ()Z
    //   61: ifne -> 82
    //   64: ldc_w 'rqdp{  !sFile.exists() || !sFile.canRead(),pls check ,return!}'
    //   67: iconst_0
    //   68: anewarray java/lang/Object
    //   71: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   74: pop
    //   75: iload #4
    //   77: istore #5
    //   79: goto -> 47
    //   82: aload_1
    //   83: invokevirtual getParentFile : ()Ljava/io/File;
    //   86: ifnull -> 107
    //   89: aload_1
    //   90: invokevirtual getParentFile : ()Ljava/io/File;
    //   93: invokevirtual exists : ()Z
    //   96: ifne -> 107
    //   99: aload_1
    //   100: invokevirtual getParentFile : ()Ljava/io/File;
    //   103: invokevirtual mkdirs : ()Z
    //   106: pop
    //   107: aload_1
    //   108: invokevirtual exists : ()Z
    //   111: ifne -> 119
    //   114: aload_1
    //   115: invokevirtual createNewFile : ()Z
    //   118: pop
    //   119: iload #4
    //   121: istore #5
    //   123: aload_1
    //   124: invokevirtual exists : ()Z
    //   127: ifeq -> 47
    //   130: iload #4
    //   132: istore #5
    //   134: aload_1
    //   135: invokevirtual canRead : ()Z
    //   138: ifeq -> 47
    //   141: new java/io/FileInputStream
    //   144: astore #6
    //   146: aload #6
    //   148: aload_0
    //   149: invokespecial <init> : (Ljava/io/File;)V
    //   152: new java/util/zip/ZipOutputStream
    //   155: astore_3
    //   156: new java/io/FileOutputStream
    //   159: astore #7
    //   161: aload #7
    //   163: aload_1
    //   164: invokespecial <init> : (Ljava/io/File;)V
    //   167: aload_3
    //   168: aload #7
    //   170: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   173: aload_3
    //   174: bipush #8
    //   176: invokevirtual setMethod : (I)V
    //   179: new java/util/zip/ZipEntry
    //   182: astore_1
    //   183: aload_1
    //   184: aload_0
    //   185: invokevirtual getName : ()Ljava/lang/String;
    //   188: invokespecial <init> : (Ljava/lang/String;)V
    //   191: aload_3
    //   192: aload_1
    //   193: invokevirtual putNextEntry : (Ljava/util/zip/ZipEntry;)V
    //   196: sipush #5000
    //   199: newarray byte
    //   201: astore_0
    //   202: aload #6
    //   204: aload_0
    //   205: invokevirtual read : ([B)I
    //   208: istore_2
    //   209: iload_2
    //   210: ifle -> 299
    //   213: aload_3
    //   214: aload_0
    //   215: iconst_0
    //   216: iload_2
    //   217: invokevirtual write : ([BII)V
    //   220: goto -> 202
    //   223: astore #7
    //   225: aload #6
    //   227: astore_1
    //   228: aload_3
    //   229: astore_0
    //   230: aload #7
    //   232: astore #6
    //   234: aload #6
    //   236: invokestatic a : (Ljava/lang/Throwable;)Z
    //   239: ifne -> 247
    //   242: aload #6
    //   244: invokevirtual printStackTrace : ()V
    //   247: aload_1
    //   248: ifnull -> 255
    //   251: aload_1
    //   252: invokevirtual close : ()V
    //   255: aload_0
    //   256: ifnull -> 263
    //   259: aload_0
    //   260: invokevirtual close : ()V
    //   263: ldc_w 'rqdp{  ZF end}'
    //   266: iconst_0
    //   267: anewarray java/lang/Object
    //   270: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   273: pop
    //   274: iload #4
    //   276: istore #5
    //   278: goto -> 47
    //   281: astore #6
    //   283: aload #6
    //   285: invokestatic a : (Ljava/lang/Throwable;)Z
    //   288: ifne -> 119
    //   291: aload #6
    //   293: invokevirtual printStackTrace : ()V
    //   296: goto -> 119
    //   299: aload_3
    //   300: invokevirtual flush : ()V
    //   303: aload_3
    //   304: invokevirtual closeEntry : ()V
    //   307: aload #6
    //   309: invokevirtual close : ()V
    //   312: aload_3
    //   313: invokevirtual close : ()V
    //   316: ldc_w 'rqdp{  ZF end}'
    //   319: iconst_0
    //   320: anewarray java/lang/Object
    //   323: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   326: pop
    //   327: iconst_1
    //   328: istore #5
    //   330: goto -> 47
    //   333: astore_0
    //   334: aload_0
    //   335: invokevirtual printStackTrace : ()V
    //   338: goto -> 312
    //   341: astore_0
    //   342: aload_0
    //   343: invokevirtual printStackTrace : ()V
    //   346: goto -> 316
    //   349: astore_1
    //   350: aload_1
    //   351: invokevirtual printStackTrace : ()V
    //   354: goto -> 255
    //   357: astore_0
    //   358: aload_0
    //   359: invokevirtual printStackTrace : ()V
    //   362: goto -> 263
    //   365: astore_1
    //   366: aconst_null
    //   367: astore_0
    //   368: aconst_null
    //   369: astore #6
    //   371: aload #6
    //   373: ifnull -> 381
    //   376: aload #6
    //   378: invokevirtual close : ()V
    //   381: aload_0
    //   382: ifnull -> 389
    //   385: aload_0
    //   386: invokevirtual close : ()V
    //   389: ldc_w 'rqdp{  ZF end}'
    //   392: iconst_0
    //   393: anewarray java/lang/Object
    //   396: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   399: pop
    //   400: aload_1
    //   401: athrow
    //   402: astore #6
    //   404: aload #6
    //   406: invokevirtual printStackTrace : ()V
    //   409: goto -> 381
    //   412: astore_0
    //   413: aload_0
    //   414: invokevirtual printStackTrace : ()V
    //   417: goto -> 389
    //   420: astore_1
    //   421: aconst_null
    //   422: astore_0
    //   423: goto -> 371
    //   426: astore_1
    //   427: aload_3
    //   428: astore_0
    //   429: goto -> 371
    //   432: astore_3
    //   433: aload_1
    //   434: astore #6
    //   436: aload_3
    //   437: astore_1
    //   438: goto -> 371
    //   441: astore #6
    //   443: aconst_null
    //   444: astore_0
    //   445: aload_3
    //   446: astore_1
    //   447: goto -> 234
    //   450: astore_0
    //   451: aconst_null
    //   452: astore_3
    //   453: aload #6
    //   455: astore_1
    //   456: aload_0
    //   457: astore #6
    //   459: aload_3
    //   460: astore_0
    //   461: goto -> 234
    // Exception table:
    //   from	to	target	type
    //   82	107	281	java/lang/Throwable
    //   107	119	281	java/lang/Throwable
    //   141	152	441	java/lang/Throwable
    //   141	152	365	finally
    //   152	173	450	java/lang/Throwable
    //   152	173	420	finally
    //   173	202	223	java/lang/Throwable
    //   173	202	426	finally
    //   202	209	223	java/lang/Throwable
    //   202	209	426	finally
    //   213	220	223	java/lang/Throwable
    //   213	220	426	finally
    //   234	247	432	finally
    //   251	255	349	java/io/IOException
    //   259	263	357	java/io/IOException
    //   299	307	223	java/lang/Throwable
    //   299	307	426	finally
    //   307	312	333	java/io/IOException
    //   312	316	341	java/io/IOException
    //   376	381	402	java/io/IOException
    //   385	389	412	java/io/IOException
  }
  
  public static byte[] a(int paramInt) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/proguard/a
    //   2: monitorenter
    //   3: bipush #16
    //   5: newarray byte
    //   7: astore_1
    //   8: new java/io/DataInputStream
    //   11: astore_2
    //   12: new java/io/FileInputStream
    //   15: astore_3
    //   16: new java/io/File
    //   19: astore #4
    //   21: aload #4
    //   23: ldc_w '/dev/urandom'
    //   26: invokespecial <init> : (Ljava/lang/String;)V
    //   29: aload_3
    //   30: aload #4
    //   32: invokespecial <init> : (Ljava/io/File;)V
    //   35: aload_2
    //   36: aload_3
    //   37: invokespecial <init> : (Ljava/io/InputStream;)V
    //   40: aload_2
    //   41: astore #4
    //   43: aload_2
    //   44: aload_1
    //   45: invokevirtual readFully : ([B)V
    //   48: aload_2
    //   49: invokevirtual close : ()V
    //   52: aload_1
    //   53: astore #4
    //   55: ldc com/tencent/bugly/legu/proguard/a
    //   57: monitorexit
    //   58: aload #4
    //   60: areturn
    //   61: astore_1
    //   62: aconst_null
    //   63: astore_2
    //   64: aload_2
    //   65: astore #4
    //   67: ldc_w 'Failed to read from /dev/urandom : %s'
    //   70: iconst_1
    //   71: anewarray java/lang/Object
    //   74: dup
    //   75: iconst_0
    //   76: aload_1
    //   77: aastore
    //   78: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   81: pop
    //   82: aload_2
    //   83: ifnull -> 90
    //   86: aload_2
    //   87: invokevirtual close : ()V
    //   90: ldc_w 'AES'
    //   93: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/KeyGenerator;
    //   96: astore #4
    //   98: new java/security/SecureRandom
    //   101: astore_2
    //   102: aload_2
    //   103: invokespecial <init> : ()V
    //   106: aload #4
    //   108: sipush #128
    //   111: aload_2
    //   112: invokevirtual init : (ILjava/security/SecureRandom;)V
    //   115: aload #4
    //   117: invokevirtual generateKey : ()Ljavax/crypto/SecretKey;
    //   120: invokeinterface getEncoded : ()[B
    //   125: astore #4
    //   127: goto -> 55
    //   130: astore_2
    //   131: aconst_null
    //   132: astore #4
    //   134: aload #4
    //   136: ifnull -> 144
    //   139: aload #4
    //   141: invokevirtual close : ()V
    //   144: aload_2
    //   145: athrow
    //   146: astore #4
    //   148: aload #4
    //   150: invokestatic b : (Ljava/lang/Throwable;)Z
    //   153: ifne -> 161
    //   156: aload #4
    //   158: invokevirtual printStackTrace : ()V
    //   161: aconst_null
    //   162: astore #4
    //   164: goto -> 55
    //   167: astore #4
    //   169: ldc com/tencent/bugly/legu/proguard/a
    //   171: monitorexit
    //   172: aload #4
    //   174: athrow
    //   175: astore_2
    //   176: goto -> 134
    //   179: astore_1
    //   180: goto -> 64
    // Exception table:
    //   from	to	target	type
    //   3	40	61	java/lang/Exception
    //   3	40	130	finally
    //   43	48	179	java/lang/Exception
    //   43	48	175	finally
    //   48	52	146	java/lang/Exception
    //   48	52	167	finally
    //   67	82	175	finally
    //   86	90	146	java/lang/Exception
    //   86	90	167	finally
    //   90	127	146	java/lang/Exception
    //   90	127	167	finally
    //   139	144	146	java/lang/Exception
    //   139	144	167	finally
    //   144	146	146	java/lang/Exception
    //   144	146	167	finally
    //   148	161	167	finally
  }
  
  public static byte[] a(int paramInt, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    try {
      SecretKeySpec secretKeySpec = new SecretKeySpec();
      this(paramArrayOfbyte2, "AES");
      Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
      IvParameterSpec ivParameterSpec = new IvParameterSpec();
      this(paramArrayOfbyte2);
      cipher.init(paramInt, secretKeySpec, ivParameterSpec);
      paramArrayOfbyte1 = cipher.doFinal(paramArrayOfbyte1);
    } catch (Exception exception) {}
    return (byte[])exception;
  }
  
  public static byte[] a(long paramLong) {
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      byte[] arrayOfByte = stringBuilder.append(paramLong).toString().getBytes("utf-8");
    } catch (UnsupportedEncodingException unsupportedEncodingException) {
      unsupportedEncodingException.printStackTrace();
      unsupportedEncodingException = null;
    } 
    return (byte[])unsupportedEncodingException;
  }
  
  public static byte[] a(am paramam) {
    try {
      d d = new d();
      this();
      d.p();
      d.a("utf-8");
      d.b(1);
      d.b("RqdServer");
      d.c("sync");
      d.a("detail", paramam);
      byte[] arrayOfByte = d.a();
    } catch (Throwable throwable) {}
    return (byte[])throwable;
  }
  
  public static byte[] a(j paramj) {
    try {
      i i = new i();
      this();
      i.a("utf-8");
      paramj.a(i);
      byte[] arrayOfByte = i.b();
    } catch (Throwable throwable) {}
    return (byte[])throwable;
  }
  
  public static byte[] a(File paramFile, String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: ldc_w 'rqdp{  ZF start}'
    //   5: iconst_0
    //   6: anewarray java/lang/Object
    //   9: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   12: pop
    //   13: ldc_w 'buglyCacheLog.txt'
    //   16: astore_3
    //   17: aload_0
    //   18: ifnull -> 485
    //   21: aload_0
    //   22: invokevirtual exists : ()Z
    //   25: ifeq -> 485
    //   28: aload_0
    //   29: invokevirtual canRead : ()Z
    //   32: ifeq -> 485
    //   35: new java/io/FileInputStream
    //   38: astore_3
    //   39: aload_3
    //   40: aload_0
    //   41: invokespecial <init> : (Ljava/io/File;)V
    //   44: aload_0
    //   45: invokevirtual getName : ()Ljava/lang/String;
    //   48: astore #4
    //   50: aload_3
    //   51: astore_0
    //   52: aload #4
    //   54: astore_3
    //   55: aload_1
    //   56: ldc_w 'UTF-8'
    //   59: invokevirtual getBytes : (Ljava/lang/String;)[B
    //   62: astore_1
    //   63: new java/io/ByteArrayInputStream
    //   66: astore #5
    //   68: aload #5
    //   70: aload_1
    //   71: invokespecial <init> : ([B)V
    //   74: new java/io/ByteArrayOutputStream
    //   77: astore #6
    //   79: aload #6
    //   81: invokespecial <init> : ()V
    //   84: new java/util/zip/ZipOutputStream
    //   87: astore_1
    //   88: aload_1
    //   89: aload #6
    //   91: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   94: aload_1
    //   95: astore #4
    //   97: aload_0
    //   98: astore #7
    //   100: aload_1
    //   101: bipush #8
    //   103: invokevirtual setMethod : (I)V
    //   106: aload_1
    //   107: astore #4
    //   109: aload_0
    //   110: astore #7
    //   112: new java/util/zip/ZipEntry
    //   115: astore #8
    //   117: aload_1
    //   118: astore #4
    //   120: aload_0
    //   121: astore #7
    //   123: aload #8
    //   125: aload_3
    //   126: invokespecial <init> : (Ljava/lang/String;)V
    //   129: aload_1
    //   130: astore #4
    //   132: aload_0
    //   133: astore #7
    //   135: aload_1
    //   136: aload #8
    //   138: invokevirtual putNextEntry : (Ljava/util/zip/ZipEntry;)V
    //   141: aload_1
    //   142: astore #4
    //   144: aload_0
    //   145: astore #7
    //   147: sipush #1024
    //   150: newarray byte
    //   152: astore_3
    //   153: aload_0
    //   154: ifnull -> 247
    //   157: aload_1
    //   158: astore #4
    //   160: aload_0
    //   161: astore #7
    //   163: aload_0
    //   164: aload_3
    //   165: invokevirtual read : ([B)I
    //   168: istore #9
    //   170: iload #9
    //   172: ifle -> 247
    //   175: aload_1
    //   176: astore #4
    //   178: aload_0
    //   179: astore #7
    //   181: aload_1
    //   182: aload_3
    //   183: iconst_0
    //   184: iload #9
    //   186: invokevirtual write : ([BII)V
    //   189: goto -> 157
    //   192: astore_3
    //   193: aload_1
    //   194: astore #4
    //   196: aload_0
    //   197: astore #7
    //   199: aload_3
    //   200: invokestatic a : (Ljava/lang/Throwable;)Z
    //   203: ifne -> 216
    //   206: aload_1
    //   207: astore #4
    //   209: aload_0
    //   210: astore #7
    //   212: aload_3
    //   213: invokevirtual printStackTrace : ()V
    //   216: aload_0
    //   217: ifnull -> 224
    //   220: aload_0
    //   221: invokevirtual close : ()V
    //   224: aload_1
    //   225: ifnull -> 232
    //   228: aload_1
    //   229: invokevirtual close : ()V
    //   232: ldc_w 'rqdp{  ZF end}'
    //   235: iconst_0
    //   236: anewarray java/lang/Object
    //   239: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   242: pop
    //   243: aload_2
    //   244: astore_3
    //   245: aload_3
    //   246: areturn
    //   247: aload_1
    //   248: astore #4
    //   250: aload_0
    //   251: astore #7
    //   253: aload #5
    //   255: aload_3
    //   256: invokevirtual read : ([B)I
    //   259: istore #9
    //   261: iload #9
    //   263: ifle -> 319
    //   266: aload_1
    //   267: astore #4
    //   269: aload_0
    //   270: astore #7
    //   272: aload_1
    //   273: aload_3
    //   274: iconst_0
    //   275: iload #9
    //   277: invokevirtual write : ([BII)V
    //   280: goto -> 247
    //   283: astore_1
    //   284: aload #7
    //   286: astore_0
    //   287: aload #4
    //   289: astore_3
    //   290: aload_0
    //   291: ifnull -> 298
    //   294: aload_0
    //   295: invokevirtual close : ()V
    //   298: aload_3
    //   299: ifnull -> 306
    //   302: aload_3
    //   303: invokevirtual close : ()V
    //   306: ldc_w 'rqdp{  ZF end}'
    //   309: iconst_0
    //   310: anewarray java/lang/Object
    //   313: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   316: pop
    //   317: aload_1
    //   318: athrow
    //   319: aload_1
    //   320: astore #4
    //   322: aload_0
    //   323: astore #7
    //   325: aload_1
    //   326: invokevirtual closeEntry : ()V
    //   329: aload_1
    //   330: astore #4
    //   332: aload_0
    //   333: astore #7
    //   335: aload_1
    //   336: invokevirtual flush : ()V
    //   339: aload_1
    //   340: astore #4
    //   342: aload_0
    //   343: astore #7
    //   345: aload_1
    //   346: invokevirtual finish : ()V
    //   349: aload_1
    //   350: astore #4
    //   352: aload_0
    //   353: astore #7
    //   355: aload #6
    //   357: invokevirtual toByteArray : ()[B
    //   360: astore_3
    //   361: aload_0
    //   362: ifnull -> 369
    //   365: aload_0
    //   366: invokevirtual close : ()V
    //   369: aload_1
    //   370: invokevirtual close : ()V
    //   373: ldc_w 'rqdp{  ZF end}'
    //   376: iconst_0
    //   377: anewarray java/lang/Object
    //   380: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   383: pop
    //   384: goto -> 245
    //   387: astore_0
    //   388: aload_0
    //   389: invokevirtual printStackTrace : ()V
    //   392: goto -> 369
    //   395: astore_0
    //   396: aload_0
    //   397: invokevirtual printStackTrace : ()V
    //   400: goto -> 373
    //   403: astore_0
    //   404: aload_0
    //   405: invokevirtual printStackTrace : ()V
    //   408: goto -> 224
    //   411: astore_0
    //   412: aload_0
    //   413: invokevirtual printStackTrace : ()V
    //   416: goto -> 232
    //   419: astore_0
    //   420: aload_0
    //   421: invokevirtual printStackTrace : ()V
    //   424: goto -> 298
    //   427: astore_0
    //   428: aload_0
    //   429: invokevirtual printStackTrace : ()V
    //   432: goto -> 306
    //   435: astore_1
    //   436: aconst_null
    //   437: astore_3
    //   438: aconst_null
    //   439: astore_0
    //   440: goto -> 290
    //   443: astore_1
    //   444: aload_3
    //   445: astore_0
    //   446: aconst_null
    //   447: astore_3
    //   448: goto -> 290
    //   451: astore_1
    //   452: aconst_null
    //   453: astore_3
    //   454: goto -> 290
    //   457: astore_3
    //   458: aconst_null
    //   459: astore_1
    //   460: aconst_null
    //   461: astore_0
    //   462: goto -> 193
    //   465: astore_1
    //   466: aload_3
    //   467: astore_0
    //   468: aconst_null
    //   469: astore #4
    //   471: aload_1
    //   472: astore_3
    //   473: aload #4
    //   475: astore_1
    //   476: goto -> 193
    //   479: astore_3
    //   480: aconst_null
    //   481: astore_1
    //   482: goto -> 193
    //   485: aconst_null
    //   486: astore_0
    //   487: goto -> 55
    // Exception table:
    //   from	to	target	type
    //   21	44	457	java/lang/Throwable
    //   21	44	435	finally
    //   44	50	465	java/lang/Throwable
    //   44	50	443	finally
    //   55	94	479	java/lang/Throwable
    //   55	94	451	finally
    //   100	106	192	java/lang/Throwable
    //   100	106	283	finally
    //   112	117	192	java/lang/Throwable
    //   112	117	283	finally
    //   123	129	192	java/lang/Throwable
    //   123	129	283	finally
    //   135	141	192	java/lang/Throwable
    //   135	141	283	finally
    //   147	153	192	java/lang/Throwable
    //   147	153	283	finally
    //   163	170	192	java/lang/Throwable
    //   163	170	283	finally
    //   181	189	192	java/lang/Throwable
    //   181	189	283	finally
    //   199	206	283	finally
    //   212	216	283	finally
    //   220	224	403	java/io/IOException
    //   228	232	411	java/io/IOException
    //   253	261	192	java/lang/Throwable
    //   253	261	283	finally
    //   272	280	192	java/lang/Throwable
    //   272	280	283	finally
    //   294	298	419	java/io/IOException
    //   302	306	427	java/io/IOException
    //   325	329	192	java/lang/Throwable
    //   325	329	283	finally
    //   335	339	192	java/lang/Throwable
    //   335	339	283	finally
    //   345	349	192	java/lang/Throwable
    //   345	349	283	finally
    //   355	361	192	java/lang/Throwable
    //   355	361	283	finally
    //   365	369	387	java/io/IOException
    //   369	373	395	java/io/IOException
  }
  
  public static byte[] a(byte[] paramArrayOfbyte, int paramInt) {
    if (paramArrayOfbyte != null) {
      w.c("rqdp{  zp:} %s rqdp{  len:} %s", new Object[] { Integer.valueOf(2), Integer.valueOf(paramArrayOfbyte.length) });
      try {
        ab ab = aa.a(2);
        if (ab == null)
          return null; 
        paramArrayOfbyte = ab.a(paramArrayOfbyte);
      } catch (Throwable throwable) {}
    } 
    return (byte[])throwable;
  }
  
  public static byte[] a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, String paramString) {
    try {
      paramArrayOfbyte = b(a(paramArrayOfbyte, 1, paramString), 2);
    } catch (Exception exception) {}
    return (byte[])exception;
  }
  
  public static byte[] a(byte[] paramArrayOfbyte, int paramInt, String paramString) {
    null = paramArrayOfbyte;
    if (paramArrayOfbyte != null) {
      if (paramInt == -1)
        return paramArrayOfbyte; 
    } else {
      return null;
    } 
    if (paramInt == 1) {
      try {
        af af = new af();
        this();
        if (af == null)
          return null; 
      } catch (Throwable throwable) {
        if (!w.a(throwable))
          throwable.printStackTrace(); 
        w.d("encrytype %d %s", new Object[] { Integer.valueOf(paramInt), paramString });
        return null;
      } 
    } else {
      if (paramInt == 3) {
        ae ae = new ae();
      } else {
        null = null;
      } 
      if (null == null)
        return null; 
    } 
    null.a(paramString);
    return null.a((byte[])throwable);
  }
  
  public static String b() {
    try {
      String str = Build.MODEL;
    } catch (Throwable throwable) {}
    return (String)throwable;
  }
  
  public static String b(Context paramContext) {
    if (!AppInfo.a(paramContext, "android.permission.READ_PHONE_STATE")) {
      w.d("no READ_PHONE_STATE permission to get IMSI", new Object[0]);
      return "null";
    } 
    if (paramContext == null)
      return null; 
    try {
      String str2 = ((TelephonyManager)paramContext.getSystemService("phone")).getSubscriberId();
      String str1 = str2;
      if (str2 != null)
        try {
          str1 = str2.toLowerCase();
        } catch (Throwable throwable1) {
          String str = str2;
        }  
    } catch (Throwable throwable) {
      throwable = null;
    } 
    return (String)throwable;
  }
  
  public static String b(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0)
      return "NULL"; 
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
      messageDigest.update(paramArrayOfbyte);
      byte[] arrayOfByte = messageDigest.digest();
      if (arrayOfByte == null)
        return ""; 
      StringBuffer stringBuffer = new StringBuffer();
      this();
      for (byte b = 0; b < arrayOfByte.length; b++) {
        String str1 = Integer.toHexString(arrayOfByte[b] & 0xFF);
        if (str1.length() == 1)
          stringBuffer.append("0"); 
        stringBuffer.append(str1);
      } 
      String str = stringBuffer.toString().toUpperCase();
    } catch (Throwable throwable) {}
    return (String)throwable;
  }
  
  public static Map<String, String> b(Parcel paramParcel) {
    Bundle bundle = null;
    byte b = 0;
    null = paramParcel.readBundle();
    if (null == null)
      return (Map<String, String>)bundle; 
    ArrayList arrayList1 = null.getStringArrayList("keys");
    ArrayList arrayList2 = null.getStringArrayList("values");
    if (arrayList1 != null && arrayList2 != null && arrayList1.size() == arrayList2.size()) {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>(arrayList1.size());
      while (true) {
        if (b < arrayList1.size()) {
          hashMap.put(arrayList1.get(b), arrayList2.get(b));
          b++;
          continue;
        } 
        return (Map)hashMap;
      } 
    } 
    w.e("map parcel error!", new Object[0]);
    return null;
  }
  
  public static void b(Parcel paramParcel, Map<String, String> paramMap) {
    if (paramMap == null || paramMap == null || paramMap.size() <= 0) {
      paramParcel.writeBundle(null);
      return;
    } 
    int i = paramMap.size();
    ArrayList arrayList1 = new ArrayList(i);
    ArrayList arrayList2 = new ArrayList(i);
    for (Map.Entry<String, String> entry : paramMap.entrySet()) {
      arrayList1.add(entry.getKey());
      arrayList2.add(entry.getValue());
    } 
    Bundle bundle = new Bundle();
    bundle.putStringArrayList("keys", arrayList1);
    bundle.putStringArrayList("values", arrayList2);
    paramParcel.writeBundle(bundle);
  }
  
  public static boolean b(Context paramContext, String paramString) {
    boolean bool2;
    boolean bool1 = true;
    w.c("[Util] try to unlock file:%s (pid=%d | tid=%d)", new Object[] { paramString, Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      String str = stringBuilder.append(paramContext.getFilesDir()).append(File.separator).append(paramString).toString();
      File file = new File();
      this(str);
      bool2 = bool1;
      if (file.exists()) {
        if (file.delete()) {
          w.c("[Util] successfully unlocked file:%s (pid=%d | tid=%d)", new Object[] { paramString, Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
          return bool1;
        } 
      } else {
        return bool2;
      } 
      bool2 = false;
    } catch (Throwable throwable) {
      w.a(throwable);
      bool2 = false;
    } 
    return bool2;
  }
  
  public static byte[] b(int paramInt, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
    try {
      KeyFactory keyFactory = KeyFactory.getInstance("RSA");
      X509EncodedKeySpec x509EncodedKeySpec = new X509EncodedKeySpec();
      this(paramArrayOfbyte2);
      PublicKey publicKey = keyFactory.generatePublic(x509EncodedKeySpec);
      Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
      cipher.init(1, publicKey);
      paramArrayOfbyte1 = cipher.doFinal(paramArrayOfbyte1);
    } catch (Exception exception) {}
    return (byte[])exception;
  }
  
  public static byte[] b(byte[] paramArrayOfbyte, int paramInt) {
    byte[] arrayOfByte = paramArrayOfbyte;
    if (paramArrayOfbyte != null) {
      if (paramInt == -1)
        return paramArrayOfbyte; 
    } else {
      return arrayOfByte;
    } 
    w.c("rqdp{  unzp:} %s rqdp{  len:} %s", new Object[] { Integer.valueOf(paramInt), Integer.valueOf(paramArrayOfbyte.length) });
    try {
      ab ab = aa.a(paramInt);
      if (ab == null)
        return null; 
      arrayOfByte = ab.b(paramArrayOfbyte);
    } catch (Throwable throwable) {}
    return arrayOfByte;
  }
  
  public static long c(byte[] paramArrayOfbyte) {
    long l = -1L;
    if (paramArrayOfbyte != null)
      try {
        String str = new String();
        this(paramArrayOfbyte, "utf-8");
        long l1 = Long.parseLong(str);
        l = l1;
      } catch (UnsupportedEncodingException unsupportedEncodingException) {
        unsupportedEncodingException.printStackTrace();
      }  
    return l;
  }
  
  public static String c() {
    try {
      String str = Build.VERSION.RELEASE;
    } catch (Throwable throwable) {}
    return (String)throwable;
  }
  
  public static String c(Context paramContext) {
    String str1;
    String str2 = "fail";
    if (paramContext == null)
      return str2; 
    try {
      str1 = Settings.Secure.getString(paramContext.getContentResolver(), "android_id");
      if (str1 == null)
        return "null"; 
      try {
        str2 = str1.toLowerCase();
        str1 = str2;
      } catch (Throwable throwable) {
        str2 = str1;
      } 
    } catch (Throwable throwable) {}
    return str1;
  }
  
  public static int d() {
    int i;
    try {
      i = Build.VERSION.SDK_INT;
    } catch (Throwable throwable) {}
    return i;
  }
  
  public static String d(Context paramContext) {
    String str1;
    String str2 = "fail";
    if (paramContext == null)
      return "fail"; 
    try {
      str1 = ((WifiManager)paramContext.getSystemService("wifi")).getConnectionInfo().getMacAddress();
      if (str1 == null)
        return "null"; 
      str2 = str1;
      str1 = str1.toLowerCase();
    } catch (Throwable throwable) {
      str1 = str2;
    } 
    return str1;
  }
  
  public static String e() {
    try {
      String str1 = p();
      String str2 = str1;
      if (str1 == null)
        str2 = System.getProperty("os.arch"); 
      StringBuilder stringBuilder = new StringBuilder();
      this();
      str2 = stringBuilder.append(str2).toString();
    } catch (Throwable throwable) {}
    return (String)throwable;
  }
  
  public static String e(Context paramContext) {
    String str = "unknown";
    try {
      NetworkInfo networkInfo = ((ConnectivityManager)paramContext.getSystemService("connectivity")).getActiveNetworkInfo();
      if (networkInfo == null)
        return null; 
      if (networkInfo.getType() == 1)
        return "WIFI"; 
      if (networkInfo.getType() == 0) {
        TelephonyManager telephonyManager = (TelephonyManager)paramContext.getSystemService("phone");
        if (telephonyManager != null) {
          StringBuilder stringBuilder;
          int i = telephonyManager.getNetworkType();
          switch (i) {
            default:
              stringBuilder = new StringBuilder();
              this("MOBILE(");
              return stringBuilder.append(i).append(")").toString();
            case 1:
              return "GPRS";
            case 2:
              return "EDGE";
            case 3:
              return "UMTS";
            case 8:
              return "HSDPA";
            case 9:
              return "HSUPA";
            case 10:
              return "HSPA";
            case 4:
              return "CDMA";
            case 5:
              return "EVDO_0";
            case 6:
              return "EVDO_A";
            case 7:
              return "1xRTT";
            case 11:
              return "iDen";
            case 12:
              return "EVDO_B";
            case 13:
              return "LTE";
            case 14:
              return "eHRPD";
            case 15:
              break;
          } 
          return "HSPA+";
        } 
      } 
    } catch (Exception exception) {
      String str1 = str;
      if (!w.a(exception)) {
        exception.printStackTrace();
        str1 = str;
      } 
      return str1;
    } 
    return "unknown";
  }
  
  public static long f() {
    long l2;
    long l1 = -1L;
    try {
      File file = Environment.getDataDirectory();
      StatFs statFs = new StatFs();
      this(file.getPath());
      l2 = statFs.getBlockSize();
      int i = statFs.getBlockCount();
      l2 = i * l2;
    } catch (Throwable throwable) {
      l2 = l1;
    } 
    return l2;
  }
  
  public static boolean f(Context paramContext) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: getstatic android/os/Build.TAGS : Ljava/lang/String;
    //   5: ifnull -> 146
    //   8: getstatic android/os/Build.TAGS : Ljava/lang/String;
    //   11: ldc_w 'test-keys'
    //   14: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   17: ifeq -> 146
    //   20: iconst_1
    //   21: istore_2
    //   22: new java/io/File
    //   25: astore_3
    //   26: aload_3
    //   27: ldc_w '/system/app/Superuser.apk'
    //   30: invokespecial <init> : (Ljava/lang/String;)V
    //   33: aload_3
    //   34: invokevirtual exists : ()Z
    //   37: istore #4
    //   39: aconst_null
    //   40: astore #5
    //   42: aconst_null
    //   43: astore #6
    //   45: aload_0
    //   46: iconst_3
    //   47: anewarray java/lang/String
    //   50: dup
    //   51: iconst_0
    //   52: ldc_w '/system/bin/sh'
    //   55: aastore
    //   56: dup
    //   57: iconst_1
    //   58: ldc_w '-c'
    //   61: aastore
    //   62: dup
    //   63: iconst_2
    //   64: ldc_w 'type su'
    //   67: aastore
    //   68: invokestatic a : (Landroid/content/Context;[Ljava/lang/String;)Ljava/util/ArrayList;
    //   71: astore_0
    //   72: aload #5
    //   74: astore_3
    //   75: aload_0
    //   76: ifnull -> 169
    //   79: aload #5
    //   81: astore_3
    //   82: aload_0
    //   83: invokevirtual size : ()I
    //   86: ifle -> 169
    //   89: aload_0
    //   90: invokevirtual iterator : ()Ljava/util/Iterator;
    //   93: astore_3
    //   94: aload #6
    //   96: astore_0
    //   97: aload_3
    //   98: invokeinterface hasNext : ()Z
    //   103: ifeq -> 158
    //   106: aload_3
    //   107: invokeinterface next : ()Ljava/lang/Object;
    //   112: checkcast java/lang/String
    //   115: astore #6
    //   117: aload #6
    //   119: iconst_0
    //   120: anewarray java/lang/Object
    //   123: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   126: pop
    //   127: aload #6
    //   129: ldc_w 'not found'
    //   132: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   135: ifeq -> 214
    //   138: iconst_0
    //   139: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   142: astore_0
    //   143: goto -> 97
    //   146: iconst_0
    //   147: istore_2
    //   148: goto -> 22
    //   151: astore_3
    //   152: iconst_0
    //   153: istore #4
    //   155: goto -> 39
    //   158: aload_0
    //   159: astore_3
    //   160: aload_0
    //   161: ifnonnull -> 169
    //   164: iconst_1
    //   165: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   168: astore_3
    //   169: aload_3
    //   170: ifnonnull -> 205
    //   173: iconst_0
    //   174: istore #7
    //   176: iload_2
    //   177: ifne -> 199
    //   180: iload #4
    //   182: ifne -> 199
    //   185: iload_1
    //   186: istore #4
    //   188: iload #7
    //   190: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   193: invokevirtual booleanValue : ()Z
    //   196: ifeq -> 202
    //   199: iconst_1
    //   200: istore #4
    //   202: iload #4
    //   204: ireturn
    //   205: aload_3
    //   206: invokevirtual booleanValue : ()Z
    //   209: istore #7
    //   211: goto -> 176
    //   214: goto -> 143
    // Exception table:
    //   from	to	target	type
    //   22	39	151	java/lang/Throwable
  }
  
  public static long g() {
    long l2;
    long l1 = -1L;
    try {
      File file = Environment.getDataDirectory();
      StatFs statFs = new StatFs();
      this(file.getPath());
      l2 = statFs.getBlockSize();
      int i = statFs.getAvailableBlocks();
      l2 = i * l2;
    } catch (Throwable throwable) {
      l2 = l1;
    } 
    return l2;
  }
  
  public static long h() {
    // Byte code:
    //   0: aconst_null
    //   1: astore_0
    //   2: new java/io/FileReader
    //   5: astore_1
    //   6: aload_1
    //   7: ldc_w '/proc/meminfo'
    //   10: invokespecial <init> : (Ljava/lang/String;)V
    //   13: new java/io/BufferedReader
    //   16: astore_2
    //   17: aload_2
    //   18: aload_1
    //   19: sipush #2048
    //   22: invokespecial <init> : (Ljava/io/Reader;I)V
    //   25: aload_2
    //   26: invokevirtual readLine : ()Ljava/lang/String;
    //   29: ldc_w ':\s+'
    //   32: iconst_2
    //   33: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   36: iconst_1
    //   37: aaload
    //   38: invokevirtual toLowerCase : ()Ljava/lang/String;
    //   41: ldc_w 'kb'
    //   44: ldc ''
    //   46: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   49: invokevirtual trim : ()Ljava/lang/String;
    //   52: invokestatic parseLong : (Ljava/lang/String;)J
    //   55: lstore_3
    //   56: lload_3
    //   57: bipush #10
    //   59: lshl
    //   60: lstore #5
    //   62: aload_2
    //   63: invokevirtual close : ()V
    //   66: aload_1
    //   67: invokevirtual close : ()V
    //   70: lload #5
    //   72: lstore_3
    //   73: lload_3
    //   74: lreturn
    //   75: astore #7
    //   77: aload #7
    //   79: invokestatic a : (Ljava/lang/Throwable;)Z
    //   82: ifne -> 66
    //   85: aload #7
    //   87: invokevirtual printStackTrace : ()V
    //   90: goto -> 66
    //   93: astore #7
    //   95: lload #5
    //   97: lstore_3
    //   98: aload #7
    //   100: invokestatic a : (Ljava/lang/Throwable;)Z
    //   103: ifne -> 73
    //   106: aload #7
    //   108: invokevirtual printStackTrace : ()V
    //   111: lload #5
    //   113: lstore_3
    //   114: goto -> 73
    //   117: astore_1
    //   118: aconst_null
    //   119: astore #7
    //   121: aload_0
    //   122: astore_2
    //   123: aload_1
    //   124: invokestatic a : (Ljava/lang/Throwable;)Z
    //   127: ifne -> 134
    //   130: aload_1
    //   131: invokevirtual printStackTrace : ()V
    //   134: aload_2
    //   135: ifnull -> 142
    //   138: aload_2
    //   139: invokevirtual close : ()V
    //   142: aload #7
    //   144: ifnull -> 152
    //   147: aload #7
    //   149: invokevirtual close : ()V
    //   152: ldc2_w -2
    //   155: lstore_3
    //   156: goto -> 73
    //   159: astore_2
    //   160: aload_2
    //   161: invokestatic a : (Ljava/lang/Throwable;)Z
    //   164: ifne -> 142
    //   167: aload_2
    //   168: invokevirtual printStackTrace : ()V
    //   171: goto -> 142
    //   174: astore #7
    //   176: aload #7
    //   178: invokestatic a : (Ljava/lang/Throwable;)Z
    //   181: ifne -> 152
    //   184: aload #7
    //   186: invokevirtual printStackTrace : ()V
    //   189: goto -> 152
    //   192: astore #7
    //   194: aconst_null
    //   195: astore_2
    //   196: aconst_null
    //   197: astore_1
    //   198: aload_2
    //   199: ifnull -> 206
    //   202: aload_2
    //   203: invokevirtual close : ()V
    //   206: aload_1
    //   207: ifnull -> 214
    //   210: aload_1
    //   211: invokevirtual close : ()V
    //   214: aload #7
    //   216: athrow
    //   217: astore_2
    //   218: aload_2
    //   219: invokestatic a : (Ljava/lang/Throwable;)Z
    //   222: ifne -> 206
    //   225: aload_2
    //   226: invokevirtual printStackTrace : ()V
    //   229: goto -> 206
    //   232: astore_2
    //   233: aload_2
    //   234: invokestatic a : (Ljava/lang/Throwable;)Z
    //   237: ifne -> 214
    //   240: aload_2
    //   241: invokevirtual printStackTrace : ()V
    //   244: goto -> 214
    //   247: astore #7
    //   249: aconst_null
    //   250: astore_2
    //   251: goto -> 198
    //   254: astore #7
    //   256: goto -> 198
    //   259: astore_0
    //   260: aload #7
    //   262: astore_1
    //   263: aload_0
    //   264: astore #7
    //   266: goto -> 198
    //   269: astore_2
    //   270: aload_1
    //   271: astore #7
    //   273: aload_2
    //   274: astore_1
    //   275: aload_0
    //   276: astore_2
    //   277: goto -> 123
    //   280: astore #7
    //   282: aload_1
    //   283: astore_0
    //   284: aload #7
    //   286: astore_1
    //   287: aload_0
    //   288: astore #7
    //   290: goto -> 123
    // Exception table:
    //   from	to	target	type
    //   2	13	117	java/lang/Throwable
    //   2	13	192	finally
    //   13	25	269	java/lang/Throwable
    //   13	25	247	finally
    //   25	56	280	java/lang/Throwable
    //   25	56	254	finally
    //   62	66	75	java/io/IOException
    //   66	70	93	java/io/IOException
    //   123	134	259	finally
    //   138	142	159	java/io/IOException
    //   147	152	174	java/io/IOException
    //   202	206	217	java/io/IOException
    //   210	214	232	java/io/IOException
  }
  
  public static long i() {
    // Byte code:
    //   0: aconst_null
    //   1: astore_0
    //   2: new java/io/FileReader
    //   5: astore_1
    //   6: aload_1
    //   7: ldc_w '/proc/meminfo'
    //   10: invokespecial <init> : (Ljava/lang/String;)V
    //   13: new java/io/BufferedReader
    //   16: astore_2
    //   17: aload_2
    //   18: aload_1
    //   19: sipush #2048
    //   22: invokespecial <init> : (Ljava/io/Reader;I)V
    //   25: aload_2
    //   26: invokevirtual readLine : ()Ljava/lang/String;
    //   29: pop
    //   30: aload_2
    //   31: invokevirtual readLine : ()Ljava/lang/String;
    //   34: ldc_w ':\s+'
    //   37: iconst_2
    //   38: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   41: iconst_1
    //   42: aaload
    //   43: invokevirtual toLowerCase : ()Ljava/lang/String;
    //   46: ldc_w 'kb'
    //   49: ldc ''
    //   51: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   54: invokevirtual trim : ()Ljava/lang/String;
    //   57: invokestatic parseLong : (Ljava/lang/String;)J
    //   60: lstore_3
    //   61: aload_2
    //   62: invokevirtual readLine : ()Ljava/lang/String;
    //   65: ldc_w ':\s+'
    //   68: iconst_2
    //   69: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   72: iconst_1
    //   73: aaload
    //   74: invokevirtual toLowerCase : ()Ljava/lang/String;
    //   77: ldc_w 'kb'
    //   80: ldc ''
    //   82: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   85: invokevirtual trim : ()Ljava/lang/String;
    //   88: invokestatic parseLong : (Ljava/lang/String;)J
    //   91: lstore #5
    //   93: aload_2
    //   94: invokevirtual readLine : ()Ljava/lang/String;
    //   97: ldc_w ':\s+'
    //   100: iconst_2
    //   101: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   104: iconst_1
    //   105: aaload
    //   106: invokevirtual toLowerCase : ()Ljava/lang/String;
    //   109: ldc_w 'kb'
    //   112: ldc ''
    //   114: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   117: invokevirtual trim : ()Ljava/lang/String;
    //   120: invokestatic parseLong : (Ljava/lang/String;)J
    //   123: lstore #7
    //   125: lload_3
    //   126: bipush #10
    //   128: lshl
    //   129: lload #5
    //   131: bipush #10
    //   133: lshl
    //   134: ladd
    //   135: lload #7
    //   137: bipush #10
    //   139: lshl
    //   140: ladd
    //   141: lstore #5
    //   143: aload_2
    //   144: invokevirtual close : ()V
    //   147: aload_1
    //   148: invokevirtual close : ()V
    //   151: lload #5
    //   153: lstore #7
    //   155: lload #7
    //   157: lreturn
    //   158: astore #9
    //   160: aload #9
    //   162: invokestatic a : (Ljava/lang/Throwable;)Z
    //   165: ifne -> 147
    //   168: aload #9
    //   170: invokevirtual printStackTrace : ()V
    //   173: goto -> 147
    //   176: astore #9
    //   178: lload #5
    //   180: lstore #7
    //   182: aload #9
    //   184: invokestatic a : (Ljava/lang/Throwable;)Z
    //   187: ifne -> 155
    //   190: aload #9
    //   192: invokevirtual printStackTrace : ()V
    //   195: lload #5
    //   197: lstore #7
    //   199: goto -> 155
    //   202: astore_1
    //   203: aconst_null
    //   204: astore #9
    //   206: aload_0
    //   207: astore_2
    //   208: aload_1
    //   209: invokestatic a : (Ljava/lang/Throwable;)Z
    //   212: ifne -> 219
    //   215: aload_1
    //   216: invokevirtual printStackTrace : ()V
    //   219: aload_2
    //   220: ifnull -> 227
    //   223: aload_2
    //   224: invokevirtual close : ()V
    //   227: aload #9
    //   229: ifnull -> 237
    //   232: aload #9
    //   234: invokevirtual close : ()V
    //   237: ldc2_w -2
    //   240: lstore #7
    //   242: goto -> 155
    //   245: astore_2
    //   246: aload_2
    //   247: invokestatic a : (Ljava/lang/Throwable;)Z
    //   250: ifne -> 227
    //   253: aload_2
    //   254: invokevirtual printStackTrace : ()V
    //   257: goto -> 227
    //   260: astore #9
    //   262: aload #9
    //   264: invokestatic a : (Ljava/lang/Throwable;)Z
    //   267: ifne -> 237
    //   270: aload #9
    //   272: invokevirtual printStackTrace : ()V
    //   275: goto -> 237
    //   278: astore #9
    //   280: aconst_null
    //   281: astore_2
    //   282: aconst_null
    //   283: astore_1
    //   284: aload_2
    //   285: ifnull -> 292
    //   288: aload_2
    //   289: invokevirtual close : ()V
    //   292: aload_1
    //   293: ifnull -> 300
    //   296: aload_1
    //   297: invokevirtual close : ()V
    //   300: aload #9
    //   302: athrow
    //   303: astore_2
    //   304: aload_2
    //   305: invokestatic a : (Ljava/lang/Throwable;)Z
    //   308: ifne -> 292
    //   311: aload_2
    //   312: invokevirtual printStackTrace : ()V
    //   315: goto -> 292
    //   318: astore_2
    //   319: aload_2
    //   320: invokestatic a : (Ljava/lang/Throwable;)Z
    //   323: ifne -> 300
    //   326: aload_2
    //   327: invokevirtual printStackTrace : ()V
    //   330: goto -> 300
    //   333: astore #9
    //   335: aconst_null
    //   336: astore_2
    //   337: goto -> 284
    //   340: astore #9
    //   342: goto -> 284
    //   345: astore_0
    //   346: aload #9
    //   348: astore_1
    //   349: aload_0
    //   350: astore #9
    //   352: goto -> 284
    //   355: astore_2
    //   356: aload_1
    //   357: astore #9
    //   359: aload_2
    //   360: astore_1
    //   361: aload_0
    //   362: astore_2
    //   363: goto -> 208
    //   366: astore #9
    //   368: aload_1
    //   369: astore_0
    //   370: aload #9
    //   372: astore_1
    //   373: aload_0
    //   374: astore #9
    //   376: goto -> 208
    // Exception table:
    //   from	to	target	type
    //   2	13	202	java/lang/Throwable
    //   2	13	278	finally
    //   13	25	355	java/lang/Throwable
    //   13	25	333	finally
    //   25	125	366	java/lang/Throwable
    //   25	125	340	finally
    //   143	147	158	java/io/IOException
    //   147	151	176	java/io/IOException
    //   208	219	345	finally
    //   223	227	245	java/io/IOException
    //   232	237	260	java/io/IOException
    //   288	292	303	java/io/IOException
    //   296	300	318	java/io/IOException
  }
  
  public static long j() {
    int i;
    long l;
    if (Environment.getExternalStorageState().equals("mounted")) {
      i = 1;
    } else {
      i = 0;
    } 
    if (!i)
      return 0L; 
    try {
      StatFs statFs = new StatFs();
      this(Environment.getExternalStorageDirectory().getPath());
      int j = statFs.getBlockSize();
      i = statFs.getBlockCount();
      l = i;
      l = j * l;
    } catch (Throwable throwable) {}
    return l;
  }
  
  public static long k() {
    int i;
    long l;
    if (Environment.getExternalStorageState().equals("mounted")) {
      i = 1;
    } else {
      i = 0;
    } 
    if (!i)
      return 0L; 
    try {
      StatFs statFs = new StatFs();
      this(Environment.getExternalStorageDirectory().getPath());
      int j = statFs.getBlockSize();
      i = statFs.getAvailableBlocks();
      l = i;
      l = j * l;
    } catch (Throwable throwable) {}
    return l;
  }
  
  public static String l() {
    String str2;
    String str1 = "fail";
    try {
      str2 = Locale.getDefault().getCountry();
    } catch (Throwable throwable) {
      str2 = str1;
    } 
    return str2;
  }
  
  public static String m() {
    String str2;
    String str1 = "fail";
    try {
      str2 = Build.BRAND;
    } catch (Throwable throwable) {
      str2 = str1;
    } 
    return str2;
  }
  
  public static String n() {
    String str;
    try {
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
      this("yyyy-MM-dd HH:mm:ss", Locale.US);
      Date date = new Date();
      this();
      str = simpleDateFormat.format(date);
    } catch (Exception exception) {
      str = (new Date()).toString();
    } 
    return str;
  }
  
  public static long o() {
    long l;
    try {
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
      this("yyyy-MM-dd", Locale.US);
      Date date = new Date();
      this();
      l = simpleDateFormat.parse(simpleDateFormat.format(date)).getTime();
    } catch (Throwable throwable) {}
    return l;
  }
  
  private static String p() {
    // Byte code:
    //   0: new java/io/FileReader
    //   3: astore_0
    //   4: aload_0
    //   5: ldc_w '/system/build.prop'
    //   8: invokespecial <init> : (Ljava/lang/String;)V
    //   11: new java/io/BufferedReader
    //   14: astore_1
    //   15: aload_1
    //   16: aload_0
    //   17: sipush #2048
    //   20: invokespecial <init> : (Ljava/io/Reader;I)V
    //   23: aload_1
    //   24: astore_2
    //   25: aload_0
    //   26: astore_3
    //   27: aload_1
    //   28: invokevirtual readLine : ()Ljava/lang/String;
    //   31: astore #4
    //   33: aload #4
    //   35: ifnull -> 368
    //   38: aload_1
    //   39: astore_2
    //   40: aload_0
    //   41: astore_3
    //   42: aload #4
    //   44: ldc_w '='
    //   47: iconst_2
    //   48: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   51: astore #4
    //   53: aload_1
    //   54: astore_2
    //   55: aload_0
    //   56: astore_3
    //   57: aload #4
    //   59: arraylength
    //   60: iconst_2
    //   61: if_icmpne -> 23
    //   64: aload_1
    //   65: astore_2
    //   66: aload_0
    //   67: astore_3
    //   68: aload #4
    //   70: iconst_0
    //   71: aaload
    //   72: ldc_w 'ro.product.cpu.abilist'
    //   75: invokevirtual equals : (Ljava/lang/Object;)Z
    //   78: ifeq -> 128
    //   81: aload #4
    //   83: iconst_1
    //   84: aaload
    //   85: astore #4
    //   87: aload #4
    //   89: astore_3
    //   90: aload #4
    //   92: ifnull -> 114
    //   95: aload_1
    //   96: astore_2
    //   97: aload_0
    //   98: astore_3
    //   99: aload #4
    //   101: ldc_w ','
    //   104: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   107: iconst_0
    //   108: aaload
    //   109: astore #4
    //   111: aload #4
    //   113: astore_3
    //   114: aload_1
    //   115: invokevirtual close : ()V
    //   118: aload_0
    //   119: invokevirtual close : ()V
    //   122: aload_3
    //   123: astore #4
    //   125: aload #4
    //   127: areturn
    //   128: aload_1
    //   129: astore_2
    //   130: aload_0
    //   131: astore_3
    //   132: aload #4
    //   134: iconst_0
    //   135: aaload
    //   136: ldc_w 'ro.product.cpu.abi'
    //   139: invokevirtual equals : (Ljava/lang/Object;)Z
    //   142: ifeq -> 23
    //   145: aload #4
    //   147: iconst_1
    //   148: aaload
    //   149: astore #4
    //   151: goto -> 87
    //   154: astore #4
    //   156: aload #4
    //   158: invokestatic a : (Ljava/lang/Throwable;)Z
    //   161: ifne -> 118
    //   164: aload #4
    //   166: invokevirtual printStackTrace : ()V
    //   169: goto -> 118
    //   172: astore_0
    //   173: aload_3
    //   174: astore #4
    //   176: aload_0
    //   177: invokestatic a : (Ljava/lang/Throwable;)Z
    //   180: ifne -> 125
    //   183: aload_0
    //   184: invokevirtual printStackTrace : ()V
    //   187: aload_3
    //   188: astore #4
    //   190: goto -> 125
    //   193: astore #5
    //   195: aconst_null
    //   196: astore #4
    //   198: aconst_null
    //   199: astore_0
    //   200: aload #4
    //   202: astore_2
    //   203: aload_0
    //   204: astore_3
    //   205: aload #5
    //   207: invokestatic a : (Ljava/lang/Throwable;)Z
    //   210: ifne -> 223
    //   213: aload #4
    //   215: astore_2
    //   216: aload_0
    //   217: astore_3
    //   218: aload #5
    //   220: invokevirtual printStackTrace : ()V
    //   223: aload #4
    //   225: ifnull -> 233
    //   228: aload #4
    //   230: invokevirtual close : ()V
    //   233: aload_0
    //   234: ifnull -> 241
    //   237: aload_0
    //   238: invokevirtual close : ()V
    //   241: aconst_null
    //   242: astore #4
    //   244: goto -> 125
    //   247: astore #4
    //   249: aload #4
    //   251: invokestatic a : (Ljava/lang/Throwable;)Z
    //   254: ifne -> 233
    //   257: aload #4
    //   259: invokevirtual printStackTrace : ()V
    //   262: goto -> 233
    //   265: astore #4
    //   267: aload #4
    //   269: invokestatic a : (Ljava/lang/Throwable;)Z
    //   272: ifne -> 241
    //   275: aload #4
    //   277: invokevirtual printStackTrace : ()V
    //   280: goto -> 241
    //   283: astore #4
    //   285: aconst_null
    //   286: astore_2
    //   287: aconst_null
    //   288: astore_0
    //   289: aload_2
    //   290: ifnull -> 297
    //   293: aload_2
    //   294: invokevirtual close : ()V
    //   297: aload_0
    //   298: ifnull -> 305
    //   301: aload_0
    //   302: invokevirtual close : ()V
    //   305: aload #4
    //   307: athrow
    //   308: astore_3
    //   309: aload_3
    //   310: invokestatic a : (Ljava/lang/Throwable;)Z
    //   313: ifne -> 297
    //   316: aload_3
    //   317: invokevirtual printStackTrace : ()V
    //   320: goto -> 297
    //   323: astore_0
    //   324: aload_0
    //   325: invokestatic a : (Ljava/lang/Throwable;)Z
    //   328: ifne -> 305
    //   331: aload_0
    //   332: invokevirtual printStackTrace : ()V
    //   335: goto -> 305
    //   338: astore #4
    //   340: aconst_null
    //   341: astore_2
    //   342: goto -> 289
    //   345: astore #4
    //   347: aload_3
    //   348: astore_0
    //   349: goto -> 289
    //   352: astore #5
    //   354: aconst_null
    //   355: astore #4
    //   357: goto -> 200
    //   360: astore #5
    //   362: aload_1
    //   363: astore #4
    //   365: goto -> 200
    //   368: aconst_null
    //   369: astore #4
    //   371: goto -> 87
    // Exception table:
    //   from	to	target	type
    //   0	11	193	java/lang/Throwable
    //   0	11	283	finally
    //   11	23	352	java/lang/Throwable
    //   11	23	338	finally
    //   27	33	360	java/lang/Throwable
    //   27	33	345	finally
    //   42	53	360	java/lang/Throwable
    //   42	53	345	finally
    //   57	64	360	java/lang/Throwable
    //   57	64	345	finally
    //   68	81	360	java/lang/Throwable
    //   68	81	345	finally
    //   99	111	360	java/lang/Throwable
    //   99	111	345	finally
    //   114	118	154	java/io/IOException
    //   118	122	172	java/io/IOException
    //   132	145	360	java/lang/Throwable
    //   132	145	345	finally
    //   205	213	345	finally
    //   218	223	345	finally
    //   228	233	247	java/io/IOException
    //   237	241	265	java/io/IOException
    //   293	297	308	java/io/IOException
    //   301	305	323	java/io/IOException
  }
  
  public void a(String paramString) {
    this.b = paramString;
  }
  
  public <T> void a(String paramString, T paramT) {
    if (paramString == null)
      throw new IllegalArgumentException("put key can not is null"); 
    if (paramT == null)
      throw new IllegalArgumentException("put value can not is null"); 
    if (paramT instanceof java.util.Set)
      throw new IllegalArgumentException("can not support Set"); 
    i i = new i();
    i.a(this.b);
    i.a(paramT, 0);
    byte[] arrayOfByte = k.a(i.a());
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>(1);
    ArrayList<String> arrayList = new ArrayList(1);
    a(arrayList, paramT);
    hashMap.put(a(arrayList), arrayOfByte);
    this.d.remove(paramString);
    this.a.put(paramString, hashMap);
  }
  
  public void a(byte[] paramArrayOfbyte) {
    this.c.a(paramArrayOfbyte);
    this.c.a(this.b);
    HashMap<Object, Object> hashMap2 = new HashMap<Object, Object>(1);
    HashMap<Object, Object> hashMap1 = new HashMap<Object, Object>(1);
    hashMap1.put("", new byte[0]);
    hashMap2.put("", hashMap1);
    this.a = this.c.a(hashMap2, 0, false);
  }
  
  public byte[] a() {
    i i = new i(0);
    i.a(this.b);
    i.a(this.a, 0);
    return k.a(i.a());
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */