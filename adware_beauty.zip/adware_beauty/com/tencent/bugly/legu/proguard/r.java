package com.tencent.bugly.legu.proguard;

import android.content.Context;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class r {
  private static r b;
  
  public Map<String, String> a = null;
  
  private Context c;
  
  private r(Context paramContext) {
    this.c = paramContext;
  }
  
  public static r a(Context paramContext) {
    if (b == null)
      b = new r(paramContext); 
    return b;
  }
  
  private static HttpURLConnection a(String paramString1, String paramString2) {
    try {
      HttpURLConnection httpURLConnection;
      URL uRL = new URL();
      this(paramString2);
      if (paramString1 != null && paramString1.toLowerCase(Locale.US).contains("wap")) {
        paramString2 = System.getProperty("http.proxyHost");
        String str = System.getProperty("http.proxyPort");
        InetSocketAddress inetSocketAddress = new InetSocketAddress();
        this(paramString2, Integer.parseInt(str));
        Proxy proxy = new Proxy();
        this(Proxy.Type.HTTP, inetSocketAddress);
        httpURLConnection = (HttpURLConnection)uRL.openConnection(proxy);
      } else {
        httpURLConnection = (HttpURLConnection)uRL.openConnection();
      } 
      httpURLConnection.setConnectTimeout(30000);
      httpURLConnection.setReadTimeout(10000);
      httpURLConnection.setDoOutput(true);
      httpURLConnection.setDoInput(true);
      httpURLConnection.setRequestMethod("POST");
      httpURLConnection.setUseCaches(false);
      httpURLConnection.setInstanceFollowRedirects(false);
    } catch (Throwable throwable) {}
    return (HttpURLConnection)throwable;
  }
  
  private HttpURLConnection a(String paramString1, byte[] paramArrayOfbyte, String paramString2, Map<String, String> paramMap) {
    if (paramString1 == null) {
      w.e("destUrl is null.", new Object[0]);
      return null;
    } 
    HttpURLConnection httpURLConnection = a(paramString2, paramString1);
    if (httpURLConnection == null) {
      w.e("Failed to get HttpURLConnection object.", new Object[0]);
      return null;
    } 
    try {
      httpURLConnection.setRequestProperty("wup_version", "3.0");
      if (paramMap != null && paramMap.size() > 0)
        for (Map.Entry<String, String> entry : paramMap.entrySet())
          httpURLConnection.setRequestProperty((String)entry.getKey(), URLEncoder.encode((String)entry.getValue(), "utf-8"));  
    } catch (Throwable null) {
      if (!w.a(null))
        null.printStackTrace(); 
      w.e("Failed to upload crash, please check your network.", new Object[0]);
      return null;
    } 
    httpURLConnection.setRequestProperty("A37", URLEncoder.encode(paramString2, "utf-8"));
    httpURLConnection.setRequestProperty("A38", URLEncoder.encode(a.e(this.c), "utf-8"));
    httpURLConnection.connect();
    OutputStream outputStream = httpURLConnection.getOutputStream();
    if (paramArrayOfbyte == null) {
      outputStream.write(0);
      return httpURLConnection;
    } 
    outputStream.write(paramArrayOfbyte);
    return httpURLConnection;
  }
  
  private static Map<String, String> a(HttpURLConnection paramHttpURLConnection) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Map<String, List<String>> map = paramHttpURLConnection.getHeaderFields();
    if (map == null || map.size() == 0)
      return null; 
    for (String str : map.keySet()) {
      List list = map.get(str);
      if (list.size() > 0)
        hashMap.put(str, list.get(0)); 
    } 
    return (Map)hashMap;
  }
  
  private static byte[] b(HttpURLConnection paramHttpURLConnection) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aload_0
    //   3: ifnonnull -> 10
    //   6: aload_1
    //   7: astore_0
    //   8: aload_0
    //   9: areturn
    //   10: new java/io/BufferedInputStream
    //   13: astore_2
    //   14: aload_2
    //   15: aload_0
    //   16: invokevirtual getInputStream : ()Ljava/io/InputStream;
    //   19: invokespecial <init> : (Ljava/io/InputStream;)V
    //   22: aload_2
    //   23: astore_0
    //   24: new java/io/ByteArrayOutputStream
    //   27: astore_3
    //   28: aload_2
    //   29: astore_0
    //   30: aload_3
    //   31: invokespecial <init> : ()V
    //   34: aload_2
    //   35: astore_0
    //   36: sipush #1024
    //   39: newarray byte
    //   41: astore #4
    //   43: aload_2
    //   44: astore_0
    //   45: aload_2
    //   46: aload #4
    //   48: invokevirtual read : ([B)I
    //   51: istore #5
    //   53: iload #5
    //   55: ifle -> 116
    //   58: aload_2
    //   59: astore_0
    //   60: aload_3
    //   61: aload #4
    //   63: iconst_0
    //   64: iload #5
    //   66: invokevirtual write : ([BII)V
    //   69: goto -> 43
    //   72: astore #4
    //   74: aload_2
    //   75: astore_0
    //   76: aload #4
    //   78: invokestatic a : (Ljava/lang/Throwable;)Z
    //   81: ifne -> 91
    //   84: aload_2
    //   85: astore_0
    //   86: aload #4
    //   88: invokevirtual printStackTrace : ()V
    //   91: aload_1
    //   92: astore_0
    //   93: aload_2
    //   94: ifnull -> 8
    //   97: aload_2
    //   98: invokevirtual close : ()V
    //   101: aload_1
    //   102: astore_0
    //   103: goto -> 8
    //   106: astore_0
    //   107: aload_0
    //   108: invokevirtual printStackTrace : ()V
    //   111: aload_1
    //   112: astore_0
    //   113: goto -> 8
    //   116: aload_2
    //   117: astore_0
    //   118: aload_3
    //   119: invokevirtual flush : ()V
    //   122: aload_2
    //   123: astore_0
    //   124: aload_3
    //   125: invokevirtual toByteArray : ()[B
    //   128: astore #4
    //   130: aload #4
    //   132: astore_0
    //   133: aload_2
    //   134: invokevirtual close : ()V
    //   137: goto -> 8
    //   140: astore_2
    //   141: aload_2
    //   142: invokevirtual printStackTrace : ()V
    //   145: goto -> 8
    //   148: astore_2
    //   149: aconst_null
    //   150: astore_0
    //   151: aload_0
    //   152: ifnull -> 159
    //   155: aload_0
    //   156: invokevirtual close : ()V
    //   159: aload_2
    //   160: athrow
    //   161: astore_0
    //   162: aload_0
    //   163: invokevirtual printStackTrace : ()V
    //   166: goto -> 159
    //   169: astore_2
    //   170: goto -> 151
    //   173: astore #4
    //   175: aconst_null
    //   176: astore_2
    //   177: goto -> 74
    // Exception table:
    //   from	to	target	type
    //   10	22	173	java/lang/Throwable
    //   10	22	148	finally
    //   24	28	72	java/lang/Throwable
    //   24	28	169	finally
    //   30	34	72	java/lang/Throwable
    //   30	34	169	finally
    //   36	43	72	java/lang/Throwable
    //   36	43	169	finally
    //   45	53	72	java/lang/Throwable
    //   45	53	169	finally
    //   60	69	72	java/lang/Throwable
    //   60	69	169	finally
    //   76	84	169	finally
    //   86	91	169	finally
    //   97	101	106	java/lang/Throwable
    //   118	122	72	java/lang/Throwable
    //   118	122	169	finally
    //   124	130	72	java/lang/Throwable
    //   124	130	169	finally
    //   133	137	140	java/lang/Throwable
    //   155	159	161	java/lang/Throwable
  }
  
  public final byte[] a(String paramString, byte[] paramArrayOfbyte, u paramu, Map<String, String> paramMap) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 19
    //   4: ldc_w 'rqdp{  no destUrl!}'
    //   7: iconst_0
    //   8: anewarray java/lang/Object
    //   11: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   14: pop
    //   15: aconst_null
    //   16: astore_1
    //   17: aload_1
    //   18: areturn
    //   19: iconst_0
    //   20: istore #5
    //   22: aload_2
    //   23: ifnonnull -> 138
    //   26: lconst_0
    //   27: lstore #6
    //   29: ldc_w 'req %s sz:%d (pid=%d | tid=%d)'
    //   32: iconst_4
    //   33: anewarray java/lang/Object
    //   36: dup
    //   37: iconst_0
    //   38: aload_1
    //   39: aastore
    //   40: dup
    //   41: iconst_1
    //   42: lload #6
    //   44: invokestatic valueOf : (J)Ljava/lang/Long;
    //   47: aastore
    //   48: dup
    //   49: iconst_2
    //   50: invokestatic myPid : ()I
    //   53: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   56: aastore
    //   57: dup
    //   58: iconst_3
    //   59: invokestatic myTid : ()I
    //   62: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   65: aastore
    //   66: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   69: pop
    //   70: iconst_0
    //   71: istore #8
    //   73: iconst_0
    //   74: istore #9
    //   76: iload #9
    //   78: iconst_1
    //   79: iadd
    //   80: istore #10
    //   82: iload #9
    //   84: iconst_3
    //   85: if_icmpge -> 927
    //   88: iload #5
    //   90: iconst_2
    //   91: if_icmpge -> 927
    //   94: iload #8
    //   96: ifeq -> 146
    //   99: iconst_0
    //   100: istore #9
    //   102: aload_0
    //   103: getfield c : Landroid/content/Context;
    //   106: invokestatic e : (Landroid/content/Context;)Ljava/lang/String;
    //   109: astore #11
    //   111: aload #11
    //   113: ifnonnull -> 195
    //   116: ldc_w 'req but network not avail,so drop!'
    //   119: iconst_0
    //   120: anewarray java/lang/Object
    //   123: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   126: pop
    //   127: iload #9
    //   129: istore #8
    //   131: iload #10
    //   133: istore #9
    //   135: goto -> 76
    //   138: aload_2
    //   139: arraylength
    //   140: i2l
    //   141: lstore #6
    //   143: goto -> 29
    //   146: iload #8
    //   148: istore #9
    //   150: iload #10
    //   152: iconst_1
    //   153: if_icmple -> 102
    //   156: new java/lang/StringBuilder
    //   159: dup
    //   160: ldc_w 'try time '
    //   163: invokespecial <init> : (Ljava/lang/String;)V
    //   166: iload #10
    //   168: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   171: invokevirtual toString : ()Ljava/lang/String;
    //   174: iconst_0
    //   175: anewarray java/lang/Object
    //   178: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   181: pop
    //   182: ldc2_w 10000
    //   185: invokestatic sleep : (J)V
    //   188: iload #8
    //   190: istore #9
    //   192: goto -> 102
    //   195: aload_3
    //   196: lload #6
    //   198: invokevirtual a : (J)V
    //   201: aload_0
    //   202: aload_1
    //   203: aload_2
    //   204: aload #11
    //   206: aload #4
    //   208: invokespecial a : (Ljava/lang/String;[BLjava/lang/String;Ljava/util/Map;)Ljava/net/HttpURLConnection;
    //   211: astore #12
    //   213: aload #12
    //   215: ifnull -> 897
    //   218: iload #9
    //   220: istore #8
    //   222: iload #5
    //   224: istore #13
    //   226: iload #10
    //   228: istore #14
    //   230: aload_1
    //   231: astore #15
    //   233: aload #12
    //   235: invokevirtual getResponseCode : ()I
    //   238: istore #16
    //   240: iload #16
    //   242: sipush #200
    //   245: if_icmpne -> 377
    //   248: iload #9
    //   250: istore #8
    //   252: iload #5
    //   254: istore #13
    //   256: iload #10
    //   258: istore #14
    //   260: aload_1
    //   261: astore #15
    //   263: aload_0
    //   264: aload #12
    //   266: invokestatic a : (Ljava/net/HttpURLConnection;)Ljava/util/Map;
    //   269: putfield a : Ljava/util/Map;
    //   272: iload #9
    //   274: istore #8
    //   276: iload #5
    //   278: istore #13
    //   280: iload #10
    //   282: istore #14
    //   284: aload_1
    //   285: astore #15
    //   287: aload #12
    //   289: invokestatic b : (Ljava/net/HttpURLConnection;)[B
    //   292: astore #11
    //   294: aload #11
    //   296: ifnonnull -> 334
    //   299: lconst_0
    //   300: lstore #17
    //   302: iload #9
    //   304: istore #8
    //   306: iload #5
    //   308: istore #13
    //   310: iload #10
    //   312: istore #14
    //   314: aload_1
    //   315: astore #15
    //   317: aload_3
    //   318: lload #17
    //   320: invokevirtual b : (J)V
    //   323: aload #12
    //   325: invokevirtual disconnect : ()V
    //   328: aload #11
    //   330: astore_1
    //   331: goto -> 17
    //   334: iload #9
    //   336: istore #8
    //   338: iload #5
    //   340: istore #13
    //   342: iload #10
    //   344: istore #14
    //   346: aload_1
    //   347: astore #15
    //   349: aload #11
    //   351: arraylength
    //   352: istore #19
    //   354: iload #19
    //   356: i2l
    //   357: lstore #17
    //   359: goto -> 302
    //   362: astore_1
    //   363: aload_1
    //   364: invokestatic a : (Ljava/lang/Throwable;)Z
    //   367: ifne -> 328
    //   370: aload_1
    //   371: invokevirtual printStackTrace : ()V
    //   374: goto -> 328
    //   377: iload #16
    //   379: sipush #301
    //   382: if_icmpeq -> 409
    //   385: iload #16
    //   387: sipush #302
    //   390: if_icmpeq -> 409
    //   393: iload #16
    //   395: sipush #303
    //   398: if_icmpeq -> 409
    //   401: iload #16
    //   403: sipush #307
    //   406: if_icmpne -> 494
    //   409: iconst_1
    //   410: istore #8
    //   412: iload #9
    //   414: istore #20
    //   416: iload #5
    //   418: istore #19
    //   420: iload #10
    //   422: istore #9
    //   424: aload_1
    //   425: astore #11
    //   427: iload #8
    //   429: ifeq -> 555
    //   432: aload #12
    //   434: ldc_w 'Location'
    //   437: invokevirtual getHeaderField : (Ljava/lang/String;)Ljava/lang/String;
    //   440: astore #11
    //   442: aload #11
    //   444: ifnonnull -> 515
    //   447: new java/lang/StringBuilder
    //   450: astore #11
    //   452: aload #11
    //   454: ldc_w 'rqdp{  redirect code:}'
    //   457: invokespecial <init> : (Ljava/lang/String;)V
    //   460: aload #11
    //   462: iload #16
    //   464: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   467: ldc_w 'rqdp{   Location is null! return}'
    //   470: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   473: invokevirtual toString : ()Ljava/lang/String;
    //   476: iconst_0
    //   477: anewarray java/lang/Object
    //   480: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   483: pop
    //   484: aload #12
    //   486: invokevirtual disconnect : ()V
    //   489: aconst_null
    //   490: astore_1
    //   491: goto -> 17
    //   494: iconst_0
    //   495: istore #8
    //   497: goto -> 412
    //   500: astore_1
    //   501: aload_1
    //   502: invokestatic a : (Ljava/lang/Throwable;)Z
    //   505: ifne -> 489
    //   508: aload_1
    //   509: invokevirtual printStackTrace : ()V
    //   512: goto -> 489
    //   515: iinc #5, 1
    //   518: iconst_0
    //   519: istore #19
    //   521: iconst_0
    //   522: istore #9
    //   524: ldc_w 'redirect code: %d ,to:%s'
    //   527: iconst_2
    //   528: anewarray java/lang/Object
    //   531: dup
    //   532: iconst_0
    //   533: iload #16
    //   535: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   538: aastore
    //   539: dup
    //   540: iconst_1
    //   541: aload #11
    //   543: aastore
    //   544: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   547: pop
    //   548: iconst_1
    //   549: istore #20
    //   551: iload #5
    //   553: istore #19
    //   555: iload #20
    //   557: istore #8
    //   559: iload #19
    //   561: istore #13
    //   563: iload #9
    //   565: istore #14
    //   567: aload #11
    //   569: astore #15
    //   571: new java/lang/StringBuilder
    //   574: astore_1
    //   575: iload #20
    //   577: istore #8
    //   579: iload #19
    //   581: istore #13
    //   583: iload #9
    //   585: istore #14
    //   587: aload #11
    //   589: astore #15
    //   591: aload_1
    //   592: ldc_w 'response code '
    //   595: invokespecial <init> : (Ljava/lang/String;)V
    //   598: iload #20
    //   600: istore #8
    //   602: iload #19
    //   604: istore #13
    //   606: iload #9
    //   608: istore #14
    //   610: aload #11
    //   612: astore #15
    //   614: aload_1
    //   615: iload #16
    //   617: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   620: invokevirtual toString : ()Ljava/lang/String;
    //   623: iconst_0
    //   624: anewarray java/lang/Object
    //   627: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   630: pop
    //   631: iload #20
    //   633: istore #8
    //   635: iload #19
    //   637: istore #13
    //   639: iload #9
    //   641: istore #14
    //   643: aload #11
    //   645: astore #15
    //   647: aload #12
    //   649: invokevirtual getContentLength : ()I
    //   652: i2l
    //   653: lstore #21
    //   655: lload #21
    //   657: lstore #17
    //   659: lload #21
    //   661: lconst_0
    //   662: lcmp
    //   663: ifge -> 669
    //   666: lconst_0
    //   667: lstore #17
    //   669: iload #20
    //   671: istore #8
    //   673: iload #19
    //   675: istore #13
    //   677: iload #9
    //   679: istore #14
    //   681: aload #11
    //   683: astore #15
    //   685: aload_3
    //   686: lload #17
    //   688: invokevirtual b : (J)V
    //   691: aload #12
    //   693: invokevirtual disconnect : ()V
    //   696: aload #11
    //   698: astore #15
    //   700: iload #9
    //   702: istore #10
    //   704: iload #19
    //   706: istore #13
    //   708: iload #20
    //   710: istore #8
    //   712: iload #13
    //   714: istore #5
    //   716: aload #15
    //   718: astore_1
    //   719: iload #10
    //   721: istore #9
    //   723: goto -> 76
    //   726: astore_1
    //   727: iload #20
    //   729: istore #8
    //   731: iload #19
    //   733: istore #13
    //   735: iload #9
    //   737: istore #10
    //   739: aload #11
    //   741: astore #15
    //   743: aload_1
    //   744: invokestatic a : (Ljava/lang/Throwable;)Z
    //   747: ifne -> 712
    //   750: aload_1
    //   751: invokevirtual printStackTrace : ()V
    //   754: iload #20
    //   756: istore #8
    //   758: iload #19
    //   760: istore #13
    //   762: iload #9
    //   764: istore #10
    //   766: aload #11
    //   768: astore #15
    //   770: goto -> 712
    //   773: astore #11
    //   775: aload #15
    //   777: astore_1
    //   778: iload #14
    //   780: istore #19
    //   782: iload #13
    //   784: istore #5
    //   786: iload #8
    //   788: istore #9
    //   790: aload #11
    //   792: invokestatic a : (Ljava/lang/Throwable;)Z
    //   795: ifne -> 803
    //   798: aload #11
    //   800: invokevirtual printStackTrace : ()V
    //   803: aload #12
    //   805: invokevirtual disconnect : ()V
    //   808: iload #9
    //   810: istore #8
    //   812: iload #5
    //   814: istore #13
    //   816: iload #19
    //   818: istore #10
    //   820: aload_1
    //   821: astore #15
    //   823: goto -> 712
    //   826: astore #11
    //   828: iload #9
    //   830: istore #8
    //   832: iload #5
    //   834: istore #13
    //   836: iload #19
    //   838: istore #10
    //   840: aload_1
    //   841: astore #15
    //   843: aload #11
    //   845: invokestatic a : (Ljava/lang/Throwable;)Z
    //   848: ifne -> 712
    //   851: aload #11
    //   853: invokevirtual printStackTrace : ()V
    //   856: iload #9
    //   858: istore #8
    //   860: iload #5
    //   862: istore #13
    //   864: iload #19
    //   866: istore #10
    //   868: aload_1
    //   869: astore #15
    //   871: goto -> 712
    //   874: astore_1
    //   875: aload #12
    //   877: invokevirtual disconnect : ()V
    //   880: aload_1
    //   881: athrow
    //   882: astore_2
    //   883: aload_2
    //   884: invokestatic a : (Ljava/lang/Throwable;)Z
    //   887: ifne -> 880
    //   890: aload_2
    //   891: invokevirtual printStackTrace : ()V
    //   894: goto -> 880
    //   897: ldc_w 'Failed to execute post.'
    //   900: iconst_0
    //   901: anewarray java/lang/Object
    //   904: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   907: pop
    //   908: aload_3
    //   909: lconst_0
    //   910: invokevirtual b : (J)V
    //   913: iload #9
    //   915: istore #8
    //   917: iload #5
    //   919: istore #13
    //   921: aload_1
    //   922: astore #15
    //   924: goto -> 712
    //   927: aconst_null
    //   928: astore_1
    //   929: goto -> 17
    //   932: astore #11
    //   934: iconst_1
    //   935: istore #9
    //   937: iload #10
    //   939: istore #19
    //   941: goto -> 790
    //   944: astore #15
    //   946: aload #11
    //   948: astore_1
    //   949: aload #15
    //   951: astore #11
    //   953: iconst_1
    //   954: istore #9
    //   956: goto -> 790
    // Exception table:
    //   from	to	target	type
    //   233	240	773	java/io/IOException
    //   233	240	874	finally
    //   263	272	773	java/io/IOException
    //   263	272	874	finally
    //   287	294	773	java/io/IOException
    //   287	294	874	finally
    //   317	323	773	java/io/IOException
    //   317	323	874	finally
    //   323	328	362	java/lang/Throwable
    //   349	354	773	java/io/IOException
    //   349	354	874	finally
    //   432	442	932	java/io/IOException
    //   432	442	874	finally
    //   447	484	932	java/io/IOException
    //   447	484	874	finally
    //   484	489	500	java/lang/Throwable
    //   524	548	944	java/io/IOException
    //   524	548	874	finally
    //   571	575	773	java/io/IOException
    //   571	575	874	finally
    //   591	598	773	java/io/IOException
    //   591	598	874	finally
    //   614	631	773	java/io/IOException
    //   614	631	874	finally
    //   647	655	773	java/io/IOException
    //   647	655	874	finally
    //   685	691	773	java/io/IOException
    //   685	691	874	finally
    //   691	696	726	java/lang/Throwable
    //   790	803	874	finally
    //   803	808	826	java/lang/Throwable
    //   875	880	882	java/lang/Throwable
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */