package com.tencent.bugly.legu.proguard;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class o {
  private static o a = null;
  
  private static p b = null;
  
  private static boolean c = false;
  
  private o(Context paramContext, List<com.tencent.bugly.legu.a> paramList) {
    b = new p(paramContext, paramList);
  }
  
  private int a(String paramString1, String paramString2, String[] paramArrayOfString, n paramn) {
    // Byte code:
    //   0: iconst_0
    //   1: istore #5
    //   3: iconst_0
    //   4: istore #6
    //   6: aload_0
    //   7: monitorenter
    //   8: getstatic com/tencent/bugly/legu/proguard/o.b : Lcom/tencent/bugly/legu/proguard/p;
    //   11: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   14: astore #7
    //   16: aload #7
    //   18: ifnull -> 31
    //   21: aload #7
    //   23: aload_1
    //   24: aload_2
    //   25: aload_3
    //   26: invokevirtual delete : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    //   29: istore #6
    //   31: iload #6
    //   33: istore #8
    //   35: aload #4
    //   37: ifnull -> 44
    //   40: iload #6
    //   42: istore #8
    //   44: aload_0
    //   45: monitorexit
    //   46: iload #8
    //   48: ireturn
    //   49: astore_1
    //   50: aload_1
    //   51: invokestatic a : (Ljava/lang/Throwable;)Z
    //   54: ifne -> 61
    //   57: aload_1
    //   58: invokevirtual printStackTrace : ()V
    //   61: iload #5
    //   63: istore #8
    //   65: aload #4
    //   67: ifnull -> 44
    //   70: iload #5
    //   72: istore #8
    //   74: goto -> 44
    //   77: astore_1
    //   78: aload_0
    //   79: monitorexit
    //   80: aload_1
    //   81: athrow
    //   82: astore_1
    //   83: aload #4
    //   85: ifnull -> 88
    //   88: aload_1
    //   89: athrow
    // Exception table:
    //   from	to	target	type
    //   8	16	49	java/lang/Throwable
    //   8	16	82	finally
    //   21	31	49	java/lang/Throwable
    //   21	31	82	finally
    //   50	61	82	finally
    //   88	90	77	finally
  }
  
  private long a(String paramString, ContentValues paramContentValues, n paramn) {
    // Byte code:
    //   0: lconst_0
    //   1: lstore #4
    //   3: aload_0
    //   4: monitorenter
    //   5: getstatic com/tencent/bugly/legu/proguard/o.b : Lcom/tencent/bugly/legu/proguard/p;
    //   8: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   11: astore #6
    //   13: lload #4
    //   15: lstore #7
    //   17: aload #6
    //   19: ifnull -> 62
    //   22: lload #4
    //   24: lstore #7
    //   26: aload_2
    //   27: ifnull -> 62
    //   30: aload #6
    //   32: aload_1
    //   33: ldc '_id'
    //   35: aload_2
    //   36: invokevirtual replace : (Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J
    //   39: lstore #7
    //   41: lload #7
    //   43: lconst_0
    //   44: lcmp
    //   45: iflt -> 79
    //   48: ldc '[db] insert %s success'
    //   50: iconst_1
    //   51: anewarray java/lang/Object
    //   54: dup
    //   55: iconst_0
    //   56: aload_1
    //   57: aastore
    //   58: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   61: pop
    //   62: lload #7
    //   64: lstore #9
    //   66: aload_3
    //   67: ifnull -> 74
    //   70: lload #7
    //   72: lstore #9
    //   74: aload_0
    //   75: monitorexit
    //   76: lload #9
    //   78: lreturn
    //   79: ldc '[db] replace %s error'
    //   81: iconst_1
    //   82: anewarray java/lang/Object
    //   85: dup
    //   86: iconst_0
    //   87: aload_1
    //   88: aastore
    //   89: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   92: pop
    //   93: goto -> 62
    //   96: astore_1
    //   97: aload_1
    //   98: invokestatic a : (Ljava/lang/Throwable;)Z
    //   101: ifne -> 108
    //   104: aload_1
    //   105: invokevirtual printStackTrace : ()V
    //   108: lload #4
    //   110: lstore #9
    //   112: aload_3
    //   113: ifnull -> 74
    //   116: lload #4
    //   118: lstore #9
    //   120: goto -> 74
    //   123: astore_1
    //   124: aload_0
    //   125: monitorexit
    //   126: aload_1
    //   127: athrow
    //   128: astore_1
    //   129: aload_3
    //   130: ifnull -> 133
    //   133: aload_1
    //   134: athrow
    // Exception table:
    //   from	to	target	type
    //   5	13	96	java/lang/Throwable
    //   5	13	128	finally
    //   30	41	96	java/lang/Throwable
    //   30	41	128	finally
    //   48	62	96	java/lang/Throwable
    //   48	62	128	finally
    //   79	93	96	java/lang/Throwable
    //   79	93	128	finally
    //   97	108	128	finally
    //   133	135	123	finally
  }
  
  private Cursor a(boolean paramBoolean, String paramString1, String[] paramArrayOfString1, String paramString2, String[] paramArrayOfString2, String paramString3, String paramString4, String paramString5, String paramString6, n paramn) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic com/tencent/bugly/legu/proguard/o.b : Lcom/tencent/bugly/legu/proguard/p;
    //   5: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   8: astore #11
    //   10: aload #11
    //   12: ifnull -> 80
    //   15: aload #11
    //   17: iload_1
    //   18: aload_2
    //   19: aload_3
    //   20: aload #4
    //   22: aload #5
    //   24: aload #6
    //   26: aload #7
    //   28: aload #8
    //   30: aload #9
    //   32: invokevirtual query : (ZLjava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   35: astore_2
    //   36: aload #10
    //   38: ifnull -> 41
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_2
    //   44: areturn
    //   45: astore_2
    //   46: aload_2
    //   47: invokestatic a : (Ljava/lang/Throwable;)Z
    //   50: ifne -> 57
    //   53: aload_2
    //   54: invokevirtual printStackTrace : ()V
    //   57: aload #10
    //   59: ifnull -> 75
    //   62: aconst_null
    //   63: astore_2
    //   64: goto -> 41
    //   67: astore_2
    //   68: aload_2
    //   69: athrow
    //   70: astore_2
    //   71: aload_0
    //   72: monitorexit
    //   73: aload_2
    //   74: athrow
    //   75: aconst_null
    //   76: astore_2
    //   77: goto -> 41
    //   80: aconst_null
    //   81: astore_2
    //   82: goto -> 36
    // Exception table:
    //   from	to	target	type
    //   2	10	45	java/lang/Throwable
    //   2	10	67	finally
    //   15	36	45	java/lang/Throwable
    //   15	36	67	finally
    //   46	57	67	finally
    //   68	70	70	finally
  }
  
  public static o a() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/proguard/o
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/proguard/o.a : Lcom/tencent/bugly/legu/proguard/o;
    //   6: astore_0
    //   7: ldc com/tencent/bugly/legu/proguard/o
    //   9: monitorexit
    //   10: aload_0
    //   11: areturn
    //   12: astore_0
    //   13: ldc com/tencent/bugly/legu/proguard/o
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	12	finally
  }
  
  public static o a(Context paramContext, List<com.tencent.bugly.legu.a> paramList) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/proguard/o
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/proguard/o.a : Lcom/tencent/bugly/legu/proguard/o;
    //   6: ifnonnull -> 23
    //   9: new com/tencent/bugly/legu/proguard/o
    //   12: astore_2
    //   13: aload_2
    //   14: aload_0
    //   15: aload_1
    //   16: invokespecial <init> : (Landroid/content/Context;Ljava/util/List;)V
    //   19: aload_2
    //   20: putstatic com/tencent/bugly/legu/proguard/o.a : Lcom/tencent/bugly/legu/proguard/o;
    //   23: getstatic com/tencent/bugly/legu/proguard/o.a : Lcom/tencent/bugly/legu/proguard/o;
    //   26: astore_0
    //   27: ldc com/tencent/bugly/legu/proguard/o
    //   29: monitorexit
    //   30: aload_0
    //   31: areturn
    //   32: astore_0
    //   33: ldc com/tencent/bugly/legu/proguard/o
    //   35: monitorexit
    //   36: aload_0
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   3	23	32	finally
    //   23	27	32	finally
  }
  
  private static q a(Cursor paramCursor) {
    Cursor cursor = null;
    if (paramCursor == null)
      return (q)cursor; 
    try {
      q q2 = new q();
      this();
      q2.a = paramCursor.getLong(paramCursor.getColumnIndex("_id"));
      q2.b = paramCursor.getInt(paramCursor.getColumnIndex("_tp"));
      q2.c = paramCursor.getString(paramCursor.getColumnIndex("_pc"));
      q2.d = paramCursor.getString(paramCursor.getColumnIndex("_th"));
      q2.e = paramCursor.getLong(paramCursor.getColumnIndex("_tm"));
      q2.g = paramCursor.getBlob(paramCursor.getColumnIndex("_dt"));
      q q1 = q2;
    } catch (Throwable throwable) {
      paramCursor = cursor;
    } 
    return (q)paramCursor;
  }
  
  private Map<String, byte[]> a(int paramInt, n paramn) {
    Map map;
    try {
      List<q> list = c(paramInt);
      map = new HashMap<Object, Object>();
      this();
      try {
        for (q q : list) {
          byte[] arrayOfByte = q.g;
          if (arrayOfByte != null)
            map.put(q.f, arrayOfByte); 
        } 
      } catch (Throwable null) {
        if (!w.a(throwable))
          throwable.printStackTrace(); 
        if (paramn != null);
        return map;
      } 
      if (paramn != null);
      return map;
    } catch (Throwable throwable) {
      map = null;
    } finally {}
    if (!w.a(throwable))
      throwable.printStackTrace(); 
    if (paramn != null);
    return map;
  }
  
  public static void a(List<q> paramList) {
    if (paramList != null && paramList.size() != 0) {
      SQLiteDatabase sQLiteDatabase = b.getWritableDatabase();
      if (sQLiteDatabase != null) {
        StringBuilder stringBuilder = new StringBuilder();
        for (q q : paramList)
          stringBuilder.append(" or _id").append(" = ").append(q.a); 
        String str = stringBuilder.toString();
        null = str;
        if (str.length() > 0)
          null = str.substring(4); 
        stringBuilder.setLength(0);
        try {
          w.c("deleted %s data %d", new Object[] { "t_lr", Integer.valueOf(sQLiteDatabase.delete("t_lr", null, null)) });
          return;
        } catch (Throwable throwable) {
          if (!w.a(throwable))
            throwable.printStackTrace(); 
          return;
        } finally {}
      } 
    } 
  }
  
  public static boolean a(int paramInt, String paramString, n paramn) {
    boolean bool1 = true;
    boolean bool2 = false;
    boolean bool3 = false;
    try {
      SQLiteDatabase sQLiteDatabase = b.getWritableDatabase();
      if (sQLiteDatabase != null) {
        String str;
        boolean bool;
        if (paramString != null && paramString.trim().length() > 0) {
          bool = false;
        } else {
          bool = true;
        } 
        if (bool) {
          StringBuilder stringBuilder = new StringBuilder();
          this("_id = ");
          str = stringBuilder.append(paramInt).toString();
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          this("_id = ");
          str = stringBuilder.append(paramInt).append(" and _tp").append(" = \"").append(str).append("\"").toString();
        } 
        paramInt = sQLiteDatabase.delete("t_pf", str, null);
        w.c("deleted %s data %d", new Object[] { "t_pf", Integer.valueOf(paramInt) });
        if (paramInt > 0) {
          bool3 = bool1;
        } else {
          bool3 = false;
        } 
      } 
      return bool3;
    } catch (Throwable throwable) {
      if (!w.a(throwable))
        throwable.printStackTrace(); 
      bool3 = bool2;
      return bool3;
    } finally {
      if (paramn != null);
    } 
  }
  
  private boolean a(int paramInt, String paramString, byte[] paramArrayOfbyte, n paramn) {
    boolean bool = false;
    try {
      q q = new q();
      this();
      q.a = paramInt;
      q.f = paramString;
      q.e = System.currentTimeMillis();
      q.g = paramArrayOfbyte;
      return b(q);
    } catch (Throwable throwable) {
      if (!w.a(throwable))
        throwable.printStackTrace(); 
      boolean bool1 = bool;
      return bool1;
    } finally {
      if (paramn != null);
    } 
  }
  
  private static ContentValues b(l paraml) {
    ContentValues contentValues2;
    ContentValues contentValues1 = null;
    if (paraml == null)
      return contentValues1; 
    try {
      ContentValues contentValues = new ContentValues();
      this();
      contentValues2 = contentValues1;
      if (paraml.a > 0L) {
        contentValues2 = contentValues1;
        if (!TextUtils.isEmpty(paraml.b)) {
          contentValues.put("_id", Long.valueOf(paraml.a));
          contentValues.put("_pc", paraml.b);
          contentValues.put("_tm", Long.valueOf(paraml.c));
          contentValues.put("_fl", Integer.valueOf(paraml.d));
          contentValues.put("_av", paraml.f);
          contentValues.put("_sv", paraml.e);
          contentValues.put("_uid", Long.valueOf(paraml.g));
          contentValues2 = contentValues;
        } 
      } 
    } catch (Throwable throwable) {
      contentValues2 = contentValues1;
    } 
    return contentValues2;
  }
  
  private static q b(Cursor paramCursor) {
    Cursor cursor = null;
    if (paramCursor == null)
      return (q)cursor; 
    try {
      q q2 = new q();
      this();
      q2.a = paramCursor.getLong(paramCursor.getColumnIndex("_id"));
      q2.e = paramCursor.getLong(paramCursor.getColumnIndex("_tm"));
      q2.f = paramCursor.getString(paramCursor.getColumnIndex("_tp"));
      q2.g = paramCursor.getBlob(paramCursor.getColumnIndex("_dt"));
      q q1 = q2;
    } catch (Throwable throwable) {
      paramCursor = cursor;
    } 
    return (q)paramCursor;
  }
  
  public static void b(int paramInt) {
    StringBuilder stringBuilder = null;
    SQLiteDatabase sQLiteDatabase = b.getWritableDatabase();
    if (sQLiteDatabase != null) {
      if (paramInt >= 0)
        try {
          stringBuilder = new StringBuilder();
          this("_tp = ");
          String str = stringBuilder.append(paramInt).toString();
          w.c("deleted %s data %d", new Object[] { "t_lr", Integer.valueOf(sQLiteDatabase.delete("t_lr", str, null)) });
          return;
        } catch (Throwable throwable) {
          if (!w.a(throwable))
            throwable.printStackTrace(); 
          return;
        } finally {} 
    } else {
      return;
    } 
    w.c("deleted %s data %d", new Object[] { "t_lr", Integer.valueOf(sQLiteDatabase.delete("t_lr", (String)stringBuilder, null)) });
  }
  
  private boolean b(q paramq) {
    boolean bool = false;
    if (paramq == null)
      return bool; 
    try {
      SQLiteDatabase sQLiteDatabase = b.getWritableDatabase();
      boolean bool1 = bool;
      if (sQLiteDatabase != null) {
        ContentValues contentValues = d(paramq);
        bool1 = bool;
        if (contentValues != null) {
          long l = sQLiteDatabase.replace("t_pf", "_id", contentValues);
          bool1 = bool;
          if (l >= 0L) {
            w.c("insert %s success!", new Object[] { "t_pf" });
            paramq.a = l;
            bool1 = true;
          } 
        } 
      } 
      return bool1;
    } catch (Throwable throwable) {
      boolean bool1 = bool;
      if (!w.a(throwable)) {
        throwable.printStackTrace();
        bool1 = bool;
      } 
      return bool1;
    } finally {}
  }
  
  private static ContentValues c(q paramq) {
    q q1 = null;
    if (paramq == null)
      return (ContentValues)q1; 
    try {
      ContentValues contentValues2 = new ContentValues();
      this();
      if (paramq.a > 0L)
        contentValues2.put("_id", Long.valueOf(paramq.a)); 
      contentValues2.put("_tp", Integer.valueOf(paramq.b));
      contentValues2.put("_pc", paramq.c);
      contentValues2.put("_th", paramq.d);
      contentValues2.put("_tm", Long.valueOf(paramq.e));
      if (paramq.g != null)
        contentValues2.put("_dt", paramq.g); 
      ContentValues contentValues1 = contentValues2;
    } catch (Throwable throwable) {
      paramq = q1;
    } 
    return (ContentValues)paramq;
  }
  
  private static l c(Cursor paramCursor) {
    Cursor cursor = null;
    if (paramCursor == null)
      return (l)cursor; 
    try {
      l l2 = new l();
      this();
      l2.a = paramCursor.getLong(paramCursor.getColumnIndex("_id"));
      l2.b = paramCursor.getString(paramCursor.getColumnIndex("_pc"));
      l2.e = paramCursor.getString(paramCursor.getColumnIndex("_sv"));
      l2.f = paramCursor.getString(paramCursor.getColumnIndex("_av"));
      l2.c = paramCursor.getLong(paramCursor.getColumnIndex("_tm"));
      l2.d = paramCursor.getInt(paramCursor.getColumnIndex("_fl"));
      l2.g = paramCursor.getLong(paramCursor.getColumnIndex("_uid"));
      l l1 = l2;
    } catch (Throwable throwable) {
      paramCursor = cursor;
    } 
    return (l)paramCursor;
  }
  
  private List<q> c(int paramInt) {
    // Byte code:
    //   0: getstatic com/tencent/bugly/legu/proguard/o.b : Lcom/tencent/bugly/legu/proguard/p;
    //   3: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnull -> 159
    //   11: new java/lang/StringBuilder
    //   14: astore_3
    //   15: aload_3
    //   16: ldc '_id = '
    //   18: invokespecial <init> : (Ljava/lang/String;)V
    //   21: aload_3
    //   22: iload_1
    //   23: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   26: invokevirtual toString : ()Ljava/lang/String;
    //   29: astore #4
    //   31: aload_2
    //   32: ldc 't_pf'
    //   34: aconst_null
    //   35: aload #4
    //   37: aconst_null
    //   38: aconst_null
    //   39: aconst_null
    //   40: aconst_null
    //   41: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   44: astore_3
    //   45: aload_3
    //   46: ifnonnull -> 72
    //   49: aload_3
    //   50: ifnull -> 68
    //   53: aload_3
    //   54: invokeinterface isClosed : ()Z
    //   59: ifne -> 68
    //   62: aload_3
    //   63: invokeinterface close : ()V
    //   68: aconst_null
    //   69: astore_3
    //   70: aload_3
    //   71: areturn
    //   72: new java/lang/StringBuilder
    //   75: astore #5
    //   77: aload #5
    //   79: invokespecial <init> : ()V
    //   82: new java/util/ArrayList
    //   85: astore #6
    //   87: aload #6
    //   89: invokespecial <init> : ()V
    //   92: aload_3
    //   93: invokeinterface moveToNext : ()Z
    //   98: ifeq -> 248
    //   101: aload_3
    //   102: invokestatic b : (Landroid/database/Cursor;)Lcom/tencent/bugly/legu/proguard/q;
    //   105: astore #7
    //   107: aload #7
    //   109: ifnull -> 164
    //   112: aload #6
    //   114: aload #7
    //   116: invokeinterface add : (Ljava/lang/Object;)Z
    //   121: pop
    //   122: goto -> 92
    //   125: astore #6
    //   127: aload #6
    //   129: invokestatic a : (Ljava/lang/Throwable;)Z
    //   132: ifne -> 140
    //   135: aload #6
    //   137: invokevirtual printStackTrace : ()V
    //   140: aload_3
    //   141: ifnull -> 159
    //   144: aload_3
    //   145: invokeinterface isClosed : ()Z
    //   150: ifne -> 159
    //   153: aload_3
    //   154: invokeinterface close : ()V
    //   159: aconst_null
    //   160: astore_3
    //   161: goto -> 70
    //   164: aload_3
    //   165: aload_3
    //   166: ldc '_tp'
    //   168: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   173: invokeinterface getString : (I)Ljava/lang/String;
    //   178: astore #7
    //   180: aload #5
    //   182: ldc_w ' or _tp'
    //   185: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   188: ldc ' = '
    //   190: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   193: aload #7
    //   195: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   198: pop
    //   199: goto -> 92
    //   202: astore #7
    //   204: ldc_w 'unknown id!'
    //   207: iconst_0
    //   208: anewarray java/lang/Object
    //   211: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   214: pop
    //   215: goto -> 92
    //   218: astore_2
    //   219: aload_3
    //   220: astore #6
    //   222: aload_2
    //   223: astore_3
    //   224: aload #6
    //   226: ifnull -> 246
    //   229: aload #6
    //   231: invokeinterface isClosed : ()Z
    //   236: ifne -> 246
    //   239: aload #6
    //   241: invokeinterface close : ()V
    //   246: aload_3
    //   247: athrow
    //   248: aload #5
    //   250: invokevirtual length : ()I
    //   253: ifle -> 309
    //   256: aload #5
    //   258: ldc_w ' and _id'
    //   261: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   264: ldc ' = '
    //   266: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   269: iload_1
    //   270: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   273: pop
    //   274: ldc_w 'deleted %s illegle data %d'
    //   277: iconst_2
    //   278: anewarray java/lang/Object
    //   281: dup
    //   282: iconst_0
    //   283: ldc 't_pf'
    //   285: aastore
    //   286: dup
    //   287: iconst_1
    //   288: aload_2
    //   289: ldc 't_pf'
    //   291: aload #4
    //   293: iconst_4
    //   294: invokevirtual substring : (I)Ljava/lang/String;
    //   297: aconst_null
    //   298: invokevirtual delete : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    //   301: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   304: aastore
    //   305: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   308: pop
    //   309: aload_3
    //   310: ifnull -> 328
    //   313: aload_3
    //   314: invokeinterface isClosed : ()Z
    //   319: ifne -> 328
    //   322: aload_3
    //   323: invokeinterface close : ()V
    //   328: aload #6
    //   330: astore_3
    //   331: goto -> 70
    //   334: astore_3
    //   335: aconst_null
    //   336: astore #6
    //   338: goto -> 224
    //   341: astore #6
    //   343: aload_3
    //   344: astore_2
    //   345: aload #6
    //   347: astore_3
    //   348: aload_2
    //   349: astore #6
    //   351: goto -> 224
    //   354: astore #6
    //   356: aconst_null
    //   357: astore_3
    //   358: goto -> 127
    // Exception table:
    //   from	to	target	type
    //   0	7	354	java/lang/Throwable
    //   0	7	334	finally
    //   11	45	354	java/lang/Throwable
    //   11	45	334	finally
    //   72	92	125	java/lang/Throwable
    //   72	92	218	finally
    //   92	107	125	java/lang/Throwable
    //   92	107	218	finally
    //   112	122	125	java/lang/Throwable
    //   112	122	218	finally
    //   127	140	341	finally
    //   164	199	202	java/lang/Throwable
    //   164	199	218	finally
    //   204	215	125	java/lang/Throwable
    //   204	215	218	finally
    //   248	309	125	java/lang/Throwable
    //   248	309	218	finally
  }
  
  private static ContentValues d(q paramq) {
    if (paramq != null) {
      ContentValues contentValues;
      boolean bool;
      String str = paramq.f;
      if (str != null && str.trim().length() > 0) {
        bool = false;
      } else {
        bool = true;
      } 
      if (bool)
        return null; 
      try {
        ContentValues contentValues1 = new ContentValues();
        this();
        if (paramq.a > 0L)
          contentValues1.put("_id", Long.valueOf(paramq.a)); 
        contentValues1.put("_tp", paramq.f);
        contentValues1.put("_tm", Long.valueOf(paramq.e));
        contentValues = contentValues1;
        if (paramq.g != null) {
          contentValues1.put("_dt", paramq.g);
          contentValues = contentValues1;
        } 
      } catch (Throwable throwable) {}
      return contentValues;
    } 
    return null;
  }
  
  public final int a(int paramInt, String paramString, long paramLong) {
    StringBuilder stringBuilder = (new StringBuilder("_id = ")).append(paramInt).append(" and _pc").append(" = '").append(paramString).append("' ");
    if (paramLong == 0L) {
      paramString = "";
      return a("t_crd", stringBuilder.append(paramString).toString(), (String[])null, (n)null);
    } 
    paramString = " and _tm < " + paramLong;
    return a("t_crd", stringBuilder.append(paramString).toString(), (String[])null, (n)null);
  }
  
  public final int a(String paramString1, String paramString2, String[] paramArrayOfString, n paramn, boolean paramBoolean) {
    return a(paramString1, paramString2, (String[])null, (n)null);
  }
  
  public final long a(String paramString, ContentValues paramContentValues, n paramn, boolean paramBoolean) {
    return a(paramString, paramContentValues, (n)null);
  }
  
  public final Cursor a(String paramString1, String[] paramArrayOfString1, String paramString2, String[] paramArrayOfString2, n paramn, boolean paramBoolean) {
    return a(false, paramString1, paramArrayOfString1, paramString2, null, null, null, null, null, null);
  }
  
  public final l a(int paramInt, String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aconst_null
    //   3: astore #4
    //   5: getstatic com/tencent/bugly/legu/proguard/o.b : Lcom/tencent/bugly/legu/proguard/p;
    //   8: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   11: astore #5
    //   13: aload #4
    //   15: astore #6
    //   17: aload #5
    //   19: ifnull -> 122
    //   22: new java/lang/StringBuilder
    //   25: astore #6
    //   27: aload #6
    //   29: ldc '_id = '
    //   31: invokespecial <init> : (Ljava/lang/String;)V
    //   34: aload #5
    //   36: ldc_w 't_crd'
    //   39: aconst_null
    //   40: aload #6
    //   42: iload_1
    //   43: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   46: ldc_w ' and _pc'
    //   49: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   52: ldc_w ' = ''
    //   55: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: aload_2
    //   59: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: ldc_w '' and _fl'
    //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: ldc_w ' > 0'
    //   71: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   74: invokevirtual toString : ()Ljava/lang/String;
    //   77: aconst_null
    //   78: aconst_null
    //   79: aconst_null
    //   80: ldc_w '_tm DESC'
    //   83: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   86: astore_2
    //   87: aload_2
    //   88: ifnonnull -> 125
    //   91: aload #4
    //   93: astore #6
    //   95: aload_2
    //   96: ifnull -> 122
    //   99: aload #4
    //   101: astore #6
    //   103: aload_2
    //   104: invokeinterface isClosed : ()Z
    //   109: ifne -> 122
    //   112: aload_2
    //   113: invokeinterface close : ()V
    //   118: aload #4
    //   120: astore #6
    //   122: aload #6
    //   124: areturn
    //   125: aload_2
    //   126: ifnull -> 268
    //   129: aload_2
    //   130: astore #6
    //   132: aload_2
    //   133: invokeinterface moveToFirst : ()Z
    //   138: ifeq -> 268
    //   141: aload_2
    //   142: astore #6
    //   144: aload_2
    //   145: invokestatic c : (Landroid/database/Cursor;)Lcom/tencent/bugly/legu/proguard/l;
    //   148: astore_3
    //   149: aload_3
    //   150: astore #6
    //   152: aload_2
    //   153: ifnull -> 171
    //   156: aload_2
    //   157: invokeinterface isClosed : ()Z
    //   162: ifne -> 171
    //   165: aload_2
    //   166: invokeinterface close : ()V
    //   171: goto -> 122
    //   174: astore_3
    //   175: aconst_null
    //   176: astore_2
    //   177: aload_2
    //   178: astore #6
    //   180: aload_3
    //   181: invokestatic a : (Ljava/lang/Throwable;)Z
    //   184: ifne -> 194
    //   187: aload_2
    //   188: astore #6
    //   190: aload_3
    //   191: invokevirtual printStackTrace : ()V
    //   194: aload #4
    //   196: astore #6
    //   198: aload_2
    //   199: ifnull -> 122
    //   202: aload #4
    //   204: astore #6
    //   206: aload_2
    //   207: invokeinterface isClosed : ()Z
    //   212: ifne -> 122
    //   215: aload_2
    //   216: invokeinterface close : ()V
    //   221: aload #4
    //   223: astore #6
    //   225: goto -> 122
    //   228: astore #6
    //   230: aload_3
    //   231: astore_2
    //   232: aload_2
    //   233: ifnull -> 251
    //   236: aload_2
    //   237: invokeinterface isClosed : ()Z
    //   242: ifne -> 251
    //   245: aload_2
    //   246: invokeinterface close : ()V
    //   251: aload #6
    //   253: athrow
    //   254: astore_3
    //   255: aload #6
    //   257: astore_2
    //   258: aload_3
    //   259: astore #6
    //   261: goto -> 232
    //   264: astore_3
    //   265: goto -> 177
    //   268: aconst_null
    //   269: astore #6
    //   271: goto -> 152
    // Exception table:
    //   from	to	target	type
    //   22	87	174	java/lang/Throwable
    //   22	87	228	finally
    //   132	141	264	java/lang/Throwable
    //   132	141	254	finally
    //   144	149	264	java/lang/Throwable
    //   144	149	254	finally
    //   180	187	254	finally
    //   190	194	254	finally
  }
  
  public final List<q> a(int paramInt) {
    // Byte code:
    //   0: getstatic com/tencent/bugly/legu/proguard/o.b : Lcom/tencent/bugly/legu/proguard/p;
    //   3: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   6: astore_2
    //   7: aload_2
    //   8: ifnull -> 167
    //   11: iload_1
    //   12: iflt -> 75
    //   15: new java/lang/StringBuilder
    //   18: astore_3
    //   19: aload_3
    //   20: ldc_w '_tp = '
    //   23: invokespecial <init> : (Ljava/lang/String;)V
    //   26: aload_3
    //   27: iload_1
    //   28: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   31: invokevirtual toString : ()Ljava/lang/String;
    //   34: astore_3
    //   35: aload_2
    //   36: ldc 't_lr'
    //   38: aconst_null
    //   39: aload_3
    //   40: aconst_null
    //   41: aconst_null
    //   42: aconst_null
    //   43: aconst_null
    //   44: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   47: astore_3
    //   48: aload_3
    //   49: ifnonnull -> 80
    //   52: aload_3
    //   53: ifnull -> 71
    //   56: aload_3
    //   57: invokeinterface isClosed : ()Z
    //   62: ifne -> 71
    //   65: aload_3
    //   66: invokeinterface close : ()V
    //   71: aconst_null
    //   72: astore_3
    //   73: aload_3
    //   74: areturn
    //   75: aconst_null
    //   76: astore_3
    //   77: goto -> 35
    //   80: new java/lang/StringBuilder
    //   83: astore #4
    //   85: aload #4
    //   87: invokespecial <init> : ()V
    //   90: new java/util/ArrayList
    //   93: astore #5
    //   95: aload #5
    //   97: invokespecial <init> : ()V
    //   100: aload_3
    //   101: invokeinterface moveToNext : ()Z
    //   106: ifeq -> 255
    //   109: aload_3
    //   110: invokestatic a : (Landroid/database/Cursor;)Lcom/tencent/bugly/legu/proguard/q;
    //   113: astore #6
    //   115: aload #6
    //   117: ifnull -> 172
    //   120: aload #5
    //   122: aload #6
    //   124: invokeinterface add : (Ljava/lang/Object;)Z
    //   129: pop
    //   130: goto -> 100
    //   133: astore #5
    //   135: aload #5
    //   137: invokestatic a : (Ljava/lang/Throwable;)Z
    //   140: ifne -> 148
    //   143: aload #5
    //   145: invokevirtual printStackTrace : ()V
    //   148: aload_3
    //   149: ifnull -> 167
    //   152: aload_3
    //   153: invokeinterface isClosed : ()Z
    //   158: ifne -> 167
    //   161: aload_3
    //   162: invokeinterface close : ()V
    //   167: aconst_null
    //   168: astore_3
    //   169: goto -> 73
    //   172: aload_3
    //   173: aload_3
    //   174: ldc '_id'
    //   176: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   181: invokeinterface getLong : (I)J
    //   186: lstore #7
    //   188: aload #4
    //   190: ldc ' or _id'
    //   192: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   195: ldc ' = '
    //   197: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   200: lload #7
    //   202: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   205: pop
    //   206: goto -> 100
    //   209: astore #6
    //   211: ldc_w 'unknown id!'
    //   214: iconst_0
    //   215: anewarray java/lang/Object
    //   218: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   221: pop
    //   222: goto -> 100
    //   225: astore_2
    //   226: aload_3
    //   227: astore #5
    //   229: aload_2
    //   230: astore_3
    //   231: aload #5
    //   233: ifnull -> 253
    //   236: aload #5
    //   238: invokeinterface isClosed : ()Z
    //   243: ifne -> 253
    //   246: aload #5
    //   248: invokeinterface close : ()V
    //   253: aload_3
    //   254: athrow
    //   255: aload #4
    //   257: invokevirtual toString : ()Ljava/lang/String;
    //   260: astore #4
    //   262: aload #4
    //   264: invokevirtual length : ()I
    //   267: ifle -> 305
    //   270: ldc_w 'deleted %s illegle data %d'
    //   273: iconst_2
    //   274: anewarray java/lang/Object
    //   277: dup
    //   278: iconst_0
    //   279: ldc 't_lr'
    //   281: aastore
    //   282: dup
    //   283: iconst_1
    //   284: aload_2
    //   285: ldc 't_lr'
    //   287: aload #4
    //   289: iconst_4
    //   290: invokevirtual substring : (I)Ljava/lang/String;
    //   293: aconst_null
    //   294: invokevirtual delete : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I
    //   297: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   300: aastore
    //   301: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   304: pop
    //   305: aload_3
    //   306: ifnull -> 324
    //   309: aload_3
    //   310: invokeinterface isClosed : ()Z
    //   315: ifne -> 324
    //   318: aload_3
    //   319: invokeinterface close : ()V
    //   324: aload #5
    //   326: astore_3
    //   327: goto -> 73
    //   330: astore_3
    //   331: aconst_null
    //   332: astore #5
    //   334: goto -> 231
    //   337: astore_2
    //   338: aload_3
    //   339: astore #5
    //   341: aload_2
    //   342: astore_3
    //   343: goto -> 231
    //   346: astore #5
    //   348: aconst_null
    //   349: astore_3
    //   350: goto -> 135
    // Exception table:
    //   from	to	target	type
    //   15	35	346	java/lang/Throwable
    //   15	35	330	finally
    //   35	48	346	java/lang/Throwable
    //   35	48	330	finally
    //   80	100	133	java/lang/Throwable
    //   80	100	225	finally
    //   100	115	133	java/lang/Throwable
    //   100	115	225	finally
    //   120	130	133	java/lang/Throwable
    //   120	130	225	finally
    //   135	148	337	finally
    //   172	206	209	java/lang/Throwable
    //   172	206	225	finally
    //   211	222	133	java/lang/Throwable
    //   211	222	225	finally
    //   255	305	133	java/lang/Throwable
    //   255	305	225	finally
  }
  
  public final List<l> a(int paramInt, String paramString1, long paramLong, String paramString2) {
    // Byte code:
    //   0: aconst_null
    //   1: astore #6
    //   3: getstatic com/tencent/bugly/legu/proguard/o.b : Lcom/tencent/bugly/legu/proguard/p;
    //   6: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   9: astore #7
    //   11: aload #7
    //   13: ifnull -> 274
    //   16: new java/lang/StringBuilder
    //   19: astore #8
    //   21: aload #8
    //   23: ldc '_id = '
    //   25: invokespecial <init> : (Ljava/lang/String;)V
    //   28: aload #8
    //   30: iload_1
    //   31: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   34: ldc_w ' and _pc'
    //   37: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: ldc_w ' = ''
    //   43: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   46: aload_2
    //   47: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   50: ldc_w '' and _fl'
    //   53: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: ldc_w ' > 0 and '
    //   59: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: ldc_w '_sv = ''
    //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   68: aload #5
    //   70: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   73: ldc_w '' '
    //   76: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   79: astore #5
    //   81: lload_3
    //   82: lconst_0
    //   83: lcmp
    //   84: ifeq -> 164
    //   87: new java/lang/StringBuilder
    //   90: astore_2
    //   91: aload_2
    //   92: ldc_w ' and _tm > '
    //   95: invokespecial <init> : (Ljava/lang/String;)V
    //   98: aload_2
    //   99: lload_3
    //   100: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   103: invokevirtual toString : ()Ljava/lang/String;
    //   106: astore_2
    //   107: aload #7
    //   109: ldc_w 't_crd'
    //   112: aconst_null
    //   113: aload #5
    //   115: aload_2
    //   116: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   119: invokevirtual toString : ()Ljava/lang/String;
    //   122: aconst_null
    //   123: aconst_null
    //   124: aconst_null
    //   125: ldc_w '_tm ASC'
    //   128: invokevirtual query : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   131: astore #5
    //   133: aload #5
    //   135: ifnonnull -> 171
    //   138: aload #5
    //   140: ifnull -> 160
    //   143: aload #5
    //   145: invokeinterface isClosed : ()Z
    //   150: ifne -> 160
    //   153: aload #5
    //   155: invokeinterface close : ()V
    //   160: aconst_null
    //   161: astore_2
    //   162: aload_2
    //   163: areturn
    //   164: ldc_w ''
    //   167: astore_2
    //   168: goto -> 107
    //   171: aload #5
    //   173: astore_2
    //   174: new java/util/ArrayList
    //   177: astore #6
    //   179: aload #5
    //   181: astore_2
    //   182: aload #6
    //   184: invokespecial <init> : ()V
    //   187: aload #5
    //   189: astore_2
    //   190: aload #5
    //   192: invokeinterface moveToNext : ()Z
    //   197: ifeq -> 279
    //   200: aload #5
    //   202: astore_2
    //   203: aload #5
    //   205: invokestatic c : (Landroid/database/Cursor;)Lcom/tencent/bugly/legu/proguard/l;
    //   208: astore #7
    //   210: aload #7
    //   212: ifnull -> 187
    //   215: aload #5
    //   217: astore_2
    //   218: aload #6
    //   220: aload #7
    //   222: invokeinterface add : (Ljava/lang/Object;)Z
    //   227: pop
    //   228: goto -> 187
    //   231: astore #6
    //   233: aload #5
    //   235: astore_2
    //   236: aload #6
    //   238: invokestatic a : (Ljava/lang/Throwable;)Z
    //   241: ifne -> 252
    //   244: aload #5
    //   246: astore_2
    //   247: aload #6
    //   249: invokevirtual printStackTrace : ()V
    //   252: aload #5
    //   254: ifnull -> 274
    //   257: aload #5
    //   259: invokeinterface isClosed : ()Z
    //   264: ifne -> 274
    //   267: aload #5
    //   269: invokeinterface close : ()V
    //   274: aconst_null
    //   275: astore_2
    //   276: goto -> 162
    //   279: aload #6
    //   281: astore_2
    //   282: aload #5
    //   284: ifnull -> 162
    //   287: aload #6
    //   289: astore_2
    //   290: aload #5
    //   292: invokeinterface isClosed : ()Z
    //   297: ifne -> 162
    //   300: aload #5
    //   302: invokeinterface close : ()V
    //   307: aload #6
    //   309: astore_2
    //   310: goto -> 162
    //   313: astore #5
    //   315: aload #6
    //   317: astore_2
    //   318: aload_2
    //   319: ifnull -> 337
    //   322: aload_2
    //   323: invokeinterface isClosed : ()Z
    //   328: ifne -> 337
    //   331: aload_2
    //   332: invokeinterface close : ()V
    //   337: aload #5
    //   339: athrow
    //   340: astore #5
    //   342: goto -> 318
    //   345: astore #6
    //   347: aconst_null
    //   348: astore #5
    //   350: goto -> 233
    // Exception table:
    //   from	to	target	type
    //   16	81	345	java/lang/Throwable
    //   16	81	313	finally
    //   87	107	345	java/lang/Throwable
    //   87	107	313	finally
    //   107	133	345	java/lang/Throwable
    //   107	133	313	finally
    //   174	179	231	java/lang/Throwable
    //   174	179	340	finally
    //   182	187	231	java/lang/Throwable
    //   182	187	340	finally
    //   190	200	231	java/lang/Throwable
    //   190	200	340	finally
    //   203	210	231	java/lang/Throwable
    //   203	210	340	finally
    //   218	228	231	java/lang/Throwable
    //   218	228	340	finally
    //   236	244	340	finally
    //   247	252	340	finally
  }
  
  public final Map<String, byte[]> a(int paramInt, n paramn, boolean paramBoolean) {
    return a(paramInt, (n)null);
  }
  
  public final boolean a(int paramInt, String paramString, n paramn, boolean paramBoolean) {
    return a(555, paramString, (n)null);
  }
  
  public final boolean a(int paramInt, String paramString, byte[] paramArrayOfbyte, n paramn, boolean paramBoolean) {
    if (!paramBoolean) {
      a a = new a(this, 4, null);
      a.a(paramInt, paramString, paramArrayOfbyte);
      v.a().b(a);
      return true;
    } 
    return a(paramInt, paramString, paramArrayOfbyte, (n)null);
  }
  
  public final boolean a(l paraml) {
    boolean bool = false;
    if (paraml == null)
      return bool; 
    try {
      SQLiteDatabase sQLiteDatabase = b.getWritableDatabase();
      boolean bool1 = bool;
      if (sQLiteDatabase != null) {
        ContentValues contentValues = b(paraml);
        bool1 = bool;
        if (contentValues != null) {
          long l1 = sQLiteDatabase.replace("t_crd", "_id", contentValues);
          bool1 = bool;
          if (l1 >= 0L) {
            w.c("insert %s success!", new Object[] { "t_crd" });
            paraml.a = l1;
            bool1 = true;
          } 
        } 
      } 
      return bool1;
    } catch (Throwable throwable) {
      boolean bool1 = bool;
      if (!w.a(throwable)) {
        throwable.printStackTrace();
        bool1 = bool;
      } 
      return bool1;
    } finally {}
  }
  
  public final boolean a(q paramq) {
    boolean bool = false;
    if (paramq == null)
      return bool; 
    try {
      SQLiteDatabase sQLiteDatabase = b.getWritableDatabase();
      boolean bool1 = bool;
      if (sQLiteDatabase != null) {
        ContentValues contentValues = c(paramq);
        bool1 = bool;
        if (contentValues != null) {
          long l = sQLiteDatabase.replace("t_lr", "_id", contentValues);
          bool1 = bool;
          if (l >= 0L) {
            w.c("insert %s success!", new Object[] { "t_lr" });
            paramq.a = l;
            bool1 = true;
          } 
        } 
      } 
      return bool1;
    } catch (Throwable throwable) {
      boolean bool1 = bool;
      if (!w.a(throwable)) {
        throwable.printStackTrace();
        bool1 = bool;
      } 
      return bool1;
    } finally {}
  }
  
  public final int b() {
    StringBuilder stringBuilder = new StringBuilder("_fl = 0 or _sv <> '");
    com.tencent.bugly.legu.crashreport.common.info.a.a().getClass();
    return a("t_crd", stringBuilder.append("2.1.9'").toString(), (String[])null, (n)null);
  }
  
  final class a extends Thread {
    private int a;
    
    private n b;
    
    private String c;
    
    private ContentValues d;
    
    private boolean e;
    
    private String[] f;
    
    private String g;
    
    private String[] h;
    
    private String i;
    
    private String j;
    
    private String k;
    
    private String l;
    
    private String m;
    
    private String[] n;
    
    private int o;
    
    private String p;
    
    private byte[] q;
    
    public a(o this$0, int param1Int, n param1n) {
      this.a = param1Int;
      this.b = param1n;
    }
    
    public final void a(int param1Int, String param1String, byte[] param1ArrayOfbyte) {
      this.o = param1Int;
      this.p = param1String;
      this.q = param1ArrayOfbyte;
    }
    
    public final void a(boolean param1Boolean, String param1String1, String[] param1ArrayOfString1, String param1String2, String[] param1ArrayOfString2, String param1String3, String param1String4, String param1String5, String param1String6) {
      this.e = param1Boolean;
      this.c = param1String1;
      this.f = param1ArrayOfString1;
      this.g = param1String2;
      this.h = param1ArrayOfString2;
      this.i = param1String3;
      this.j = param1String4;
      this.k = param1String5;
      this.l = param1String6;
    }
    
    public final void run() {
      switch (this.a) {
        default:
          return;
        case 1:
          o.a(this.r, this.c, this.d, this.b);
        case 2:
          o.a(this.r, this.c, this.m, this.n, this.b);
        case 3:
          o.a(this.r, this.e, this.c, this.f, this.g, this.h, this.i, this.j, this.k, this.l, this.b);
        case 4:
          o.a(this.r, this.o, this.p, this.q, this.b);
        case 5:
          o.a(this.r, this.o, this.b);
        case 6:
          break;
      } 
      o o1 = this.r;
      o.a(this.o, this.p, this.b);
    }
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */