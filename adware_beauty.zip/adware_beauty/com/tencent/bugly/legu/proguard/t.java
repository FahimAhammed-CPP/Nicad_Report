package com.tencent.bugly.legu.proguard;

import android.content.Context;
import android.os.Process;
import android.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

public final class t {
  private static t a = null;
  
  private final o b;
  
  private final Context c;
  
  private Map<Integer, Long> d = new HashMap<Integer, Long>();
  
  private LinkedBlockingQueue<Runnable> e = new LinkedBlockingQueue<Runnable>();
  
  private final Object f = new Object();
  
  private String g = null;
  
  private byte[] h = null;
  
  private long i = 0L;
  
  private byte[] j = null;
  
  private long k = 0L;
  
  private String l = null;
  
  private long m = 0L;
  
  private final Object n = new Object();
  
  private boolean o = false;
  
  private final Object p = new Object();
  
  private boolean q = true;
  
  private t(Context paramContext) {
    this.c = paramContext;
    this.b = o.a();
    try {
      Class.forName("android.util.Base64");
    } catch (ClassNotFoundException classNotFoundException) {
      w.a("[UploadManager] can not find Base64 class, will not use stronger security way to upload", new Object[0]);
      this.q = false;
    } 
    if (this.q) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDP9x32s5pPtZBXzJBz2GWM/sbTvVO2+RvW0PH01IdaBxc/").append("fB6fbHZocC9T3nl1+J5eAFjIRVuV8vHDky7Qo82Mnh0PVvcZIEQvMMVKU8dsMQopxgsOs2gkSHJwgWdinKNS8CmWobo6pFwPUW11lMv714jAUZRq2GBOqiO2vQI6iwIDAQAB");
      this.g = stringBuilder.toString();
    } 
  }
  
  public static t a() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/proguard/t
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/proguard/t.a : Lcom/tencent/bugly/legu/proguard/t;
    //   6: astore_0
    //   7: ldc com/tencent/bugly/legu/proguard/t
    //   9: monitorexit
    //   10: aload_0
    //   11: areturn
    //   12: astore_0
    //   13: ldc com/tencent/bugly/legu/proguard/t
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	12	finally
  }
  
  public static t a(Context paramContext) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/proguard/t
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/proguard/t.a : Lcom/tencent/bugly/legu/proguard/t;
    //   6: ifnonnull -> 22
    //   9: new com/tencent/bugly/legu/proguard/t
    //   12: astore_1
    //   13: aload_1
    //   14: aload_0
    //   15: invokespecial <init> : (Landroid/content/Context;)V
    //   18: aload_1
    //   19: putstatic com/tencent/bugly/legu/proguard/t.a : Lcom/tencent/bugly/legu/proguard/t;
    //   22: getstatic com/tencent/bugly/legu/proguard/t.a : Lcom/tencent/bugly/legu/proguard/t;
    //   25: astore_0
    //   26: ldc com/tencent/bugly/legu/proguard/t
    //   28: monitorexit
    //   29: aload_0
    //   30: areturn
    //   31: astore_0
    //   32: ldc com/tencent/bugly/legu/proguard/t
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   3	22	31	finally
    //   22	26	31	finally
  }
  
  private void a(Runnable paramRunnable, long paramLong) {
    if (paramRunnable == null) {
      w.d("[UploadManager] upload task should not be null", new Object[0]);
      return;
    } 
    w.c("[UploadManager] execute synchronized upload task (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
    Thread thread = new Thread(paramRunnable);
    thread.setName("BuglySyncUploadThread");
    thread.start();
    try {
      thread.join(paramLong);
    } catch (Throwable throwable) {
      w.e("[UploadManager] failed to execute upload synchronized task with message: %s. Add it to queue", new Object[] { throwable.getMessage() });
      a(paramRunnable);
    } 
  }
  
  private void a(Runnable paramRunnable, boolean paramBoolean, long paramLong) {
    if (paramRunnable == null)
      w.d("[UploadManager] upload task should not be null", new Object[0]); 
    v v = v.a();
    if (v == null)
      w.d("[UploadManager] async task handler has not been initialized", new Object[0]); 
    w.c("[UploadManager] add upload task (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
    if (this.l != null) {
      if (c()) {
        w.c("[UploadManager] sucessfully got session ID, try to execute upload task now (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
        if (paramBoolean) {
          a(paramRunnable, paramLong);
        } else if (v == null) {
          a(paramRunnable);
        } else {
          v.c(paramRunnable);
        } 
        b(0);
        return;
      } 
      w.a("[UploadManager] session ID is expired, drop it (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
      a(false);
    } 
    synchronized (this.p) {
      if (!this.o) {
        a a;
        this.o = true;
        w.c("[UploadManager] try to request session ID now (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
        if (paramBoolean) {
          a = new a();
          this(this, this.c, paramRunnable, paramLong);
          a(a, 0L);
        } else {
          a(paramRunnable);
          paramRunnable = new a();
          super(this, this.c);
          a.c(paramRunnable);
        } 
      } else {
        a(paramRunnable);
      } 
      return;
    } 
  }
  
  private boolean a(Runnable paramRunnable) {
    boolean bool = false;
    if (paramRunnable == null) {
      w.d("[UploadManager] upload task should not be null", new Object[0]);
      return bool;
    } 
    try {
      w.c("[UploadManager] add upload task to queue (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
      Object object = this.f;
      /* monitor enter ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
      try {
        this.e.put(paramRunnable);
        /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=null} */
        bool = true;
      } finally {}
    } catch (Throwable throwable) {
      w.e("[UploadManager] failed to add upload task to queue: %s", new Object[] { throwable.getMessage() });
    } 
    return bool;
  }
  
  private boolean b(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: ifge -> 18
    //   4: ldc '[UploadManager] number of task to execute should >= 0'
    //   6: iconst_0
    //   7: anewarray java/lang/Object
    //   10: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   13: pop
    //   14: iconst_0
    //   15: istore_2
    //   16: iload_2
    //   17: ireturn
    //   18: aload_0
    //   19: getfield f : Ljava/lang/Object;
    //   22: astore_3
    //   23: aload_3
    //   24: monitorenter
    //   25: aload_0
    //   26: getfield e : Ljava/util/concurrent/LinkedBlockingQueue;
    //   29: invokevirtual isEmpty : ()Z
    //   32: ifeq -> 42
    //   35: aload_3
    //   36: monitorexit
    //   37: iconst_1
    //   38: istore_2
    //   39: goto -> 16
    //   42: ldc '[UploadManager] execute upload tasks of queue which has %d tasks (pid=%d | tid=%d)'
    //   44: iconst_3
    //   45: anewarray java/lang/Object
    //   48: dup
    //   49: iconst_0
    //   50: aload_0
    //   51: getfield e : Ljava/util/concurrent/LinkedBlockingQueue;
    //   54: invokevirtual size : ()I
    //   57: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   60: aastore
    //   61: dup
    //   62: iconst_1
    //   63: invokestatic myPid : ()I
    //   66: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   69: aastore
    //   70: dup
    //   71: iconst_2
    //   72: invokestatic currentThread : ()Ljava/lang/Thread;
    //   75: invokevirtual getId : ()J
    //   78: invokestatic valueOf : (J)Ljava/lang/Long;
    //   81: aastore
    //   82: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   85: pop
    //   86: iload_1
    //   87: ifeq -> 104
    //   90: iload_1
    //   91: istore #4
    //   93: iload_1
    //   94: aload_0
    //   95: getfield e : Ljava/util/concurrent/LinkedBlockingQueue;
    //   98: invokevirtual size : ()I
    //   101: if_icmple -> 113
    //   104: aload_0
    //   105: getfield e : Ljava/util/concurrent/LinkedBlockingQueue;
    //   108: invokevirtual size : ()I
    //   111: istore #4
    //   113: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/v;
    //   116: astore #5
    //   118: aload #5
    //   120: ifnonnull -> 140
    //   123: ldc '[UploadManager] async task handler has not been initialized'
    //   125: iconst_0
    //   126: anewarray java/lang/Object
    //   129: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   132: pop
    //   133: aload_3
    //   134: monitorexit
    //   135: iconst_0
    //   136: istore_2
    //   137: goto -> 16
    //   140: iconst_0
    //   141: istore_1
    //   142: iload_1
    //   143: iload #4
    //   145: if_icmpge -> 221
    //   148: aload_0
    //   149: getfield e : Ljava/util/concurrent/LinkedBlockingQueue;
    //   152: invokevirtual poll : ()Ljava/lang/Object;
    //   155: checkcast java/lang/Runnable
    //   158: astore #6
    //   160: aload #6
    //   162: ifnull -> 179
    //   165: aload #5
    //   167: aload #6
    //   169: invokevirtual c : (Ljava/lang/Runnable;)Z
    //   172: pop
    //   173: iinc #1, 1
    //   176: goto -> 142
    //   179: ldc_w '[UploadManager] upload task poll from queue is null'
    //   182: iconst_0
    //   183: anewarray java/lang/Object
    //   186: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   189: pop
    //   190: goto -> 173
    //   193: astore #6
    //   195: ldc_w '[UploadManager] failed to execute upload task with message: %s'
    //   198: iconst_1
    //   199: anewarray java/lang/Object
    //   202: dup
    //   203: iconst_0
    //   204: aload #6
    //   206: invokevirtual getMessage : ()Ljava/lang/String;
    //   209: aastore
    //   210: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   213: pop
    //   214: aload_3
    //   215: monitorexit
    //   216: iconst_0
    //   217: istore_2
    //   218: goto -> 16
    //   221: aload_3
    //   222: monitorexit
    //   223: iconst_1
    //   224: istore_2
    //   225: goto -> 16
    //   228: astore #6
    //   230: aload_3
    //   231: monitorexit
    //   232: aload #6
    //   234: athrow
    // Exception table:
    //   from	to	target	type
    //   25	37	228	finally
    //   42	86	228	finally
    //   93	104	228	finally
    //   104	113	228	finally
    //   113	118	228	finally
    //   123	135	228	finally
    //   148	160	193	java/lang/Throwable
    //   148	160	228	finally
    //   165	173	193	java/lang/Throwable
    //   165	173	228	finally
    //   179	190	193	java/lang/Throwable
    //   179	190	228	finally
    //   195	216	228	finally
  }
  
  private static boolean d() {
    boolean bool = false;
    w.c("[UploadManager] drop security info of database (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
    try {
      o o1 = o.a();
      if (o1 == null) {
        w.d("[UploadManager] failed to get Database", new Object[0]);
        return bool;
      } 
      boolean bool1 = o1.a(555, "security_info", (n)null, true);
      bool = bool1;
    } catch (Throwable throwable) {
      w.a(throwable);
    } 
    return bool;
  }
  
  private boolean e() {
    boolean bool;
    w.c("[UploadManager] record security info to database (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
    try {
      o o1 = o.a();
      if (o1 == null) {
        w.d("[UploadManager] failed to get Database", new Object[0]);
        return false;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      this();
      if (this.j != null) {
        stringBuilder.append(Base64.encodeToString(this.j, 0));
        stringBuilder.append("#");
        if (this.m != 0L) {
          stringBuilder.append(Long.toString(this.k));
        } else {
          stringBuilder.append("null");
        } 
        stringBuilder.append("#");
        if (this.l != null) {
          stringBuilder.append(this.l);
        } else {
          stringBuilder.append("null");
        } 
        stringBuilder.append("#");
        if (this.m != 0L) {
          stringBuilder.append(Long.toString(this.m));
        } else {
          stringBuilder.append("null");
        } 
        o1.a(555, "security_info", stringBuilder.toString().getBytes(), (n)null, true);
        return true;
      } 
      w.c("[UploadManager] AES key is null, will not record", new Object[0]);
      bool = false;
    } catch (Throwable throwable) {
      w.a(throwable);
      d();
      bool = false;
    } 
    return bool;
  }
  
  private boolean f() {
    // Byte code:
    //   0: ldc_w '[UploadManager] load security info from dataBase (pid=%d | tid=%d)'
    //   3: iconst_2
    //   4: anewarray java/lang/Object
    //   7: dup
    //   8: iconst_0
    //   9: invokestatic myPid : ()I
    //   12: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   15: aastore
    //   16: dup
    //   17: iconst_1
    //   18: invokestatic myTid : ()I
    //   21: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   24: aastore
    //   25: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   28: pop
    //   29: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   32: astore_1
    //   33: aload_1
    //   34: ifnonnull -> 52
    //   37: ldc_w '[UploadManager] failed to get Database'
    //   40: iconst_0
    //   41: anewarray java/lang/Object
    //   44: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   47: pop
    //   48: iconst_0
    //   49: istore_2
    //   50: iload_2
    //   51: ireturn
    //   52: aload_1
    //   53: sipush #555
    //   56: aconst_null
    //   57: iconst_1
    //   58: invokevirtual a : (ILcom/tencent/bugly/legu/proguard/n;Z)Ljava/util/Map;
    //   61: astore_1
    //   62: aload_1
    //   63: ifnull -> 299
    //   66: aload_1
    //   67: ldc_w 'security_info'
    //   70: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   75: ifeq -> 299
    //   78: new java/lang/String
    //   81: astore_3
    //   82: aload_3
    //   83: aload_1
    //   84: ldc_w 'security_info'
    //   87: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   92: checkcast [B
    //   95: invokespecial <init> : ([B)V
    //   98: aload_3
    //   99: ldc_w '#'
    //   102: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   105: astore_1
    //   106: aload_1
    //   107: arraylength
    //   108: iconst_4
    //   109: if_icmpne -> 340
    //   112: aload_1
    //   113: iconst_0
    //   114: aaload
    //   115: invokevirtual isEmpty : ()Z
    //   118: ifne -> 380
    //   121: aload_1
    //   122: iconst_0
    //   123: aaload
    //   124: ldc_w 'null'
    //   127: invokevirtual equals : (Ljava/lang/Object;)Z
    //   130: istore_2
    //   131: iload_2
    //   132: ifne -> 380
    //   135: aload_0
    //   136: aload_1
    //   137: iconst_0
    //   138: aaload
    //   139: iconst_0
    //   140: invokestatic decode : (Ljava/lang/String;I)[B
    //   143: putfield j : [B
    //   146: iconst_0
    //   147: istore #4
    //   149: iload #4
    //   151: istore #5
    //   153: iload #4
    //   155: ifne -> 203
    //   158: iload #4
    //   160: istore #5
    //   162: aload_1
    //   163: iconst_1
    //   164: aaload
    //   165: invokevirtual isEmpty : ()Z
    //   168: ifne -> 203
    //   171: aload_1
    //   172: iconst_1
    //   173: aaload
    //   174: ldc_w 'null'
    //   177: invokevirtual equals : (Ljava/lang/Object;)Z
    //   180: istore_2
    //   181: iload #4
    //   183: istore #5
    //   185: iload_2
    //   186: ifne -> 203
    //   189: aload_0
    //   190: aload_1
    //   191: iconst_1
    //   192: aaload
    //   193: invokestatic parseLong : (Ljava/lang/String;)J
    //   196: putfield k : J
    //   199: iload #4
    //   201: istore #5
    //   203: iload #5
    //   205: ifne -> 236
    //   208: aload_1
    //   209: iconst_2
    //   210: aaload
    //   211: invokevirtual isEmpty : ()Z
    //   214: ifne -> 236
    //   217: aload_1
    //   218: iconst_2
    //   219: aaload
    //   220: ldc_w 'null'
    //   223: invokevirtual equals : (Ljava/lang/Object;)Z
    //   226: ifne -> 236
    //   229: aload_0
    //   230: aload_1
    //   231: iconst_2
    //   232: aaload
    //   233: putfield l : Ljava/lang/String;
    //   236: iload #5
    //   238: istore #4
    //   240: iload #5
    //   242: ifne -> 290
    //   245: iload #5
    //   247: istore #4
    //   249: aload_1
    //   250: iconst_3
    //   251: aaload
    //   252: invokevirtual isEmpty : ()Z
    //   255: ifne -> 290
    //   258: aload_1
    //   259: iconst_3
    //   260: aaload
    //   261: ldc_w 'null'
    //   264: invokevirtual equals : (Ljava/lang/Object;)Z
    //   267: istore_2
    //   268: iload #5
    //   270: istore #4
    //   272: iload_2
    //   273: ifne -> 290
    //   276: aload_0
    //   277: aload_1
    //   278: iconst_3
    //   279: aaload
    //   280: invokestatic parseLong : (Ljava/lang/String;)J
    //   283: putfield m : J
    //   286: iload #5
    //   288: istore #4
    //   290: iload #4
    //   292: ifeq -> 299
    //   295: invokestatic d : ()Z
    //   298: pop
    //   299: iconst_1
    //   300: istore_2
    //   301: goto -> 50
    //   304: astore_3
    //   305: aload_3
    //   306: invokestatic a : (Ljava/lang/Throwable;)Z
    //   309: pop
    //   310: iconst_1
    //   311: istore #4
    //   313: goto -> 149
    //   316: astore_3
    //   317: aload_3
    //   318: invokestatic a : (Ljava/lang/Throwable;)Z
    //   321: pop
    //   322: iconst_1
    //   323: istore #5
    //   325: goto -> 203
    //   328: astore_1
    //   329: aload_1
    //   330: invokestatic a : (Ljava/lang/Throwable;)Z
    //   333: pop
    //   334: iconst_1
    //   335: istore #4
    //   337: goto -> 290
    //   340: ldc_w 'securityInfo = %s, strings.length = %d'
    //   343: iconst_2
    //   344: anewarray java/lang/Object
    //   347: dup
    //   348: iconst_0
    //   349: aload_3
    //   350: aastore
    //   351: dup
    //   352: iconst_1
    //   353: aload_1
    //   354: arraylength
    //   355: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   358: aastore
    //   359: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   362: pop
    //   363: iconst_1
    //   364: istore #4
    //   366: goto -> 290
    //   369: astore_1
    //   370: aload_1
    //   371: invokestatic a : (Ljava/lang/Throwable;)Z
    //   374: pop
    //   375: iconst_0
    //   376: istore_2
    //   377: goto -> 50
    //   380: iconst_0
    //   381: istore #4
    //   383: goto -> 149
    // Exception table:
    //   from	to	target	type
    //   29	33	369	java/lang/Throwable
    //   37	48	369	java/lang/Throwable
    //   52	62	369	java/lang/Throwable
    //   66	131	369	java/lang/Throwable
    //   135	146	304	java/lang/Throwable
    //   162	181	369	java/lang/Throwable
    //   189	199	316	java/lang/Throwable
    //   208	236	369	java/lang/Throwable
    //   249	268	369	java/lang/Throwable
    //   276	286	328	java/lang/Throwable
    //   295	299	369	java/lang/Throwable
    //   305	310	369	java/lang/Throwable
    //   317	322	369	java/lang/Throwable
    //   329	334	369	java/lang/Throwable
    //   340	363	369	java/lang/Throwable
  }
  
  public final long a(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iload_1
    //   3: iflt -> 43
    //   6: aload_0
    //   7: getfield d : Ljava/util/Map;
    //   10: iload_1
    //   11: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   14: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   19: checkcast java/lang/Long
    //   22: astore_2
    //   23: aload_2
    //   24: ifnonnull -> 35
    //   27: ldc2_w -2
    //   30: lstore_3
    //   31: aload_0
    //   32: monitorexit
    //   33: lload_3
    //   34: lreturn
    //   35: aload_2
    //   36: invokevirtual longValue : ()J
    //   39: lstore_3
    //   40: goto -> 31
    //   43: ldc_w 'unknown up %d'
    //   46: iconst_1
    //   47: anewarray java/lang/Object
    //   50: dup
    //   51: iconst_0
    //   52: iload_1
    //   53: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   56: aastore
    //   57: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   60: pop
    //   61: ldc2_w -2
    //   64: lstore_3
    //   65: goto -> 31
    //   68: astore_2
    //   69: aload_0
    //   70: monitorexit
    //   71: aload_2
    //   72: athrow
    // Exception table:
    //   from	to	target	type
    //   6	23	68	finally
    //   35	40	68	finally
    //   43	61	68	finally
  }
  
  public final void a(int paramInt1, int paramInt2, byte[] paramArrayOfbyte, String paramString, s params) {
    try {
      if (this.q) {
        u u1 = new u();
        this(this.c, paramInt1, paramInt2, paramArrayOfbyte, null, params, true);
        a(u1, false, 0L);
        return;
      } 
      u u = new u();
      this(this.c, paramInt1, paramInt2, paramArrayOfbyte, null, params, false);
      v.a().b(u);
    } catch (Throwable throwable) {}
  }
  
  public final void a(int paramInt, long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iload_1
    //   3: iflt -> 52
    //   6: aload_0
    //   7: getfield d : Ljava/util/Map;
    //   10: iload_1
    //   11: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   14: lload_2
    //   15: invokestatic valueOf : (J)Ljava/lang/Long;
    //   18: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   23: pop
    //   24: ldc_w 'up %d %d'
    //   27: iconst_2
    //   28: anewarray java/lang/Object
    //   31: dup
    //   32: iconst_0
    //   33: iload_1
    //   34: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   37: aastore
    //   38: dup
    //   39: iconst_1
    //   40: lload_2
    //   41: invokestatic valueOf : (J)Ljava/lang/Long;
    //   44: aastore
    //   45: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   48: pop
    //   49: aload_0
    //   50: monitorexit
    //   51: return
    //   52: ldc_w 'unknown up %d'
    //   55: iconst_1
    //   56: anewarray java/lang/Object
    //   59: dup
    //   60: iconst_0
    //   61: iload_1
    //   62: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   65: aastore
    //   66: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   69: pop
    //   70: goto -> 49
    //   73: astore #4
    //   75: aload_0
    //   76: monitorexit
    //   77: aload #4
    //   79: athrow
    // Exception table:
    //   from	to	target	type
    //   6	49	73	finally
    //   52	70	73	finally
  }
  
  public final void a(int paramInt, am paramam, String paramString, s params) {
    a(paramInt, paramam, null, params, false, 0L);
  }
  
  public final void a(int paramInt, am paramam, String paramString, s params, boolean paramBoolean, long paramLong) {
    u u;
    try {
      if (this.q) {
        u u1 = new u();
        this(this.c, paramInt, paramam, paramString, params, true);
        a(u1, paramBoolean, paramLong);
        return;
      } 
      u = new u();
      this(this.c, paramInt, paramam, paramString, params, false);
      if (paramBoolean) {
        a(u, paramLong);
        return;
      } 
    } catch (Throwable throwable) {
      if (!w.a(throwable))
        throwable.printStackTrace(); 
      return;
    } 
    v.a().b(u);
  }
  
  public final void a(int paramInt, an paraman) {
    // Byte code:
    //   0: aload_0
    //   1: getfield q : Z
    //   4: ifne -> 8
    //   7: return
    //   8: iload_1
    //   9: iconst_2
    //   10: if_icmpne -> 87
    //   13: ldc_w '[UploadManager] Session ID is invalid, will clear security context (pid=%d | tid=%d)'
    //   16: iconst_2
    //   17: anewarray java/lang/Object
    //   20: dup
    //   21: iconst_0
    //   22: invokestatic myPid : ()I
    //   25: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   28: aastore
    //   29: dup
    //   30: iconst_1
    //   31: invokestatic myTid : ()I
    //   34: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   37: aastore
    //   38: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   41: pop
    //   42: aload_0
    //   43: iconst_1
    //   44: invokevirtual a : (Z)V
    //   47: aload_0
    //   48: getfield p : Ljava/lang/Object;
    //   51: astore_3
    //   52: aload_3
    //   53: monitorenter
    //   54: aload_0
    //   55: getfield o : Z
    //   58: ifeq -> 77
    //   61: aload_0
    //   62: iconst_0
    //   63: putfield o : Z
    //   66: aload_0
    //   67: getfield c : Landroid/content/Context;
    //   70: ldc_w 'security_info'
    //   73: invokestatic b : (Landroid/content/Context;Ljava/lang/String;)Z
    //   76: pop
    //   77: aload_3
    //   78: monitorexit
    //   79: goto -> 7
    //   82: astore_2
    //   83: aload_3
    //   84: monitorexit
    //   85: aload_2
    //   86: athrow
    //   87: aload_0
    //   88: getfield o : Z
    //   91: ifeq -> 7
    //   94: aload_2
    //   95: ifnull -> 427
    //   98: ldc_w '[UploadManager] record security context (pid=%d | tid=%d)'
    //   101: iconst_2
    //   102: anewarray java/lang/Object
    //   105: dup
    //   106: iconst_0
    //   107: invokestatic myPid : ()I
    //   110: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   113: aastore
    //   114: dup
    //   115: iconst_1
    //   116: invokestatic myTid : ()I
    //   119: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   122: aastore
    //   123: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   126: pop
    //   127: aload_2
    //   128: getfield h : Ljava/util/Map;
    //   131: astore_3
    //   132: aload_3
    //   133: ifnull -> 422
    //   136: aload_3
    //   137: ldc_w 'S1'
    //   140: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   145: ifeq -> 422
    //   148: aload_3
    //   149: ldc_w 'S2'
    //   152: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   157: ifeq -> 422
    //   160: aload_0
    //   161: aload_2
    //   162: getfield e : J
    //   165: invokestatic currentTimeMillis : ()J
    //   168: lsub
    //   169: putfield i : J
    //   172: ldc_w '[UploadManager] time lag of server is: %d'
    //   175: iconst_1
    //   176: anewarray java/lang/Object
    //   179: dup
    //   180: iconst_0
    //   181: aload_0
    //   182: getfield i : J
    //   185: invokestatic valueOf : (J)Ljava/lang/Long;
    //   188: aastore
    //   189: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   192: pop
    //   193: aload_0
    //   194: aload_3
    //   195: ldc_w 'S1'
    //   198: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   203: checkcast java/lang/String
    //   206: putfield l : Ljava/lang/String;
    //   209: ldc_w '[UploadManager] session ID from server is: %s'
    //   212: iconst_1
    //   213: anewarray java/lang/Object
    //   216: dup
    //   217: iconst_0
    //   218: aload_0
    //   219: getfield l : Ljava/lang/String;
    //   222: aastore
    //   223: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   226: pop
    //   227: aload_0
    //   228: getfield l : Ljava/lang/String;
    //   231: invokevirtual length : ()I
    //   234: istore_1
    //   235: iload_1
    //   236: ifle -> 411
    //   239: aload_0
    //   240: aload_3
    //   241: ldc_w 'S2'
    //   244: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   249: checkcast java/lang/String
    //   252: invokestatic parseLong : (Ljava/lang/String;)J
    //   255: putfield m : J
    //   258: aload_0
    //   259: getfield m : J
    //   262: lstore #4
    //   264: new java/util/Date
    //   267: astore_2
    //   268: aload_2
    //   269: aload_0
    //   270: getfield m : J
    //   273: invokespecial <init> : (J)V
    //   276: ldc_w '[UploadManager] session expired time from server is: %d(%s)'
    //   279: iconst_2
    //   280: anewarray java/lang/Object
    //   283: dup
    //   284: iconst_0
    //   285: lload #4
    //   287: invokestatic valueOf : (J)Ljava/lang/Long;
    //   290: aastore
    //   291: dup
    //   292: iconst_1
    //   293: aload_2
    //   294: invokevirtual toString : ()Ljava/lang/String;
    //   297: aastore
    //   298: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   301: pop
    //   302: aload_0
    //   303: getfield m : J
    //   306: ldc2_w 1000
    //   309: lcmp
    //   310: ifge -> 331
    //   313: ldc_w '[UploadManager] session expired time from server is less than 1 second, will set to default value'
    //   316: iconst_0
    //   317: anewarray java/lang/Object
    //   320: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   323: pop
    //   324: aload_0
    //   325: ldc2_w 259200000
    //   328: putfield m : J
    //   331: aload_0
    //   332: iconst_0
    //   333: invokespecial b : (I)Z
    //   336: pop
    //   337: aload_0
    //   338: invokespecial e : ()Z
    //   341: istore #6
    //   343: iload #6
    //   345: ifeq -> 395
    //   348: iconst_0
    //   349: istore_1
    //   350: iload_1
    //   351: ifeq -> 47
    //   354: aload_0
    //   355: iconst_0
    //   356: invokevirtual a : (Z)V
    //   359: goto -> 47
    //   362: astore_2
    //   363: ldc_w '[UploadManager] session expired time is invalid, will set to default value'
    //   366: iconst_0
    //   367: anewarray java/lang/Object
    //   370: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   373: pop
    //   374: aload_0
    //   375: ldc2_w 259200000
    //   378: putfield m : J
    //   381: goto -> 331
    //   384: astore_2
    //   385: aload_2
    //   386: invokestatic a : (Ljava/lang/Throwable;)Z
    //   389: pop
    //   390: iconst_1
    //   391: istore_1
    //   392: goto -> 350
    //   395: ldc_w '[UploadManager] failed to record database'
    //   398: iconst_0
    //   399: anewarray java/lang/Object
    //   402: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   405: pop
    //   406: iconst_1
    //   407: istore_1
    //   408: goto -> 350
    //   411: ldc_w '[UploadManager] session ID from server is invalid, try next time'
    //   414: iconst_0
    //   415: anewarray java/lang/Object
    //   418: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   421: pop
    //   422: iconst_1
    //   423: istore_1
    //   424: goto -> 350
    //   427: ldc_w '[UploadManager] fail to init security context and clear local info (pid=%d | tid=%d)'
    //   430: iconst_2
    //   431: anewarray java/lang/Object
    //   434: dup
    //   435: iconst_0
    //   436: invokestatic myPid : ()I
    //   439: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   442: aastore
    //   443: dup
    //   444: iconst_1
    //   445: invokestatic myTid : ()I
    //   448: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   451: aastore
    //   452: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   455: pop
    //   456: aload_0
    //   457: iconst_0
    //   458: invokevirtual a : (Z)V
    //   461: goto -> 47
    // Exception table:
    //   from	to	target	type
    //   54	77	82	finally
    //   77	79	82	finally
    //   127	132	384	java/lang/Throwable
    //   136	235	384	java/lang/Throwable
    //   239	331	362	java/lang/NumberFormatException
    //   239	331	384	java/lang/Throwable
    //   331	343	384	java/lang/Throwable
    //   363	381	384	java/lang/Throwable
    //   395	406	384	java/lang/Throwable
    //   411	422	384	java/lang/Throwable
  }
  
  protected final void a(long paramLong) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new com/tencent/bugly/legu/proguard/q
    //   5: astore_3
    //   6: aload_3
    //   7: invokespecial <init> : ()V
    //   10: aload_3
    //   11: iconst_3
    //   12: putfield b : I
    //   15: aload_3
    //   16: invokestatic o : ()J
    //   19: putfield e : J
    //   22: aload_3
    //   23: ldc_w ''
    //   26: putfield c : Ljava/lang/String;
    //   29: aload_3
    //   30: ldc_w ''
    //   33: putfield d : Ljava/lang/String;
    //   36: aload_3
    //   37: lload_1
    //   38: invokestatic a : (J)[B
    //   41: putfield g : [B
    //   44: aload_0
    //   45: getfield b : Lcom/tencent/bugly/legu/proguard/o;
    //   48: astore #4
    //   50: iconst_3
    //   51: invokestatic b : (I)V
    //   54: aload_0
    //   55: getfield b : Lcom/tencent/bugly/legu/proguard/o;
    //   58: aload_3
    //   59: invokevirtual a : (Lcom/tencent/bugly/legu/proguard/q;)Z
    //   62: pop
    //   63: ldc_w 'consume update %d'
    //   66: iconst_1
    //   67: anewarray java/lang/Object
    //   70: dup
    //   71: iconst_0
    //   72: lload_1
    //   73: invokestatic valueOf : (J)Ljava/lang/Long;
    //   76: aastore
    //   77: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   80: pop
    //   81: aload_0
    //   82: monitorexit
    //   83: return
    //   84: astore #4
    //   86: aload_0
    //   87: monitorexit
    //   88: aload #4
    //   90: athrow
    // Exception table:
    //   from	to	target	type
    //   2	81	84	finally
  }
  
  protected final void a(boolean paramBoolean) {
    synchronized (this.n) {
      w.c("[UploadManager] clear security context (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
      this.j = null;
      this.l = null;
      this.m = 0L;
      if (paramBoolean)
        d(); 
      return;
    } 
  }
  
  public final boolean a(Map<String, String> paramMap) {
    boolean bool = false;
    if (paramMap != null) {
      w.c("[UploadManager] integrate security to HTTP headers (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
      if (this.l != null) {
        paramMap.put("secureSessionId", this.l);
        return true;
      } 
      if (this.j == null || this.j.length << 3 != 128) {
        w.d("[UploadManager] AES key is invalid", new Object[0]);
        return bool;
      } 
      if (this.h == null) {
        this.h = Base64.decode(this.g, 0);
        if (this.h == null) {
          w.d("[UploadManager] failed to decode RSA public key", new Object[0]);
          return bool;
        } 
      } 
      byte[] arrayOfByte = a.b(1, this.j, this.h);
      if (arrayOfByte == null) {
        w.d("[UploadManager] failed to encrypt AES key", new Object[0]);
        return bool;
      } 
      String str = Base64.encodeToString(arrayOfByte, 0);
      if (str == null) {
        w.d("[UploadManager] failed to encode AES key", new Object[0]);
        return bool;
      } 
      paramMap.put("raKey", str);
      bool = true;
    } 
    return bool;
  }
  
  public final byte[] a(byte[] paramArrayOfbyte) {
    if (this.j == null || this.j.length << 3 != 128) {
      w.d("[UploadManager] AES key is invalid (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
      return null;
    } 
    return a.a(1, paramArrayOfbyte, this.j);
  }
  
  public final long b() {
    long l1 = 0L;
    long l2 = a.o();
    List<q> list = this.b.a(3);
    if (list != null && list.size() > 0) {
      long l4 = l1;
      try {
        q q = list.get(0);
        long l = l1;
        l4 = l1;
        if (q.e >= l2) {
          l4 = l1;
          l = a.c(q.g);
          l4 = l;
          list.remove(q);
        } 
        l4 = l;
      } catch (Throwable throwable) {
        w.e("error local type %d", new Object[] { Integer.valueOf(3) });
      } 
      long l5 = l4;
      if (list.size() > 0) {
        o o1 = this.b;
        o.a(list);
        l5 = l4;
      } 
      w.c("consume getted %d", new Object[] { Long.valueOf(l5) });
      return l5;
    } 
    long l3 = 0L;
    w.c("consume getted %d", new Object[] { Long.valueOf(l3) });
    return l3;
  }
  
  public final byte[] b(byte[] paramArrayOfbyte) {
    if (this.j == null || this.j.length << 3 != 128) {
      w.d("[UploadManager] AES key is invalid (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
      return null;
    } 
    return a.a(2, paramArrayOfbyte, this.j);
  }
  
  protected final boolean c() {
    boolean bool = false;
    null = bool;
    if (this.l != null) {
      if (this.m == 0L)
        return bool; 
    } else {
      return null;
    } 
    long l = System.currentTimeMillis() + this.i;
    if (this.m < l) {
      w.c("[UploadManager] session ID expired time from server is: %d(%s), but now is: %d(%s)", new Object[] { Long.valueOf(this.m), (new Date(this.m)).toString(), Long.valueOf(l), (new Date(l)).toString() });
      return bool;
    } 
    return true;
  }
  
  final class a implements Runnable {
    private final Context a;
    
    private final Runnable b;
    
    private final long c;
    
    public a(Context param1Context) {
      this(param1Context, null, 0L);
    }
    
    public a(Context param1Context, Runnable param1Runnable, long param1Long) {
      this.a = param1Context;
      this.b = param1Runnable;
      this.c = param1Long;
    }
    
    public final void run() {
      if (!a.a(this.a, "security_info", 30000L)) {
        v v = v.a();
        if (v == null) {
          w.e("[UploadManager] async task handler has not been initialized", new Object[0]);
          return;
        } 
        w.c("[UploadManager] sleep %d try to lock security file again", new Object[] { Integer.valueOf(5000) });
        try {
          Thread.sleep(5000L);
        } catch (InterruptedException interruptedException) {
          interruptedException.printStackTrace();
        } 
        v.c(new a(t.a(this.d)));
        return;
      } 
      if (!t.b(this.d)) {
        w.d("[UploadManager] failed to load security info from database", new Object[0]);
        this.d.a(false);
      } 
      if (t.c(this.d) != null) {
        if (this.d.c()) {
          w.c("[UploadManager] sucessfully got session ID, try to execute upload tasks now (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
          if (this.b != null)
            t.a(this.d, this.b, this.c); 
          t.a(this.d, 0);
          a.b(this.a, "security_info");
          synchronized (t.d(this.d)) {
            t.a(this.d, false);
            return;
          } 
        } 
        w.a("[UploadManager] session ID is expired, drop it", new Object[0]);
        this.d.a(true);
      } 
      byte[] arrayOfByte = a.a(128);
      if (arrayOfByte != null && arrayOfByte.length << 3 == 128) {
        t.a(this.d, arrayOfByte);
        w.c("[UploadManager] execute one upload task for requesting session ID (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
        if (this.b != null) {
          t.a(this.d, this.b, this.c);
          return;
        } 
        if (!t.a(this.d, 1)) {
          w.d("[UploadManager] failed to execute one upload task (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
        } else {
          return;
        } 
      } else {
        w.d("[UploadManager] failed to create AES key (pid=%d | tid=%d)", new Object[] { Integer.valueOf(Process.myPid()), Integer.valueOf(Process.myTid()) });
      } 
      this.d.a(false);
      a.b(this.a, "security_info");
      synchronized (t.d(this.d)) {
        t.a(this.d, false);
        return;
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */