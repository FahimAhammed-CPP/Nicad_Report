package com.tencent.bugly.legu.proguard;

import java.nio.ByteBuffer;
import java.util.HashMap;

public final class d extends c {
  private static HashMap<String, byte[]> f = null;
  
  private static HashMap<String, HashMap<String, byte[]>> g = null;
  
  private f e = new f();
  
  public d() {
    this.e.a = (short)2;
  }
  
  public final <T> void a(String paramString, T paramT) {
    if (paramString.startsWith("."))
      throw new IllegalArgumentException("put name can not startwith . , now is " + paramString); 
    super.a(paramString, paramT);
  }
  
  public final void a(byte[] paramArrayOfbyte) {
    if (paramArrayOfbyte.length < 4)
      throw new IllegalArgumentException("decode package must include size head"); 
    try {
      h h2 = new h();
      this(paramArrayOfbyte, 4);
      h2.a(this.b);
      this.e.a(h2);
      if (this.e.a == 3) {
        h h = new h();
        this(this.e.e);
        h.a(this.b);
        if (f == null) {
          HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
          this();
          f = (HashMap)hashMap;
          hashMap.put("", new byte[0]);
        } 
        this.d = h.a(f, 0, false);
        return;
      } 
      h h1 = new h();
      this(this.e.e);
      h1.a(this.b);
      if (g == null) {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        this();
        g = (HashMap)hashMap;
        hashMap = new HashMap<Object, Object>();
        this();
        hashMap.put("", new byte[0]);
        g.put("", hashMap);
      } 
      this.a = h1.a(g, 0, false);
      new HashMap<Object, Object>();
      return;
    } catch (Exception exception) {
      throw new RuntimeException(exception);
    } 
  }
  
  public final byte[] a() {
    ByteBuffer byteBuffer2;
    if (this.e.a == 2) {
      if (this.e.c.equals(""))
        throw new IllegalArgumentException("servantName can not is null"); 
      if (this.e.d.equals(""))
        throw new IllegalArgumentException("funcName can not is null"); 
    } else {
      if (this.e.c == null)
        this.e.c = ""; 
      if (this.e.d == null)
        this.e.d = ""; 
    } 
    i i2 = new i(0);
    i2.a(this.b);
    if (this.e.a == 2) {
      i2.a(this.a, 0);
      this.e.e = k.a(i2.a());
      i2 = new i(0);
      i2.a(this.b);
      this.e.a(i2);
      byte[] arrayOfByte1 = k.a(i2.a());
      int j = arrayOfByte1.length;
      byteBuffer2 = ByteBuffer.allocate(j + 4);
      byteBuffer2.putInt(j + 4).put(arrayOfByte1).flip();
      return byteBuffer2.array();
    } 
    byteBuffer2.a(this.d, 0);
    this.e.e = k.a(byteBuffer2.a());
    i i1 = new i(0);
    i1.a(this.b);
    this.e.a(i1);
    byte[] arrayOfByte = k.a(i1.a());
    int i = arrayOfByte.length;
    ByteBuffer byteBuffer1 = ByteBuffer.allocate(i + 4);
    byteBuffer1.putInt(i + 4).put(arrayOfByte).flip();
    return byteBuffer1.array();
  }
  
  public final void b(int paramInt) {
    this.e.b = 1;
  }
  
  public final void b(String paramString) {
    this.e.c = paramString;
  }
  
  public final void c(String paramString) {
    this.e.d = paramString;
  }
  
  public final void p() {
    super.p();
    this.e.a = (short)3;
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */