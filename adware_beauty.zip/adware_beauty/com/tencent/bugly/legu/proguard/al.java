package com.tencent.bugly.legu.proguard;

import java.util.ArrayList;

public final class al extends j implements Cloneable {
  private static ArrayList<ak> b;
  
  public ArrayList<ak> a = null;
  
  public final void a(h paramh) {
    if (b == null) {
      b = new ArrayList<ak>();
      ak ak = new ak();
      b.add(ak);
    } 
    this.a = (ArrayList<ak>)paramh.<ArrayList<ak>>a(b, 0, true);
  }
  
  public final void a(i parami) {
    parami.a(this.a, 0);
  }
  
  public final void a(StringBuilder paramStringBuilder, int paramInt) {}
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */