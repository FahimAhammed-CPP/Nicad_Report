package com.tencent.bugly.legu.proguard;

import java.util.HashMap;

public class c extends a {
  protected HashMap<String, byte[]> d = null;
  
  private HashMap<String, Object> e = new HashMap<String, Object>();
  
  private h f = new h();
  
  public <T> void a(String paramString, T paramT) {
    byte[] arrayOfByte;
    if (this.d != null) {
      if (paramString == null)
        throw new IllegalArgumentException("put key can not is null"); 
      if (paramT == null)
        throw new IllegalArgumentException("put value can not is null"); 
      if (paramT instanceof java.util.Set)
        throw new IllegalArgumentException("can not support Set"); 
      i i = new i();
      i.a(this.b);
      i.a(paramT, 0);
      arrayOfByte = k.a(i.a());
      this.d.put(paramString, arrayOfByte);
      return;
    } 
    super.a(paramString, arrayOfByte);
  }
  
  public void a(byte[] paramArrayOfbyte) {
    try {
      super.a(paramArrayOfbyte);
    } catch (Exception exception) {
      this.f.a(paramArrayOfbyte);
      this.f.a(this.b);
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>(1);
      hashMap.put("", new byte[0]);
      this.d = this.f.a(hashMap, 0, false);
    } 
  }
  
  public byte[] a() {
    if (this.d != null) {
      i i = new i(0);
      i.a(this.b);
      i.a(this.d, 0);
      return k.a(i.a());
    } 
    return super.a();
  }
  
  public final <T> T b(String paramString, T paramT) throws b {
    Object object = null;
    if (this.d != null) {
      if (this.d.containsKey(paramString)) {
        if (this.e.containsKey(paramString))
          return (T)this.e.get(paramString); 
        object = this.d.get(paramString);
        try {
          this.f.a((byte[])object);
          this.f.a(this.b);
          paramT = this.f.a(paramT, 0, true);
          object = paramT;
          if (paramT != null) {
            this.e.put(paramString, paramT);
            object = paramT;
          } 
        } catch (Exception exception) {
          throw new b(exception);
        } 
      } 
      return (T)object;
    } 
    if (this.a.containsKey(exception)) {
      if (this.e.containsKey(exception))
        return (T)this.e.get(exception); 
      object = ((HashMap)this.a.get(exception)).entrySet().iterator();
      if (object.hasNext()) {
        object = object.next();
        object.getKey();
        object = object.getValue();
      } else {
        object = new byte[0];
      } 
      try {
        this.f.a((byte[])object);
        this.f.a(this.b);
        object = this.f.a(paramT, 0, true);
        this.e.put(exception, object);
      } catch (Exception exception1) {
        throw new b(exception1);
      } 
    } 
    return (T)object;
  }
  
  public void p() {
    this.d = (HashMap)new HashMap<String, byte>();
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */