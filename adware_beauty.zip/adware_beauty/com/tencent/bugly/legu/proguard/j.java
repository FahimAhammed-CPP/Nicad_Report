package com.tencent.bugly.legu.proguard;

import java.io.Serializable;

public abstract class j implements Serializable {
  public abstract void a(h paramh);
  
  public abstract void a(i parami);
  
  public abstract void a(StringBuilder paramStringBuilder, int paramInt);
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    a(stringBuilder, 0);
    return stringBuilder.toString();
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */