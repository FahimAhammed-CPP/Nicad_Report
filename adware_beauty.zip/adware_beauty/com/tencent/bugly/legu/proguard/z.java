package com.tencent.bugly.legu.proguard;

import android.content.Context;
import com.tencent.bugly.legu.BuglyStrategy;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.common.strategy.a;
import com.tencent.bugly.legu.crashreport.crash.b;

public final class z {
  private Context a;
  
  private b b;
  
  private a c;
  
  private a d;
  
  public z(Context paramContext, b paramb, a parama, a parama1, BuglyStrategy.a parama2) {
    this.a = paramContext;
    this.b = paramb;
    this.c = parama;
    this.d = parama1;
  }
  
  public final void a(Thread paramThread, String paramString1, String paramString2, String paramString3) {
    // Byte code:
    //   0: ldc 'U3D Crash Happen'
    //   2: iconst_0
    //   3: anewarray java/lang/Object
    //   6: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   9: pop
    //   10: aload_0
    //   11: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   14: invokevirtual c : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   17: pop
    //   18: aload_0
    //   19: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   22: invokevirtual b : ()Z
    //   25: ifne -> 81
    //   28: ldc 'waiting for remote sync'
    //   30: iconst_0
    //   31: anewarray java/lang/Object
    //   34: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   37: pop
    //   38: iconst_0
    //   39: istore #5
    //   41: aload_0
    //   42: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   45: invokevirtual b : ()Z
    //   48: istore #6
    //   50: iload #6
    //   52: ifne -> 81
    //   55: ldc2_w 500
    //   58: invokestatic sleep : (J)V
    //   61: iload #5
    //   63: sipush #500
    //   66: iadd
    //   67: istore #7
    //   69: iload #7
    //   71: istore #5
    //   73: iload #7
    //   75: sipush #5000
    //   78: if_icmplt -> 41
    //   81: aload_0
    //   82: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   85: invokevirtual b : ()Z
    //   88: ifne -> 101
    //   91: ldc 'no remote but still store!'
    //   93: iconst_0
    //   94: anewarray java/lang/Object
    //   97: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   100: pop
    //   101: aload_0
    //   102: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   105: invokevirtual c : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   108: getfield d : Z
    //   111: ifne -> 243
    //   114: aload_0
    //   115: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   118: invokevirtual b : ()Z
    //   121: ifeq -> 243
    //   124: ldc 'crash report was closed by remote , will not upload to Bugly , print local for helpful!'
    //   126: iconst_0
    //   127: anewarray java/lang/Object
    //   130: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   133: pop
    //   134: invokestatic n : ()Ljava/lang/String;
    //   137: astore #8
    //   139: aload_0
    //   140: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   143: getfield d : Ljava/lang/String;
    //   146: astore #9
    //   148: new java/lang/StringBuilder
    //   151: astore #10
    //   153: aload #10
    //   155: invokespecial <init> : ()V
    //   158: ldc 'U3D'
    //   160: aload #8
    //   162: aload #9
    //   164: aload_1
    //   165: aload #10
    //   167: aload_2
    //   168: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   171: ldc '\\n'
    //   173: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   176: aload_3
    //   177: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   180: ldc '\\n'
    //   182: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   185: aload #4
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: invokevirtual toString : ()Ljava/lang/String;
    //   193: aconst_null
    //   194: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Thread;Ljava/lang/String;Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   197: ldc 'handle end'
    //   199: iconst_0
    //   200: anewarray java/lang/Object
    //   203: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   206: pop
    //   207: return
    //   208: astore #9
    //   210: aload #9
    //   212: invokevirtual printStackTrace : ()V
    //   215: goto -> 61
    //   218: astore_1
    //   219: aload_1
    //   220: invokestatic a : (Ljava/lang/Throwable;)Z
    //   223: ifne -> 230
    //   226: aload_1
    //   227: invokevirtual printStackTrace : ()V
    //   230: ldc 'handle end'
    //   232: iconst_0
    //   233: anewarray java/lang/Object
    //   236: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   239: pop
    //   240: goto -> 207
    //   243: new com/tencent/bugly/legu/crashreport/crash/CrashDetailBean
    //   246: astore #8
    //   248: aload #8
    //   250: invokespecial <init> : ()V
    //   253: aload #8
    //   255: invokestatic i : ()J
    //   258: putfield B : J
    //   261: aload #8
    //   263: invokestatic g : ()J
    //   266: putfield C : J
    //   269: aload #8
    //   271: invokestatic k : ()J
    //   274: putfield D : J
    //   277: aload #8
    //   279: aload_0
    //   280: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   283: invokevirtual o : ()J
    //   286: putfield E : J
    //   289: aload #8
    //   291: aload_0
    //   292: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   295: invokevirtual n : ()J
    //   298: putfield F : J
    //   301: aload #8
    //   303: aload_0
    //   304: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   307: invokevirtual p : ()J
    //   310: putfield G : J
    //   313: aload #8
    //   315: aload_0
    //   316: getfield a : Landroid/content/Context;
    //   319: getstatic com/tencent/bugly/legu/crashreport/crash/c.d : I
    //   322: aconst_null
    //   323: invokestatic a : (Landroid/content/Context;ILjava/lang/String;)Ljava/lang/String;
    //   326: putfield w : Ljava/lang/String;
    //   329: aload #8
    //   331: iconst_0
    //   332: invokestatic a : (Z)[B
    //   335: putfield x : [B
    //   338: aload #8
    //   340: iconst_4
    //   341: putfield b : I
    //   344: aload #8
    //   346: aload_0
    //   347: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   350: invokevirtual g : ()Ljava/lang/String;
    //   353: putfield e : Ljava/lang/String;
    //   356: aload #8
    //   358: aload_0
    //   359: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   362: getfield i : Ljava/lang/String;
    //   365: putfield f : Ljava/lang/String;
    //   368: aload #8
    //   370: aload_0
    //   371: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   374: invokevirtual t : ()Ljava/lang/String;
    //   377: putfield g : Ljava/lang/String;
    //   380: aload #8
    //   382: aload_0
    //   383: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   386: invokevirtual f : ()Ljava/lang/String;
    //   389: putfield m : Ljava/lang/String;
    //   392: new java/lang/StringBuilder
    //   395: astore #9
    //   397: aload #9
    //   399: invokespecial <init> : ()V
    //   402: aload #8
    //   404: aload #9
    //   406: aload_2
    //   407: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   410: invokevirtual toString : ()Ljava/lang/String;
    //   413: putfield n : Ljava/lang/String;
    //   416: new java/lang/StringBuilder
    //   419: astore #9
    //   421: aload #9
    //   423: invokespecial <init> : ()V
    //   426: aload #8
    //   428: aload #9
    //   430: aload_3
    //   431: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   434: invokevirtual toString : ()Ljava/lang/String;
    //   437: putfield o : Ljava/lang/String;
    //   440: ldc ''
    //   442: astore #10
    //   444: aload #10
    //   446: astore #9
    //   448: aload #4
    //   450: ifnull -> 487
    //   453: aload #4
    //   455: ldc '\\n'
    //   457: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   460: astore #11
    //   462: aload #10
    //   464: astore #9
    //   466: aload #11
    //   468: ifnull -> 487
    //   471: aload #10
    //   473: astore #9
    //   475: aload #11
    //   477: arraylength
    //   478: ifle -> 487
    //   481: aload #11
    //   483: iconst_0
    //   484: aaload
    //   485: astore #9
    //   487: aload #8
    //   489: aload #9
    //   491: putfield p : Ljava/lang/String;
    //   494: aload #8
    //   496: aload #4
    //   498: putfield q : Ljava/lang/String;
    //   501: aload #8
    //   503: invokestatic currentTimeMillis : ()J
    //   506: putfield r : J
    //   509: aload #8
    //   511: aload #8
    //   513: getfield q : Ljava/lang/String;
    //   516: invokevirtual getBytes : ()[B
    //   519: invokestatic b : ([B)Ljava/lang/String;
    //   522: putfield u : Ljava/lang/String;
    //   525: aload #8
    //   527: getstatic com/tencent/bugly/legu/crashreport/crash/c.e : I
    //   530: iconst_0
    //   531: invokestatic a : (IZ)Ljava/util/Map;
    //   534: putfield y : Ljava/util/Map;
    //   537: aload #8
    //   539: aload_0
    //   540: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   543: getfield d : Ljava/lang/String;
    //   546: putfield z : Ljava/lang/String;
    //   549: new java/lang/StringBuilder
    //   552: astore #9
    //   554: aload #9
    //   556: invokespecial <init> : ()V
    //   559: aload #8
    //   561: aload #9
    //   563: aload_1
    //   564: invokevirtual getName : ()Ljava/lang/String;
    //   567: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   570: ldc '('
    //   572: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   575: aload_1
    //   576: invokevirtual getId : ()J
    //   579: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   582: ldc ')'
    //   584: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   587: invokevirtual toString : ()Ljava/lang/String;
    //   590: putfield A : Ljava/lang/String;
    //   593: aload #8
    //   595: aload_0
    //   596: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   599: invokevirtual v : ()Ljava/lang/String;
    //   602: putfield H : Ljava/lang/String;
    //   605: aload #8
    //   607: aload_0
    //   608: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   611: invokevirtual s : ()Ljava/util/Map;
    //   614: putfield h : Ljava/util/Map;
    //   617: aload #8
    //   619: aload_0
    //   620: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   623: invokevirtual E : ()Ljava/util/Map;
    //   626: putfield i : Ljava/util/Map;
    //   629: aload #8
    //   631: aload_0
    //   632: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   635: getfield a : J
    //   638: putfield L : J
    //   641: aload #8
    //   643: aload_0
    //   644: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   647: getfield n : Z
    //   650: putfield M : Z
    //   653: aload #8
    //   655: aload_0
    //   656: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   659: invokevirtual B : ()I
    //   662: putfield O : I
    //   665: aload #8
    //   667: aload_0
    //   668: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   671: invokevirtual C : ()I
    //   674: putfield P : I
    //   677: aload #8
    //   679: aload_0
    //   680: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   683: invokevirtual w : ()Ljava/util/Map;
    //   686: putfield Q : Ljava/util/Map;
    //   689: aload #8
    //   691: aload_0
    //   692: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   695: invokevirtual A : ()Ljava/util/Map;
    //   698: putfield R : Ljava/util/Map;
    //   701: aload_0
    //   702: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   705: aload #8
    //   707: invokevirtual b : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   710: aload #8
    //   712: ifnonnull -> 739
    //   715: ldc_w 'pkg crash datas fail!'
    //   718: iconst_0
    //   719: anewarray java/lang/Object
    //   722: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   725: pop
    //   726: ldc 'handle end'
    //   728: iconst_0
    //   729: anewarray java/lang/Object
    //   732: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   735: pop
    //   736: goto -> 207
    //   739: invokestatic n : ()Ljava/lang/String;
    //   742: astore #11
    //   744: aload_0
    //   745: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   748: getfield d : Ljava/lang/String;
    //   751: astore #9
    //   753: new java/lang/StringBuilder
    //   756: astore #10
    //   758: aload #10
    //   760: invokespecial <init> : ()V
    //   763: ldc 'U3D'
    //   765: aload #11
    //   767: aload #9
    //   769: aload_1
    //   770: aload #10
    //   772: aload_2
    //   773: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   776: ldc '\\n'
    //   778: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   781: aload_3
    //   782: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   785: ldc '\\n'
    //   787: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   790: aload #4
    //   792: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   795: invokevirtual toString : ()Ljava/lang/String;
    //   798: aload #8
    //   800: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Thread;Ljava/lang/String;Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   803: aload_0
    //   804: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   807: aload #8
    //   809: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)Z
    //   812: ifne -> 828
    //   815: aload_0
    //   816: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   819: aload #8
    //   821: ldc2_w 5000
    //   824: iconst_1
    //   825: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;JZ)V
    //   828: ldc 'handle end'
    //   830: iconst_0
    //   831: anewarray java/lang/Object
    //   834: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   837: pop
    //   838: goto -> 207
    //   841: astore_1
    //   842: ldc 'handle end'
    //   844: iconst_0
    //   845: anewarray java/lang/Object
    //   848: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   851: pop
    //   852: aload_1
    //   853: athrow
    // Exception table:
    //   from	to	target	type
    //   10	38	218	java/lang/Throwable
    //   10	38	841	finally
    //   41	50	218	java/lang/Throwable
    //   41	50	841	finally
    //   55	61	208	java/lang/InterruptedException
    //   55	61	218	java/lang/Throwable
    //   55	61	841	finally
    //   81	101	218	java/lang/Throwable
    //   81	101	841	finally
    //   101	197	218	java/lang/Throwable
    //   101	197	841	finally
    //   210	215	218	java/lang/Throwable
    //   210	215	841	finally
    //   219	230	841	finally
    //   243	440	218	java/lang/Throwable
    //   243	440	841	finally
    //   453	462	218	java/lang/Throwable
    //   453	462	841	finally
    //   475	481	218	java/lang/Throwable
    //   475	481	841	finally
    //   487	710	218	java/lang/Throwable
    //   487	710	841	finally
    //   715	726	218	java/lang/Throwable
    //   715	726	841	finally
    //   739	828	218	java/lang/Throwable
    //   739	828	841	finally
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */