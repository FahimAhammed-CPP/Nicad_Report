package com.tencent.bugly.legu.proguard;

import android.content.Context;

public final class m {
  private static m a = null;
  
  private static long b = System.currentTimeMillis();
  
  private m(Context paramContext) {}
  
  public static m a() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/proguard/m
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/proguard/m.a : Lcom/tencent/bugly/legu/proguard/m;
    //   6: astore_0
    //   7: ldc com/tencent/bugly/legu/proguard/m
    //   9: monitorexit
    //   10: aload_0
    //   11: areturn
    //   12: astore_0
    //   13: ldc com/tencent/bugly/legu/proguard/m
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	12	finally
  }
  
  public static m a(Context paramContext) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/proguard/m
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/proguard/m.a : Lcom/tencent/bugly/legu/proguard/m;
    //   6: ifnonnull -> 22
    //   9: new com/tencent/bugly/legu/proguard/m
    //   12: astore_1
    //   13: aload_1
    //   14: aload_0
    //   15: invokespecial <init> : (Landroid/content/Context;)V
    //   18: aload_1
    //   19: putstatic com/tencent/bugly/legu/proguard/m.a : Lcom/tencent/bugly/legu/proguard/m;
    //   22: getstatic com/tencent/bugly/legu/proguard/m.a : Lcom/tencent/bugly/legu/proguard/m;
    //   25: astore_0
    //   26: ldc com/tencent/bugly/legu/proguard/m
    //   28: monitorexit
    //   29: aload_0
    //   30: areturn
    //   31: astore_0
    //   32: ldc com/tencent/bugly/legu/proguard/m
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   3	22	31	finally
    //   22	26	31	finally
  }
  
  private int b(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: iconst_1
    //   6: invokespecial d : (I)J
    //   9: lstore_3
    //   10: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   13: iload_1
    //   14: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   17: getfield d : Ljava/lang/String;
    //   20: lload_3
    //   21: invokevirtual a : (ILjava/lang/String;J)I
    //   24: istore_1
    //   25: aload_0
    //   26: monitorexit
    //   27: iload_1
    //   28: ireturn
    //   29: astore #5
    //   31: ldc 'clearHistoryCrashRecord failed'
    //   33: iconst_0
    //   34: anewarray java/lang/Object
    //   37: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   40: pop
    //   41: iload_2
    //   42: istore_1
    //   43: goto -> 25
    //   46: astore #5
    //   48: aload_0
    //   49: monitorexit
    //   50: aload #5
    //   52: athrow
    // Exception table:
    //   from	to	target	type
    //   4	25	29	java/lang/Exception
    //   4	25	46	finally
    //   31	41	46	finally
  }
  
  private boolean b(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   5: getfield d : Ljava/lang/String;
    //   8: astore_2
    //   9: aload_2
    //   10: ifnonnull -> 29
    //   13: ldc 'process name is null'
    //   15: iconst_0
    //   16: anewarray java/lang/Object
    //   19: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   22: pop
    //   23: iconst_0
    //   24: istore_3
    //   25: aload_0
    //   26: monitorexit
    //   27: iload_3
    //   28: ireturn
    //   29: aload_0
    //   30: iconst_0
    //   31: invokespecial d : (I)J
    //   34: lstore #4
    //   36: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   39: astore #6
    //   41: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   44: invokevirtual getClass : ()Ljava/lang/Class;
    //   47: pop
    //   48: aload #6
    //   50: iload_1
    //   51: aload_2
    //   52: lload #4
    //   54: ldc '2.1.9'
    //   56: invokevirtual a : (ILjava/lang/String;JLjava/lang/String;)Ljava/util/List;
    //   59: astore_2
    //   60: aload_2
    //   61: ifnonnull -> 69
    //   64: iconst_0
    //   65: istore_3
    //   66: goto -> 25
    //   69: aload_2
    //   70: invokeinterface size : ()I
    //   75: iconst_2
    //   76: if_icmpge -> 84
    //   79: iconst_0
    //   80: istore_3
    //   81: goto -> 25
    //   84: iconst_0
    //   85: istore_1
    //   86: iload_1
    //   87: iconst_1
    //   88: iadd
    //   89: aload_2
    //   90: invokeinterface size : ()I
    //   95: if_icmpge -> 153
    //   98: aload_2
    //   99: iload_1
    //   100: iconst_1
    //   101: iadd
    //   102: invokeinterface get : (I)Ljava/lang/Object;
    //   107: checkcast com/tencent/bugly/legu/proguard/l
    //   110: getfield c : J
    //   113: lstore #7
    //   115: aload_2
    //   116: iload_1
    //   117: invokeinterface get : (I)Ljava/lang/Object;
    //   122: checkcast com/tencent/bugly/legu/proguard/l
    //   125: getfield c : J
    //   128: lstore #4
    //   130: lload #7
    //   132: lload #4
    //   134: lsub
    //   135: ldc2_w 86400000
    //   138: lcmp
    //   139: ifge -> 147
    //   142: iconst_1
    //   143: istore_3
    //   144: goto -> 25
    //   147: iinc #1, 1
    //   150: goto -> 86
    //   153: iconst_0
    //   154: istore_3
    //   155: goto -> 25
    //   158: astore_2
    //   159: ldc 'FrenquencyCrash failed'
    //   161: iconst_0
    //   162: anewarray java/lang/Object
    //   165: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   168: pop
    //   169: iconst_0
    //   170: istore_3
    //   171: goto -> 25
    //   174: astore_2
    //   175: aload_0
    //   176: monitorexit
    //   177: aload_2
    //   178: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	158	java/lang/Exception
    //   2	9	174	finally
    //   13	23	158	java/lang/Exception
    //   13	23	174	finally
    //   29	60	158	java/lang/Exception
    //   29	60	174	finally
    //   69	79	158	java/lang/Exception
    //   69	79	174	finally
    //   86	130	158	java/lang/Exception
    //   86	130	174	finally
    //   159	169	174	finally
  }
  
  private l c(int paramInt) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   7: getfield d : Ljava/lang/String;
    //   10: astore_3
    //   11: aload_3
    //   12: ifnonnull -> 29
    //   15: ldc 'process name is null'
    //   17: iconst_0
    //   18: anewarray java/lang/Object
    //   21: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   24: pop
    //   25: aload_0
    //   26: monitorexit
    //   27: aload_2
    //   28: areturn
    //   29: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   32: iload_1
    //   33: aload_3
    //   34: invokevirtual a : (ILjava/lang/String;)Lcom/tencent/bugly/legu/proguard/l;
    //   37: astore_3
    //   38: aload_3
    //   39: astore_2
    //   40: goto -> 25
    //   43: astore_3
    //   44: ldc 'getLatestCrashRecord failed'
    //   46: iconst_0
    //   47: anewarray java/lang/Object
    //   50: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   53: pop
    //   54: goto -> 25
    //   57: astore_2
    //   58: aload_0
    //   59: monitorexit
    //   60: aload_2
    //   61: athrow
    // Exception table:
    //   from	to	target	type
    //   4	11	43	java/lang/Exception
    //   4	11	57	finally
    //   15	25	43	java/lang/Exception
    //   15	25	57	finally
    //   29	38	43	java/lang/Exception
    //   29	38	57	finally
    //   44	54	57	finally
  }
  
  private long d(int paramInt) {
    // Byte code:
    //   0: lconst_0
    //   1: lstore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: lload_2
    //   5: lstore #4
    //   7: iload_1
    //   8: tableswitch default -> 32, 0 -> 35, 1 -> 40
    //   32: lload_2
    //   33: lstore #4
    //   35: aload_0
    //   36: monitorexit
    //   37: lload #4
    //   39: lreturn
    //   40: invokestatic currentTimeMillis : ()J
    //   43: lstore #4
    //   45: lload #4
    //   47: ldc2_w 86400000
    //   50: lsub
    //   51: lstore #4
    //   53: goto -> 35
    //   56: astore #6
    //   58: aload_0
    //   59: monitorexit
    //   60: aload #6
    //   62: athrow
    // Exception table:
    //   from	to	target	type
    //   40	45	56	finally
  }
  
  public final boolean a(int paramInt) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: iconst_1
    //   3: istore_3
    //   4: aload_0
    //   5: monitorenter
    //   6: iload_2
    //   7: istore #4
    //   9: aload_0
    //   10: iload_1
    //   11: invokespecial c : (I)Lcom/tencent/bugly/legu/proguard/l;
    //   14: astore #5
    //   16: iload_3
    //   17: istore #6
    //   19: aload #5
    //   21: ifnull -> 60
    //   24: iload_3
    //   25: istore #6
    //   27: iload_2
    //   28: istore #4
    //   30: invokestatic currentTimeMillis : ()J
    //   33: aload #5
    //   35: getfield c : J
    //   38: lsub
    //   39: ldc2_w 86400000
    //   42: lcmp
    //   43: ifgt -> 60
    //   46: iload_2
    //   47: istore #4
    //   49: aload_0
    //   50: iload_1
    //   51: invokespecial b : (I)Z
    //   54: ifne -> 89
    //   57: iload_3
    //   58: istore #6
    //   60: iload #6
    //   62: istore #4
    //   64: iload #6
    //   66: ifeq -> 84
    //   69: iload #6
    //   71: istore #4
    //   73: aload_0
    //   74: iload_1
    //   75: iconst_1
    //   76: invokespecial b : (II)I
    //   79: pop
    //   80: iload #6
    //   82: istore #4
    //   84: aload_0
    //   85: monitorexit
    //   86: iload #4
    //   88: ireturn
    //   89: iconst_0
    //   90: istore #6
    //   92: goto -> 60
    //   95: astore #5
    //   97: ldc 'canInit failed'
    //   99: iconst_0
    //   100: anewarray java/lang/Object
    //   103: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   106: pop
    //   107: goto -> 84
    //   110: astore #5
    //   112: aload_0
    //   113: monitorexit
    //   114: aload #5
    //   116: athrow
    // Exception table:
    //   from	to	target	type
    //   9	16	95	java/lang/Exception
    //   9	16	110	finally
    //   30	46	95	java/lang/Exception
    //   30	46	110	finally
    //   49	57	95	java/lang/Exception
    //   49	57	110	finally
    //   73	80	95	java/lang/Exception
    //   73	80	110	finally
    //   97	107	110	finally
  }
  
  public final boolean a(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_0
    //   3: monitorenter
    //   4: new com/tencent/bugly/legu/proguard/l
    //   7: astore #4
    //   9: aload #4
    //   11: invokespecial <init> : ()V
    //   14: aload #4
    //   16: ldc2_w 1004
    //   19: putfield a : J
    //   22: aload #4
    //   24: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   27: getfield d : Ljava/lang/String;
    //   30: putfield b : Ljava/lang/String;
    //   33: aload #4
    //   35: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   38: getfield i : Ljava/lang/String;
    //   41: putfield f : Ljava/lang/String;
    //   44: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   47: invokevirtual getClass : ()Ljava/lang/Class;
    //   50: pop
    //   51: aload #4
    //   53: ldc '2.1.9'
    //   55: putfield e : Ljava/lang/String;
    //   58: aload #4
    //   60: iload_2
    //   61: putfield d : I
    //   64: aload #4
    //   66: invokestatic currentTimeMillis : ()J
    //   69: putfield c : J
    //   72: aload #4
    //   74: getstatic com/tencent/bugly/legu/proguard/m.b : J
    //   77: putfield g : J
    //   80: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   83: aload #4
    //   85: invokevirtual a : (Lcom/tencent/bugly/legu/proguard/l;)Z
    //   88: istore #5
    //   90: aload_0
    //   91: monitorexit
    //   92: iload #5
    //   94: ireturn
    //   95: astore #4
    //   97: ldc 'saveCrashRecord failed'
    //   99: iconst_0
    //   100: anewarray java/lang/Object
    //   103: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   106: pop
    //   107: iload_3
    //   108: istore #5
    //   110: goto -> 90
    //   113: astore #4
    //   115: aload_0
    //   116: monitorexit
    //   117: aload #4
    //   119: athrow
    // Exception table:
    //   from	to	target	type
    //   4	90	95	java/lang/Exception
    //   4	90	113	finally
    //   97	107	113	finally
  }
  
  public final int b() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   7: astore_2
    //   8: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   11: invokevirtual getClass : ()Ljava/lang/Class;
    //   14: pop
    //   15: aload_2
    //   16: invokevirtual b : ()I
    //   19: istore_3
    //   20: iload_3
    //   21: istore_1
    //   22: aload_0
    //   23: monitorexit
    //   24: iload_1
    //   25: ireturn
    //   26: astore_2
    //   27: ldc 'clearInvalidCrashRecord failed'
    //   29: iconst_0
    //   30: anewarray java/lang/Object
    //   33: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   36: pop
    //   37: goto -> 22
    //   40: astore_2
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_2
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   4	20	26	java/lang/Exception
    //   4	20	40	finally
    //   27	37	40	finally
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */