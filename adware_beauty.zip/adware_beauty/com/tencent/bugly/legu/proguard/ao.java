package com.tencent.bugly.legu.proguard;

public final class ao extends j implements Cloneable {
  public String a = "";
  
  private String b = "";
  
  public final void a(h paramh) {
    this.a = paramh.b(0, true);
    this.b = paramh.b(1, true);
  }
  
  public final void a(i parami) {
    parami.a(this.a, 0);
    parami.a(this.b, 1);
  }
  
  public final void a(StringBuilder paramStringBuilder, int paramInt) {}
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/ao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */