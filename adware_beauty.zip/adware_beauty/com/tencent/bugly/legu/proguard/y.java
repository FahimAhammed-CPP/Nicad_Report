package com.tencent.bugly.legu.proguard;

import android.content.Context;
import com.tencent.bugly.legu.BuglyStrategy;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.common.strategy.a;
import com.tencent.bugly.legu.crashreport.crash.b;

public final class y {
  private Context a;
  
  private b b;
  
  private a c;
  
  private a d;
  
  public y(Context paramContext, b paramb, a parama, a parama1, BuglyStrategy.a parama2) {
    this.a = paramContext;
    this.b = paramb;
    this.c = parama;
    this.d = parama1;
  }
  
  public final void a(Thread paramThread, int paramInt, String paramString1, String paramString2, String paramString3) {
    // Byte code:
    //   0: ldc 'Cocos2d-x Crash Happen'
    //   2: iconst_0
    //   3: anewarray java/lang/Object
    //   6: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   9: pop
    //   10: aload_0
    //   11: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   14: invokevirtual c : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   17: pop
    //   18: aload_0
    //   19: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   22: invokevirtual b : ()Z
    //   25: ifne -> 81
    //   28: ldc 'waiting for remote sync'
    //   30: iconst_0
    //   31: anewarray java/lang/Object
    //   34: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   37: pop
    //   38: iconst_0
    //   39: istore #6
    //   41: aload_0
    //   42: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   45: invokevirtual b : ()Z
    //   48: istore #7
    //   50: iload #7
    //   52: ifne -> 81
    //   55: ldc2_w 500
    //   58: invokestatic sleep : (J)V
    //   61: iload #6
    //   63: sipush #500
    //   66: iadd
    //   67: istore #8
    //   69: iload #8
    //   71: istore #6
    //   73: iload #8
    //   75: sipush #5000
    //   78: if_icmplt -> 41
    //   81: aload_0
    //   82: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   85: invokevirtual b : ()Z
    //   88: ifne -> 101
    //   91: ldc 'no remote but still store!'
    //   93: iconst_0
    //   94: anewarray java/lang/Object
    //   97: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   100: pop
    //   101: aload_0
    //   102: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   105: invokevirtual c : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   108: astore #9
    //   110: aload #9
    //   112: getfield d : Z
    //   115: ifne -> 248
    //   118: aload_0
    //   119: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   122: invokevirtual b : ()Z
    //   125: ifeq -> 248
    //   128: ldc 'crash report was closed by remote , will not upload to Bugly , print local for helpful!'
    //   130: iconst_0
    //   131: anewarray java/lang/Object
    //   134: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   137: pop
    //   138: invokestatic n : ()Ljava/lang/String;
    //   141: astore #10
    //   143: aload_0
    //   144: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   147: getfield d : Ljava/lang/String;
    //   150: astore #9
    //   152: new java/lang/StringBuilder
    //   155: astore #11
    //   157: aload #11
    //   159: invokespecial <init> : ()V
    //   162: ldc 'Cocos2dx'
    //   164: aload #10
    //   166: aload #9
    //   168: aload_1
    //   169: aload #11
    //   171: aload_3
    //   172: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   175: ldc '\\n'
    //   177: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   180: aload #4
    //   182: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   185: ldc '\\n'
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: aload #5
    //   192: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   195: invokevirtual toString : ()Ljava/lang/String;
    //   198: aconst_null
    //   199: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Thread;Ljava/lang/String;Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   202: ldc 'handle end'
    //   204: iconst_0
    //   205: anewarray java/lang/Object
    //   208: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   211: pop
    //   212: return
    //   213: astore #9
    //   215: aload #9
    //   217: invokevirtual printStackTrace : ()V
    //   220: goto -> 61
    //   223: astore_1
    //   224: aload_1
    //   225: invokestatic a : (Ljava/lang/Throwable;)Z
    //   228: ifne -> 235
    //   231: aload_1
    //   232: invokevirtual printStackTrace : ()V
    //   235: ldc 'handle end'
    //   237: iconst_0
    //   238: anewarray java/lang/Object
    //   241: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   244: pop
    //   245: goto -> 212
    //   248: aload #9
    //   250: getfield h : Z
    //   253: ifne -> 279
    //   256: ldc 'cocos report is disabled.'
    //   258: iconst_0
    //   259: anewarray java/lang/Object
    //   262: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   265: pop
    //   266: ldc 'handle end'
    //   268: iconst_0
    //   269: anewarray java/lang/Object
    //   272: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   275: pop
    //   276: goto -> 212
    //   279: new com/tencent/bugly/legu/crashreport/crash/CrashDetailBean
    //   282: astore #10
    //   284: aload #10
    //   286: invokespecial <init> : ()V
    //   289: aload #10
    //   291: invokestatic i : ()J
    //   294: putfield B : J
    //   297: aload #10
    //   299: invokestatic g : ()J
    //   302: putfield C : J
    //   305: aload #10
    //   307: invokestatic k : ()J
    //   310: putfield D : J
    //   313: aload #10
    //   315: aload_0
    //   316: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   319: invokevirtual o : ()J
    //   322: putfield E : J
    //   325: aload #10
    //   327: aload_0
    //   328: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   331: invokevirtual n : ()J
    //   334: putfield F : J
    //   337: aload #10
    //   339: aload_0
    //   340: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   343: invokevirtual p : ()J
    //   346: putfield G : J
    //   349: aload #10
    //   351: aload_0
    //   352: getfield a : Landroid/content/Context;
    //   355: getstatic com/tencent/bugly/legu/crashreport/crash/c.d : I
    //   358: aconst_null
    //   359: invokestatic a : (Landroid/content/Context;ILjava/lang/String;)Ljava/lang/String;
    //   362: putfield w : Ljava/lang/String;
    //   365: aload #10
    //   367: iconst_0
    //   368: invokestatic a : (Z)[B
    //   371: putfield x : [B
    //   374: aload #10
    //   376: iload_2
    //   377: putfield b : I
    //   380: aload #10
    //   382: aload_0
    //   383: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   386: invokevirtual g : ()Ljava/lang/String;
    //   389: putfield e : Ljava/lang/String;
    //   392: aload #10
    //   394: aload_0
    //   395: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   398: getfield i : Ljava/lang/String;
    //   401: putfield f : Ljava/lang/String;
    //   404: aload #10
    //   406: aload_0
    //   407: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   410: invokevirtual t : ()Ljava/lang/String;
    //   413: putfield g : Ljava/lang/String;
    //   416: aload #10
    //   418: aload_0
    //   419: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   422: invokevirtual f : ()Ljava/lang/String;
    //   425: putfield m : Ljava/lang/String;
    //   428: new java/lang/StringBuilder
    //   431: astore #9
    //   433: aload #9
    //   435: invokespecial <init> : ()V
    //   438: aload #10
    //   440: aload #9
    //   442: aload_3
    //   443: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   446: invokevirtual toString : ()Ljava/lang/String;
    //   449: putfield n : Ljava/lang/String;
    //   452: new java/lang/StringBuilder
    //   455: astore #9
    //   457: aload #9
    //   459: invokespecial <init> : ()V
    //   462: aload #10
    //   464: aload #9
    //   466: aload #4
    //   468: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   471: invokevirtual toString : ()Ljava/lang/String;
    //   474: putfield o : Ljava/lang/String;
    //   477: ldc ''
    //   479: astore #11
    //   481: aload #11
    //   483: astore #9
    //   485: aload #5
    //   487: ifnull -> 524
    //   490: aload #5
    //   492: ldc '\\n'
    //   494: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   497: astore #12
    //   499: aload #11
    //   501: astore #9
    //   503: aload #12
    //   505: ifnull -> 524
    //   508: aload #11
    //   510: astore #9
    //   512: aload #12
    //   514: arraylength
    //   515: ifle -> 524
    //   518: aload #12
    //   520: iconst_0
    //   521: aaload
    //   522: astore #9
    //   524: aload #10
    //   526: aload #9
    //   528: putfield p : Ljava/lang/String;
    //   531: aload #10
    //   533: aload #5
    //   535: putfield q : Ljava/lang/String;
    //   538: aload #10
    //   540: invokestatic currentTimeMillis : ()J
    //   543: putfield r : J
    //   546: aload #10
    //   548: aload #10
    //   550: getfield q : Ljava/lang/String;
    //   553: invokevirtual getBytes : ()[B
    //   556: invokestatic b : ([B)Ljava/lang/String;
    //   559: putfield u : Ljava/lang/String;
    //   562: aload #10
    //   564: getstatic com/tencent/bugly/legu/crashreport/crash/c.e : I
    //   567: iconst_0
    //   568: invokestatic a : (IZ)Ljava/util/Map;
    //   571: putfield y : Ljava/util/Map;
    //   574: aload #10
    //   576: aload_0
    //   577: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   580: getfield d : Ljava/lang/String;
    //   583: putfield z : Ljava/lang/String;
    //   586: new java/lang/StringBuilder
    //   589: astore #9
    //   591: aload #9
    //   593: invokespecial <init> : ()V
    //   596: aload #10
    //   598: aload #9
    //   600: aload_1
    //   601: invokevirtual getName : ()Ljava/lang/String;
    //   604: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   607: ldc '('
    //   609: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   612: aload_1
    //   613: invokevirtual getId : ()J
    //   616: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   619: ldc ')'
    //   621: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   624: invokevirtual toString : ()Ljava/lang/String;
    //   627: putfield A : Ljava/lang/String;
    //   630: aload #10
    //   632: aload_0
    //   633: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   636: invokevirtual v : ()Ljava/lang/String;
    //   639: putfield H : Ljava/lang/String;
    //   642: aload #10
    //   644: aload_0
    //   645: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   648: invokevirtual s : ()Ljava/util/Map;
    //   651: putfield h : Ljava/util/Map;
    //   654: aload #10
    //   656: aload_0
    //   657: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   660: invokevirtual E : ()Ljava/util/Map;
    //   663: putfield i : Ljava/util/Map;
    //   666: aload #10
    //   668: aload_0
    //   669: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   672: getfield a : J
    //   675: putfield L : J
    //   678: aload #10
    //   680: aload_0
    //   681: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   684: getfield n : Z
    //   687: putfield M : Z
    //   690: aload #10
    //   692: aload_0
    //   693: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   696: invokevirtual B : ()I
    //   699: putfield O : I
    //   702: aload #10
    //   704: aload_0
    //   705: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   708: invokevirtual C : ()I
    //   711: putfield P : I
    //   714: aload #10
    //   716: aload_0
    //   717: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   720: invokevirtual w : ()Ljava/util/Map;
    //   723: putfield Q : Ljava/util/Map;
    //   726: aload #10
    //   728: aload_0
    //   729: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   732: invokevirtual A : ()Ljava/util/Map;
    //   735: putfield R : Ljava/util/Map;
    //   738: aload_0
    //   739: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   742: aload #10
    //   744: invokevirtual b : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   747: aload #10
    //   749: ifnonnull -> 776
    //   752: ldc_w 'pkg crash datas fail!'
    //   755: iconst_0
    //   756: anewarray java/lang/Object
    //   759: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   762: pop
    //   763: ldc 'handle end'
    //   765: iconst_0
    //   766: anewarray java/lang/Object
    //   769: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   772: pop
    //   773: goto -> 212
    //   776: invokestatic n : ()Ljava/lang/String;
    //   779: astore #9
    //   781: aload_0
    //   782: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   785: getfield d : Ljava/lang/String;
    //   788: astore #11
    //   790: new java/lang/StringBuilder
    //   793: astore #12
    //   795: aload #12
    //   797: invokespecial <init> : ()V
    //   800: ldc 'Cocos2dx'
    //   802: aload #9
    //   804: aload #11
    //   806: aload_1
    //   807: aload #12
    //   809: aload_3
    //   810: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   813: ldc '\\n'
    //   815: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   818: aload #4
    //   820: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   823: ldc '\\n'
    //   825: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   828: aload #5
    //   830: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   833: invokevirtual toString : ()Ljava/lang/String;
    //   836: aload #10
    //   838: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Thread;Ljava/lang/String;Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   841: aload_0
    //   842: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   845: aload #10
    //   847: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)Z
    //   850: ifne -> 866
    //   853: aload_0
    //   854: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   857: aload #10
    //   859: ldc2_w 5000
    //   862: iconst_0
    //   863: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;JZ)V
    //   866: ldc 'handle end'
    //   868: iconst_0
    //   869: anewarray java/lang/Object
    //   872: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   875: pop
    //   876: goto -> 212
    //   879: astore_1
    //   880: ldc 'handle end'
    //   882: iconst_0
    //   883: anewarray java/lang/Object
    //   886: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   889: pop
    //   890: aload_1
    //   891: athrow
    // Exception table:
    //   from	to	target	type
    //   10	38	223	java/lang/Throwable
    //   10	38	879	finally
    //   41	50	223	java/lang/Throwable
    //   41	50	879	finally
    //   55	61	213	java/lang/InterruptedException
    //   55	61	223	java/lang/Throwable
    //   55	61	879	finally
    //   81	101	223	java/lang/Throwable
    //   81	101	879	finally
    //   101	202	223	java/lang/Throwable
    //   101	202	879	finally
    //   215	220	223	java/lang/Throwable
    //   215	220	879	finally
    //   224	235	879	finally
    //   248	266	223	java/lang/Throwable
    //   248	266	879	finally
    //   279	477	223	java/lang/Throwable
    //   279	477	879	finally
    //   490	499	223	java/lang/Throwable
    //   490	499	879	finally
    //   512	518	223	java/lang/Throwable
    //   512	518	879	finally
    //   524	747	223	java/lang/Throwable
    //   524	747	879	finally
    //   752	763	223	java/lang/Throwable
    //   752	763	879	finally
    //   776	866	223	java/lang/Throwable
    //   776	866	879	finally
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */