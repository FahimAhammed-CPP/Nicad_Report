package com.tencent.bugly.legu.proguard;

public final class aj extends j implements Cloneable {
  private static byte[] d;
  
  private byte a = (byte)0;
  
  private String b = "";
  
  private byte[] c = null;
  
  public aj() {}
  
  public aj(byte paramByte, String paramString, byte[] paramArrayOfbyte) {
    this.a = (byte)paramByte;
    this.b = paramString;
    this.c = paramArrayOfbyte;
  }
  
  public final void a(h paramh) {
    this.a = paramh.a(this.a, 0, true);
    this.b = paramh.b(1, true);
    if (d == null) {
      byte[] arrayOfByte1 = new byte[1];
      d = arrayOfByte1;
      arrayOfByte1[0] = (byte)0;
    } 
    byte[] arrayOfByte = d;
    this.c = paramh.c(2, false);
  }
  
  public final void a(i parami) {
    parami.a(this.a, 0);
    parami.a(this.b, 1);
    if (this.c != null)
      parami.a(this.c, 2); 
  }
  
  public final void a(StringBuilder paramStringBuilder, int paramInt) {}
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/aj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */