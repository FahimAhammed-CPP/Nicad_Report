package com.tencent.bugly.legu.proguard;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;

public final class x {
  public static boolean a;
  
  private static SimpleDateFormat b = null;
  
  private static int c;
  
  private static StringBuilder d;
  
  private static StringBuilder e;
  
  private static a f;
  
  private static String g;
  
  private static String h;
  
  private static Context i;
  
  private static String j;
  
  private static boolean k;
  
  private static int l;
  
  private static Object m;
  
  private static Object n;
  
  private static Method o;
  
  static {
    a = true;
    c = 5120;
    m = new Object();
    n = null;
    o = null;
    try {
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
      this("MM-dd HH:mm:ss");
      b = simpleDateFormat;
      o = Class.forName("com.tencent.bugly.crashreport.crash.jni.NativeCrashHandler").getDeclaredMethod("appendLogToNative", new Class[] { String.class, String.class, String.class });
    } catch (Throwable throwable) {}
  }
  
  public static void a(int paramInt) {
    synchronized (m) {
      c = paramInt;
      if (paramInt < 0) {
        c = 0;
      } else if (paramInt > 10240) {
        c = 10240;
      } 
      return;
    } 
  }
  
  public static void a(Context paramContext) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/proguard/x
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/proguard/x.k : Z
    //   6: ifne -> 21
    //   9: aload_0
    //   10: ifnull -> 21
    //   13: getstatic com/tencent/bugly/legu/proguard/x.a : Z
    //   16: istore_1
    //   17: iload_1
    //   18: ifne -> 25
    //   21: ldc com/tencent/bugly/legu/proguard/x
    //   23: monitorexit
    //   24: return
    //   25: new java/lang/StringBuilder
    //   28: astore_2
    //   29: aload_2
    //   30: iconst_0
    //   31: invokespecial <init> : (I)V
    //   34: aload_2
    //   35: putstatic com/tencent/bugly/legu/proguard/x.e : Ljava/lang/StringBuilder;
    //   38: new java/lang/StringBuilder
    //   41: astore_2
    //   42: aload_2
    //   43: iconst_0
    //   44: invokespecial <init> : (I)V
    //   47: aload_2
    //   48: putstatic com/tencent/bugly/legu/proguard/x.d : Ljava/lang/StringBuilder;
    //   51: aload_0
    //   52: putstatic com/tencent/bugly/legu/proguard/x.i : Landroid/content/Context;
    //   55: aload_0
    //   56: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   59: astore_0
    //   60: aload_0
    //   61: getfield d : Ljava/lang/String;
    //   64: putstatic com/tencent/bugly/legu/proguard/x.g : Ljava/lang/String;
    //   67: aload_0
    //   68: invokevirtual getClass : ()Ljava/lang/Class;
    //   71: pop
    //   72: ldc 'legu'
    //   74: putstatic com/tencent/bugly/legu/proguard/x.h : Ljava/lang/String;
    //   77: new java/lang/StringBuilder
    //   80: astore_0
    //   81: aload_0
    //   82: invokespecial <init> : ()V
    //   85: aload_0
    //   86: getstatic com/tencent/bugly/legu/proguard/x.i : Landroid/content/Context;
    //   89: invokevirtual getFilesDir : ()Ljava/io/File;
    //   92: invokevirtual getPath : ()Ljava/lang/String;
    //   95: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   98: ldc '/buglylog_'
    //   100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: getstatic com/tencent/bugly/legu/proguard/x.g : Ljava/lang/String;
    //   106: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: ldc '_'
    //   111: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   114: getstatic com/tencent/bugly/legu/proguard/x.h : Ljava/lang/String;
    //   117: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   120: ldc '.txt'
    //   122: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   125: invokevirtual toString : ()Ljava/lang/String;
    //   128: putstatic com/tencent/bugly/legu/proguard/x.j : Ljava/lang/String;
    //   131: invokestatic myPid : ()I
    //   134: putstatic com/tencent/bugly/legu/proguard/x.l : I
    //   137: iconst_1
    //   138: putstatic com/tencent/bugly/legu/proguard/x.k : Z
    //   141: goto -> 21
    //   144: astore_0
    //   145: ldc com/tencent/bugly/legu/proguard/x
    //   147: monitorexit
    //   148: aload_0
    //   149: athrow
    //   150: astore_0
    //   151: goto -> 137
    // Exception table:
    //   from	to	target	type
    //   3	9	144	finally
    //   13	17	144	finally
    //   25	137	150	java/lang/Throwable
    //   25	137	144	finally
    //   137	141	144	finally
  }
  
  public static void a(String paramString1, String paramString2, String paramString3) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/proguard/x
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/proguard/x.k : Z
    //   6: ifeq -> 17
    //   9: getstatic com/tencent/bugly/legu/proguard/x.a : Z
    //   12: istore_3
    //   13: iload_3
    //   14: ifne -> 21
    //   17: ldc com/tencent/bugly/legu/proguard/x
    //   19: monitorexit
    //   20: return
    //   21: aload_0
    //   22: aload_1
    //   23: aload_2
    //   24: invokestatic b : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    //   27: pop
    //   28: invokestatic myTid : ()I
    //   31: istore #4
    //   33: getstatic com/tencent/bugly/legu/proguard/x.d : Ljava/lang/StringBuilder;
    //   36: iconst_0
    //   37: invokevirtual setLength : (I)V
    //   40: aload_2
    //   41: astore #5
    //   43: aload_2
    //   44: invokevirtual length : ()I
    //   47: sipush #30720
    //   50: if_icmple -> 73
    //   53: aload_2
    //   54: aload_2
    //   55: invokevirtual length : ()I
    //   58: sipush #30720
    //   61: isub
    //   62: aload_2
    //   63: invokevirtual length : ()I
    //   66: iconst_1
    //   67: isub
    //   68: invokevirtual substring : (II)Ljava/lang/String;
    //   71: astore #5
    //   73: new java/util/Date
    //   76: astore_2
    //   77: aload_2
    //   78: invokespecial <init> : ()V
    //   81: getstatic com/tencent/bugly/legu/proguard/x.b : Ljava/text/SimpleDateFormat;
    //   84: ifnull -> 220
    //   87: getstatic com/tencent/bugly/legu/proguard/x.b : Ljava/text/SimpleDateFormat;
    //   90: aload_2
    //   91: invokevirtual format : (Ljava/util/Date;)Ljava/lang/String;
    //   94: astore_2
    //   95: getstatic com/tencent/bugly/legu/proguard/x.d : Ljava/lang/StringBuilder;
    //   98: aload_2
    //   99: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   102: ldc ' '
    //   104: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   107: getstatic com/tencent/bugly/legu/proguard/x.l : I
    //   110: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   113: ldc ' '
    //   115: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   118: iload #4
    //   120: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   123: ldc ' '
    //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: aload_0
    //   129: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   132: ldc ' '
    //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   137: aload_1
    //   138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   141: ldc ': '
    //   143: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: aload #5
    //   148: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: ldc '\\r\\n'
    //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: pop
    //   157: getstatic com/tencent/bugly/legu/proguard/x.d : Ljava/lang/StringBuilder;
    //   160: invokevirtual toString : ()Ljava/lang/String;
    //   163: astore_0
    //   164: getstatic com/tencent/bugly/legu/proguard/x.m : Ljava/lang/Object;
    //   167: astore_1
    //   168: aload_1
    //   169: monitorenter
    //   170: getstatic com/tencent/bugly/legu/proguard/x.e : Ljava/lang/StringBuilder;
    //   173: aload_0
    //   174: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   177: pop
    //   178: aload_1
    //   179: monitorexit
    //   180: getstatic com/tencent/bugly/legu/proguard/x.e : Ljava/lang/StringBuilder;
    //   183: invokevirtual length : ()I
    //   186: getstatic com/tencent/bugly/legu/proguard/x.c : I
    //   189: if_icmple -> 17
    //   192: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/v;
    //   195: astore_1
    //   196: new com/tencent/bugly/legu/proguard/x$1
    //   199: astore_2
    //   200: aload_2
    //   201: aload_0
    //   202: invokespecial <init> : (Ljava/lang/String;)V
    //   205: aload_1
    //   206: aload_2
    //   207: invokevirtual a : (Ljava/lang/Runnable;)Z
    //   210: pop
    //   211: goto -> 17
    //   214: astore_0
    //   215: ldc com/tencent/bugly/legu/proguard/x
    //   217: monitorexit
    //   218: aload_0
    //   219: athrow
    //   220: aload_2
    //   221: invokevirtual toString : ()Ljava/lang/String;
    //   224: astore_2
    //   225: goto -> 95
    //   228: astore_0
    //   229: aload_1
    //   230: monitorexit
    //   231: aload_0
    //   232: athrow
    // Exception table:
    //   from	to	target	type
    //   3	13	214	finally
    //   21	40	214	finally
    //   43	73	214	finally
    //   73	95	214	finally
    //   95	170	214	finally
    //   170	180	228	finally
    //   180	211	214	finally
    //   220	225	214	finally
    //   229	233	214	finally
  }
  
  public static void a(String paramString1, String paramString2, Throwable paramThrowable) {
    if (paramThrowable != null) {
      String str1;
      String str2 = paramThrowable.getMessage();
      String str3 = str2;
      if (str2 == null)
        str3 = ""; 
      StringBuilder stringBuilder = (new StringBuilder()).append(str3).append('\n');
      if (paramThrowable == null) {
        str1 = "";
      } else {
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        str1.printStackTrace(printWriter);
        printWriter.flush();
        str1 = stringWriter.toString();
      } 
      a(paramString1, paramString2, stringBuilder.append(str1).toString());
    } 
  }
  
  public static byte[] a(boolean paramBoolean) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: getstatic com/tencent/bugly/legu/proguard/x.a : Z
    //   5: ifne -> 12
    //   8: aload_1
    //   9: astore_2
    //   10: aload_2
    //   11: areturn
    //   12: getstatic com/tencent/bugly/legu/proguard/x.m : Ljava/lang/Object;
    //   15: astore_3
    //   16: aload_3
    //   17: monitorenter
    //   18: iload_0
    //   19: ifeq -> 73
    //   22: getstatic com/tencent/bugly/legu/proguard/x.f : Lcom/tencent/bugly/legu/proguard/x$a;
    //   25: ifnull -> 73
    //   28: getstatic com/tencent/bugly/legu/proguard/x.f : Lcom/tencent/bugly/legu/proguard/x$a;
    //   31: invokestatic d : (Lcom/tencent/bugly/legu/proguard/x$a;)Z
    //   34: ifeq -> 73
    //   37: getstatic com/tencent/bugly/legu/proguard/x.f : Lcom/tencent/bugly/legu/proguard/x$a;
    //   40: invokestatic a : (Lcom/tencent/bugly/legu/proguard/x$a;)Ljava/io/File;
    //   43: astore_2
    //   44: getstatic com/tencent/bugly/legu/proguard/x.e : Ljava/lang/StringBuilder;
    //   47: invokevirtual length : ()I
    //   50: istore #4
    //   52: iload #4
    //   54: ifne -> 78
    //   57: aload_2
    //   58: ifnonnull -> 78
    //   61: aload_3
    //   62: monitorexit
    //   63: aload_1
    //   64: astore_2
    //   65: goto -> 10
    //   68: astore_2
    //   69: aload_3
    //   70: monitorexit
    //   71: aload_2
    //   72: athrow
    //   73: aconst_null
    //   74: astore_2
    //   75: goto -> 44
    //   78: aload_2
    //   79: getstatic com/tencent/bugly/legu/proguard/x.e : Ljava/lang/StringBuilder;
    //   82: invokevirtual toString : ()Ljava/lang/String;
    //   85: invokestatic a : (Ljava/io/File;Ljava/lang/String;)[B
    //   88: astore_2
    //   89: aload_3
    //   90: monitorexit
    //   91: goto -> 10
    //   94: astore_2
    //   95: aload_3
    //   96: monitorexit
    //   97: aload_1
    //   98: astore_2
    //   99: goto -> 10
    // Exception table:
    //   from	to	target	type
    //   22	44	94	java/lang/Throwable
    //   22	44	68	finally
    //   44	52	94	java/lang/Throwable
    //   44	52	68	finally
    //   61	63	68	finally
    //   78	89	94	java/lang/Throwable
    //   78	89	68	finally
    //   89	91	68	finally
  }
  
  private static boolean b(String paramString1, String paramString2, String paramString3) {
    boolean bool;
    if (o == null)
      return false; 
    if (n == null) {
      Object object = a.a("com.tencent.bugly.crashreport.crash.jni.NativeCrashHandler", "getInstance", null, null, null);
      n = object;
      if (object == null)
        return false; 
    } 
    try {
      bool = ((Boolean)o.invoke(n, new Object[] { paramString1, paramString2, paramString3 })).booleanValue();
    } catch (Throwable throwable) {
      Log.w(w.a, throwable.getMessage());
      bool = false;
    } 
    return bool;
  }
  
  public static final class a {
    private boolean a;
    
    private File b;
    
    private String c;
    
    private long d;
    
    private long e = 30720L;
    
    public a(String param1String) {
      if (param1String != null && !param1String.equals("")) {
        this.c = param1String;
        this.a = a();
      } 
    }
    
    private boolean a() {
      // Byte code:
      //   0: iconst_0
      //   1: istore_1
      //   2: aload_0
      //   3: monitorenter
      //   4: new java/io/File
      //   7: astore_2
      //   8: aload_2
      //   9: aload_0
      //   10: getfield c : Ljava/lang/String;
      //   13: invokespecial <init> : (Ljava/lang/String;)V
      //   16: aload_0
      //   17: aload_2
      //   18: putfield b : Ljava/io/File;
      //   21: aload_0
      //   22: getfield b : Ljava/io/File;
      //   25: invokevirtual exists : ()Z
      //   28: ifeq -> 50
      //   31: aload_0
      //   32: getfield b : Ljava/io/File;
      //   35: invokevirtual delete : ()Z
      //   38: ifne -> 50
      //   41: aload_0
      //   42: iconst_0
      //   43: putfield a : Z
      //   46: aload_0
      //   47: monitorexit
      //   48: iload_1
      //   49: ireturn
      //   50: aload_0
      //   51: getfield b : Ljava/io/File;
      //   54: invokevirtual createNewFile : ()Z
      //   57: ifne -> 74
      //   60: aload_0
      //   61: iconst_0
      //   62: putfield a : Z
      //   65: goto -> 46
      //   68: astore_2
      //   69: aload_0
      //   70: iconst_0
      //   71: putfield a : Z
      //   74: iconst_1
      //   75: istore_1
      //   76: goto -> 46
      //   79: astore_2
      //   80: aload_0
      //   81: monitorexit
      //   82: aload_2
      //   83: athrow
      // Exception table:
      //   from	to	target	type
      //   4	46	68	java/lang/Throwable
      //   4	46	79	finally
      //   50	65	68	java/lang/Throwable
      //   50	65	79	finally
      //   69	74	79	finally
    }
    
    public final boolean a(String param1String) {
      // Byte code:
      //   0: iconst_0
      //   1: istore_2
      //   2: aload_0
      //   3: monitorenter
      //   4: aload_0
      //   5: getfield a : Z
      //   8: istore_3
      //   9: iload_3
      //   10: ifne -> 17
      //   13: aload_0
      //   14: monitorexit
      //   15: iload_2
      //   16: ireturn
      //   17: new java/io/FileOutputStream
      //   20: astore #4
      //   22: aload #4
      //   24: aload_0
      //   25: getfield b : Ljava/io/File;
      //   28: iconst_1
      //   29: invokespecial <init> : (Ljava/io/File;Z)V
      //   32: aload_1
      //   33: ldc 'UTF-8'
      //   35: invokevirtual getBytes : (Ljava/lang/String;)[B
      //   38: astore_1
      //   39: aload #4
      //   41: aload_1
      //   42: invokevirtual write : ([B)V
      //   45: aload #4
      //   47: invokevirtual flush : ()V
      //   50: aload #4
      //   52: invokevirtual close : ()V
      //   55: aload_0
      //   56: getfield d : J
      //   59: lstore #5
      //   61: aload_0
      //   62: aload_1
      //   63: arraylength
      //   64: i2l
      //   65: lload #5
      //   67: ladd
      //   68: putfield d : J
      //   71: iconst_1
      //   72: istore_2
      //   73: goto -> 13
      //   76: astore_1
      //   77: aload_0
      //   78: iconst_0
      //   79: putfield a : Z
      //   82: goto -> 13
      //   85: astore_1
      //   86: aload_0
      //   87: monitorexit
      //   88: aload_1
      //   89: athrow
      // Exception table:
      //   from	to	target	type
      //   4	9	85	finally
      //   17	71	76	java/lang/Throwable
      //   17	71	85	finally
      //   77	82	85	finally
    }
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */