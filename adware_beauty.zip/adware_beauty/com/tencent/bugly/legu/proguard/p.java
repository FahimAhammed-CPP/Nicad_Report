package com.tencent.bugly.legu.proguard;

import android.annotation.TargetApi;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.tencent.bugly.legu.a;
import java.util.List;

public final class p extends SQLiteOpenHelper {
  private static int a = 11;
  
  private Context b;
  
  private List<a> c;
  
  public p(Context paramContext, List<a> paramList) {
    super(paramContext, stringBuilder.append("legu").toString(), null, a);
    this.b = paramContext;
    this.c = paramList;
  }
  
  private boolean a(SQLiteDatabase paramSQLiteDatabase) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: iconst_4
    //   5: anewarray java/lang/String
    //   8: astore_3
    //   9: aload_3
    //   10: iconst_0
    //   11: ldc 't_crd'
    //   13: aastore
    //   14: aload_3
    //   15: iconst_1
    //   16: ldc 't_lr'
    //   18: aastore
    //   19: aload_3
    //   20: iconst_2
    //   21: ldc 't_ui'
    //   23: aastore
    //   24: aload_3
    //   25: iconst_3
    //   26: ldc 't_pf'
    //   28: aastore
    //   29: aload_3
    //   30: arraylength
    //   31: istore #4
    //   33: iconst_0
    //   34: istore #5
    //   36: iload_2
    //   37: istore #6
    //   39: iload #5
    //   41: iload #4
    //   43: if_icmpge -> 99
    //   46: aload_3
    //   47: iload #5
    //   49: aaload
    //   50: astore #7
    //   52: new java/lang/StringBuilder
    //   55: astore #8
    //   57: aload #8
    //   59: ldc 'DROP TABLE IF EXISTS '
    //   61: invokespecial <init> : (Ljava/lang/String;)V
    //   64: aload_1
    //   65: aload #8
    //   67: aload #7
    //   69: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: invokevirtual toString : ()Ljava/lang/String;
    //   75: invokevirtual execSQL : (Ljava/lang/String;)V
    //   78: iinc #5, 1
    //   81: goto -> 36
    //   84: astore_1
    //   85: aload_1
    //   86: invokestatic b : (Ljava/lang/Throwable;)Z
    //   89: ifne -> 96
    //   92: aload_1
    //   93: invokevirtual printStackTrace : ()V
    //   96: iconst_0
    //   97: istore #6
    //   99: aload_0
    //   100: monitorexit
    //   101: iload #6
    //   103: ireturn
    //   104: astore_1
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_1
    //   108: athrow
    // Exception table:
    //   from	to	target	type
    //   4	9	84	java/lang/Throwable
    //   4	9	104	finally
    //   29	33	84	java/lang/Throwable
    //   29	33	104	finally
    //   52	78	84	java/lang/Throwable
    //   52	78	104	finally
    //   85	96	104	finally
  }
  
  public final SQLiteDatabase getReadableDatabase() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aconst_null
    //   5: astore_2
    //   6: aload_2
    //   7: ifnonnull -> 83
    //   10: iload_1
    //   11: iconst_5
    //   12: if_icmpge -> 83
    //   15: iinc #1, 1
    //   18: aload_0
    //   19: invokespecial getReadableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   22: astore_3
    //   23: aload_3
    //   24: astore_2
    //   25: goto -> 6
    //   28: astore_3
    //   29: ldc 'try db count %d'
    //   31: iconst_1
    //   32: anewarray java/lang/Object
    //   35: dup
    //   36: iconst_0
    //   37: iload_1
    //   38: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   41: aastore
    //   42: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   45: pop
    //   46: iload_1
    //   47: iconst_5
    //   48: if_icmpne -> 61
    //   51: ldc 'get db fail!'
    //   53: iconst_0
    //   54: anewarray java/lang/Object
    //   57: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   60: pop
    //   61: ldc2_w 200
    //   64: invokestatic sleep : (J)V
    //   67: goto -> 6
    //   70: astore_3
    //   71: aload_3
    //   72: invokevirtual printStackTrace : ()V
    //   75: goto -> 6
    //   78: astore_2
    //   79: aload_0
    //   80: monitorexit
    //   81: aload_2
    //   82: athrow
    //   83: aload_0
    //   84: monitorexit
    //   85: aload_2
    //   86: areturn
    // Exception table:
    //   from	to	target	type
    //   18	23	28	java/lang/Throwable
    //   18	23	78	finally
    //   29	46	78	finally
    //   51	61	78	finally
    //   61	67	70	java/lang/InterruptedException
    //   61	67	78	finally
    //   71	75	78	finally
  }
  
  public final SQLiteDatabase getWritableDatabase() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aconst_null
    //   5: astore_2
    //   6: aload_2
    //   7: ifnonnull -> 83
    //   10: iload_1
    //   11: iconst_5
    //   12: if_icmpge -> 83
    //   15: iinc #1, 1
    //   18: aload_0
    //   19: invokespecial getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   22: astore_3
    //   23: aload_3
    //   24: astore_2
    //   25: goto -> 6
    //   28: astore_3
    //   29: ldc 'try db %d'
    //   31: iconst_1
    //   32: anewarray java/lang/Object
    //   35: dup
    //   36: iconst_0
    //   37: iload_1
    //   38: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   41: aastore
    //   42: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   45: pop
    //   46: iload_1
    //   47: iconst_5
    //   48: if_icmpne -> 61
    //   51: ldc 'get db fail!'
    //   53: iconst_0
    //   54: anewarray java/lang/Object
    //   57: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   60: pop
    //   61: ldc2_w 200
    //   64: invokestatic sleep : (J)V
    //   67: goto -> 6
    //   70: astore_3
    //   71: aload_3
    //   72: invokevirtual printStackTrace : ()V
    //   75: goto -> 6
    //   78: astore_2
    //   79: aload_0
    //   80: monitorexit
    //   81: aload_2
    //   82: athrow
    //   83: aload_2
    //   84: ifnonnull -> 97
    //   87: ldc 'db error delay error record 1min'
    //   89: iconst_0
    //   90: anewarray java/lang/Object
    //   93: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   96: pop
    //   97: aload_0
    //   98: monitorexit
    //   99: aload_2
    //   100: areturn
    // Exception table:
    //   from	to	target	type
    //   18	23	28	java/lang/Throwable
    //   18	23	78	finally
    //   29	46	78	finally
    //   51	61	78	finally
    //   61	67	70	java/lang/InterruptedException
    //   61	67	78	finally
    //   71	75	78	finally
    //   87	97	78	finally
  }
  
  public final void onCreate(SQLiteDatabase paramSQLiteDatabase) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/lang/StringBuilder
    //   5: astore_2
    //   6: aload_2
    //   7: invokespecial <init> : ()V
    //   10: aload_2
    //   11: iconst_0
    //   12: invokevirtual setLength : (I)V
    //   15: aload_2
    //   16: ldc ' CREATE TABLE IF NOT EXISTS t_ui'
    //   18: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   21: ldc ' ( _id'
    //   23: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   26: ldc ' INTEGER PRIMARY KEY'
    //   28: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   31: ldc ' , _tm'
    //   33: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   36: ldc ' int'
    //   38: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: ldc ' , _ut'
    //   43: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   46: ldc ' int'
    //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: ldc ' , _tp'
    //   53: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: ldc ' int'
    //   58: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: ldc ' , _dt'
    //   63: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: ldc ' blob'
    //   68: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   71: ldc ' , _pc'
    //   73: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   76: ldc ' text'
    //   78: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   81: ldc ' ) '
    //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: pop
    //   87: ldc 'create %s'
    //   89: iconst_1
    //   90: anewarray java/lang/Object
    //   93: dup
    //   94: iconst_0
    //   95: aload_2
    //   96: invokevirtual toString : ()Ljava/lang/String;
    //   99: aastore
    //   100: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   103: pop
    //   104: aload_1
    //   105: aload_2
    //   106: invokevirtual toString : ()Ljava/lang/String;
    //   109: invokevirtual execSQL : (Ljava/lang/String;)V
    //   112: aload_2
    //   113: iconst_0
    //   114: invokevirtual setLength : (I)V
    //   117: aload_2
    //   118: ldc ' CREATE TABLE IF NOT EXISTS t_lr'
    //   120: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   123: ldc ' ( _id'
    //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: ldc ' INTEGER PRIMARY KEY'
    //   130: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   133: ldc ' , _tp'
    //   135: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   138: ldc ' int'
    //   140: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   143: ldc ' , _tm'
    //   145: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: ldc ' int'
    //   150: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   153: ldc ' , _pc'
    //   155: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: ldc ' text'
    //   160: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   163: ldc ' , _th'
    //   165: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   168: ldc ' text'
    //   170: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   173: ldc ' , _dt'
    //   175: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   178: ldc ' blob'
    //   180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: ldc ' ) '
    //   185: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   188: pop
    //   189: ldc 'create %s'
    //   191: iconst_1
    //   192: anewarray java/lang/Object
    //   195: dup
    //   196: iconst_0
    //   197: aload_2
    //   198: invokevirtual toString : ()Ljava/lang/String;
    //   201: aastore
    //   202: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   205: pop
    //   206: aload_1
    //   207: aload_2
    //   208: invokevirtual toString : ()Ljava/lang/String;
    //   211: invokevirtual execSQL : (Ljava/lang/String;)V
    //   214: aload_2
    //   215: iconst_0
    //   216: invokevirtual setLength : (I)V
    //   219: aload_2
    //   220: ldc ' CREATE TABLE IF NOT EXISTS t_pf'
    //   222: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: ldc ' ( _id'
    //   227: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   230: ldc ' integer'
    //   232: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   235: ldc ' , _tp'
    //   237: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   240: ldc ' text'
    //   242: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   245: ldc ' , _tm'
    //   247: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   250: ldc ' int'
    //   252: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   255: ldc ' , _dt'
    //   257: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   260: ldc ' blob'
    //   262: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   265: ldc ',primary key(_id'
    //   267: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   270: ldc ',_tp'
    //   272: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   275: ldc ' )) '
    //   277: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   280: pop
    //   281: ldc 'create %s'
    //   283: iconst_1
    //   284: anewarray java/lang/Object
    //   287: dup
    //   288: iconst_0
    //   289: aload_2
    //   290: invokevirtual toString : ()Ljava/lang/String;
    //   293: aastore
    //   294: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   297: pop
    //   298: aload_1
    //   299: aload_2
    //   300: invokevirtual toString : ()Ljava/lang/String;
    //   303: invokevirtual execSQL : (Ljava/lang/String;)V
    //   306: aload_2
    //   307: iconst_0
    //   308: invokevirtual setLength : (I)V
    //   311: aload_2
    //   312: ldc ' CREATE TABLE IF NOT EXISTS t_crd'
    //   314: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   317: ldc ' ( _id'
    //   319: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   322: ldc ' integer'
    //   324: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   327: ldc ' , _pc'
    //   329: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   332: ldc ' text'
    //   334: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   337: ldc ' , _tm'
    //   339: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   342: ldc ' int'
    //   344: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   347: ldc ' , _fl'
    //   349: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   352: ldc ' int'
    //   354: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   357: ldc ' , _sv'
    //   359: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   362: ldc ' text'
    //   364: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   367: ldc ' , _av'
    //   369: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   372: ldc ' text'
    //   374: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   377: ldc ' , _uid'
    //   379: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   382: ldc ' integer'
    //   384: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   387: ldc ',primary key(_id'
    //   389: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   392: ldc ',_pc'
    //   394: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   397: ldc ',_uid'
    //   399: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   402: ldc ' )) '
    //   404: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   407: pop
    //   408: ldc 'create %s'
    //   410: iconst_1
    //   411: anewarray java/lang/Object
    //   414: dup
    //   415: iconst_0
    //   416: aload_2
    //   417: invokevirtual toString : ()Ljava/lang/String;
    //   420: aastore
    //   421: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   424: pop
    //   425: aload_1
    //   426: aload_2
    //   427: invokevirtual toString : ()Ljava/lang/String;
    //   430: invokevirtual execSQL : (Ljava/lang/String;)V
    //   433: aload_2
    //   434: iconst_0
    //   435: invokevirtual setLength : (I)V
    //   438: aload_2
    //   439: ldc ' CREATE TABLE IF NOT EXISTS t_cr'
    //   441: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   444: ldc ' ( _id'
    //   446: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   449: ldc ' INTEGER PRIMARY KEY'
    //   451: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   454: ldc ' , _tm'
    //   456: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   459: ldc ' int'
    //   461: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   464: ldc ' , _s1'
    //   466: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   469: ldc ' text'
    //   471: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   474: ldc ' , _up'
    //   476: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   479: ldc ' int'
    //   481: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   484: ldc ' , _me'
    //   486: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   489: ldc ' int'
    //   491: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   494: ldc ' , _uc'
    //   496: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   499: ldc ' int'
    //   501: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   504: ldc ' , _dt'
    //   506: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   509: ldc ' blob'
    //   511: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   514: ldc ' ) '
    //   516: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   519: pop
    //   520: ldc 'create %s'
    //   522: iconst_1
    //   523: anewarray java/lang/Object
    //   526: dup
    //   527: iconst_0
    //   528: aload_2
    //   529: aastore
    //   530: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   533: pop
    //   534: aload_1
    //   535: aload_2
    //   536: invokevirtual toString : ()Ljava/lang/String;
    //   539: invokevirtual execSQL : (Ljava/lang/String;)V
    //   542: aload_2
    //   543: iconst_0
    //   544: invokevirtual setLength : (I)V
    //   547: aload_2
    //   548: ldc ' CREATE TABLE IF NOT EXISTS dl_1002'
    //   550: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   553: ldc ' (_id'
    //   555: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   558: ldc ' integer primary key autoincrement, _dUrl'
    //   560: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   563: ldc ' varchar(100), _sFile'
    //   565: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   568: ldc ' varchar(100), _sLen'
    //   570: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   573: ldc ' INTEGER, _tLen'
    //   575: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   578: ldc ' INTEGER, _MD5'
    //   580: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   583: ldc ' varchar(100), _DLTIME'
    //   585: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   588: ldc ' INTEGER)'
    //   590: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   593: pop
    //   594: ldc 'create %s'
    //   596: iconst_1
    //   597: anewarray java/lang/Object
    //   600: dup
    //   601: iconst_0
    //   602: aload_2
    //   603: aastore
    //   604: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   607: pop
    //   608: aload_1
    //   609: aload_2
    //   610: invokevirtual toString : ()Ljava/lang/String;
    //   613: invokevirtual execSQL : (Ljava/lang/String;)V
    //   616: aload_2
    //   617: iconst_0
    //   618: invokevirtual setLength : (I)V
    //   621: aload_2
    //   622: ldc 'CREATE TABLE IF NOT EXISTS ge_1002'
    //   624: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   627: ldc ' (_id'
    //   629: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   632: ldc ' integer primary key autoincrement, _time'
    //   634: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   637: ldc ' INTEGER, _datas'
    //   639: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   642: ldc ' blob)'
    //   644: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   647: pop
    //   648: ldc 'create %s'
    //   650: iconst_1
    //   651: anewarray java/lang/Object
    //   654: dup
    //   655: iconst_0
    //   656: aload_2
    //   657: aastore
    //   658: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   661: pop
    //   662: aload_1
    //   663: aload_2
    //   664: invokevirtual toString : ()Ljava/lang/String;
    //   667: invokevirtual execSQL : (Ljava/lang/String;)V
    //   670: aload_2
    //   671: iconst_0
    //   672: invokevirtual setLength : (I)V
    //   675: aload_2
    //   676: ldc ' CREATE TABLE IF NOT EXISTS st_1002'
    //   678: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   681: ldc ' ( _id'
    //   683: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   686: ldc ' integer'
    //   688: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   691: ldc ' , _tp'
    //   693: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   696: ldc ' text'
    //   698: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   701: ldc ' , _tm'
    //   703: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   706: ldc ' int'
    //   708: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   711: ldc ' , _dt'
    //   713: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   716: ldc ' blob'
    //   718: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   721: ldc ',primary key(_id'
    //   723: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   726: ldc ',_tp'
    //   728: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   731: ldc ' )) '
    //   733: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   736: pop
    //   737: ldc 'create %s'
    //   739: iconst_1
    //   740: anewarray java/lang/Object
    //   743: dup
    //   744: iconst_0
    //   745: aload_2
    //   746: invokevirtual toString : ()Ljava/lang/String;
    //   749: aastore
    //   750: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   753: pop
    //   754: aload_1
    //   755: aload_2
    //   756: invokevirtual toString : ()Ljava/lang/String;
    //   759: invokevirtual execSQL : (Ljava/lang/String;)V
    //   762: aload_0
    //   763: getfield c : Ljava/util/List;
    //   766: astore_2
    //   767: aload_2
    //   768: ifnonnull -> 794
    //   771: aload_0
    //   772: monitorexit
    //   773: return
    //   774: astore_2
    //   775: aload_2
    //   776: invokestatic b : (Ljava/lang/Throwable;)Z
    //   779: ifne -> 762
    //   782: aload_2
    //   783: invokevirtual printStackTrace : ()V
    //   786: goto -> 762
    //   789: astore_1
    //   790: aload_0
    //   791: monitorexit
    //   792: aload_1
    //   793: athrow
    //   794: aload_0
    //   795: getfield c : Ljava/util/List;
    //   798: invokeinterface iterator : ()Ljava/util/Iterator;
    //   803: astore_2
    //   804: aload_2
    //   805: invokeinterface hasNext : ()Z
    //   810: ifeq -> 771
    //   813: aload_2
    //   814: invokeinterface next : ()Ljava/lang/Object;
    //   819: checkcast com/tencent/bugly/legu/a
    //   822: astore_3
    //   823: aload_3
    //   824: aload_1
    //   825: invokevirtual onDbCreate : (Landroid/database/sqlite/SQLiteDatabase;)V
    //   828: goto -> 804
    //   831: astore_3
    //   832: aload_3
    //   833: invokestatic b : (Ljava/lang/Throwable;)Z
    //   836: ifne -> 804
    //   839: aload_3
    //   840: invokevirtual printStackTrace : ()V
    //   843: goto -> 804
    // Exception table:
    //   from	to	target	type
    //   2	762	774	java/lang/Throwable
    //   2	762	789	finally
    //   762	767	789	finally
    //   775	786	789	finally
    //   794	804	789	finally
    //   804	823	789	finally
    //   823	828	831	java/lang/Throwable
    //   823	828	789	finally
    //   832	843	789	finally
  }
  
  @TargetApi(11)
  public final void onDowngrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic d : ()I
    //   5: bipush #11
    //   7: if_icmplt -> 122
    //   10: ldc_w 'drowngrade %d to %d drop tables!}'
    //   13: iconst_2
    //   14: anewarray java/lang/Object
    //   17: dup
    //   18: iconst_0
    //   19: iload_2
    //   20: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   23: aastore
    //   24: dup
    //   25: iconst_1
    //   26: iload_3
    //   27: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   30: aastore
    //   31: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   34: pop
    //   35: aload_0
    //   36: getfield c : Ljava/util/List;
    //   39: ifnull -> 109
    //   42: aload_0
    //   43: getfield c : Ljava/util/List;
    //   46: invokeinterface iterator : ()Ljava/util/Iterator;
    //   51: astore #4
    //   53: aload #4
    //   55: invokeinterface hasNext : ()Z
    //   60: ifeq -> 109
    //   63: aload #4
    //   65: invokeinterface next : ()Ljava/lang/Object;
    //   70: checkcast com/tencent/bugly/legu/a
    //   73: astore #5
    //   75: aload #5
    //   77: aload_1
    //   78: iload_2
    //   79: iload_3
    //   80: invokevirtual onDbDowngrade : (Landroid/database/sqlite/SQLiteDatabase;II)V
    //   83: goto -> 53
    //   86: astore #5
    //   88: aload #5
    //   90: invokestatic b : (Ljava/lang/Throwable;)Z
    //   93: ifne -> 53
    //   96: aload #5
    //   98: invokevirtual printStackTrace : ()V
    //   101: goto -> 53
    //   104: astore_1
    //   105: aload_0
    //   106: monitorexit
    //   107: aload_1
    //   108: athrow
    //   109: aload_0
    //   110: aload_1
    //   111: invokespecial a : (Landroid/database/sqlite/SQLiteDatabase;)Z
    //   114: ifeq -> 125
    //   117: aload_0
    //   118: aload_1
    //   119: invokevirtual onCreate : (Landroid/database/sqlite/SQLiteDatabase;)V
    //   122: aload_0
    //   123: monitorexit
    //   124: return
    //   125: ldc_w 'drop fail delete db'
    //   128: iconst_0
    //   129: anewarray java/lang/Object
    //   132: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   135: pop
    //   136: aload_0
    //   137: getfield b : Landroid/content/Context;
    //   140: ldc_w 'bugly_db'
    //   143: invokevirtual getDatabasePath : (Ljava/lang/String;)Ljava/io/File;
    //   146: astore_1
    //   147: aload_1
    //   148: ifnull -> 122
    //   151: aload_1
    //   152: invokevirtual canWrite : ()Z
    //   155: ifeq -> 122
    //   158: aload_1
    //   159: invokevirtual delete : ()Z
    //   162: pop
    //   163: goto -> 122
    // Exception table:
    //   from	to	target	type
    //   2	53	104	finally
    //   53	75	104	finally
    //   75	83	86	java/lang/Throwable
    //   75	83	104	finally
    //   88	101	104	finally
    //   109	122	104	finally
    //   125	147	104	finally
    //   151	163	104	finally
  }
  
  public final void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: ldc_w 'upgrade %d to %d , drop tables!'
    //   5: iconst_2
    //   6: anewarray java/lang/Object
    //   9: dup
    //   10: iconst_0
    //   11: iload_2
    //   12: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   15: aastore
    //   16: dup
    //   17: iconst_1
    //   18: iload_3
    //   19: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   22: aastore
    //   23: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   26: pop
    //   27: aload_0
    //   28: getfield c : Ljava/util/List;
    //   31: ifnull -> 101
    //   34: aload_0
    //   35: getfield c : Ljava/util/List;
    //   38: invokeinterface iterator : ()Ljava/util/Iterator;
    //   43: astore #4
    //   45: aload #4
    //   47: invokeinterface hasNext : ()Z
    //   52: ifeq -> 101
    //   55: aload #4
    //   57: invokeinterface next : ()Ljava/lang/Object;
    //   62: checkcast com/tencent/bugly/legu/a
    //   65: astore #5
    //   67: aload #5
    //   69: aload_1
    //   70: iload_2
    //   71: iload_3
    //   72: invokevirtual onDbUpgrade : (Landroid/database/sqlite/SQLiteDatabase;II)V
    //   75: goto -> 45
    //   78: astore #5
    //   80: aload #5
    //   82: invokestatic b : (Ljava/lang/Throwable;)Z
    //   85: ifne -> 45
    //   88: aload #5
    //   90: invokevirtual printStackTrace : ()V
    //   93: goto -> 45
    //   96: astore_1
    //   97: aload_0
    //   98: monitorexit
    //   99: aload_1
    //   100: athrow
    //   101: aload_0
    //   102: aload_1
    //   103: invokespecial a : (Landroid/database/sqlite/SQLiteDatabase;)Z
    //   106: ifeq -> 117
    //   109: aload_0
    //   110: aload_1
    //   111: invokevirtual onCreate : (Landroid/database/sqlite/SQLiteDatabase;)V
    //   114: aload_0
    //   115: monitorexit
    //   116: return
    //   117: ldc_w 'drop fail delete db'
    //   120: iconst_0
    //   121: anewarray java/lang/Object
    //   124: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   127: pop
    //   128: aload_0
    //   129: getfield b : Landroid/content/Context;
    //   132: ldc_w 'bugly_db'
    //   135: invokevirtual getDatabasePath : (Ljava/lang/String;)Ljava/io/File;
    //   138: astore_1
    //   139: aload_1
    //   140: ifnull -> 114
    //   143: aload_1
    //   144: invokevirtual canWrite : ()Z
    //   147: ifeq -> 114
    //   150: aload_1
    //   151: invokevirtual delete : ()Z
    //   154: pop
    //   155: goto -> 114
    // Exception table:
    //   from	to	target	type
    //   2	45	96	finally
    //   45	67	96	finally
    //   67	75	78	java/lang/Throwable
    //   67	75	96	finally
    //   80	93	96	finally
    //   101	114	96	finally
    //   117	139	96	finally
    //   143	155	96	finally
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */