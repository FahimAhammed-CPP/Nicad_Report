package com.tencent.bugly.legu.proguard;

import java.util.ArrayList;

public final class ai extends j implements Cloneable {
  private static ArrayList<String> c;
  
  private String a = "";
  
  private ArrayList<String> b = null;
  
  public final void a(h paramh) {
    this.a = paramh.b(0, true);
    if (c == null) {
      c = new ArrayList<String>();
      c.add("");
    } 
    this.b = (ArrayList<String>)paramh.<ArrayList<String>>a(c, 1, false);
  }
  
  public final void a(i parami) {
    parami.a(this.a, 0);
    if (this.b != null)
      parami.a(this.b, 1); 
  }
  
  public final void a(StringBuilder paramStringBuilder, int paramInt) {}
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/ai.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */