package com.tencent.bugly.legu;

import android.content.Context;
import com.tencent.bugly.legu.crashreport.CrashReport;
import com.tencent.bugly.legu.crashreport.common.strategy.StrategyBean;
import com.tencent.bugly.legu.crashreport.crash.c;
import com.tencent.bugly.legu.crashreport.crash.d;
import com.tencent.bugly.legu.crashreport.inner.InnerAPI;
import com.tencent.bugly.legu.proguard.m;
import com.tencent.bugly.legu.proguard.w;

public class CrashModule extends a {
  public static final int MODULE_ID = 1004;
  
  private static int c = 0;
  
  private static boolean d = false;
  
  private static CrashModule e = new CrashModule();
  
  private long a;
  
  private BuglyStrategy.a b;
  
  private void a(Context paramContext, BuglyStrategy paramBuglyStrategy) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_2
    //   3: ifnonnull -> 9
    //   6: aload_0
    //   7: monitorexit
    //   8: return
    //   9: aload_2
    //   10: invokevirtual getLibBuglySOFilePath : ()Ljava/lang/String;
    //   13: astore_3
    //   14: aload_3
    //   15: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   18: ifne -> 43
    //   21: aload_1
    //   22: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   25: aload_3
    //   26: putfield k : Ljava/lang/String;
    //   29: ldc 'setted libBugly.so file path :%s'
    //   31: iconst_1
    //   32: anewarray java/lang/Object
    //   35: dup
    //   36: iconst_0
    //   37: aload_3
    //   38: aastore
    //   39: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   42: pop
    //   43: aload_2
    //   44: invokevirtual getCrashHandleCallback : ()Lcom/tencent/bugly/legu/BuglyStrategy$a;
    //   47: ifnull -> 68
    //   50: aload_0
    //   51: aload_2
    //   52: invokevirtual getCrashHandleCallback : ()Lcom/tencent/bugly/legu/BuglyStrategy$a;
    //   55: putfield b : Lcom/tencent/bugly/legu/BuglyStrategy$a;
    //   58: ldc 'setted CrashHanldeCallback'
    //   60: iconst_0
    //   61: anewarray java/lang/Object
    //   64: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   67: pop
    //   68: aload_2
    //   69: invokevirtual getAppReportDelay : ()J
    //   72: lconst_0
    //   73: lcmp
    //   74: ifle -> 6
    //   77: aload_0
    //   78: aload_2
    //   79: invokevirtual getAppReportDelay : ()J
    //   82: putfield a : J
    //   85: ldc 'setted delay: %d'
    //   87: iconst_1
    //   88: anewarray java/lang/Object
    //   91: dup
    //   92: iconst_0
    //   93: aload_0
    //   94: getfield a : J
    //   97: invokestatic valueOf : (J)Ljava/lang/Long;
    //   100: aastore
    //   101: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   104: pop
    //   105: goto -> 6
    //   108: astore_1
    //   109: aload_0
    //   110: monitorexit
    //   111: aload_1
    //   112: athrow
    // Exception table:
    //   from	to	target	type
    //   9	43	108	finally
    //   43	68	108	finally
    //   68	105	108	finally
  }
  
  public static CrashModule getInstance() {
    e.id = 1004;
    return e;
  }
  
  public static boolean hasInitialized() {
    return d;
  }
  
  public String[] getTables() {
    return new String[] { "t_cr" };
  }
  
  public void init(Context paramContext, boolean paramBoolean, BuglyStrategy paramBuglyStrategy) {
    if (paramContext != null && !d) {
      m m2 = m.a();
      int i = c + 1;
      c = i;
      m2.a(1004, i);
      d = true;
      CrashReport.setContext(paramContext);
      a(paramContext, paramBuglyStrategy);
      c.a(1004, paramContext, paramBoolean, this.b, null, null);
      c c = c.a();
      c.e();
      if (paramBuglyStrategy == null || paramBuglyStrategy.isEnableNativeCrashMonitor()) {
        c.g();
      } else {
        w.a("[crash] Closed native crash monitor!", new Object[0]);
        c.f();
      } 
      if (paramBuglyStrategy == null || paramBuglyStrategy.isEnableANRCrashMonitor()) {
        c.h();
      } else {
        w.a("[crash] Closed ANR monitor!", new Object[0]);
        c.i();
      } 
      InnerAPI.context = paramContext;
      d.a(paramContext);
      c.a().a(this.a);
      m m1 = m.a();
      i = c - 1;
      c = i;
      m1.a(1004, i);
    } 
  }
  
  public void onServerStrategyChanged(StrategyBean paramStrategyBean) {
    if (paramStrategyBean != null) {
      c c = c.a();
      if (c != null)
        c.a(paramStrategyBean); 
      d.a(paramStrategyBean);
    } 
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/CrashModule.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */