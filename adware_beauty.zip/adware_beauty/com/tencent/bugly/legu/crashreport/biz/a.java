package com.tencent.bugly.legu.crashreport.biz;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.os.Parcel;
import com.tencent.bugly.legu.crashreport.common.strategy.StrategyBean;
import com.tencent.bugly.legu.proguard.o;
import com.tencent.bugly.legu.proguard.s;
import com.tencent.bugly.legu.proguard.v;
import com.tencent.bugly.legu.proguard.w;
import java.util.List;

public final class a {
  private Context a;
  
  private long b;
  
  private int c;
  
  public a(Context paramContext) {
    this.a = paramContext;
  }
  
  private static ContentValues a(UserInfoBean paramUserInfoBean) {
    UserInfoBean userInfoBean = null;
    if (paramUserInfoBean == null)
      return (ContentValues)userInfoBean; 
    try {
      ContentValues contentValues2 = new ContentValues();
      this();
      if (paramUserInfoBean.a > 0L)
        contentValues2.put("_id", Long.valueOf(paramUserInfoBean.a)); 
      contentValues2.put("_tm", Long.valueOf(paramUserInfoBean.e));
      contentValues2.put("_ut", Long.valueOf(paramUserInfoBean.f));
      contentValues2.put("_tp", Integer.valueOf(paramUserInfoBean.b));
      contentValues2.put("_pc", paramUserInfoBean.c);
      Parcel parcel = Parcel.obtain();
      paramUserInfoBean.writeToParcel(parcel, 0);
      byte[] arrayOfByte = parcel.marshall();
      parcel.recycle();
      contentValues2.put("_dt", arrayOfByte);
      ContentValues contentValues1 = contentValues2;
    } catch (Throwable throwable) {
      paramUserInfoBean = userInfoBean;
    } 
    return (ContentValues)paramUserInfoBean;
  }
  
  private static UserInfoBean a(Cursor paramCursor) {
    if (paramCursor == null)
      return null; 
    try {
      byte[] arrayOfByte = paramCursor.getBlob(paramCursor.getColumnIndex("_dt"));
      if (arrayOfByte == null)
        return null; 
      long l = paramCursor.getLong(paramCursor.getColumnIndex("_id"));
      UserInfoBean userInfoBean2 = (UserInfoBean)com.tencent.bugly.legu.proguard.a.a(arrayOfByte, UserInfoBean.CREATOR);
      UserInfoBean userInfoBean1 = userInfoBean2;
      if (userInfoBean2 != null) {
        userInfoBean2.a = l;
        userInfoBean1 = userInfoBean2;
      } 
    } catch (Throwable throwable) {}
    return (UserInfoBean)throwable;
  }
  
  private static void a(List<UserInfoBean> paramList) {
    if (paramList != null && paramList.size() != 0) {
      StringBuilder stringBuilder = new StringBuilder();
      for (UserInfoBean userInfoBean : paramList)
        stringBuilder.append(" or _id").append(" = ").append(userInfoBean.a); 
      String str2 = stringBuilder.toString();
      String str1 = str2;
      if (str2.length() > 0)
        str1 = str2.substring(4); 
      stringBuilder.setLength(0);
      try {
        w.c("deleted %s data %d", new Object[] { "t_ui", Integer.valueOf(o.a().a("t_ui", str1, null, null, true)) });
      } catch (Throwable throwable) {}
    } 
  }
  
  public final List<UserInfoBean> a(String paramString) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_1
    //   3: ifnull -> 63
    //   6: aload_1
    //   7: invokevirtual trim : ()Ljava/lang/String;
    //   10: invokevirtual length : ()I
    //   13: ifle -> 63
    //   16: iload_2
    //   17: ifeq -> 68
    //   20: aconst_null
    //   21: astore_1
    //   22: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   25: ldc 't_ui'
    //   27: aconst_null
    //   28: aload_1
    //   29: aconst_null
    //   30: aconst_null
    //   31: iconst_1
    //   32: invokevirtual a : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Lcom/tencent/bugly/legu/proguard/n;Z)Landroid/database/Cursor;
    //   35: astore_1
    //   36: aload_1
    //   37: ifnonnull -> 95
    //   40: aload_1
    //   41: ifnull -> 59
    //   44: aload_1
    //   45: invokeinterface isClosed : ()Z
    //   50: ifne -> 59
    //   53: aload_1
    //   54: invokeinterface close : ()V
    //   59: aconst_null
    //   60: astore_1
    //   61: aload_1
    //   62: areturn
    //   63: iconst_1
    //   64: istore_2
    //   65: goto -> 16
    //   68: new java/lang/StringBuilder
    //   71: astore_3
    //   72: aload_3
    //   73: ldc '_pc = ''
    //   75: invokespecial <init> : (Ljava/lang/String;)V
    //   78: aload_3
    //   79: aload_1
    //   80: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   83: ldc '''
    //   85: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   88: invokevirtual toString : ()Ljava/lang/String;
    //   91: astore_1
    //   92: goto -> 22
    //   95: new java/lang/StringBuilder
    //   98: astore #4
    //   100: aload #4
    //   102: invokespecial <init> : ()V
    //   105: new java/util/ArrayList
    //   108: astore_3
    //   109: aload_3
    //   110: invokespecial <init> : ()V
    //   113: aload_1
    //   114: invokeinterface moveToNext : ()Z
    //   119: ifeq -> 261
    //   122: aload_1
    //   123: invokestatic a : (Landroid/database/Cursor;)Lcom/tencent/bugly/legu/crashreport/biz/UserInfoBean;
    //   126: astore #5
    //   128: aload #5
    //   130: ifnull -> 181
    //   133: aload_3
    //   134: aload #5
    //   136: invokeinterface add : (Ljava/lang/Object;)Z
    //   141: pop
    //   142: goto -> 113
    //   145: astore_3
    //   146: aload_3
    //   147: invokestatic a : (Ljava/lang/Throwable;)Z
    //   150: ifne -> 157
    //   153: aload_3
    //   154: invokevirtual printStackTrace : ()V
    //   157: aload_1
    //   158: ifnull -> 176
    //   161: aload_1
    //   162: invokeinterface isClosed : ()Z
    //   167: ifne -> 176
    //   170: aload_1
    //   171: invokeinterface close : ()V
    //   176: aconst_null
    //   177: astore_1
    //   178: goto -> 61
    //   181: aload_1
    //   182: aload_1
    //   183: ldc '_id'
    //   185: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   190: invokeinterface getLong : (I)J
    //   195: lstore #6
    //   197: aload #4
    //   199: ldc ' or _id'
    //   201: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   204: ldc ' = '
    //   206: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   209: lload #6
    //   211: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   214: pop
    //   215: goto -> 113
    //   218: astore #5
    //   220: ldc 'unknown id!'
    //   222: iconst_0
    //   223: anewarray java/lang/Object
    //   226: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   229: pop
    //   230: goto -> 113
    //   233: astore #4
    //   235: aload_1
    //   236: astore_3
    //   237: aload #4
    //   239: astore_1
    //   240: aload_3
    //   241: ifnull -> 259
    //   244: aload_3
    //   245: invokeinterface isClosed : ()Z
    //   250: ifne -> 259
    //   253: aload_3
    //   254: invokeinterface close : ()V
    //   259: aload_1
    //   260: athrow
    //   261: aload #4
    //   263: invokevirtual toString : ()Ljava/lang/String;
    //   266: astore #4
    //   268: aload #4
    //   270: invokevirtual length : ()I
    //   273: ifle -> 318
    //   276: aload #4
    //   278: iconst_4
    //   279: invokevirtual substring : (I)Ljava/lang/String;
    //   282: astore #4
    //   284: ldc '[session] deleted %s error data %d'
    //   286: iconst_2
    //   287: anewarray java/lang/Object
    //   290: dup
    //   291: iconst_0
    //   292: ldc 't_ui'
    //   294: aastore
    //   295: dup
    //   296: iconst_1
    //   297: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   300: ldc 't_ui'
    //   302: aload #4
    //   304: aconst_null
    //   305: aconst_null
    //   306: iconst_1
    //   307: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Lcom/tencent/bugly/legu/proguard/n;Z)I
    //   310: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   313: aastore
    //   314: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   317: pop
    //   318: aload_1
    //   319: ifnull -> 337
    //   322: aload_1
    //   323: invokeinterface isClosed : ()Z
    //   328: ifne -> 337
    //   331: aload_1
    //   332: invokeinterface close : ()V
    //   337: aload_3
    //   338: astore_1
    //   339: goto -> 61
    //   342: astore_1
    //   343: aconst_null
    //   344: astore_3
    //   345: goto -> 240
    //   348: astore_3
    //   349: aload_1
    //   350: astore #4
    //   352: aload_3
    //   353: astore_1
    //   354: aload #4
    //   356: astore_3
    //   357: goto -> 240
    //   360: astore_3
    //   361: aconst_null
    //   362: astore_1
    //   363: goto -> 146
    // Exception table:
    //   from	to	target	type
    //   6	16	360	java/lang/Throwable
    //   6	16	342	finally
    //   22	36	360	java/lang/Throwable
    //   22	36	342	finally
    //   68	92	360	java/lang/Throwable
    //   68	92	342	finally
    //   95	113	145	java/lang/Throwable
    //   95	113	233	finally
    //   113	128	145	java/lang/Throwable
    //   113	128	233	finally
    //   133	142	145	java/lang/Throwable
    //   133	142	233	finally
    //   146	157	348	finally
    //   181	215	218	java/lang/Throwable
    //   181	215	233	finally
    //   220	230	145	java/lang/Throwable
    //   220	230	233	finally
    //   261	318	145	java/lang/Throwable
    //   261	318	233	finally
  }
  
  public final void a() {
    this.b = com.tencent.bugly.legu.proguard.a.o() + 86400000L;
    v.a().a(new b(this), this.b - System.currentTimeMillis() + 5000L);
  }
  
  public final void a(int paramInt, boolean paramBoolean, long paramLong) {
    boolean bool = true;
    StrategyBean strategyBean = com.tencent.bugly.legu.crashreport.common.strategy.a.a().c();
    if (strategyBean != null && !strategyBean.e && paramInt != 1 && paramInt != 3) {
      w.e("UserInfo is disable", new Object[0]);
      return;
    } 
    if (paramInt == 1)
      this.c++; 
    Context context = this.a;
    if (paramInt != 1)
      bool = false; 
    com.tencent.bugly.legu.crashreport.common.info.a a1 = com.tencent.bugly.legu.crashreport.common.info.a.a(context);
    UserInfoBean userInfoBean = new UserInfoBean();
    userInfoBean.b = paramInt;
    userInfoBean.c = a1.d;
    userInfoBean.d = a1.f();
    userInfoBean.e = System.currentTimeMillis();
    userInfoBean.f = -1L;
    userInfoBean.n = a1.i;
    userInfoBean.o = bool;
    userInfoBean.l = a1.n;
    userInfoBean.m = a1.o;
    userInfoBean.g = a1.p;
    userInfoBean.h = a1.q;
    userInfoBean.i = a1.r;
    userInfoBean.k = a1.s;
    userInfoBean.r = a1.w();
    userInfoBean.s = a1.A();
    userInfoBean.p = a1.B();
    userInfoBean.q = a1.C();
    v.a().a(new a(this, userInfoBean, paramBoolean), 0L);
  }
  
  public final void b() {
    // Byte code:
    //   0: iconst_1
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield a : Landroid/content/Context;
    //   8: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   11: getfield d : Ljava/lang/String;
    //   14: astore_2
    //   15: new java/util/ArrayList
    //   18: astore_3
    //   19: aload_3
    //   20: invokespecial <init> : ()V
    //   23: aload_0
    //   24: aload_2
    //   25: invokevirtual a : (Ljava/lang/String;)Ljava/util/List;
    //   28: astore_2
    //   29: aload_2
    //   30: ifnull -> 378
    //   33: aload_2
    //   34: invokeinterface size : ()I
    //   39: bipush #10
    //   41: isub
    //   42: istore #4
    //   44: iload #4
    //   46: ifle -> 198
    //   49: iconst_0
    //   50: istore #5
    //   52: iload #5
    //   54: aload_2
    //   55: invokeinterface size : ()I
    //   60: iconst_1
    //   61: isub
    //   62: if_icmpge -> 167
    //   65: iload #5
    //   67: iconst_1
    //   68: iadd
    //   69: istore #6
    //   71: iload #6
    //   73: aload_2
    //   74: invokeinterface size : ()I
    //   79: if_icmpge -> 161
    //   82: aload_2
    //   83: iload #5
    //   85: invokeinterface get : (I)Ljava/lang/Object;
    //   90: checkcast com/tencent/bugly/legu/crashreport/biz/UserInfoBean
    //   93: getfield e : J
    //   96: aload_2
    //   97: iload #6
    //   99: invokeinterface get : (I)Ljava/lang/Object;
    //   104: checkcast com/tencent/bugly/legu/crashreport/biz/UserInfoBean
    //   107: getfield e : J
    //   110: lcmp
    //   111: ifle -> 155
    //   114: aload_2
    //   115: iload #5
    //   117: invokeinterface get : (I)Ljava/lang/Object;
    //   122: checkcast com/tencent/bugly/legu/crashreport/biz/UserInfoBean
    //   125: astore #7
    //   127: aload_2
    //   128: iload #5
    //   130: aload_2
    //   131: iload #6
    //   133: invokeinterface get : (I)Ljava/lang/Object;
    //   138: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   143: pop
    //   144: aload_2
    //   145: iload #6
    //   147: aload #7
    //   149: invokeinterface set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   154: pop
    //   155: iinc #6, 1
    //   158: goto -> 71
    //   161: iinc #5, 1
    //   164: goto -> 52
    //   167: iconst_0
    //   168: istore #5
    //   170: iload #5
    //   172: iload #4
    //   174: if_icmpge -> 198
    //   177: aload_3
    //   178: aload_2
    //   179: iload #5
    //   181: invokeinterface get : (I)Ljava/lang/Object;
    //   186: invokeinterface add : (Ljava/lang/Object;)Z
    //   191: pop
    //   192: iinc #5, 1
    //   195: goto -> 170
    //   198: aload_2
    //   199: invokeinterface iterator : ()Ljava/util/Iterator;
    //   204: astore #7
    //   206: iconst_0
    //   207: istore #5
    //   209: aload #7
    //   211: invokeinterface hasNext : ()Z
    //   216: ifeq -> 311
    //   219: aload #7
    //   221: invokeinterface next : ()Ljava/lang/Object;
    //   226: checkcast com/tencent/bugly/legu/crashreport/biz/UserInfoBean
    //   229: astore #8
    //   231: aload #8
    //   233: getfield f : J
    //   236: ldc2_w -1
    //   239: lcmp
    //   240: ifeq -> 271
    //   243: aload #7
    //   245: invokeinterface remove : ()V
    //   250: aload #8
    //   252: getfield e : J
    //   255: invokestatic o : ()J
    //   258: lcmp
    //   259: ifge -> 271
    //   262: aload_3
    //   263: aload #8
    //   265: invokeinterface add : (Ljava/lang/Object;)Z
    //   270: pop
    //   271: aload #8
    //   273: getfield e : J
    //   276: invokestatic currentTimeMillis : ()J
    //   279: ldc2_w 600000
    //   282: lsub
    //   283: lcmp
    //   284: ifle -> 549
    //   287: aload #8
    //   289: getfield b : I
    //   292: iconst_1
    //   293: if_icmpeq -> 305
    //   296: aload #8
    //   298: getfield b : I
    //   301: iconst_4
    //   302: if_icmpne -> 549
    //   305: iinc #5, 1
    //   308: goto -> 209
    //   311: iload #5
    //   313: bipush #15
    //   315: if_icmple -> 543
    //   318: ldc_w '[userinfo] userinfo too many times in 10 min: %d'
    //   321: iconst_1
    //   322: anewarray java/lang/Object
    //   325: dup
    //   326: iconst_0
    //   327: iload #5
    //   329: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   332: aastore
    //   333: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   336: pop
    //   337: iconst_0
    //   338: istore #5
    //   340: aload_3
    //   341: invokeinterface size : ()I
    //   346: ifle -> 353
    //   349: aload_3
    //   350: invokestatic a : (Ljava/util/List;)V
    //   353: iload #5
    //   355: ifeq -> 375
    //   358: aload_2
    //   359: ifnull -> 375
    //   362: aload_2
    //   363: invokeinterface size : ()I
    //   368: istore #5
    //   370: iload #5
    //   372: ifne -> 392
    //   375: aload_0
    //   376: monitorexit
    //   377: return
    //   378: new java/util/ArrayList
    //   381: dup
    //   382: invokespecial <init> : ()V
    //   385: astore_2
    //   386: iconst_1
    //   387: istore #5
    //   389: goto -> 340
    //   392: ldc_w '[userinfo] do userinfo, size: %d'
    //   395: iconst_1
    //   396: anewarray java/lang/Object
    //   399: dup
    //   400: iconst_0
    //   401: aload_2
    //   402: invokeinterface size : ()I
    //   407: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   410: aastore
    //   411: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   414: pop
    //   415: aload_0
    //   416: getfield c : I
    //   419: iconst_1
    //   420: if_icmpne -> 456
    //   423: iload_1
    //   424: istore #5
    //   426: aload_2
    //   427: iload #5
    //   429: invokestatic a : (Ljava/util/List;I)Lcom/tencent/bugly/legu/proguard/ar;
    //   432: astore_3
    //   433: aload_3
    //   434: ifnonnull -> 462
    //   437: ldc_w '[biz] create uPkg fail!'
    //   440: iconst_0
    //   441: anewarray java/lang/Object
    //   444: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   447: pop
    //   448: goto -> 375
    //   451: astore_2
    //   452: aload_0
    //   453: monitorexit
    //   454: aload_2
    //   455: athrow
    //   456: iconst_2
    //   457: istore #5
    //   459: goto -> 426
    //   462: aload_3
    //   463: invokestatic a : (Lcom/tencent/bugly/legu/proguard/j;)[B
    //   466: astore_3
    //   467: aload_3
    //   468: ifnonnull -> 485
    //   471: ldc_w '[biz] send encode fail!'
    //   474: iconst_0
    //   475: anewarray java/lang/Object
    //   478: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   481: pop
    //   482: goto -> 375
    //   485: aload_0
    //   486: getfield a : Landroid/content/Context;
    //   489: sipush #640
    //   492: aload_3
    //   493: invokestatic a : (Landroid/content/Context;I[B)Lcom/tencent/bugly/legu/proguard/am;
    //   496: astore_3
    //   497: aload_3
    //   498: ifnonnull -> 515
    //   501: ldc_w 'request package is null.'
    //   504: iconst_0
    //   505: anewarray java/lang/Object
    //   508: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   511: pop
    //   512: goto -> 375
    //   515: new com/tencent/bugly/legu/crashreport/biz/a$1
    //   518: astore #7
    //   520: aload #7
    //   522: aload_0
    //   523: aload_2
    //   524: invokespecial <init> : (Lcom/tencent/bugly/legu/crashreport/biz/a;Ljava/util/List;)V
    //   527: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/t;
    //   530: sipush #1001
    //   533: aload_3
    //   534: aconst_null
    //   535: aload #7
    //   537: invokevirtual a : (ILcom/tencent/bugly/legu/proguard/am;Ljava/lang/String;Lcom/tencent/bugly/legu/proguard/s;)V
    //   540: goto -> 375
    //   543: iconst_1
    //   544: istore #5
    //   546: goto -> 340
    //   549: goto -> 308
    // Exception table:
    //   from	to	target	type
    //   4	29	451	finally
    //   33	44	451	finally
    //   52	65	451	finally
    //   71	155	451	finally
    //   177	192	451	finally
    //   198	206	451	finally
    //   209	271	451	finally
    //   271	305	451	finally
    //   318	337	451	finally
    //   340	353	451	finally
    //   362	370	451	finally
    //   378	386	451	finally
    //   392	423	451	finally
    //   426	433	451	finally
    //   437	448	451	finally
    //   462	467	451	finally
    //   471	482	451	finally
    //   485	497	451	finally
    //   501	512	451	finally
    //   515	540	451	finally
  }
  
  final class a implements Runnable {
    private boolean a;
    
    private UserInfoBean b;
    
    public a(a this$0, UserInfoBean param1UserInfoBean, boolean param1Boolean) {
      this.b = param1UserInfoBean;
      this.a = param1Boolean;
    }
    
    public final void run() {
      try {
        if (this.b != null) {
          UserInfoBean userInfoBean = this.b;
          if (userInfoBean != null) {
            com.tencent.bugly.legu.crashreport.common.info.a a1 = com.tencent.bugly.legu.crashreport.common.info.a.a();
            if (a1 != null)
              userInfoBean.j = a1.d(); 
          } 
          w.c("record userinfo", new Object[0]);
          a.a(this.c, this.b);
        } 
        if (this.a)
          this.c.b(); 
      } catch (Throwable throwable) {}
    }
  }
  
  final class b implements Runnable {
    b(a this$0) {}
    
    public final void run() {
      long l = System.currentTimeMillis();
      if (l < a.a(this.a)) {
        v.a().a(new b(this.a), a.a(this.a) - l + 5000L);
        return;
      } 
      a.b(this.a);
      this.a.a(3, false, 0L);
      this.a.a();
    }
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/biz/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */