package com.tencent.bugly.legu.crashreport.biz;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import com.tencent.bugly.legu.BuglyStrategy;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.common.strategy.StrategyBean;
import com.tencent.bugly.legu.crashreport.common.strategy.a;
import com.tencent.bugly.legu.proguard.v;
import com.tencent.bugly.legu.proguard.w;

public final class b {
  public static a a;
  
  private static boolean b;
  
  private static int c = 10;
  
  private static long d = 300000L;
  
  private static long e = 30000L;
  
  private static long f = 0L;
  
  private static int g;
  
  private static long h;
  
  private static long i;
  
  private static long j = 0L;
  
  private static Application.ActivityLifecycleCallbacks k = null;
  
  private static Class<?> l = null;
  
  public static void a() {
    if (a != null)
      a.a(2, false, 0L); 
  }
  
  public static void a(long paramLong) {
    long l = paramLong;
    if (paramLong < 0L)
      l = (a.a().c()).m; 
    f = l;
  }
  
  public static void a(Context paramContext) {
    if (b && paramContext != null) {
      Application application = null;
      if (Build.VERSION.SDK_INT >= 14) {
        if (paramContext.getApplicationContext() instanceof Application)
          application = (Application)paramContext.getApplicationContext(); 
        if (application != null)
          try {
            if (k != null)
              application.unregisterActivityLifecycleCallbacks(k); 
          } catch (Exception exception) {} 
      } 
      b = false;
    } 
  }
  
  public static void a(Context paramContext, BuglyStrategy paramBuglyStrategy) {
    if (!b) {
      long l;
      e = (a.a().c()).m;
      c = (a.a().c()).s;
      a = new a(paramContext);
      b = true;
      if (paramBuglyStrategy != null) {
        l = paramBuglyStrategy.getUserInfoActivity();
        l = paramBuglyStrategy.getAppReportDelay();
      } else {
        l = 0L;
      } 
      if (l <= 0L) {
        c(paramContext, paramBuglyStrategy);
        return;
      } 
      v.a().a(new Runnable(paramContext, paramBuglyStrategy) {
            public final void run() {
              b.b(this.a, this.b);
            }
          }l);
    } 
  }
  
  public static void a(StrategyBean paramStrategyBean) {
    if (paramStrategyBean != null) {
      if (paramStrategyBean.m > 0L)
        e = paramStrategyBean.m; 
      if (paramStrategyBean.s > 0)
        c = paramStrategyBean.s; 
      if (paramStrategyBean.t > 0L)
        d = paramStrategyBean.t; 
    } 
  }
  
  private static void c(Context paramContext, BuglyStrategy paramBuglyStrategy) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 413
    //   4: aload_1
    //   5: invokevirtual recordUserInfoOnceADay : ()Z
    //   8: istore_2
    //   9: aload_1
    //   10: invokevirtual isEnableUserInfo : ()Z
    //   13: istore_3
    //   14: iload_2
    //   15: ifeq -> 159
    //   18: aload_0
    //   19: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   22: astore_1
    //   23: aload_1
    //   24: getfield d : Ljava/lang/String;
    //   27: astore #4
    //   29: getstatic com/tencent/bugly/legu/crashreport/biz/b.a : Lcom/tencent/bugly/legu/crashreport/biz/a;
    //   32: aload #4
    //   34: invokevirtual a : (Ljava/lang/String;)Ljava/util/List;
    //   37: astore #5
    //   39: aload #5
    //   41: ifnull -> 151
    //   44: iconst_0
    //   45: istore #6
    //   47: iload #6
    //   49: aload #5
    //   51: invokeinterface size : ()I
    //   56: if_icmpge -> 151
    //   59: aload #5
    //   61: iload #6
    //   63: invokeinterface get : (I)Ljava/lang/Object;
    //   68: checkcast com/tencent/bugly/legu/crashreport/biz/UserInfoBean
    //   71: astore #4
    //   73: aload #4
    //   75: getfield n : Ljava/lang/String;
    //   78: aload_1
    //   79: getfield i : Ljava/lang/String;
    //   82: invokevirtual equals : (Ljava/lang/Object;)Z
    //   85: ifeq -> 145
    //   88: aload #4
    //   90: getfield b : I
    //   93: iconst_1
    //   94: if_icmpne -> 145
    //   97: invokestatic o : ()J
    //   100: lstore #7
    //   102: lload #7
    //   104: lconst_0
    //   105: lcmp
    //   106: ifle -> 151
    //   109: aload #4
    //   111: getfield e : J
    //   114: lload #7
    //   116: lcmp
    //   117: iflt -> 145
    //   120: aload #4
    //   122: getfield f : J
    //   125: lconst_0
    //   126: lcmp
    //   127: ifgt -> 136
    //   130: getstatic com/tencent/bugly/legu/crashreport/biz/b.a : Lcom/tencent/bugly/legu/crashreport/biz/a;
    //   133: invokevirtual b : ()V
    //   136: iconst_0
    //   137: istore #6
    //   139: iload #6
    //   141: ifne -> 157
    //   144: return
    //   145: iinc #6, 1
    //   148: goto -> 47
    //   151: iconst_1
    //   152: istore #6
    //   154: goto -> 139
    //   157: iconst_0
    //   158: istore_3
    //   159: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   162: astore #4
    //   164: aload #4
    //   166: ifnull -> 266
    //   169: iconst_0
    //   170: istore #9
    //   172: invokestatic currentThread : ()Ljava/lang/Thread;
    //   175: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   178: astore #5
    //   180: aload #5
    //   182: arraylength
    //   183: istore #10
    //   185: aconst_null
    //   186: astore_1
    //   187: iconst_0
    //   188: istore #6
    //   190: iload #6
    //   192: iload #10
    //   194: if_icmpge -> 245
    //   197: aload #5
    //   199: iload #6
    //   201: aaload
    //   202: astore #11
    //   204: aload #11
    //   206: invokevirtual getMethodName : ()Ljava/lang/String;
    //   209: ldc 'onCreate'
    //   211: invokevirtual equals : (Ljava/lang/Object;)Z
    //   214: ifeq -> 223
    //   217: aload #11
    //   219: invokevirtual getClassName : ()Ljava/lang/String;
    //   222: astore_1
    //   223: aload #11
    //   225: invokevirtual getClassName : ()Ljava/lang/String;
    //   228: ldc 'android.app.Activity'
    //   230: invokevirtual equals : (Ljava/lang/Object;)Z
    //   233: ifeq -> 239
    //   236: iconst_1
    //   237: istore #9
    //   239: iinc #6, 1
    //   242: goto -> 190
    //   245: aload_1
    //   246: ifnull -> 403
    //   249: iload #9
    //   251: ifeq -> 397
    //   254: aload #4
    //   256: iconst_1
    //   257: putfield n : Z
    //   260: aload #4
    //   262: aload_1
    //   263: putfield o : Ljava/lang/String;
    //   266: iload_3
    //   267: ifeq -> 327
    //   270: aconst_null
    //   271: astore_1
    //   272: getstatic android/os/Build$VERSION.SDK_INT : I
    //   275: bipush #14
    //   277: if_icmplt -> 327
    //   280: aload_0
    //   281: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   284: instanceof android/app/Application
    //   287: ifeq -> 298
    //   290: aload_0
    //   291: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   294: checkcast android/app/Application
    //   297: astore_1
    //   298: aload_1
    //   299: ifnull -> 327
    //   302: getstatic com/tencent/bugly/legu/crashreport/biz/b.k : Landroid/app/Application$ActivityLifecycleCallbacks;
    //   305: ifnonnull -> 320
    //   308: new com/tencent/bugly/legu/crashreport/biz/b$2
    //   311: astore_0
    //   312: aload_0
    //   313: invokespecial <init> : ()V
    //   316: aload_0
    //   317: putstatic com/tencent/bugly/legu/crashreport/biz/b.k : Landroid/app/Application$ActivityLifecycleCallbacks;
    //   320: aload_1
    //   321: getstatic com/tencent/bugly/legu/crashreport/biz/b.k : Landroid/app/Application$ActivityLifecycleCallbacks;
    //   324: invokevirtual registerActivityLifecycleCallbacks : (Landroid/app/Application$ActivityLifecycleCallbacks;)V
    //   327: invokestatic currentTimeMillis : ()J
    //   330: putstatic com/tencent/bugly/legu/crashreport/biz/b.i : J
    //   333: getstatic com/tencent/bugly/legu/crashreport/biz/b.a : Lcom/tencent/bugly/legu/crashreport/biz/a;
    //   336: iconst_1
    //   337: iconst_1
    //   338: lconst_0
    //   339: invokevirtual a : (IZJ)V
    //   342: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/t;
    //   345: sipush #1001
    //   348: invokestatic currentTimeMillis : ()J
    //   351: invokevirtual a : (IJ)V
    //   354: ldc '[session] launch app, new start'
    //   356: iconst_0
    //   357: anewarray java/lang/Object
    //   360: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   363: pop
    //   364: getstatic com/tencent/bugly/legu/crashreport/biz/b.a : Lcom/tencent/bugly/legu/crashreport/biz/a;
    //   367: invokevirtual a : ()V
    //   370: getstatic com/tencent/bugly/legu/crashreport/biz/b.a : Lcom/tencent/bugly/legu/crashreport/biz/a;
    //   373: astore_0
    //   374: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/v;
    //   377: new com/tencent/bugly/legu/crashreport/biz/a$a
    //   380: dup
    //   381: aload_0
    //   382: aconst_null
    //   383: iconst_1
    //   384: invokespecial <init> : (Lcom/tencent/bugly/legu/crashreport/biz/a;Lcom/tencent/bugly/legu/crashreport/biz/UserInfoBean;Z)V
    //   387: ldc2_w 21600000
    //   390: invokevirtual a : (Ljava/lang/Runnable;J)Z
    //   393: pop
    //   394: goto -> 144
    //   397: ldc 'background'
    //   399: astore_1
    //   400: goto -> 260
    //   403: ldc 'unknown'
    //   405: astore_1
    //   406: goto -> 260
    //   409: astore_0
    //   410: goto -> 327
    //   413: iconst_1
    //   414: istore_3
    //   415: iconst_0
    //   416: istore_2
    //   417: goto -> 14
    // Exception table:
    //   from	to	target	type
    //   302	320	409	java/lang/Exception
    //   320	327	409	java/lang/Exception
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/biz/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */