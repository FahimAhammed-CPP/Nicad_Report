package com.tencent.bugly.legu.crashreport.common.info;

import android.content.Context;
import android.content.pm.PackageInfo;
import com.tencent.bugly.legu.proguard.w;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class a {
  private static a V = null;
  
  private String A;
  
  private String B;
  
  private String C;
  
  private String D;
  
  private String E;
  
  private String F;
  
  private String G;
  
  private String H;
  
  private String I;
  
  private long J;
  
  private long K;
  
  private long L;
  
  private String M;
  
  private String N;
  
  private Map<String, PlugInBean> O;
  
  private boolean P;
  
  private String Q;
  
  private String R;
  
  private Boolean S;
  
  private String T;
  
  private Map<String, PlugInBean> U;
  
  private int W;
  
  private int X;
  
  private Map<String, String> Y;
  
  private Map<String, String> Z;
  
  public final long a;
  
  private final Object aa;
  
  private final Object ab;
  
  public final byte b;
  
  public String c;
  
  public final String d;
  
  public final String e;
  
  public final String f;
  
  public final String g;
  
  public long h;
  
  public String i;
  
  public String j;
  
  public String k;
  
  public String l;
  
  public List<String> m;
  
  public boolean n;
  
  public String o;
  
  public long p;
  
  public long q;
  
  public long r;
  
  public long s;
  
  public boolean t;
  
  public String u;
  
  public String v;
  
  public String w;
  
  public boolean x;
  
  public boolean y;
  
  private final Context z;
  
  private a(Context paramContext) {
    Context context;
    this.C = "unknown";
    this.D = "unknown";
    this.E = "";
    this.F = null;
    this.G = null;
    this.H = null;
    this.I = null;
    this.J = -1L;
    this.K = -1L;
    this.L = -1L;
    this.M = null;
    this.N = null;
    this.O = null;
    this.P = true;
    this.Q = null;
    this.i = null;
    this.R = null;
    this.j = null;
    this.S = null;
    this.T = null;
    this.k = null;
    this.l = null;
    this.U = null;
    this.m = null;
    this.W = -1;
    this.X = -1;
    this.Y = new HashMap<String, String>();
    this.Z = new HashMap<String, String>();
    this.o = "unknown";
    this.p = 0L;
    this.q = 0L;
    this.r = 0L;
    this.s = 0L;
    this.t = false;
    this.u = null;
    this.v = null;
    this.w = null;
    this.x = false;
    this.y = false;
    this.aa = new Object();
    this.ab = new Object();
    this.a = System.currentTimeMillis();
    if (paramContext == null) {
      context = paramContext;
    } else {
      Context context1 = paramContext.getApplicationContext();
      context = context1;
      if (context1 == null)
        context = paramContext; 
    } 
    this.z = context;
    this.b = (byte)1;
    PackageInfo packageInfo = AppInfo.b(paramContext);
    if (packageInfo != null) {
      this.i = AppInfo.a(packageInfo);
      this.u = this.i;
      this.v = AppInfo.b(packageInfo);
    } 
    this.c = AppInfo.a(paramContext);
    this.d = AppInfo.c(paramContext);
    this.e = com.tencent.bugly.legu.proguard.a.m();
    this.f = com.tencent.bugly.legu.proguard.a.b();
    this.g = "Android " + com.tencent.bugly.legu.proguard.a.c() + ",level " + com.tencent.bugly.legu.proguard.a.d();
    this.f + ";" + this.g;
    Map<String, String> map = AppInfo.d(paramContext);
    if (map != null)
      try {
        this.m = AppInfo.a(map);
        String str2 = map.get("BUGLY_APPID");
        if (str2 != null)
          this.R = str2; 
        str2 = map.get("BUGLY_APP_VERSION");
        if (str2 != null)
          this.i = str2; 
        str2 = map.get("BUGLY_APP_CHANNEL");
        if (str2 != null)
          this.j = str2; 
        str2 = map.get("BUGLY_ENABLE_DEBUG");
        if (str2 != null) {
          boolean bool;
          if (str2.toLowerCase().equals("true")) {
            bool = true;
          } else {
            bool = false;
          } 
          this.t = bool;
        } 
        String str1 = map.get("com.tencent.rdm.uuid");
        if (str1 != null)
          this.w = str1; 
      } catch (Throwable throwable) {} 
    try {
      if (!paramContext.getDatabasePath("bugly_db_legu").exists()) {
        this.y = true;
        w.c("App is first time to be installed on the device.", new Object[0]);
      } 
    } catch (Throwable throwable) {}
    w.c("com info create end", new Object[0]);
  }
  
  public static a a() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/common/info/a
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/crashreport/common/info/a.V : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   6: astore_0
    //   7: ldc com/tencent/bugly/legu/crashreport/common/info/a
    //   9: monitorexit
    //   10: aload_0
    //   11: areturn
    //   12: astore_0
    //   13: ldc com/tencent/bugly/legu/crashreport/common/info/a
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	12	finally
  }
  
  public static a a(Context paramContext) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/common/info/a
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/crashreport/common/info/a.V : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   6: ifnonnull -> 22
    //   9: new com/tencent/bugly/legu/crashreport/common/info/a
    //   12: astore_1
    //   13: aload_1
    //   14: aload_0
    //   15: invokespecial <init> : (Landroid/content/Context;)V
    //   18: aload_1
    //   19: putstatic com/tencent/bugly/legu/crashreport/common/info/a.V : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   22: getstatic com/tencent/bugly/legu/crashreport/common/info/a.V : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   25: astore_0
    //   26: ldc com/tencent/bugly/legu/crashreport/common/info/a
    //   28: monitorexit
    //   29: aload_0
    //   30: areturn
    //   31: astore_0
    //   32: ldc com/tencent/bugly/legu/crashreport/common/info/a
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   3	22	31	finally
    //   22	26	31	finally
  }
  
  public static String b() {
    return "2.1.9";
  }
  
  public final Map<String, String> A() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield Z : Ljava/util/Map;
    //   6: invokeinterface size : ()I
    //   11: istore_1
    //   12: iload_1
    //   13: ifgt -> 22
    //   16: aconst_null
    //   17: astore_2
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_2
    //   21: areturn
    //   22: new java/util/HashMap
    //   25: dup
    //   26: aload_0
    //   27: getfield Z : Ljava/util/Map;
    //   30: invokespecial <init> : (Ljava/util/Map;)V
    //   33: astore_2
    //   34: goto -> 18
    //   37: astore_2
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_2
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	37	finally
    //   22	34	37	finally
  }
  
  public final int B() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield W : I
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final int C() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield X : I
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final boolean D() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield z : Landroid/content/Context;
    //   6: invokestatic e : (Landroid/content/Context;)Z
    //   9: istore_1
    //   10: aload_0
    //   11: monitorexit
    //   12: iload_1
    //   13: ireturn
    //   14: astore_2
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_2
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	14	finally
  }
  
  public final Map<String, PlugInBean> E() {
    /* monitor enter ThisExpression{ObjectType{com/tencent/bugly/legu/crashreport/common/info/a}} */
    /* monitor exit ThisExpression{ObjectType{com/tencent/bugly/legu/crashreport/common/info/a}} */
    return null;
  }
  
  public final int F() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic d : ()I
    //   5: istore_1
    //   6: aload_0
    //   7: monitorexit
    //   8: iload_1
    //   9: ireturn
    //   10: astore_2
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_2
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	6	10	finally
  }
  
  public final void a(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield W : I
    //   6: istore_2
    //   7: iload_2
    //   8: iload_1
    //   9: if_icmpeq -> 45
    //   12: aload_0
    //   13: iload_1
    //   14: putfield W : I
    //   17: ldc_w 'user scene tag %d changed to tag %d'
    //   20: iconst_2
    //   21: anewarray java/lang/Object
    //   24: dup
    //   25: iconst_0
    //   26: iload_2
    //   27: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   30: aastore
    //   31: dup
    //   32: iconst_1
    //   33: aload_0
    //   34: getfield W : I
    //   37: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   40: aastore
    //   41: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   44: pop
    //   45: aload_0
    //   46: monitorexit
    //   47: return
    //   48: astore_3
    //   49: aload_0
    //   50: monitorexit
    //   51: aload_3
    //   52: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	48	finally
    //   12	45	48	finally
  }
  
  public final void a(String paramString) {
    this.R = paramString;
  }
  
  public final void a(String paramString1, String paramString2) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_1
    //   5: ifnull -> 107
    //   8: aload_1
    //   9: invokevirtual trim : ()Ljava/lang/String;
    //   12: invokevirtual length : ()I
    //   15: ifle -> 107
    //   18: iconst_0
    //   19: istore #4
    //   21: iload #4
    //   23: ifne -> 48
    //   26: aload_2
    //   27: ifnull -> 113
    //   30: aload_2
    //   31: invokevirtual trim : ()Ljava/lang/String;
    //   34: invokevirtual length : ()I
    //   37: ifle -> 113
    //   40: iload_3
    //   41: istore #4
    //   43: iload #4
    //   45: ifeq -> 119
    //   48: new java/lang/StringBuilder
    //   51: astore #5
    //   53: aload #5
    //   55: invokespecial <init> : ()V
    //   58: aload #5
    //   60: aload_1
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: invokevirtual toString : ()Ljava/lang/String;
    //   67: astore #5
    //   69: new java/lang/StringBuilder
    //   72: astore_1
    //   73: aload_1
    //   74: invokespecial <init> : ()V
    //   77: ldc_w 'key&value should not be empty %s %s'
    //   80: iconst_2
    //   81: anewarray java/lang/Object
    //   84: dup
    //   85: iconst_0
    //   86: aload #5
    //   88: aastore
    //   89: dup
    //   90: iconst_1
    //   91: aload_1
    //   92: aload_2
    //   93: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   96: invokevirtual toString : ()Ljava/lang/String;
    //   99: aastore
    //   100: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   103: pop
    //   104: aload_0
    //   105: monitorexit
    //   106: return
    //   107: iconst_1
    //   108: istore #4
    //   110: goto -> 21
    //   113: iconst_1
    //   114: istore #4
    //   116: goto -> 43
    //   119: aload_0
    //   120: getfield Y : Ljava/util/Map;
    //   123: aload_1
    //   124: aload_2
    //   125: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   130: pop
    //   131: goto -> 104
    //   134: astore_1
    //   135: aload_0
    //   136: monitorexit
    //   137: aload_1
    //   138: athrow
    // Exception table:
    //   from	to	target	type
    //   8	18	134	finally
    //   30	40	134	finally
    //   48	104	134	finally
    //   119	131	134	finally
  }
  
  public final void b(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: astore_2
    //   4: aload_1
    //   5: ifnonnull -> 12
    //   8: ldc_w '10000'
    //   11: astore_2
    //   12: new java/lang/StringBuilder
    //   15: astore_1
    //   16: aload_1
    //   17: invokespecial <init> : ()V
    //   20: aload_0
    //   21: aload_1
    //   22: aload_2
    //   23: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   26: invokevirtual toString : ()Ljava/lang/String;
    //   29: putfield C : Ljava/lang/String;
    //   32: aload_0
    //   33: monitorexit
    //   34: return
    //   35: astore_1
    //   36: aload_0
    //   37: monitorexit
    //   38: aload_1
    //   39: athrow
    // Exception table:
    //   from	to	target	type
    //   12	32	35	finally
  }
  
  public final void b(String paramString1, String paramString2) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_1
    //   5: ifnull -> 108
    //   8: aload_1
    //   9: invokevirtual trim : ()Ljava/lang/String;
    //   12: invokevirtual length : ()I
    //   15: ifle -> 108
    //   18: iconst_0
    //   19: istore #4
    //   21: iload #4
    //   23: ifne -> 48
    //   26: aload_2
    //   27: ifnull -> 114
    //   30: aload_2
    //   31: invokevirtual trim : ()Ljava/lang/String;
    //   34: invokevirtual length : ()I
    //   37: ifle -> 114
    //   40: iload_3
    //   41: istore #4
    //   43: iload #4
    //   45: ifeq -> 120
    //   48: new java/lang/StringBuilder
    //   51: astore #5
    //   53: aload #5
    //   55: invokespecial <init> : ()V
    //   58: aload #5
    //   60: aload_1
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: invokevirtual toString : ()Ljava/lang/String;
    //   67: astore_1
    //   68: new java/lang/StringBuilder
    //   71: astore #5
    //   73: aload #5
    //   75: invokespecial <init> : ()V
    //   78: ldc_w 'server key&value should not be empty %s %s'
    //   81: iconst_2
    //   82: anewarray java/lang/Object
    //   85: dup
    //   86: iconst_0
    //   87: aload_1
    //   88: aastore
    //   89: dup
    //   90: iconst_1
    //   91: aload #5
    //   93: aload_2
    //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: invokevirtual toString : ()Ljava/lang/String;
    //   100: aastore
    //   101: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   104: pop
    //   105: aload_0
    //   106: monitorexit
    //   107: return
    //   108: iconst_1
    //   109: istore #4
    //   111: goto -> 21
    //   114: iconst_1
    //   115: istore #4
    //   117: goto -> 43
    //   120: aload_0
    //   121: getfield Z : Ljava/util/Map;
    //   124: aload_1
    //   125: aload_2
    //   126: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   131: pop
    //   132: goto -> 105
    //   135: astore_1
    //   136: aload_0
    //   137: monitorexit
    //   138: aload_1
    //   139: athrow
    // Exception table:
    //   from	to	target	type
    //   8	18	135	finally
    //   30	40	135	finally
    //   48	105	135	finally
    //   120	132	135	finally
  }
  
  public final void c() {
    synchronized (this.aa) {
      this.A = UUID.randomUUID().toString();
      return;
    } 
  }
  
  public final void c(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield B : Ljava/lang/String;
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
  
  public final String d() {
    if (this.A == null)
      synchronized (this.aa) {
        if (this.A == null)
          this.A = UUID.randomUUID().toString(); 
        return this.A;
      }  
    return this.A;
  }
  
  public final void d(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/lang/StringBuilder
    //   5: astore_2
    //   6: aload_2
    //   7: invokespecial <init> : ()V
    //   10: aload_0
    //   11: aload_2
    //   12: aload_1
    //   13: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   16: invokevirtual toString : ()Ljava/lang/String;
    //   19: putfield D : Ljava/lang/String;
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	25	finally
  }
  
  public final String e() {
    String str = null;
    if (false)
      throw new NullPointerException(); 
    if (true)
      str = this.R; 
    return str;
  }
  
  public final void e(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/lang/StringBuilder
    //   5: astore_2
    //   6: aload_2
    //   7: invokespecial <init> : ()V
    //   10: aload_0
    //   11: aload_2
    //   12: aload_1
    //   13: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   16: invokevirtual toString : ()Ljava/lang/String;
    //   19: putfield E : Ljava/lang/String;
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	25	finally
  }
  
  public final String f() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield C : Ljava/lang/String;
    //   6: astore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: aload_1
    //   10: areturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final String f(String paramString) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_1
    //   5: ifnull -> 58
    //   8: aload_1
    //   9: invokevirtual trim : ()Ljava/lang/String;
    //   12: invokevirtual length : ()I
    //   15: ifle -> 58
    //   18: iload_2
    //   19: ifeq -> 63
    //   22: new java/lang/StringBuilder
    //   25: astore_3
    //   26: aload_3
    //   27: invokespecial <init> : ()V
    //   30: ldc_w 'key should not be empty %s'
    //   33: iconst_1
    //   34: anewarray java/lang/Object
    //   37: dup
    //   38: iconst_0
    //   39: aload_3
    //   40: aload_1
    //   41: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: invokevirtual toString : ()Ljava/lang/String;
    //   47: aastore
    //   48: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   51: pop
    //   52: aconst_null
    //   53: astore_1
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_1
    //   57: areturn
    //   58: iconst_1
    //   59: istore_2
    //   60: goto -> 18
    //   63: aload_0
    //   64: getfield Y : Ljava/util/Map;
    //   67: aload_1
    //   68: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   73: checkcast java/lang/String
    //   76: astore_1
    //   77: goto -> 54
    //   80: astore_1
    //   81: aload_0
    //   82: monitorexit
    //   83: aload_1
    //   84: athrow
    // Exception table:
    //   from	to	target	type
    //   8	18	80	finally
    //   22	52	80	finally
    //   63	77	80	finally
  }
  
  public final String g() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield B : Ljava/lang/String;
    //   6: ifnull -> 18
    //   9: aload_0
    //   10: getfield B : Ljava/lang/String;
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: areturn
    //   18: new java/lang/StringBuilder
    //   21: astore_1
    //   22: aload_1
    //   23: invokespecial <init> : ()V
    //   26: aload_0
    //   27: aload_1
    //   28: aload_0
    //   29: invokevirtual j : ()Ljava/lang/String;
    //   32: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   35: ldc_w '|'
    //   38: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: aload_0
    //   42: invokevirtual l : ()Ljava/lang/String;
    //   45: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   48: ldc_w '|'
    //   51: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   54: aload_0
    //   55: invokevirtual m : ()Ljava/lang/String;
    //   58: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: invokevirtual toString : ()Ljava/lang/String;
    //   64: putfield B : Ljava/lang/String;
    //   67: aload_0
    //   68: getfield B : Ljava/lang/String;
    //   71: astore_1
    //   72: goto -> 14
    //   75: astore_1
    //   76: aload_0
    //   77: monitorexit
    //   78: aload_1
    //   79: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	75	finally
    //   18	72	75	finally
  }
  
  public final String g(String paramString) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_1
    //   5: ifnull -> 58
    //   8: aload_1
    //   9: invokevirtual trim : ()Ljava/lang/String;
    //   12: invokevirtual length : ()I
    //   15: ifle -> 58
    //   18: iload_2
    //   19: ifeq -> 63
    //   22: new java/lang/StringBuilder
    //   25: astore_3
    //   26: aload_3
    //   27: invokespecial <init> : ()V
    //   30: ldc_w 'key should not be empty %s'
    //   33: iconst_1
    //   34: anewarray java/lang/Object
    //   37: dup
    //   38: iconst_0
    //   39: aload_3
    //   40: aload_1
    //   41: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: invokevirtual toString : ()Ljava/lang/String;
    //   47: aastore
    //   48: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   51: pop
    //   52: aconst_null
    //   53: astore_1
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_1
    //   57: areturn
    //   58: iconst_1
    //   59: istore_2
    //   60: goto -> 18
    //   63: aload_0
    //   64: getfield Y : Ljava/util/Map;
    //   67: aload_1
    //   68: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   73: checkcast java/lang/String
    //   76: astore_1
    //   77: goto -> 54
    //   80: astore_1
    //   81: aload_0
    //   82: monitorexit
    //   83: aload_1
    //   84: athrow
    // Exception table:
    //   from	to	target	type
    //   8	18	80	finally
    //   22	52	80	finally
    //   63	77	80	finally
  }
  
  public final String h() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield D : Ljava/lang/String;
    //   6: astore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: aload_1
    //   10: areturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final String i() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield E : Ljava/lang/String;
    //   6: astore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: aload_1
    //   10: areturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final String j() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield P : Z
    //   6: ifne -> 16
    //   9: ldc ''
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: aload_0
    //   17: getfield F : Ljava/lang/String;
    //   20: ifnonnull -> 34
    //   23: aload_0
    //   24: aload_0
    //   25: getfield z : Landroid/content/Context;
    //   28: invokestatic a : (Landroid/content/Context;)Ljava/lang/String;
    //   31: putfield F : Ljava/lang/String;
    //   34: aload_0
    //   35: getfield F : Ljava/lang/String;
    //   38: astore_1
    //   39: goto -> 12
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	42	finally
    //   16	34	42	finally
    //   34	39	42	finally
  }
  
  public final String k() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield P : Z
    //   6: ifne -> 16
    //   9: ldc ''
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: aload_0
    //   17: getfield G : Ljava/lang/String;
    //   20: ifnonnull -> 34
    //   23: aload_0
    //   24: aload_0
    //   25: getfield z : Landroid/content/Context;
    //   28: invokestatic d : (Landroid/content/Context;)Ljava/lang/String;
    //   31: putfield G : Ljava/lang/String;
    //   34: aload_0
    //   35: getfield G : Ljava/lang/String;
    //   38: astore_1
    //   39: goto -> 12
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	42	finally
    //   16	34	42	finally
    //   34	39	42	finally
  }
  
  public final String l() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield P : Z
    //   6: ifne -> 16
    //   9: ldc ''
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: aload_0
    //   17: getfield H : Ljava/lang/String;
    //   20: ifnonnull -> 34
    //   23: aload_0
    //   24: aload_0
    //   25: getfield z : Landroid/content/Context;
    //   28: invokestatic b : (Landroid/content/Context;)Ljava/lang/String;
    //   31: putfield H : Ljava/lang/String;
    //   34: aload_0
    //   35: getfield H : Ljava/lang/String;
    //   38: astore_1
    //   39: goto -> 12
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	42	finally
    //   16	34	42	finally
    //   34	39	42	finally
  }
  
  public final String m() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield P : Z
    //   6: ifne -> 16
    //   9: ldc ''
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: aload_0
    //   17: getfield I : Ljava/lang/String;
    //   20: ifnonnull -> 34
    //   23: aload_0
    //   24: aload_0
    //   25: getfield z : Landroid/content/Context;
    //   28: invokestatic c : (Landroid/content/Context;)Ljava/lang/String;
    //   31: putfield I : Ljava/lang/String;
    //   34: aload_0
    //   35: getfield I : Ljava/lang/String;
    //   38: astore_1
    //   39: goto -> 12
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	42	finally
    //   16	34	42	finally
    //   34	39	42	finally
  }
  
  public final long n() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield J : J
    //   6: lconst_0
    //   7: lcmp
    //   8: ifgt -> 18
    //   11: aload_0
    //   12: invokestatic f : ()J
    //   15: putfield J : J
    //   18: aload_0
    //   19: getfield J : J
    //   22: lstore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: lload_1
    //   26: lreturn
    //   27: astore_3
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_3
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	27	finally
    //   18	23	27	finally
  }
  
  public final long o() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield K : J
    //   6: lconst_0
    //   7: lcmp
    //   8: ifgt -> 18
    //   11: aload_0
    //   12: invokestatic h : ()J
    //   15: putfield K : J
    //   18: aload_0
    //   19: getfield K : J
    //   22: lstore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: lload_1
    //   26: lreturn
    //   27: astore_3
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_3
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	27	finally
    //   18	23	27	finally
  }
  
  public final long p() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield L : J
    //   6: lconst_0
    //   7: lcmp
    //   8: ifgt -> 18
    //   11: aload_0
    //   12: invokestatic j : ()J
    //   15: putfield L : J
    //   18: aload_0
    //   19: getfield L : J
    //   22: lstore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: lload_1
    //   26: lreturn
    //   27: astore_3
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_3
    //   31: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	27	finally
    //   18	23	27	finally
  }
  
  public final String q() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield M : Ljava/lang/String;
    //   6: ifnonnull -> 16
    //   9: aload_0
    //   10: invokestatic e : ()Ljava/lang/String;
    //   13: putfield M : Ljava/lang/String;
    //   16: aload_0
    //   17: getfield M : Ljava/lang/String;
    //   20: astore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_1
    //   24: areturn
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	25	finally
    //   16	21	25	finally
  }
  
  public final String r() {
    if (this.N == null)
      synchronized (this.ab) {
        if (this.N == null)
          this.N = com.tencent.bugly.legu.proguard.a.a(this.z, "ro.board.platform"); 
        return this.N;
      }  
    return this.N;
  }
  
  public final Map<String, PlugInBean> s() {
    /* monitor enter ThisExpression{ObjectType{com/tencent/bugly/legu/crashreport/common/info/a}} */
    /* monitor exit ThisExpression{ObjectType{com/tencent/bugly/legu/crashreport/common/info/a}} */
    return null;
  }
  
  public final String t() {
    if (this.Q == null)
      this.Q = com.tencent.bugly.legu.proguard.a.l(); 
    return this.Q;
  }
  
  public final Boolean u() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield S : Ljava/lang/Boolean;
    //   6: ifnonnull -> 23
    //   9: aload_0
    //   10: aload_0
    //   11: getfield z : Landroid/content/Context;
    //   14: invokestatic f : (Landroid/content/Context;)Z
    //   17: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   20: putfield S : Ljava/lang/Boolean;
    //   23: aload_0
    //   24: getfield S : Ljava/lang/Boolean;
    //   27: astore_1
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_1
    //   31: areturn
    //   32: astore_1
    //   33: aload_0
    //   34: monitorexit
    //   35: aload_1
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   2	23	32	finally
    //   23	28	32	finally
  }
  
  public final String v() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield T : Ljava/lang/String;
    //   8: ifnonnull -> 119
    //   11: new java/lang/StringBuilder
    //   14: astore_2
    //   15: aload_2
    //   16: invokespecial <init> : ()V
    //   19: aload_0
    //   20: getfield z : Landroid/content/Context;
    //   23: astore_3
    //   24: aload_3
    //   25: ldc_w 'ro.miui.ui.version.name'
    //   28: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   31: astore #4
    //   33: aload #4
    //   35: ifnull -> 128
    //   38: aload #4
    //   40: invokevirtual trim : ()Ljava/lang/String;
    //   43: invokevirtual length : ()I
    //   46: ifle -> 128
    //   49: iconst_0
    //   50: istore #5
    //   52: iload #5
    //   54: ifne -> 134
    //   57: aload #4
    //   59: ldc_w 'fail'
    //   62: invokevirtual equals : (Ljava/lang/Object;)Z
    //   65: ifne -> 134
    //   68: new java/lang/StringBuilder
    //   71: astore_3
    //   72: aload_3
    //   73: ldc_w 'XiaoMi/MIUI/'
    //   76: invokespecial <init> : (Ljava/lang/String;)V
    //   79: aload_3
    //   80: aload #4
    //   82: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   85: invokevirtual toString : ()Ljava/lang/String;
    //   88: astore_3
    //   89: aload_0
    //   90: aload_2
    //   91: aload_3
    //   92: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: invokevirtual toString : ()Ljava/lang/String;
    //   98: putfield T : Ljava/lang/String;
    //   101: ldc_w 'rom:%s'
    //   104: iconst_1
    //   105: anewarray java/lang/Object
    //   108: dup
    //   109: iconst_0
    //   110: aload_0
    //   111: getfield T : Ljava/lang/String;
    //   114: aastore
    //   115: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   118: pop
    //   119: aload_0
    //   120: getfield T : Ljava/lang/String;
    //   123: astore_3
    //   124: aload_0
    //   125: monitorexit
    //   126: aload_3
    //   127: areturn
    //   128: iconst_1
    //   129: istore #5
    //   131: goto -> 52
    //   134: aload_3
    //   135: ldc_w 'ro.build.version.emui'
    //   138: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   141: astore #4
    //   143: aload #4
    //   145: ifnull -> 202
    //   148: aload #4
    //   150: invokevirtual trim : ()Ljava/lang/String;
    //   153: invokevirtual length : ()I
    //   156: ifle -> 202
    //   159: iconst_0
    //   160: istore #5
    //   162: iload #5
    //   164: ifne -> 208
    //   167: aload #4
    //   169: ldc_w 'fail'
    //   172: invokevirtual equals : (Ljava/lang/Object;)Z
    //   175: ifne -> 208
    //   178: new java/lang/StringBuilder
    //   181: astore_3
    //   182: aload_3
    //   183: ldc_w 'HuaWei/EMOTION/'
    //   186: invokespecial <init> : (Ljava/lang/String;)V
    //   189: aload_3
    //   190: aload #4
    //   192: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   195: invokevirtual toString : ()Ljava/lang/String;
    //   198: astore_3
    //   199: goto -> 89
    //   202: iconst_1
    //   203: istore #5
    //   205: goto -> 162
    //   208: aload_3
    //   209: ldc_w 'ro.lenovo.series'
    //   212: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   215: astore #4
    //   217: aload #4
    //   219: ifnull -> 286
    //   222: aload #4
    //   224: invokevirtual trim : ()Ljava/lang/String;
    //   227: invokevirtual length : ()I
    //   230: ifle -> 286
    //   233: iconst_0
    //   234: istore #5
    //   236: iload #5
    //   238: ifne -> 292
    //   241: aload #4
    //   243: ldc_w 'fail'
    //   246: invokevirtual equals : (Ljava/lang/Object;)Z
    //   249: ifne -> 292
    //   252: aload_3
    //   253: ldc_w 'ro.build.version.incremental'
    //   256: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   259: astore_3
    //   260: new java/lang/StringBuilder
    //   263: astore #4
    //   265: aload #4
    //   267: ldc_w 'Lenovo/VIBE/'
    //   270: invokespecial <init> : (Ljava/lang/String;)V
    //   273: aload #4
    //   275: aload_3
    //   276: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   279: invokevirtual toString : ()Ljava/lang/String;
    //   282: astore_3
    //   283: goto -> 89
    //   286: iconst_1
    //   287: istore #5
    //   289: goto -> 236
    //   292: aload_3
    //   293: ldc_w 'ro.build.nubia.rom.name'
    //   296: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   299: astore #4
    //   301: aload #4
    //   303: ifnull -> 379
    //   306: aload #4
    //   308: invokevirtual trim : ()Ljava/lang/String;
    //   311: invokevirtual length : ()I
    //   314: ifle -> 379
    //   317: iconst_0
    //   318: istore #5
    //   320: iload #5
    //   322: ifne -> 385
    //   325: aload #4
    //   327: ldc_w 'fail'
    //   330: invokevirtual equals : (Ljava/lang/Object;)Z
    //   333: ifne -> 385
    //   336: new java/lang/StringBuilder
    //   339: astore #6
    //   341: aload #6
    //   343: ldc_w 'Zte/NUBIA/'
    //   346: invokespecial <init> : (Ljava/lang/String;)V
    //   349: aload #6
    //   351: aload #4
    //   353: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   356: ldc_w '_'
    //   359: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   362: aload_3
    //   363: ldc_w 'ro.build.nubia.rom.code'
    //   366: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   369: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   372: invokevirtual toString : ()Ljava/lang/String;
    //   375: astore_3
    //   376: goto -> 89
    //   379: iconst_1
    //   380: istore #5
    //   382: goto -> 320
    //   385: aload_3
    //   386: ldc_w 'ro.meizu.product.model'
    //   389: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   392: astore #4
    //   394: aload #4
    //   396: ifnull -> 461
    //   399: aload #4
    //   401: invokevirtual trim : ()Ljava/lang/String;
    //   404: invokevirtual length : ()I
    //   407: ifle -> 461
    //   410: iconst_0
    //   411: istore #5
    //   413: iload #5
    //   415: ifne -> 467
    //   418: aload #4
    //   420: ldc_w 'fail'
    //   423: invokevirtual equals : (Ljava/lang/Object;)Z
    //   426: ifne -> 467
    //   429: new java/lang/StringBuilder
    //   432: astore #4
    //   434: aload #4
    //   436: ldc_w 'Meizu/FLYME/'
    //   439: invokespecial <init> : (Ljava/lang/String;)V
    //   442: aload #4
    //   444: aload_3
    //   445: ldc_w 'ro.build.display.id'
    //   448: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   451: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   454: invokevirtual toString : ()Ljava/lang/String;
    //   457: astore_3
    //   458: goto -> 89
    //   461: iconst_1
    //   462: istore #5
    //   464: goto -> 413
    //   467: aload_3
    //   468: ldc_w 'ro.build.version.opporom'
    //   471: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   474: astore #4
    //   476: aload #4
    //   478: ifnull -> 535
    //   481: aload #4
    //   483: invokevirtual trim : ()Ljava/lang/String;
    //   486: invokevirtual length : ()I
    //   489: ifle -> 535
    //   492: iconst_0
    //   493: istore #5
    //   495: iload #5
    //   497: ifne -> 541
    //   500: aload #4
    //   502: ldc_w 'fail'
    //   505: invokevirtual equals : (Ljava/lang/Object;)Z
    //   508: ifne -> 541
    //   511: new java/lang/StringBuilder
    //   514: astore_3
    //   515: aload_3
    //   516: ldc_w 'Oppo/COLOROS/'
    //   519: invokespecial <init> : (Ljava/lang/String;)V
    //   522: aload_3
    //   523: aload #4
    //   525: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   528: invokevirtual toString : ()Ljava/lang/String;
    //   531: astore_3
    //   532: goto -> 89
    //   535: iconst_1
    //   536: istore #5
    //   538: goto -> 495
    //   541: aload_3
    //   542: ldc_w 'ro.vivo.os.build.display.id'
    //   545: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   548: astore #4
    //   550: aload #4
    //   552: ifnull -> 609
    //   555: aload #4
    //   557: invokevirtual trim : ()Ljava/lang/String;
    //   560: invokevirtual length : ()I
    //   563: ifle -> 609
    //   566: iconst_0
    //   567: istore #5
    //   569: iload #5
    //   571: ifne -> 615
    //   574: aload #4
    //   576: ldc_w 'fail'
    //   579: invokevirtual equals : (Ljava/lang/Object;)Z
    //   582: ifne -> 615
    //   585: new java/lang/StringBuilder
    //   588: astore_3
    //   589: aload_3
    //   590: ldc_w 'vivo/FUNTOUCH/'
    //   593: invokespecial <init> : (Ljava/lang/String;)V
    //   596: aload_3
    //   597: aload #4
    //   599: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   602: invokevirtual toString : ()Ljava/lang/String;
    //   605: astore_3
    //   606: goto -> 89
    //   609: iconst_1
    //   610: istore #5
    //   612: goto -> 569
    //   615: aload_3
    //   616: ldc_w 'ro.aa.romver'
    //   619: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   622: astore #4
    //   624: aload #4
    //   626: ifnull -> 702
    //   629: aload #4
    //   631: invokevirtual trim : ()Ljava/lang/String;
    //   634: invokevirtual length : ()I
    //   637: ifle -> 702
    //   640: iconst_0
    //   641: istore #5
    //   643: iload #5
    //   645: ifne -> 708
    //   648: aload #4
    //   650: ldc_w 'fail'
    //   653: invokevirtual equals : (Ljava/lang/Object;)Z
    //   656: ifne -> 708
    //   659: new java/lang/StringBuilder
    //   662: astore #6
    //   664: aload #6
    //   666: ldc_w 'htc/'
    //   669: invokespecial <init> : (Ljava/lang/String;)V
    //   672: aload #6
    //   674: aload #4
    //   676: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   679: ldc_w '/'
    //   682: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   685: aload_3
    //   686: ldc_w 'ro.build.description'
    //   689: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   692: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   695: invokevirtual toString : ()Ljava/lang/String;
    //   698: astore_3
    //   699: goto -> 89
    //   702: iconst_1
    //   703: istore #5
    //   705: goto -> 643
    //   708: aload_3
    //   709: ldc_w 'ro.lewa.version'
    //   712: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   715: astore #4
    //   717: aload #4
    //   719: ifnull -> 795
    //   722: aload #4
    //   724: invokevirtual trim : ()Ljava/lang/String;
    //   727: invokevirtual length : ()I
    //   730: ifle -> 795
    //   733: iconst_0
    //   734: istore #5
    //   736: iload #5
    //   738: ifne -> 801
    //   741: aload #4
    //   743: ldc_w 'fail'
    //   746: invokevirtual equals : (Ljava/lang/Object;)Z
    //   749: ifne -> 801
    //   752: new java/lang/StringBuilder
    //   755: astore #6
    //   757: aload #6
    //   759: ldc_w 'tcl/'
    //   762: invokespecial <init> : (Ljava/lang/String;)V
    //   765: aload #6
    //   767: aload #4
    //   769: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   772: ldc_w '/'
    //   775: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   778: aload_3
    //   779: ldc_w 'ro.build.display.id'
    //   782: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   785: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   788: invokevirtual toString : ()Ljava/lang/String;
    //   791: astore_3
    //   792: goto -> 89
    //   795: iconst_1
    //   796: istore #5
    //   798: goto -> 736
    //   801: aload_3
    //   802: ldc_w 'ro.gn.gnromvernumber'
    //   805: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   808: astore #4
    //   810: aload #4
    //   812: ifnull -> 888
    //   815: aload #4
    //   817: invokevirtual trim : ()Ljava/lang/String;
    //   820: invokevirtual length : ()I
    //   823: ifle -> 888
    //   826: iconst_0
    //   827: istore #5
    //   829: iload #5
    //   831: ifne -> 894
    //   834: aload #4
    //   836: ldc_w 'fail'
    //   839: invokevirtual equals : (Ljava/lang/Object;)Z
    //   842: ifne -> 894
    //   845: new java/lang/StringBuilder
    //   848: astore #6
    //   850: aload #6
    //   852: ldc_w 'amigo/'
    //   855: invokespecial <init> : (Ljava/lang/String;)V
    //   858: aload #6
    //   860: aload #4
    //   862: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   865: ldc_w '/'
    //   868: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   871: aload_3
    //   872: ldc_w 'ro.build.display.id'
    //   875: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   878: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   881: invokevirtual toString : ()Ljava/lang/String;
    //   884: astore_3
    //   885: goto -> 89
    //   888: iconst_1
    //   889: istore #5
    //   891: goto -> 829
    //   894: aload_3
    //   895: ldc_w 'ro.build.tyd.kbstyle_version'
    //   898: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   901: astore #4
    //   903: aload #4
    //   905: ifnull -> 962
    //   908: aload #4
    //   910: invokevirtual trim : ()Ljava/lang/String;
    //   913: invokevirtual length : ()I
    //   916: ifle -> 962
    //   919: iload_1
    //   920: istore #5
    //   922: iload #5
    //   924: ifne -> 968
    //   927: aload #4
    //   929: ldc_w 'fail'
    //   932: invokevirtual equals : (Ljava/lang/Object;)Z
    //   935: ifne -> 968
    //   938: new java/lang/StringBuilder
    //   941: astore_3
    //   942: aload_3
    //   943: ldc_w 'dido/'
    //   946: invokespecial <init> : (Ljava/lang/String;)V
    //   949: aload_3
    //   950: aload #4
    //   952: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   955: invokevirtual toString : ()Ljava/lang/String;
    //   958: astore_3
    //   959: goto -> 89
    //   962: iconst_1
    //   963: istore #5
    //   965: goto -> 922
    //   968: new java/lang/StringBuilder
    //   971: astore #4
    //   973: aload #4
    //   975: invokespecial <init> : ()V
    //   978: aload #4
    //   980: aload_3
    //   981: ldc_w 'ro.build.fingerprint'
    //   984: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   987: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   990: ldc_w '/'
    //   993: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   996: aload_3
    //   997: ldc_w 'ro.build.rom.id'
    //   1000: invokestatic a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   1003: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1006: invokevirtual toString : ()Ljava/lang/String;
    //   1009: astore_3
    //   1010: goto -> 89
    //   1013: astore_3
    //   1014: aload_0
    //   1015: monitorexit
    //   1016: aload_3
    //   1017: athrow
    // Exception table:
    //   from	to	target	type
    //   4	33	1013	finally
    //   38	49	1013	finally
    //   57	89	1013	finally
    //   89	119	1013	finally
    //   119	124	1013	finally
    //   134	143	1013	finally
    //   148	159	1013	finally
    //   167	199	1013	finally
    //   208	217	1013	finally
    //   222	233	1013	finally
    //   241	283	1013	finally
    //   292	301	1013	finally
    //   306	317	1013	finally
    //   325	376	1013	finally
    //   385	394	1013	finally
    //   399	410	1013	finally
    //   418	458	1013	finally
    //   467	476	1013	finally
    //   481	492	1013	finally
    //   500	532	1013	finally
    //   541	550	1013	finally
    //   555	566	1013	finally
    //   574	606	1013	finally
    //   615	624	1013	finally
    //   629	640	1013	finally
    //   648	699	1013	finally
    //   708	717	1013	finally
    //   722	733	1013	finally
    //   741	792	1013	finally
    //   801	810	1013	finally
    //   815	826	1013	finally
    //   834	885	1013	finally
    //   894	903	1013	finally
    //   908	919	1013	finally
    //   927	959	1013	finally
    //   968	1010	1013	finally
  }
  
  public final Map<String, String> w() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield Y : Ljava/util/Map;
    //   6: invokeinterface size : ()I
    //   11: istore_1
    //   12: iload_1
    //   13: ifgt -> 22
    //   16: aconst_null
    //   17: astore_2
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_2
    //   21: areturn
    //   22: new java/util/HashMap
    //   25: dup
    //   26: aload_0
    //   27: getfield Y : Ljava/util/Map;
    //   30: invokespecial <init> : (Ljava/util/Map;)V
    //   33: astore_2
    //   34: goto -> 18
    //   37: astore_2
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_2
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	37	finally
    //   22	34	37	finally
  }
  
  public final void x() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield Y : Ljava/util/Map;
    //   6: invokeinterface clear : ()V
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  public final int y() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield Y : Ljava/util/Map;
    //   6: invokeinterface size : ()I
    //   11: istore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: iload_1
    //   15: ireturn
    //   16: astore_2
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_2
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public final Set<String> z() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield Y : Ljava/util/Map;
    //   6: invokeinterface keySet : ()Ljava/util/Set;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/common/info/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */