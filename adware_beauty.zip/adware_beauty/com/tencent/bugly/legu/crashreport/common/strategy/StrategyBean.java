package com.tencent.bugly.legu.crashreport.common.strategy;

import android.os.Parcel;
import android.os.Parcelable;
import com.tencent.bugly.legu.proguard.a;
import java.util.Map;

public class StrategyBean implements Parcelable {
  public static final Parcelable.Creator<StrategyBean> CREATOR;
  
  public static String a;
  
  private static String u = "http://android.bugly.qq.com/rqd/async";
  
  private static String v = "http://android.bugly.qq.com/rqd/async";
  
  private static String w = "http://rqd.uu.qq.com/rqd/sync";
  
  public long b = -1L;
  
  public long c = -1L;
  
  public boolean d = true;
  
  public boolean e = true;
  
  public boolean f = true;
  
  public boolean g = true;
  
  public boolean h = true;
  
  public boolean i = true;
  
  public boolean j = true;
  
  public boolean k = true;
  
  public long l;
  
  public long m = 30000L;
  
  public String n = u;
  
  public String o = v;
  
  public String p = w;
  
  public String q;
  
  public Map<String, String> r;
  
  public int s = 10;
  
  public long t = 300000L;
  
  static {
    CREATOR = new Parcelable.Creator<StrategyBean>() {
      
      };
  }
  
  public StrategyBean() {
    this.c = System.currentTimeMillis();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("S(@L@L").append("@)");
    a = stringBuilder.toString();
    stringBuilder.setLength(0);
    stringBuilder.append("*^@K#K").append("@!");
    this.q = stringBuilder.toString();
  }
  
  public StrategyBean(Parcel paramParcel) {
    try {
      boolean bool1;
      StringBuilder stringBuilder = new StringBuilder();
      this();
      stringBuilder.append("S(@L@L").append("@)");
      a = stringBuilder.toString();
      this.c = paramParcel.readLong();
      if (paramParcel.readByte() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.d = bool1;
      if (paramParcel.readByte() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.e = bool1;
      if (paramParcel.readByte() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.f = bool1;
      this.n = paramParcel.readString();
      this.o = paramParcel.readString();
      this.q = paramParcel.readString();
      this.r = a.b(paramParcel);
      if (paramParcel.readByte() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.g = bool1;
      if (paramParcel.readByte() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.j = bool1;
      if (paramParcel.readByte() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.k = bool1;
      this.m = paramParcel.readLong();
      if (paramParcel.readByte() == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      this.h = bool1;
      if (paramParcel.readByte() == 1) {
        bool1 = bool;
      } else {
        bool1 = false;
      } 
      this.i = bool1;
      this.l = paramParcel.readLong();
      this.s = paramParcel.readInt();
      this.t = paramParcel.readLong();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public int describeContents() {
    return 0;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    boolean bool = true;
    paramParcel.writeLong(this.c);
    if (this.d) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    paramParcel.writeByte((byte)paramInt);
    if (this.e) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    paramParcel.writeByte((byte)paramInt);
    if (this.f) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    paramParcel.writeByte((byte)paramInt);
    paramParcel.writeString(this.n);
    paramParcel.writeString(this.o);
    paramParcel.writeString(this.q);
    a.b(paramParcel, this.r);
    if (this.g) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    paramParcel.writeByte((byte)paramInt);
    if (this.j) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    paramParcel.writeByte((byte)paramInt);
    if (this.k) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    paramParcel.writeByte((byte)paramInt);
    paramParcel.writeLong(this.m);
    if (this.h) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    paramParcel.writeByte((byte)paramInt);
    if (this.i) {
      paramInt = bool;
    } else {
      paramInt = 0;
    } 
    paramParcel.writeByte((byte)paramInt);
    paramParcel.writeLong(this.l);
    paramParcel.writeInt(this.s);
    paramParcel.writeLong(this.t);
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/common/strategy/StrategyBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */