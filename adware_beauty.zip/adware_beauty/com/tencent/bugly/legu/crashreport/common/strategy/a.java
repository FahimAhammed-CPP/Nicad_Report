package com.tencent.bugly.legu.crashreport.common.strategy;

import android.content.Context;
import com.tencent.bugly.legu.crashreport.biz.b;
import com.tencent.bugly.legu.proguard.ap;
import com.tencent.bugly.legu.proguard.o;
import com.tencent.bugly.legu.proguard.q;
import com.tencent.bugly.legu.proguard.v;
import com.tencent.bugly.legu.proguard.w;
import java.util.List;
import java.util.Map;

public final class a {
  public static int a = 1000;
  
  private static a b = null;
  
  private final List<com.tencent.bugly.legu.a> c;
  
  private final v d;
  
  private final StrategyBean e;
  
  private StrategyBean f = null;
  
  private Context g;
  
  private a(Context paramContext, List<com.tencent.bugly.legu.a> paramList) {
    this.g = paramContext;
    this.e = new StrategyBean();
    this.c = paramList;
    this.d = v.a();
    this.d.b(new Thread(this) {
          public final void run() {
            try {
              Map map = o.a().a(a.a, null, true);
              if (map != null) {
                byte[] arrayOfByte2 = (byte[])map.get("key_imei");
                byte[] arrayOfByte1 = (byte[])map.get("key_ip");
                if (arrayOfByte2 != null) {
                  com.tencent.bugly.legu.crashreport.common.info.a a2 = com.tencent.bugly.legu.crashreport.common.info.a.a(a.a(this.a));
                  String str = new String();
                  this(arrayOfByte2);
                  a2.e(str);
                } 
                if (arrayOfByte1 != null) {
                  com.tencent.bugly.legu.crashreport.common.info.a a2 = com.tencent.bugly.legu.crashreport.common.info.a.a(a.a(this.a));
                  String str = new String();
                  this(arrayOfByte1);
                  a2.d(str);
                } 
              } 
              a a1 = this.a;
              StrategyBean strategyBean = a.d();
              a.a(this.a, strategyBean);
              this.a.a(a.b(this.a));
            } catch (Throwable throwable) {}
          }
        });
  }
  
  public static a a() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/common/strategy/a
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/crashreport/common/strategy/a.b : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   6: astore_0
    //   7: ldc com/tencent/bugly/legu/crashreport/common/strategy/a
    //   9: monitorexit
    //   10: aload_0
    //   11: areturn
    //   12: astore_0
    //   13: ldc com/tencent/bugly/legu/crashreport/common/strategy/a
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	12	finally
  }
  
  public static a a(Context paramContext, List<com.tencent.bugly.legu.a> paramList) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/common/strategy/a
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/crashreport/common/strategy/a.b : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   6: ifnonnull -> 23
    //   9: new com/tencent/bugly/legu/crashreport/common/strategy/a
    //   12: astore_2
    //   13: aload_2
    //   14: aload_0
    //   15: aload_1
    //   16: invokespecial <init> : (Landroid/content/Context;Ljava/util/List;)V
    //   19: aload_2
    //   20: putstatic com/tencent/bugly/legu/crashreport/common/strategy/a.b : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   23: getstatic com/tencent/bugly/legu/crashreport/common/strategy/a.b : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   26: astore_0
    //   27: ldc com/tencent/bugly/legu/crashreport/common/strategy/a
    //   29: monitorexit
    //   30: aload_0
    //   31: areturn
    //   32: astore_0
    //   33: ldc com/tencent/bugly/legu/crashreport/common/strategy/a
    //   35: monitorexit
    //   36: aload_0
    //   37: athrow
    // Exception table:
    //   from	to	target	type
    //   3	23	32	finally
    //   23	27	32	finally
  }
  
  public static StrategyBean d() {
    null = o.a().a(2);
    if (null != null && null.size() > 0) {
      q q = null.get(0);
      if (q.g != null)
        return (StrategyBean)com.tencent.bugly.legu.proguard.a.a(q.g, StrategyBean.CREATOR); 
    } 
    return null;
  }
  
  protected final void a(StrategyBean paramStrategyBean) {
    for (com.tencent.bugly.legu.a a1 : this.c) {
      try {
        w.c("[strategy] Notify %s", new Object[] { a1.getClass().getName() });
        a1.onServerStrategyChanged(paramStrategyBean);
      } catch (Throwable throwable) {
        if (!w.a(throwable))
          throwable.printStackTrace(); 
      } 
    } 
    b.a(paramStrategyBean);
  }
  
  public final void a(ap paramap) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_0
    //   6: getfield f : Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   9: ifnull -> 27
    //   12: aload_1
    //   13: getfield h : J
    //   16: aload_0
    //   17: getfield f : Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   20: getfield l : J
    //   23: lcmp
    //   24: ifeq -> 4
    //   27: new com/tencent/bugly/legu/crashreport/common/strategy/StrategyBean
    //   30: dup
    //   31: invokespecial <init> : ()V
    //   34: astore_2
    //   35: aload_2
    //   36: aload_1
    //   37: getfield a : Z
    //   40: putfield d : Z
    //   43: aload_2
    //   44: aload_1
    //   45: getfield c : Z
    //   48: putfield f : Z
    //   51: aload_2
    //   52: aload_1
    //   53: getfield b : Z
    //   56: putfield e : Z
    //   59: aload_1
    //   60: getfield d : Ljava/lang/String;
    //   63: astore_3
    //   64: aload_3
    //   65: ifnull -> 574
    //   68: aload_3
    //   69: invokevirtual trim : ()Ljava/lang/String;
    //   72: invokevirtual length : ()I
    //   75: ifle -> 574
    //   78: iconst_0
    //   79: istore #4
    //   81: iload #4
    //   83: ifne -> 111
    //   86: ldc 'upload url changes to %s'
    //   88: iconst_1
    //   89: anewarray java/lang/Object
    //   92: dup
    //   93: iconst_0
    //   94: aload_1
    //   95: getfield d : Ljava/lang/String;
    //   98: aastore
    //   99: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   102: pop
    //   103: aload_2
    //   104: aload_1
    //   105: getfield d : Ljava/lang/String;
    //   108: putfield n : Ljava/lang/String;
    //   111: aload_1
    //   112: getfield e : Ljava/lang/String;
    //   115: astore_3
    //   116: aload_3
    //   117: ifnull -> 580
    //   120: aload_3
    //   121: invokevirtual trim : ()Ljava/lang/String;
    //   124: invokevirtual length : ()I
    //   127: ifle -> 580
    //   130: iconst_0
    //   131: istore #4
    //   133: iload #4
    //   135: ifne -> 163
    //   138: ldc 'exception upload url changes to %s'
    //   140: iconst_1
    //   141: anewarray java/lang/Object
    //   144: dup
    //   145: iconst_0
    //   146: aload_1
    //   147: getfield e : Ljava/lang/String;
    //   150: aastore
    //   151: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   154: pop
    //   155: aload_2
    //   156: aload_1
    //   157: getfield e : Ljava/lang/String;
    //   160: putfield o : Ljava/lang/String;
    //   163: aload_1
    //   164: getfield f : Lcom/tencent/bugly/legu/proguard/ao;
    //   167: ifnull -> 211
    //   170: aload_1
    //   171: getfield f : Lcom/tencent/bugly/legu/proguard/ao;
    //   174: getfield a : Ljava/lang/String;
    //   177: astore_3
    //   178: aload_3
    //   179: ifnull -> 586
    //   182: aload_3
    //   183: invokevirtual trim : ()Ljava/lang/String;
    //   186: invokevirtual length : ()I
    //   189: ifle -> 586
    //   192: iconst_0
    //   193: istore #4
    //   195: iload #4
    //   197: ifne -> 211
    //   200: aload_2
    //   201: aload_1
    //   202: getfield f : Lcom/tencent/bugly/legu/proguard/ao;
    //   205: getfield a : Ljava/lang/String;
    //   208: putfield q : Ljava/lang/String;
    //   211: aload_1
    //   212: getfield h : J
    //   215: lconst_0
    //   216: lcmp
    //   217: ifeq -> 228
    //   220: aload_2
    //   221: aload_1
    //   222: getfield h : J
    //   225: putfield l : J
    //   228: aload_1
    //   229: getfield g : Ljava/util/Map;
    //   232: ifnull -> 382
    //   235: aload_1
    //   236: getfield g : Ljava/util/Map;
    //   239: invokeinterface size : ()I
    //   244: ifle -> 382
    //   247: aload_2
    //   248: aload_1
    //   249: getfield g : Ljava/util/Map;
    //   252: putfield r : Ljava/util/Map;
    //   255: aload_1
    //   256: getfield g : Ljava/util/Map;
    //   259: ldc 'B11'
    //   261: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   266: checkcast java/lang/String
    //   269: astore_3
    //   270: aload_3
    //   271: ifnull -> 592
    //   274: aload_3
    //   275: ldc '1'
    //   277: invokevirtual equals : (Ljava/lang/Object;)Z
    //   280: ifeq -> 592
    //   283: aload_2
    //   284: iconst_1
    //   285: putfield g : Z
    //   288: aload_2
    //   289: aload_1
    //   290: getfield i : I
    //   293: i2l
    //   294: putfield m : J
    //   297: aload_2
    //   298: aload_1
    //   299: getfield i : I
    //   302: i2l
    //   303: putfield t : J
    //   306: aload_1
    //   307: getfield g : Ljava/util/Map;
    //   310: ldc 'B27'
    //   312: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   317: checkcast java/lang/String
    //   320: astore_3
    //   321: aload_3
    //   322: ifnull -> 349
    //   325: aload_3
    //   326: invokevirtual length : ()I
    //   329: ifle -> 349
    //   332: aload_3
    //   333: invokestatic parseInt : (Ljava/lang/String;)I
    //   336: istore #4
    //   338: iload #4
    //   340: ifle -> 349
    //   343: aload_2
    //   344: iload #4
    //   346: putfield s : I
    //   349: aload_1
    //   350: getfield g : Ljava/util/Map;
    //   353: ldc 'B25'
    //   355: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   360: checkcast java/lang/String
    //   363: astore_1
    //   364: aload_1
    //   365: ifnull -> 615
    //   368: aload_1
    //   369: ldc '1'
    //   371: invokevirtual equals : (Ljava/lang/Object;)Z
    //   374: ifeq -> 615
    //   377: aload_2
    //   378: iconst_1
    //   379: putfield h : Z
    //   382: ldc 'cr:%b,qu:%b,uin:%b,an:%b,ss:%b,ssT:%b,ssOT:%d,cos:%b,lstT:%d'
    //   384: bipush #9
    //   386: anewarray java/lang/Object
    //   389: dup
    //   390: iconst_0
    //   391: aload_2
    //   392: getfield d : Z
    //   395: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   398: aastore
    //   399: dup
    //   400: iconst_1
    //   401: aload_2
    //   402: getfield f : Z
    //   405: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   408: aastore
    //   409: dup
    //   410: iconst_2
    //   411: aload_2
    //   412: getfield e : Z
    //   415: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   418: aastore
    //   419: dup
    //   420: iconst_3
    //   421: aload_2
    //   422: getfield g : Z
    //   425: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   428: aastore
    //   429: dup
    //   430: iconst_4
    //   431: aload_2
    //   432: getfield j : Z
    //   435: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   438: aastore
    //   439: dup
    //   440: iconst_5
    //   441: aload_2
    //   442: getfield k : Z
    //   445: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   448: aastore
    //   449: dup
    //   450: bipush #6
    //   452: aload_2
    //   453: getfield m : J
    //   456: invokestatic valueOf : (J)Ljava/lang/Long;
    //   459: aastore
    //   460: dup
    //   461: bipush #7
    //   463: aload_2
    //   464: getfield h : Z
    //   467: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   470: aastore
    //   471: dup
    //   472: bipush #8
    //   474: aload_2
    //   475: getfield l : J
    //   478: invokestatic valueOf : (J)Ljava/lang/Long;
    //   481: aastore
    //   482: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   485: pop
    //   486: aload_0
    //   487: aload_2
    //   488: putfield f : Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   491: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   494: pop
    //   495: iconst_2
    //   496: invokestatic b : (I)V
    //   499: new com/tencent/bugly/legu/proguard/q
    //   502: dup
    //   503: invokespecial <init> : ()V
    //   506: astore_3
    //   507: aload_3
    //   508: iconst_2
    //   509: putfield b : I
    //   512: aload_3
    //   513: aload_2
    //   514: getfield b : J
    //   517: putfield a : J
    //   520: aload_3
    //   521: aload_2
    //   522: getfield c : J
    //   525: putfield e : J
    //   528: invokestatic obtain : ()Landroid/os/Parcel;
    //   531: astore #5
    //   533: aload_2
    //   534: aload #5
    //   536: iconst_0
    //   537: invokeinterface writeToParcel : (Landroid/os/Parcel;I)V
    //   542: aload #5
    //   544: invokevirtual marshall : ()[B
    //   547: astore_1
    //   548: aload #5
    //   550: invokevirtual recycle : ()V
    //   553: aload_3
    //   554: aload_1
    //   555: putfield g : [B
    //   558: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   561: aload_3
    //   562: invokevirtual a : (Lcom/tencent/bugly/legu/proguard/q;)Z
    //   565: pop
    //   566: aload_0
    //   567: aload_2
    //   568: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;)V
    //   571: goto -> 4
    //   574: iconst_1
    //   575: istore #4
    //   577: goto -> 81
    //   580: iconst_1
    //   581: istore #4
    //   583: goto -> 133
    //   586: iconst_1
    //   587: istore #4
    //   589: goto -> 195
    //   592: aload_2
    //   593: iconst_0
    //   594: putfield g : Z
    //   597: goto -> 288
    //   600: astore_3
    //   601: aload_3
    //   602: invokestatic a : (Ljava/lang/Throwable;)Z
    //   605: ifne -> 349
    //   608: aload_3
    //   609: invokevirtual printStackTrace : ()V
    //   612: goto -> 349
    //   615: aload_2
    //   616: iconst_0
    //   617: putfield h : Z
    //   620: goto -> 382
    // Exception table:
    //   from	to	target	type
    //   332	338	600	java/lang/Exception
    //   343	349	600	java/lang/Exception
  }
  
  public final boolean b() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnull -> 17
    //   11: iconst_1
    //   12: istore_2
    //   13: aload_0
    //   14: monitorexit
    //   15: iload_2
    //   16: ireturn
    //   17: iconst_0
    //   18: istore_2
    //   19: goto -> 13
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	22	finally
  }
  
  public final StrategyBean c() {
    return (this.f != null) ? this.f : this.e;
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/common/strategy/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */