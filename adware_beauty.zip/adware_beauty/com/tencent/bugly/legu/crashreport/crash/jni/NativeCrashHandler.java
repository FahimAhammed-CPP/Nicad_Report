package com.tencent.bugly.legu.crashreport.crash.jni;

import android.annotation.SuppressLint;
import android.content.Context;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.common.strategy.StrategyBean;
import com.tencent.bugly.legu.crashreport.common.strategy.a;
import com.tencent.bugly.legu.crashreport.crash.CrashDetailBean;
import com.tencent.bugly.legu.crashreport.crash.b;
import com.tencent.bugly.legu.proguard.a;
import com.tencent.bugly.legu.proguard.v;
import com.tencent.bugly.legu.proguard.w;

public class NativeCrashHandler {
  private static NativeCrashHandler a;
  
  private static boolean l = false;
  
  private final Context b;
  
  private final a c;
  
  private final v d;
  
  private NativeExceptionHandler e;
  
  private String f;
  
  private final boolean g;
  
  private boolean h;
  
  private boolean i;
  
  private boolean j;
  
  private boolean k;
  
  private b m;
  
  @SuppressLint({"SdCardPath"})
  private NativeCrashHandler(Context paramContext, a parama, b paramb, v paramv, boolean paramBoolean, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: iconst_0
    //   6: putfield h : Z
    //   9: aload_0
    //   10: iconst_0
    //   11: putfield i : Z
    //   14: aload_0
    //   15: iconst_0
    //   16: putfield j : Z
    //   19: aload_0
    //   20: iconst_0
    //   21: putfield k : Z
    //   24: aload_1
    //   25: ifnonnull -> 94
    //   28: aload_1
    //   29: astore #7
    //   31: aload_0
    //   32: aload #7
    //   34: putfield b : Landroid/content/Context;
    //   37: aload #6
    //   39: ifnull -> 115
    //   42: aload #6
    //   44: invokevirtual trim : ()Ljava/lang/String;
    //   47: invokevirtual length : ()I
    //   50: istore #8
    //   52: iload #8
    //   54: ifle -> 115
    //   57: iconst_0
    //   58: istore #8
    //   60: iload #8
    //   62: ifne -> 121
    //   65: aload_0
    //   66: aload_3
    //   67: putfield m : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   70: aload_0
    //   71: aload #6
    //   73: putfield f : Ljava/lang/String;
    //   76: aload_0
    //   77: aload_2
    //   78: putfield c : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   81: aload_0
    //   82: aload #4
    //   84: putfield d : Lcom/tencent/bugly/legu/proguard/v;
    //   87: aload_0
    //   88: iload #5
    //   90: putfield g : Z
    //   93: return
    //   94: aload_1
    //   95: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   98: astore #9
    //   100: aload #9
    //   102: astore #7
    //   104: aload #9
    //   106: ifnonnull -> 31
    //   109: aload_1
    //   110: astore #7
    //   112: goto -> 31
    //   115: iconst_1
    //   116: istore #8
    //   118: goto -> 60
    //   121: aload_1
    //   122: ldc 'bugly'
    //   124: iconst_0
    //   125: invokevirtual getDir : (Ljava/lang/String;I)Ljava/io/File;
    //   128: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   131: astore #6
    //   133: goto -> 65
    //   136: astore #6
    //   138: aload_1
    //   139: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   142: getfield c : Ljava/lang/String;
    //   145: astore_1
    //   146: new java/lang/StringBuilder
    //   149: dup
    //   150: ldc '/data/data/'
    //   152: invokespecial <init> : (Ljava/lang/String;)V
    //   155: aload_1
    //   156: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   159: ldc '/app_bugly'
    //   161: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: invokevirtual toString : ()Ljava/lang/String;
    //   167: astore #6
    //   169: goto -> 65
    // Exception table:
    //   from	to	target	type
    //   42	52	136	java/lang/Throwable
    //   121	133	136	java/lang/Throwable
  }
  
  private void a(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield j : Z
    //   6: ifeq -> 22
    //   9: ldc 'native already registed!'
    //   11: iconst_0
    //   12: anewarray java/lang/Object
    //   15: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   18: pop
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: new com/tencent/bugly/legu/crashreport/crash/jni/a
    //   25: astore_2
    //   26: aload_2
    //   27: aload_0
    //   28: getfield b : Landroid/content/Context;
    //   31: aload_0
    //   32: getfield c : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   35: aload_0
    //   36: getfield m : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   39: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   42: aload_0
    //   43: getfield f : Ljava/lang/String;
    //   46: invokespecial <init> : (Landroid/content/Context;Lcom/tencent/bugly/legu/crashreport/common/info/a;Lcom/tencent/bugly/legu/crashreport/crash/b;Lcom/tencent/bugly/legu/crashreport/common/strategy/a;Ljava/lang/String;)V
    //   49: aload_0
    //   50: aload_2
    //   51: putfield e : Lcom/tencent/bugly/legu/crashreport/crash/jni/NativeExceptionHandler;
    //   54: aload_0
    //   55: getfield i : Z
    //   58: istore_3
    //   59: iload_3
    //   60: ifeq -> 288
    //   63: aload_0
    //   64: aload_0
    //   65: getfield f : Ljava/lang/String;
    //   68: iload_1
    //   69: iconst_1
    //   70: invokevirtual regist : (Ljava/lang/String;ZI)Ljava/lang/String;
    //   73: astore #4
    //   75: aload #4
    //   77: ifnull -> 219
    //   80: ldc 'Native Crash Report enable!'
    //   82: iconst_0
    //   83: anewarray java/lang/Object
    //   86: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   89: pop
    //   90: ldc 'Check extra jni for Bugly NDK v%s'
    //   92: iconst_1
    //   93: anewarray java/lang/Object
    //   96: dup
    //   97: iconst_0
    //   98: aload #4
    //   100: aastore
    //   101: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   104: pop
    //   105: ldc '2.1.1'
    //   107: ldc '.'
    //   109: ldc ''
    //   111: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   114: astore #5
    //   116: aload #4
    //   118: ldc '.'
    //   120: ldc ''
    //   122: invokevirtual replace : (Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;
    //   125: astore #6
    //   127: aload #6
    //   129: invokevirtual length : ()I
    //   132: iconst_2
    //   133: if_icmpne -> 237
    //   136: new java/lang/StringBuilder
    //   139: astore_2
    //   140: aload_2
    //   141: invokespecial <init> : ()V
    //   144: aload_2
    //   145: aload #6
    //   147: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: ldc '0'
    //   152: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   155: invokevirtual toString : ()Ljava/lang/String;
    //   158: astore_2
    //   159: aload_2
    //   160: invokestatic parseInt : (Ljava/lang/String;)I
    //   163: aload #5
    //   165: invokestatic parseInt : (Ljava/lang/String;)I
    //   168: if_icmplt -> 175
    //   171: iconst_1
    //   172: putstatic com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler.l : Z
    //   175: getstatic com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler.l : Z
    //   178: ifeq -> 275
    //   181: ldc 'Extra bugly jni can be accessed.'
    //   183: iconst_0
    //   184: anewarray java/lang/Object
    //   187: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   190: pop
    //   191: aload_0
    //   192: getfield c : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   195: aload #4
    //   197: putfield l : Ljava/lang/String;
    //   200: aload_0
    //   201: iconst_1
    //   202: putfield j : Z
    //   205: goto -> 19
    //   208: astore_2
    //   209: ldc 'load bugly so fail'
    //   211: iconst_0
    //   212: anewarray java/lang/Object
    //   215: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   218: pop
    //   219: aload_0
    //   220: iconst_0
    //   221: putfield i : Z
    //   224: aload_0
    //   225: iconst_0
    //   226: putfield h : Z
    //   229: goto -> 19
    //   232: astore_2
    //   233: aload_0
    //   234: monitorexit
    //   235: aload_2
    //   236: athrow
    //   237: aload #6
    //   239: astore_2
    //   240: aload #6
    //   242: invokevirtual length : ()I
    //   245: iconst_1
    //   246: if_icmpne -> 159
    //   249: new java/lang/StringBuilder
    //   252: astore_2
    //   253: aload_2
    //   254: invokespecial <init> : ()V
    //   257: aload_2
    //   258: aload #6
    //   260: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   263: ldc '00'
    //   265: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   268: invokevirtual toString : ()Ljava/lang/String;
    //   271: astore_2
    //   272: goto -> 159
    //   275: ldc 'Extra bugly jni can not be accessed.'
    //   277: iconst_0
    //   278: anewarray java/lang/Object
    //   281: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   284: pop
    //   285: goto -> 191
    //   288: aload_0
    //   289: getfield h : Z
    //   292: istore_1
    //   293: iload_1
    //   294: ifeq -> 219
    //   297: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   300: astore #6
    //   302: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   305: astore_2
    //   306: aload_0
    //   307: getfield f : Ljava/lang/String;
    //   310: astore #5
    //   312: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   315: invokevirtual q : ()Ljava/lang/String;
    //   318: astore #4
    //   320: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   323: invokevirtual F : ()I
    //   326: istore #7
    //   328: ldc 'com.tencent.feedback.eup.jni.NativeExceptionUpload'
    //   330: ldc 'registNativeExceptionHandler2'
    //   332: aconst_null
    //   333: iconst_4
    //   334: anewarray java/lang/Class
    //   337: dup
    //   338: iconst_0
    //   339: ldc java/lang/String
    //   341: aastore
    //   342: dup
    //   343: iconst_1
    //   344: ldc java/lang/String
    //   346: aastore
    //   347: dup
    //   348: iconst_2
    //   349: aload #6
    //   351: aastore
    //   352: dup
    //   353: iconst_3
    //   354: aload_2
    //   355: aastore
    //   356: iconst_4
    //   357: anewarray java/lang/Object
    //   360: dup
    //   361: iconst_0
    //   362: aload #5
    //   364: aastore
    //   365: dup
    //   366: iconst_1
    //   367: aload #4
    //   369: aastore
    //   370: dup
    //   371: iconst_2
    //   372: iload #7
    //   374: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   377: aastore
    //   378: dup
    //   379: iconst_3
    //   380: iconst_1
    //   381: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   384: aastore
    //   385: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    //   388: checkcast java/lang/String
    //   391: astore #6
    //   393: aload #6
    //   395: astore_2
    //   396: aload #6
    //   398: ifnonnull -> 479
    //   401: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   404: astore #4
    //   406: aload_0
    //   407: getfield f : Ljava/lang/String;
    //   410: astore #6
    //   412: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   415: invokevirtual q : ()Ljava/lang/String;
    //   418: astore_2
    //   419: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   422: invokevirtual F : ()I
    //   425: istore #7
    //   427: ldc 'com.tencent.feedback.eup.jni.NativeExceptionUpload'
    //   429: ldc 'registNativeExceptionHandler'
    //   431: aconst_null
    //   432: iconst_3
    //   433: anewarray java/lang/Class
    //   436: dup
    //   437: iconst_0
    //   438: ldc java/lang/String
    //   440: aastore
    //   441: dup
    //   442: iconst_1
    //   443: ldc java/lang/String
    //   445: aastore
    //   446: dup
    //   447: iconst_2
    //   448: aload #4
    //   450: aastore
    //   451: iconst_3
    //   452: anewarray java/lang/Object
    //   455: dup
    //   456: iconst_0
    //   457: aload #6
    //   459: aastore
    //   460: dup
    //   461: iconst_1
    //   462: aload_2
    //   463: aastore
    //   464: dup
    //   465: iconst_2
    //   466: iload #7
    //   468: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   471: aastore
    //   472: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    //   475: checkcast java/lang/String
    //   478: astore_2
    //   479: aload_2
    //   480: ifnull -> 219
    //   483: aload_0
    //   484: iconst_1
    //   485: putfield j : Z
    //   488: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   491: aload_2
    //   492: putfield l : Ljava/lang/String;
    //   495: ldc 'com.tencent.feedback.eup.jni.NativeExceptionUpload'
    //   497: ldc 'enableHandler'
    //   499: aconst_null
    //   500: iconst_1
    //   501: anewarray java/lang/Class
    //   504: dup
    //   505: iconst_0
    //   506: getstatic java/lang/Boolean.TYPE : Ljava/lang/Class;
    //   509: aastore
    //   510: iconst_1
    //   511: anewarray java/lang/Object
    //   514: dup
    //   515: iconst_0
    //   516: iconst_1
    //   517: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   520: aastore
    //   521: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    //   524: pop
    //   525: getstatic com/tencent/bugly/legu/b.b : Z
    //   528: ifeq -> 572
    //   531: iconst_3
    //   532: istore #7
    //   534: ldc 'com.tencent.feedback.eup.jni.NativeExceptionUpload'
    //   536: ldc 'setLogMode'
    //   538: aconst_null
    //   539: iconst_1
    //   540: anewarray java/lang/Class
    //   543: dup
    //   544: iconst_0
    //   545: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
    //   548: aastore
    //   549: iconst_1
    //   550: anewarray java/lang/Object
    //   553: dup
    //   554: iconst_0
    //   555: iload #7
    //   557: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   560: aastore
    //   561: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    //   564: pop
    //   565: goto -> 19
    //   568: astore_2
    //   569: goto -> 219
    //   572: iconst_5
    //   573: istore #7
    //   575: goto -> 534
    //   578: astore_2
    //   579: goto -> 175
    // Exception table:
    //   from	to	target	type
    //   2	19	232	finally
    //   22	59	232	finally
    //   63	75	208	java/lang/Throwable
    //   63	75	232	finally
    //   80	159	208	java/lang/Throwable
    //   80	159	232	finally
    //   159	175	578	java/lang/Throwable
    //   159	175	232	finally
    //   175	191	208	java/lang/Throwable
    //   175	191	232	finally
    //   191	205	208	java/lang/Throwable
    //   191	205	232	finally
    //   209	219	232	finally
    //   219	229	232	finally
    //   240	272	208	java/lang/Throwable
    //   240	272	232	finally
    //   275	285	208	java/lang/Throwable
    //   275	285	232	finally
    //   288	293	232	finally
    //   297	393	568	java/lang/Throwable
    //   297	393	232	finally
    //   401	479	568	java/lang/Throwable
    //   401	479	232	finally
    //   483	531	568	java/lang/Throwable
    //   483	531	232	finally
    //   534	565	568	java/lang/Throwable
    //   534	565	232	finally
  }
  
  private static boolean a(String paramString, boolean paramBoolean) {
    boolean bool = true;
    try {
      w.a("[native] trying to load so: %s", new Object[] { paramString });
      if (paramBoolean) {
        System.load(paramString);
      } else {
        System.loadLibrary(paramString);
      } 
      try {
        w.a("[native] load so success: %s", new Object[] { paramString });
        return bool;
      } catch (Throwable null) {
        paramBoolean = true;
      } 
    } catch (Throwable throwable) {
      paramBoolean = false;
    } 
    w.d(throwable.getMessage(), new Object[0]);
    w.d("[native] Failed to load so, please check.", new Object[] { paramString });
    return paramBoolean;
  }
  
  private void b() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield j : Z
    //   6: ifne -> 22
    //   9: ldc 'native already unregisted!'
    //   11: iconst_0
    //   12: anewarray java/lang/Object
    //   15: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   18: pop
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: aload_0
    //   23: invokevirtual unregist : ()Ljava/lang/String;
    //   26: ifnull -> 135
    //   29: ldc 'Native Crash Report close!'
    //   31: iconst_0
    //   32: anewarray java/lang/Object
    //   35: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   38: pop
    //   39: aload_0
    //   40: iconst_0
    //   41: putfield j : Z
    //   44: goto -> 19
    //   47: astore_1
    //   48: ldc 'unregist bugly so fail'
    //   50: iconst_0
    //   51: anewarray java/lang/Object
    //   54: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   57: pop
    //   58: ldc 'com.tencent.feedback.eup.jni.NativeExceptionUpload'
    //   60: ldc 'enableHandler'
    //   62: aconst_null
    //   63: iconst_1
    //   64: anewarray java/lang/Class
    //   67: dup
    //   68: iconst_0
    //   69: getstatic java/lang/Boolean.TYPE : Ljava/lang/Class;
    //   72: aastore
    //   73: iconst_1
    //   74: anewarray java/lang/Object
    //   77: dup
    //   78: iconst_0
    //   79: iconst_0
    //   80: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   83: aastore
    //   84: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    //   87: pop
    //   88: aload_0
    //   89: iconst_0
    //   90: putfield j : Z
    //   93: ldc 'unregist rqd so success'
    //   95: iconst_0
    //   96: anewarray java/lang/Object
    //   99: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   102: pop
    //   103: goto -> 19
    //   106: astore_1
    //   107: ldc 'unregist rqd so fail'
    //   109: iconst_0
    //   110: anewarray java/lang/Object
    //   113: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   116: pop
    //   117: aload_0
    //   118: iconst_0
    //   119: putfield i : Z
    //   122: aload_0
    //   123: iconst_0
    //   124: putfield h : Z
    //   127: goto -> 19
    //   130: astore_1
    //   131: aload_0
    //   132: monitorexit
    //   133: aload_1
    //   134: athrow
    //   135: ldc 'unregist bugly so success'
    //   137: iconst_0
    //   138: anewarray java/lang/Object
    //   141: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   144: pop
    //   145: goto -> 58
    // Exception table:
    //   from	to	target	type
    //   2	19	130	finally
    //   22	44	47	java/lang/Throwable
    //   22	44	130	finally
    //   48	58	130	finally
    //   58	103	106	java/lang/Throwable
    //   58	103	130	finally
    //   107	127	130	finally
    //   135	145	47	java/lang/Throwable
    //   135	145	130	finally
  }
  
  private void b(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iload_1
    //   3: ifeq -> 13
    //   6: aload_0
    //   7: invokevirtual startNativeMonitor : ()V
    //   10: aload_0
    //   11: monitorexit
    //   12: return
    //   13: aload_0
    //   14: invokespecial b : ()V
    //   17: goto -> 10
    //   20: astore_2
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_2
    //   24: athrow
    // Exception table:
    //   from	to	target	type
    //   6	10	20	finally
    //   13	17	20	finally
  }
  
  private void c(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield k : Z
    //   6: iload_1
    //   7: if_icmpeq -> 33
    //   10: ldc_w 'user change native %b'
    //   13: iconst_1
    //   14: anewarray java/lang/Object
    //   17: dup
    //   18: iconst_0
    //   19: iload_1
    //   20: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   23: aastore
    //   24: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   27: pop
    //   28: aload_0
    //   29: iload_1
    //   30: putfield k : Z
    //   33: aload_0
    //   34: monitorexit
    //   35: return
    //   36: astore_2
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_2
    //   40: athrow
    // Exception table:
    //   from	to	target	type
    //   2	33	36	finally
  }
  
  public static NativeCrashHandler getInstance() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler.a : Lcom/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler;
    //   6: astore_0
    //   7: ldc com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler
    //   9: monitorexit
    //   10: aload_0
    //   11: areturn
    //   12: astore_0
    //   13: ldc com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	12	finally
  }
  
  public static NativeCrashHandler getInstance(Context paramContext, a parama, b paramb, a parama1, v paramv, boolean paramBoolean, String paramString) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler.a : Lcom/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler;
    //   6: ifnonnull -> 30
    //   9: new com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler
    //   12: astore_3
    //   13: aload_3
    //   14: aload_0
    //   15: aload_1
    //   16: aload_2
    //   17: aload #4
    //   19: iload #5
    //   21: aload #6
    //   23: invokespecial <init> : (Landroid/content/Context;Lcom/tencent/bugly/legu/crashreport/common/info/a;Lcom/tencent/bugly/legu/crashreport/crash/b;Lcom/tencent/bugly/legu/proguard/v;ZLjava/lang/String;)V
    //   26: aload_3
    //   27: putstatic com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler.a : Lcom/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler;
    //   30: getstatic com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler.a : Lcom/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler;
    //   33: astore_0
    //   34: ldc com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler
    //   36: monitorexit
    //   37: aload_0
    //   38: areturn
    //   39: astore_0
    //   40: ldc com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler
    //   42: monitorexit
    //   43: aload_0
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   3	30	39	finally
    //   30	34	39	finally
  }
  
  protected final void a() {
    // Byte code:
    //   0: invokestatic o : ()J
    //   3: lstore_1
    //   4: getstatic com/tencent/bugly/legu/crashreport/crash/c.f : J
    //   7: lstore_3
    //   8: new java/io/File
    //   11: dup
    //   12: aload_0
    //   13: getfield f : Ljava/lang/String;
    //   16: invokespecial <init> : (Ljava/lang/String;)V
    //   19: astore #5
    //   21: aload #5
    //   23: invokevirtual exists : ()Z
    //   26: ifeq -> 55
    //   29: aload #5
    //   31: invokevirtual isDirectory : ()Z
    //   34: ifeq -> 55
    //   37: aload #5
    //   39: invokevirtual listFiles : ()[Ljava/io/File;
    //   42: astore #5
    //   44: aload #5
    //   46: ifnull -> 55
    //   49: aload #5
    //   51: arraylength
    //   52: ifne -> 56
    //   55: return
    //   56: ldc_w 'tomb_'
    //   59: invokevirtual length : ()I
    //   62: istore #6
    //   64: aload #5
    //   66: arraylength
    //   67: istore #7
    //   69: iconst_0
    //   70: istore #8
    //   72: iconst_0
    //   73: istore #9
    //   75: iload #8
    //   77: iload #7
    //   79: if_icmpge -> 202
    //   82: aload #5
    //   84: iload #8
    //   86: aaload
    //   87: astore #10
    //   89: aload #10
    //   91: invokevirtual getName : ()Ljava/lang/String;
    //   94: astore #11
    //   96: iload #9
    //   98: istore #12
    //   100: aload #11
    //   102: ldc_w 'tomb_'
    //   105: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   108: ifeq -> 153
    //   111: aload #11
    //   113: ldc_w '.txt'
    //   116: invokevirtual indexOf : (Ljava/lang/String;)I
    //   119: istore #12
    //   121: iload #12
    //   123: ifle -> 181
    //   126: aload #11
    //   128: iload #6
    //   130: iload #12
    //   132: invokevirtual substring : (II)Ljava/lang/String;
    //   135: invokestatic parseLong : (Ljava/lang/String;)J
    //   138: lstore #13
    //   140: lload #13
    //   142: lload_1
    //   143: lload_3
    //   144: lsub
    //   145: lcmp
    //   146: iflt -> 181
    //   149: iload #9
    //   151: istore #12
    //   153: iinc #8, 1
    //   156: iload #12
    //   158: istore #9
    //   160: goto -> 75
    //   163: astore #15
    //   165: ldc_w 'tomb format error delete %s'
    //   168: iconst_1
    //   169: anewarray java/lang/Object
    //   172: dup
    //   173: iconst_0
    //   174: aload #11
    //   176: aastore
    //   177: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   180: pop
    //   181: iload #9
    //   183: istore #12
    //   185: aload #10
    //   187: invokevirtual delete : ()Z
    //   190: ifeq -> 153
    //   193: iload #9
    //   195: iconst_1
    //   196: iadd
    //   197: istore #12
    //   199: goto -> 153
    //   202: ldc_w 'clean tombs %d'
    //   205: iconst_1
    //   206: anewarray java/lang/Object
    //   209: dup
    //   210: iconst_0
    //   211: iload #9
    //   213: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   216: aastore
    //   217: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   220: pop
    //   221: goto -> 55
    // Exception table:
    //   from	to	target	type
    //   111	121	163	java/lang/Throwable
    //   126	140	163	java/lang/Throwable
  }
  
  public boolean appendLogToNative(String paramString1, String paramString2, String paramString3) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (this.i) {
      if (!l)
        return bool1; 
    } else {
      return bool2;
    } 
    bool2 = bool1;
    if (paramString1 != null) {
      bool2 = bool1;
      if (paramString2 != null) {
        bool2 = bool1;
        if (paramString3 != null)
          try {
            bool2 = appendNativeLog(paramString1, paramString2, paramString3);
          } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
            l = false;
            bool2 = bool1;
          } catch (Throwable throwable) {
            bool2 = bool1;
          }  
      } 
    } 
    return bool2;
  }
  
  protected native boolean appendNativeLog(String paramString1, String paramString2, String paramString3);
  
  protected native boolean appendWholeNativeLog(String paramString);
  
  public String getDumpFilePath() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield f : Ljava/lang/String;
    //   6: astore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: aload_1
    //   10: areturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public NativeExceptionHandler getNativeExceptionHandler() {
    return this.e;
  }
  
  protected native String getNativeKeyValueList();
  
  protected native String getNativeLog();
  
  public boolean isUserOpened() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield k : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public void onStrategyChanged(StrategyBean paramStrategyBean) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_1
    //   5: ifnull -> 40
    //   8: aload_1
    //   9: getfield d : Z
    //   12: aload_0
    //   13: getfield j : Z
    //   16: if_icmpeq -> 40
    //   19: ldc_w 'server native changed to %b'
    //   22: iconst_1
    //   23: anewarray java/lang/Object
    //   26: dup
    //   27: iconst_0
    //   28: aload_1
    //   29: getfield d : Z
    //   32: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   35: aastore
    //   36: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   39: pop
    //   40: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   43: invokevirtual c : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   46: getfield d : Z
    //   49: ifeq -> 93
    //   52: aload_0
    //   53: getfield k : Z
    //   56: ifeq -> 93
    //   59: iload_2
    //   60: aload_0
    //   61: getfield j : Z
    //   64: if_icmpeq -> 90
    //   67: ldc_w 'native changed to %b'
    //   70: iconst_1
    //   71: anewarray java/lang/Object
    //   74: dup
    //   75: iconst_0
    //   76: iload_2
    //   77: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   80: aastore
    //   81: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   84: pop
    //   85: aload_0
    //   86: iload_2
    //   87: invokespecial b : (Z)V
    //   90: aload_0
    //   91: monitorexit
    //   92: return
    //   93: iconst_0
    //   94: istore_2
    //   95: goto -> 59
    //   98: astore_1
    //   99: aload_0
    //   100: monitorexit
    //   101: aload_1
    //   102: athrow
    // Exception table:
    //   from	to	target	type
    //   8	40	98	finally
    //   40	59	98	finally
    //   59	90	98	finally
  }
  
  public boolean putKeyValueToNative(String paramString1, String paramString2) {
    boolean bool1 = false;
    boolean bool2 = bool1;
    if (this.i) {
      if (!l)
        return bool1; 
    } else {
      return bool2;
    } 
    bool2 = bool1;
    if (paramString1 != null) {
      bool2 = bool1;
      if (paramString2 != null)
        try {
          bool2 = putNativeKeyValue(paramString1, paramString2);
        } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
          l = false;
          bool2 = bool1;
        } catch (Throwable throwable) {
          bool2 = bool1;
        }  
    } 
    return bool2;
  }
  
  protected native boolean putNativeKeyValue(String paramString1, String paramString2);
  
  protected native String regist(String paramString, boolean paramBoolean, int paramInt);
  
  protected native String removeNativeKeyValue(String paramString);
  
  public void setDumpFilePath(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield f : Ljava/lang/String;
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
  
  public void setUserOpened(boolean paramBoolean) {
    c(paramBoolean);
    if ((a.a().c()).d && isUserOpened()) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    if (paramBoolean != this.j) {
      w.a("native changed to %b", new Object[] { Boolean.valueOf(paramBoolean) });
      b(paramBoolean);
    } 
  }
  
  public void startNativeMonitor() {
    // Byte code:
    //   0: iconst_1
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield i : Z
    //   8: ifne -> 18
    //   11: aload_0
    //   12: getfield h : Z
    //   15: ifeq -> 29
    //   18: aload_0
    //   19: aload_0
    //   20: getfield g : Z
    //   23: invokespecial a : (Z)V
    //   26: aload_0
    //   27: monitorexit
    //   28: return
    //   29: aload_0
    //   30: getfield c : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   33: getfield k : Ljava/lang/String;
    //   36: astore_2
    //   37: aload_2
    //   38: ifnull -> 189
    //   41: aload_2
    //   42: invokevirtual trim : ()Ljava/lang/String;
    //   45: invokevirtual length : ()I
    //   48: ifle -> 189
    //   51: iconst_0
    //   52: istore_3
    //   53: iload_3
    //   54: ifne -> 65
    //   57: aload_0
    //   58: getfield c : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   61: getfield k : Ljava/lang/String;
    //   64: astore_2
    //   65: aload_0
    //   66: getfield c : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   69: getfield k : Ljava/lang/String;
    //   72: astore_2
    //   73: aload_2
    //   74: ifnull -> 194
    //   77: aload_2
    //   78: invokevirtual trim : ()Ljava/lang/String;
    //   81: invokevirtual length : ()I
    //   84: ifle -> 194
    //   87: iconst_0
    //   88: istore_3
    //   89: iload_3
    //   90: ifeq -> 199
    //   93: ldc_w 'Bugly'
    //   96: astore_2
    //   97: aload_0
    //   98: getfield c : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   101: getfield k : Ljava/lang/String;
    //   104: astore #4
    //   106: aload #4
    //   108: ifnull -> 210
    //   111: aload #4
    //   113: invokevirtual trim : ()Ljava/lang/String;
    //   116: invokevirtual length : ()I
    //   119: ifle -> 210
    //   122: iconst_0
    //   123: istore_3
    //   124: iload_3
    //   125: ifne -> 215
    //   128: aload_0
    //   129: aload_2
    //   130: iload_1
    //   131: invokestatic a : (Ljava/lang/String;Z)Z
    //   134: putfield i : Z
    //   137: aload_0
    //   138: getfield i : Z
    //   141: ifne -> 151
    //   144: aload_0
    //   145: getfield h : Z
    //   148: ifeq -> 26
    //   151: aload_0
    //   152: aload_0
    //   153: getfield g : Z
    //   156: invokespecial a : (Z)V
    //   159: aload_0
    //   160: getfield d : Lcom/tencent/bugly/legu/proguard/v;
    //   163: astore #4
    //   165: new com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler$1
    //   168: astore_2
    //   169: aload_2
    //   170: aload_0
    //   171: invokespecial <init> : (Lcom/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler;)V
    //   174: aload #4
    //   176: aload_2
    //   177: invokevirtual b : (Ljava/lang/Runnable;)Z
    //   180: pop
    //   181: goto -> 26
    //   184: astore_2
    //   185: aload_0
    //   186: monitorexit
    //   187: aload_2
    //   188: athrow
    //   189: iconst_1
    //   190: istore_3
    //   191: goto -> 53
    //   194: iconst_1
    //   195: istore_3
    //   196: goto -> 89
    //   199: aload_0
    //   200: getfield c : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   203: getfield k : Ljava/lang/String;
    //   206: astore_2
    //   207: goto -> 97
    //   210: iconst_1
    //   211: istore_3
    //   212: goto -> 124
    //   215: iconst_0
    //   216: istore_1
    //   217: goto -> 128
    // Exception table:
    //   from	to	target	type
    //   4	18	184	finally
    //   18	26	184	finally
    //   29	37	184	finally
    //   41	51	184	finally
    //   57	65	184	finally
    //   65	73	184	finally
    //   77	87	184	finally
    //   97	106	184	finally
    //   111	122	184	finally
    //   128	151	184	finally
    //   151	181	184	finally
    //   199	207	184	finally
  }
  
  protected native void testCrash();
  
  public void testNativeCrash() {
    if (!this.i) {
      w.d("libBugly.so has not been load! so fail!", new Object[0]);
      return;
    } 
    testCrash();
  }
  
  protected native String unregist();
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */