package com.tencent.bugly.legu.crashreport.crash.anr;

import com.tencent.bugly.legu.proguard.w;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class TraceFileHelper {
  private static String a(BufferedReader paramBufferedReader) throws IOException {
    // Byte code:
    //   0: new java/lang/StringBuffer
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_1
    //   8: iconst_0
    //   9: istore_2
    //   10: iload_2
    //   11: iconst_3
    //   12: if_icmpge -> 58
    //   15: aload_0
    //   16: invokevirtual readLine : ()Ljava/lang/String;
    //   19: astore_3
    //   20: aload_3
    //   21: ifnonnull -> 28
    //   24: aconst_null
    //   25: astore_0
    //   26: aload_0
    //   27: areturn
    //   28: aload_1
    //   29: new java/lang/StringBuilder
    //   32: dup
    //   33: invokespecial <init> : ()V
    //   36: aload_3
    //   37: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: ldc '\\n'
    //   42: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: invokevirtual toString : ()Ljava/lang/String;
    //   48: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   51: pop
    //   52: iinc #2, 1
    //   55: goto -> 10
    //   58: aload_1
    //   59: invokevirtual toString : ()Ljava/lang/String;
    //   62: astore_0
    //   63: goto -> 26
  }
  
  private static Object[] a(BufferedReader paramBufferedReader, Pattern... paramVarArgs) throws IOException {
    Object[] arrayOfObject1 = null;
    Object[] arrayOfObject2 = arrayOfObject1;
    if (paramBufferedReader != null) {
      if (paramVarArgs == null)
        return arrayOfObject1; 
    } else {
      return arrayOfObject2;
    } 
    while (true) {
      String str = paramBufferedReader.readLine();
      arrayOfObject2 = arrayOfObject1;
      if (str != null) {
        int i = paramVarArgs.length;
        for (byte b = 0; b < i; b++) {
          Pattern pattern = paramVarArgs[b];
          if (pattern.matcher(str).matches()) {
            arrayOfObject2 = new Object[2];
            arrayOfObject2[0] = pattern;
            arrayOfObject2[1] = str;
            return arrayOfObject2;
          } 
        } 
        continue;
      } 
      // Byte code: goto -> 14
    } 
  }
  
  private static String b(BufferedReader paramBufferedReader) throws IOException {
    StringBuffer stringBuffer = new StringBuffer();
    while (true) {
      String str = paramBufferedReader.readLine();
      if (str != null && str.trim().length() > 0) {
        stringBuffer.append(str + "\n");
        continue;
      } 
      break;
    } 
    return stringBuffer.toString();
  }
  
  public static a readFirstDumpInfo(String paramString, boolean paramBoolean) {
    String str = null;
    if (paramString == null) {
      w.e("path:%s", new Object[] { paramString });
      return (a)str;
    } 
    a a = new a();
    readTraceFile(paramString, new b(a, paramBoolean) {
          public final boolean a(long param1Long) {
            w.c("process end %d", new Object[] { Long.valueOf(param1Long) });
            return false;
          }
          
          public final boolean a(long param1Long1, long param1Long2, String param1String) {
            boolean bool = false;
            w.c("new process %s", new Object[] { param1String });
            this.a.a = param1Long1;
            this.a.b = param1String;
            this.a.c = param1Long2;
            if (this.b)
              bool = true; 
            return bool;
          }
          
          public final boolean a(String param1String1, int param1Int, String param1String2, String param1String3) {
            w.c("new thread %s", new Object[] { param1String1 });
            if (this.a.d == null)
              this.a.d = (Map)new HashMap<String, String>(); 
            this.a.d.put(param1String1, new String[] { param1String2, param1String3, param1Int });
            return true;
          }
        });
    if (a.a > 0L && a.c > 0L && a.b != null)
      return a; 
    w.e("first dump error %s", new Object[] { a.a + " " + a.c + " " + a.b });
    return (a)str;
  }
  
  public static a readTargetDumpInfo(String paramString1, String paramString2, boolean paramBoolean) {
    if (paramString1 == null || paramString2 == null)
      return null; 
    a a = new a();
    readTraceFile(paramString2, new b(a, paramBoolean) {
          public final boolean a(long param1Long) {
            boolean bool = false;
            w.c("process end %d", new Object[] { Long.valueOf(param1Long) });
            if (this.a.a <= 0L || this.a.c <= 0L || this.a.b == null)
              bool = true; 
            return bool;
          }
          
          public final boolean a(long param1Long1, long param1Long2, String param1String) {
            boolean bool = true;
            w.c("new process %s", new Object[] { param1String });
            if (param1String.equals(param1String)) {
              this.a.a = param1Long1;
              this.a.b = param1String;
              this.a.c = param1Long2;
              if (!this.b)
                bool = false; 
            } 
            return bool;
          }
          
          public final boolean a(String param1String1, int param1Int, String param1String2, String param1String3) {
            w.c("new thread %s", new Object[] { param1String1 });
            if (this.a.a > 0L && this.a.c > 0L && this.a.b != null) {
              if (this.a.d == null)
                this.a.d = (Map)new HashMap<String, String>(); 
              this.a.d.put(param1String1, new String[] { param1String2, param1String3, param1Int });
            } 
            return true;
          }
        });
    if (a.a > 0L && a.c > 0L) {
      a a1 = a;
      return (a.b == null) ? null : a1;
    } 
    return null;
  }
  
  public static void readTraceFile(String paramString, b paramb) {
    // Byte code:
    //   0: aload_0
    //   1: ifnull -> 8
    //   4: aload_1
    //   5: ifnonnull -> 9
    //   8: return
    //   9: new java/io/File
    //   12: dup
    //   13: aload_0
    //   14: invokespecial <init> : (Ljava/lang/String;)V
    //   17: astore_2
    //   18: aload_2
    //   19: invokevirtual exists : ()Z
    //   22: ifeq -> 8
    //   25: aload_2
    //   26: invokevirtual lastModified : ()J
    //   29: pop2
    //   30: aload_2
    //   31: invokevirtual length : ()J
    //   34: pop2
    //   35: aconst_null
    //   36: astore_0
    //   37: new java/io/BufferedReader
    //   40: astore_3
    //   41: new java/io/FileReader
    //   44: astore #4
    //   46: aload #4
    //   48: aload_2
    //   49: invokespecial <init> : (Ljava/io/File;)V
    //   52: aload_3
    //   53: aload #4
    //   55: invokespecial <init> : (Ljava/io/Reader;)V
    //   58: ldc '-{5}\spid\s\d+\sat\s\d+-\d+-\d+\s\d{2}:\d{2}:\d{2}\s-{5}'
    //   60: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   63: astore #5
    //   65: ldc '-{5}\send\s\d+\s-{5}'
    //   67: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   70: astore #6
    //   72: ldc 'Cmd\sline:\s(\S+)'
    //   74: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   77: astore_2
    //   78: ldc '".+"\s(daemon\s){0,1}prio=\d+\stid=\d+\s.*'
    //   80: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   83: astore_0
    //   84: new java/text/SimpleDateFormat
    //   87: astore #4
    //   89: aload #4
    //   91: ldc 'yyyy-MM-dd HH:mm:ss'
    //   93: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   96: invokespecial <init> : (Ljava/lang/String;Ljava/util/Locale;)V
    //   99: aload_3
    //   100: iconst_1
    //   101: anewarray java/util/regex/Pattern
    //   104: dup
    //   105: iconst_0
    //   106: aload #5
    //   108: aastore
    //   109: invokestatic a : (Ljava/io/BufferedReader;[Ljava/util/regex/Pattern;)[Ljava/lang/Object;
    //   112: astore #7
    //   114: aload #7
    //   116: ifnull -> 574
    //   119: aload #7
    //   121: iconst_1
    //   122: aaload
    //   123: invokevirtual toString : ()Ljava/lang/String;
    //   126: ldc '\s'
    //   128: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   131: astore #7
    //   133: aload #7
    //   135: iconst_2
    //   136: aaload
    //   137: invokestatic parseLong : (Ljava/lang/String;)J
    //   140: lstore #8
    //   142: new java/lang/StringBuilder
    //   145: astore #10
    //   147: aload #10
    //   149: invokespecial <init> : ()V
    //   152: aload #4
    //   154: aload #10
    //   156: aload #7
    //   158: iconst_4
    //   159: aaload
    //   160: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   163: ldc ' '
    //   165: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   168: aload #7
    //   170: iconst_5
    //   171: aaload
    //   172: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   175: invokevirtual toString : ()Ljava/lang/String;
    //   178: invokevirtual parse : (Ljava/lang/String;)Ljava/util/Date;
    //   181: invokevirtual getTime : ()J
    //   184: lstore #11
    //   186: aload_3
    //   187: iconst_1
    //   188: anewarray java/util/regex/Pattern
    //   191: dup
    //   192: iconst_0
    //   193: aload_2
    //   194: aastore
    //   195: invokestatic a : (Ljava/io/BufferedReader;[Ljava/util/regex/Pattern;)[Ljava/lang/Object;
    //   198: astore #7
    //   200: aload #7
    //   202: ifnonnull -> 227
    //   205: aload_3
    //   206: invokevirtual close : ()V
    //   209: goto -> 8
    //   212: astore_0
    //   213: aload_0
    //   214: invokestatic a : (Ljava/lang/Throwable;)Z
    //   217: ifne -> 8
    //   220: aload_0
    //   221: invokevirtual printStackTrace : ()V
    //   224: goto -> 8
    //   227: aload_2
    //   228: aload #7
    //   230: iconst_1
    //   231: aaload
    //   232: invokevirtual toString : ()Ljava/lang/String;
    //   235: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   238: astore #7
    //   240: aload #7
    //   242: invokevirtual find : ()Z
    //   245: pop
    //   246: aload #7
    //   248: iconst_1
    //   249: invokevirtual group : (I)Ljava/lang/String;
    //   252: pop
    //   253: aload_1
    //   254: lload #8
    //   256: lload #11
    //   258: aload #7
    //   260: iconst_1
    //   261: invokevirtual group : (I)Ljava/lang/String;
    //   264: invokeinterface a : (JJLjava/lang/String;)Z
    //   269: istore #13
    //   271: iload #13
    //   273: ifne -> 298
    //   276: aload_3
    //   277: invokevirtual close : ()V
    //   280: goto -> 8
    //   283: astore_0
    //   284: aload_0
    //   285: invokestatic a : (Ljava/lang/Throwable;)Z
    //   288: ifne -> 8
    //   291: aload_0
    //   292: invokevirtual printStackTrace : ()V
    //   295: goto -> 8
    //   298: aload_3
    //   299: iconst_2
    //   300: anewarray java/util/regex/Pattern
    //   303: dup
    //   304: iconst_0
    //   305: aload_0
    //   306: aastore
    //   307: dup
    //   308: iconst_1
    //   309: aload #6
    //   311: aastore
    //   312: invokestatic a : (Ljava/io/BufferedReader;[Ljava/util/regex/Pattern;)[Ljava/lang/Object;
    //   315: astore #7
    //   317: aload #7
    //   319: ifnull -> 99
    //   322: aload #7
    //   324: iconst_0
    //   325: aaload
    //   326: aload_0
    //   327: if_acmpne -> 522
    //   330: aload #7
    //   332: iconst_1
    //   333: aaload
    //   334: invokevirtual toString : ()Ljava/lang/String;
    //   337: astore #10
    //   339: ldc '".+"'
    //   341: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   344: aload #10
    //   346: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   349: astore #7
    //   351: aload #7
    //   353: invokevirtual find : ()Z
    //   356: pop
    //   357: aload #7
    //   359: invokevirtual group : ()Ljava/lang/String;
    //   362: astore #7
    //   364: aload #7
    //   366: iconst_1
    //   367: aload #7
    //   369: invokevirtual length : ()I
    //   372: iconst_1
    //   373: isub
    //   374: invokevirtual substring : (II)Ljava/lang/String;
    //   377: astore #7
    //   379: aload #10
    //   381: ldc 'NATIVE'
    //   383: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   386: pop
    //   387: ldc 'tid=\d+'
    //   389: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   392: aload #10
    //   394: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   397: astore #10
    //   399: aload #10
    //   401: invokevirtual find : ()Z
    //   404: pop
    //   405: aload #10
    //   407: invokevirtual group : ()Ljava/lang/String;
    //   410: astore #10
    //   412: aload_1
    //   413: aload #7
    //   415: aload #10
    //   417: aload #10
    //   419: ldc '='
    //   421: invokevirtual indexOf : (Ljava/lang/String;)I
    //   424: iconst_1
    //   425: iadd
    //   426: invokevirtual substring : (I)Ljava/lang/String;
    //   429: invokestatic parseInt : (Ljava/lang/String;)I
    //   432: aload_3
    //   433: invokestatic a : (Ljava/io/BufferedReader;)Ljava/lang/String;
    //   436: aload_3
    //   437: invokestatic b : (Ljava/io/BufferedReader;)Ljava/lang/String;
    //   440: invokeinterface a : (Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)Z
    //   445: pop
    //   446: goto -> 298
    //   449: astore_1
    //   450: aload_3
    //   451: astore_0
    //   452: aload_1
    //   453: invokevirtual getClass : ()Ljava/lang/Class;
    //   456: invokevirtual getName : ()Ljava/lang/String;
    //   459: astore_2
    //   460: new java/lang/StringBuilder
    //   463: astore_3
    //   464: aload_3
    //   465: invokespecial <init> : ()V
    //   468: ldc 'trace open fail:%s : %s'
    //   470: iconst_2
    //   471: anewarray java/lang/Object
    //   474: dup
    //   475: iconst_0
    //   476: aload_2
    //   477: aastore
    //   478: dup
    //   479: iconst_1
    //   480: aload_3
    //   481: aload_1
    //   482: invokevirtual getMessage : ()Ljava/lang/String;
    //   485: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   488: invokevirtual toString : ()Ljava/lang/String;
    //   491: aastore
    //   492: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   495: pop
    //   496: aload_0
    //   497: ifnull -> 8
    //   500: aload_0
    //   501: invokevirtual close : ()V
    //   504: goto -> 8
    //   507: astore_0
    //   508: aload_0
    //   509: invokestatic a : (Ljava/lang/Throwable;)Z
    //   512: ifne -> 8
    //   515: aload_0
    //   516: invokevirtual printStackTrace : ()V
    //   519: goto -> 8
    //   522: aload_1
    //   523: aload #7
    //   525: iconst_1
    //   526: aaload
    //   527: invokevirtual toString : ()Ljava/lang/String;
    //   530: ldc '\s'
    //   532: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   535: iconst_2
    //   536: aaload
    //   537: invokestatic parseLong : (Ljava/lang/String;)J
    //   540: invokeinterface a : (J)Z
    //   545: istore #13
    //   547: iload #13
    //   549: ifne -> 99
    //   552: aload_3
    //   553: invokevirtual close : ()V
    //   556: goto -> 8
    //   559: astore_0
    //   560: aload_0
    //   561: invokestatic a : (Ljava/lang/Throwable;)Z
    //   564: ifne -> 8
    //   567: aload_0
    //   568: invokevirtual printStackTrace : ()V
    //   571: goto -> 8
    //   574: aload_3
    //   575: invokevirtual close : ()V
    //   578: goto -> 8
    //   581: astore_0
    //   582: aload_0
    //   583: invokestatic a : (Ljava/lang/Throwable;)Z
    //   586: ifne -> 8
    //   589: aload_0
    //   590: invokevirtual printStackTrace : ()V
    //   593: goto -> 8
    //   596: astore_0
    //   597: aconst_null
    //   598: astore_1
    //   599: aload_1
    //   600: ifnull -> 607
    //   603: aload_1
    //   604: invokevirtual close : ()V
    //   607: aload_0
    //   608: athrow
    //   609: astore_1
    //   610: aload_1
    //   611: invokestatic a : (Ljava/lang/Throwable;)Z
    //   614: ifne -> 607
    //   617: aload_1
    //   618: invokevirtual printStackTrace : ()V
    //   621: goto -> 607
    //   624: astore_0
    //   625: aload_3
    //   626: astore_1
    //   627: goto -> 599
    //   630: astore_3
    //   631: aload_0
    //   632: astore_1
    //   633: aload_3
    //   634: astore_0
    //   635: goto -> 599
    //   638: astore_1
    //   639: goto -> 452
    // Exception table:
    //   from	to	target	type
    //   37	58	638	java/lang/Exception
    //   37	58	596	finally
    //   58	99	449	java/lang/Exception
    //   58	99	624	finally
    //   99	114	449	java/lang/Exception
    //   99	114	624	finally
    //   119	200	449	java/lang/Exception
    //   119	200	624	finally
    //   205	209	212	java/io/IOException
    //   227	271	449	java/lang/Exception
    //   227	271	624	finally
    //   276	280	283	java/io/IOException
    //   298	317	449	java/lang/Exception
    //   298	317	624	finally
    //   330	446	449	java/lang/Exception
    //   330	446	624	finally
    //   452	496	630	finally
    //   500	504	507	java/io/IOException
    //   522	547	449	java/lang/Exception
    //   522	547	624	finally
    //   552	556	559	java/io/IOException
    //   574	578	581	java/io/IOException
    //   603	607	609	java/io/IOException
  }
  
  public static final class a {
    public long a;
    
    public String b;
    
    public long c;
    
    public Map<String, String[]> d;
  }
  
  public static interface b {
    boolean a(long param1Long);
    
    boolean a(long param1Long1, long param1Long2, String param1String);
    
    boolean a(String param1String1, int param1Int, String param1String2, String param1String3);
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/anr/TraceFileHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */