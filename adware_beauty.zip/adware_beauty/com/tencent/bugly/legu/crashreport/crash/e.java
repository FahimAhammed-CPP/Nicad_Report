package com.tencent.bugly.legu.crashreport.crash;

import android.content.Context;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.common.strategy.StrategyBean;
import com.tencent.bugly.legu.crashreport.common.strategy.a;
import com.tencent.bugly.legu.proguard.a;
import com.tencent.bugly.legu.proguard.w;
import com.tencent.bugly.legu.proguard.x;
import java.util.HashMap;

public final class e implements Thread.UncaughtExceptionHandler {
  private static Thread.UncaughtExceptionHandler f;
  
  private static boolean h;
  
  private static final Object i = new Object();
  
  private static int j;
  
  private Context a;
  
  private b b;
  
  private a c;
  
  private a d;
  
  private Thread.UncaughtExceptionHandler e;
  
  private boolean g = false;
  
  public e(Context paramContext, b paramb, a parama, a parama1) {
    this.a = paramContext;
    this.b = paramb;
    this.c = parama;
    this.d = parama1;
  }
  
  private static String a(Throwable paramThrowable, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: ifnonnull -> 8
    //   4: aconst_null
    //   5: astore_0
    //   6: aload_0
    //   7: areturn
    //   8: new java/lang/StringBuilder
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: astore_2
    //   16: aload_0
    //   17: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   20: ifnull -> 133
    //   23: aload_0
    //   24: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   27: astore_3
    //   28: aload_3
    //   29: arraylength
    //   30: istore #4
    //   32: iconst_0
    //   33: istore #5
    //   35: iload #5
    //   37: iload #4
    //   39: if_icmpge -> 133
    //   42: aload_3
    //   43: iload #5
    //   45: aaload
    //   46: astore_0
    //   47: iload_1
    //   48: ifle -> 95
    //   51: aload_2
    //   52: invokevirtual length : ()I
    //   55: iload_1
    //   56: if_icmplt -> 95
    //   59: new java/lang/StringBuilder
    //   62: astore_0
    //   63: aload_0
    //   64: ldc '\\n[Stack over limit size :'
    //   66: invokespecial <init> : (Ljava/lang/String;)V
    //   69: aload_2
    //   70: aload_0
    //   71: iload_1
    //   72: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   75: ldc ' , has been cutted !]'
    //   77: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: invokevirtual toString : ()Ljava/lang/String;
    //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: pop
    //   87: aload_2
    //   88: invokevirtual toString : ()Ljava/lang/String;
    //   91: astore_0
    //   92: goto -> 6
    //   95: aload_2
    //   96: aload_0
    //   97: invokevirtual toString : ()Ljava/lang/String;
    //   100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: ldc '\\n'
    //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: pop
    //   109: iinc #5, 1
    //   112: goto -> 35
    //   115: astore_0
    //   116: ldc 'gen stack error %s'
    //   118: iconst_1
    //   119: anewarray java/lang/Object
    //   122: dup
    //   123: iconst_0
    //   124: aload_0
    //   125: invokevirtual toString : ()Ljava/lang/String;
    //   128: aastore
    //   129: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   132: pop
    //   133: aload_2
    //   134: invokevirtual toString : ()Ljava/lang/String;
    //   137: astore_0
    //   138: goto -> 6
    // Exception table:
    //   from	to	target	type
    //   16	32	115	java/lang/Throwable
    //   51	92	115	java/lang/Throwable
    //   95	109	115	java/lang/Throwable
  }
  
  private void a(Thread.UncaughtExceptionHandler paramUncaughtExceptionHandler) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: putfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: astore_1
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_1
    //   14: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	10	finally
  }
  
  private CrashDetailBean b(Thread paramThread, Throwable paramThrowable, boolean paramBoolean, String paramString, byte[] paramArrayOfbyte) {
    String str1;
    StringBuilder stringBuilder;
    boolean bool = c.a().l();
    if (bool && paramBoolean) {
      String str = " This Crash Caused By ANR , PLS To Fix ANR , This Trace May Be Not Useful![Bugly]";
    } else {
      String str = "";
    } 
    if (bool && paramBoolean)
      w.e("This Crash Caused By ANR , PLS To Fix ANR , This Trace May Be Not Useful!", new Object[0]); 
    CrashDetailBean crashDetailBean = new CrashDetailBean();
    w.e("3", new Object[0]);
    crashDetailBean.B = a.i();
    crashDetailBean.C = a.g();
    crashDetailBean.D = a.k();
    crashDetailBean.E = this.d.o();
    crashDetailBean.F = this.d.n();
    crashDetailBean.G = this.d.p();
    crashDetailBean.w = a.a(this.a, c.d, null);
    crashDetailBean.x = x.a(paramBoolean);
    if (crashDetailBean.x == null) {
      i = 0;
    } else {
      i = crashDetailBean.x.length;
    } 
    w.a("user log size:%d", new Object[] { Integer.valueOf(i) });
    if (paramBoolean) {
      i = 0;
    } else {
      i = 2;
    } 
    crashDetailBean.b = i;
    crashDetailBean.e = this.d.g();
    crashDetailBean.f = this.d.i;
    crashDetailBean.g = this.d.t();
    crashDetailBean.m = this.d.f();
    if (paramThrowable == null)
      return null; 
    Throwable throwable2;
    for (throwable2 = paramThrowable; throwable2.getCause() != null; throwable2 = throwable2.getCause());
    String str2 = paramThrowable.getClass().getName();
    String str3 = b(paramThrowable, 1000);
    String str4 = str3;
    if (str3 == null)
      str4 = ""; 
    int i = (paramThrowable.getStackTrace()).length;
    if (paramThrowable.getCause() != null) {
      bool = true;
    } else {
      bool = false;
    } 
    w.e("stack frame :%d, has cause %b", new Object[] { Integer.valueOf(i), Boolean.valueOf(bool) });
    str3 = "";
    if ((paramThrowable.getStackTrace()).length > 0)
      str3 = paramThrowable.getStackTrace()[0].toString(); 
    if (throwable2 != paramThrowable) {
      crashDetailBean.n = throwable2.getClass().getName();
      crashDetailBean.o = b(throwable2, 1000);
      if (crashDetailBean.o == null)
        crashDetailBean.o = ""; 
      crashDetailBean.p = throwable2.getStackTrace()[0].toString();
      stringBuilder = new StringBuilder();
      stringBuilder.append(str2).append(":").append(str4).append("\n");
      stringBuilder.append(str3);
      stringBuilder.append("\n......");
      stringBuilder.append("\nCaused by:\n");
      stringBuilder.append(crashDetailBean.n).append(":").append(crashDetailBean.o).append("\n");
      str1 = a(throwable2, c.e);
      stringBuilder.append(str1);
      crashDetailBean.q = stringBuilder.toString();
    } else {
      crashDetailBean.n = str2;
      crashDetailBean.o = str4 + stringBuilder;
      if (crashDetailBean.o == null)
        crashDetailBean.o = ""; 
      crashDetailBean.p = str3;
      str1 = a((Throwable)str1, c.e);
      crashDetailBean.q = str1;
    } 
    crashDetailBean.r = System.currentTimeMillis();
    crashDetailBean.u = a.b(crashDetailBean.q.getBytes());
    try {
      crashDetailBean.y = a.a(c.e, false);
      crashDetailBean.z = this.d.d;
      stringBuilder = new StringBuilder();
      this();
      crashDetailBean.A = stringBuilder.append(paramThread.getName()).append("(").append(paramThread.getId()).append(")").toString();
      crashDetailBean.y.put(crashDetailBean.A, str1);
      crashDetailBean.H = this.d.v();
      crashDetailBean.h = this.d.s();
      crashDetailBean.i = this.d.E();
      crashDetailBean.L = this.d.a;
      crashDetailBean.M = this.d.n;
      crashDetailBean.O = this.d.B();
      crashDetailBean.P = this.d.C();
      crashDetailBean.Q = this.d.w();
      crashDetailBean.R = this.d.A();
      if (paramBoolean) {
        this.b.b(crashDetailBean);
      } else {
        boolean bool1;
        if (paramString != null && paramString.length() > 0) {
          i = 1;
        } else {
          i = 0;
        } 
        if (paramArrayOfbyte != null && paramArrayOfbyte.length > 0) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (i != 0) {
          crashDetailBean.N = new HashMap<String, String>(1);
          crashDetailBean.N.put("UserData", paramString);
        } 
        if (bool1)
          crashDetailBean.S = paramArrayOfbyte; 
      } 
      CrashDetailBean crashDetailBean1 = crashDetailBean;
    } catch (Throwable throwable1) {
      w.e("handle crash error %s", new Object[] { throwable1.toString() });
    } 
    return (CrashDetailBean)throwable1;
  }
  
  private static String b(Throwable paramThrowable, int paramInt) {
    return (paramThrowable.getMessage() == null) ? "" : ((paramThrowable.getMessage().length() <= 1000) ? paramThrowable.getMessage() : (paramThrowable.getMessage().substring(0, 1000) + "\n[Message over limit size:1000" + ", has been cutted!]"));
  }
  
  private static boolean b(Thread.UncaughtExceptionHandler paramUncaughtExceptionHandler) {
    boolean bool = true;
    if (paramUncaughtExceptionHandler == null)
      return bool; 
    String str = paramUncaughtExceptionHandler.getClass().getName();
    StackTraceElement[] arrayOfStackTraceElement = Thread.currentThread().getStackTrace();
    int i = arrayOfStackTraceElement.length;
    byte b1 = 0;
    while (true) {
      boolean bool1 = bool;
      if (b1 < i) {
        StackTraceElement stackTraceElement = arrayOfStackTraceElement[b1];
        String str2 = stackTraceElement.getClassName();
        String str1 = stackTraceElement.getMethodName();
        if (str.equals(str2) && "uncaughtException".equals(str1))
          return false; 
        b1++;
        continue;
      } 
      return bool1;
    } 
  }
  
  private static boolean c() {
    synchronized (i) {
      boolean bool = h;
      h = true;
      return bool;
    } 
  }
  
  public final void a() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: getstatic com/tencent/bugly/legu/crashreport/crash/e.j : I
    //   5: bipush #10
    //   7: if_icmplt -> 32
    //   10: ldc_w 'java crash handler over %d, no need set.'
    //   13: iconst_1
    //   14: anewarray java/lang/Object
    //   17: dup
    //   18: iconst_0
    //   19: bipush #10
    //   21: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   24: aastore
    //   25: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   28: pop
    //   29: aload_0
    //   30: monitorexit
    //   31: return
    //   32: invokestatic getDefaultUncaughtExceptionHandler : ()Ljava/lang/Thread$UncaughtExceptionHandler;
    //   35: astore_1
    //   36: aload_1
    //   37: ifnull -> 29
    //   40: aload_0
    //   41: invokevirtual getClass : ()Ljava/lang/Class;
    //   44: invokevirtual getName : ()Ljava/lang/String;
    //   47: aload_1
    //   48: invokevirtual getClass : ()Ljava/lang/Class;
    //   51: invokevirtual getName : ()Ljava/lang/String;
    //   54: invokevirtual equals : (Ljava/lang/Object;)Z
    //   57: ifne -> 29
    //   60: ldc_w 'com.android.internal.os.RuntimeInit$UncaughtHandler'
    //   63: aload_1
    //   64: invokevirtual getClass : ()Ljava/lang/Class;
    //   67: invokevirtual getName : ()Ljava/lang/String;
    //   70: invokevirtual equals : (Ljava/lang/Object;)Z
    //   73: ifeq -> 151
    //   76: ldc_w 'backup system java handler: %s'
    //   79: iconst_1
    //   80: anewarray java/lang/Object
    //   83: dup
    //   84: iconst_0
    //   85: aload_1
    //   86: invokevirtual toString : ()Ljava/lang/String;
    //   89: aastore
    //   90: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   93: pop
    //   94: aload_1
    //   95: putstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   98: aload_0
    //   99: aload_1
    //   100: putfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   103: aload_0
    //   104: aload_1
    //   105: invokespecial a : (Ljava/lang/Thread$UncaughtExceptionHandler;)V
    //   108: aload_0
    //   109: invokestatic setDefaultUncaughtExceptionHandler : (Ljava/lang/Thread$UncaughtExceptionHandler;)V
    //   112: aload_0
    //   113: iconst_1
    //   114: putfield g : Z
    //   117: getstatic com/tencent/bugly/legu/crashreport/crash/e.j : I
    //   120: iconst_1
    //   121: iadd
    //   122: putstatic com/tencent/bugly/legu/crashreport/crash/e.j : I
    //   125: ldc_w 'registered java monitor: %s'
    //   128: iconst_1
    //   129: anewarray java/lang/Object
    //   132: dup
    //   133: iconst_0
    //   134: aload_0
    //   135: invokevirtual toString : ()Ljava/lang/String;
    //   138: aastore
    //   139: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   142: pop
    //   143: goto -> 29
    //   146: astore_1
    //   147: aload_0
    //   148: monitorexit
    //   149: aload_1
    //   150: athrow
    //   151: ldc_w 'backup java handler: %s'
    //   154: iconst_1
    //   155: anewarray java/lang/Object
    //   158: dup
    //   159: iconst_0
    //   160: aload_1
    //   161: invokevirtual toString : ()Ljava/lang/String;
    //   164: aastore
    //   165: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   168: pop
    //   169: aload_0
    //   170: aload_1
    //   171: putfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   174: goto -> 103
    // Exception table:
    //   from	to	target	type
    //   2	29	146	finally
    //   32	36	146	finally
    //   40	103	146	finally
    //   103	143	146	finally
    //   151	174	146	finally
  }
  
  public final void a(StrategyBean paramStrategyBean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnull -> 49
    //   6: aload_1
    //   7: getfield d : Z
    //   10: aload_0
    //   11: getfield g : Z
    //   14: if_icmpeq -> 49
    //   17: ldc_w 'java changed to %b'
    //   20: iconst_1
    //   21: anewarray java/lang/Object
    //   24: dup
    //   25: iconst_0
    //   26: aload_1
    //   27: getfield d : Z
    //   30: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   33: aastore
    //   34: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   37: pop
    //   38: aload_1
    //   39: getfield d : Z
    //   42: ifeq -> 52
    //   45: aload_0
    //   46: invokevirtual a : ()V
    //   49: aload_0
    //   50: monitorexit
    //   51: return
    //   52: aload_0
    //   53: invokevirtual b : ()V
    //   56: goto -> 49
    //   59: astore_1
    //   60: aload_0
    //   61: monitorexit
    //   62: aload_1
    //   63: athrow
    // Exception table:
    //   from	to	target	type
    //   6	49	59	finally
    //   52	56	59	finally
  }
  
  public final void a(Thread paramThread, Throwable paramThrowable, boolean paramBoolean, String paramString, byte[] paramArrayOfbyte) {
    // Byte code:
    //   0: iload_3
    //   1: ifeq -> 134
    //   4: ldc_w 'Java Crash Happen cause by %s(%d)'
    //   7: iconst_2
    //   8: anewarray java/lang/Object
    //   11: dup
    //   12: iconst_0
    //   13: aload_1
    //   14: invokevirtual getName : ()Ljava/lang/String;
    //   17: aastore
    //   18: dup
    //   19: iconst_1
    //   20: aload_1
    //   21: invokevirtual getId : ()J
    //   24: invokestatic valueOf : (J)Ljava/lang/Long;
    //   27: aastore
    //   28: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   31: pop
    //   32: invokestatic c : ()Z
    //   35: ifeq -> 76
    //   38: ldc_w 'this class has handled this exception'
    //   41: iconst_0
    //   42: anewarray java/lang/Object
    //   45: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   48: pop
    //   49: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   52: ifnull -> 110
    //   55: ldc_w 'call system handler'
    //   58: iconst_0
    //   59: anewarray java/lang/Object
    //   62: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   65: pop
    //   66: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   69: aload_1
    //   70: aload_2
    //   71: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   76: aload_0
    //   77: getfield g : Z
    //   80: ifne -> 288
    //   83: ldc_w 'Java crash handler is disable. Just return.'
    //   86: iconst_0
    //   87: anewarray java/lang/Object
    //   90: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   93: pop
    //   94: iload_3
    //   95: ifne -> 148
    //   98: ldc_w 'not to shut down return'
    //   101: iconst_0
    //   102: anewarray java/lang/Object
    //   105: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   108: pop
    //   109: return
    //   110: ldc_w 'current process die'
    //   113: iconst_0
    //   114: anewarray java/lang/Object
    //   117: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   120: pop
    //   121: invokestatic myPid : ()I
    //   124: invokestatic killProcess : (I)V
    //   127: iconst_1
    //   128: invokestatic exit : (I)V
    //   131: goto -> 76
    //   134: ldc_w 'Java Catch Happen'
    //   137: iconst_0
    //   138: anewarray java/lang/Object
    //   141: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   144: pop
    //   145: goto -> 76
    //   148: aload_0
    //   149: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   152: ifnull -> 201
    //   155: aload_0
    //   156: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   159: invokestatic b : (Ljava/lang/Thread$UncaughtExceptionHandler;)Z
    //   162: ifeq -> 201
    //   165: ldc_w 'sys default last handle start!'
    //   168: iconst_0
    //   169: anewarray java/lang/Object
    //   172: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   175: pop
    //   176: aload_0
    //   177: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   180: aload_1
    //   181: aload_2
    //   182: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   187: ldc_w 'sys default last handle end!'
    //   190: iconst_0
    //   191: anewarray java/lang/Object
    //   194: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   197: pop
    //   198: goto -> 109
    //   201: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   204: ifnull -> 242
    //   207: ldc_w 'system handle start!'
    //   210: iconst_0
    //   211: anewarray java/lang/Object
    //   214: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   217: pop
    //   218: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   221: aload_1
    //   222: aload_2
    //   223: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   228: ldc_w 'system handle end!'
    //   231: iconst_0
    //   232: anewarray java/lang/Object
    //   235: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   238: pop
    //   239: goto -> 109
    //   242: ldc_w 'crashreport last handle start!'
    //   245: iconst_0
    //   246: anewarray java/lang/Object
    //   249: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   252: pop
    //   253: ldc_w 'current process die'
    //   256: iconst_0
    //   257: anewarray java/lang/Object
    //   260: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   263: pop
    //   264: invokestatic myPid : ()I
    //   267: invokestatic killProcess : (I)V
    //   270: iconst_1
    //   271: invokestatic exit : (I)V
    //   274: ldc_w 'crashreport last handle end!'
    //   277: iconst_0
    //   278: anewarray java/lang/Object
    //   281: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   284: pop
    //   285: goto -> 109
    //   288: aload_0
    //   289: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   292: invokevirtual b : ()Z
    //   295: ifne -> 352
    //   298: ldc_w 'waiting for remote sync'
    //   301: iconst_0
    //   302: anewarray java/lang/Object
    //   305: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   308: pop
    //   309: iconst_0
    //   310: istore #6
    //   312: aload_0
    //   313: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   316: invokevirtual b : ()Z
    //   319: istore #7
    //   321: iload #7
    //   323: ifne -> 352
    //   326: ldc2_w 500
    //   329: invokestatic sleep : (J)V
    //   332: iload #6
    //   334: sipush #500
    //   337: iadd
    //   338: istore #8
    //   340: iload #8
    //   342: istore #6
    //   344: iload #8
    //   346: sipush #5000
    //   349: if_icmplt -> 312
    //   352: aload_0
    //   353: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   356: invokevirtual b : ()Z
    //   359: ifne -> 373
    //   362: ldc_w 'no remote but still store!'
    //   365: iconst_0
    //   366: anewarray java/lang/Object
    //   369: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   372: pop
    //   373: aload_0
    //   374: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   377: invokevirtual c : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   380: getfield d : Z
    //   383: ifne -> 646
    //   386: aload_0
    //   387: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   390: invokevirtual b : ()Z
    //   393: ifeq -> 646
    //   396: ldc_w 'crash report was closed by remote , will not upload to Bugly , print local for helpful!'
    //   399: iconst_0
    //   400: anewarray java/lang/Object
    //   403: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   406: pop
    //   407: iload_3
    //   408: ifeq -> 498
    //   411: ldc_w 'JAVA_CRASH'
    //   414: astore #4
    //   416: aload #4
    //   418: invokestatic n : ()Ljava/lang/String;
    //   421: aload_0
    //   422: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   425: getfield d : Ljava/lang/String;
    //   428: aload_1
    //   429: aload_2
    //   430: invokestatic a : (Ljava/lang/Throwable;)Ljava/lang/String;
    //   433: aconst_null
    //   434: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Thread;Ljava/lang/String;Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   437: iload_3
    //   438: ifne -> 506
    //   441: ldc_w 'not to shut down return'
    //   444: iconst_0
    //   445: anewarray java/lang/Object
    //   448: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   451: pop
    //   452: goto -> 109
    //   455: astore #9
    //   457: aload #9
    //   459: invokevirtual printStackTrace : ()V
    //   462: goto -> 332
    //   465: astore #4
    //   467: aload #4
    //   469: invokestatic a : (Ljava/lang/Throwable;)Z
    //   472: ifne -> 480
    //   475: aload #4
    //   477: invokevirtual printStackTrace : ()V
    //   480: iload_3
    //   481: ifne -> 1055
    //   484: ldc_w 'not to shut down return'
    //   487: iconst_0
    //   488: anewarray java/lang/Object
    //   491: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   494: pop
    //   495: goto -> 109
    //   498: ldc_w 'JAVA_CATCH'
    //   501: astore #4
    //   503: goto -> 416
    //   506: aload_0
    //   507: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   510: ifnull -> 559
    //   513: aload_0
    //   514: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   517: invokestatic b : (Ljava/lang/Thread$UncaughtExceptionHandler;)Z
    //   520: ifeq -> 559
    //   523: ldc_w 'sys default last handle start!'
    //   526: iconst_0
    //   527: anewarray java/lang/Object
    //   530: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   533: pop
    //   534: aload_0
    //   535: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   538: aload_1
    //   539: aload_2
    //   540: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   545: ldc_w 'sys default last handle end!'
    //   548: iconst_0
    //   549: anewarray java/lang/Object
    //   552: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   555: pop
    //   556: goto -> 109
    //   559: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   562: ifnull -> 600
    //   565: ldc_w 'system handle start!'
    //   568: iconst_0
    //   569: anewarray java/lang/Object
    //   572: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   575: pop
    //   576: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   579: aload_1
    //   580: aload_2
    //   581: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   586: ldc_w 'system handle end!'
    //   589: iconst_0
    //   590: anewarray java/lang/Object
    //   593: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   596: pop
    //   597: goto -> 109
    //   600: ldc_w 'crashreport last handle start!'
    //   603: iconst_0
    //   604: anewarray java/lang/Object
    //   607: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   610: pop
    //   611: ldc_w 'current process die'
    //   614: iconst_0
    //   615: anewarray java/lang/Object
    //   618: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   621: pop
    //   622: invokestatic myPid : ()I
    //   625: invokestatic killProcess : (I)V
    //   628: iconst_1
    //   629: invokestatic exit : (I)V
    //   632: ldc_w 'crashreport last handle end!'
    //   635: iconst_0
    //   636: anewarray java/lang/Object
    //   639: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   642: pop
    //   643: goto -> 109
    //   646: aload_0
    //   647: aload_1
    //   648: aload_2
    //   649: iload_3
    //   650: aload #4
    //   652: aload #5
    //   654: invokespecial b : (Ljava/lang/Thread;Ljava/lang/Throwable;ZLjava/lang/String;[B)Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;
    //   657: astore #5
    //   659: aload #5
    //   661: ifnonnull -> 833
    //   664: ldc_w 'pkg crash datas fail!'
    //   667: iconst_0
    //   668: anewarray java/lang/Object
    //   671: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   674: pop
    //   675: iload_3
    //   676: ifne -> 693
    //   679: ldc_w 'not to shut down return'
    //   682: iconst_0
    //   683: anewarray java/lang/Object
    //   686: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   689: pop
    //   690: goto -> 109
    //   693: aload_0
    //   694: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   697: ifnull -> 746
    //   700: aload_0
    //   701: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   704: invokestatic b : (Ljava/lang/Thread$UncaughtExceptionHandler;)Z
    //   707: ifeq -> 746
    //   710: ldc_w 'sys default last handle start!'
    //   713: iconst_0
    //   714: anewarray java/lang/Object
    //   717: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   720: pop
    //   721: aload_0
    //   722: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   725: aload_1
    //   726: aload_2
    //   727: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   732: ldc_w 'sys default last handle end!'
    //   735: iconst_0
    //   736: anewarray java/lang/Object
    //   739: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   742: pop
    //   743: goto -> 109
    //   746: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   749: ifnull -> 787
    //   752: ldc_w 'system handle start!'
    //   755: iconst_0
    //   756: anewarray java/lang/Object
    //   759: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   762: pop
    //   763: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   766: aload_1
    //   767: aload_2
    //   768: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   773: ldc_w 'system handle end!'
    //   776: iconst_0
    //   777: anewarray java/lang/Object
    //   780: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   783: pop
    //   784: goto -> 109
    //   787: ldc_w 'crashreport last handle start!'
    //   790: iconst_0
    //   791: anewarray java/lang/Object
    //   794: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   797: pop
    //   798: ldc_w 'current process die'
    //   801: iconst_0
    //   802: anewarray java/lang/Object
    //   805: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   808: pop
    //   809: invokestatic myPid : ()I
    //   812: invokestatic killProcess : (I)V
    //   815: iconst_1
    //   816: invokestatic exit : (I)V
    //   819: ldc_w 'crashreport last handle end!'
    //   822: iconst_0
    //   823: anewarray java/lang/Object
    //   826: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   829: pop
    //   830: goto -> 109
    //   833: iload_3
    //   834: ifeq -> 907
    //   837: ldc_w 'JAVA_CRASH'
    //   840: astore #4
    //   842: aload #4
    //   844: invokestatic n : ()Ljava/lang/String;
    //   847: aload_0
    //   848: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   851: getfield d : Ljava/lang/String;
    //   854: aload_1
    //   855: aload_2
    //   856: invokestatic a : (Ljava/lang/Throwable;)Ljava/lang/String;
    //   859: aload #5
    //   861: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Thread;Ljava/lang/String;Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   864: aload_0
    //   865: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   868: aload #5
    //   870: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)Z
    //   873: ifne -> 889
    //   876: aload_0
    //   877: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   880: aload #5
    //   882: ldc2_w 5000
    //   885: iload_3
    //   886: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;JZ)V
    //   889: iload_3
    //   890: ifne -> 915
    //   893: ldc_w 'not to shut down return'
    //   896: iconst_0
    //   897: anewarray java/lang/Object
    //   900: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   903: pop
    //   904: goto -> 109
    //   907: ldc_w 'JAVA_CATCH'
    //   910: astore #4
    //   912: goto -> 842
    //   915: aload_0
    //   916: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   919: ifnull -> 968
    //   922: aload_0
    //   923: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   926: invokestatic b : (Ljava/lang/Thread$UncaughtExceptionHandler;)Z
    //   929: ifeq -> 968
    //   932: ldc_w 'sys default last handle start!'
    //   935: iconst_0
    //   936: anewarray java/lang/Object
    //   939: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   942: pop
    //   943: aload_0
    //   944: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   947: aload_1
    //   948: aload_2
    //   949: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   954: ldc_w 'sys default last handle end!'
    //   957: iconst_0
    //   958: anewarray java/lang/Object
    //   961: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   964: pop
    //   965: goto -> 109
    //   968: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   971: ifnull -> 1009
    //   974: ldc_w 'system handle start!'
    //   977: iconst_0
    //   978: anewarray java/lang/Object
    //   981: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   984: pop
    //   985: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   988: aload_1
    //   989: aload_2
    //   990: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   995: ldc_w 'system handle end!'
    //   998: iconst_0
    //   999: anewarray java/lang/Object
    //   1002: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1005: pop
    //   1006: goto -> 109
    //   1009: ldc_w 'crashreport last handle start!'
    //   1012: iconst_0
    //   1013: anewarray java/lang/Object
    //   1016: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1019: pop
    //   1020: ldc_w 'current process die'
    //   1023: iconst_0
    //   1024: anewarray java/lang/Object
    //   1027: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1030: pop
    //   1031: invokestatic myPid : ()I
    //   1034: invokestatic killProcess : (I)V
    //   1037: iconst_1
    //   1038: invokestatic exit : (I)V
    //   1041: ldc_w 'crashreport last handle end!'
    //   1044: iconst_0
    //   1045: anewarray java/lang/Object
    //   1048: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1051: pop
    //   1052: goto -> 109
    //   1055: aload_0
    //   1056: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   1059: ifnull -> 1108
    //   1062: aload_0
    //   1063: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   1066: invokestatic b : (Ljava/lang/Thread$UncaughtExceptionHandler;)Z
    //   1069: ifeq -> 1108
    //   1072: ldc_w 'sys default last handle start!'
    //   1075: iconst_0
    //   1076: anewarray java/lang/Object
    //   1079: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1082: pop
    //   1083: aload_0
    //   1084: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   1087: aload_1
    //   1088: aload_2
    //   1089: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   1094: ldc_w 'sys default last handle end!'
    //   1097: iconst_0
    //   1098: anewarray java/lang/Object
    //   1101: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1104: pop
    //   1105: goto -> 109
    //   1108: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   1111: ifnull -> 1149
    //   1114: ldc_w 'system handle start!'
    //   1117: iconst_0
    //   1118: anewarray java/lang/Object
    //   1121: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1124: pop
    //   1125: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   1128: aload_1
    //   1129: aload_2
    //   1130: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   1135: ldc_w 'system handle end!'
    //   1138: iconst_0
    //   1139: anewarray java/lang/Object
    //   1142: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1145: pop
    //   1146: goto -> 109
    //   1149: ldc_w 'crashreport last handle start!'
    //   1152: iconst_0
    //   1153: anewarray java/lang/Object
    //   1156: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1159: pop
    //   1160: ldc_w 'current process die'
    //   1163: iconst_0
    //   1164: anewarray java/lang/Object
    //   1167: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1170: pop
    //   1171: invokestatic myPid : ()I
    //   1174: invokestatic killProcess : (I)V
    //   1177: iconst_1
    //   1178: invokestatic exit : (I)V
    //   1181: ldc_w 'crashreport last handle end!'
    //   1184: iconst_0
    //   1185: anewarray java/lang/Object
    //   1188: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1191: pop
    //   1192: goto -> 109
    //   1195: astore #4
    //   1197: iload_3
    //   1198: ifne -> 1215
    //   1201: ldc_w 'not to shut down return'
    //   1204: iconst_0
    //   1205: anewarray java/lang/Object
    //   1208: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1211: pop
    //   1212: goto -> 109
    //   1215: aload_0
    //   1216: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   1219: ifnull -> 1268
    //   1222: aload_0
    //   1223: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   1226: invokestatic b : (Ljava/lang/Thread$UncaughtExceptionHandler;)Z
    //   1229: ifeq -> 1268
    //   1232: ldc_w 'sys default last handle start!'
    //   1235: iconst_0
    //   1236: anewarray java/lang/Object
    //   1239: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1242: pop
    //   1243: aload_0
    //   1244: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   1247: aload_1
    //   1248: aload_2
    //   1249: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   1254: ldc_w 'sys default last handle end!'
    //   1257: iconst_0
    //   1258: anewarray java/lang/Object
    //   1261: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1264: pop
    //   1265: aload #4
    //   1267: athrow
    //   1268: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   1271: ifnull -> 1309
    //   1274: ldc_w 'system handle start!'
    //   1277: iconst_0
    //   1278: anewarray java/lang/Object
    //   1281: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1284: pop
    //   1285: getstatic com/tencent/bugly/legu/crashreport/crash/e.f : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   1288: aload_1
    //   1289: aload_2
    //   1290: invokeinterface uncaughtException : (Ljava/lang/Thread;Ljava/lang/Throwable;)V
    //   1295: ldc_w 'system handle end!'
    //   1298: iconst_0
    //   1299: anewarray java/lang/Object
    //   1302: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1305: pop
    //   1306: goto -> 1265
    //   1309: ldc_w 'crashreport last handle start!'
    //   1312: iconst_0
    //   1313: anewarray java/lang/Object
    //   1316: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1319: pop
    //   1320: ldc_w 'current process die'
    //   1323: iconst_0
    //   1324: anewarray java/lang/Object
    //   1327: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1330: pop
    //   1331: invokestatic myPid : ()I
    //   1334: invokestatic killProcess : (I)V
    //   1337: iconst_1
    //   1338: invokestatic exit : (I)V
    //   1341: ldc_w 'crashreport last handle end!'
    //   1344: iconst_0
    //   1345: anewarray java/lang/Object
    //   1348: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1351: pop
    //   1352: goto -> 1265
    // Exception table:
    //   from	to	target	type
    //   76	94	465	java/lang/Throwable
    //   76	94	1195	finally
    //   288	309	465	java/lang/Throwable
    //   288	309	1195	finally
    //   312	321	465	java/lang/Throwable
    //   312	321	1195	finally
    //   326	332	455	java/lang/InterruptedException
    //   326	332	465	java/lang/Throwable
    //   326	332	1195	finally
    //   352	373	465	java/lang/Throwable
    //   352	373	1195	finally
    //   373	407	465	java/lang/Throwable
    //   373	407	1195	finally
    //   416	437	465	java/lang/Throwable
    //   416	437	1195	finally
    //   457	462	465	java/lang/Throwable
    //   457	462	1195	finally
    //   467	480	1195	finally
    //   646	659	465	java/lang/Throwable
    //   646	659	1195	finally
    //   664	675	465	java/lang/Throwable
    //   664	675	1195	finally
    //   842	889	465	java/lang/Throwable
    //   842	889	1195	finally
  }
  
  public final void b() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: iconst_0
    //   4: putfield g : Z
    //   7: ldc_w 'close java monitor!'
    //   10: iconst_0
    //   11: anewarray java/lang/Object
    //   14: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   17: pop
    //   18: invokestatic getDefaultUncaughtExceptionHandler : ()Ljava/lang/Thread$UncaughtExceptionHandler;
    //   21: invokevirtual getClass : ()Ljava/lang/Class;
    //   24: invokevirtual getName : ()Ljava/lang/String;
    //   27: ldc_w 'bugly'
    //   30: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   33: ifeq -> 69
    //   36: ldc_w 'Java monitor to unregister: %s'
    //   39: iconst_1
    //   40: anewarray java/lang/Object
    //   43: dup
    //   44: iconst_0
    //   45: aload_0
    //   46: invokevirtual toString : ()Ljava/lang/String;
    //   49: aastore
    //   50: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   53: pop
    //   54: aload_0
    //   55: getfield e : Ljava/lang/Thread$UncaughtExceptionHandler;
    //   58: invokestatic setDefaultUncaughtExceptionHandler : (Ljava/lang/Thread$UncaughtExceptionHandler;)V
    //   61: getstatic com/tencent/bugly/legu/crashreport/crash/e.j : I
    //   64: iconst_1
    //   65: isub
    //   66: putstatic com/tencent/bugly/legu/crashreport/crash/e.j : I
    //   69: aload_0
    //   70: monitorexit
    //   71: return
    //   72: astore_1
    //   73: aload_0
    //   74: monitorexit
    //   75: aload_1
    //   76: athrow
    // Exception table:
    //   from	to	target	type
    //   2	69	72	finally
  }
  
  public final void uncaughtException(Thread paramThread, Throwable paramThrowable) {
    a(paramThread, paramThrowable, true, null, null);
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */