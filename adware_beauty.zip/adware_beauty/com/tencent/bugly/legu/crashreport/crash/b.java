package com.tencent.bugly.legu.crashreport.crash;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.os.Parcel;
import com.tencent.bugly.legu.BuglyStrategy;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.common.strategy.StrategyBean;
import com.tencent.bugly.legu.crashreport.common.strategy.a;
import com.tencent.bugly.legu.proguard.a;
import com.tencent.bugly.legu.proguard.aj;
import com.tencent.bugly.legu.proguard.ak;
import com.tencent.bugly.legu.proguard.al;
import com.tencent.bugly.legu.proguard.am;
import com.tencent.bugly.legu.proguard.j;
import com.tencent.bugly.legu.proguard.n;
import com.tencent.bugly.legu.proguard.o;
import com.tencent.bugly.legu.proguard.q;
import com.tencent.bugly.legu.proguard.s;
import com.tencent.bugly.legu.proguard.t;
import com.tencent.bugly.legu.proguard.w;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public final class b {
  private static int a = 0;
  
  private Context b;
  
  private o c;
  
  private a d;
  
  private n e;
  
  private BuglyStrategy.a f;
  
  public b(int paramInt, Context paramContext, t paramt, o paramo, a parama, BuglyStrategy.a parama1, n paramn) {
    a = paramInt;
    this.b = paramContext;
    this.c = paramo;
    this.d = parama;
    this.f = parama1;
    this.e = paramn;
  }
  
  private static CrashDetailBean a(Cursor paramCursor) {
    if (paramCursor == null)
      return null; 
    try {
      byte[] arrayOfByte = paramCursor.getBlob(paramCursor.getColumnIndex("_dt"));
      if (arrayOfByte == null)
        return null; 
      long l = paramCursor.getLong(paramCursor.getColumnIndex("_id"));
      CrashDetailBean crashDetailBean2 = (CrashDetailBean)a.a(arrayOfByte, CrashDetailBean.CREATOR);
      CrashDetailBean crashDetailBean1 = crashDetailBean2;
      if (crashDetailBean2 != null) {
        crashDetailBean2.a = l;
        crashDetailBean1 = crashDetailBean2;
      } 
    } catch (Throwable throwable) {}
    return (CrashDetailBean)throwable;
  }
  
  private CrashDetailBean a(List<a> paramList, CrashDetailBean paramCrashDetailBean) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 13
    //   4: aload_1
    //   5: invokeinterface size : ()I
    //   10: ifne -> 17
    //   13: aload_2
    //   14: astore_1
    //   15: aload_1
    //   16: areturn
    //   17: aconst_null
    //   18: astore_3
    //   19: new java/util/ArrayList
    //   22: dup
    //   23: bipush #10
    //   25: invokespecial <init> : (I)V
    //   28: astore #4
    //   30: aload_1
    //   31: invokeinterface iterator : ()Ljava/util/Iterator;
    //   36: astore #5
    //   38: aload #5
    //   40: invokeinterface hasNext : ()Z
    //   45: ifeq -> 81
    //   48: aload #5
    //   50: invokeinterface next : ()Ljava/lang/Object;
    //   55: checkcast com/tencent/bugly/legu/crashreport/crash/a
    //   58: astore #6
    //   60: aload #6
    //   62: getfield e : Z
    //   65: ifeq -> 38
    //   68: aload #4
    //   70: aload #6
    //   72: invokeinterface add : (Ljava/lang/Object;)Z
    //   77: pop
    //   78: goto -> 38
    //   81: aload #4
    //   83: invokeinterface size : ()I
    //   88: ifle -> 516
    //   91: aload_0
    //   92: aload #4
    //   94: invokespecial b : (Ljava/util/List;)Ljava/util/List;
    //   97: astore #6
    //   99: aload #6
    //   101: ifnull -> 516
    //   104: aload #6
    //   106: invokeinterface size : ()I
    //   111: ifle -> 516
    //   114: aload #6
    //   116: invokestatic sort : (Ljava/util/List;)V
    //   119: iconst_0
    //   120: istore #7
    //   122: iload #7
    //   124: aload #6
    //   126: invokeinterface size : ()I
    //   131: if_icmpge -> 281
    //   134: aload #6
    //   136: iload #7
    //   138: invokeinterface get : (I)Ljava/lang/Object;
    //   143: checkcast com/tencent/bugly/legu/crashreport/crash/CrashDetailBean
    //   146: astore #4
    //   148: iload #7
    //   150: ifne -> 162
    //   153: aload #4
    //   155: astore_3
    //   156: iinc #7, 1
    //   159: goto -> 122
    //   162: aload #4
    //   164: getfield s : Ljava/lang/String;
    //   167: ifnull -> 513
    //   170: aload #4
    //   172: getfield s : Ljava/lang/String;
    //   175: ldc '\\n'
    //   177: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   180: astore #4
    //   182: aload #4
    //   184: ifnull -> 513
    //   187: aload #4
    //   189: arraylength
    //   190: istore #8
    //   192: iconst_0
    //   193: istore #9
    //   195: iload #9
    //   197: iload #8
    //   199: if_icmpge -> 513
    //   202: aload #4
    //   204: iload #9
    //   206: aaload
    //   207: astore #5
    //   209: aload_3
    //   210: getfield s : Ljava/lang/String;
    //   213: new java/lang/StringBuilder
    //   216: dup
    //   217: invokespecial <init> : ()V
    //   220: aload #5
    //   222: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: invokevirtual toString : ()Ljava/lang/String;
    //   228: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   231: ifne -> 275
    //   234: aload_3
    //   235: aload_3
    //   236: getfield t : I
    //   239: iconst_1
    //   240: iadd
    //   241: putfield t : I
    //   244: aload_3
    //   245: new java/lang/StringBuilder
    //   248: dup
    //   249: invokespecial <init> : ()V
    //   252: aload_3
    //   253: getfield s : Ljava/lang/String;
    //   256: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   259: aload #5
    //   261: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   264: ldc '\\n'
    //   266: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   269: invokevirtual toString : ()Ljava/lang/String;
    //   272: putfield s : Ljava/lang/String;
    //   275: iinc #9, 1
    //   278: goto -> 195
    //   281: aload_3
    //   282: ifnonnull -> 510
    //   285: aload_2
    //   286: iconst_1
    //   287: putfield j : Z
    //   290: aload_2
    //   291: iconst_0
    //   292: putfield t : I
    //   295: aload_2
    //   296: ldc ''
    //   298: putfield s : Ljava/lang/String;
    //   301: aload_2
    //   302: astore_3
    //   303: aload_1
    //   304: invokeinterface iterator : ()Ljava/util/Iterator;
    //   309: astore #4
    //   311: aload #4
    //   313: invokeinterface hasNext : ()Z
    //   318: ifeq -> 419
    //   321: aload #4
    //   323: invokeinterface next : ()Ljava/lang/Object;
    //   328: checkcast com/tencent/bugly/legu/crashreport/crash/a
    //   331: astore_1
    //   332: aload_1
    //   333: getfield e : Z
    //   336: ifne -> 311
    //   339: aload_1
    //   340: getfield d : Z
    //   343: ifne -> 311
    //   346: aload_3
    //   347: getfield s : Ljava/lang/String;
    //   350: new java/lang/StringBuilder
    //   353: dup
    //   354: invokespecial <init> : ()V
    //   357: aload_1
    //   358: getfield b : J
    //   361: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   364: invokevirtual toString : ()Ljava/lang/String;
    //   367: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   370: ifne -> 311
    //   373: aload_3
    //   374: aload_3
    //   375: getfield t : I
    //   378: iconst_1
    //   379: iadd
    //   380: putfield t : I
    //   383: aload_3
    //   384: new java/lang/StringBuilder
    //   387: dup
    //   388: invokespecial <init> : ()V
    //   391: aload_3
    //   392: getfield s : Ljava/lang/String;
    //   395: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   398: aload_1
    //   399: getfield b : J
    //   402: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   405: ldc '\\n'
    //   407: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   410: invokevirtual toString : ()Ljava/lang/String;
    //   413: putfield s : Ljava/lang/String;
    //   416: goto -> 311
    //   419: aload_3
    //   420: astore_1
    //   421: aload_3
    //   422: getfield r : J
    //   425: aload_2
    //   426: getfield r : J
    //   429: lcmp
    //   430: ifeq -> 15
    //   433: aload_3
    //   434: astore_1
    //   435: aload_3
    //   436: getfield s : Ljava/lang/String;
    //   439: new java/lang/StringBuilder
    //   442: dup
    //   443: invokespecial <init> : ()V
    //   446: aload_2
    //   447: getfield r : J
    //   450: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   453: invokevirtual toString : ()Ljava/lang/String;
    //   456: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   459: ifne -> 15
    //   462: aload_3
    //   463: aload_3
    //   464: getfield t : I
    //   467: iconst_1
    //   468: iadd
    //   469: putfield t : I
    //   472: aload_3
    //   473: new java/lang/StringBuilder
    //   476: dup
    //   477: invokespecial <init> : ()V
    //   480: aload_3
    //   481: getfield s : Ljava/lang/String;
    //   484: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   487: aload_2
    //   488: getfield r : J
    //   491: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   494: ldc '\\n'
    //   496: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   499: invokevirtual toString : ()Ljava/lang/String;
    //   502: putfield s : Ljava/lang/String;
    //   505: aload_3
    //   506: astore_1
    //   507: goto -> 15
    //   510: goto -> 303
    //   513: goto -> 156
    //   516: aconst_null
    //   517: astore_3
    //   518: goto -> 281
  }
  
  private static aj a(String paramString1, Context paramContext, String paramString2) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_2
    //   3: ifnull -> 10
    //   6: aload_1
    //   7: ifnonnull -> 24
    //   10: ldc 'rqdp{  createZipAttachment sourcePath == null || context == null ,pls check}'
    //   12: iconst_0
    //   13: anewarray java/lang/Object
    //   16: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   19: pop
    //   20: aload_3
    //   21: astore_0
    //   22: aload_0
    //   23: areturn
    //   24: ldc 'zip %s'
    //   26: iconst_1
    //   27: anewarray java/lang/Object
    //   30: dup
    //   31: iconst_0
    //   32: aload_2
    //   33: aastore
    //   34: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   37: pop
    //   38: new java/io/File
    //   41: dup
    //   42: aload_2
    //   43: invokespecial <init> : (Ljava/lang/String;)V
    //   46: astore_2
    //   47: new java/io/File
    //   50: dup
    //   51: aload_1
    //   52: invokevirtual getCacheDir : ()Ljava/io/File;
    //   55: aload_0
    //   56: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   59: astore #4
    //   61: aload_2
    //   62: aload #4
    //   64: sipush #5000
    //   67: invokestatic a : (Ljava/io/File;Ljava/io/File;I)Z
    //   70: ifne -> 88
    //   73: ldc 'zip fail!'
    //   75: iconst_0
    //   76: anewarray java/lang/Object
    //   79: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   82: pop
    //   83: aload_3
    //   84: astore_0
    //   85: goto -> 22
    //   88: new java/io/ByteArrayOutputStream
    //   91: dup
    //   92: invokespecial <init> : ()V
    //   95: astore #5
    //   97: new java/io/FileInputStream
    //   100: astore_1
    //   101: aload_1
    //   102: aload #4
    //   104: invokespecial <init> : (Ljava/io/File;)V
    //   107: aload_1
    //   108: astore_0
    //   109: sipush #1000
    //   112: newarray byte
    //   114: astore_2
    //   115: aload_1
    //   116: astore_0
    //   117: aload_1
    //   118: aload_2
    //   119: invokevirtual read : ([B)I
    //   122: istore #6
    //   124: iload #6
    //   126: ifle -> 205
    //   129: aload_1
    //   130: astore_0
    //   131: aload #5
    //   133: aload_2
    //   134: iconst_0
    //   135: iload #6
    //   137: invokevirtual write : ([BII)V
    //   140: aload_1
    //   141: astore_0
    //   142: aload #5
    //   144: invokevirtual flush : ()V
    //   147: goto -> 115
    //   150: astore_2
    //   151: aload_1
    //   152: astore_0
    //   153: aload_2
    //   154: invokestatic a : (Ljava/lang/Throwable;)Z
    //   157: ifne -> 166
    //   160: aload_1
    //   161: astore_0
    //   162: aload_2
    //   163: invokevirtual printStackTrace : ()V
    //   166: aload_1
    //   167: ifnull -> 174
    //   170: aload_1
    //   171: invokevirtual close : ()V
    //   174: aload_3
    //   175: astore_0
    //   176: aload #4
    //   178: invokevirtual exists : ()Z
    //   181: ifeq -> 22
    //   184: ldc 'del tmp'
    //   186: iconst_0
    //   187: anewarray java/lang/Object
    //   190: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   193: pop
    //   194: aload #4
    //   196: invokevirtual delete : ()Z
    //   199: pop
    //   200: aload_3
    //   201: astore_0
    //   202: goto -> 22
    //   205: aload_1
    //   206: astore_0
    //   207: aload #5
    //   209: invokevirtual toByteArray : ()[B
    //   212: astore_2
    //   213: aload_1
    //   214: astore_0
    //   215: ldc 'read bytes :%d'
    //   217: iconst_1
    //   218: anewarray java/lang/Object
    //   221: dup
    //   222: iconst_0
    //   223: aload_2
    //   224: arraylength
    //   225: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   228: aastore
    //   229: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   232: pop
    //   233: aload_1
    //   234: astore_0
    //   235: new com/tencent/bugly/legu/proguard/aj
    //   238: dup
    //   239: iconst_2
    //   240: aload #4
    //   242: invokevirtual getName : ()Ljava/lang/String;
    //   245: aload_2
    //   246: invokespecial <init> : (BLjava/lang/String;[B)V
    //   249: astore_2
    //   250: aload_1
    //   251: invokevirtual close : ()V
    //   254: aload #4
    //   256: invokevirtual exists : ()Z
    //   259: ifeq -> 278
    //   262: ldc 'del tmp'
    //   264: iconst_0
    //   265: anewarray java/lang/Object
    //   268: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   271: pop
    //   272: aload #4
    //   274: invokevirtual delete : ()Z
    //   277: pop
    //   278: aload_2
    //   279: astore_0
    //   280: goto -> 22
    //   283: astore_0
    //   284: aload_0
    //   285: invokestatic a : (Ljava/lang/Throwable;)Z
    //   288: ifne -> 254
    //   291: aload_0
    //   292: invokevirtual printStackTrace : ()V
    //   295: goto -> 254
    //   298: astore_0
    //   299: aload_0
    //   300: invokestatic a : (Ljava/lang/Throwable;)Z
    //   303: ifne -> 174
    //   306: aload_0
    //   307: invokevirtual printStackTrace : ()V
    //   310: goto -> 174
    //   313: astore_1
    //   314: aconst_null
    //   315: astore_0
    //   316: aload_0
    //   317: ifnull -> 324
    //   320: aload_0
    //   321: invokevirtual close : ()V
    //   324: aload #4
    //   326: invokevirtual exists : ()Z
    //   329: ifeq -> 348
    //   332: ldc 'del tmp'
    //   334: iconst_0
    //   335: anewarray java/lang/Object
    //   338: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   341: pop
    //   342: aload #4
    //   344: invokevirtual delete : ()Z
    //   347: pop
    //   348: aload_1
    //   349: athrow
    //   350: astore_0
    //   351: aload_0
    //   352: invokestatic a : (Ljava/lang/Throwable;)Z
    //   355: ifne -> 324
    //   358: aload_0
    //   359: invokevirtual printStackTrace : ()V
    //   362: goto -> 324
    //   365: astore_1
    //   366: goto -> 316
    //   369: astore_2
    //   370: aconst_null
    //   371: astore_1
    //   372: goto -> 151
    // Exception table:
    //   from	to	target	type
    //   97	107	369	java/lang/Throwable
    //   97	107	313	finally
    //   109	115	150	java/lang/Throwable
    //   109	115	365	finally
    //   117	124	150	java/lang/Throwable
    //   117	124	365	finally
    //   131	140	150	java/lang/Throwable
    //   131	140	365	finally
    //   142	147	150	java/lang/Throwable
    //   142	147	365	finally
    //   153	160	365	finally
    //   162	166	365	finally
    //   170	174	298	java/io/IOException
    //   207	213	150	java/lang/Throwable
    //   207	213	365	finally
    //   215	233	150	java/lang/Throwable
    //   215	233	365	finally
    //   235	250	150	java/lang/Throwable
    //   235	250	365	finally
    //   250	254	283	java/io/IOException
    //   320	324	350	java/io/IOException
  }
  
  private static ak a(Context paramContext, CrashDetailBean paramCrashDetailBean, a parama) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_3
    //   2: aload_0
    //   3: ifnull -> 14
    //   6: aload_1
    //   7: ifnull -> 14
    //   10: aload_2
    //   11: ifnonnull -> 29
    //   14: ldc_w 'enExp args == null'
    //   17: iconst_0
    //   18: anewarray java/lang/Object
    //   21: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   24: pop
    //   25: aconst_null
    //   26: astore_0
    //   27: aload_0
    //   28: areturn
    //   29: new com/tencent/bugly/legu/proguard/ak
    //   32: dup
    //   33: invokespecial <init> : ()V
    //   36: astore #4
    //   38: aload_1
    //   39: getfield b : I
    //   42: tableswitch default -> 84, 0 -> 403, 1 -> 433, 2 -> 463, 3 -> 373, 4 -> 493, 5 -> 553, 6 -> 523
    //   84: ldc_w 'crash type error! %d'
    //   87: iconst_1
    //   88: anewarray java/lang/Object
    //   91: dup
    //   92: iconst_0
    //   93: aload_1
    //   94: getfield b : I
    //   97: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   100: aastore
    //   101: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   104: pop
    //   105: aload #4
    //   107: aload_1
    //   108: getfield r : J
    //   111: putfield b : J
    //   114: aload #4
    //   116: aload_1
    //   117: getfield n : Ljava/lang/String;
    //   120: putfield c : Ljava/lang/String;
    //   123: aload #4
    //   125: aload_1
    //   126: getfield o : Ljava/lang/String;
    //   129: putfield d : Ljava/lang/String;
    //   132: aload #4
    //   134: aload_1
    //   135: getfield p : Ljava/lang/String;
    //   138: putfield e : Ljava/lang/String;
    //   141: aload #4
    //   143: aload_1
    //   144: getfield q : Ljava/lang/String;
    //   147: putfield g : Ljava/lang/String;
    //   150: aload #4
    //   152: aload_1
    //   153: getfield y : Ljava/util/Map;
    //   156: putfield h : Ljava/util/Map;
    //   159: aload #4
    //   161: aload_1
    //   162: getfield c : Ljava/lang/String;
    //   165: putfield i : Ljava/lang/String;
    //   168: aload #4
    //   170: aconst_null
    //   171: putfield j : Lcom/tencent/bugly/legu/proguard/ai;
    //   174: aload #4
    //   176: aload_1
    //   177: getfield m : Ljava/lang/String;
    //   180: putfield l : Ljava/lang/String;
    //   183: aload #4
    //   185: aload_1
    //   186: getfield e : Ljava/lang/String;
    //   189: putfield m : Ljava/lang/String;
    //   192: aload #4
    //   194: aload_1
    //   195: getfield A : Ljava/lang/String;
    //   198: putfield f : Ljava/lang/String;
    //   201: aload #4
    //   203: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   206: invokevirtual h : ()Ljava/lang/String;
    //   209: putfield t : Ljava/lang/String;
    //   212: aload #4
    //   214: aconst_null
    //   215: putfield n : Lcom/tencent/bugly/legu/proguard/ah;
    //   218: aload_1
    //   219: getfield i : Ljava/util/Map;
    //   222: ifnull -> 583
    //   225: aload_1
    //   226: getfield i : Ljava/util/Map;
    //   229: invokeinterface size : ()I
    //   234: ifle -> 583
    //   237: aload #4
    //   239: new java/util/ArrayList
    //   242: dup
    //   243: invokespecial <init> : ()V
    //   246: putfield o : Ljava/util/ArrayList;
    //   249: aload_1
    //   250: getfield i : Ljava/util/Map;
    //   253: invokeinterface entrySet : ()Ljava/util/Set;
    //   258: invokeinterface iterator : ()Ljava/util/Iterator;
    //   263: astore #5
    //   265: aload #5
    //   267: invokeinterface hasNext : ()Z
    //   272: ifeq -> 583
    //   275: aload #5
    //   277: invokeinterface next : ()Ljava/lang/Object;
    //   282: checkcast java/util/Map$Entry
    //   285: astore #6
    //   287: new com/tencent/bugly/legu/proguard/ah
    //   290: dup
    //   291: invokespecial <init> : ()V
    //   294: astore #7
    //   296: aload #7
    //   298: aload #6
    //   300: invokeinterface getValue : ()Ljava/lang/Object;
    //   305: checkcast com/tencent/bugly/legu/crashreport/common/info/PlugInBean
    //   308: getfield a : Ljava/lang/String;
    //   311: putfield a : Ljava/lang/String;
    //   314: aload #7
    //   316: aload #6
    //   318: invokeinterface getValue : ()Ljava/lang/Object;
    //   323: checkcast com/tencent/bugly/legu/crashreport/common/info/PlugInBean
    //   326: getfield c : Ljava/lang/String;
    //   329: putfield c : Ljava/lang/String;
    //   332: aload #7
    //   334: aload #6
    //   336: invokeinterface getValue : ()Ljava/lang/Object;
    //   341: checkcast com/tencent/bugly/legu/crashreport/common/info/PlugInBean
    //   344: getfield b : Ljava/lang/String;
    //   347: putfield d : Ljava/lang/String;
    //   350: aload #7
    //   352: aload_2
    //   353: invokevirtual q : ()Ljava/lang/String;
    //   356: putfield b : Ljava/lang/String;
    //   359: aload #4
    //   361: getfield o : Ljava/util/ArrayList;
    //   364: aload #7
    //   366: invokevirtual add : (Ljava/lang/Object;)Z
    //   369: pop
    //   370: goto -> 265
    //   373: aload_1
    //   374: getfield j : Z
    //   377: ifeq -> 395
    //   380: ldc_w '203'
    //   383: astore #7
    //   385: aload #4
    //   387: aload #7
    //   389: putfield a : Ljava/lang/String;
    //   392: goto -> 105
    //   395: ldc_w '103'
    //   398: astore #7
    //   400: goto -> 385
    //   403: aload_1
    //   404: getfield j : Z
    //   407: ifeq -> 425
    //   410: ldc_w '200'
    //   413: astore #7
    //   415: aload #4
    //   417: aload #7
    //   419: putfield a : Ljava/lang/String;
    //   422: goto -> 105
    //   425: ldc_w '100'
    //   428: astore #7
    //   430: goto -> 415
    //   433: aload_1
    //   434: getfield j : Z
    //   437: ifeq -> 455
    //   440: ldc_w '201'
    //   443: astore #7
    //   445: aload #4
    //   447: aload #7
    //   449: putfield a : Ljava/lang/String;
    //   452: goto -> 105
    //   455: ldc_w '101'
    //   458: astore #7
    //   460: goto -> 445
    //   463: aload_1
    //   464: getfield j : Z
    //   467: ifeq -> 485
    //   470: ldc_w '202'
    //   473: astore #7
    //   475: aload #4
    //   477: aload #7
    //   479: putfield a : Ljava/lang/String;
    //   482: goto -> 105
    //   485: ldc_w '102'
    //   488: astore #7
    //   490: goto -> 475
    //   493: aload_1
    //   494: getfield j : Z
    //   497: ifeq -> 515
    //   500: ldc_w '204'
    //   503: astore #7
    //   505: aload #4
    //   507: aload #7
    //   509: putfield a : Ljava/lang/String;
    //   512: goto -> 105
    //   515: ldc_w '104'
    //   518: astore #7
    //   520: goto -> 505
    //   523: aload_1
    //   524: getfield j : Z
    //   527: ifeq -> 545
    //   530: ldc_w '206'
    //   533: astore #7
    //   535: aload #4
    //   537: aload #7
    //   539: putfield a : Ljava/lang/String;
    //   542: goto -> 105
    //   545: ldc_w '106'
    //   548: astore #7
    //   550: goto -> 535
    //   553: aload_1
    //   554: getfield j : Z
    //   557: ifeq -> 575
    //   560: ldc_w '207'
    //   563: astore #7
    //   565: aload #4
    //   567: aload #7
    //   569: putfield a : Ljava/lang/String;
    //   572: goto -> 105
    //   575: ldc_w '107'
    //   578: astore #7
    //   580: goto -> 565
    //   583: aload_1
    //   584: getfield h : Ljava/util/Map;
    //   587: ifnull -> 729
    //   590: aload_1
    //   591: getfield h : Ljava/util/Map;
    //   594: invokeinterface size : ()I
    //   599: ifle -> 729
    //   602: aload #4
    //   604: new java/util/ArrayList
    //   607: dup
    //   608: invokespecial <init> : ()V
    //   611: putfield p : Ljava/util/ArrayList;
    //   614: aload_1
    //   615: getfield h : Ljava/util/Map;
    //   618: invokeinterface entrySet : ()Ljava/util/Set;
    //   623: invokeinterface iterator : ()Ljava/util/Iterator;
    //   628: astore #6
    //   630: aload #6
    //   632: invokeinterface hasNext : ()Z
    //   637: ifeq -> 729
    //   640: aload #6
    //   642: invokeinterface next : ()Ljava/lang/Object;
    //   647: checkcast java/util/Map$Entry
    //   650: astore #7
    //   652: new com/tencent/bugly/legu/proguard/ah
    //   655: dup
    //   656: invokespecial <init> : ()V
    //   659: astore #5
    //   661: aload #5
    //   663: aload #7
    //   665: invokeinterface getValue : ()Ljava/lang/Object;
    //   670: checkcast com/tencent/bugly/legu/crashreport/common/info/PlugInBean
    //   673: getfield a : Ljava/lang/String;
    //   676: putfield a : Ljava/lang/String;
    //   679: aload #5
    //   681: aload #7
    //   683: invokeinterface getValue : ()Ljava/lang/Object;
    //   688: checkcast com/tencent/bugly/legu/crashreport/common/info/PlugInBean
    //   691: getfield c : Ljava/lang/String;
    //   694: putfield c : Ljava/lang/String;
    //   697: aload #5
    //   699: aload #7
    //   701: invokeinterface getValue : ()Ljava/lang/Object;
    //   706: checkcast com/tencent/bugly/legu/crashreport/common/info/PlugInBean
    //   709: getfield b : Ljava/lang/String;
    //   712: putfield d : Ljava/lang/String;
    //   715: aload #4
    //   717: getfield p : Ljava/util/ArrayList;
    //   720: aload #5
    //   722: invokevirtual add : (Ljava/lang/Object;)Z
    //   725: pop
    //   726: goto -> 630
    //   729: aload_1
    //   730: getfield j : Z
    //   733: ifeq -> 873
    //   736: aload #4
    //   738: aload_1
    //   739: getfield t : I
    //   742: putfield k : I
    //   745: aload_1
    //   746: getfield s : Ljava/lang/String;
    //   749: ifnull -> 821
    //   752: aload_1
    //   753: getfield s : Ljava/lang/String;
    //   756: invokevirtual length : ()I
    //   759: ifle -> 821
    //   762: aload #4
    //   764: getfield q : Ljava/util/ArrayList;
    //   767: ifnonnull -> 782
    //   770: aload #4
    //   772: new java/util/ArrayList
    //   775: dup
    //   776: invokespecial <init> : ()V
    //   779: putfield q : Ljava/util/ArrayList;
    //   782: aload #4
    //   784: getfield q : Ljava/util/ArrayList;
    //   787: astore #6
    //   789: new com/tencent/bugly/legu/proguard/aj
    //   792: astore #7
    //   794: aload #7
    //   796: iconst_1
    //   797: ldc_w 'alltimes.txt'
    //   800: aload_1
    //   801: getfield s : Ljava/lang/String;
    //   804: ldc_w 'utf-8'
    //   807: invokevirtual getBytes : (Ljava/lang/String;)[B
    //   810: invokespecial <init> : (BLjava/lang/String;[B)V
    //   813: aload #6
    //   815: aload #7
    //   817: invokevirtual add : (Ljava/lang/Object;)Z
    //   820: pop
    //   821: aload #4
    //   823: getfield k : I
    //   826: istore #8
    //   828: aload #4
    //   830: getfield q : Ljava/util/ArrayList;
    //   833: ifnull -> 2658
    //   836: aload #4
    //   838: getfield q : Ljava/util/ArrayList;
    //   841: invokevirtual size : ()I
    //   844: istore #9
    //   846: ldc_w 'crashcount:%d sz:%d'
    //   849: iconst_2
    //   850: anewarray java/lang/Object
    //   853: dup
    //   854: iconst_0
    //   855: iload #8
    //   857: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   860: aastore
    //   861: dup
    //   862: iconst_1
    //   863: iload #9
    //   865: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   868: aastore
    //   869: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   872: pop
    //   873: aload_1
    //   874: getfield w : Ljava/lang/String;
    //   877: ifnull -> 939
    //   880: aload #4
    //   882: getfield q : Ljava/util/ArrayList;
    //   885: ifnonnull -> 900
    //   888: aload #4
    //   890: new java/util/ArrayList
    //   893: dup
    //   894: invokespecial <init> : ()V
    //   897: putfield q : Ljava/util/ArrayList;
    //   900: aload #4
    //   902: getfield q : Ljava/util/ArrayList;
    //   905: astore #6
    //   907: new com/tencent/bugly/legu/proguard/aj
    //   910: astore #7
    //   912: aload #7
    //   914: iconst_1
    //   915: ldc_w 'log.txt'
    //   918: aload_1
    //   919: getfield w : Ljava/lang/String;
    //   922: ldc_w 'utf-8'
    //   925: invokevirtual getBytes : (Ljava/lang/String;)[B
    //   928: invokespecial <init> : (BLjava/lang/String;[B)V
    //   931: aload #6
    //   933: aload #7
    //   935: invokevirtual add : (Ljava/lang/Object;)Z
    //   938: pop
    //   939: aload_1
    //   940: getfield x : [B
    //   943: ifnull -> 1013
    //   946: aload_1
    //   947: getfield x : [B
    //   950: arraylength
    //   951: ifle -> 1013
    //   954: new com/tencent/bugly/legu/proguard/aj
    //   957: dup
    //   958: iconst_2
    //   959: ldc_w 'buglylog.zip'
    //   962: aload_1
    //   963: getfield x : [B
    //   966: invokespecial <init> : (BLjava/lang/String;[B)V
    //   969: astore #7
    //   971: ldc_w 'attach user log'
    //   974: iconst_0
    //   975: anewarray java/lang/Object
    //   978: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   981: pop
    //   982: aload #4
    //   984: getfield q : Ljava/util/ArrayList;
    //   987: ifnonnull -> 1002
    //   990: aload #4
    //   992: new java/util/ArrayList
    //   995: dup
    //   996: invokespecial <init> : ()V
    //   999: putfield q : Ljava/util/ArrayList;
    //   1002: aload #4
    //   1004: getfield q : Ljava/util/ArrayList;
    //   1007: aload #7
    //   1009: invokevirtual add : (Ljava/lang/Object;)Z
    //   1012: pop
    //   1013: aload_1
    //   1014: getfield b : I
    //   1017: iconst_3
    //   1018: if_icmpne -> 1184
    //   1021: aload #4
    //   1023: getfield q : Ljava/util/ArrayList;
    //   1026: ifnonnull -> 1041
    //   1029: aload #4
    //   1031: new java/util/ArrayList
    //   1034: dup
    //   1035: invokespecial <init> : ()V
    //   1038: putfield q : Ljava/util/ArrayList;
    //   1041: aload_1
    //   1042: getfield N : Ljava/util/Map;
    //   1045: ifnull -> 1137
    //   1048: aload_1
    //   1049: getfield N : Ljava/util/Map;
    //   1052: ldc_w 'BUGLY_CR_01'
    //   1055: invokeinterface containsKey : (Ljava/lang/Object;)Z
    //   1060: ifeq -> 1137
    //   1063: aload #4
    //   1065: getfield q : Ljava/util/ArrayList;
    //   1068: astore #6
    //   1070: new com/tencent/bugly/legu/proguard/aj
    //   1073: astore #7
    //   1075: aload #7
    //   1077: iconst_1
    //   1078: ldc_w 'anrMessage.txt'
    //   1081: aload_1
    //   1082: getfield N : Ljava/util/Map;
    //   1085: ldc_w 'BUGLY_CR_01'
    //   1088: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1093: checkcast java/lang/String
    //   1096: ldc_w 'utf-8'
    //   1099: invokevirtual getBytes : (Ljava/lang/String;)[B
    //   1102: invokespecial <init> : (BLjava/lang/String;[B)V
    //   1105: aload #6
    //   1107: aload #7
    //   1109: invokevirtual add : (Ljava/lang/Object;)Z
    //   1112: pop
    //   1113: ldc_w 'attach anr message'
    //   1116: iconst_0
    //   1117: anewarray java/lang/Object
    //   1120: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1123: pop
    //   1124: aload_1
    //   1125: getfield N : Ljava/util/Map;
    //   1128: ldc_w 'BUGLY_CR_01'
    //   1131: invokeinterface remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   1136: pop
    //   1137: aload_1
    //   1138: getfield v : Ljava/lang/String;
    //   1141: ifnull -> 1184
    //   1144: ldc_w 'trace.zip'
    //   1147: aload_0
    //   1148: aload_1
    //   1149: getfield v : Ljava/lang/String;
    //   1152: invokestatic a : (Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;)Lcom/tencent/bugly/legu/proguard/aj;
    //   1155: astore #7
    //   1157: aload #7
    //   1159: ifnull -> 1184
    //   1162: ldc_w 'attach traces'
    //   1165: iconst_0
    //   1166: anewarray java/lang/Object
    //   1169: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1172: pop
    //   1173: aload #4
    //   1175: getfield q : Ljava/util/ArrayList;
    //   1178: aload #7
    //   1180: invokevirtual add : (Ljava/lang/Object;)Z
    //   1183: pop
    //   1184: aload_1
    //   1185: getfield b : I
    //   1188: iconst_1
    //   1189: if_icmpne -> 1256
    //   1192: aload #4
    //   1194: getfield q : Ljava/util/ArrayList;
    //   1197: ifnonnull -> 1212
    //   1200: aload #4
    //   1202: new java/util/ArrayList
    //   1205: dup
    //   1206: invokespecial <init> : ()V
    //   1209: putfield q : Ljava/util/ArrayList;
    //   1212: aload_1
    //   1213: getfield v : Ljava/lang/String;
    //   1216: ifnull -> 1256
    //   1219: ldc_w 'tomb.zip'
    //   1222: aload_0
    //   1223: aload_1
    //   1224: getfield v : Ljava/lang/String;
    //   1227: invokestatic a : (Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;)Lcom/tencent/bugly/legu/proguard/aj;
    //   1230: astore_0
    //   1231: aload_0
    //   1232: ifnull -> 1256
    //   1235: ldc_w 'attach tombs'
    //   1238: iconst_0
    //   1239: anewarray java/lang/Object
    //   1242: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1245: pop
    //   1246: aload #4
    //   1248: getfield q : Ljava/util/ArrayList;
    //   1251: aload_0
    //   1252: invokevirtual add : (Ljava/lang/Object;)Z
    //   1255: pop
    //   1256: aload_1
    //   1257: getfield S : [B
    //   1260: ifnull -> 1326
    //   1263: aload_1
    //   1264: getfield S : [B
    //   1267: arraylength
    //   1268: ifle -> 1326
    //   1271: aload #4
    //   1273: getfield q : Ljava/util/ArrayList;
    //   1276: ifnonnull -> 1291
    //   1279: aload #4
    //   1281: new java/util/ArrayList
    //   1284: dup
    //   1285: invokespecial <init> : ()V
    //   1288: putfield q : Ljava/util/ArrayList;
    //   1291: aload #4
    //   1293: getfield q : Ljava/util/ArrayList;
    //   1296: new com/tencent/bugly/legu/proguard/aj
    //   1299: dup
    //   1300: iconst_1
    //   1301: ldc_w 'userExtraByteData'
    //   1304: aload_1
    //   1305: getfield S : [B
    //   1308: invokespecial <init> : (BLjava/lang/String;[B)V
    //   1311: invokevirtual add : (Ljava/lang/Object;)Z
    //   1314: pop
    //   1315: ldc_w 'attach extraData'
    //   1318: iconst_0
    //   1319: anewarray java/lang/Object
    //   1322: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   1325: pop
    //   1326: aload #4
    //   1328: new java/util/HashMap
    //   1331: dup
    //   1332: invokespecial <init> : ()V
    //   1335: putfield r : Ljava/util/Map;
    //   1338: aload #4
    //   1340: getfield r : Ljava/util/Map;
    //   1343: ldc_w 'A9'
    //   1346: new java/lang/StringBuilder
    //   1349: dup
    //   1350: invokespecial <init> : ()V
    //   1353: aload_1
    //   1354: getfield B : J
    //   1357: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   1360: invokevirtual toString : ()Ljava/lang/String;
    //   1363: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1368: pop
    //   1369: aload #4
    //   1371: getfield r : Ljava/util/Map;
    //   1374: ldc_w 'A11'
    //   1377: new java/lang/StringBuilder
    //   1380: dup
    //   1381: invokespecial <init> : ()V
    //   1384: aload_1
    //   1385: getfield C : J
    //   1388: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   1391: invokevirtual toString : ()Ljava/lang/String;
    //   1394: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1399: pop
    //   1400: aload #4
    //   1402: getfield r : Ljava/util/Map;
    //   1405: ldc_w 'A10'
    //   1408: new java/lang/StringBuilder
    //   1411: dup
    //   1412: invokespecial <init> : ()V
    //   1415: aload_1
    //   1416: getfield D : J
    //   1419: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   1422: invokevirtual toString : ()Ljava/lang/String;
    //   1425: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1430: pop
    //   1431: aload #4
    //   1433: getfield r : Ljava/util/Map;
    //   1436: ldc_w 'A23'
    //   1439: new java/lang/StringBuilder
    //   1442: dup
    //   1443: invokespecial <init> : ()V
    //   1446: aload_1
    //   1447: getfield f : Ljava/lang/String;
    //   1450: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1453: invokevirtual toString : ()Ljava/lang/String;
    //   1456: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1461: pop
    //   1462: aload #4
    //   1464: getfield r : Ljava/util/Map;
    //   1467: ldc_w 'A7'
    //   1470: new java/lang/StringBuilder
    //   1473: dup
    //   1474: invokespecial <init> : ()V
    //   1477: aload_2
    //   1478: getfield e : Ljava/lang/String;
    //   1481: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1484: invokevirtual toString : ()Ljava/lang/String;
    //   1487: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1492: pop
    //   1493: aload #4
    //   1495: getfield r : Ljava/util/Map;
    //   1498: ldc_w 'A6'
    //   1501: new java/lang/StringBuilder
    //   1504: dup
    //   1505: invokespecial <init> : ()V
    //   1508: aload_2
    //   1509: invokevirtual r : ()Ljava/lang/String;
    //   1512: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1515: invokevirtual toString : ()Ljava/lang/String;
    //   1518: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1523: pop
    //   1524: aload #4
    //   1526: getfield r : Ljava/util/Map;
    //   1529: ldc_w 'A5'
    //   1532: new java/lang/StringBuilder
    //   1535: dup
    //   1536: invokespecial <init> : ()V
    //   1539: aload_2
    //   1540: invokevirtual q : ()Ljava/lang/String;
    //   1543: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1546: invokevirtual toString : ()Ljava/lang/String;
    //   1549: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1554: pop
    //   1555: aload #4
    //   1557: getfield r : Ljava/util/Map;
    //   1560: ldc_w 'A22'
    //   1563: new java/lang/StringBuilder
    //   1566: dup
    //   1567: invokespecial <init> : ()V
    //   1570: aload_2
    //   1571: invokevirtual g : ()Ljava/lang/String;
    //   1574: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1577: invokevirtual toString : ()Ljava/lang/String;
    //   1580: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1585: pop
    //   1586: aload #4
    //   1588: getfield r : Ljava/util/Map;
    //   1591: ldc_w 'A2'
    //   1594: new java/lang/StringBuilder
    //   1597: dup
    //   1598: invokespecial <init> : ()V
    //   1601: aload_1
    //   1602: getfield F : J
    //   1605: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   1608: invokevirtual toString : ()Ljava/lang/String;
    //   1611: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1616: pop
    //   1617: aload #4
    //   1619: getfield r : Ljava/util/Map;
    //   1622: ldc_w 'A1'
    //   1625: new java/lang/StringBuilder
    //   1628: dup
    //   1629: invokespecial <init> : ()V
    //   1632: aload_1
    //   1633: getfield E : J
    //   1636: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   1639: invokevirtual toString : ()Ljava/lang/String;
    //   1642: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1647: pop
    //   1648: aload #4
    //   1650: getfield r : Ljava/util/Map;
    //   1653: ldc_w 'A24'
    //   1656: new java/lang/StringBuilder
    //   1659: dup
    //   1660: invokespecial <init> : ()V
    //   1663: aload_2
    //   1664: getfield g : Ljava/lang/String;
    //   1667: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1670: invokevirtual toString : ()Ljava/lang/String;
    //   1673: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1678: pop
    //   1679: aload #4
    //   1681: getfield r : Ljava/util/Map;
    //   1684: ldc_w 'A17'
    //   1687: new java/lang/StringBuilder
    //   1690: dup
    //   1691: invokespecial <init> : ()V
    //   1694: aload_1
    //   1695: getfield G : J
    //   1698: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   1701: invokevirtual toString : ()Ljava/lang/String;
    //   1704: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1709: pop
    //   1710: aload #4
    //   1712: getfield r : Ljava/util/Map;
    //   1715: ldc_w 'A3'
    //   1718: new java/lang/StringBuilder
    //   1721: dup
    //   1722: invokespecial <init> : ()V
    //   1725: aload_2
    //   1726: invokevirtual j : ()Ljava/lang/String;
    //   1729: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1732: invokevirtual toString : ()Ljava/lang/String;
    //   1735: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1740: pop
    //   1741: aload #4
    //   1743: getfield r : Ljava/util/Map;
    //   1746: ldc_w 'A16'
    //   1749: new java/lang/StringBuilder
    //   1752: dup
    //   1753: invokespecial <init> : ()V
    //   1756: aload_2
    //   1757: invokevirtual l : ()Ljava/lang/String;
    //   1760: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1763: invokevirtual toString : ()Ljava/lang/String;
    //   1766: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1771: pop
    //   1772: aload #4
    //   1774: getfield r : Ljava/util/Map;
    //   1777: ldc_w 'A25'
    //   1780: new java/lang/StringBuilder
    //   1783: dup
    //   1784: invokespecial <init> : ()V
    //   1787: aload_2
    //   1788: invokevirtual m : ()Ljava/lang/String;
    //   1791: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1794: invokevirtual toString : ()Ljava/lang/String;
    //   1797: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1802: pop
    //   1803: aload #4
    //   1805: getfield r : Ljava/util/Map;
    //   1808: ldc_w 'A14'
    //   1811: new java/lang/StringBuilder
    //   1814: dup
    //   1815: invokespecial <init> : ()V
    //   1818: aload_2
    //   1819: invokevirtual k : ()Ljava/lang/String;
    //   1822: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1825: invokevirtual toString : ()Ljava/lang/String;
    //   1828: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1833: pop
    //   1834: aload #4
    //   1836: getfield r : Ljava/util/Map;
    //   1839: ldc_w 'A15'
    //   1842: new java/lang/StringBuilder
    //   1845: dup
    //   1846: invokespecial <init> : ()V
    //   1849: aload_2
    //   1850: invokevirtual t : ()Ljava/lang/String;
    //   1853: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1856: invokevirtual toString : ()Ljava/lang/String;
    //   1859: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1864: pop
    //   1865: aload #4
    //   1867: getfield r : Ljava/util/Map;
    //   1870: ldc_w 'A13'
    //   1873: new java/lang/StringBuilder
    //   1876: dup
    //   1877: invokespecial <init> : ()V
    //   1880: aload_2
    //   1881: invokevirtual u : ()Ljava/lang/Boolean;
    //   1884: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1887: invokevirtual toString : ()Ljava/lang/String;
    //   1890: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1895: pop
    //   1896: aload #4
    //   1898: getfield r : Ljava/util/Map;
    //   1901: ldc_w 'A34'
    //   1904: new java/lang/StringBuilder
    //   1907: dup
    //   1908: invokespecial <init> : ()V
    //   1911: aload_1
    //   1912: getfield z : Ljava/lang/String;
    //   1915: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1918: invokevirtual toString : ()Ljava/lang/String;
    //   1921: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1926: pop
    //   1927: aload_2
    //   1928: getfield w : Ljava/lang/String;
    //   1931: ifnull -> 1965
    //   1934: aload #4
    //   1936: getfield r : Ljava/util/Map;
    //   1939: ldc_w 'productIdentify'
    //   1942: new java/lang/StringBuilder
    //   1945: dup
    //   1946: invokespecial <init> : ()V
    //   1949: aload_2
    //   1950: getfield w : Ljava/lang/String;
    //   1953: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1956: invokevirtual toString : ()Ljava/lang/String;
    //   1959: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1964: pop
    //   1965: aload #4
    //   1967: getfield r : Ljava/util/Map;
    //   1970: astore_0
    //   1971: new java/lang/StringBuilder
    //   1974: astore #7
    //   1976: aload #7
    //   1978: invokespecial <init> : ()V
    //   1981: aload_0
    //   1982: ldc_w 'A26'
    //   1985: aload #7
    //   1987: aload_1
    //   1988: getfield H : Ljava/lang/String;
    //   1991: ldc_w 'utf-8'
    //   1994: invokestatic encode : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   1997: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2000: invokevirtual toString : ()Ljava/lang/String;
    //   2003: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2008: pop
    //   2009: aload_1
    //   2010: getfield b : I
    //   2013: iconst_1
    //   2014: if_icmpne -> 2110
    //   2017: aload #4
    //   2019: getfield r : Ljava/util/Map;
    //   2022: ldc_w 'A27'
    //   2025: new java/lang/StringBuilder
    //   2028: dup
    //   2029: invokespecial <init> : ()V
    //   2032: aload_1
    //   2033: getfield J : Ljava/lang/String;
    //   2036: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2039: invokevirtual toString : ()Ljava/lang/String;
    //   2042: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2047: pop
    //   2048: aload #4
    //   2050: getfield r : Ljava/util/Map;
    //   2053: ldc_w 'A28'
    //   2056: new java/lang/StringBuilder
    //   2059: dup
    //   2060: invokespecial <init> : ()V
    //   2063: aload_1
    //   2064: getfield I : Ljava/lang/String;
    //   2067: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2070: invokevirtual toString : ()Ljava/lang/String;
    //   2073: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2078: pop
    //   2079: aload #4
    //   2081: getfield r : Ljava/util/Map;
    //   2084: ldc_w 'A29'
    //   2087: new java/lang/StringBuilder
    //   2090: dup
    //   2091: invokespecial <init> : ()V
    //   2094: aload_1
    //   2095: getfield k : Z
    //   2098: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   2101: invokevirtual toString : ()Ljava/lang/String;
    //   2104: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2109: pop
    //   2110: aload #4
    //   2112: getfield r : Ljava/util/Map;
    //   2115: ldc_w 'A30'
    //   2118: new java/lang/StringBuilder
    //   2121: dup
    //   2122: invokespecial <init> : ()V
    //   2125: aload_1
    //   2126: getfield K : Ljava/lang/String;
    //   2129: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2132: invokevirtual toString : ()Ljava/lang/String;
    //   2135: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2140: pop
    //   2141: aload #4
    //   2143: getfield r : Ljava/util/Map;
    //   2146: ldc_w 'A18'
    //   2149: new java/lang/StringBuilder
    //   2152: dup
    //   2153: invokespecial <init> : ()V
    //   2156: aload_1
    //   2157: getfield L : J
    //   2160: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   2163: invokevirtual toString : ()Ljava/lang/String;
    //   2166: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2171: pop
    //   2172: aload #4
    //   2174: getfield r : Ljava/util/Map;
    //   2177: astore #7
    //   2179: new java/lang/StringBuilder
    //   2182: dup
    //   2183: invokespecial <init> : ()V
    //   2186: astore_0
    //   2187: aload_1
    //   2188: getfield M : Z
    //   2191: ifne -> 2704
    //   2194: iconst_1
    //   2195: istore #10
    //   2197: aload #7
    //   2199: ldc_w 'A36'
    //   2202: aload_0
    //   2203: iload #10
    //   2205: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   2208: invokevirtual toString : ()Ljava/lang/String;
    //   2211: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2216: pop
    //   2217: aload #4
    //   2219: getfield r : Ljava/util/Map;
    //   2222: ldc_w 'F02'
    //   2225: new java/lang/StringBuilder
    //   2228: dup
    //   2229: invokespecial <init> : ()V
    //   2232: aload_2
    //   2233: getfield p : J
    //   2236: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   2239: invokevirtual toString : ()Ljava/lang/String;
    //   2242: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2247: pop
    //   2248: aload #4
    //   2250: getfield r : Ljava/util/Map;
    //   2253: ldc_w 'F03'
    //   2256: new java/lang/StringBuilder
    //   2259: dup
    //   2260: invokespecial <init> : ()V
    //   2263: aload_2
    //   2264: getfield q : J
    //   2267: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   2270: invokevirtual toString : ()Ljava/lang/String;
    //   2273: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2278: pop
    //   2279: aload #4
    //   2281: getfield r : Ljava/util/Map;
    //   2284: ldc_w 'F04'
    //   2287: new java/lang/StringBuilder
    //   2290: dup
    //   2291: invokespecial <init> : ()V
    //   2294: aload_2
    //   2295: invokevirtual d : ()Ljava/lang/String;
    //   2298: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2301: invokevirtual toString : ()Ljava/lang/String;
    //   2304: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2309: pop
    //   2310: aload #4
    //   2312: getfield r : Ljava/util/Map;
    //   2315: ldc_w 'F05'
    //   2318: new java/lang/StringBuilder
    //   2321: dup
    //   2322: invokespecial <init> : ()V
    //   2325: aload_2
    //   2326: getfield r : J
    //   2329: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   2332: invokevirtual toString : ()Ljava/lang/String;
    //   2335: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2340: pop
    //   2341: aload #4
    //   2343: getfield r : Ljava/util/Map;
    //   2346: ldc_w 'F06'
    //   2349: new java/lang/StringBuilder
    //   2352: dup
    //   2353: invokespecial <init> : ()V
    //   2356: aload_2
    //   2357: getfield o : Ljava/lang/String;
    //   2360: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2363: invokevirtual toString : ()Ljava/lang/String;
    //   2366: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2371: pop
    //   2372: aload #4
    //   2374: getfield r : Ljava/util/Map;
    //   2377: ldc_w 'F08'
    //   2380: new java/lang/StringBuilder
    //   2383: dup
    //   2384: invokespecial <init> : ()V
    //   2387: aload_2
    //   2388: getfield u : Ljava/lang/String;
    //   2391: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2394: invokevirtual toString : ()Ljava/lang/String;
    //   2397: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2402: pop
    //   2403: aload #4
    //   2405: getfield r : Ljava/util/Map;
    //   2408: ldc_w 'F09'
    //   2411: new java/lang/StringBuilder
    //   2414: dup
    //   2415: invokespecial <init> : ()V
    //   2418: aload_2
    //   2419: getfield v : Ljava/lang/String;
    //   2422: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2425: invokevirtual toString : ()Ljava/lang/String;
    //   2428: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2433: pop
    //   2434: aload #4
    //   2436: getfield r : Ljava/util/Map;
    //   2439: ldc_w 'F10'
    //   2442: new java/lang/StringBuilder
    //   2445: dup
    //   2446: invokespecial <init> : ()V
    //   2449: aload_2
    //   2450: getfield s : J
    //   2453: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   2456: invokevirtual toString : ()Ljava/lang/String;
    //   2459: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2464: pop
    //   2465: aload_1
    //   2466: getfield O : I
    //   2469: iflt -> 2503
    //   2472: aload #4
    //   2474: getfield r : Ljava/util/Map;
    //   2477: ldc_w 'C01'
    //   2480: new java/lang/StringBuilder
    //   2483: dup
    //   2484: invokespecial <init> : ()V
    //   2487: aload_1
    //   2488: getfield O : I
    //   2491: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2494: invokevirtual toString : ()Ljava/lang/String;
    //   2497: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2502: pop
    //   2503: aload_1
    //   2504: getfield P : I
    //   2507: iflt -> 2541
    //   2510: aload #4
    //   2512: getfield r : Ljava/util/Map;
    //   2515: ldc_w 'C02'
    //   2518: new java/lang/StringBuilder
    //   2521: dup
    //   2522: invokespecial <init> : ()V
    //   2525: aload_1
    //   2526: getfield P : I
    //   2529: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   2532: invokevirtual toString : ()Ljava/lang/String;
    //   2535: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2540: pop
    //   2541: aload_1
    //   2542: getfield Q : Ljava/util/Map;
    //   2545: ifnull -> 2710
    //   2548: aload_1
    //   2549: getfield Q : Ljava/util/Map;
    //   2552: invokeinterface size : ()I
    //   2557: ifle -> 2710
    //   2560: aload_1
    //   2561: getfield Q : Ljava/util/Map;
    //   2564: invokeinterface entrySet : ()Ljava/util/Set;
    //   2569: invokeinterface iterator : ()Ljava/util/Iterator;
    //   2574: astore #7
    //   2576: aload #7
    //   2578: invokeinterface hasNext : ()Z
    //   2583: ifeq -> 2710
    //   2586: aload #7
    //   2588: invokeinterface next : ()Ljava/lang/Object;
    //   2593: checkcast java/util/Map$Entry
    //   2596: astore_0
    //   2597: aload #4
    //   2599: getfield r : Ljava/util/Map;
    //   2602: new java/lang/StringBuilder
    //   2605: dup
    //   2606: ldc_w 'C03_'
    //   2609: invokespecial <init> : (Ljava/lang/String;)V
    //   2612: aload_0
    //   2613: invokeinterface getKey : ()Ljava/lang/Object;
    //   2618: checkcast java/lang/String
    //   2621: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2624: invokevirtual toString : ()Ljava/lang/String;
    //   2627: aload_0
    //   2628: invokeinterface getValue : ()Ljava/lang/Object;
    //   2633: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2638: pop
    //   2639: goto -> 2576
    //   2642: astore #7
    //   2644: aload #7
    //   2646: invokevirtual printStackTrace : ()V
    //   2649: aload #4
    //   2651: aconst_null
    //   2652: putfield q : Ljava/util/ArrayList;
    //   2655: goto -> 821
    //   2658: iconst_0
    //   2659: istore #9
    //   2661: goto -> 846
    //   2664: astore #7
    //   2666: aload #7
    //   2668: invokevirtual printStackTrace : ()V
    //   2671: aload #4
    //   2673: aconst_null
    //   2674: putfield q : Ljava/util/ArrayList;
    //   2677: goto -> 939
    //   2680: astore #7
    //   2682: aload #7
    //   2684: invokevirtual printStackTrace : ()V
    //   2687: aload #4
    //   2689: aconst_null
    //   2690: putfield q : Ljava/util/ArrayList;
    //   2693: goto -> 1124
    //   2696: astore_0
    //   2697: aload_0
    //   2698: invokevirtual printStackTrace : ()V
    //   2701: goto -> 2009
    //   2704: iconst_0
    //   2705: istore #10
    //   2707: goto -> 2197
    //   2710: aload_1
    //   2711: getfield R : Ljava/util/Map;
    //   2714: ifnull -> 2811
    //   2717: aload_1
    //   2718: getfield R : Ljava/util/Map;
    //   2721: invokeinterface size : ()I
    //   2726: ifle -> 2811
    //   2729: aload_1
    //   2730: getfield R : Ljava/util/Map;
    //   2733: invokeinterface entrySet : ()Ljava/util/Set;
    //   2738: invokeinterface iterator : ()Ljava/util/Iterator;
    //   2743: astore #7
    //   2745: aload #7
    //   2747: invokeinterface hasNext : ()Z
    //   2752: ifeq -> 2811
    //   2755: aload #7
    //   2757: invokeinterface next : ()Ljava/lang/Object;
    //   2762: checkcast java/util/Map$Entry
    //   2765: astore_0
    //   2766: aload #4
    //   2768: getfield r : Ljava/util/Map;
    //   2771: new java/lang/StringBuilder
    //   2774: dup
    //   2775: ldc_w 'C04_'
    //   2778: invokespecial <init> : (Ljava/lang/String;)V
    //   2781: aload_0
    //   2782: invokeinterface getKey : ()Ljava/lang/Object;
    //   2787: checkcast java/lang/String
    //   2790: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2793: invokevirtual toString : ()Ljava/lang/String;
    //   2796: aload_0
    //   2797: invokeinterface getValue : ()Ljava/lang/Object;
    //   2802: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   2807: pop
    //   2808: goto -> 2745
    //   2811: aload #4
    //   2813: aconst_null
    //   2814: putfield s : Ljava/util/Map;
    //   2817: aload_1
    //   2818: getfield N : Ljava/util/Map;
    //   2821: ifnull -> 2872
    //   2824: aload_1
    //   2825: getfield N : Ljava/util/Map;
    //   2828: invokeinterface size : ()I
    //   2833: ifle -> 2872
    //   2836: aload #4
    //   2838: aload_1
    //   2839: getfield N : Ljava/util/Map;
    //   2842: putfield s : Ljava/util/Map;
    //   2845: ldc_w 'setted message size %d'
    //   2848: iconst_1
    //   2849: anewarray java/lang/Object
    //   2852: dup
    //   2853: iconst_0
    //   2854: aload #4
    //   2856: getfield s : Ljava/util/Map;
    //   2859: invokeinterface size : ()I
    //   2864: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   2867: aastore
    //   2868: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   2871: pop
    //   2872: aload_1
    //   2873: getfield n : Ljava/lang/String;
    //   2876: astore_0
    //   2877: aload_1
    //   2878: getfield c : Ljava/lang/String;
    //   2881: astore #7
    //   2883: aload_2
    //   2884: invokevirtual d : ()Ljava/lang/String;
    //   2887: astore_2
    //   2888: aload_1
    //   2889: getfield r : J
    //   2892: aload_1
    //   2893: getfield L : J
    //   2896: lsub
    //   2897: ldc2_w 1000
    //   2900: ldiv
    //   2901: lstore #11
    //   2903: aload_1
    //   2904: getfield k : Z
    //   2907: istore #13
    //   2909: aload_1
    //   2910: getfield M : Z
    //   2913: istore #14
    //   2915: aload_1
    //   2916: getfield j : Z
    //   2919: istore #15
    //   2921: aload_1
    //   2922: getfield b : I
    //   2925: iconst_1
    //   2926: if_icmpne -> 3052
    //   2929: iload_3
    //   2930: istore #10
    //   2932: ldc_w '%s rid:%s sess:%s ls:%ds isR:%b isF:%b isM:%b isN:%b mc:%d ,%s ,isUp:%b ,vm:%d'
    //   2935: bipush #12
    //   2937: anewarray java/lang/Object
    //   2940: dup
    //   2941: iconst_0
    //   2942: aload_0
    //   2943: aastore
    //   2944: dup
    //   2945: iconst_1
    //   2946: aload #7
    //   2948: aastore
    //   2949: dup
    //   2950: iconst_2
    //   2951: aload_2
    //   2952: aastore
    //   2953: dup
    //   2954: iconst_3
    //   2955: lload #11
    //   2957: invokestatic valueOf : (J)Ljava/lang/Long;
    //   2960: aastore
    //   2961: dup
    //   2962: iconst_4
    //   2963: iload #13
    //   2965: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   2968: aastore
    //   2969: dup
    //   2970: iconst_5
    //   2971: iload #14
    //   2973: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   2976: aastore
    //   2977: dup
    //   2978: bipush #6
    //   2980: iload #15
    //   2982: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   2985: aastore
    //   2986: dup
    //   2987: bipush #7
    //   2989: iload #10
    //   2991: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   2994: aastore
    //   2995: dup
    //   2996: bipush #8
    //   2998: aload_1
    //   2999: getfield t : I
    //   3002: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   3005: aastore
    //   3006: dup
    //   3007: bipush #9
    //   3009: aload_1
    //   3010: getfield s : Ljava/lang/String;
    //   3013: aastore
    //   3014: dup
    //   3015: bipush #10
    //   3017: aload_1
    //   3018: getfield d : Z
    //   3021: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   3024: aastore
    //   3025: dup
    //   3026: bipush #11
    //   3028: aload #4
    //   3030: getfield r : Ljava/util/Map;
    //   3033: invokeinterface size : ()I
    //   3038: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   3041: aastore
    //   3042: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   3045: pop
    //   3046: aload #4
    //   3048: astore_0
    //   3049: goto -> 27
    //   3052: iconst_0
    //   3053: istore #10
    //   3055: goto -> 2932
    // Exception table:
    //   from	to	target	type
    //   782	821	2642	java/io/UnsupportedEncodingException
    //   900	939	2664	java/io/UnsupportedEncodingException
    //   1063	1124	2680	java/io/UnsupportedEncodingException
    //   1965	2009	2696	java/io/UnsupportedEncodingException
  }
  
  private static List<a> a(List<a> paramList) {
    if (paramList == null || paramList.size() == 0)
      return null; 
    long l = a.o();
    ArrayList<a> arrayList = new ArrayList();
    for (a a1 : paramList) {
      if (a1.d && a1.b < l - 86400000L)
        arrayList.add(a1); 
    } 
    return arrayList;
  }
  
  public static void a(String paramString1, String paramString2, String paramString3, Thread paramThread, String paramString4, CrashDetailBean paramCrashDetailBean) {
    a a1 = a.a();
    if (a1 != null) {
      boolean bool;
      w.e("#++++++++++Record By Bugly++++++++++#", new Object[0]);
      w.e("# You can use Bugly(http:\\\\bugly.qq.com) to get more Crash Detail!", new Object[0]);
      w.e("# PKG NAME: %s", new Object[] { a1.c });
      w.e("# APP VER: %s", new Object[] { a1.i });
      w.e("# LAUNCH TIME: %s", new Object[] { a.a(new Date((a.a()).a)) });
      w.e("# CRASH TYPE: %s", new Object[] { paramString1 });
      w.e("# CRASH TIME: %s", new Object[] { paramString2 });
      w.e("# CRASH PROCESS: %s", new Object[] { paramString3 });
      if (paramThread != null)
        w.e("# CRASH THREAD: %s", new Object[] { paramThread.getName() }); 
      if (paramCrashDetailBean != null) {
        w.e("# REPORT ID: %s", new Object[] { paramCrashDetailBean.c });
        paramString2 = a1.f;
        if (a1.u().booleanValue()) {
          paramString1 = "ROOTED";
        } else {
          paramString1 = "UNROOT";
        } 
        w.e("# CRASH DEVICE: %s %s", new Object[] { paramString2, paramString1 });
        w.e("# RUNTIME AVAIL RAM:%d ROM:%d SD:%d", new Object[] { Long.valueOf(paramCrashDetailBean.B), Long.valueOf(paramCrashDetailBean.C), Long.valueOf(paramCrashDetailBean.D) });
        w.e("# RUNTIME TOTAL RAM:%d ROM:%d SD:%d", new Object[] { Long.valueOf(paramCrashDetailBean.E), Long.valueOf(paramCrashDetailBean.F), Long.valueOf(paramCrashDetailBean.G) });
        paramString1 = paramCrashDetailBean.J;
        if (paramString1 != null && paramString1.trim().length() > 0) {
          bool = false;
        } else {
          bool = true;
        } 
        if (!bool) {
          w.e("# EXCEPTION FIRED BY %s %s", new Object[] { paramCrashDetailBean.J, paramCrashDetailBean.I });
        } else if (paramCrashDetailBean.b == 3) {
          if (paramCrashDetailBean.N == null) {
            paramString1 = "null";
          } else {
            paramString1 = paramCrashDetailBean.N.get("BUGLY_CR_01");
          } 
          w.e("# EXCEPTION ANR MESSAGE:\n %s", new Object[] { paramString1 });
        } 
      } 
      if (paramString4 != null && paramString4.trim().length() > 0) {
        bool = false;
      } else {
        bool = true;
      } 
      if (!bool) {
        w.e("# CRASH STACK: ", new Object[0]);
        w.e(paramString4, new Object[0]);
      } 
      w.e("#++++++++++++++++++++++++++++++++++++++++++#", new Object[0]);
    } 
  }
  
  public static void a(boolean paramBoolean, List<CrashDetailBean> paramList) {
    if (paramList != null && paramList.size() > 0) {
      w.c("up finish update state %b", new Object[] { Boolean.valueOf(paramBoolean) });
      for (CrashDetailBean crashDetailBean : paramList) {
        w.c("pre uid:%s uc:%d re:%b me:%b", new Object[] { crashDetailBean.c, Integer.valueOf(crashDetailBean.l), Boolean.valueOf(crashDetailBean.d), Boolean.valueOf(crashDetailBean.j) });
        crashDetailBean.l++;
        crashDetailBean.d = paramBoolean;
        w.c("set uid:%s uc:%d re:%b me:%b", new Object[] { crashDetailBean.c, Integer.valueOf(crashDetailBean.l), Boolean.valueOf(crashDetailBean.d), Boolean.valueOf(crashDetailBean.j) });
      } 
      for (CrashDetailBean crashDetailBean : paramList)
        c.a().a(crashDetailBean); 
      w.c("update state size %d", new Object[] { Integer.valueOf(paramList.size()) });
    } 
    if (!paramBoolean)
      w.b("[crash] upload fail.", new Object[0]); 
  }
  
  private static a b(Cursor paramCursor) {
    Cursor cursor = null;
    boolean bool = true;
    if (paramCursor == null)
      return (a)cursor; 
    try {
      boolean bool1;
      a a2 = new a();
      this();
      a2.a = paramCursor.getLong(paramCursor.getColumnIndex("_id"));
      a2.b = paramCursor.getLong(paramCursor.getColumnIndex("_tm"));
      a2.c = paramCursor.getString(paramCursor.getColumnIndex("_s1"));
      if (paramCursor.getInt(paramCursor.getColumnIndex("_up")) == 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      a2.d = bool1;
      if (paramCursor.getInt(paramCursor.getColumnIndex("_me")) == 1) {
        bool1 = bool;
      } else {
        bool1 = false;
      } 
      a2.e = bool1;
      a2.f = paramCursor.getInt(paramCursor.getColumnIndex("_uc"));
      a a1 = a2;
    } catch (Throwable throwable) {
      paramCursor = cursor;
    } 
    return (a)paramCursor;
  }
  
  private List<a> b() {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: new java/util/ArrayList
    //   5: dup
    //   6: invokespecial <init> : ()V
    //   9: astore_2
    //   10: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   13: ldc_w 't_cr'
    //   16: bipush #6
    //   18: anewarray java/lang/String
    //   21: dup
    //   22: iconst_0
    //   23: ldc '_id'
    //   25: aastore
    //   26: dup
    //   27: iconst_1
    //   28: ldc_w '_tm'
    //   31: aastore
    //   32: dup
    //   33: iconst_2
    //   34: ldc_w '_s1'
    //   37: aastore
    //   38: dup
    //   39: iconst_3
    //   40: ldc_w '_up'
    //   43: aastore
    //   44: dup
    //   45: iconst_4
    //   46: ldc_w '_me'
    //   49: aastore
    //   50: dup
    //   51: iconst_5
    //   52: ldc_w '_uc'
    //   55: aastore
    //   56: aconst_null
    //   57: aconst_null
    //   58: aconst_null
    //   59: iconst_1
    //   60: invokevirtual a : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Lcom/tencent/bugly/legu/proguard/n;Z)Landroid/database/Cursor;
    //   63: astore_3
    //   64: aload_3
    //   65: astore_1
    //   66: aload_1
    //   67: ifnonnull -> 93
    //   70: aload_1
    //   71: ifnull -> 89
    //   74: aload_1
    //   75: invokeinterface isClosed : ()Z
    //   80: ifne -> 89
    //   83: aload_1
    //   84: invokeinterface close : ()V
    //   89: aconst_null
    //   90: astore_1
    //   91: aload_1
    //   92: areturn
    //   93: new java/lang/StringBuilder
    //   96: astore_3
    //   97: aload_3
    //   98: invokespecial <init> : ()V
    //   101: aload_1
    //   102: invokeinterface moveToNext : ()Z
    //   107: ifeq -> 249
    //   110: aload_1
    //   111: invokestatic b : (Landroid/database/Cursor;)Lcom/tencent/bugly/legu/crashreport/crash/a;
    //   114: astore #4
    //   116: aload #4
    //   118: ifnull -> 169
    //   121: aload_2
    //   122: aload #4
    //   124: invokeinterface add : (Ljava/lang/Object;)Z
    //   129: pop
    //   130: goto -> 101
    //   133: astore_3
    //   134: aload_3
    //   135: invokestatic a : (Ljava/lang/Throwable;)Z
    //   138: ifne -> 145
    //   141: aload_3
    //   142: invokevirtual printStackTrace : ()V
    //   145: aload_1
    //   146: ifnull -> 164
    //   149: aload_1
    //   150: invokeinterface isClosed : ()Z
    //   155: ifne -> 164
    //   158: aload_1
    //   159: invokeinterface close : ()V
    //   164: aload_2
    //   165: astore_1
    //   166: goto -> 91
    //   169: aload_1
    //   170: aload_1
    //   171: ldc '_id'
    //   173: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   178: invokeinterface getLong : (I)J
    //   183: lstore #5
    //   185: aload_3
    //   186: ldc_w ' or _id'
    //   189: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   192: ldc_w ' = '
    //   195: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   198: lload #5
    //   200: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   203: pop
    //   204: goto -> 101
    //   207: astore #4
    //   209: ldc_w 'unknown id!'
    //   212: iconst_0
    //   213: anewarray java/lang/Object
    //   216: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   219: pop
    //   220: goto -> 101
    //   223: astore_3
    //   224: aload_1
    //   225: astore_2
    //   226: aload_3
    //   227: astore_1
    //   228: aload_2
    //   229: ifnull -> 247
    //   232: aload_2
    //   233: invokeinterface isClosed : ()Z
    //   238: ifne -> 247
    //   241: aload_2
    //   242: invokeinterface close : ()V
    //   247: aload_1
    //   248: athrow
    //   249: aload_3
    //   250: invokevirtual toString : ()Ljava/lang/String;
    //   253: astore_3
    //   254: aload_3
    //   255: invokevirtual length : ()I
    //   258: ifle -> 303
    //   261: aload_3
    //   262: iconst_4
    //   263: invokevirtual substring : (I)Ljava/lang/String;
    //   266: astore_3
    //   267: ldc_w 'deleted %s illegle data %d'
    //   270: iconst_2
    //   271: anewarray java/lang/Object
    //   274: dup
    //   275: iconst_0
    //   276: ldc_w 't_cr'
    //   279: aastore
    //   280: dup
    //   281: iconst_1
    //   282: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   285: ldc_w 't_cr'
    //   288: aload_3
    //   289: aconst_null
    //   290: aconst_null
    //   291: iconst_1
    //   292: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Lcom/tencent/bugly/legu/proguard/n;Z)I
    //   295: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   298: aastore
    //   299: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   302: pop
    //   303: aload_1
    //   304: ifnull -> 322
    //   307: aload_1
    //   308: invokeinterface isClosed : ()Z
    //   313: ifne -> 322
    //   316: aload_1
    //   317: invokeinterface close : ()V
    //   322: aload_2
    //   323: astore_1
    //   324: goto -> 91
    //   327: astore_1
    //   328: aconst_null
    //   329: astore_2
    //   330: goto -> 228
    //   333: astore_2
    //   334: aload_1
    //   335: astore_3
    //   336: aload_2
    //   337: astore_1
    //   338: aload_3
    //   339: astore_2
    //   340: goto -> 228
    //   343: astore_3
    //   344: goto -> 134
    // Exception table:
    //   from	to	target	type
    //   10	64	343	java/lang/Throwable
    //   10	64	327	finally
    //   93	101	133	java/lang/Throwable
    //   93	101	223	finally
    //   101	116	133	java/lang/Throwable
    //   101	116	223	finally
    //   121	130	133	java/lang/Throwable
    //   121	130	223	finally
    //   134	145	333	finally
    //   169	204	207	java/lang/Throwable
    //   169	204	223	finally
    //   209	220	133	java/lang/Throwable
    //   209	220	223	finally
    //   249	303	133	java/lang/Throwable
    //   249	303	223	finally
  }
  
  private List<CrashDetailBean> b(List<a> paramList) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 13
    //   4: aload_1
    //   5: invokeinterface size : ()I
    //   10: ifne -> 17
    //   13: aconst_null
    //   14: astore_1
    //   15: aload_1
    //   16: areturn
    //   17: new java/lang/StringBuilder
    //   20: dup
    //   21: invokespecial <init> : ()V
    //   24: astore_2
    //   25: aload_1
    //   26: invokeinterface iterator : ()Ljava/util/Iterator;
    //   31: astore_1
    //   32: aload_1
    //   33: invokeinterface hasNext : ()Z
    //   38: ifeq -> 75
    //   41: aload_1
    //   42: invokeinterface next : ()Ljava/lang/Object;
    //   47: checkcast com/tencent/bugly/legu/crashreport/crash/a
    //   50: astore_3
    //   51: aload_2
    //   52: ldc_w ' or _id'
    //   55: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: ldc_w ' = '
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: aload_3
    //   65: getfield a : J
    //   68: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   71: pop
    //   72: goto -> 32
    //   75: aload_2
    //   76: invokevirtual toString : ()Ljava/lang/String;
    //   79: astore_3
    //   80: aload_3
    //   81: astore_1
    //   82: aload_3
    //   83: invokevirtual length : ()I
    //   86: ifle -> 95
    //   89: aload_3
    //   90: iconst_4
    //   91: invokevirtual substring : (I)Ljava/lang/String;
    //   94: astore_1
    //   95: aload_2
    //   96: iconst_0
    //   97: invokevirtual setLength : (I)V
    //   100: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   103: ldc_w 't_cr'
    //   106: aconst_null
    //   107: aload_1
    //   108: aconst_null
    //   109: aconst_null
    //   110: iconst_1
    //   111: invokevirtual a : (Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Lcom/tencent/bugly/legu/proguard/n;Z)Landroid/database/Cursor;
    //   114: astore_1
    //   115: aload_1
    //   116: ifnonnull -> 143
    //   119: aload_1
    //   120: ifnull -> 138
    //   123: aload_1
    //   124: invokeinterface isClosed : ()Z
    //   129: ifne -> 138
    //   132: aload_1
    //   133: invokeinterface close : ()V
    //   138: aconst_null
    //   139: astore_1
    //   140: goto -> 15
    //   143: new java/util/ArrayList
    //   146: astore_3
    //   147: aload_3
    //   148: invokespecial <init> : ()V
    //   151: aload_1
    //   152: invokeinterface moveToNext : ()Z
    //   157: ifeq -> 299
    //   160: aload_1
    //   161: invokestatic a : (Landroid/database/Cursor;)Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;
    //   164: astore #4
    //   166: aload #4
    //   168: ifnull -> 219
    //   171: aload_3
    //   172: aload #4
    //   174: invokeinterface add : (Ljava/lang/Object;)Z
    //   179: pop
    //   180: goto -> 151
    //   183: astore_3
    //   184: aload_3
    //   185: invokestatic a : (Ljava/lang/Throwable;)Z
    //   188: ifne -> 195
    //   191: aload_3
    //   192: invokevirtual printStackTrace : ()V
    //   195: aload_1
    //   196: ifnull -> 214
    //   199: aload_1
    //   200: invokeinterface isClosed : ()Z
    //   205: ifne -> 214
    //   208: aload_1
    //   209: invokeinterface close : ()V
    //   214: aconst_null
    //   215: astore_1
    //   216: goto -> 15
    //   219: aload_1
    //   220: aload_1
    //   221: ldc '_id'
    //   223: invokeinterface getColumnIndex : (Ljava/lang/String;)I
    //   228: invokeinterface getLong : (I)J
    //   233: lstore #5
    //   235: aload_2
    //   236: ldc_w ' or _id'
    //   239: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   242: ldc_w ' = '
    //   245: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   248: lload #5
    //   250: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   253: pop
    //   254: goto -> 151
    //   257: astore #4
    //   259: ldc_w 'unknown id!'
    //   262: iconst_0
    //   263: anewarray java/lang/Object
    //   266: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   269: pop
    //   270: goto -> 151
    //   273: astore_2
    //   274: aload_1
    //   275: astore_3
    //   276: aload_2
    //   277: astore_1
    //   278: aload_3
    //   279: ifnull -> 297
    //   282: aload_3
    //   283: invokeinterface isClosed : ()Z
    //   288: ifne -> 297
    //   291: aload_3
    //   292: invokeinterface close : ()V
    //   297: aload_1
    //   298: athrow
    //   299: aload_2
    //   300: invokevirtual toString : ()Ljava/lang/String;
    //   303: astore_2
    //   304: aload_2
    //   305: invokevirtual length : ()I
    //   308: ifle -> 353
    //   311: aload_2
    //   312: iconst_4
    //   313: invokevirtual substring : (I)Ljava/lang/String;
    //   316: astore_2
    //   317: ldc_w 'deleted %s illegle data %d'
    //   320: iconst_2
    //   321: anewarray java/lang/Object
    //   324: dup
    //   325: iconst_0
    //   326: ldc_w 't_cr'
    //   329: aastore
    //   330: dup
    //   331: iconst_1
    //   332: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/o;
    //   335: ldc_w 't_cr'
    //   338: aload_2
    //   339: aconst_null
    //   340: aconst_null
    //   341: iconst_1
    //   342: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Lcom/tencent/bugly/legu/proguard/n;Z)I
    //   345: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   348: aastore
    //   349: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   352: pop
    //   353: aload_1
    //   354: ifnull -> 372
    //   357: aload_1
    //   358: invokeinterface isClosed : ()Z
    //   363: ifne -> 372
    //   366: aload_1
    //   367: invokeinterface close : ()V
    //   372: aload_3
    //   373: astore_1
    //   374: goto -> 15
    //   377: astore_1
    //   378: aconst_null
    //   379: astore_3
    //   380: goto -> 278
    //   383: astore_3
    //   384: aload_1
    //   385: astore_2
    //   386: aload_3
    //   387: astore_1
    //   388: aload_2
    //   389: astore_3
    //   390: goto -> 278
    //   393: astore_3
    //   394: aconst_null
    //   395: astore_1
    //   396: goto -> 184
    // Exception table:
    //   from	to	target	type
    //   100	115	393	java/lang/Throwable
    //   100	115	377	finally
    //   143	151	183	java/lang/Throwable
    //   143	151	273	finally
    //   151	166	183	java/lang/Throwable
    //   151	166	273	finally
    //   171	180	183	java/lang/Throwable
    //   171	180	273	finally
    //   184	195	383	finally
    //   219	254	257	java/lang/Throwable
    //   219	254	273	finally
    //   259	270	183	java/lang/Throwable
    //   259	270	273	finally
    //   299	353	183	java/lang/Throwable
    //   299	353	273	finally
  }
  
  private static void c(List<a> paramList) {
    if (paramList != null && paramList.size() != 0) {
      StringBuilder stringBuilder = new StringBuilder();
      for (a a1 : paramList)
        stringBuilder.append(" or _id").append(" = ").append(a1.a); 
      String str2 = stringBuilder.toString();
      String str1 = str2;
      if (str2.length() > 0)
        str1 = str2.substring(4); 
      stringBuilder.setLength(0);
      try {
        w.c("deleted %s data %d", new Object[] { "t_cr", Integer.valueOf(o.a().a("t_cr", str1, null, null, true)) });
      } catch (Throwable throwable) {}
    } 
  }
  
  private static ContentValues d(CrashDetailBean paramCrashDetailBean) {
    CrashDetailBean crashDetailBean = null;
    boolean bool = true;
    if (paramCrashDetailBean == null)
      return (ContentValues)crashDetailBean; 
    try {
      boolean bool1;
      ContentValues contentValues2 = new ContentValues();
      this();
      if (paramCrashDetailBean.a > 0L)
        contentValues2.put("_id", Long.valueOf(paramCrashDetailBean.a)); 
      contentValues2.put("_tm", Long.valueOf(paramCrashDetailBean.r));
      contentValues2.put("_s1", paramCrashDetailBean.u);
      if (paramCrashDetailBean.d) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      contentValues2.put("_up", Integer.valueOf(bool1));
      if (paramCrashDetailBean.j) {
        bool1 = bool;
      } else {
        bool1 = false;
      } 
      contentValues2.put("_me", Integer.valueOf(bool1));
      contentValues2.put("_uc", Integer.valueOf(paramCrashDetailBean.l));
      Parcel parcel = Parcel.obtain();
      paramCrashDetailBean.writeToParcel(parcel, 0);
      byte[] arrayOfByte = parcel.marshall();
      parcel.recycle();
      contentValues2.put("_dt", arrayOfByte);
      ContentValues contentValues1 = contentValues2;
    } catch (Throwable throwable) {
      paramCrashDetailBean = crashDetailBean;
    } 
    return (ContentValues)paramCrashDetailBean;
  }
  
  private static void d(List<CrashDetailBean> paramList) {
    if (paramList != null)
      try {
        if (paramList.size() != 0) {
          StringBuilder stringBuilder = new StringBuilder();
          this();
          for (CrashDetailBean crashDetailBean : paramList)
            stringBuilder.append(" or _id").append(" = ").append(crashDetailBean.a); 
          String str2 = stringBuilder.toString();
          String str1 = str2;
          if (str2.length() > 0)
            str1 = str2.substring(4); 
          stringBuilder.setLength(0);
          w.c("deleted %s data %d", new Object[] { "t_cr", Integer.valueOf(o.a().a("t_cr", str1, null, null, true)) });
        } 
      } catch (Throwable throwable) {} 
  }
  
  public final List<CrashDetailBean> a() {
    List<CrashDetailBean> list;
    StrategyBean strategyBean1 = null;
    StrategyBean strategyBean2 = a.a().c();
    if (strategyBean2 == null) {
      w.d("have not synced remote!", new Object[0]);
      return (List<CrashDetailBean>)strategyBean1;
    } 
    if (!strategyBean2.d) {
      w.d("Crashreport remote closed, please check your APPID correct and Version available, then uninstall and reinstall your app.", new Object[0]);
      w.b("[init] WARNING! Crashreport closed by server, please check your APPID correct and Version available, then uninstall and reinstall your app.", new Object[0]);
      return (List<CrashDetailBean>)strategyBean1;
    } 
    long l1 = System.currentTimeMillis();
    long l2 = a.o();
    List<a> list1 = b();
    strategyBean2 = strategyBean1;
    if (list1 != null) {
      strategyBean2 = strategyBean1;
      if (list1.size() > 0) {
        ArrayList<a> arrayList = new ArrayList();
        Iterator<a> iterator = list1.iterator();
        while (iterator.hasNext()) {
          a a1 = iterator.next();
          if (a1.b < l2 - c.f) {
            iterator.remove();
            arrayList.add(a1);
            continue;
          } 
          if (a1.d) {
            if (a1.b >= l1 - 86400000L) {
              iterator.remove();
              continue;
            } 
            if (!a1.e) {
              iterator.remove();
              arrayList.add(a1);
            } 
            continue;
          } 
          if (a1.f >= 3L && a1.b < l1 - 86400000L) {
            iterator.remove();
            arrayList.add(a1);
          } 
        } 
        if (arrayList.size() > 0)
          c(arrayList); 
        arrayList = new ArrayList<a>();
        list = b(list1);
        if (list != null && list.size() > 0) {
          String str = (a.a()).i;
          Iterator<CrashDetailBean> iterator1 = list.iterator();
          while (iterator1.hasNext()) {
            CrashDetailBean crashDetailBean = iterator1.next();
            if (!str.equals(crashDetailBean.f)) {
              iterator1.remove();
              arrayList.add(crashDetailBean);
            } 
          } 
        } 
        if (arrayList.size() > 0)
          d((List)arrayList); 
      } 
    } 
    return list;
  }
  
  public final void a(CrashDetailBean paramCrashDetailBean, long paramLong, boolean paramBoolean) {
    w.a("try to upload right now", new Object[0]);
    ArrayList<CrashDetailBean> arrayList = new ArrayList();
    arrayList.add(paramCrashDetailBean);
    a(arrayList, 5000L, paramBoolean);
    int i = paramCrashDetailBean.b;
    if (this.e != null)
      n n1 = this.e; 
  }
  
  public final void a(List<CrashDetailBean> paramList, long paramLong, boolean paramBoolean) {
    al al = null;
    if (!(this.d.c()).d) {
      w.d("remote report is disable!", new Object[0]);
      w.b("[crash] server closed bugly in this app. please check your appid if is correct, and re-install it", new Object[0]);
      return;
    } 
    if (paramList != null && paramList.size() != 0) {
      try {
        Context context = this.b;
        a a1 = a.a();
        if (context == null || paramList == null || paramList.size() == 0 || a1 == null) {
          w.d("enEXPPkg args == null!", new Object[0]);
        } else {
          al = new al();
          this();
          ArrayList arrayList = new ArrayList();
          this();
          al.a = arrayList;
          Iterator<CrashDetailBean> iterator = paramList.iterator();
          while (true) {
            if (iterator.hasNext()) {
              CrashDetailBean crashDetailBean = iterator.next();
              al.a.add(a(context, crashDetailBean, a1));
              continue;
            } 
            if (al == null) {
              w.d("create eupPkg fail!", new Object[0]);
              return;
            } 
          } 
        } 
        if (al == null) {
          w.d("create eupPkg fail!", new Object[0]);
          return;
        } 
      } catch (Throwable throwable) {
        w.e("req cr error %s", new Object[] { throwable.toString() });
        if (!w.b(throwable))
          throwable.printStackTrace(); 
        return;
      } 
      byte[] arrayOfByte = a.a((j)al);
      if (arrayOfByte == null) {
        w.d("send encode fail!", new Object[0]);
        return;
      } 
      am am = a.a(this.b, 630, arrayOfByte);
      if (am == null) {
        w.d("request package is null.", new Object[0]);
        return;
      } 
      s s = new s() {
          public final void a(boolean param1Boolean) {
            b b1 = this.b;
            b.a(param1Boolean, this.a);
          }
        };
      super(this, (List)throwable);
      if (!paramBoolean) {
        t.a().a(a, am, null, s);
        return;
      } 
      t.a().a(a, am, null, s, true, paramLong);
      w.a("wake up!", new Object[0]);
    } 
  }
  
  public final boolean a(CrashDetailBean paramCrashDetailBean) {
    return a(paramCrashDetailBean, -123456789);
  }
  
  public final boolean a(CrashDetailBean paramCrashDetailBean, int paramInt) {
    boolean bool = true;
    paramInt = paramCrashDetailBean.b;
    String str = paramCrashDetailBean.n;
    str = paramCrashDetailBean.p;
    str = paramCrashDetailBean.q;
    long l = paramCrashDetailBean.r;
    str = paramCrashDetailBean.m;
    str = paramCrashDetailBean.e;
    str = paramCrashDetailBean.c;
    if (this.e == null || this.e.c()) {
      ArrayList<a> arrayList;
      if (paramCrashDetailBean.b != 2) {
        q q = new q();
        q.b = 1;
        q.c = paramCrashDetailBean.z;
        q.d = paramCrashDetailBean.A;
        q.e = paramCrashDetailBean.r;
        o o1 = this.c;
        o.b(1);
        this.c.a(q);
        w.b("[crash] a crash occur, handling...", new Object[0]);
      } else {
        w.b("[crash] a caught exception occur, handling...", new Object[0]);
      } 
      List<a> list = b();
      String str1 = null;
      str = str1;
      if (list != null) {
        str = str1;
        if (list.size() > 0) {
          arrayList = new ArrayList(10);
          ArrayList<a> arrayList1 = new ArrayList(10);
          arrayList.addAll(a(list));
          list.removeAll(arrayList);
          if (!com.tencent.bugly.legu.b.b && c.c) {
            Iterator<a> iterator = list.iterator();
            for (paramInt = 0; iterator.hasNext(); paramInt = i) {
              a a1 = iterator.next();
              int i = paramInt;
              if (paramCrashDetailBean.u.equals(a1.c)) {
                if (a1.e)
                  paramInt = 1; 
                arrayList1.add(a1);
                i = paramInt;
              } 
            } 
            if (paramInt != 0 || arrayList1.size() + 1 >= 5) {
              w.a("same crash occur too much do merged!", new Object[0]);
              paramCrashDetailBean = a(arrayList1, paramCrashDetailBean);
              paramCrashDetailBean.a = -1L;
              c(paramCrashDetailBean);
              arrayList.addAll(arrayList1);
              c(arrayList);
              w.b("[crash] save crash success. this device crash many times, won't upload crashes immediately", new Object[0]);
              return bool;
            } 
          } 
        } 
      } 
      c(paramCrashDetailBean);
      c(arrayList);
      w.b("[crash] save crash success", new Object[0]);
      bool = false;
    } 
    return bool;
  }
  
  public final void b(CrashDetailBean paramCrashDetailBean) {
    // Byte code:
    //   0: aload_1
    //   1: ifnonnull -> 5
    //   4: return
    //   5: aload_0
    //   6: getfield f : Lcom/tencent/bugly/legu/BuglyStrategy$a;
    //   9: ifnonnull -> 19
    //   12: aload_0
    //   13: getfield e : Lcom/tencent/bugly/legu/proguard/n;
    //   16: ifnull -> 4
    //   19: ldc_w '[crash callback] start user's callback:onCrashHandleStart()'
    //   22: iconst_0
    //   23: anewarray java/lang/Object
    //   26: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   29: pop
    //   30: aload_1
    //   31: getfield b : I
    //   34: tableswitch default -> 76, 0 -> 79, 1 -> 534, 2 -> 529, 3 -> 524, 4 -> 539, 5 -> 544, 6 -> 549
    //   76: goto -> 4
    //   79: iconst_0
    //   80: istore_2
    //   81: aload_1
    //   82: getfield b : I
    //   85: istore_3
    //   86: aload_1
    //   87: getfield n : Ljava/lang/String;
    //   90: astore #4
    //   92: aload_1
    //   93: getfield p : Ljava/lang/String;
    //   96: astore #4
    //   98: aload_1
    //   99: getfield q : Ljava/lang/String;
    //   102: astore #4
    //   104: aload_1
    //   105: getfield r : J
    //   108: lstore #5
    //   110: aconst_null
    //   111: astore #4
    //   113: aload_0
    //   114: getfield e : Lcom/tencent/bugly/legu/proguard/n;
    //   117: ifnull -> 555
    //   120: aload_0
    //   121: getfield e : Lcom/tencent/bugly/legu/proguard/n;
    //   124: astore #7
    //   126: aload_0
    //   127: getfield e : Lcom/tencent/bugly/legu/proguard/n;
    //   130: invokeinterface b : ()Ljava/lang/String;
    //   135: astore #7
    //   137: aload #7
    //   139: ifnull -> 166
    //   142: new java/util/HashMap
    //   145: astore #4
    //   147: aload #4
    //   149: iconst_1
    //   150: invokespecial <init> : (I)V
    //   153: aload #4
    //   155: ldc_w 'userData'
    //   158: aload #7
    //   160: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   165: pop
    //   166: aload #4
    //   168: ifnull -> 630
    //   171: aload #4
    //   173: invokeinterface size : ()I
    //   178: ifle -> 630
    //   181: new java/util/LinkedHashMap
    //   184: astore #7
    //   186: aload #7
    //   188: aload #4
    //   190: invokeinterface size : ()I
    //   195: invokespecial <init> : (I)V
    //   198: aload_1
    //   199: aload #7
    //   201: putfield N : Ljava/util/Map;
    //   204: aload #4
    //   206: invokeinterface entrySet : ()Ljava/util/Set;
    //   211: invokeinterface iterator : ()Ljava/util/Iterator;
    //   216: astore #8
    //   218: aload #8
    //   220: invokeinterface hasNext : ()Z
    //   225: ifeq -> 630
    //   228: aload #8
    //   230: invokeinterface next : ()Ljava/lang/Object;
    //   235: checkcast java/util/Map$Entry
    //   238: astore #9
    //   240: aload #9
    //   242: invokeinterface getKey : ()Ljava/lang/Object;
    //   247: checkcast java/lang/String
    //   250: astore #4
    //   252: aload #4
    //   254: ifnull -> 587
    //   257: aload #4
    //   259: invokevirtual trim : ()Ljava/lang/String;
    //   262: invokevirtual length : ()I
    //   265: ifle -> 587
    //   268: iconst_0
    //   269: istore_3
    //   270: iload_3
    //   271: ifne -> 218
    //   274: aload #9
    //   276: invokeinterface getKey : ()Ljava/lang/Object;
    //   281: checkcast java/lang/String
    //   284: astore #7
    //   286: aload #7
    //   288: astore #4
    //   290: aload #7
    //   292: invokevirtual length : ()I
    //   295: bipush #100
    //   297: if_icmple -> 334
    //   300: aload #7
    //   302: iconst_0
    //   303: bipush #100
    //   305: invokevirtual substring : (II)Ljava/lang/String;
    //   308: astore #4
    //   310: ldc_w 'setted key length is over limit %d substring to %s'
    //   313: iconst_2
    //   314: anewarray java/lang/Object
    //   317: dup
    //   318: iconst_0
    //   319: bipush #100
    //   321: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   324: aastore
    //   325: dup
    //   326: iconst_1
    //   327: aload #4
    //   329: aastore
    //   330: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   333: pop
    //   334: aload #9
    //   336: invokeinterface getValue : ()Ljava/lang/Object;
    //   341: checkcast java/lang/String
    //   344: astore #7
    //   346: aload #7
    //   348: ifnull -> 592
    //   351: aload #7
    //   353: invokevirtual trim : ()Ljava/lang/String;
    //   356: invokevirtual length : ()I
    //   359: ifle -> 592
    //   362: iconst_0
    //   363: istore_3
    //   364: iload_3
    //   365: ifne -> 597
    //   368: aload #9
    //   370: invokeinterface getValue : ()Ljava/lang/Object;
    //   375: checkcast java/lang/String
    //   378: invokevirtual length : ()I
    //   381: sipush #30000
    //   384: if_icmple -> 597
    //   387: aload #9
    //   389: invokeinterface getValue : ()Ljava/lang/Object;
    //   394: checkcast java/lang/String
    //   397: aload #9
    //   399: invokeinterface getValue : ()Ljava/lang/Object;
    //   404: checkcast java/lang/String
    //   407: invokevirtual length : ()I
    //   410: sipush #30000
    //   413: isub
    //   414: invokevirtual substring : (I)Ljava/lang/String;
    //   417: astore #7
    //   419: ldc_w 'setted %s value length is over limit %d substring'
    //   422: iconst_2
    //   423: anewarray java/lang/Object
    //   426: dup
    //   427: iconst_0
    //   428: aload #4
    //   430: aastore
    //   431: dup
    //   432: iconst_1
    //   433: sipush #30000
    //   436: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   439: aastore
    //   440: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   443: pop
    //   444: aload_1
    //   445: getfield N : Ljava/util/Map;
    //   448: aload #4
    //   450: aload #7
    //   452: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   457: pop
    //   458: ldc_w 'add setted key %s value size:%d'
    //   461: iconst_2
    //   462: anewarray java/lang/Object
    //   465: dup
    //   466: iconst_0
    //   467: aload #4
    //   469: aastore
    //   470: dup
    //   471: iconst_1
    //   472: aload #7
    //   474: invokevirtual length : ()I
    //   477: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   480: aastore
    //   481: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   484: pop
    //   485: goto -> 218
    //   488: astore_1
    //   489: ldc_w 'crash handle callback somthing wrong! %s'
    //   492: iconst_1
    //   493: anewarray java/lang/Object
    //   496: dup
    //   497: iconst_0
    //   498: aload_1
    //   499: invokevirtual getClass : ()Ljava/lang/Class;
    //   502: invokevirtual getName : ()Ljava/lang/String;
    //   505: aastore
    //   506: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   509: pop
    //   510: aload_1
    //   511: invokestatic a : (Ljava/lang/Throwable;)Z
    //   514: ifne -> 4
    //   517: aload_1
    //   518: invokevirtual printStackTrace : ()V
    //   521: goto -> 4
    //   524: iconst_4
    //   525: istore_2
    //   526: goto -> 81
    //   529: iconst_1
    //   530: istore_2
    //   531: goto -> 81
    //   534: iconst_2
    //   535: istore_2
    //   536: goto -> 81
    //   539: iconst_3
    //   540: istore_2
    //   541: goto -> 81
    //   544: iconst_5
    //   545: istore_2
    //   546: goto -> 81
    //   549: bipush #6
    //   551: istore_2
    //   552: goto -> 81
    //   555: aload_0
    //   556: getfield f : Lcom/tencent/bugly/legu/BuglyStrategy$a;
    //   559: ifnull -> 166
    //   562: aload_0
    //   563: getfield f : Lcom/tencent/bugly/legu/BuglyStrategy$a;
    //   566: iload_2
    //   567: aload_1
    //   568: getfield n : Ljava/lang/String;
    //   571: aload_1
    //   572: getfield o : Ljava/lang/String;
    //   575: aload_1
    //   576: getfield q : Ljava/lang/String;
    //   579: invokevirtual onCrashHandleStart : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/util/Map;
    //   582: astore #4
    //   584: goto -> 166
    //   587: iconst_1
    //   588: istore_3
    //   589: goto -> 270
    //   592: iconst_1
    //   593: istore_3
    //   594: goto -> 364
    //   597: new java/lang/StringBuilder
    //   600: astore #7
    //   602: aload #7
    //   604: invokespecial <init> : ()V
    //   607: aload #7
    //   609: aload #9
    //   611: invokeinterface getValue : ()Ljava/lang/Object;
    //   616: checkcast java/lang/String
    //   619: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   622: invokevirtual toString : ()Ljava/lang/String;
    //   625: astore #7
    //   627: goto -> 444
    //   630: ldc_w '[crash callback] start user's callback:onCrashHandleStart2GetExtraDatas()'
    //   633: iconst_0
    //   634: anewarray java/lang/Object
    //   637: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   640: pop
    //   641: aconst_null
    //   642: astore #4
    //   644: aload_0
    //   645: getfield e : Lcom/tencent/bugly/legu/proguard/n;
    //   648: ifnull -> 742
    //   651: aload_0
    //   652: getfield e : Lcom/tencent/bugly/legu/proguard/n;
    //   655: invokeinterface a : ()[B
    //   660: astore #4
    //   662: aload_1
    //   663: aload #4
    //   665: putfield S : [B
    //   668: aload_1
    //   669: getfield S : [B
    //   672: ifnull -> 4
    //   675: aload_1
    //   676: getfield S : [B
    //   679: arraylength
    //   680: sipush #30000
    //   683: if_icmple -> 717
    //   686: ldc_w 'extra bytes size %d is over limit %d will drop over part'
    //   689: iconst_2
    //   690: anewarray java/lang/Object
    //   693: dup
    //   694: iconst_0
    //   695: aload_1
    //   696: getfield S : [B
    //   699: arraylength
    //   700: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   703: aastore
    //   704: dup
    //   705: iconst_1
    //   706: sipush #30000
    //   709: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   712: aastore
    //   713: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   716: pop
    //   717: ldc_w 'add extra bytes %d '
    //   720: iconst_1
    //   721: anewarray java/lang/Object
    //   724: dup
    //   725: iconst_0
    //   726: aload_1
    //   727: getfield S : [B
    //   730: arraylength
    //   731: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   734: aastore
    //   735: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   738: pop
    //   739: goto -> 4
    //   742: aload_0
    //   743: getfield f : Lcom/tencent/bugly/legu/BuglyStrategy$a;
    //   746: ifnull -> 662
    //   749: aload_0
    //   750: getfield f : Lcom/tencent/bugly/legu/BuglyStrategy$a;
    //   753: iload_2
    //   754: aload_1
    //   755: getfield n : Ljava/lang/String;
    //   758: aload_1
    //   759: getfield o : Ljava/lang/String;
    //   762: aload_1
    //   763: getfield q : Ljava/lang/String;
    //   766: invokevirtual onCrashHandleStart2GetExtraDatas : (ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B
    //   769: astore #4
    //   771: goto -> 662
    // Exception table:
    //   from	to	target	type
    //   19	76	488	java/lang/Throwable
    //   81	110	488	java/lang/Throwable
    //   113	137	488	java/lang/Throwable
    //   142	166	488	java/lang/Throwable
    //   171	218	488	java/lang/Throwable
    //   218	252	488	java/lang/Throwable
    //   257	268	488	java/lang/Throwable
    //   274	286	488	java/lang/Throwable
    //   290	334	488	java/lang/Throwable
    //   334	346	488	java/lang/Throwable
    //   351	362	488	java/lang/Throwable
    //   368	444	488	java/lang/Throwable
    //   444	485	488	java/lang/Throwable
    //   555	584	488	java/lang/Throwable
    //   597	627	488	java/lang/Throwable
    //   630	641	488	java/lang/Throwable
    //   644	662	488	java/lang/Throwable
    //   662	717	488	java/lang/Throwable
    //   717	739	488	java/lang/Throwable
    //   742	771	488	java/lang/Throwable
  }
  
  public final void c(CrashDetailBean paramCrashDetailBean) {
    if (paramCrashDetailBean != null) {
      ContentValues contentValues = d(paramCrashDetailBean);
      if (contentValues != null) {
        long l = o.a().a("t_cr", contentValues, null, true);
        if (l >= 0L) {
          w.c("insert %s success!", new Object[] { "t_cr" });
          paramCrashDetailBean.a = l;
        } 
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */