package com.tencent.bugly.legu.crashreport.crash;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import com.tencent.bugly.legu.crashreport.biz.b;

public class BuglyBroadcastRecevier extends BroadcastReceiver {
  public static String ACTION_PROCESS_CRASHED;
  
  public static String ACTION_PROCESS_LAUNCHED = "com.tencent.feedback.A01";
  
  public static final long UPLOADLIMITED = 60000L;
  
  private static BuglyBroadcastRecevier d;
  
  private IntentFilter a = new IntentFilter();
  
  private Context b;
  
  private String c;
  
  static {
    ACTION_PROCESS_CRASHED = "com.tencent.feedback.A02";
    d = null;
  }
  
  private boolean a(Context paramContext, Intent paramIntent) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_3
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_1
    //   5: ifnull -> 28
    //   8: aload_2
    //   9: ifnull -> 28
    //   12: aload_2
    //   13: invokevirtual getAction : ()Ljava/lang/String;
    //   16: ldc 'android.net.conn.CONNECTIVITY_CHANGE'
    //   18: invokevirtual equals : (Ljava/lang/Object;)Z
    //   21: istore #4
    //   23: iload #4
    //   25: ifne -> 36
    //   28: iconst_0
    //   29: istore #4
    //   31: aload_0
    //   32: monitorexit
    //   33: iload #4
    //   35: ireturn
    //   36: aload_0
    //   37: getfield b : Landroid/content/Context;
    //   40: invokestatic e : (Landroid/content/Context;)Ljava/lang/String;
    //   43: astore_2
    //   44: new java/lang/StringBuilder
    //   47: astore #5
    //   49: aload #5
    //   51: ldc 'is Connect BC '
    //   53: invokespecial <init> : (Ljava/lang/String;)V
    //   56: aload #5
    //   58: aload_2
    //   59: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: invokevirtual toString : ()Ljava/lang/String;
    //   65: iconst_0
    //   66: anewarray java/lang/Object
    //   69: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   72: pop
    //   73: new java/lang/StringBuilder
    //   76: astore #5
    //   78: aload #5
    //   80: invokespecial <init> : ()V
    //   83: aload #5
    //   85: aload_0
    //   86: getfield c : Ljava/lang/String;
    //   89: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   92: invokevirtual toString : ()Ljava/lang/String;
    //   95: astore #5
    //   97: new java/lang/StringBuilder
    //   100: astore #6
    //   102: aload #6
    //   104: invokespecial <init> : ()V
    //   107: ldc 'network %s changed to %s'
    //   109: iconst_2
    //   110: anewarray java/lang/Object
    //   113: dup
    //   114: iconst_0
    //   115: aload #5
    //   117: aastore
    //   118: dup
    //   119: iconst_1
    //   120: aload #6
    //   122: aload_2
    //   123: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   126: invokevirtual toString : ()Ljava/lang/String;
    //   129: aastore
    //   130: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   133: pop
    //   134: aload_2
    //   135: ifnonnull -> 154
    //   138: aload_0
    //   139: aconst_null
    //   140: putfield c : Ljava/lang/String;
    //   143: iload_3
    //   144: istore #4
    //   146: goto -> 31
    //   149: astore_1
    //   150: aload_0
    //   151: monitorexit
    //   152: aload_1
    //   153: athrow
    //   154: aload_0
    //   155: getfield c : Ljava/lang/String;
    //   158: astore #5
    //   160: aload_0
    //   161: aload_2
    //   162: putfield c : Ljava/lang/String;
    //   165: invokestatic currentTimeMillis : ()J
    //   168: lstore #7
    //   170: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   173: astore #6
    //   175: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/t;
    //   178: astore #9
    //   180: aload_1
    //   181: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   184: astore_1
    //   185: aload #6
    //   187: ifnull -> 199
    //   190: aload #9
    //   192: ifnull -> 199
    //   195: aload_1
    //   196: ifnonnull -> 215
    //   199: ldc 'not inited BC not work'
    //   201: iconst_0
    //   202: anewarray java/lang/Object
    //   205: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   208: pop
    //   209: iload_3
    //   210: istore #4
    //   212: goto -> 31
    //   215: iload_3
    //   216: istore #4
    //   218: aload_2
    //   219: aload #5
    //   221: invokevirtual equals : (Ljava/lang/Object;)Z
    //   224: ifne -> 31
    //   227: lload #7
    //   229: aload #9
    //   231: getstatic com/tencent/bugly/legu/crashreport/crash/c.a : I
    //   234: invokevirtual a : (I)J
    //   237: lsub
    //   238: ldc2_w 60000
    //   241: lcmp
    //   242: ifle -> 262
    //   245: ldc 'try to upload crash on network changed.'
    //   247: iconst_0
    //   248: anewarray java/lang/Object
    //   251: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   254: pop
    //   255: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/crash/c;
    //   258: lconst_0
    //   259: invokevirtual a : (J)V
    //   262: iload_3
    //   263: istore #4
    //   265: lload #7
    //   267: aload #9
    //   269: sipush #1001
    //   272: invokevirtual a : (I)J
    //   275: lsub
    //   276: ldc2_w 60000
    //   279: lcmp
    //   280: ifle -> 31
    //   283: ldc 'try to upload userinfo on network changed.'
    //   285: iconst_0
    //   286: anewarray java/lang/Object
    //   289: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   292: pop
    //   293: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/v;
    //   296: astore_1
    //   297: new com/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier$1
    //   300: astore_2
    //   301: aload_2
    //   302: aload_0
    //   303: invokespecial <init> : (Lcom/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier;)V
    //   306: aload_1
    //   307: aload_2
    //   308: invokevirtual b : (Ljava/lang/Runnable;)Z
    //   311: pop
    //   312: iload_3
    //   313: istore #4
    //   315: goto -> 31
    // Exception table:
    //   from	to	target	type
    //   12	23	149	finally
    //   36	134	149	finally
    //   138	143	149	finally
    //   154	185	149	finally
    //   199	209	149	finally
    //   218	262	149	finally
    //   265	312	149	finally
  }
  
  public static BuglyBroadcastRecevier getInstance() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier.d : Lcom/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier;
    //   6: ifnonnull -> 21
    //   9: new com/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier
    //   12: astore_0
    //   13: aload_0
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: putstatic com/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier.d : Lcom/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier;
    //   21: getstatic com/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier.d : Lcom/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier;
    //   24: astore_0
    //   25: ldc com/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier
    //   27: monitorexit
    //   28: aload_0
    //   29: areturn
    //   30: astore_0
    //   31: ldc com/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier
    //   33: monitorexit
    //   34: aload_0
    //   35: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	30	finally
    //   21	25	30	finally
  }
  
  public void addFilter(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Landroid/content/IntentFilter;
    //   6: aload_1
    //   7: invokevirtual hasAction : (Ljava/lang/String;)Z
    //   10: ifne -> 21
    //   13: aload_0
    //   14: getfield a : Landroid/content/IntentFilter;
    //   17: aload_1
    //   18: invokevirtual addAction : (Ljava/lang/String;)V
    //   21: ldc 'add action %s'
    //   23: iconst_1
    //   24: anewarray java/lang/Object
    //   27: dup
    //   28: iconst_0
    //   29: aload_1
    //   30: aastore
    //   31: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   34: pop
    //   35: aload_0
    //   36: monitorexit
    //   37: return
    //   38: astore_1
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_1
    //   42: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	38	finally
    //   21	35	38	finally
  }
  
  protected void finalize() throws Throwable {
    super.finalize();
    if (this.b != null)
      this.b.unregisterReceiver(this); 
  }
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    try {
      a(paramContext, paramIntent);
    } catch (Throwable throwable) {}
  }
  
  public void regist(Context paramContext, b paramb) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: ldc 'regis BC'
    //   4: iconst_0
    //   5: anewarray java/lang/Object
    //   8: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   11: pop
    //   12: aload_0
    //   13: aload_1
    //   14: putfield b : Landroid/content/Context;
    //   17: aload_1
    //   18: aload_0
    //   19: aload_0
    //   20: getfield a : Landroid/content/IntentFilter;
    //   23: invokevirtual registerReceiver : (Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    //   26: pop
    //   27: aload_0
    //   28: monitorexit
    //   29: return
    //   30: astore_1
    //   31: aload_1
    //   32: invokevirtual printStackTrace : ()V
    //   35: goto -> 27
    //   38: astore_1
    //   39: aload_0
    //   40: monitorexit
    //   41: aload_1
    //   42: athrow
    // Exception table:
    //   from	to	target	type
    //   2	27	30	java/lang/Throwable
    //   2	27	38	finally
    //   31	35	38	finally
  }
  
  public void unregist(Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: ldc 'unregis BC'
    //   4: iconst_0
    //   5: anewarray java/lang/Object
    //   8: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   11: pop
    //   12: aload_1
    //   13: aload_0
    //   14: invokevirtual unregisterReceiver : (Landroid/content/BroadcastReceiver;)V
    //   17: aload_0
    //   18: aload_1
    //   19: putfield b : Landroid/content/Context;
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: astore_1
    //   26: aload_1
    //   27: invokestatic a : (Ljava/lang/Throwable;)Z
    //   30: ifne -> 22
    //   33: aload_1
    //   34: invokevirtual printStackTrace : ()V
    //   37: goto -> 22
    //   40: astore_1
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_1
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	25	java/lang/Throwable
    //   2	22	40	finally
    //   26	37	40	finally
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/BuglyBroadcastRecevier.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */