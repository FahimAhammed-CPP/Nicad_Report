package com.tencent.bugly.legu.crashreport.crash.anr;

import android.app.ActivityManager;
import android.content.Context;
import android.os.FileObserver;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.common.strategy.StrategyBean;
import com.tencent.bugly.legu.crashreport.common.strategy.a;
import com.tencent.bugly.legu.crashreport.crash.CrashDetailBean;
import com.tencent.bugly.legu.crashreport.crash.c;
import com.tencent.bugly.legu.proguard.a;
import com.tencent.bugly.legu.proguard.v;
import com.tencent.bugly.legu.proguard.w;
import com.tencent.bugly.legu.proguard.x;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public final class b {
  private AtomicInteger a;
  
  private long b;
  
  private final Context c;
  
  private final a d;
  
  private final v e;
  
  private final a f;
  
  private final String g;
  
  private final com.tencent.bugly.legu.crashreport.crash.b h;
  
  private FileObserver i;
  
  private boolean j;
  
  public b(Context paramContext, a parama, a parama1, v paramv, com.tencent.bugly.legu.crashreport.crash.b paramb) {
    Context context;
    this.a = new AtomicInteger(0);
    this.b = -1L;
    this.j = true;
    if (paramContext == null) {
      context = paramContext;
    } else {
      Context context1 = paramContext.getApplicationContext();
      context = context1;
      if (context1 == null)
        context = paramContext; 
    } 
    this.c = context;
    this.g = paramContext.getDir("bugly", 0).getAbsolutePath();
    this.d = parama1;
    this.e = paramv;
    this.f = parama;
    this.h = paramb;
  }
  
  private static ActivityManager.ProcessErrorStateInfo a(Context paramContext, long paramLong) {
    if (10000L < 0L) {
      paramLong = 0L;
    } else {
      paramLong = 10000L;
    } 
    w.c("to find!", new Object[0]);
    ActivityManager activityManager = (ActivityManager)paramContext.getSystemService("activity");
    paramLong /= 500L;
    for (byte b1 = 0;; b1++) {
      w.c("waiting!", new Object[0]);
      List list = activityManager.getProcessesInErrorState();
      if (list != null)
        for (ActivityManager.ProcessErrorStateInfo processErrorStateInfo : list) {
          if (processErrorStateInfo.condition == 2) {
            w.c("found!", new Object[0]);
            return processErrorStateInfo;
          } 
        }  
      try {
        Thread.sleep(500L);
        if (b1 >= paramLong) {
          w.c("end!", new Object[0]);
          list = null;
          continue;
        } 
      } catch (InterruptedException interruptedException) {
        interruptedException.printStackTrace();
        if (b1 >= paramLong) {
          w.c("end!", new Object[0]);
          interruptedException = null;
          continue;
        } 
      } 
    } 
  }
  
  private CrashDetailBean a(a parama) {
    CrashDetailBean crashDetailBean = new CrashDetailBean();
    try {
      String str;
      crashDetailBean.B = a.i();
      crashDetailBean.C = a.g();
      crashDetailBean.D = a.k();
      crashDetailBean.E = this.d.o();
      crashDetailBean.F = this.d.n();
      crashDetailBean.G = this.d.p();
      crashDetailBean.w = a.a(this.c, c.d, null);
      crashDetailBean.x = x.a(true);
      crashDetailBean.b = 3;
      crashDetailBean.e = this.d.g();
      crashDetailBean.f = this.d.i;
      crashDetailBean.g = this.d.t();
      crashDetailBean.m = this.d.f();
      crashDetailBean.n = "ANR_EXCEPTION";
      crashDetailBean.o = parama.f;
      crashDetailBean.q = parama.g;
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      this();
      crashDetailBean.N = hashMap;
      crashDetailBean.N.put("BUGLY_CR_01", parama.e);
      int i = crashDetailBean.q.indexOf("\n");
      if (i > 0) {
        str = crashDetailBean.q.substring(0, i);
      } else {
        str = "GET_FAIL";
      } 
      crashDetailBean.p = str;
      crashDetailBean.r = parama.c;
      crashDetailBean.u = a.b(crashDetailBean.q.getBytes());
      crashDetailBean.y = parama.b;
      crashDetailBean.z = this.d.d;
      crashDetailBean.A = "main(1)";
      crashDetailBean.H = this.d.v();
      crashDetailBean.h = this.d.s();
      crashDetailBean.i = this.d.E();
      crashDetailBean.v = parama.d;
      crashDetailBean.K = this.d.l;
      crashDetailBean.L = this.d.a;
      crashDetailBean.M = this.d.n;
      crashDetailBean.O = this.d.B();
      crashDetailBean.P = this.d.C();
      crashDetailBean.Q = this.d.w();
      crashDetailBean.R = this.d.A();
    } catch (Throwable throwable) {}
    return crashDetailBean;
  }
  
  private boolean a(Context paramContext, String paramString, ActivityManager.ProcessErrorStateInfo paramProcessErrorStateInfo, long paramLong, Map<String, String> paramMap) {
    // Byte code:
    //   0: aload_0
    //   1: getfield f : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   4: invokevirtual c : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   7: pop
    //   8: aload_0
    //   9: getfield f : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   12: invokevirtual b : ()Z
    //   15: ifne -> 68
    //   18: ldc_w 'waiting for remote sync'
    //   21: iconst_0
    //   22: anewarray java/lang/Object
    //   25: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   28: pop
    //   29: iconst_0
    //   30: istore #7
    //   32: aload_0
    //   33: getfield f : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   36: invokevirtual b : ()Z
    //   39: ifne -> 68
    //   42: ldc2_w 500
    //   45: invokestatic sleep : (J)V
    //   48: iload #7
    //   50: sipush #500
    //   53: iadd
    //   54: istore #8
    //   56: iload #8
    //   58: istore #7
    //   60: iload #8
    //   62: sipush #5000
    //   65: if_icmplt -> 32
    //   68: new java/io/File
    //   71: dup
    //   72: aload_1
    //   73: invokevirtual getFilesDir : ()Ljava/io/File;
    //   76: new java/lang/StringBuilder
    //   79: dup
    //   80: ldc_w 'bugly/bugly_trace_'
    //   83: invokespecial <init> : (Ljava/lang/String;)V
    //   86: lload #4
    //   88: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   91: ldc_w '.txt'
    //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: invokevirtual toString : ()Ljava/lang/String;
    //   100: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   103: astore #9
    //   105: new com/tencent/bugly/legu/crashreport/crash/anr/a
    //   108: dup
    //   109: invokespecial <init> : ()V
    //   112: astore_1
    //   113: aload_1
    //   114: lload #4
    //   116: putfield c : J
    //   119: aload_1
    //   120: aload #9
    //   122: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   125: putfield d : Ljava/lang/String;
    //   128: aload_1
    //   129: aload_3
    //   130: getfield processName : Ljava/lang/String;
    //   133: putfield a : Ljava/lang/String;
    //   136: aload_1
    //   137: aload_3
    //   138: getfield shortMsg : Ljava/lang/String;
    //   141: putfield f : Ljava/lang/String;
    //   144: aload_1
    //   145: aload_3
    //   146: getfield longMsg : Ljava/lang/String;
    //   149: putfield e : Ljava/lang/String;
    //   152: aload_1
    //   153: aload #6
    //   155: putfield b : Ljava/util/Map;
    //   158: aload #6
    //   160: ifnull -> 236
    //   163: aload #6
    //   165: invokeinterface keySet : ()Ljava/util/Set;
    //   170: invokeinterface iterator : ()Ljava/util/Iterator;
    //   175: astore #9
    //   177: aload #9
    //   179: invokeinterface hasNext : ()Z
    //   184: ifeq -> 236
    //   187: aload #9
    //   189: invokeinterface next : ()Ljava/lang/Object;
    //   194: checkcast java/lang/String
    //   197: astore_3
    //   198: aload_3
    //   199: ldc_w 'main('
    //   202: invokevirtual startsWith : (Ljava/lang/String;)Z
    //   205: ifeq -> 177
    //   208: aload_1
    //   209: aload #6
    //   211: aload_3
    //   212: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   217: checkcast java/lang/String
    //   220: putfield g : Ljava/lang/String;
    //   223: goto -> 177
    //   226: astore #9
    //   228: aload #9
    //   230: invokevirtual printStackTrace : ()V
    //   233: goto -> 48
    //   236: aload_1
    //   237: getfield c : J
    //   240: lstore #4
    //   242: aload_1
    //   243: getfield d : Ljava/lang/String;
    //   246: astore #10
    //   248: aload_1
    //   249: getfield a : Ljava/lang/String;
    //   252: astore #6
    //   254: aload_1
    //   255: getfield f : Ljava/lang/String;
    //   258: astore #9
    //   260: aload_1
    //   261: getfield e : Ljava/lang/String;
    //   264: astore_3
    //   265: aload_1
    //   266: getfield b : Ljava/util/Map;
    //   269: ifnonnull -> 368
    //   272: iconst_0
    //   273: istore #7
    //   275: ldc_w 'anr tm:%d\\ntr:%s\\nproc:%s\\nsMsg:%s\\n lMsg:%s\\n threads:%d'
    //   278: bipush #6
    //   280: anewarray java/lang/Object
    //   283: dup
    //   284: iconst_0
    //   285: lload #4
    //   287: invokestatic valueOf : (J)Ljava/lang/Long;
    //   290: aastore
    //   291: dup
    //   292: iconst_1
    //   293: aload #10
    //   295: aastore
    //   296: dup
    //   297: iconst_2
    //   298: aload #6
    //   300: aastore
    //   301: dup
    //   302: iconst_3
    //   303: aload #9
    //   305: aastore
    //   306: dup
    //   307: iconst_4
    //   308: aload_3
    //   309: aastore
    //   310: dup
    //   311: iconst_5
    //   312: iload #7
    //   314: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   317: aastore
    //   318: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   321: pop
    //   322: aload_0
    //   323: getfield f : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   326: invokevirtual b : ()Z
    //   329: ifne -> 382
    //   332: ldc_w 'crash report sync remote fail, will not upload to Bugly , print local for helpful!'
    //   335: iconst_0
    //   336: anewarray java/lang/Object
    //   339: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   342: pop
    //   343: ldc_w 'ANR'
    //   346: invokestatic n : ()Ljava/lang/String;
    //   349: aload_1
    //   350: getfield a : Ljava/lang/String;
    //   353: aconst_null
    //   354: aload_1
    //   355: getfield e : Ljava/lang/String;
    //   358: aconst_null
    //   359: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Thread;Ljava/lang/String;Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   362: iconst_0
    //   363: istore #11
    //   365: iload #11
    //   367: ireturn
    //   368: aload_1
    //   369: getfield b : Ljava/util/Map;
    //   372: invokeinterface size : ()I
    //   377: istore #7
    //   379: goto -> 275
    //   382: aload_0
    //   383: getfield f : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   386: invokevirtual c : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   389: getfield g : Z
    //   392: ifne -> 412
    //   395: ldc_w 'ANR Report is closed!'
    //   398: iconst_0
    //   399: anewarray java/lang/Object
    //   402: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   405: pop
    //   406: iconst_0
    //   407: istore #11
    //   409: goto -> 365
    //   412: ldc_w 'found visiable anr , start to upload!'
    //   415: iconst_0
    //   416: anewarray java/lang/Object
    //   419: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   422: pop
    //   423: aload_0
    //   424: aload_1
    //   425: invokespecial a : (Lcom/tencent/bugly/legu/crashreport/crash/anr/a;)Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;
    //   428: astore_3
    //   429: aload_3
    //   430: ifnonnull -> 450
    //   433: ldc_w 'pack anr fail!'
    //   436: iconst_0
    //   437: anewarray java/lang/Object
    //   440: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   443: pop
    //   444: iconst_0
    //   445: istore #11
    //   447: goto -> 365
    //   450: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/crash/c;
    //   453: aload_3
    //   454: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   457: aload_3
    //   458: getfield a : J
    //   461: lconst_0
    //   462: lcmp
    //   463: iflt -> 585
    //   466: ldc_w 'backup anr record success!'
    //   469: iconst_0
    //   470: anewarray java/lang/Object
    //   473: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   476: pop
    //   477: aload_2
    //   478: ifnull -> 529
    //   481: new java/io/File
    //   484: dup
    //   485: aload_2
    //   486: invokespecial <init> : (Ljava/lang/String;)V
    //   489: invokevirtual exists : ()Z
    //   492: ifeq -> 529
    //   495: aload_0
    //   496: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   499: iconst_3
    //   500: invokevirtual set : (I)V
    //   503: aload_2
    //   504: aload_1
    //   505: getfield d : Ljava/lang/String;
    //   508: aload_1
    //   509: getfield a : Ljava/lang/String;
    //   512: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    //   515: ifeq -> 529
    //   518: ldc_w 'backup trace success'
    //   521: iconst_0
    //   522: anewarray java/lang/Object
    //   525: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   528: pop
    //   529: ldc_w 'ANR'
    //   532: invokestatic n : ()Ljava/lang/String;
    //   535: aload_1
    //   536: getfield a : Ljava/lang/String;
    //   539: aconst_null
    //   540: aload_1
    //   541: getfield e : Ljava/lang/String;
    //   544: aload_3
    //   545: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Thread;Ljava/lang/String;Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   548: aload_0
    //   549: getfield h : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   552: aload_3
    //   553: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)Z
    //   556: ifne -> 571
    //   559: aload_0
    //   560: getfield h : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   563: aload_3
    //   564: ldc2_w 5000
    //   567: iconst_1
    //   568: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;JZ)V
    //   571: aload_0
    //   572: getfield h : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   575: aload_3
    //   576: invokevirtual b : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   579: iconst_1
    //   580: istore #11
    //   582: goto -> 365
    //   585: ldc_w 'backup anr record fail!'
    //   588: iconst_0
    //   589: anewarray java/lang/Object
    //   592: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   595: pop
    //   596: goto -> 477
    // Exception table:
    //   from	to	target	type
    //   42	48	226	java/lang/InterruptedException
  }
  
  private static boolean a(String paramString1, String paramString2, String paramString3) {
    boolean bool;
    TraceFileHelper.a a1 = TraceFileHelper.readTargetDumpInfo(paramString3, paramString1, true);
    if (a1 == null || a1.d == null || a1.d.size() <= 0) {
      w.e("not found trace dump for %s", new Object[] { paramString3 });
      return false;
    } 
    File file = new File(paramString2);
    try {
      if (!file.exists()) {
        if (!file.getParentFile().exists())
          file.getParentFile().mkdirs(); 
        file.createNewFile();
      } 
      if (!file.exists() || !file.canWrite()) {
        w.e("backup file create fail %s", new Object[] { paramString2 });
        return false;
      } 
    } catch (Exception exception) {
      if (!w.a(exception))
        exception.printStackTrace(); 
      w.e("backup file create error! %s  %s", new Object[] { exception.getClass().getName() + ":" + exception.getMessage(), paramString2 });
      return false;
    } 
    paramString1 = null;
    try {
      BufferedWriter bufferedWriter = new BufferedWriter();
      FileWriter fileWriter = new FileWriter();
      this(file, false);
    } catch (IOException iOException) {
    
    } finally {
      paramString2 = null;
      if (paramString2 != null)
        try {
          paramString2.close();
        } catch (IOException iOException) {} 
    } 
    return bool;
  }
  
  private void b(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iload_1
    //   3: ifeq -> 13
    //   6: aload_0
    //   7: invokespecial c : ()V
    //   10: aload_0
    //   11: monitorexit
    //   12: return
    //   13: aload_0
    //   14: invokespecial d : ()V
    //   17: goto -> 10
    //   20: astore_2
    //   21: aload_0
    //   22: monitorexit
    //   23: aload_2
    //   24: athrow
    // Exception table:
    //   from	to	target	type
    //   6	10	20	finally
    //   13	17	20	finally
  }
  
  private void c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial e : ()Z
    //   6: ifeq -> 23
    //   9: ldc_w 'start when started!'
    //   12: iconst_0
    //   13: anewarray java/lang/Object
    //   16: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   19: pop
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: new com/tencent/bugly/legu/crashreport/crash/anr/b$1
    //   26: astore_1
    //   27: aload_1
    //   28: aload_0
    //   29: ldc_w '/data/anr/'
    //   32: bipush #8
    //   34: invokespecial <init> : (Lcom/tencent/bugly/legu/crashreport/crash/anr/b;Ljava/lang/String;I)V
    //   37: aload_0
    //   38: aload_1
    //   39: putfield i : Landroid/os/FileObserver;
    //   42: aload_0
    //   43: getfield i : Landroid/os/FileObserver;
    //   46: invokevirtual startWatching : ()V
    //   49: ldc_w 'start anr monitor!'
    //   52: iconst_0
    //   53: anewarray java/lang/Object
    //   56: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   59: pop
    //   60: aload_0
    //   61: getfield e : Lcom/tencent/bugly/legu/proguard/v;
    //   64: astore_1
    //   65: new com/tencent/bugly/legu/crashreport/crash/anr/b$2
    //   68: astore_2
    //   69: aload_2
    //   70: aload_0
    //   71: invokespecial <init> : (Lcom/tencent/bugly/legu/crashreport/crash/anr/b;)V
    //   74: aload_1
    //   75: aload_2
    //   76: invokevirtual b : (Ljava/lang/Runnable;)Z
    //   79: pop
    //   80: goto -> 20
    //   83: astore_1
    //   84: aload_0
    //   85: aconst_null
    //   86: putfield i : Landroid/os/FileObserver;
    //   89: ldc_w 'start anr monitor failed!'
    //   92: iconst_0
    //   93: anewarray java/lang/Object
    //   96: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   99: pop
    //   100: aload_1
    //   101: invokestatic a : (Ljava/lang/Throwable;)Z
    //   104: ifne -> 20
    //   107: aload_1
    //   108: invokevirtual printStackTrace : ()V
    //   111: goto -> 20
    //   114: astore_1
    //   115: aload_0
    //   116: monitorexit
    //   117: aload_1
    //   118: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	114	finally
    //   23	42	114	finally
    //   42	80	83	java/lang/Throwable
    //   42	80	114	finally
    //   84	111	114	finally
  }
  
  private void c(boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield j : Z
    //   6: iload_1
    //   7: if_icmpeq -> 33
    //   10: ldc_w 'user change anr %b'
    //   13: iconst_1
    //   14: anewarray java/lang/Object
    //   17: dup
    //   18: iconst_0
    //   19: iload_1
    //   20: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   23: aastore
    //   24: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   27: pop
    //   28: aload_0
    //   29: iload_1
    //   30: putfield j : Z
    //   33: aload_0
    //   34: monitorexit
    //   35: return
    //   36: astore_2
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_2
    //   40: athrow
    // Exception table:
    //   from	to	target	type
    //   2	33	36	finally
  }
  
  private void d() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial e : ()Z
    //   6: ifne -> 23
    //   9: ldc_w 'close when closed!'
    //   12: iconst_0
    //   13: anewarray java/lang/Object
    //   16: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   19: pop
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: aload_0
    //   24: getfield i : Landroid/os/FileObserver;
    //   27: invokevirtual stopWatching : ()V
    //   30: aload_0
    //   31: aconst_null
    //   32: putfield i : Landroid/os/FileObserver;
    //   35: ldc_w 'close anr monitor!'
    //   38: iconst_0
    //   39: anewarray java/lang/Object
    //   42: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   45: pop
    //   46: goto -> 20
    //   49: astore_1
    //   50: ldc_w 'stop anr monitor failed!'
    //   53: iconst_0
    //   54: anewarray java/lang/Object
    //   57: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   60: pop
    //   61: aload_1
    //   62: invokestatic a : (Ljava/lang/Throwable;)Z
    //   65: ifne -> 20
    //   68: aload_1
    //   69: invokevirtual printStackTrace : ()V
    //   72: goto -> 20
    //   75: astore_1
    //   76: aload_0
    //   77: monitorexit
    //   78: aload_1
    //   79: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	75	finally
    //   23	46	49	java/lang/Throwable
    //   23	46	75	finally
    //   50	72	75	finally
  }
  
  private boolean e() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield i : Landroid/os/FileObserver;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnull -> 17
    //   11: iconst_1
    //   12: istore_2
    //   13: aload_0
    //   14: monitorexit
    //   15: iload_2
    //   16: ireturn
    //   17: iconst_0
    //   18: istore_2
    //   19: goto -> 13
    //   22: astore_1
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_1
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	22	finally
  }
  
  private boolean f() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield j : Z
    //   6: istore_1
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_1
    //   10: ireturn
    //   11: astore_2
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_2
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final void a(StrategyBean paramStrategyBean) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_1
    //   5: ifnull -> 40
    //   8: aload_1
    //   9: getfield g : Z
    //   12: aload_0
    //   13: invokespecial e : ()Z
    //   16: if_icmpeq -> 40
    //   19: ldc_w 'server anr changed to %b'
    //   22: iconst_1
    //   23: anewarray java/lang/Object
    //   26: dup
    //   27: iconst_0
    //   28: aload_1
    //   29: getfield g : Z
    //   32: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   35: aastore
    //   36: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   39: pop
    //   40: aload_1
    //   41: getfield g : Z
    //   44: ifeq -> 88
    //   47: aload_0
    //   48: invokespecial f : ()Z
    //   51: ifeq -> 88
    //   54: iload_2
    //   55: aload_0
    //   56: invokespecial e : ()Z
    //   59: if_icmpeq -> 85
    //   62: ldc_w 'anr changed to %b'
    //   65: iconst_1
    //   66: anewarray java/lang/Object
    //   69: dup
    //   70: iconst_0
    //   71: iload_2
    //   72: invokestatic valueOf : (Z)Ljava/lang/Boolean;
    //   75: aastore
    //   76: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   79: pop
    //   80: aload_0
    //   81: iload_2
    //   82: invokespecial b : (Z)V
    //   85: aload_0
    //   86: monitorexit
    //   87: return
    //   88: iconst_0
    //   89: istore_2
    //   90: goto -> 54
    //   93: astore_1
    //   94: aload_0
    //   95: monitorexit
    //   96: aload_1
    //   97: athrow
    // Exception table:
    //   from	to	target	type
    //   8	40	93	finally
    //   40	54	93	finally
    //   54	85	93	finally
  }
  
  public final void a(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   6: invokevirtual get : ()I
    //   9: ifeq -> 26
    //   12: ldc_w 'trace started return '
    //   15: iconst_0
    //   16: anewarray java/lang/Object
    //   19: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   22: pop
    //   23: aload_0
    //   24: monitorexit
    //   25: return
    //   26: aload_0
    //   27: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   30: iconst_1
    //   31: invokevirtual set : (I)V
    //   34: aload_0
    //   35: monitorexit
    //   36: ldc_w 'read trace first dump for create time!'
    //   39: iconst_0
    //   40: anewarray java/lang/Object
    //   43: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   46: pop
    //   47: aload_1
    //   48: iconst_0
    //   49: invokestatic readFirstDumpInfo : (Ljava/lang/String;Z)Lcom/tencent/bugly/legu/crashreport/crash/anr/TraceFileHelper$a;
    //   52: astore_2
    //   53: aload_2
    //   54: ifnull -> 399
    //   57: aload_2
    //   58: getfield c : J
    //   61: lstore_3
    //   62: lload_3
    //   63: lstore #5
    //   65: lload_3
    //   66: ldc2_w -1
    //   69: lcmp
    //   70: ifne -> 89
    //   73: ldc_w 'trace dump fail could not get time!'
    //   76: iconst_0
    //   77: anewarray java/lang/Object
    //   80: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   83: pop
    //   84: invokestatic currentTimeMillis : ()J
    //   87: lstore #5
    //   89: lload #5
    //   91: aload_0
    //   92: getfield b : J
    //   95: lsub
    //   96: invokestatic abs : (J)J
    //   99: ldc2_w 10000
    //   102: lcmp
    //   103: ifge -> 142
    //   106: ldc_w 'should not process ANR too Fre in %d'
    //   109: iconst_1
    //   110: anewarray java/lang/Object
    //   113: dup
    //   114: iconst_0
    //   115: sipush #10000
    //   118: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   121: aastore
    //   122: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   125: pop
    //   126: aload_0
    //   127: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   130: iconst_0
    //   131: invokevirtual set : (I)V
    //   134: goto -> 25
    //   137: astore_1
    //   138: aload_0
    //   139: monitorexit
    //   140: aload_1
    //   141: athrow
    //   142: aload_0
    //   143: lload #5
    //   145: putfield b : J
    //   148: aload_0
    //   149: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   152: iconst_1
    //   153: invokevirtual set : (I)V
    //   156: getstatic com/tencent/bugly/legu/crashreport/crash/c.e : I
    //   159: iconst_0
    //   160: invokestatic a : (IZ)Ljava/util/Map;
    //   163: astore_2
    //   164: aload_2
    //   165: ifnull -> 177
    //   168: aload_2
    //   169: invokeinterface size : ()I
    //   174: ifgt -> 227
    //   177: ldc_w 'can't get all thread skip this anr'
    //   180: iconst_0
    //   181: anewarray java/lang/Object
    //   184: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   187: pop
    //   188: aload_0
    //   189: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   192: iconst_0
    //   193: invokevirtual set : (I)V
    //   196: goto -> 25
    //   199: astore_1
    //   200: aload_1
    //   201: invokestatic a : (Ljava/lang/Throwable;)Z
    //   204: pop
    //   205: ldc_w 'get all thread stack fail!'
    //   208: iconst_0
    //   209: anewarray java/lang/Object
    //   212: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   215: pop
    //   216: aload_0
    //   217: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   220: iconst_0
    //   221: invokevirtual set : (I)V
    //   224: goto -> 25
    //   227: aload_0
    //   228: getfield c : Landroid/content/Context;
    //   231: ldc2_w 10000
    //   234: invokestatic a : (Landroid/content/Context;J)Landroid/app/ActivityManager$ProcessErrorStateInfo;
    //   237: astore #7
    //   239: aload #7
    //   241: ifnonnull -> 266
    //   244: ldc_w 'proc state is unvisiable!'
    //   247: iconst_0
    //   248: anewarray java/lang/Object
    //   251: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   254: pop
    //   255: aload_0
    //   256: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   259: iconst_0
    //   260: invokevirtual set : (I)V
    //   263: goto -> 25
    //   266: aload #7
    //   268: getfield pid : I
    //   271: invokestatic myPid : ()I
    //   274: if_icmpeq -> 307
    //   277: ldc_w 'not mind proc!'
    //   280: iconst_1
    //   281: anewarray java/lang/Object
    //   284: dup
    //   285: iconst_0
    //   286: aload #7
    //   288: getfield processName : Ljava/lang/String;
    //   291: aastore
    //   292: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   295: pop
    //   296: aload_0
    //   297: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   300: iconst_0
    //   301: invokevirtual set : (I)V
    //   304: goto -> 25
    //   307: ldc_w 'found visiable anr , start to process!'
    //   310: iconst_0
    //   311: anewarray java/lang/Object
    //   314: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   317: pop
    //   318: aload_0
    //   319: aload_0
    //   320: getfield c : Landroid/content/Context;
    //   323: aload_1
    //   324: aload #7
    //   326: lload #5
    //   328: aload_2
    //   329: invokespecial a : (Landroid/content/Context;Ljava/lang/String;Landroid/app/ActivityManager$ProcessErrorStateInfo;JLjava/util/Map;)Z
    //   332: pop
    //   333: aload_0
    //   334: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   337: iconst_0
    //   338: invokevirtual set : (I)V
    //   341: goto -> 25
    //   344: astore_1
    //   345: aload_1
    //   346: invokestatic a : (Ljava/lang/Throwable;)Z
    //   349: ifne -> 356
    //   352: aload_1
    //   353: invokevirtual printStackTrace : ()V
    //   356: ldc_w 'handle anr error %s'
    //   359: iconst_1
    //   360: anewarray java/lang/Object
    //   363: dup
    //   364: iconst_0
    //   365: aload_1
    //   366: invokevirtual getClass : ()Ljava/lang/Class;
    //   369: invokevirtual toString : ()Ljava/lang/String;
    //   372: aastore
    //   373: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   376: pop
    //   377: aload_0
    //   378: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   381: iconst_0
    //   382: invokevirtual set : (I)V
    //   385: goto -> 25
    //   388: astore_1
    //   389: aload_0
    //   390: getfield a : Ljava/util/concurrent/atomic/AtomicInteger;
    //   393: iconst_0
    //   394: invokevirtual set : (I)V
    //   397: aload_1
    //   398: athrow
    //   399: ldc2_w -1
    //   402: lstore_3
    //   403: goto -> 62
    // Exception table:
    //   from	to	target	type
    //   2	25	137	finally
    //   26	36	137	finally
    //   36	53	344	java/lang/Throwable
    //   36	53	388	finally
    //   57	62	344	java/lang/Throwable
    //   57	62	388	finally
    //   73	89	344	java/lang/Throwable
    //   73	89	388	finally
    //   89	126	344	java/lang/Throwable
    //   89	126	388	finally
    //   142	156	344	java/lang/Throwable
    //   142	156	388	finally
    //   156	164	199	java/lang/Throwable
    //   156	164	388	finally
    //   168	177	344	java/lang/Throwable
    //   168	177	388	finally
    //   177	188	344	java/lang/Throwable
    //   177	188	388	finally
    //   200	216	344	java/lang/Throwable
    //   200	216	388	finally
    //   227	239	344	java/lang/Throwable
    //   227	239	388	finally
    //   244	255	344	java/lang/Throwable
    //   244	255	388	finally
    //   266	296	344	java/lang/Throwable
    //   266	296	388	finally
    //   307	333	344	java/lang/Throwable
    //   307	333	388	finally
    //   345	356	388	finally
    //   356	377	388	finally
  }
  
  public final void a(boolean paramBoolean) {
    c(paramBoolean);
    if ((a.a().c()).g && f()) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    if (paramBoolean != e()) {
      w.a("anr changed to %b", new Object[] { Boolean.valueOf(paramBoolean) });
      b(paramBoolean);
    } 
  }
  
  public final boolean a() {
    return (this.a.get() != 0);
  }
  
  protected final void b() {
    long l1 = a.o();
    long l2 = c.f;
    File file = new File(this.g);
    if (file.exists() && file.isDirectory()) {
      File[] arrayOfFile = file.listFiles();
      if (arrayOfFile != null && arrayOfFile.length != 0) {
        Object object;
        int i = "bugly_trace_".length();
        int j = arrayOfFile.length;
        byte b1 = 0;
        boolean bool = false;
        while (b1 < j) {
          file = arrayOfFile[b1];
          String str = file.getName();
          Object object1 = object;
          if (str.startsWith("bugly_trace_")) {
            try {
              int k = str.indexOf(".txt");
              if (k > 0) {
                long l = Long.parseLong(str.substring(i, k));
                if (l >= l1 - l2) {
                  Object object2 = object;
                  continue;
                } 
              } 
            } catch (Throwable throwable) {
              w.e("tomb format error delete %s", new Object[] { str });
            } 
            object1 = object;
            if (file.delete())
              int k = object + 1; 
          } 
          continue;
          b1++;
          object = SYNTHETIC_LOCAL_VARIABLE_12;
        } 
        w.c("clean tombs %d", new Object[] { Integer.valueOf(object) });
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/anr/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */