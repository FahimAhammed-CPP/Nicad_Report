package com.tencent.bugly.legu.crashreport.crash;

import android.content.Context;
import com.tencent.bugly.legu.BuglyStrategy;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.common.strategy.StrategyBean;
import com.tencent.bugly.legu.crashreport.common.strategy.a;
import com.tencent.bugly.legu.crashreport.crash.anr.b;
import com.tencent.bugly.legu.crashreport.crash.jni.NativeCrashHandler;
import com.tencent.bugly.legu.proguard.a;
import com.tencent.bugly.legu.proguard.n;
import com.tencent.bugly.legu.proguard.o;
import com.tencent.bugly.legu.proguard.q;
import com.tencent.bugly.legu.proguard.t;
import com.tencent.bugly.legu.proguard.v;
import com.tencent.bugly.legu.proguard.w;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class c {
  public static int a = 0;
  
  public static boolean b = false;
  
  public static boolean c = true;
  
  public static int d = 20000;
  
  public static int e = 20000;
  
  public static long f = 604800000L;
  
  public static String g = null;
  
  public static boolean h = false;
  
  public static String i = null;
  
  public static int j = 5000;
  
  private static c n;
  
  public final b k;
  
  public BuglyStrategy.a l;
  
  private final Context m;
  
  private final e o;
  
  private final NativeCrashHandler p;
  
  private a q;
  
  private v r;
  
  private final b s;
  
  private Boolean t;
  
  private c(int paramInt, Context paramContext, v paramv, boolean paramBoolean, BuglyStrategy.a parama, n paramn, String paramString) {
    Context context;
    a = paramInt;
    if (paramContext == null) {
      context = paramContext;
    } else {
      Context context1 = paramContext.getApplicationContext();
      context = context1;
      if (context1 == null)
        context = paramContext; 
    } 
    this.m = context;
    this.q = a.a();
    t t = t.a();
    o o = o.a();
    a a1 = a.a(context);
    this.r = paramv;
    this.l = parama;
    this.k = new b(paramInt, context, t, o, this.q, parama, paramn);
    this.o = new e(context, this.k, this.q, a1);
    this.p = NativeCrashHandler.getInstance(context, a1, this.k, this.q, paramv, paramBoolean, paramString);
    this.s = new b(context, this.q, a1, paramv, this.k);
    BuglyBroadcastRecevier buglyBroadcastRecevier = BuglyBroadcastRecevier.getInstance();
    buglyBroadcastRecevier.addFilter("android.net.conn.CONNECTIVITY_CHANGE");
    buglyBroadcastRecevier.regist(context, this.k);
  }
  
  public static c a() {
    return n;
  }
  
  public static void a(int paramInt, Context paramContext, boolean paramBoolean, BuglyStrategy.a parama, n paramn, String paramString) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/crash/c
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/crashreport/crash/c.n : Lcom/tencent/bugly/legu/crashreport/crash/c;
    //   6: ifnonnull -> 35
    //   9: new com/tencent/bugly/legu/crashreport/crash/c
    //   12: astore #4
    //   14: aload #4
    //   16: sipush #1004
    //   19: aload_1
    //   20: invokestatic a : ()Lcom/tencent/bugly/legu/proguard/v;
    //   23: iload_2
    //   24: aload_3
    //   25: aconst_null
    //   26: aconst_null
    //   27: invokespecial <init> : (ILandroid/content/Context;Lcom/tencent/bugly/legu/proguard/v;ZLcom/tencent/bugly/legu/BuglyStrategy$a;Lcom/tencent/bugly/legu/proguard/n;Ljava/lang/String;)V
    //   30: aload #4
    //   32: putstatic com/tencent/bugly/legu/crashreport/crash/c.n : Lcom/tencent/bugly/legu/crashreport/crash/c;
    //   35: ldc com/tencent/bugly/legu/crashreport/crash/c
    //   37: monitorexit
    //   38: return
    //   39: astore_1
    //   40: ldc com/tencent/bugly/legu/crashreport/crash/c
    //   42: monitorexit
    //   43: aload_1
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   3	35	39	finally
  }
  
  public final void a(long paramLong) {
    v.a().a(new Thread(this) {
          public final void run() {
            if (a.a(c.b(this.a), "local_crash_lock", 10000L)) {
              List<CrashDetailBean> list = this.a.k.a();
              if (list != null && list.size() > 0) {
                List<CrashDetailBean> list1;
                int i = list.size();
                if (i > 100L) {
                  ArrayList arrayList = new ArrayList();
                  Collections.sort(list);
                  byte b = 0;
                  while (true) {
                    list1 = arrayList;
                    if (b < 100L) {
                      arrayList.add(list.get(i - 1 - b));
                      b++;
                      continue;
                    } 
                    break;
                  } 
                } else {
                  list1 = list;
                } 
                this.a.k.a(list1, 0L, false);
              } 
              a.b(c.b(this.a), "local_crash_lock");
            } 
          }
        }paramLong);
  }
  
  public final void a(StrategyBean paramStrategyBean) {
    this.o.a(paramStrategyBean);
    this.p.onStrategyChanged(paramStrategyBean);
    this.s.a(paramStrategyBean);
  }
  
  public final void a(CrashDetailBean paramCrashDetailBean) {
    this.k.c(paramCrashDetailBean);
  }
  
  public final void a(Thread paramThread, Throwable paramThrowable, boolean paramBoolean, String paramString, byte[] paramArrayOfbyte) {
    this.r.b(new Runnable(this, false, paramThread, paramThrowable, null, null) {
          public final void run() {
            try {
              w.c("post a throwable %b", new Object[] { Boolean.valueOf(this.a) });
              c.a(this.f).a(this.b, this.c, false, this.d, this.e);
            } catch (Throwable throwable) {}
          }
        });
  }
  
  public final boolean b() {
    boolean bool = false;
    Boolean bool1 = this.t;
    if (bool1 != null)
      return bool1.booleanValue(); 
    String str = (a.a()).d;
    List list = o.a().a(1);
    ArrayList<q> arrayList = new ArrayList();
    if (list != null && list.size() > 0) {
      for (q q : list) {
        if (str.equals(q.c)) {
          this.t = Boolean.valueOf(true);
          arrayList.add(q);
        } 
      } 
      if (arrayList.size() > 0) {
        o.a();
        o.a(arrayList);
      } 
      return true;
    } 
    this.t = Boolean.valueOf(false);
    return bool;
  }
  
  public final void c() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield o : Lcom/tencent/bugly/legu/crashreport/crash/e;
    //   6: invokevirtual a : ()V
    //   9: aload_0
    //   10: getfield p : Lcom/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler;
    //   13: iconst_1
    //   14: invokevirtual setUserOpened : (Z)V
    //   17: aload_0
    //   18: getfield s : Lcom/tencent/bugly/legu/crashreport/crash/anr/b;
    //   21: iconst_1
    //   22: invokevirtual a : (Z)V
    //   25: aload_0
    //   26: monitorexit
    //   27: return
    //   28: astore_1
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_1
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   2	25	28	finally
  }
  
  public final void d() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield o : Lcom/tencent/bugly/legu/crashreport/crash/e;
    //   6: invokevirtual b : ()V
    //   9: aload_0
    //   10: getfield p : Lcom/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler;
    //   13: iconst_0
    //   14: invokevirtual setUserOpened : (Z)V
    //   17: aload_0
    //   18: getfield s : Lcom/tencent/bugly/legu/crashreport/crash/anr/b;
    //   21: iconst_0
    //   22: invokevirtual a : (Z)V
    //   25: aload_0
    //   26: monitorexit
    //   27: return
    //   28: astore_1
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_1
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   2	25	28	finally
  }
  
  public final void e() {
    this.o.a();
  }
  
  public final void f() {
    this.p.setUserOpened(false);
  }
  
  public final void g() {
    this.p.setUserOpened(true);
  }
  
  public final void h() {
    this.s.a(true);
  }
  
  public final void i() {
    this.s.a(false);
  }
  
  public final void j() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield p : Lcom/tencent/bugly/legu/crashreport/crash/jni/NativeCrashHandler;
    //   6: invokevirtual testNativeCrash : ()V
    //   9: aload_0
    //   10: monitorexit
    //   11: return
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   2	9	12	finally
  }
  
  public final void k() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield s : Lcom/tencent/bugly/legu/crashreport/crash/anr/b;
    //   8: astore_2
    //   9: iload_1
    //   10: iconst_1
    //   11: iadd
    //   12: istore_3
    //   13: iload_1
    //   14: bipush #30
    //   16: if_icmpge -> 70
    //   19: ldc_w 'try main sleep for make a test anr! try:%d/30 , kill it if you don't want to wait!'
    //   22: iconst_1
    //   23: anewarray java/lang/Object
    //   26: dup
    //   27: iconst_0
    //   28: iload_3
    //   29: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   32: aastore
    //   33: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   36: pop
    //   37: ldc2_w 5000
    //   40: invokestatic sleep : (J)V
    //   43: iload_3
    //   44: istore_1
    //   45: goto -> 9
    //   48: astore_2
    //   49: aload_2
    //   50: invokevirtual printStackTrace : ()V
    //   53: iload_3
    //   54: istore_1
    //   55: goto -> 9
    //   58: astore_2
    //   59: aload_2
    //   60: invokestatic a : (Ljava/lang/Throwable;)Z
    //   63: ifne -> 70
    //   66: aload_2
    //   67: invokevirtual printStackTrace : ()V
    //   70: aload_0
    //   71: monitorexit
    //   72: return
    //   73: astore_2
    //   74: aload_0
    //   75: monitorexit
    //   76: aload_2
    //   77: athrow
    // Exception table:
    //   from	to	target	type
    //   4	9	73	finally
    //   19	37	58	java/lang/Throwable
    //   19	37	73	finally
    //   37	43	48	java/lang/InterruptedException
    //   37	43	58	java/lang/Throwable
    //   37	43	73	finally
    //   49	53	58	java/lang/Throwable
    //   49	53	73	finally
    //   59	70	73	finally
  }
  
  public final boolean l() {
    return this.s.a();
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */