package com.tencent.bugly.legu.crashreport.crash.jni;

import android.content.Context;
import com.tencent.bugly.legu.crashreport.crash.CrashDetailBean;
import com.tencent.bugly.legu.crashreport.crash.b;
import com.tencent.bugly.legu.crashreport.crash.c;
import com.tencent.bugly.legu.proguard.w;
import com.tencent.bugly.legu.proguard.x;
import java.util.Map;

public final class a implements NativeExceptionHandler {
  private final Context a;
  
  private final b b;
  
  private final com.tencent.bugly.legu.crashreport.common.info.a c;
  
  private final com.tencent.bugly.legu.crashreport.common.strategy.a d;
  
  private final String e;
  
  public a(Context paramContext, com.tencent.bugly.legu.crashreport.common.info.a parama, b paramb, com.tencent.bugly.legu.crashreport.common.strategy.a parama1, String paramString) {
    this.a = paramContext;
    this.b = paramb;
    this.c = parama;
    this.d = parama1;
    this.e = paramString;
  }
  
  public final void handleNativeException(int paramInt1, int paramInt2, long paramLong1, long paramLong2, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt3, String paramString5, int paramInt4, int paramInt5, int paramInt6, String paramString6, String paramString7) {
    w.a("Native Crash Happen v1", new Object[0]);
    handleNativeException2(paramInt1, paramInt2, paramLong1, paramLong2, paramString1, paramString2, paramString3, paramString4, paramInt3, paramString5, paramInt4, paramInt5, paramInt6, paramString6, paramString7, null);
  }
  
  public final void handleNativeException2(int paramInt1, int paramInt2, long paramLong1, long paramLong2, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt3, String paramString5, int paramInt4, int paramInt5, int paramInt6, String paramString6, String paramString7, String[] paramArrayOfString) {
    // Byte code:
    //   0: ldc 'Native Crash Happen v2'
    //   2: iconst_0
    //   3: anewarray java/lang/Object
    //   6: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   9: pop
    //   10: aload_0
    //   11: getfield d : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   14: invokevirtual c : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   17: pop
    //   18: aload_0
    //   19: getfield d : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   22: invokevirtual b : ()Z
    //   25: ifne -> 75
    //   28: ldc 'waiting for remote sync'
    //   30: iconst_0
    //   31: anewarray java/lang/Object
    //   34: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   37: pop
    //   38: iconst_0
    //   39: istore_1
    //   40: aload_0
    //   41: getfield d : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   44: invokevirtual b : ()Z
    //   47: istore #19
    //   49: iload #19
    //   51: ifne -> 75
    //   54: ldc2_w 500
    //   57: invokestatic sleep : (J)V
    //   60: iload_1
    //   61: sipush #500
    //   64: iadd
    //   65: istore_2
    //   66: iload_2
    //   67: istore_1
    //   68: iload_2
    //   69: sipush #5000
    //   72: if_icmplt -> 40
    //   75: lload #5
    //   77: ldc2_w 1000
    //   80: ldiv
    //   81: lstore #5
    //   83: aload #9
    //   85: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   88: astore #20
    //   90: new java/lang/StringBuilder
    //   93: astore #9
    //   95: aload #9
    //   97: ldc 'UNKNOWN('
    //   99: invokespecial <init> : (Ljava/lang/String;)V
    //   102: aload #9
    //   104: iload #13
    //   106: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   109: ldc ')'
    //   111: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   114: invokevirtual toString : ()Ljava/lang/String;
    //   117: astore #21
    //   119: iload #11
    //   121: ifle -> 365
    //   124: new java/lang/StringBuilder
    //   127: astore #9
    //   129: aload #9
    //   131: invokespecial <init> : ()V
    //   134: aload #9
    //   136: aload #7
    //   138: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   141: ldc '('
    //   143: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: aload #12
    //   148: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: ldc ')'
    //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: invokevirtual toString : ()Ljava/lang/String;
    //   159: astore #7
    //   161: ldc 'KERNEL'
    //   163: astore #9
    //   165: aload_0
    //   166: getfield d : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   169: invokevirtual b : ()Z
    //   172: ifne -> 185
    //   175: ldc 'no remote but still store!'
    //   177: iconst_0
    //   178: anewarray java/lang/Object
    //   181: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   184: pop
    //   185: aload_0
    //   186: getfield d : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   189: invokevirtual c : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   192: getfield d : Z
    //   195: ifne -> 390
    //   198: aload_0
    //   199: getfield d : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   202: invokevirtual b : ()Z
    //   205: ifeq -> 390
    //   208: ldc 'crash report was closed by remote , will not upload to Bugly , print local for helpful!'
    //   210: iconst_0
    //   211: anewarray java/lang/Object
    //   214: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   217: pop
    //   218: invokestatic n : ()Ljava/lang/String;
    //   221: astore #9
    //   223: aload_0
    //   224: getfield c : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   227: getfield d : Ljava/lang/String;
    //   230: astore #17
    //   232: invokestatic currentThread : ()Ljava/lang/Thread;
    //   235: astore #12
    //   237: new java/lang/StringBuilder
    //   240: astore #16
    //   242: aload #16
    //   244: invokespecial <init> : ()V
    //   247: ldc 'NATIVE_CRASH'
    //   249: aload #9
    //   251: aload #17
    //   253: aload #12
    //   255: aload #16
    //   257: aload #7
    //   259: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   262: ldc '\\n'
    //   264: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   267: aload #8
    //   269: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   272: ldc '\\n'
    //   274: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   277: aload #20
    //   279: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   282: invokevirtual toString : ()Ljava/lang/String;
    //   285: aconst_null
    //   286: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Thread;Ljava/lang/String;Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   289: aload #10
    //   291: ifnull -> 336
    //   294: new java/io/File
    //   297: astore #7
    //   299: aload #7
    //   301: aload #10
    //   303: invokespecial <init> : (Ljava/lang/String;)V
    //   306: aload #7
    //   308: invokevirtual isFile : ()Z
    //   311: ifeq -> 336
    //   314: aload #7
    //   316: invokevirtual exists : ()Z
    //   319: ifeq -> 336
    //   322: aload #7
    //   324: invokevirtual canWrite : ()Z
    //   327: ifeq -> 336
    //   330: aload #7
    //   332: invokevirtual delete : ()Z
    //   335: pop
    //   336: return
    //   337: astore #16
    //   339: aload #16
    //   341: invokevirtual printStackTrace : ()V
    //   344: goto -> 60
    //   347: astore #7
    //   349: aload #7
    //   351: invokestatic a : (Ljava/lang/Throwable;)Z
    //   354: ifne -> 336
    //   357: aload #7
    //   359: invokevirtual printStackTrace : ()V
    //   362: goto -> 336
    //   365: iload #13
    //   367: ifle -> 904
    //   370: aload_0
    //   371: getfield a : Landroid/content/Context;
    //   374: astore #9
    //   376: iload #13
    //   378: invokestatic a : (I)Ljava/lang/String;
    //   381: astore #21
    //   383: aload #12
    //   385: astore #9
    //   387: goto -> 165
    //   390: aconst_null
    //   391: astore #16
    //   393: aconst_null
    //   394: astore #12
    //   396: aload #18
    //   398: ifnull -> 648
    //   401: new java/util/HashMap
    //   404: astore #12
    //   406: aload #12
    //   408: invokespecial <init> : ()V
    //   411: aload #18
    //   413: arraylength
    //   414: istore_2
    //   415: iconst_0
    //   416: istore_1
    //   417: iload_1
    //   418: iload_2
    //   419: if_icmpge -> 484
    //   422: aload #18
    //   424: iload_1
    //   425: aaload
    //   426: astore #22
    //   428: aload #22
    //   430: ldc '='
    //   432: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   435: astore #16
    //   437: aload #16
    //   439: arraylength
    //   440: iconst_2
    //   441: if_icmpne -> 466
    //   444: aload #12
    //   446: aload #16
    //   448: iconst_0
    //   449: aaload
    //   450: aload #16
    //   452: iconst_1
    //   453: aaload
    //   454: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   459: pop
    //   460: iinc #1, 1
    //   463: goto -> 417
    //   466: ldc 'bad extraMsg %s'
    //   468: iconst_1
    //   469: anewarray java/lang/Object
    //   472: dup
    //   473: iconst_0
    //   474: aload #22
    //   476: aastore
    //   477: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   480: pop
    //   481: goto -> 460
    //   484: aload #12
    //   486: ldc 'ExceptionProcessName'
    //   488: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   493: checkcast java/lang/String
    //   496: astore #16
    //   498: aload #12
    //   500: ldc 'ExceptionThreadName'
    //   502: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   507: checkcast java/lang/String
    //   510: astore #12
    //   512: aload #16
    //   514: ifnull -> 525
    //   517: aload #16
    //   519: invokevirtual length : ()I
    //   522: ifne -> 661
    //   525: aload_0
    //   526: getfield c : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   529: getfield d : Ljava/lang/String;
    //   532: astore #18
    //   534: aload #12
    //   536: ifnull -> 547
    //   539: aload #12
    //   541: invokevirtual length : ()I
    //   544: ifne -> 683
    //   547: invokestatic currentThread : ()Ljava/lang/Thread;
    //   550: astore #12
    //   552: new java/lang/StringBuilder
    //   555: astore #16
    //   557: aload #16
    //   559: invokespecial <init> : ()V
    //   562: aload #16
    //   564: aload #12
    //   566: invokevirtual getName : ()Ljava/lang/String;
    //   569: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   572: ldc '('
    //   574: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   577: aload #12
    //   579: invokevirtual getId : ()J
    //   582: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   585: ldc ')'
    //   587: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   590: invokevirtual toString : ()Ljava/lang/String;
    //   593: astore #16
    //   595: aload_0
    //   596: aload #18
    //   598: aload #16
    //   600: ldc2_w 1000
    //   603: lload_3
    //   604: lmul
    //   605: lload #5
    //   607: ladd
    //   608: aload #7
    //   610: aload #8
    //   612: aload #20
    //   614: aload #9
    //   616: aload #21
    //   618: aload #10
    //   620: aload #17
    //   622: aconst_null
    //   623: aconst_null
    //   624: iconst_1
    //   625: invokevirtual packageCrashDatas : (Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[BLjava/util/Map;Z)Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;
    //   628: astore #17
    //   630: aload #17
    //   632: ifnonnull -> 795
    //   635: ldc 'pkg crash datas fail!'
    //   637: iconst_0
    //   638: anewarray java/lang/Object
    //   641: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   644: pop
    //   645: goto -> 336
    //   648: ldc 'not found extraMsg'
    //   650: iconst_0
    //   651: anewarray java/lang/Object
    //   654: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   657: pop
    //   658: goto -> 512
    //   661: ldc 'crash process name change to %s'
    //   663: iconst_1
    //   664: anewarray java/lang/Object
    //   667: dup
    //   668: iconst_0
    //   669: aload #16
    //   671: aastore
    //   672: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   675: pop
    //   676: aload #16
    //   678: astore #18
    //   680: goto -> 534
    //   683: ldc 'crash thread name change to %s'
    //   685: iconst_1
    //   686: anewarray java/lang/Object
    //   689: dup
    //   690: iconst_0
    //   691: aload #12
    //   693: aastore
    //   694: invokestatic c : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   697: pop
    //   698: invokestatic getAllStackTraces : ()Ljava/util/Map;
    //   701: invokeinterface keySet : ()Ljava/util/Set;
    //   706: invokeinterface iterator : ()Ljava/util/Iterator;
    //   711: astore #22
    //   713: aload #12
    //   715: astore #16
    //   717: aload #22
    //   719: invokeinterface hasNext : ()Z
    //   724: ifeq -> 595
    //   727: aload #22
    //   729: invokeinterface next : ()Ljava/lang/Object;
    //   734: checkcast java/lang/Thread
    //   737: astore #16
    //   739: aload #16
    //   741: invokevirtual getName : ()Ljava/lang/String;
    //   744: aload #12
    //   746: invokevirtual equals : (Ljava/lang/Object;)Z
    //   749: ifeq -> 713
    //   752: new java/lang/StringBuilder
    //   755: astore #22
    //   757: aload #22
    //   759: invokespecial <init> : ()V
    //   762: aload #22
    //   764: aload #12
    //   766: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   769: ldc '('
    //   771: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   774: aload #16
    //   776: invokevirtual getId : ()J
    //   779: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   782: ldc ')'
    //   784: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   787: invokevirtual toString : ()Ljava/lang/String;
    //   790: astore #16
    //   792: goto -> 595
    //   795: invokestatic n : ()Ljava/lang/String;
    //   798: astore #9
    //   800: aload_0
    //   801: getfield c : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   804: getfield d : Ljava/lang/String;
    //   807: astore #16
    //   809: invokestatic currentThread : ()Ljava/lang/Thread;
    //   812: astore #10
    //   814: new java/lang/StringBuilder
    //   817: astore #12
    //   819: aload #12
    //   821: invokespecial <init> : ()V
    //   824: ldc 'NATIVE_CRASH'
    //   826: aload #9
    //   828: aload #16
    //   830: aload #10
    //   832: aload #12
    //   834: aload #7
    //   836: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   839: ldc '\\n'
    //   841: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   844: aload #8
    //   846: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   849: ldc '\\n'
    //   851: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   854: aload #20
    //   856: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   859: invokevirtual toString : ()Ljava/lang/String;
    //   862: aload #17
    //   864: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Thread;Ljava/lang/String;Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   867: aload_0
    //   868: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   871: aload #17
    //   873: iload #11
    //   875: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;I)Z
    //   878: ifne -> 894
    //   881: aload_0
    //   882: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   885: aload #17
    //   887: ldc2_w 5000
    //   890: iconst_1
    //   891: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;JZ)V
    //   894: aload_0
    //   895: getfield e : Ljava/lang/String;
    //   898: invokestatic b : (Ljava/lang/String;)V
    //   901: goto -> 336
    //   904: aload #12
    //   906: astore #9
    //   908: goto -> 165
    // Exception table:
    //   from	to	target	type
    //   10	38	347	java/lang/Throwable
    //   40	49	347	java/lang/Throwable
    //   54	60	337	java/lang/InterruptedException
    //   54	60	347	java/lang/Throwable
    //   75	119	347	java/lang/Throwable
    //   124	161	347	java/lang/Throwable
    //   165	185	347	java/lang/Throwable
    //   185	289	347	java/lang/Throwable
    //   294	336	347	java/lang/Throwable
    //   339	344	347	java/lang/Throwable
    //   370	383	347	java/lang/Throwable
    //   401	415	347	java/lang/Throwable
    //   428	460	347	java/lang/Throwable
    //   466	481	347	java/lang/Throwable
    //   484	512	347	java/lang/Throwable
    //   517	525	347	java/lang/Throwable
    //   525	534	347	java/lang/Throwable
    //   539	547	347	java/lang/Throwable
    //   547	595	347	java/lang/Throwable
    //   595	630	347	java/lang/Throwable
    //   635	645	347	java/lang/Throwable
    //   648	658	347	java/lang/Throwable
    //   661	676	347	java/lang/Throwable
    //   683	713	347	java/lang/Throwable
    //   717	792	347	java/lang/Throwable
    //   795	894	347	java/lang/Throwable
    //   894	901	347	java/lang/Throwable
  }
  
  public final CrashDetailBean packageCrashDatas(String paramString1, String paramString2, long paramLong, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8, String paramString9, byte[] paramArrayOfbyte, Map<String, String> paramMap, boolean paramBoolean) {
    String str;
    boolean bool = c.a().l();
    if (bool) {
      str = " This Crash Caused By ANR , PLS To Fix ANR , This Trace May Be Not Useful![Bugly]";
    } else {
      str = "";
    } 
    if (bool)
      w.e("This Crash Caused By ANR , PLS To Fix ANR , This Trace May Be Not Useful!", new Object[0]); 
    CrashDetailBean crashDetailBean = new CrashDetailBean();
    crashDetailBean.b = 1;
    crashDetailBean.e = this.c.g();
    crashDetailBean.f = this.c.i;
    crashDetailBean.g = this.c.t();
    crashDetailBean.m = this.c.f();
    crashDetailBean.n = paramString3;
    crashDetailBean.o = str;
    crashDetailBean.p = paramString4;
    crashDetailBean.q = paramString5;
    crashDetailBean.r = paramLong;
    crashDetailBean.u = com.tencent.bugly.legu.proguard.a.b(crashDetailBean.q.getBytes());
    crashDetailBean.z = paramString1;
    crashDetailBean.A = paramString2;
    crashDetailBean.H = this.c.v();
    crashDetailBean.h = this.c.s();
    crashDetailBean.i = this.c.E();
    crashDetailBean.v = paramString8;
    crashDetailBean.I = paramString7;
    crashDetailBean.J = paramString6;
    crashDetailBean.K = paramString9;
    crashDetailBean.E = this.c.o();
    crashDetailBean.F = this.c.n();
    crashDetailBean.G = this.c.p();
    if (paramBoolean) {
      crashDetailBean.B = com.tencent.bugly.legu.proguard.a.i();
      crashDetailBean.C = com.tencent.bugly.legu.proguard.a.g();
      crashDetailBean.D = com.tencent.bugly.legu.proguard.a.k();
      crashDetailBean.w = com.tencent.bugly.legu.proguard.a.a(this.a, c.d, null);
      crashDetailBean.x = x.a(true);
      crashDetailBean.L = this.c.a;
      crashDetailBean.M = this.c.n;
      crashDetailBean.O = this.c.B();
      crashDetailBean.P = this.c.C();
      crashDetailBean.Q = this.c.w();
      crashDetailBean.R = this.c.A();
      crashDetailBean.y = com.tencent.bugly.legu.proguard.a.a(c.e, false);
      if (crashDetailBean.q != null) {
        int i = crashDetailBean.q.indexOf("java:\n");
        if (i > 0) {
          i += "java:\n".length();
          paramString2 = crashDetailBean.q.substring(i, crashDetailBean.q.length() - 1);
          if (paramString2.length() > 0 && crashDetailBean.y.containsKey(crashDetailBean.A)) {
            paramString3 = (String)crashDetailBean.y.get(crashDetailBean.A);
            int j = paramString3.indexOf(paramString2);
            if (j > 0) {
              paramString2 = paramString3.substring(j);
              crashDetailBean.y.put(crashDetailBean.A, paramString2);
              crashDetailBean.q = crashDetailBean.q.substring(0, i);
              crashDetailBean.q += paramString2;
            } 
          } 
        } 
      } 
      if (paramString1 == null)
        crashDetailBean.z = this.c.d; 
      this.b.b(crashDetailBean);
      return crashDetailBean;
    } 
    crashDetailBean.B = -1L;
    crashDetailBean.C = -1L;
    crashDetailBean.D = -1L;
    crashDetailBean.w = "this crash is occurred at last process! Log is miss, when get an terrible ABRT Native Exception etc.";
    crashDetailBean.L = -1L;
    crashDetailBean.O = -1;
    crashDetailBean.P = -1;
    crashDetailBean.Q = paramMap;
    crashDetailBean.R = null;
    crashDetailBean.y = null;
    if (paramString1 == null)
      crashDetailBean.z = "unknown(record)"; 
    if (paramArrayOfbyte == null) {
      crashDetailBean.x = "this crash is occurred at last process! Log is miss, when get an terrible ABRT Native Exception etc.".getBytes();
      return crashDetailBean;
    } 
    crashDetailBean.x = paramArrayOfbyte;
    return crashDetailBean;
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/jni/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */