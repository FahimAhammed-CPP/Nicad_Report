package com.tencent.bugly.legu.crashreport.crash.h5;

import android.content.Context;
import com.tencent.bugly.legu.BuglyStrategy;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.common.strategy.a;
import java.util.Map;

public final class b {
  private Context a;
  
  private com.tencent.bugly.legu.crashreport.crash.b b;
  
  private a c;
  
  private a d;
  
  public b(Context paramContext, com.tencent.bugly.legu.crashreport.crash.b paramb, a parama, a parama1, BuglyStrategy.a parama2) {
    this.a = paramContext;
    this.b = paramb;
    this.c = parama;
    this.d = parama1;
  }
  
  public final void a(Thread paramThread, String paramString1, String paramString2, String paramString3, Map<String, String> paramMap) {
    // Byte code:
    //   0: ldc 'H5 Crash Happen'
    //   2: iconst_0
    //   3: anewarray java/lang/Object
    //   6: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   9: pop
    //   10: aload_0
    //   11: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   14: invokevirtual b : ()Z
    //   17: ifne -> 73
    //   20: ldc 'waiting for remote sync'
    //   22: iconst_0
    //   23: anewarray java/lang/Object
    //   26: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   29: pop
    //   30: iconst_0
    //   31: istore #6
    //   33: aload_0
    //   34: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   37: invokevirtual b : ()Z
    //   40: istore #7
    //   42: iload #7
    //   44: ifne -> 73
    //   47: ldc2_w 500
    //   50: invokestatic sleep : (J)V
    //   53: iload #6
    //   55: sipush #500
    //   58: iadd
    //   59: istore #8
    //   61: iload #8
    //   63: istore #6
    //   65: iload #8
    //   67: sipush #5000
    //   70: if_icmplt -> 33
    //   73: aload_0
    //   74: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   77: invokevirtual b : ()Z
    //   80: ifne -> 93
    //   83: ldc 'no remote but still store!'
    //   85: iconst_0
    //   86: anewarray java/lang/Object
    //   89: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   92: pop
    //   93: aload_0
    //   94: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   97: invokevirtual c : ()Lcom/tencent/bugly/legu/crashreport/common/strategy/StrategyBean;
    //   100: astore #9
    //   102: aload #9
    //   104: getfield d : Z
    //   107: ifne -> 239
    //   110: aload_0
    //   111: getfield c : Lcom/tencent/bugly/legu/crashreport/common/strategy/a;
    //   114: invokevirtual b : ()Z
    //   117: ifeq -> 239
    //   120: ldc 'crash report was closed by remote , will not upload to Bugly , print local for helpful!'
    //   122: iconst_0
    //   123: anewarray java/lang/Object
    //   126: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   129: pop
    //   130: invokestatic n : ()Ljava/lang/String;
    //   133: astore #10
    //   135: aload_0
    //   136: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   139: getfield d : Ljava/lang/String;
    //   142: astore #5
    //   144: new java/lang/StringBuilder
    //   147: astore #9
    //   149: aload #9
    //   151: invokespecial <init> : ()V
    //   154: ldc 'H5'
    //   156: aload #10
    //   158: aload #5
    //   160: aload_1
    //   161: aload #9
    //   163: aload_2
    //   164: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: ldc '\\n'
    //   169: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: aload_3
    //   173: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   176: ldc '\\n'
    //   178: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: aload #4
    //   183: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   186: invokevirtual toString : ()Ljava/lang/String;
    //   189: aconst_null
    //   190: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Thread;Ljava/lang/String;Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   193: ldc 'handle end'
    //   195: iconst_0
    //   196: anewarray java/lang/Object
    //   199: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   202: pop
    //   203: return
    //   204: astore #9
    //   206: aload #9
    //   208: invokevirtual printStackTrace : ()V
    //   211: goto -> 53
    //   214: astore_1
    //   215: aload_1
    //   216: invokestatic a : (Ljava/lang/Throwable;)Z
    //   219: ifne -> 226
    //   222: aload_1
    //   223: invokevirtual printStackTrace : ()V
    //   226: ldc 'handle end'
    //   228: iconst_0
    //   229: anewarray java/lang/Object
    //   232: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   235: pop
    //   236: goto -> 203
    //   239: aload #9
    //   241: getfield i : Z
    //   244: ifne -> 270
    //   247: ldc 'cocos report is disabled.'
    //   249: iconst_0
    //   250: anewarray java/lang/Object
    //   253: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   256: pop
    //   257: ldc 'handle end'
    //   259: iconst_0
    //   260: anewarray java/lang/Object
    //   263: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   266: pop
    //   267: goto -> 203
    //   270: new com/tencent/bugly/legu/crashreport/crash/CrashDetailBean
    //   273: astore #9
    //   275: aload #9
    //   277: invokespecial <init> : ()V
    //   280: aload #9
    //   282: invokestatic i : ()J
    //   285: putfield B : J
    //   288: aload #9
    //   290: invokestatic g : ()J
    //   293: putfield C : J
    //   296: aload #9
    //   298: invokestatic k : ()J
    //   301: putfield D : J
    //   304: aload #9
    //   306: aload_0
    //   307: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   310: invokevirtual o : ()J
    //   313: putfield E : J
    //   316: aload #9
    //   318: aload_0
    //   319: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   322: invokevirtual n : ()J
    //   325: putfield F : J
    //   328: aload #9
    //   330: aload_0
    //   331: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   334: invokevirtual p : ()J
    //   337: putfield G : J
    //   340: aload #9
    //   342: aload_0
    //   343: getfield a : Landroid/content/Context;
    //   346: getstatic com/tencent/bugly/legu/crashreport/crash/c.d : I
    //   349: aconst_null
    //   350: invokestatic a : (Landroid/content/Context;ILjava/lang/String;)Ljava/lang/String;
    //   353: putfield w : Ljava/lang/String;
    //   356: aload #9
    //   358: iconst_5
    //   359: putfield b : I
    //   362: aload #9
    //   364: aload_0
    //   365: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   368: invokevirtual g : ()Ljava/lang/String;
    //   371: putfield e : Ljava/lang/String;
    //   374: aload #9
    //   376: aload_0
    //   377: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   380: getfield i : Ljava/lang/String;
    //   383: putfield f : Ljava/lang/String;
    //   386: aload #9
    //   388: aload_0
    //   389: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   392: invokevirtual t : ()Ljava/lang/String;
    //   395: putfield g : Ljava/lang/String;
    //   398: aload #9
    //   400: aload_0
    //   401: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   404: invokevirtual f : ()Ljava/lang/String;
    //   407: putfield m : Ljava/lang/String;
    //   410: new java/lang/StringBuilder
    //   413: astore #10
    //   415: aload #10
    //   417: invokespecial <init> : ()V
    //   420: aload #9
    //   422: aload #10
    //   424: aload_2
    //   425: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   428: invokevirtual toString : ()Ljava/lang/String;
    //   431: putfield n : Ljava/lang/String;
    //   434: new java/lang/StringBuilder
    //   437: astore #10
    //   439: aload #10
    //   441: invokespecial <init> : ()V
    //   444: aload #9
    //   446: aload #10
    //   448: aload_3
    //   449: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   452: invokevirtual toString : ()Ljava/lang/String;
    //   455: putfield o : Ljava/lang/String;
    //   458: aload #9
    //   460: ldc '0'
    //   462: putfield p : Ljava/lang/String;
    //   465: aload #9
    //   467: aload #4
    //   469: putfield q : Ljava/lang/String;
    //   472: aload #9
    //   474: invokestatic currentTimeMillis : ()J
    //   477: putfield r : J
    //   480: aload #9
    //   482: aload #9
    //   484: getfield q : Ljava/lang/String;
    //   487: invokevirtual getBytes : ()[B
    //   490: invokestatic b : ([B)Ljava/lang/String;
    //   493: putfield u : Ljava/lang/String;
    //   496: aload #9
    //   498: getstatic com/tencent/bugly/legu/crashreport/crash/c.e : I
    //   501: iconst_0
    //   502: invokestatic a : (IZ)Ljava/util/Map;
    //   505: putfield y : Ljava/util/Map;
    //   508: aload #9
    //   510: aload_0
    //   511: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   514: getfield d : Ljava/lang/String;
    //   517: putfield z : Ljava/lang/String;
    //   520: new java/lang/StringBuilder
    //   523: astore #10
    //   525: aload #10
    //   527: invokespecial <init> : ()V
    //   530: aload #9
    //   532: aload #10
    //   534: aload_1
    //   535: invokevirtual getName : ()Ljava/lang/String;
    //   538: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   541: ldc '('
    //   543: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   546: aload_1
    //   547: invokevirtual getId : ()J
    //   550: invokevirtual append : (J)Ljava/lang/StringBuilder;
    //   553: ldc ')'
    //   555: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   558: invokevirtual toString : ()Ljava/lang/String;
    //   561: putfield A : Ljava/lang/String;
    //   564: aload #9
    //   566: aload_0
    //   567: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   570: invokevirtual v : ()Ljava/lang/String;
    //   573: putfield H : Ljava/lang/String;
    //   576: aload #9
    //   578: aload_0
    //   579: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   582: invokevirtual s : ()Ljava/util/Map;
    //   585: putfield h : Ljava/util/Map;
    //   588: aload #9
    //   590: aload_0
    //   591: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   594: getfield a : J
    //   597: putfield L : J
    //   600: aload #9
    //   602: aload_0
    //   603: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   606: getfield n : Z
    //   609: putfield M : Z
    //   612: aload #9
    //   614: aload_0
    //   615: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   618: invokevirtual B : ()I
    //   621: putfield O : I
    //   624: aload #9
    //   626: aload_0
    //   627: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   630: invokevirtual C : ()I
    //   633: putfield P : I
    //   636: aload #9
    //   638: aload_0
    //   639: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   642: invokevirtual w : ()Ljava/util/Map;
    //   645: putfield Q : Ljava/util/Map;
    //   648: aload #9
    //   650: aload_0
    //   651: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   654: invokevirtual A : ()Ljava/util/Map;
    //   657: putfield R : Ljava/util/Map;
    //   660: aload_0
    //   661: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   664: aload #9
    //   666: invokevirtual b : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   669: aload #9
    //   671: iconst_0
    //   672: invokestatic a : (Z)[B
    //   675: putfield x : [B
    //   678: aload #9
    //   680: getfield N : Ljava/util/Map;
    //   683: ifnonnull -> 703
    //   686: new java/util/LinkedHashMap
    //   689: astore #10
    //   691: aload #10
    //   693: invokespecial <init> : ()V
    //   696: aload #9
    //   698: aload #10
    //   700: putfield N : Ljava/util/Map;
    //   703: aload #5
    //   705: ifnull -> 720
    //   708: aload #9
    //   710: getfield N : Ljava/util/Map;
    //   713: aload #5
    //   715: invokeinterface putAll : (Ljava/util/Map;)V
    //   720: aload #9
    //   722: ifnonnull -> 749
    //   725: ldc_w 'pkg crash datas fail!'
    //   728: iconst_0
    //   729: anewarray java/lang/Object
    //   732: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   735: pop
    //   736: ldc 'handle end'
    //   738: iconst_0
    //   739: anewarray java/lang/Object
    //   742: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   745: pop
    //   746: goto -> 203
    //   749: invokestatic n : ()Ljava/lang/String;
    //   752: astore #11
    //   754: aload_0
    //   755: getfield d : Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   758: getfield d : Ljava/lang/String;
    //   761: astore #10
    //   763: new java/lang/StringBuilder
    //   766: astore #5
    //   768: aload #5
    //   770: invokespecial <init> : ()V
    //   773: ldc 'H5'
    //   775: aload #11
    //   777: aload #10
    //   779: aload_1
    //   780: aload #5
    //   782: aload_2
    //   783: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   786: ldc '\\n'
    //   788: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   791: aload_3
    //   792: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   795: ldc '\\n'
    //   797: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   800: aload #4
    //   802: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   805: invokevirtual toString : ()Ljava/lang/String;
    //   808: aload #9
    //   810: invokestatic a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Thread;Ljava/lang/String;Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)V
    //   813: aload_0
    //   814: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   817: aload #9
    //   819: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;)Z
    //   822: ifne -> 838
    //   825: aload_0
    //   826: getfield b : Lcom/tencent/bugly/legu/crashreport/crash/b;
    //   829: aload #9
    //   831: ldc2_w 5000
    //   834: iconst_0
    //   835: invokevirtual a : (Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;JZ)V
    //   838: ldc 'handle end'
    //   840: iconst_0
    //   841: anewarray java/lang/Object
    //   844: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   847: pop
    //   848: goto -> 203
    //   851: astore_1
    //   852: ldc 'handle end'
    //   854: iconst_0
    //   855: anewarray java/lang/Object
    //   858: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   861: pop
    //   862: aload_1
    //   863: athrow
    // Exception table:
    //   from	to	target	type
    //   10	30	214	java/lang/Throwable
    //   10	30	851	finally
    //   33	42	214	java/lang/Throwable
    //   33	42	851	finally
    //   47	53	204	java/lang/InterruptedException
    //   47	53	214	java/lang/Throwable
    //   47	53	851	finally
    //   73	93	214	java/lang/Throwable
    //   73	93	851	finally
    //   93	193	214	java/lang/Throwable
    //   93	193	851	finally
    //   206	211	214	java/lang/Throwable
    //   206	211	851	finally
    //   215	226	851	finally
    //   239	257	214	java/lang/Throwable
    //   239	257	851	finally
    //   270	703	214	java/lang/Throwable
    //   270	703	851	finally
    //   708	720	214	java/lang/Throwable
    //   708	720	851	finally
    //   725	736	214	java/lang/Throwable
    //   725	736	851	finally
    //   749	838	214	java/lang/Throwable
    //   749	838	851	finally
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/h5/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */