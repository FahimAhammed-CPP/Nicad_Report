package com.tencent.bugly.legu.crashreport.crash;

public final class a implements Comparable<a> {
  public long a = -1L;
  
  public long b = -1L;
  
  public String c = null;
  
  public boolean d = false;
  
  public boolean e = false;
  
  public int f = 0;
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */