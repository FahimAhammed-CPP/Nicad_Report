package com.tencent.bugly.legu.crashreport.crash.h5;

public final class a {
  public String a = null;
  
  public String b = null;
  
  public String c = null;
  
  public String d = null;
  
  public String e = null;
  
  public String f = null;
  
  public String g = null;
  
  public String h = null;
  
  public String i = null;
  
  public long j = 0L;
  
  public long k = 0L;
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/h5/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */