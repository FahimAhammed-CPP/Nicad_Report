package com.tencent.StubShell;

import java.lang.reflect.Field;

public class XposedCheck {
  private static final String XPOSED_BRIDGE = "de.robv.android.xposed.XposedBridge";
  
  private static final String XPOSED_HELPERS = "de.robv.android.xposed.XposedHelpers";
  
  private static boolean isXposedExistByThrow() {
    boolean bool = false;
    try {
      Exception exception = new Exception();
      this("Exception xp");
      throw exception;
    } catch (Exception exception) {
      StackTraceElement[] arrayOfStackTraceElement = exception.getStackTrace();
      int i = arrayOfStackTraceElement.length;
      for (byte b = 0;; b++) {
        boolean bool1 = bool;
        if (b < i) {
          if (arrayOfStackTraceElement[b].getClassName().contains("de.robv.android.xposed.XposedBridge"))
            return true; 
        } else {
          return bool1;
        } 
      } 
    } 
  }
  
  private static boolean isXposedExists() {
    boolean bool = true;
    try {
      ClassLoader.getSystemClassLoader().loadClass("de.robv.android.xposed.XposedHelpers").newInstance();
      try {
        ClassLoader.getSystemClassLoader().loadClass("de.robv.android.xposed.XposedBridge").newInstance();
      } catch (InstantiationException instantiationException) {
        instantiationException.printStackTrace();
      } catch (IllegalAccessException illegalAccessException) {
        illegalAccessException.printStackTrace();
      } catch (ClassNotFoundException classNotFoundException) {
        classNotFoundException.printStackTrace();
        bool = false;
      } 
    } catch (InstantiationException instantiationException) {
      instantiationException.printStackTrace();
    } catch (IllegalAccessException illegalAccessException) {
      illegalAccessException.printStackTrace();
    } catch (ClassNotFoundException classNotFoundException) {
      classNotFoundException.printStackTrace();
      bool = false;
    } 
    return bool;
  }
  
  public static boolean tryShutdownXposed() {
    boolean bool1 = true;
    boolean bool2 = bool1;
    if (isXposedExistByThrow())
      try {
        Field field = ClassLoader.getSystemClassLoader().loadClass("de.robv.android.xposed.XposedBridge").getDeclaredField("disableHooks");
        field.setAccessible(true);
        field.set(null, Boolean.valueOf(true));
        bool2 = bool1;
      } catch (NoSuchFieldException noSuchFieldException) {
        noSuchFieldException.printStackTrace();
        bool2 = false;
      } catch (ClassNotFoundException classNotFoundException) {
        classNotFoundException.printStackTrace();
        bool2 = false;
      } catch (IllegalAccessException illegalAccessException) {
        illegalAccessException.printStackTrace();
        bool2 = false;
      }  
    return bool2;
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/StubShell/XposedCheck.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */