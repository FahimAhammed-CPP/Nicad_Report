package com.tencent.StubShell;

import android.os.Build;
import com.tencent.bugly.legu.crashreport.BuglyLog;
import java.io.File;
import org.json.JSONObject;

public class SystemInfoException extends Throwable {
  public SystemInfoException(String paramString) {
    if (paramString != null)
      try {
        BuglyLog.i("Legu", paramString);
      } catch (Throwable throwable) {
        throwable.printStackTrace();
      }  
  }
  
  public SystemInfoException(String paramString1, String paramString2) {
    JSONObject jSONObject = new JSONObject();
    try {
      jSONObject.put("fingerprint", Build.FINGERPRINT);
      File file = new File();
      this("/system/lib/libdvm.so");
      if (file.exists())
        jSONObject.put("libdvm32", b.a("/system/lib/libdvm.so")); 
      file = new File();
      this("/system/lib/libart.so");
      if (file.exists())
        jSONObject.put("libart32", b.a("/system/lib/libart.so")); 
      file = new File();
      this("/system/lib64/libdvm.so");
      if (file.exists())
        jSONObject.put("libdvm64", b.a("/system/lib64/libdvm.so")); 
      file = new File();
      this("/system/lib64/libart.so");
      if (file.exists())
        jSONObject.put("libart64", b.a("/system/lib64/libart.so")); 
      file = new File();
      this(paramString1);
      if (file.exists())
        jSONObject.put("apk_md5", b.a(paramString1)); 
      jSONObject.put("apk_version", paramString2);
      BuglyLog.i("Legu", jSONObject.toString());
    } catch (Throwable throwable) {
      throwable.printStackTrace();
    } 
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/StubShell/SystemInfoException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */