package com.tencent.StubShell;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class TxReceiver extends BroadcastReceiver {
  public static String TX_RECIEVER = "com.tencent.StubShell.TxReceiver";
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    TxAppEntry.a(paramIntent);
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/StubShell/TxReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */