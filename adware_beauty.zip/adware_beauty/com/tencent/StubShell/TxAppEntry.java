package com.tencent.StubShell;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Handler;
import android.util.Log;
import com.tencent.bugly.legu.crashreport.CrashReport;
import dalvik.system.DexFile;
import java.io.File;
import java.util.Enumeration;

public class TxAppEntry extends Application {
  public static String a;
  
  public static String b;
  
  public static String c;
  
  static int d = 0;
  
  static boolean e = false;
  
  private static Context f;
  
  private static String g;
  
  private static String h;
  
  private static String i = "";
  
  private static boolean j = false;
  
  private static String mOldAPPName;
  
  public static Object mPClassLoader;
  
  private static String mPKName;
  
  private static String mSocPath;
  
  private static String mSrcPath;
  
  private static String mVerFilePath;
  
  private static boolean mbVerCheck = false;
  
  private static final String version = "5b2285003ea517813bdc885103f9455bcab976c9a9fdc7ae004c52f795e1c8d1";
  
  private Handler k = null;
  
  static {
    a = "";
    b = "";
    c = "___XSSTUB___";
    try {
      j = "__TRUE__".equals(c);
    } catch (Throwable throwable) {
      Log.w("SecShell", throwable);
    } 
    d = 0;
    e = false;
  }
  
  public static void a(Intent paramIntent) {
    reciver(paramIntent);
  }
  
  private void a(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getApplicationInfo : ()Landroid/content/pm/ApplicationInfo;
    //   4: astore_2
    //   5: aload_2
    //   6: getfield dataDir : Ljava/lang/String;
    //   9: astore_3
    //   10: new java/lang/StringBuilder
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: aload_3
    //   18: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   21: ldc '/tx_shell'
    //   23: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   26: invokevirtual toString : ()Ljava/lang/String;
    //   29: astore #4
    //   31: aload_2
    //   32: getfield sourceDir : Ljava/lang/String;
    //   35: putstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   38: getstatic android/os/Build$VERSION.SDK_INT : I
    //   41: istore #5
    //   43: iconst_0
    //   44: istore #6
    //   46: iload #5
    //   48: bipush #19
    //   50: if_icmpge -> 410
    //   53: iload #6
    //   55: istore #5
    //   57: aconst_null
    //   58: astore_3
    //   59: getstatic android/os/Build$VERSION.SDK_INT : I
    //   62: bipush #21
    //   64: if_icmpge -> 71
    //   67: getstatic android/os/Build.CPU_ABI : Ljava/lang/String;
    //   70: astore_3
    //   71: aload_3
    //   72: ifnull -> 86
    //   75: aload_3
    //   76: astore #7
    //   78: aload_3
    //   79: invokevirtual length : ()I
    //   82: iconst_2
    //   83: if_icmpge -> 104
    //   86: aload_3
    //   87: astore #7
    //   89: getstatic android/os/Build$VERSION.SDK_INT : I
    //   92: bipush #21
    //   94: if_icmplt -> 104
    //   97: getstatic android/os/Build.SUPPORTED_ABIS : [Ljava/lang/String;
    //   100: iconst_0
    //   101: aaload
    //   102: astore #7
    //   104: iconst_1
    //   105: istore #8
    //   107: iconst_1
    //   108: istore #9
    //   110: aload #7
    //   112: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   115: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   118: ldc 'x86'
    //   120: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   123: ifeq -> 470
    //   126: iconst_0
    //   127: istore #6
    //   129: iconst_0
    //   130: istore #8
    //   132: aload #7
    //   134: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   137: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   140: ldc 'mips'
    //   142: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   145: ifeq -> 151
    //   148: iconst_1
    //   149: istore #8
    //   151: getstatic android/os/Build$VERSION.SDK_INT : I
    //   154: bipush #8
    //   156: if_icmple -> 535
    //   159: aload_2
    //   160: getfield nativeLibraryDir : Ljava/lang/String;
    //   163: astore_3
    //   164: ldc ''
    //   166: astore_2
    //   167: iload #6
    //   169: ifeq -> 565
    //   172: new java/lang/StringBuilder
    //   175: dup
    //   176: invokespecial <init> : ()V
    //   179: aload_1
    //   180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: aload_0
    //   184: invokespecial d : ()Ljava/lang/String;
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: invokevirtual toString : ()Ljava/lang/String;
    //   193: astore_1
    //   194: new java/lang/StringBuilder
    //   197: dup
    //   198: invokespecial <init> : ()V
    //   201: ldc ''
    //   203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: ldc 'lib'
    //   208: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   211: aload_1
    //   212: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   215: ldc '.so'
    //   217: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   220: invokevirtual toString : ()Ljava/lang/String;
    //   223: astore #10
    //   225: new java/lang/StringBuilder
    //   228: dup
    //   229: invokespecial <init> : ()V
    //   232: ldc ''
    //   234: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   237: ldc 'lib'
    //   239: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   242: aload_2
    //   243: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   246: ldc '.so'
    //   248: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   251: invokevirtual toString : ()Ljava/lang/String;
    //   254: astore_2
    //   255: new java/io/File
    //   258: dup
    //   259: new java/lang/StringBuilder
    //   262: dup
    //   263: invokespecial <init> : ()V
    //   266: aload_3
    //   267: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   270: ldc '/'
    //   272: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   275: aload #10
    //   277: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   280: invokevirtual toString : ()Ljava/lang/String;
    //   283: invokespecial <init> : (Ljava/lang/String;)V
    //   286: astore #11
    //   288: new java/io/File
    //   291: dup
    //   292: new java/lang/StringBuilder
    //   295: dup
    //   296: invokespecial <init> : ()V
    //   299: aload #4
    //   301: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   304: ldc '/'
    //   306: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   309: aload_2
    //   310: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   313: invokevirtual toString : ()Ljava/lang/String;
    //   316: invokespecial <init> : (Ljava/lang/String;)V
    //   319: astore_3
    //   320: iload #6
    //   322: ifne -> 762
    //   325: getstatic android/os/Build$VERSION.SDK_INT : I
    //   328: bipush #19
    //   330: if_icmpge -> 762
    //   333: aload_3
    //   334: invokevirtual exists : ()Z
    //   337: ifeq -> 616
    //   340: invokestatic getRuntime : ()Ljava/lang/Runtime;
    //   343: astore_3
    //   344: new java/lang/StringBuilder
    //   347: astore_1
    //   348: aload_1
    //   349: invokespecial <init> : ()V
    //   352: aload_3
    //   353: aload_1
    //   354: ldc 'chmod 700 '
    //   356: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   359: aload #4
    //   361: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   364: ldc '/'
    //   366: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   369: aload_2
    //   370: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   373: invokevirtual toString : ()Ljava/lang/String;
    //   376: invokevirtual exec : (Ljava/lang/String;)Ljava/lang/Process;
    //   379: pop
    //   380: new java/lang/StringBuilder
    //   383: astore_1
    //   384: aload_1
    //   385: invokespecial <init> : ()V
    //   388: aload_1
    //   389: aload #4
    //   391: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   394: ldc '/'
    //   396: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   399: aload_2
    //   400: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   403: invokevirtual toString : ()Ljava/lang/String;
    //   406: invokestatic load : (Ljava/lang/String;)V
    //   409: return
    //   410: iload #5
    //   412: bipush #19
    //   414: if_icmple -> 445
    //   417: getstatic android/os/Build.SUPPORTED_64_BIT_ABIS : [Ljava/lang/String;
    //   420: astore_3
    //   421: iload #6
    //   423: istore #5
    //   425: aload_3
    //   426: ifnull -> 57
    //   429: iload #6
    //   431: istore #5
    //   433: aload_3
    //   434: arraylength
    //   435: iconst_1
    //   436: if_icmple -> 57
    //   439: iconst_1
    //   440: istore #5
    //   442: goto -> 57
    //   445: iload #6
    //   447: istore #5
    //   449: new java/io/File
    //   452: dup
    //   453: ldc '/system/lib64'
    //   455: invokespecial <init> : (Ljava/lang/String;)V
    //   458: invokevirtual exists : ()Z
    //   461: ifeq -> 57
    //   464: iconst_1
    //   465: istore #5
    //   467: goto -> 57
    //   470: iload #9
    //   472: istore #6
    //   474: getstatic android/os/Build$VERSION.SDK_INT : I
    //   477: bipush #21
    //   479: if_icmplt -> 129
    //   482: getstatic android/os/Build.SUPPORTED_ABIS : [Ljava/lang/String;
    //   485: astore_3
    //   486: iload #9
    //   488: istore #6
    //   490: aload_3
    //   491: ifnull -> 129
    //   494: iconst_0
    //   495: istore #9
    //   497: iload #8
    //   499: istore #6
    //   501: iload #9
    //   503: aload_3
    //   504: arraylength
    //   505: if_icmpge -> 129
    //   508: aload_3
    //   509: iload #9
    //   511: aaload
    //   512: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   515: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   518: ldc 'x86'
    //   520: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   523: ifeq -> 529
    //   526: iconst_0
    //   527: istore #8
    //   529: iinc #9, 1
    //   532: goto -> 497
    //   535: new java/lang/StringBuilder
    //   538: dup
    //   539: invokespecial <init> : ()V
    //   542: ldc '/data/data/'
    //   544: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   547: getstatic com/tencent/StubShell/TxAppEntry.mPKName : Ljava/lang/String;
    //   550: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   553: ldc '/lib'
    //   555: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   558: invokevirtual toString : ()Ljava/lang/String;
    //   561: astore_3
    //   562: goto -> 164
    //   565: new java/lang/StringBuilder
    //   568: dup
    //   569: invokespecial <init> : ()V
    //   572: aload_1
    //   573: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   576: aload_0
    //   577: invokespecial d : ()Ljava/lang/String;
    //   580: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   583: invokevirtual toString : ()Ljava/lang/String;
    //   586: astore #10
    //   588: new java/lang/StringBuilder
    //   591: dup
    //   592: invokespecial <init> : ()V
    //   595: aload_1
    //   596: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   599: aload_0
    //   600: invokespecial d : ()Ljava/lang/String;
    //   603: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   606: invokevirtual toString : ()Ljava/lang/String;
    //   609: astore_2
    //   610: aload #10
    //   612: astore_1
    //   613: goto -> 194
    //   616: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   619: new java/lang/StringBuilder
    //   622: dup
    //   623: invokespecial <init> : ()V
    //   626: ldc 'lib/armeabi/'
    //   628: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   631: aload_2
    //   632: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   635: invokevirtual toString : ()Ljava/lang/String;
    //   638: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   641: ifne -> 699
    //   644: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   647: new java/lang/StringBuilder
    //   650: dup
    //   651: invokespecial <init> : ()V
    //   654: ldc 'lib/armeabi/'
    //   656: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   659: aload_2
    //   660: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   663: invokevirtual toString : ()Ljava/lang/String;
    //   666: new java/lang/StringBuilder
    //   669: dup
    //   670: invokespecial <init> : ()V
    //   673: aload #4
    //   675: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   678: ldc '/'
    //   680: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   683: aload_2
    //   684: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   687: invokevirtual toString : ()Ljava/lang/String;
    //   690: invokestatic extract : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   693: ifne -> 340
    //   696: goto -> 340
    //   699: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   702: new java/lang/StringBuilder
    //   705: dup
    //   706: invokespecial <init> : ()V
    //   709: ldc 'lib/armeabi-v7a/'
    //   711: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   714: aload_2
    //   715: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   718: invokevirtual toString : ()Ljava/lang/String;
    //   721: new java/lang/StringBuilder
    //   724: dup
    //   725: invokespecial <init> : ()V
    //   728: aload #4
    //   730: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   733: ldc '/'
    //   735: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   738: aload_2
    //   739: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   742: invokevirtual toString : ()Ljava/lang/String;
    //   745: invokestatic extract : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   748: ifne -> 340
    //   751: goto -> 340
    //   754: astore_1
    //   755: aload_1
    //   756: invokevirtual printStackTrace : ()V
    //   759: goto -> 409
    //   762: aload #11
    //   764: invokevirtual exists : ()Z
    //   767: ifeq -> 777
    //   770: aload_1
    //   771: invokestatic loadLibrary : (Ljava/lang/String;)V
    //   774: goto -> 409
    //   777: new java/lang/StringBuilder
    //   780: dup
    //   781: invokespecial <init> : ()V
    //   784: aload #4
    //   786: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   789: ldc '/'
    //   791: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   794: aload #10
    //   796: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   799: invokevirtual toString : ()Ljava/lang/String;
    //   802: astore_2
    //   803: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   806: new java/lang/StringBuilder
    //   809: dup
    //   810: invokespecial <init> : ()V
    //   813: ldc 'lib/'
    //   815: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   818: aload #7
    //   820: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   823: ldc '/'
    //   825: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   828: aload #10
    //   830: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   833: invokevirtual toString : ()Ljava/lang/String;
    //   836: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   839: ifne -> 929
    //   842: new java/lang/StringBuilder
    //   845: dup
    //   846: invokespecial <init> : ()V
    //   849: ldc 'lib/'
    //   851: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   854: aload #7
    //   856: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   859: ldc '/'
    //   861: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   864: aload #10
    //   866: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   869: invokevirtual toString : ()Ljava/lang/String;
    //   872: astore_1
    //   873: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   876: aload_1
    //   877: aload_2
    //   878: invokestatic extract : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   881: ifne -> 409
    //   884: invokestatic getRuntime : ()Ljava/lang/Runtime;
    //   887: astore_1
    //   888: new java/lang/StringBuilder
    //   891: astore_3
    //   892: aload_3
    //   893: invokespecial <init> : ()V
    //   896: aload_1
    //   897: aload_3
    //   898: ldc 'chmod 700 '
    //   900: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   903: aload_2
    //   904: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   907: invokevirtual toString : ()Ljava/lang/String;
    //   910: invokevirtual exec : (Ljava/lang/String;)Ljava/lang/Process;
    //   913: pop
    //   914: aload_2
    //   915: invokestatic load : (Ljava/lang/String;)V
    //   918: goto -> 409
    //   921: astore_1
    //   922: aload_1
    //   923: invokevirtual printStackTrace : ()V
    //   926: goto -> 409
    //   929: iload #5
    //   931: ifeq -> 1363
    //   934: iload #6
    //   936: ifeq -> 1098
    //   939: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   942: new java/lang/StringBuilder
    //   945: dup
    //   946: invokespecial <init> : ()V
    //   949: ldc 'lib/arm64-v8a/'
    //   951: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   954: aload #10
    //   956: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   959: invokevirtual toString : ()Ljava/lang/String;
    //   962: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   965: ifne -> 992
    //   968: new java/lang/StringBuilder
    //   971: dup
    //   972: invokespecial <init> : ()V
    //   975: ldc 'lib/arm64-v8a/'
    //   977: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   980: aload #10
    //   982: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   985: invokevirtual toString : ()Ljava/lang/String;
    //   988: astore_1
    //   989: goto -> 873
    //   992: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   995: new java/lang/StringBuilder
    //   998: dup
    //   999: invokespecial <init> : ()V
    //   1002: ldc 'lib/armeabi/'
    //   1004: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1007: aload #10
    //   1009: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1012: invokevirtual toString : ()Ljava/lang/String;
    //   1015: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1018: ifne -> 1045
    //   1021: new java/lang/StringBuilder
    //   1024: dup
    //   1025: invokespecial <init> : ()V
    //   1028: ldc 'lib/armeabi/'
    //   1030: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1033: aload #10
    //   1035: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1038: invokevirtual toString : ()Ljava/lang/String;
    //   1041: astore_1
    //   1042: goto -> 873
    //   1045: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1048: new java/lang/StringBuilder
    //   1051: dup
    //   1052: invokespecial <init> : ()V
    //   1055: ldc 'lib/armeabi-v7a/'
    //   1057: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1060: aload #10
    //   1062: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1065: invokevirtual toString : ()Ljava/lang/String;
    //   1068: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1071: ifne -> 1700
    //   1074: new java/lang/StringBuilder
    //   1077: dup
    //   1078: invokespecial <init> : ()V
    //   1081: ldc 'lib/armeabi-v7a/'
    //   1083: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1086: aload #10
    //   1088: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1091: invokevirtual toString : ()Ljava/lang/String;
    //   1094: astore_1
    //   1095: goto -> 873
    //   1098: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1101: new java/lang/StringBuilder
    //   1104: dup
    //   1105: invokespecial <init> : ()V
    //   1108: ldc 'lib/x86_64/'
    //   1110: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1113: aload #10
    //   1115: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1118: invokevirtual toString : ()Ljava/lang/String;
    //   1121: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1124: ifne -> 1151
    //   1127: new java/lang/StringBuilder
    //   1130: dup
    //   1131: invokespecial <init> : ()V
    //   1134: ldc 'lib/x86_64/'
    //   1136: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1139: aload #10
    //   1141: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1144: invokevirtual toString : ()Ljava/lang/String;
    //   1147: astore_1
    //   1148: goto -> 873
    //   1151: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1154: new java/lang/StringBuilder
    //   1157: dup
    //   1158: invokespecial <init> : ()V
    //   1161: ldc 'lib/arm64-v8a/'
    //   1163: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1166: aload #10
    //   1168: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1171: invokevirtual toString : ()Ljava/lang/String;
    //   1174: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1177: ifne -> 1204
    //   1180: new java/lang/StringBuilder
    //   1183: dup
    //   1184: invokespecial <init> : ()V
    //   1187: ldc 'lib/arm64-v8a/'
    //   1189: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1192: aload #10
    //   1194: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1197: invokevirtual toString : ()Ljava/lang/String;
    //   1200: astore_1
    //   1201: goto -> 873
    //   1204: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1207: new java/lang/StringBuilder
    //   1210: dup
    //   1211: invokespecial <init> : ()V
    //   1214: ldc 'lib/x86/'
    //   1216: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1219: aload #10
    //   1221: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1224: invokevirtual toString : ()Ljava/lang/String;
    //   1227: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1230: ifne -> 1257
    //   1233: new java/lang/StringBuilder
    //   1236: dup
    //   1237: invokespecial <init> : ()V
    //   1240: ldc 'lib/x86/'
    //   1242: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1245: aload #10
    //   1247: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1250: invokevirtual toString : ()Ljava/lang/String;
    //   1253: astore_1
    //   1254: goto -> 873
    //   1257: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1260: new java/lang/StringBuilder
    //   1263: dup
    //   1264: invokespecial <init> : ()V
    //   1267: ldc 'lib/armeabi/'
    //   1269: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1272: aload #10
    //   1274: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1277: invokevirtual toString : ()Ljava/lang/String;
    //   1280: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1283: ifne -> 1310
    //   1286: new java/lang/StringBuilder
    //   1289: dup
    //   1290: invokespecial <init> : ()V
    //   1293: ldc 'lib/armeabi/'
    //   1295: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1298: aload #10
    //   1300: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1303: invokevirtual toString : ()Ljava/lang/String;
    //   1306: astore_1
    //   1307: goto -> 873
    //   1310: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1313: new java/lang/StringBuilder
    //   1316: dup
    //   1317: invokespecial <init> : ()V
    //   1320: ldc 'lib/armeabi-v7a/'
    //   1322: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1325: aload #10
    //   1327: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1330: invokevirtual toString : ()Ljava/lang/String;
    //   1333: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1336: ifne -> 1700
    //   1339: new java/lang/StringBuilder
    //   1342: dup
    //   1343: invokespecial <init> : ()V
    //   1346: ldc 'lib/armeabi-v7a/'
    //   1348: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1351: aload #10
    //   1353: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1356: invokevirtual toString : ()Ljava/lang/String;
    //   1359: astore_1
    //   1360: goto -> 873
    //   1363: iload #6
    //   1365: ifeq -> 1541
    //   1368: iload #8
    //   1370: ifeq -> 1706
    //   1373: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1376: new java/lang/StringBuilder
    //   1379: dup
    //   1380: invokespecial <init> : ()V
    //   1383: ldc 'lib/mips/'
    //   1385: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1388: aload #10
    //   1390: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1393: invokevirtual toString : ()Ljava/lang/String;
    //   1396: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1399: ifne -> 1706
    //   1402: new java/lang/StringBuilder
    //   1405: dup
    //   1406: invokespecial <init> : ()V
    //   1409: ldc 'lib/mips/'
    //   1411: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1414: aload #10
    //   1416: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1419: invokevirtual toString : ()Ljava/lang/String;
    //   1422: astore_3
    //   1423: iconst_1
    //   1424: istore #5
    //   1426: aload_3
    //   1427: astore_1
    //   1428: iload #5
    //   1430: ifne -> 873
    //   1433: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1436: new java/lang/StringBuilder
    //   1439: dup
    //   1440: invokespecial <init> : ()V
    //   1443: ldc 'lib/armeabi/'
    //   1445: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1448: aload #10
    //   1450: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1453: invokevirtual toString : ()Ljava/lang/String;
    //   1456: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1459: ifne -> 1486
    //   1462: new java/lang/StringBuilder
    //   1465: dup
    //   1466: invokespecial <init> : ()V
    //   1469: ldc 'lib/armeabi/'
    //   1471: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1474: aload #10
    //   1476: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1479: invokevirtual toString : ()Ljava/lang/String;
    //   1482: astore_1
    //   1483: goto -> 873
    //   1486: aload_3
    //   1487: astore_1
    //   1488: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1491: new java/lang/StringBuilder
    //   1494: dup
    //   1495: invokespecial <init> : ()V
    //   1498: ldc 'lib/armeabi-v7a/'
    //   1500: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1503: aload #10
    //   1505: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1508: invokevirtual toString : ()Ljava/lang/String;
    //   1511: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1514: ifne -> 873
    //   1517: new java/lang/StringBuilder
    //   1520: dup
    //   1521: invokespecial <init> : ()V
    //   1524: ldc 'lib/armeabi-v7a/'
    //   1526: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1529: aload #10
    //   1531: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1534: invokevirtual toString : ()Ljava/lang/String;
    //   1537: astore_1
    //   1538: goto -> 873
    //   1541: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1544: new java/lang/StringBuilder
    //   1547: dup
    //   1548: invokespecial <init> : ()V
    //   1551: ldc 'lib/x86/'
    //   1553: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1556: aload #10
    //   1558: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1561: invokevirtual toString : ()Ljava/lang/String;
    //   1564: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1567: ifne -> 1594
    //   1570: new java/lang/StringBuilder
    //   1573: dup
    //   1574: invokespecial <init> : ()V
    //   1577: ldc 'lib/x86/'
    //   1579: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1582: aload #10
    //   1584: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1587: invokevirtual toString : ()Ljava/lang/String;
    //   1590: astore_1
    //   1591: goto -> 873
    //   1594: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1597: new java/lang/StringBuilder
    //   1600: dup
    //   1601: invokespecial <init> : ()V
    //   1604: ldc 'lib/armeabi/'
    //   1606: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1609: aload #10
    //   1611: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1614: invokevirtual toString : ()Ljava/lang/String;
    //   1617: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1620: ifne -> 1647
    //   1623: new java/lang/StringBuilder
    //   1626: dup
    //   1627: invokespecial <init> : ()V
    //   1630: ldc 'lib/armeabi/'
    //   1632: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1635: aload #10
    //   1637: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1640: invokevirtual toString : ()Ljava/lang/String;
    //   1643: astore_1
    //   1644: goto -> 873
    //   1647: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1650: new java/lang/StringBuilder
    //   1653: dup
    //   1654: invokespecial <init> : ()V
    //   1657: ldc 'lib/armeabi-v7a/'
    //   1659: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1662: aload #10
    //   1664: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1667: invokevirtual toString : ()Ljava/lang/String;
    //   1670: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1673: ifne -> 1700
    //   1676: new java/lang/StringBuilder
    //   1679: dup
    //   1680: invokespecial <init> : ()V
    //   1683: ldc 'lib/armeabi-v7a/'
    //   1685: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1688: aload #10
    //   1690: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1693: invokevirtual toString : ()Ljava/lang/String;
    //   1696: astore_1
    //   1697: goto -> 873
    //   1700: ldc ''
    //   1702: astore_1
    //   1703: goto -> 873
    //   1706: iconst_0
    //   1707: istore #5
    //   1709: ldc ''
    //   1711: astore_3
    //   1712: goto -> 1426
    // Exception table:
    //   from	to	target	type
    //   340	409	754	java/io/IOException
    //   884	918	921	java/io/IOException
  }
  
  private boolean b(Context paramContext) {
    boolean bool = false;
    if (paramContext != null) {
      f = paramContext;
      mPKName = getBaseContext().getPackageName();
      PackageManager.NameNotFoundException nameNotFoundException = null;
      try {
        ApplicationInfo applicationInfo = paramContext.getPackageManager().getApplicationInfo(mPKName, 128);
        if (applicationInfo != null) {
          mOldAPPName = applicationInfo.metaData.getString("TxAppEntry");
          mSrcPath = (f.getApplicationInfo()).sourceDir;
          try {
            i = (f.getPackageManager().getPackageInfo(mPKName, 0)).versionName;
            mVerFilePath = "/data/data/";
            mVerFilePath += mPKName;
            mVerFilePath += "/tx_shell/";
            a = mVerFilePath;
            File file = new File(mVerFilePath);
            if (!file.exists())
              file.mkdir(); 
            g = mVerFilePath + "libshella.so";
            h = mVerFilePath + "libshellb.so";
            mSocPath = mVerFilePath + "libshellc.so";
            mVerFilePath += g();
            bool = true;
          } catch (Exception exception) {}
        } 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException1) {
        nameNotFoundException1 = nameNotFoundException;
      } 
    } 
    return bool;
  }
  
  private String c() {
    return "2.9.1.2";
  }
  
  private void c(Context paramContext) {
    String str = i;
    if (!"1258609889".equals("user_bugly_appid")) {
      CrashReport.UserStrategy userStrategy = new CrashReport.UserStrategy(paramContext);
      userStrategy.setAppVersion(str);
      userStrategy.setEnableUserInfo(false);
      userStrategy.setRecordUserInfoOnceADay(true);
      CrashReport.setSdkExtraData(paramContext, "1258609889", str);
      CrashReport.initCrashReport(paramContext, "1258609889", false, userStrategy);
    } 
  }
  
  private static native void changeEnv(Context paramContext);
  
  private String d() {
    return "";
  }
  
  private void d(Context paramContext) {
    AssetManager assetManager = paramContext.getAssets();
    String str = (paramContext.getApplicationInfo()).sourceDir;
    try {
      System.loadLibrary("nfix");
      fixNativeResource(assetManager, str);
    } catch (Throwable throwable) {}
    try {
      System.loadLibrary("ufix");
      fixUnityResource(assetManager, str);
    } catch (Throwable throwable) {}
  }
  
  private void e() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getApplicationInfo : ()Landroid/content/pm/ApplicationInfo;
    //   4: astore_1
    //   5: aload_1
    //   6: getfield dataDir : Ljava/lang/String;
    //   9: astore_2
    //   10: new java/lang/StringBuilder
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: aload_2
    //   18: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   21: ldc '/tx_shell'
    //   23: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   26: invokevirtual toString : ()Ljava/lang/String;
    //   29: astore_3
    //   30: aload_1
    //   31: getfield sourceDir : Ljava/lang/String;
    //   34: putstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   37: getstatic android/os/Build$VERSION.SDK_INT : I
    //   40: istore #4
    //   42: iconst_0
    //   43: istore #5
    //   45: iload #4
    //   47: bipush #19
    //   49: if_icmpge -> 422
    //   52: iload #5
    //   54: istore #4
    //   56: aconst_null
    //   57: astore_2
    //   58: getstatic android/os/Build$VERSION.SDK_INT : I
    //   61: bipush #21
    //   63: if_icmpge -> 70
    //   66: getstatic android/os/Build.CPU_ABI : Ljava/lang/String;
    //   69: astore_2
    //   70: aload_2
    //   71: ifnull -> 85
    //   74: aload_2
    //   75: astore #6
    //   77: aload_2
    //   78: invokevirtual length : ()I
    //   81: iconst_2
    //   82: if_icmpge -> 103
    //   85: aload_2
    //   86: astore #6
    //   88: getstatic android/os/Build$VERSION.SDK_INT : I
    //   91: bipush #21
    //   93: if_icmplt -> 103
    //   96: getstatic android/os/Build.SUPPORTED_ABIS : [Ljava/lang/String;
    //   99: iconst_0
    //   100: aaload
    //   101: astore #6
    //   103: iconst_1
    //   104: istore #7
    //   106: iconst_1
    //   107: istore #8
    //   109: aload #6
    //   111: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   114: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   117: ldc 'x86'
    //   119: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   122: ifeq -> 482
    //   125: iconst_0
    //   126: istore #5
    //   128: iconst_0
    //   129: istore #7
    //   131: aload #6
    //   133: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   136: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   139: ldc 'mips'
    //   141: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   144: ifeq -> 150
    //   147: iconst_1
    //   148: istore #7
    //   150: getstatic android/os/Build$VERSION.SDK_INT : I
    //   153: bipush #8
    //   155: if_icmple -> 547
    //   158: aload_1
    //   159: getfield nativeLibraryDir : Ljava/lang/String;
    //   162: astore_2
    //   163: ldc ''
    //   165: astore #9
    //   167: iload #5
    //   169: ifeq -> 577
    //   172: new java/lang/StringBuilder
    //   175: dup
    //   176: invokespecial <init> : ()V
    //   179: invokestatic f : ()Ljava/lang/String;
    //   182: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   185: ldc_w '-'
    //   188: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   191: aload_0
    //   192: invokespecial c : ()Ljava/lang/String;
    //   195: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   198: invokevirtual toString : ()Ljava/lang/String;
    //   201: astore_1
    //   202: new java/lang/StringBuilder
    //   205: dup
    //   206: invokespecial <init> : ()V
    //   209: ldc ''
    //   211: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   214: ldc 'lib'
    //   216: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   219: aload_1
    //   220: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   223: ldc '.so'
    //   225: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   228: invokevirtual toString : ()Ljava/lang/String;
    //   231: astore #10
    //   233: new java/lang/StringBuilder
    //   236: dup
    //   237: invokespecial <init> : ()V
    //   240: ldc ''
    //   242: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   245: ldc 'lib'
    //   247: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   250: aload #9
    //   252: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   255: ldc '.so'
    //   257: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   260: invokevirtual toString : ()Ljava/lang/String;
    //   263: astore #9
    //   265: new java/io/File
    //   268: dup
    //   269: new java/lang/StringBuilder
    //   272: dup
    //   273: invokespecial <init> : ()V
    //   276: aload_2
    //   277: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   280: ldc '/'
    //   282: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   285: aload #10
    //   287: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   290: invokevirtual toString : ()Ljava/lang/String;
    //   293: invokespecial <init> : (Ljava/lang/String;)V
    //   296: astore #11
    //   298: new java/io/File
    //   301: dup
    //   302: new java/lang/StringBuilder
    //   305: dup
    //   306: invokespecial <init> : ()V
    //   309: aload_3
    //   310: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   313: ldc '/'
    //   315: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   318: aload #9
    //   320: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   323: invokevirtual toString : ()Ljava/lang/String;
    //   326: invokespecial <init> : (Ljava/lang/String;)V
    //   329: astore_2
    //   330: iload #5
    //   332: ifne -> 784
    //   335: getstatic android/os/Build$VERSION.SDK_INT : I
    //   338: bipush #19
    //   340: if_icmpge -> 784
    //   343: aload_2
    //   344: invokevirtual exists : ()Z
    //   347: ifeq -> 635
    //   350: invokestatic getRuntime : ()Ljava/lang/Runtime;
    //   353: astore #6
    //   355: new java/lang/StringBuilder
    //   358: astore_2
    //   359: aload_2
    //   360: invokespecial <init> : ()V
    //   363: aload #6
    //   365: aload_2
    //   366: ldc 'chmod 700 '
    //   368: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   371: aload_3
    //   372: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   375: ldc '/'
    //   377: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   380: aload #9
    //   382: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   385: invokevirtual toString : ()Ljava/lang/String;
    //   388: invokevirtual exec : (Ljava/lang/String;)Ljava/lang/Process;
    //   391: pop
    //   392: new java/lang/StringBuilder
    //   395: astore_2
    //   396: aload_2
    //   397: invokespecial <init> : ()V
    //   400: aload_2
    //   401: aload_3
    //   402: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   405: ldc '/'
    //   407: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   410: aload #9
    //   412: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   415: invokevirtual toString : ()Ljava/lang/String;
    //   418: invokestatic load : (Ljava/lang/String;)V
    //   421: return
    //   422: iload #4
    //   424: bipush #19
    //   426: if_icmple -> 457
    //   429: getstatic android/os/Build.SUPPORTED_64_BIT_ABIS : [Ljava/lang/String;
    //   432: astore_2
    //   433: iload #5
    //   435: istore #4
    //   437: aload_2
    //   438: ifnull -> 56
    //   441: iload #5
    //   443: istore #4
    //   445: aload_2
    //   446: arraylength
    //   447: iconst_1
    //   448: if_icmple -> 56
    //   451: iconst_1
    //   452: istore #4
    //   454: goto -> 56
    //   457: iload #5
    //   459: istore #4
    //   461: new java/io/File
    //   464: dup
    //   465: ldc '/system/lib64'
    //   467: invokespecial <init> : (Ljava/lang/String;)V
    //   470: invokevirtual exists : ()Z
    //   473: ifeq -> 56
    //   476: iconst_1
    //   477: istore #4
    //   479: goto -> 56
    //   482: iload #8
    //   484: istore #5
    //   486: getstatic android/os/Build$VERSION.SDK_INT : I
    //   489: bipush #21
    //   491: if_icmplt -> 128
    //   494: getstatic android/os/Build.SUPPORTED_ABIS : [Ljava/lang/String;
    //   497: astore_2
    //   498: iload #8
    //   500: istore #5
    //   502: aload_2
    //   503: ifnull -> 128
    //   506: iconst_0
    //   507: istore #8
    //   509: iload #7
    //   511: istore #5
    //   513: iload #8
    //   515: aload_2
    //   516: arraylength
    //   517: if_icmpge -> 128
    //   520: aload_2
    //   521: iload #8
    //   523: aaload
    //   524: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   527: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   530: ldc 'x86'
    //   532: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   535: ifeq -> 541
    //   538: iconst_0
    //   539: istore #7
    //   541: iinc #8, 1
    //   544: goto -> 509
    //   547: new java/lang/StringBuilder
    //   550: dup
    //   551: invokespecial <init> : ()V
    //   554: ldc '/data/data/'
    //   556: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   559: getstatic com/tencent/StubShell/TxAppEntry.mPKName : Ljava/lang/String;
    //   562: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   565: ldc '/lib'
    //   567: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   570: invokevirtual toString : ()Ljava/lang/String;
    //   573: astore_2
    //   574: goto -> 163
    //   577: new java/lang/StringBuilder
    //   580: dup
    //   581: invokespecial <init> : ()V
    //   584: ldc_w 'shellx-'
    //   587: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   590: aload_0
    //   591: invokespecial c : ()Ljava/lang/String;
    //   594: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   597: invokevirtual toString : ()Ljava/lang/String;
    //   600: astore_1
    //   601: new java/lang/StringBuilder
    //   604: dup
    //   605: invokespecial <init> : ()V
    //   608: invokestatic f : ()Ljava/lang/String;
    //   611: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   614: ldc_w '-'
    //   617: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   620: aload_0
    //   621: invokespecial c : ()Ljava/lang/String;
    //   624: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   627: invokevirtual toString : ()Ljava/lang/String;
    //   630: astore #9
    //   632: goto -> 202
    //   635: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   638: new java/lang/StringBuilder
    //   641: dup
    //   642: invokespecial <init> : ()V
    //   645: ldc 'lib/armeabi/'
    //   647: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   650: aload #9
    //   652: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   655: invokevirtual toString : ()Ljava/lang/String;
    //   658: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   661: ifne -> 720
    //   664: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   667: new java/lang/StringBuilder
    //   670: dup
    //   671: invokespecial <init> : ()V
    //   674: ldc 'lib/armeabi/'
    //   676: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   679: aload #9
    //   681: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   684: invokevirtual toString : ()Ljava/lang/String;
    //   687: new java/lang/StringBuilder
    //   690: dup
    //   691: invokespecial <init> : ()V
    //   694: aload_3
    //   695: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   698: ldc '/'
    //   700: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   703: aload #9
    //   705: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   708: invokevirtual toString : ()Ljava/lang/String;
    //   711: invokestatic extract : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   714: ifne -> 350
    //   717: goto -> 350
    //   720: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   723: new java/lang/StringBuilder
    //   726: dup
    //   727: invokespecial <init> : ()V
    //   730: ldc 'lib/armeabi-v7a/'
    //   732: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   735: aload #9
    //   737: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   740: invokevirtual toString : ()Ljava/lang/String;
    //   743: new java/lang/StringBuilder
    //   746: dup
    //   747: invokespecial <init> : ()V
    //   750: aload_3
    //   751: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   754: ldc '/'
    //   756: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   759: aload #9
    //   761: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   764: invokevirtual toString : ()Ljava/lang/String;
    //   767: invokestatic extract : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   770: ifne -> 350
    //   773: goto -> 350
    //   776: astore_2
    //   777: aload_2
    //   778: invokevirtual printStackTrace : ()V
    //   781: goto -> 421
    //   784: aload #11
    //   786: invokevirtual exists : ()Z
    //   789: ifeq -> 799
    //   792: aload_1
    //   793: invokestatic loadLibrary : (Ljava/lang/String;)V
    //   796: goto -> 421
    //   799: ldc ''
    //   801: astore_2
    //   802: new java/lang/StringBuilder
    //   805: dup
    //   806: invokespecial <init> : ()V
    //   809: aload_3
    //   810: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   813: ldc '/'
    //   815: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   818: aload #10
    //   820: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   823: invokevirtual toString : ()Ljava/lang/String;
    //   826: astore_1
    //   827: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   830: new java/lang/StringBuilder
    //   833: dup
    //   834: invokespecial <init> : ()V
    //   837: ldc 'lib/'
    //   839: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   842: aload #6
    //   844: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   847: ldc '/'
    //   849: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   852: aload #10
    //   854: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   857: invokevirtual toString : ()Ljava/lang/String;
    //   860: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   863: ifne -> 955
    //   866: new java/lang/StringBuilder
    //   869: dup
    //   870: invokespecial <init> : ()V
    //   873: ldc 'lib/'
    //   875: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   878: aload #6
    //   880: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   883: ldc '/'
    //   885: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   888: aload #10
    //   890: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   893: invokevirtual toString : ()Ljava/lang/String;
    //   896: astore_2
    //   897: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   900: aload_2
    //   901: aload_1
    //   902: invokestatic extract : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   905: ifne -> 421
    //   908: invokestatic getRuntime : ()Ljava/lang/Runtime;
    //   911: astore #6
    //   913: new java/lang/StringBuilder
    //   916: astore_2
    //   917: aload_2
    //   918: invokespecial <init> : ()V
    //   921: aload #6
    //   923: aload_2
    //   924: ldc 'chmod 700 '
    //   926: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   929: aload_1
    //   930: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   933: invokevirtual toString : ()Ljava/lang/String;
    //   936: invokevirtual exec : (Ljava/lang/String;)Ljava/lang/Process;
    //   939: pop
    //   940: aload_1
    //   941: invokestatic load : (Ljava/lang/String;)V
    //   944: goto -> 421
    //   947: astore_2
    //   948: aload_2
    //   949: invokevirtual printStackTrace : ()V
    //   952: goto -> 421
    //   955: iload #4
    //   957: ifeq -> 1910
    //   960: iload #5
    //   962: ifeq -> 1124
    //   965: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   968: new java/lang/StringBuilder
    //   971: dup
    //   972: invokespecial <init> : ()V
    //   975: ldc 'lib/arm64-v8a/'
    //   977: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   980: aload #10
    //   982: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   985: invokevirtual toString : ()Ljava/lang/String;
    //   988: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   991: ifne -> 1018
    //   994: new java/lang/StringBuilder
    //   997: dup
    //   998: invokespecial <init> : ()V
    //   1001: ldc 'lib/arm64-v8a/'
    //   1003: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1006: aload #10
    //   1008: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1011: invokevirtual toString : ()Ljava/lang/String;
    //   1014: astore_2
    //   1015: goto -> 897
    //   1018: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1021: new java/lang/StringBuilder
    //   1024: dup
    //   1025: invokespecial <init> : ()V
    //   1028: ldc 'lib/armeabi/'
    //   1030: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1033: aload #10
    //   1035: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1038: invokevirtual toString : ()Ljava/lang/String;
    //   1041: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1044: ifne -> 1071
    //   1047: new java/lang/StringBuilder
    //   1050: dup
    //   1051: invokespecial <init> : ()V
    //   1054: ldc 'lib/armeabi/'
    //   1056: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1059: aload #10
    //   1061: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1064: invokevirtual toString : ()Ljava/lang/String;
    //   1067: astore_2
    //   1068: goto -> 897
    //   1071: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1074: new java/lang/StringBuilder
    //   1077: dup
    //   1078: invokespecial <init> : ()V
    //   1081: ldc 'lib/armeabi-v7a/'
    //   1083: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1086: aload #10
    //   1088: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1091: invokevirtual toString : ()Ljava/lang/String;
    //   1094: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1097: ifne -> 897
    //   1100: new java/lang/StringBuilder
    //   1103: dup
    //   1104: invokespecial <init> : ()V
    //   1107: ldc 'lib/armeabi-v7a/'
    //   1109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1112: aload #10
    //   1114: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1117: invokevirtual toString : ()Ljava/lang/String;
    //   1120: astore_2
    //   1121: goto -> 897
    //   1124: getstatic android/os/Build$VERSION.SDK_INT : I
    //   1127: bipush #21
    //   1129: if_icmplt -> 2266
    //   1132: getstatic android/os/Build.SUPPORTED_ABIS : [Ljava/lang/String;
    //   1135: astore_2
    //   1136: aload_2
    //   1137: ifnull -> 2266
    //   1140: iconst_0
    //   1141: istore #4
    //   1143: iload #4
    //   1145: aload_2
    //   1146: arraylength
    //   1147: if_icmpge -> 2266
    //   1150: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1153: new java/lang/StringBuilder
    //   1156: dup
    //   1157: invokespecial <init> : ()V
    //   1160: ldc 'lib/'
    //   1162: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1165: aload_2
    //   1166: iload #4
    //   1168: aaload
    //   1169: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   1172: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   1175: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1178: ldc '/'
    //   1180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1183: aload #9
    //   1185: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1188: invokevirtual toString : ()Ljava/lang/String;
    //   1191: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1194: ifeq -> 1244
    //   1197: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1200: new java/lang/StringBuilder
    //   1203: dup
    //   1204: invokespecial <init> : ()V
    //   1207: ldc 'lib/'
    //   1209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1212: aload_2
    //   1213: iload #4
    //   1215: aaload
    //   1216: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   1219: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   1222: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1225: ldc '/'
    //   1227: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1230: aload #10
    //   1232: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1235: invokevirtual toString : ()Ljava/lang/String;
    //   1238: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1241: ifne -> 1685
    //   1244: aload_2
    //   1245: iload #4
    //   1247: aaload
    //   1248: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   1251: invokevirtual toLowerCase : (Ljava/util/Locale;)Ljava/lang/String;
    //   1254: astore_2
    //   1255: iconst_1
    //   1256: istore #4
    //   1258: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1261: new java/lang/StringBuilder
    //   1264: dup
    //   1265: invokespecial <init> : ()V
    //   1268: ldc 'lib/x86_64/'
    //   1270: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1273: aload #10
    //   1275: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1278: invokevirtual toString : ()Ljava/lang/String;
    //   1281: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1284: ifne -> 1381
    //   1287: new java/lang/StringBuilder
    //   1290: dup
    //   1291: invokespecial <init> : ()V
    //   1294: ldc 'lib/x86_64/'
    //   1296: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1299: aload #10
    //   1301: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1304: invokevirtual toString : ()Ljava/lang/String;
    //   1307: astore_2
    //   1308: getstatic android/os/Build$VERSION.SDK_INT : I
    //   1311: bipush #21
    //   1313: if_icmplt -> 1324
    //   1316: aload_2
    //   1317: astore #6
    //   1319: iload #4
    //   1321: ifne -> 1375
    //   1324: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1327: new java/lang/StringBuilder
    //   1330: dup
    //   1331: invokespecial <init> : ()V
    //   1334: ldc 'lib/x86_64/'
    //   1336: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1339: aload #10
    //   1341: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1344: invokevirtual toString : ()Ljava/lang/String;
    //   1347: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1350: ifne -> 1691
    //   1353: new java/lang/StringBuilder
    //   1356: dup
    //   1357: invokespecial <init> : ()V
    //   1360: ldc 'lib/x86_64/'
    //   1362: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1365: aload #10
    //   1367: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1370: invokevirtual toString : ()Ljava/lang/String;
    //   1373: astore #6
    //   1375: aload #6
    //   1377: astore_2
    //   1378: goto -> 897
    //   1381: aload_2
    //   1382: ldc_w 'arm64-v8a'
    //   1385: invokevirtual compareTo : (Ljava/lang/String;)I
    //   1388: ifne -> 1444
    //   1391: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1394: new java/lang/StringBuilder
    //   1397: dup
    //   1398: invokespecial <init> : ()V
    //   1401: ldc 'lib/arm64-v8a/'
    //   1403: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1406: aload #10
    //   1408: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1411: invokevirtual toString : ()Ljava/lang/String;
    //   1414: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1417: ifne -> 2260
    //   1420: new java/lang/StringBuilder
    //   1423: dup
    //   1424: invokespecial <init> : ()V
    //   1427: ldc 'lib/arm64-v8a/'
    //   1429: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1432: aload #10
    //   1434: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1437: invokevirtual toString : ()Ljava/lang/String;
    //   1440: astore_2
    //   1441: goto -> 1308
    //   1444: aload_2
    //   1445: ldc 'x86'
    //   1447: invokevirtual compareTo : (Ljava/lang/String;)I
    //   1450: ifne -> 1506
    //   1453: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1456: new java/lang/StringBuilder
    //   1459: dup
    //   1460: invokespecial <init> : ()V
    //   1463: ldc 'lib/x86/'
    //   1465: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1468: aload #10
    //   1470: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1473: invokevirtual toString : ()Ljava/lang/String;
    //   1476: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1479: ifne -> 2260
    //   1482: new java/lang/StringBuilder
    //   1485: dup
    //   1486: invokespecial <init> : ()V
    //   1489: ldc 'lib/x86/'
    //   1491: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1494: aload #10
    //   1496: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1499: invokevirtual toString : ()Ljava/lang/String;
    //   1502: astore_2
    //   1503: goto -> 1308
    //   1506: aload_2
    //   1507: ldc_w 'armeabi-v7a'
    //   1510: invokevirtual compareTo : (Ljava/lang/String;)I
    //   1513: ifeq -> 1526
    //   1516: aload_2
    //   1517: ldc_w 'armeabi'
    //   1520: invokevirtual compareTo : (Ljava/lang/String;)I
    //   1523: ifne -> 2260
    //   1526: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1529: new java/lang/StringBuilder
    //   1532: dup
    //   1533: invokespecial <init> : ()V
    //   1536: ldc 'lib/x86/'
    //   1538: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1541: aload #10
    //   1543: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1546: invokevirtual toString : ()Ljava/lang/String;
    //   1549: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1552: ifne -> 1579
    //   1555: new java/lang/StringBuilder
    //   1558: dup
    //   1559: invokespecial <init> : ()V
    //   1562: ldc 'lib/x86/'
    //   1564: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1567: aload #10
    //   1569: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1572: invokevirtual toString : ()Ljava/lang/String;
    //   1575: astore_2
    //   1576: goto -> 1308
    //   1579: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1582: new java/lang/StringBuilder
    //   1585: dup
    //   1586: invokespecial <init> : ()V
    //   1589: ldc 'lib/armeabi/'
    //   1591: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1594: aload #10
    //   1596: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1599: invokevirtual toString : ()Ljava/lang/String;
    //   1602: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1605: ifne -> 1632
    //   1608: new java/lang/StringBuilder
    //   1611: dup
    //   1612: invokespecial <init> : ()V
    //   1615: ldc 'lib/armeabi/'
    //   1617: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1620: aload #10
    //   1622: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1625: invokevirtual toString : ()Ljava/lang/String;
    //   1628: astore_2
    //   1629: goto -> 1308
    //   1632: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1635: new java/lang/StringBuilder
    //   1638: dup
    //   1639: invokespecial <init> : ()V
    //   1642: ldc 'lib/armeabi-v7a/'
    //   1644: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1647: aload #10
    //   1649: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1652: invokevirtual toString : ()Ljava/lang/String;
    //   1655: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1658: ifne -> 2260
    //   1661: new java/lang/StringBuilder
    //   1664: dup
    //   1665: invokespecial <init> : ()V
    //   1668: ldc 'lib/armeabi-v7a/'
    //   1670: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1673: aload #10
    //   1675: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1678: invokevirtual toString : ()Ljava/lang/String;
    //   1681: astore_2
    //   1682: goto -> 1308
    //   1685: iinc #4, 1
    //   1688: goto -> 1143
    //   1691: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1694: new java/lang/StringBuilder
    //   1697: dup
    //   1698: invokespecial <init> : ()V
    //   1701: ldc 'lib/arm64-v8a/'
    //   1703: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1706: aload #10
    //   1708: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1711: invokevirtual toString : ()Ljava/lang/String;
    //   1714: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1717: ifne -> 1745
    //   1720: new java/lang/StringBuilder
    //   1723: dup
    //   1724: invokespecial <init> : ()V
    //   1727: ldc 'lib/arm64-v8a/'
    //   1729: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1732: aload #10
    //   1734: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1737: invokevirtual toString : ()Ljava/lang/String;
    //   1740: astore #6
    //   1742: goto -> 1375
    //   1745: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1748: new java/lang/StringBuilder
    //   1751: dup
    //   1752: invokespecial <init> : ()V
    //   1755: ldc 'lib/x86/'
    //   1757: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1760: aload #10
    //   1762: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1765: invokevirtual toString : ()Ljava/lang/String;
    //   1768: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1771: ifne -> 1799
    //   1774: new java/lang/StringBuilder
    //   1777: dup
    //   1778: invokespecial <init> : ()V
    //   1781: ldc 'lib/x86/'
    //   1783: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1786: aload #10
    //   1788: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1791: invokevirtual toString : ()Ljava/lang/String;
    //   1794: astore #6
    //   1796: goto -> 1375
    //   1799: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1802: new java/lang/StringBuilder
    //   1805: dup
    //   1806: invokespecial <init> : ()V
    //   1809: ldc 'lib/armeabi/'
    //   1811: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1814: aload #10
    //   1816: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1819: invokevirtual toString : ()Ljava/lang/String;
    //   1822: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1825: ifne -> 1853
    //   1828: new java/lang/StringBuilder
    //   1831: dup
    //   1832: invokespecial <init> : ()V
    //   1835: ldc 'lib/armeabi/'
    //   1837: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1840: aload #10
    //   1842: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1845: invokevirtual toString : ()Ljava/lang/String;
    //   1848: astore #6
    //   1850: goto -> 1375
    //   1853: aload_2
    //   1854: astore #6
    //   1856: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1859: new java/lang/StringBuilder
    //   1862: dup
    //   1863: invokespecial <init> : ()V
    //   1866: ldc 'lib/armeabi-v7a/'
    //   1868: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1871: aload #10
    //   1873: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1876: invokevirtual toString : ()Ljava/lang/String;
    //   1879: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1882: ifne -> 1375
    //   1885: new java/lang/StringBuilder
    //   1888: dup
    //   1889: invokespecial <init> : ()V
    //   1892: ldc 'lib/armeabi-v7a/'
    //   1894: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1897: aload #10
    //   1899: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1902: invokevirtual toString : ()Ljava/lang/String;
    //   1905: astore #6
    //   1907: goto -> 1375
    //   1910: iload #5
    //   1912: ifeq -> 2091
    //   1915: iload #7
    //   1917: ifeq -> 2250
    //   1920: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1923: new java/lang/StringBuilder
    //   1926: dup
    //   1927: invokespecial <init> : ()V
    //   1930: ldc 'lib/mips/'
    //   1932: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1935: aload #10
    //   1937: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1940: invokevirtual toString : ()Ljava/lang/String;
    //   1943: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   1946: ifne -> 2250
    //   1949: new java/lang/StringBuilder
    //   1952: dup
    //   1953: invokespecial <init> : ()V
    //   1956: ldc 'lib/mips/'
    //   1958: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1961: aload #10
    //   1963: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1966: invokevirtual toString : ()Ljava/lang/String;
    //   1969: astore #6
    //   1971: iconst_1
    //   1972: istore #4
    //   1974: aload #6
    //   1976: astore_2
    //   1977: iload #4
    //   1979: ifne -> 2032
    //   1982: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   1985: new java/lang/StringBuilder
    //   1988: dup
    //   1989: invokespecial <init> : ()V
    //   1992: ldc 'lib/armeabi/'
    //   1994: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1997: aload #10
    //   1999: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2002: invokevirtual toString : ()Ljava/lang/String;
    //   2005: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   2008: ifne -> 2035
    //   2011: new java/lang/StringBuilder
    //   2014: dup
    //   2015: invokespecial <init> : ()V
    //   2018: ldc 'lib/armeabi/'
    //   2020: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2023: aload #10
    //   2025: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2028: invokevirtual toString : ()Ljava/lang/String;
    //   2031: astore_2
    //   2032: goto -> 897
    //   2035: aload #6
    //   2037: astore_2
    //   2038: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   2041: new java/lang/StringBuilder
    //   2044: dup
    //   2045: invokespecial <init> : ()V
    //   2048: ldc 'lib/armeabi-v7a/'
    //   2050: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2053: aload #10
    //   2055: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2058: invokevirtual toString : ()Ljava/lang/String;
    //   2061: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   2064: ifne -> 2032
    //   2067: new java/lang/StringBuilder
    //   2070: dup
    //   2071: invokespecial <init> : ()V
    //   2074: ldc 'lib/armeabi-v7a/'
    //   2076: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2079: aload #10
    //   2081: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2084: invokevirtual toString : ()Ljava/lang/String;
    //   2087: astore_2
    //   2088: goto -> 2032
    //   2091: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   2094: new java/lang/StringBuilder
    //   2097: dup
    //   2098: invokespecial <init> : ()V
    //   2101: ldc 'lib/x86/'
    //   2103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2106: aload #10
    //   2108: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2111: invokevirtual toString : ()Ljava/lang/String;
    //   2114: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   2117: ifne -> 2144
    //   2120: new java/lang/StringBuilder
    //   2123: dup
    //   2124: invokespecial <init> : ()V
    //   2127: ldc 'lib/x86/'
    //   2129: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2132: aload #10
    //   2134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2137: invokevirtual toString : ()Ljava/lang/String;
    //   2140: astore_2
    //   2141: goto -> 897
    //   2144: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   2147: new java/lang/StringBuilder
    //   2150: dup
    //   2151: invokespecial <init> : ()V
    //   2154: ldc 'lib/armeabi/'
    //   2156: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2159: aload #10
    //   2161: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2164: invokevirtual toString : ()Ljava/lang/String;
    //   2167: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   2170: ifne -> 2197
    //   2173: new java/lang/StringBuilder
    //   2176: dup
    //   2177: invokespecial <init> : ()V
    //   2180: ldc 'lib/armeabi/'
    //   2182: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2185: aload #10
    //   2187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2190: invokevirtual toString : ()Ljava/lang/String;
    //   2193: astore_2
    //   2194: goto -> 897
    //   2197: getstatic com/tencent/StubShell/TxAppEntry.b : Ljava/lang/String;
    //   2200: new java/lang/StringBuilder
    //   2203: dup
    //   2204: invokespecial <init> : ()V
    //   2207: ldc 'lib/armeabi-v7a/'
    //   2209: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2212: aload #10
    //   2214: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2217: invokevirtual toString : ()Ljava/lang/String;
    //   2220: invokestatic exist : (Ljava/lang/String;Ljava/lang/String;)I
    //   2223: ifne -> 897
    //   2226: new java/lang/StringBuilder
    //   2229: dup
    //   2230: invokespecial <init> : ()V
    //   2233: ldc 'lib/armeabi-v7a/'
    //   2235: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2238: aload #10
    //   2240: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   2243: invokevirtual toString : ()Ljava/lang/String;
    //   2246: astore_2
    //   2247: goto -> 897
    //   2250: iconst_0
    //   2251: istore #4
    //   2253: ldc ''
    //   2255: astore #6
    //   2257: goto -> 1974
    //   2260: ldc ''
    //   2262: astore_2
    //   2263: goto -> 1308
    //   2266: iconst_0
    //   2267: istore #4
    //   2269: ldc ''
    //   2271: astore_2
    //   2272: goto -> 1308
    // Exception table:
    //   from	to	target	type
    //   350	421	776	java/io/IOException
    //   908	944	947	java/io/IOException
  }
  
  private static String f() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("sh");
    stringBuilder.append("el");
    stringBuilder.append("la");
    return stringBuilder.toString();
  }
  
  private static native void fixNativeResource(AssetManager paramAssetManager, String paramString);
  
  private static native void fixUnityResource(AssetManager paramAssetManager, String paramString);
  
  private static String g() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("sh");
    stringBuilder.append("el");
    stringBuilder.append("la");
    stringBuilder.append("_ve");
    stringBuilder.append("rs");
    stringBuilder.append("i");
    stringBuilder.append("on");
    return stringBuilder.toString();
  }
  
  private static native void load(Context paramContext);
  
  private static native void reciver(Intent paramIntent);
  
  private static native void runCreate(Context paramContext);
  
  public static native Enumeration txEntries(DexFile paramDexFile);
  
  public void a(Context paramContext) {
    e();
    load(f);
  }
  
  protected void attachBaseContext(Context paramContext) {
    super.attachBaseContext(paramContext);
    SystemClassLoaderInjector.fixAndroid(paramContext, this);
    if (b((Context)this)) {
      d(paramContext);
      this.k = new Handler(getMainLooper());
      CrashReport.UserStrategy userStrategy = new CrashReport.UserStrategy((Context)this);
      userStrategy.setAppVersion("2.9.1.2");
      CrashReport.setSdkExtraData((Context)this, "900015015", "2.9.1.2");
      CrashReport.initCrashReport((Context)this, "900015015", false, userStrategy);
      (new Thread(new d(this))).start();
      a((Context)this);
    } 
  }
  
  public String getPackageName() {
    // Byte code:
    //   0: new java/lang/Exception
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: invokevirtual getStackTrace : ()[Ljava/lang/StackTraceElement;
    //   10: astore_1
    //   11: aload_1
    //   12: arraylength
    //   13: istore_2
    //   14: iconst_0
    //   15: istore_3
    //   16: iload_3
    //   17: iload_2
    //   18: if_icmpge -> 245
    //   21: aload_1
    //   22: iload_3
    //   23: aaload
    //   24: astore #4
    //   26: aload #4
    //   28: invokevirtual getClassName : ()Ljava/lang/String;
    //   31: ldc_w 'android.app.ActivityThread'
    //   34: invokevirtual compareTo : (Ljava/lang/String;)I
    //   37: ifne -> 234
    //   40: aload #4
    //   42: invokevirtual getMethodName : ()Ljava/lang/String;
    //   45: ldc_w 'installProvider'
    //   48: invokevirtual compareTo : (Ljava/lang/String;)I
    //   51: ifne -> 234
    //   54: getstatic com/tencent/StubShell/TxAppEntry.d : I
    //   57: iconst_1
    //   58: iadd
    //   59: putstatic com/tencent/StubShell/TxAppEntry.d : I
    //   62: new java/lang/StringBuilder
    //   65: astore #4
    //   67: aload #4
    //   69: invokespecial <init> : ()V
    //   72: ldc 'SecShell'
    //   74: aload #4
    //   76: ldc_w 'getPackageName g_trickCount:'
    //   79: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   82: getstatic com/tencent/StubShell/TxAppEntry.d : I
    //   85: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   88: ldc_w ' mPKName:'
    //   91: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   94: getstatic com/tencent/StubShell/TxAppEntry.mPKName : Ljava/lang/String;
    //   97: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: invokevirtual toString : ()Ljava/lang/String;
    //   103: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   106: pop
    //   107: getstatic com/tencent/StubShell/TxAppEntry.d : I
    //   110: iconst_1
    //   111: if_icmpne -> 132
    //   114: getstatic com/tencent/StubShell/TxAppEntry.mPKName : Ljava/lang/String;
    //   117: ifnonnull -> 125
    //   120: ldc ''
    //   122: astore_1
    //   123: aload_1
    //   124: areturn
    //   125: getstatic com/tencent/StubShell/TxAppEntry.mPKName : Ljava/lang/String;
    //   128: astore_1
    //   129: goto -> 123
    //   132: getstatic com/tencent/StubShell/TxAppEntry.d : I
    //   135: iconst_1
    //   136: if_icmple -> 234
    //   139: new java/lang/StringBuilder
    //   142: astore #4
    //   144: aload #4
    //   146: invokespecial <init> : ()V
    //   149: ldc 'SecShell'
    //   151: aload #4
    //   153: ldc_w 'getPackageName change_flag:'
    //   156: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   159: getstatic com/tencent/StubShell/TxAppEntry.e : Z
    //   162: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   165: ldc_w ' ret:'
    //   168: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   171: getstatic com/tencent/StubShell/TxAppEntry.mPKName : Ljava/lang/String;
    //   174: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   177: ldc_w ' sp:'
    //   180: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: getstatic com/tencent/StubShell/TxAppEntry.j : Z
    //   186: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   189: invokevirtual toString : ()Ljava/lang/String;
    //   192: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   195: pop
    //   196: getstatic com/tencent/StubShell/TxAppEntry.e : Z
    //   199: ifne -> 234
    //   202: getstatic com/tencent/StubShell/TxAppEntry.j : Z
    //   205: ifne -> 234
    //   208: ldc 'SecShell'
    //   210: ldc_w 'getPackageName changeEnv call'
    //   213: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   216: pop
    //   217: aload_0
    //   218: invokestatic changeEnv : (Landroid/content/Context;)V
    //   221: ldc 'SecShell'
    //   223: ldc_w 'getPackageName changeEnv end'
    //   226: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   229: pop
    //   230: iconst_1
    //   231: putstatic com/tencent/StubShell/TxAppEntry.e : Z
    //   234: iinc #3, 1
    //   237: goto -> 16
    //   240: astore_1
    //   241: aload_1
    //   242: invokevirtual printStackTrace : ()V
    //   245: getstatic com/tencent/StubShell/TxAppEntry.mPKName : Ljava/lang/String;
    //   248: astore_1
    //   249: goto -> 123
    // Exception table:
    //   from	to	target	type
    //   11	14	240	java/lang/Throwable
    //   26	120	240	java/lang/Throwable
    //   125	129	240	java/lang/Throwable
    //   132	234	240	java/lang/Throwable
  }
  
  public void onCreate() {
    runCreate((Context)this);
    c(f);
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/StubShell/TxAppEntry.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */