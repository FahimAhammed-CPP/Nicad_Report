package com.tencent.StubShell;

import android.annotation.TargetApi;
import android.app.Application;
import android.content.Context;
import android.util.Log;
import dalvik.system.PathClassLoader;
import java.lang.reflect.Field;

@TargetApi(14)
class a extends PathClassLoader {
  private static Object a = null;
  
  private static String b = null;
  
  private a(String paramString, ClassLoader paramClassLoader, Application paramApplication) {
    super(paramString, paramClassLoader);
    try {
      b = paramApplication.getPackageCodePath();
    } catch (Throwable throwable) {
      Log.e("SecShell", "AndroidNClassLoader init:" + paramString, throwable);
    } 
  }
  
  public static ClassLoader a(ClassLoader paramClassLoader, Application paramApplication) {
    try {
      paramClassLoader = a("", paramClassLoader, paramApplication);
      a(paramApplication, paramClassLoader);
    } catch (Throwable throwable) {
      Log.e("SecShell", "AndroidNClassLoader inject", throwable);
      throwable = null;
    } 
    return (ClassLoader)throwable;
  }
  
  private static ClassLoader a(String paramString, ClassLoader paramClassLoader, Application paramApplication) {
    a a1;
    try {
      a a2 = new a();
      this(paramString, paramClassLoader, paramApplication);
      Field field = c.a(paramClassLoader, "pathList");
      Object object = field.get(paramClassLoader);
      field.set(a2, a(object, (ClassLoader)a2, false));
      c.a(object, "definingContext").set(object, a2);
      a = object;
      a1 = a2;
    } catch (Throwable throwable) {
      Log.e("SecShell", "AndroidNClassLoader createAndroidNClassLoader", throwable);
    } 
    return (ClassLoader)a1;
  }
  
  private static Object a(Object paramObject, ClassLoader paramClassLoader, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_4
    //   2: anewarray java/lang/Class
    //   5: dup
    //   6: iconst_0
    //   7: ldc java/lang/ClassLoader
    //   9: aastore
    //   10: dup
    //   11: iconst_1
    //   12: ldc java/lang/String
    //   14: aastore
    //   15: dup
    //   16: iconst_2
    //   17: ldc java/lang/String
    //   19: aastore
    //   20: dup
    //   21: iconst_3
    //   22: ldc java/io/File
    //   24: aastore
    //   25: invokestatic a : (Ljava/lang/Object;[Ljava/lang/Class;)Ljava/lang/reflect/Constructor;
    //   28: astore_3
    //   29: iload_2
    //   30: ifeq -> 61
    //   33: aload_3
    //   34: iconst_4
    //   35: anewarray java/lang/Object
    //   38: dup
    //   39: iconst_0
    //   40: aload_1
    //   41: aastore
    //   42: dup
    //   43: iconst_1
    //   44: ldc ''
    //   46: aastore
    //   47: dup
    //   48: iconst_2
    //   49: aconst_null
    //   50: aastore
    //   51: dup
    //   52: iconst_3
    //   53: aconst_null
    //   54: aastore
    //   55: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
    //   58: astore_0
    //   59: aload_0
    //   60: areturn
    //   61: aload_0
    //   62: ldc 'dexElements'
    //   64: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   67: aload_0
    //   68: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   71: checkcast [Ljava/lang/Object;
    //   74: astore #4
    //   76: aload_0
    //   77: ldc 'nativeLibraryDirectories'
    //   79: invokestatic a : (Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   82: aload_0
    //   83: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   86: checkcast java/util/List
    //   89: astore_0
    //   90: new java/lang/StringBuilder
    //   93: astore #5
    //   95: aload #5
    //   97: invokespecial <init> : ()V
    //   100: aload #4
    //   102: invokevirtual getClass : ()Ljava/lang/Class;
    //   105: invokevirtual getComponentType : ()Ljava/lang/Class;
    //   108: ldc 'dexFile'
    //   110: invokestatic a : (Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;
    //   113: astore #6
    //   115: iconst_1
    //   116: istore #7
    //   118: aload #4
    //   120: arraylength
    //   121: istore #8
    //   123: iconst_0
    //   124: istore #9
    //   126: iload #9
    //   128: iload #8
    //   130: if_icmpge -> 245
    //   133: aload #6
    //   135: aload #4
    //   137: iload #9
    //   139: aaload
    //   140: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   143: checkcast dalvik/system/DexFile
    //   146: astore #10
    //   148: iload #7
    //   150: istore #11
    //   152: aload #10
    //   154: ifnull -> 211
    //   157: aload #10
    //   159: invokevirtual getName : ()Ljava/lang/String;
    //   162: ifnonnull -> 171
    //   165: iinc #9, 1
    //   168: goto -> 126
    //   171: aload #10
    //   173: invokevirtual getName : ()Ljava/lang/String;
    //   176: getstatic com/tencent/StubShell/a.b : Ljava/lang/String;
    //   179: invokevirtual equals : (Ljava/lang/Object;)Z
    //   182: ifne -> 188
    //   185: goto -> 165
    //   188: iload #7
    //   190: ifeq -> 218
    //   193: iconst_0
    //   194: istore #7
    //   196: aload #5
    //   198: aload #10
    //   200: invokevirtual getName : ()Ljava/lang/String;
    //   203: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   206: pop
    //   207: iload #7
    //   209: istore #11
    //   211: iload #11
    //   213: istore #7
    //   215: goto -> 165
    //   218: aload #5
    //   220: getstatic java/io/File.pathSeparator : Ljava/lang/String;
    //   223: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   226: pop
    //   227: goto -> 196
    //   230: astore_0
    //   231: ldc 'SecShell'
    //   233: ldc 'AndroidNClassLoader recreateDexPathList'
    //   235: aload_0
    //   236: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   239: pop
    //   240: aconst_null
    //   241: astore_0
    //   242: goto -> 59
    //   245: aload #5
    //   247: invokevirtual toString : ()Ljava/lang/String;
    //   250: astore #4
    //   252: new java/lang/StringBuilder
    //   255: astore #6
    //   257: aload #6
    //   259: invokespecial <init> : ()V
    //   262: ldc 'SecShell'
    //   264: aload #6
    //   266: ldc 'recreateDexPathList dexPath:'
    //   268: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   271: aload #4
    //   273: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   276: invokevirtual toString : ()Ljava/lang/String;
    //   279: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   282: pop
    //   283: new java/lang/StringBuilder
    //   286: astore #6
    //   288: aload #6
    //   290: invokespecial <init> : ()V
    //   293: aload_0
    //   294: invokeinterface iterator : ()Ljava/util/Iterator;
    //   299: astore_0
    //   300: iconst_1
    //   301: istore #7
    //   303: aload_0
    //   304: invokeinterface hasNext : ()Z
    //   309: ifeq -> 362
    //   312: aload_0
    //   313: invokeinterface next : ()Ljava/lang/Object;
    //   318: checkcast java/io/File
    //   321: astore #10
    //   323: aload #10
    //   325: ifnull -> 303
    //   328: iload #7
    //   330: ifeq -> 350
    //   333: iconst_0
    //   334: istore #7
    //   336: aload #6
    //   338: aload #10
    //   340: invokevirtual getAbsolutePath : ()Ljava/lang/String;
    //   343: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   346: pop
    //   347: goto -> 303
    //   350: aload #6
    //   352: getstatic java/io/File.pathSeparator : Ljava/lang/String;
    //   355: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   358: pop
    //   359: goto -> 336
    //   362: aload_3
    //   363: iconst_4
    //   364: anewarray java/lang/Object
    //   367: dup
    //   368: iconst_0
    //   369: aload_1
    //   370: aastore
    //   371: dup
    //   372: iconst_1
    //   373: aload #4
    //   375: aastore
    //   376: dup
    //   377: iconst_2
    //   378: aload #6
    //   380: invokevirtual toString : ()Ljava/lang/String;
    //   383: aastore
    //   384: dup
    //   385: iconst_3
    //   386: aconst_null
    //   387: aastore
    //   388: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
    //   391: astore_0
    //   392: goto -> 59
    // Exception table:
    //   from	to	target	type
    //   0	29	230	java/lang/Throwable
    //   33	59	230	java/lang/Throwable
    //   61	115	230	java/lang/Throwable
    //   118	123	230	java/lang/Throwable
    //   133	148	230	java/lang/Throwable
    //   157	165	230	java/lang/Throwable
    //   171	185	230	java/lang/Throwable
    //   196	207	230	java/lang/Throwable
    //   218	227	230	java/lang/Throwable
    //   245	300	230	java/lang/Throwable
    //   303	323	230	java/lang/Throwable
    //   336	347	230	java/lang/Throwable
    //   350	359	230	java/lang/Throwable
    //   362	392	230	java/lang/Throwable
  }
  
  private static void a(Application paramApplication, ClassLoader paramClassLoader) {
    try {
      Context context = (Context)c.a(paramApplication, "mBase").get(paramApplication);
      Object object = c.a(context, "mPackageInfo").get(context);
      c.a(object, "mClassLoader").set(object, paramClassLoader);
    } catch (Throwable throwable) {
      Log.e("SecShell", "AndroidNClassLoader reflectPackageInfoClassloader", throwable);
    } 
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/StubShell/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */