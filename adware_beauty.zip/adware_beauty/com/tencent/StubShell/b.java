package com.tencent.StubShell;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;

public class b {
  private static final char[] a = new char[] { 
      '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
      'A', 'B', 'C', 'D', 'E', 'F' };
  
  public static String a(InputStream paramInputStream) {
    String str1;
    String str2 = "";
    byte[] arrayOfByte = new byte[8192];
    try {
      MessageDigest messageDigest = MessageDigest.getInstance("MD5");
      while (true) {
        int i = paramInputStream.read(arrayOfByte);
        if (i > 0) {
          messageDigest.update(arrayOfByte, 0, i);
          continue;
        } 
        return a(messageDigest.digest());
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
      str1 = str2;
    } 
    return str1;
  }
  
  public static String a(String paramString) {
    try {
      String str;
      FileInputStream fileInputStream = new FileInputStream();
      this(paramString);
      try {
        paramString = a(fileInputStream);
        FileInputStream fileInputStream1 = fileInputStream;
        str = paramString;
        if (fileInputStream1 != null)
          try {
            fileInputStream1.close();
          } catch (IOException iOException) {
            iOException.printStackTrace();
          }  
        return str;
      } catch (Exception null) {
        paramString = str;
      } 
    } catch (Exception exception) {
      paramString = null;
    } 
    exception.printStackTrace();
    String str1 = "";
    String str2 = paramString;
    if (str2 != null)
      try {
        str2.close();
      } catch (IOException iOException) {
        iOException.printStackTrace();
      }  
    return str1;
  }
  
  public static String a(byte[] paramArrayOfbyte) {
    StringBuilder stringBuilder = new StringBuilder(paramArrayOfbyte.length * 2);
    for (byte b1 = 0; b1 < paramArrayOfbyte.length; b1++) {
      stringBuilder.append(a[(paramArrayOfbyte[b1] & 0xF0) >>> 4]);
      stringBuilder.append(a[paramArrayOfbyte[b1] & 0xF]);
    } 
    return stringBuilder.toString();
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/StubShell/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */