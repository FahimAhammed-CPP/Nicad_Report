package com.tencent.StubShell;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class ZipUtil {
  public static int exist(String paramString1, String paramString2) {
    byte b3;
    byte b1 = -1;
    byte b2 = b1;
    try {
      File file = new File();
      b2 = b1;
      this(paramString1);
      b2 = b1;
      ZipFile zipFile = new ZipFile();
      b2 = b1;
      this(file);
      b3 = b1;
      b2 = b1;
      if (zipFile.getEntry(paramString2) != null)
        b3 = 0; 
      b2 = b3;
      zipFile.close();
    } catch (Exception exception) {
      b3 = b2;
    } 
    return b3;
  }
  
  public static int extract(String paramString1, String paramString2, String paramString3) {
    boolean bool = false;
    try {
      File file = new File();
      this(paramString3);
      if (file.exists() == true)
        file.delete(); 
      FileOutputStream fileOutputStream = new FileOutputStream();
      this(file);
      file = new File();
      this(paramString1);
      ZipFile zipFile = new ZipFile();
      this(file);
      ZipEntry zipEntry = zipFile.getEntry(paramString2);
      if (zipEntry == null);
      InputStream inputStream = zipFile.getInputStream(zipEntry);
      byte[] arrayOfByte = new byte[1024];
      while (true) {
        int i = inputStream.read(arrayOfByte);
        if (i > 0) {
          fileOutputStream.write(arrayOfByte, 0, i);
          continue;
        } 
        fileOutputStream.close();
        inputStream.close();
        zipFile.close();
        return bool;
      } 
    } catch (Exception exception) {
      if (exception.getMessage() != null)
        return 1; 
    } 
    return bool;
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/StubShell/ZipUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */