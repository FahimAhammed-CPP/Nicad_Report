package com.tencent.StubShell;

import com.tencent.bugly.legu.crashreport.CrashReport;

class d implements Runnable {
  d(TxAppEntry paramTxAppEntry) {}
  
  public void run() {
    CrashReport.postCatchedException(new SystemInfoException(TxAppEntry.a(), TxAppEntry.b()));
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/StubShell/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */