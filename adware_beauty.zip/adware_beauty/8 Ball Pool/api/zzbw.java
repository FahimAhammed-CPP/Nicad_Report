package com.android.billingclient.api;

import android.text.TextUtils;
import h8800e55c.pc41fcc5f.v416f9e89;

public final class zzbw {
  private String zza;
  
  private zzbw() {}
  
  public final zzbw zza(String paramString) {
    this.zza = paramString;
    return this;
  }
  
  public final zzby zzb() {
    if (!TextUtils.isEmpty(this.zza))
      return new zzby(this.zza, null, null, 0, null); 
    throw new IllegalArgumentException(v416f9e89.xbd520268("15248"));
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\zzbw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */