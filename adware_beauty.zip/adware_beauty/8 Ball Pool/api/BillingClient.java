package com.android.billingclient.api;

import android.app.Activity;
import android.content.Context;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public abstract class BillingClient {
  public static Builder newBuilder(Context paramContext) {
    return new Builder(paramContext, null);
  }
  
  public abstract void acknowledgePurchase(AcknowledgePurchaseParams paramAcknowledgePurchaseParams, AcknowledgePurchaseResponseListener paramAcknowledgePurchaseResponseListener);
  
  public abstract void consumeAsync(ConsumeParams paramConsumeParams, ConsumeResponseListener paramConsumeResponseListener);
  
  public abstract void endConnection();
  
  public abstract int getConnectionState();
  
  public abstract BillingResult isFeatureSupported(String paramString);
  
  public abstract boolean isReady();
  
  public abstract BillingResult launchBillingFlow(Activity paramActivity, BillingFlowParams paramBillingFlowParams);
  
  @Deprecated
  public abstract void launchPriceChangeConfirmationFlow(Activity paramActivity, PriceChangeFlowParams paramPriceChangeFlowParams, PriceChangeConfirmationListener paramPriceChangeConfirmationListener);
  
  public abstract void queryProductDetailsAsync(QueryProductDetailsParams paramQueryProductDetailsParams, ProductDetailsResponseListener paramProductDetailsResponseListener);
  
  public abstract void queryPurchaseHistoryAsync(QueryPurchaseHistoryParams paramQueryPurchaseHistoryParams, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener);
  
  @Deprecated
  public abstract void queryPurchaseHistoryAsync(String paramString, PurchaseHistoryResponseListener paramPurchaseHistoryResponseListener);
  
  public abstract void queryPurchasesAsync(QueryPurchasesParams paramQueryPurchasesParams, PurchasesResponseListener paramPurchasesResponseListener);
  
  @Deprecated
  public abstract void queryPurchasesAsync(String paramString, PurchasesResponseListener paramPurchasesResponseListener);
  
  @Deprecated
  public abstract void querySkuDetailsAsync(SkuDetailsParams paramSkuDetailsParams, SkuDetailsResponseListener paramSkuDetailsResponseListener);
  
  public abstract BillingResult showInAppMessages(Activity paramActivity, InAppMessageParams paramInAppMessageParams, InAppMessageResponseListener paramInAppMessageResponseListener);
  
  public abstract void startConnection(BillingClientStateListener paramBillingClientStateListener);
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface BillingResponseCode {
    public static final int BILLING_UNAVAILABLE = 3;
    
    public static final int DEVELOPER_ERROR = 5;
    
    public static final int ERROR = 6;
    
    public static final int FEATURE_NOT_SUPPORTED = -2;
    
    public static final int ITEM_ALREADY_OWNED = 7;
    
    public static final int ITEM_NOT_OWNED = 8;
    
    public static final int ITEM_UNAVAILABLE = 4;
    
    public static final int OK = 0;
    
    public static final int SERVICE_DISCONNECTED = -1;
    
    public static final int SERVICE_TIMEOUT = -3;
    
    public static final int SERVICE_UNAVAILABLE = 2;
    
    public static final int USER_CANCELED = 1;
  }
  
  public static final class Builder {
    private volatile String zza;
    
    private volatile boolean zzb;
    
    private volatile boolean zzc;
    
    private final Context zzd;
    
    private volatile PurchasesUpdatedListener zze;
    
    private volatile zzbf zzf;
    
    private volatile AlternativeBillingListener zzg;
    
    public BillingClient build() {
      if (this.zzd != null) {
        if (this.zze != null) {
          if (this.zzb) {
            if (this.zze != null || this.zzg == null)
              return (this.zze != null) ? new BillingClientImpl(null, this.zzb, false, this.zzd, this.zze, this.zzg) : new BillingClientImpl(null, this.zzb, this.zzd, null); 
            throw new IllegalArgumentException(v416f9e89.xbd520268("15310"));
          } 
          throw new IllegalArgumentException(v416f9e89.xbd520268("15311"));
        } 
        throw new IllegalArgumentException(v416f9e89.xbd520268("15312"));
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("15313"));
    }
    
    public Builder enableAlternativeBilling(AlternativeBillingListener param1AlternativeBillingListener) {
      this.zzg = param1AlternativeBillingListener;
      return this;
    }
    
    public Builder enablePendingPurchases() {
      this.zzb = true;
      return this;
    }
    
    public Builder setListener(PurchasesUpdatedListener param1PurchasesUpdatedListener) {
      this.zze = param1PurchasesUpdatedListener;
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface ConnectionState {
    public static final int CLOSED = 3;
    
    public static final int CONNECTED = 2;
    
    public static final int CONNECTING = 1;
    
    public static final int DISCONNECTED = 0;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface FeatureType {
    public static final String IN_APP_MESSAGING = v416f9e89.xbd520268("14904");
    
    public static final String PRICE_CHANGE_CONFIRMATION = v416f9e89.xbd520268("14905");
    
    public static final String PRODUCT_DETAILS = v416f9e89.xbd520268("14906");
    
    public static final String SUBSCRIPTIONS = v416f9e89.xbd520268("14907");
    
    public static final String SUBSCRIPTIONS_UPDATE = v416f9e89.xbd520268("14908");
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface ProductType {
    public static final String INAPP = v416f9e89.xbd520268("14909");
    
    public static final String SUBS = v416f9e89.xbd520268("14910");
  }
  
  @Deprecated
  @Retention(RetentionPolicy.SOURCE)
  public static @interface SkuType {
    public static final String INAPP = v416f9e89.xbd520268("15164");
    
    public static final String SUBS = v416f9e89.xbd520268("15165");
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\BillingClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */