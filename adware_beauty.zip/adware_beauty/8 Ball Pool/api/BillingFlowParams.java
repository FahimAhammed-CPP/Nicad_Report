package com.android.billingclient.api;

import android.text.TextUtils;
import com.google.android.gms.internal.play_billing.zzm;
import com.google.android.gms.internal.play_billing.zzu;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class BillingFlowParams {
  public static final String EXTRA_PARAM_KEY_ACCOUNT_ID = v416f9e89.xbd520268("15738");
  
  private boolean zza;
  
  private String zzb;
  
  private String zzc;
  
  private SubscriptionUpdateParams zzd;
  
  private zzu zze;
  
  private ArrayList zzf;
  
  private boolean zzg;
  
  private BillingFlowParams() {}
  
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  public final int zza() {
    return this.zzd.zza();
  }
  
  public final String zzb() {
    return this.zzb;
  }
  
  public final String zzc() {
    return this.zzc;
  }
  
  public final String zzd() {
    return this.zzd.zzc();
  }
  
  public final String zze() {
    return this.zzd.zzd();
  }
  
  public final ArrayList zzf() {
    ArrayList arrayList = new ArrayList();
    arrayList.addAll(this.zzf);
    return arrayList;
  }
  
  public final List zzg() {
    return (List)this.zze;
  }
  
  public final boolean zzo() {
    return this.zzg;
  }
  
  final boolean zzp() {
    return !(this.zzb == null && this.zzc == null && this.zzd.zzd() == null && this.zzd.zza() == 0 && !this.zza && !this.zzg);
  }
  
  public static class Builder {
    private String zza;
    
    private String zzb;
    
    private List zzc;
    
    private ArrayList zzd;
    
    private boolean zze;
    
    private BillingFlowParams.SubscriptionUpdateParams.Builder zzf;
    
    private Builder() {
      BillingFlowParams.SubscriptionUpdateParams.Builder builder = BillingFlowParams.SubscriptionUpdateParams.newBuilder();
      BillingFlowParams.SubscriptionUpdateParams.Builder.zza(builder);
      this.zzf = builder;
    }
    
    public BillingFlowParams build() {
      // Byte code:
      //   0: aload_0
      //   1: getfield zzd : Ljava/util/ArrayList;
      //   4: astore #7
      //   6: iconst_1
      //   7: istore #6
      //   9: aload #7
      //   11: ifnull -> 27
      //   14: aload #7
      //   16: invokevirtual isEmpty : ()Z
      //   19: ifne -> 27
      //   22: iconst_1
      //   23: istore_1
      //   24: goto -> 29
      //   27: iconst_0
      //   28: istore_1
      //   29: aload_0
      //   30: getfield zzc : Ljava/util/List;
      //   33: astore #7
      //   35: aload #7
      //   37: ifnull -> 55
      //   40: aload #7
      //   42: invokeinterface isEmpty : ()Z
      //   47: ifne -> 55
      //   50: iconst_1
      //   51: istore_2
      //   52: goto -> 57
      //   55: iconst_0
      //   56: istore_2
      //   57: iload_1
      //   58: ifne -> 81
      //   61: iload_2
      //   62: ifeq -> 68
      //   65: goto -> 81
      //   68: new java/lang/IllegalArgumentException
      //   71: dup
      //   72: ldc '15701'
      //   74: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   77: invokespecial <init> : (Ljava/lang/String;)V
      //   80: athrow
      //   81: iload_1
      //   82: ifeq -> 105
      //   85: iload_2
      //   86: ifne -> 92
      //   89: goto -> 105
      //   92: new java/lang/IllegalArgumentException
      //   95: dup
      //   96: ldc '15702'
      //   98: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   101: invokespecial <init> : (Ljava/lang/String;)V
      //   104: athrow
      //   105: ldc '15703'
      //   107: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   110: astore #7
      //   112: iload_1
      //   113: ifeq -> 368
      //   116: aload_0
      //   117: getfield zzd : Ljava/util/ArrayList;
      //   120: aconst_null
      //   121: invokevirtual contains : (Ljava/lang/Object;)Z
      //   124: ifne -> 355
      //   127: aload_0
      //   128: getfield zzd : Ljava/util/ArrayList;
      //   131: invokevirtual size : ()I
      //   134: iconst_1
      //   135: if_icmple -> 603
      //   138: aload_0
      //   139: getfield zzd : Ljava/util/ArrayList;
      //   142: iconst_0
      //   143: invokevirtual get : (I)Ljava/lang/Object;
      //   146: checkcast com/android/billingclient/api/SkuDetails
      //   149: astore #9
      //   151: aload #9
      //   153: invokevirtual getType : ()Ljava/lang/String;
      //   156: astore #8
      //   158: aload_0
      //   159: getfield zzd : Ljava/util/ArrayList;
      //   162: astore #10
      //   164: aload #10
      //   166: invokeinterface size : ()I
      //   171: istore #4
      //   173: iconst_0
      //   174: istore_3
      //   175: iload_3
      //   176: iload #4
      //   178: if_icmpge -> 253
      //   181: aload #10
      //   183: iload_3
      //   184: invokeinterface get : (I)Ljava/lang/Object;
      //   189: checkcast com/android/billingclient/api/SkuDetails
      //   192: astore #11
      //   194: aload #8
      //   196: aload #7
      //   198: invokevirtual equals : (Ljava/lang/Object;)Z
      //   201: ifne -> 246
      //   204: aload #11
      //   206: invokevirtual getType : ()Ljava/lang/String;
      //   209: aload #7
      //   211: invokevirtual equals : (Ljava/lang/Object;)Z
      //   214: ifne -> 246
      //   217: aload #8
      //   219: aload #11
      //   221: invokevirtual getType : ()Ljava/lang/String;
      //   224: invokevirtual equals : (Ljava/lang/Object;)Z
      //   227: ifeq -> 233
      //   230: goto -> 246
      //   233: new java/lang/IllegalArgumentException
      //   236: dup
      //   237: ldc '15704'
      //   239: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   242: invokespecial <init> : (Ljava/lang/String;)V
      //   245: athrow
      //   246: iload_3
      //   247: iconst_1
      //   248: iadd
      //   249: istore_3
      //   250: goto -> 175
      //   253: aload #9
      //   255: invokevirtual zzd : ()Ljava/lang/String;
      //   258: astore #9
      //   260: aload_0
      //   261: getfield zzd : Ljava/util/ArrayList;
      //   264: astore #10
      //   266: aload #10
      //   268: invokeinterface size : ()I
      //   273: istore #4
      //   275: iconst_0
      //   276: istore_3
      //   277: iload_3
      //   278: iload #4
      //   280: if_icmpge -> 603
      //   283: aload #10
      //   285: iload_3
      //   286: invokeinterface get : (I)Ljava/lang/Object;
      //   291: checkcast com/android/billingclient/api/SkuDetails
      //   294: astore #11
      //   296: aload #8
      //   298: aload #7
      //   300: invokevirtual equals : (Ljava/lang/Object;)Z
      //   303: ifne -> 348
      //   306: aload #11
      //   308: invokevirtual getType : ()Ljava/lang/String;
      //   311: aload #7
      //   313: invokevirtual equals : (Ljava/lang/Object;)Z
      //   316: ifne -> 348
      //   319: aload #9
      //   321: aload #11
      //   323: invokevirtual zzd : ()Ljava/lang/String;
      //   326: invokevirtual equals : (Ljava/lang/Object;)Z
      //   329: ifeq -> 335
      //   332: goto -> 348
      //   335: new java/lang/IllegalArgumentException
      //   338: dup
      //   339: ldc '15705'
      //   341: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   344: invokespecial <init> : (Ljava/lang/String;)V
      //   347: athrow
      //   348: iload_3
      //   349: iconst_1
      //   350: iadd
      //   351: istore_3
      //   352: goto -> 277
      //   355: new java/lang/IllegalArgumentException
      //   358: dup
      //   359: ldc '15706'
      //   361: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   364: invokespecial <init> : (Ljava/lang/String;)V
      //   367: athrow
      //   368: aload_0
      //   369: getfield zzc : Ljava/util/List;
      //   372: iconst_0
      //   373: invokeinterface get : (I)Ljava/lang/Object;
      //   378: checkcast com/android/billingclient/api/BillingFlowParams$ProductDetailsParams
      //   381: astore #8
      //   383: iconst_0
      //   384: istore_3
      //   385: iload_3
      //   386: aload_0
      //   387: getfield zzc : Ljava/util/List;
      //   390: invokeinterface size : ()I
      //   395: if_icmpge -> 496
      //   398: aload_0
      //   399: getfield zzc : Ljava/util/List;
      //   402: iload_3
      //   403: invokeinterface get : (I)Ljava/lang/Object;
      //   408: checkcast com/android/billingclient/api/BillingFlowParams$ProductDetailsParams
      //   411: astore #9
      //   413: aload #9
      //   415: ifnull -> 483
      //   418: iload_3
      //   419: ifeq -> 476
      //   422: aload #9
      //   424: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   427: invokevirtual getProductType : ()Ljava/lang/String;
      //   430: aload #8
      //   432: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   435: invokevirtual getProductType : ()Ljava/lang/String;
      //   438: invokevirtual equals : (Ljava/lang/Object;)Z
      //   441: ifne -> 476
      //   444: aload #9
      //   446: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   449: invokevirtual getProductType : ()Ljava/lang/String;
      //   452: aload #7
      //   454: invokevirtual equals : (Ljava/lang/Object;)Z
      //   457: ifeq -> 463
      //   460: goto -> 476
      //   463: new java/lang/IllegalArgumentException
      //   466: dup
      //   467: ldc '15707'
      //   469: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   472: invokespecial <init> : (Ljava/lang/String;)V
      //   475: athrow
      //   476: iload_3
      //   477: iconst_1
      //   478: iadd
      //   479: istore_3
      //   480: goto -> 385
      //   483: new java/lang/IllegalArgumentException
      //   486: dup
      //   487: ldc '15708'
      //   489: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   492: invokespecial <init> : (Ljava/lang/String;)V
      //   495: athrow
      //   496: aload #8
      //   498: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   501: invokevirtual zza : ()Ljava/lang/String;
      //   504: astore #9
      //   506: aload_0
      //   507: getfield zzc : Ljava/util/List;
      //   510: invokeinterface iterator : ()Ljava/util/Iterator;
      //   515: astore #10
      //   517: aload #10
      //   519: invokeinterface hasNext : ()Z
      //   524: ifeq -> 603
      //   527: aload #10
      //   529: invokeinterface next : ()Ljava/lang/Object;
      //   534: checkcast com/android/billingclient/api/BillingFlowParams$ProductDetailsParams
      //   537: astore #11
      //   539: aload #8
      //   541: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   544: invokevirtual getProductType : ()Ljava/lang/String;
      //   547: aload #7
      //   549: invokevirtual equals : (Ljava/lang/Object;)Z
      //   552: ifne -> 517
      //   555: aload #11
      //   557: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   560: invokevirtual getProductType : ()Ljava/lang/String;
      //   563: aload #7
      //   565: invokevirtual equals : (Ljava/lang/Object;)Z
      //   568: ifne -> 517
      //   571: aload #9
      //   573: aload #11
      //   575: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   578: invokevirtual zza : ()Ljava/lang/String;
      //   581: invokevirtual equals : (Ljava/lang/Object;)Z
      //   584: ifeq -> 590
      //   587: goto -> 517
      //   590: new java/lang/IllegalArgumentException
      //   593: dup
      //   594: ldc '15709'
      //   596: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
      //   599: invokespecial <init> : (Ljava/lang/String;)V
      //   602: athrow
      //   603: new com/android/billingclient/api/BillingFlowParams
      //   606: dup
      //   607: aconst_null
      //   608: invokespecial <init> : (Lcom/android/billingclient/api/zzaz;)V
      //   611: astore #8
      //   613: iload_1
      //   614: ifeq -> 641
      //   617: iload #6
      //   619: istore #5
      //   621: aload_0
      //   622: getfield zzd : Ljava/util/ArrayList;
      //   625: iconst_0
      //   626: invokevirtual get : (I)Ljava/lang/Object;
      //   629: checkcast com/android/billingclient/api/SkuDetails
      //   632: invokevirtual zzd : ()Ljava/lang/String;
      //   635: invokevirtual isEmpty : ()Z
      //   638: ifeq -> 680
      //   641: iload_2
      //   642: ifeq -> 677
      //   645: aload_0
      //   646: getfield zzc : Ljava/util/List;
      //   649: iconst_0
      //   650: invokeinterface get : (I)Ljava/lang/Object;
      //   655: checkcast com/android/billingclient/api/BillingFlowParams$ProductDetailsParams
      //   658: invokevirtual zza : ()Lcom/android/billingclient/api/ProductDetails;
      //   661: invokevirtual zza : ()Ljava/lang/String;
      //   664: invokevirtual isEmpty : ()Z
      //   667: ifne -> 677
      //   670: iload #6
      //   672: istore #5
      //   674: goto -> 680
      //   677: iconst_0
      //   678: istore #5
      //   680: aload #8
      //   682: iload #5
      //   684: invokestatic zzh : (Lcom/android/billingclient/api/BillingFlowParams;Z)V
      //   687: aload #8
      //   689: aload_0
      //   690: getfield zza : Ljava/lang/String;
      //   693: invokestatic zzj : (Lcom/android/billingclient/api/BillingFlowParams;Ljava/lang/String;)V
      //   696: aload #8
      //   698: aload_0
      //   699: getfield zzb : Ljava/lang/String;
      //   702: invokestatic zzk : (Lcom/android/billingclient/api/BillingFlowParams;Ljava/lang/String;)V
      //   705: aload #8
      //   707: aload_0
      //   708: getfield zzf : Lcom/android/billingclient/api/BillingFlowParams$SubscriptionUpdateParams$Builder;
      //   711: invokevirtual build : ()Lcom/android/billingclient/api/BillingFlowParams$SubscriptionUpdateParams;
      //   714: invokestatic zzn : (Lcom/android/billingclient/api/BillingFlowParams;Lcom/android/billingclient/api/BillingFlowParams$SubscriptionUpdateParams;)V
      //   717: aload_0
      //   718: getfield zzd : Ljava/util/ArrayList;
      //   721: astore #7
      //   723: aload #7
      //   725: ifnull -> 742
      //   728: new java/util/ArrayList
      //   731: dup
      //   732: aload #7
      //   734: invokespecial <init> : (Ljava/util/Collection;)V
      //   737: astore #7
      //   739: goto -> 751
      //   742: new java/util/ArrayList
      //   745: dup
      //   746: invokespecial <init> : ()V
      //   749: astore #7
      //   751: aload #8
      //   753: aload #7
      //   755: invokestatic zzm : (Lcom/android/billingclient/api/BillingFlowParams;Ljava/util/ArrayList;)V
      //   758: aload #8
      //   760: aload_0
      //   761: getfield zze : Z
      //   764: invokestatic zzi : (Lcom/android/billingclient/api/BillingFlowParams;Z)V
      //   767: aload_0
      //   768: getfield zzc : Ljava/util/List;
      //   771: astore #7
      //   773: aload #7
      //   775: ifnull -> 788
      //   778: aload #7
      //   780: invokestatic zzj : (Ljava/util/Collection;)Lcom/google/android/gms/internal/play_billing/zzu;
      //   783: astore #7
      //   785: goto -> 793
      //   788: invokestatic zzk : ()Lcom/google/android/gms/internal/play_billing/zzu;
      //   791: astore #7
      //   793: aload #8
      //   795: aload #7
      //   797: invokestatic zzl : (Lcom/android/billingclient/api/BillingFlowParams;Lcom/google/android/gms/internal/play_billing/zzu;)V
      //   800: aload #8
      //   802: areturn
    }
    
    public Builder setIsOfferPersonalized(boolean param1Boolean) {
      this.zze = param1Boolean;
      return this;
    }
    
    public Builder setObfuscatedAccountId(String param1String) {
      this.zza = param1String;
      return this;
    }
    
    public Builder setObfuscatedProfileId(String param1String) {
      this.zzb = param1String;
      return this;
    }
    
    public Builder setProductDetailsParamsList(List<BillingFlowParams.ProductDetailsParams> param1List) {
      this.zzc = new ArrayList<BillingFlowParams.ProductDetailsParams>(param1List);
      return this;
    }
    
    @Deprecated
    public Builder setSkuDetails(SkuDetails param1SkuDetails) {
      ArrayList<SkuDetails> arrayList = new ArrayList();
      arrayList.add(param1SkuDetails);
      this.zzd = arrayList;
      return this;
    }
    
    public Builder setSubscriptionUpdateParams(BillingFlowParams.SubscriptionUpdateParams param1SubscriptionUpdateParams) {
      this.zzf = BillingFlowParams.SubscriptionUpdateParams.zzb(param1SubscriptionUpdateParams);
      return this;
    }
  }
  
  public static final class ProductDetailsParams {
    private final ProductDetails zza;
    
    private final String zzb;
    
    public static Builder newBuilder() {
      return new Builder(null);
    }
    
    public final ProductDetails zza() {
      return this.zza;
    }
    
    public final String zzb() {
      return this.zzb;
    }
    
    public static class Builder {
      private ProductDetails zza;
      
      private String zzb;
      
      private Builder() {}
      
      public BillingFlowParams.ProductDetailsParams build() {
        zzm.zzc(this.zza, v416f9e89.xbd520268("15734"));
        zzm.zzc(this.zzb, v416f9e89.xbd520268("15735"));
        return new BillingFlowParams.ProductDetailsParams(this, null);
      }
      
      public Builder setOfferToken(String param2String) {
        this.zzb = param2String;
        return this;
      }
      
      public Builder setProductDetails(ProductDetails param2ProductDetails) {
        this.zza = param2ProductDetails;
        if (param2ProductDetails.getOneTimePurchaseOfferDetails() != null) {
          Objects.requireNonNull(param2ProductDetails.getOneTimePurchaseOfferDetails());
          this.zzb = param2ProductDetails.getOneTimePurchaseOfferDetails().zza();
        } 
        return this;
      }
    }
  }
  
  public static class Builder {
    private ProductDetails zza;
    
    private String zzb;
    
    private Builder() {}
    
    public BillingFlowParams.ProductDetailsParams build() {
      zzm.zzc(this.zza, v416f9e89.xbd520268("15734"));
      zzm.zzc(this.zzb, v416f9e89.xbd520268("15735"));
      return new BillingFlowParams.ProductDetailsParams(this, null);
    }
    
    public Builder setOfferToken(String param1String) {
      this.zzb = param1String;
      return this;
    }
    
    public Builder setProductDetails(ProductDetails param1ProductDetails) {
      this.zza = param1ProductDetails;
      if (param1ProductDetails.getOneTimePurchaseOfferDetails() != null) {
        Objects.requireNonNull(param1ProductDetails.getOneTimePurchaseOfferDetails());
        this.zzb = param1ProductDetails.getOneTimePurchaseOfferDetails().zza();
      } 
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface ProrationMode {
    public static final int DEFERRED = 4;
    
    public static final int IMMEDIATE_AND_CHARGE_FULL_PRICE = 5;
    
    public static final int IMMEDIATE_AND_CHARGE_PRORATED_PRICE = 2;
    
    public static final int IMMEDIATE_WITHOUT_PRORATION = 3;
    
    public static final int IMMEDIATE_WITH_TIME_PRORATION = 1;
    
    public static final int UNKNOWN_SUBSCRIPTION_UPGRADE_DOWNGRADE_POLICY = 0;
  }
  
  public static class SubscriptionUpdateParams {
    private String zza;
    
    private String zzb;
    
    private int zzc = 0;
    
    private SubscriptionUpdateParams() {}
    
    public static Builder newBuilder() {
      return new Builder(null);
    }
    
    final int zza() {
      return this.zzc;
    }
    
    final String zzc() {
      return this.zza;
    }
    
    final String zzd() {
      return this.zzb;
    }
    
    public static class Builder {
      private String zza;
      
      private String zzb;
      
      private boolean zzc;
      
      private int zzd = 0;
      
      private Builder() {}
      
      public BillingFlowParams.SubscriptionUpdateParams build() {
        boolean bool;
        if (!TextUtils.isEmpty(this.zza) || !TextUtils.isEmpty(null)) {
          bool = true;
        } else {
          bool = false;
        } 
        int i = true ^ TextUtils.isEmpty(this.zzb);
        if (!bool || i == 0) {
          if (this.zzc || bool || i != 0) {
            BillingFlowParams.SubscriptionUpdateParams subscriptionUpdateParams = new BillingFlowParams.SubscriptionUpdateParams(null);
            BillingFlowParams.SubscriptionUpdateParams.zze(subscriptionUpdateParams, this.zza);
            BillingFlowParams.SubscriptionUpdateParams.zzg(subscriptionUpdateParams, this.zzd);
            BillingFlowParams.SubscriptionUpdateParams.zzf(subscriptionUpdateParams, this.zzb);
            return subscriptionUpdateParams;
          } 
          throw new IllegalArgumentException(v416f9e89.xbd520268("15737"));
        } 
        throw new IllegalArgumentException(v416f9e89.xbd520268("15736"));
      }
      
      public Builder setOldPurchaseToken(String param2String) {
        this.zza = param2String;
        return this;
      }
      
      @Deprecated
      public Builder setOldSkuPurchaseToken(String param2String) {
        this.zza = param2String;
        return this;
      }
      
      public Builder setOriginalExternalTransactionId(String param2String) {
        this.zzb = param2String;
        return this;
      }
      
      public Builder setReplaceProrationMode(int param2Int) {
        this.zzd = param2Int;
        return this;
      }
      
      @Deprecated
      public Builder setReplaceSkusProrationMode(int param2Int) {
        this.zzd = param2Int;
        return this;
      }
    }
  }
  
  public static class Builder {
    private String zza;
    
    private String zzb;
    
    private boolean zzc;
    
    private int zzd = 0;
    
    private Builder() {}
    
    public BillingFlowParams.SubscriptionUpdateParams build() {
      boolean bool;
      if (!TextUtils.isEmpty(this.zza) || !TextUtils.isEmpty(null)) {
        bool = true;
      } else {
        bool = false;
      } 
      int i = true ^ TextUtils.isEmpty(this.zzb);
      if (!bool || i == 0) {
        if (this.zzc || bool || i != 0) {
          BillingFlowParams.SubscriptionUpdateParams subscriptionUpdateParams = new BillingFlowParams.SubscriptionUpdateParams(null);
          BillingFlowParams.SubscriptionUpdateParams.zze(subscriptionUpdateParams, this.zza);
          BillingFlowParams.SubscriptionUpdateParams.zzg(subscriptionUpdateParams, this.zzd);
          BillingFlowParams.SubscriptionUpdateParams.zzf(subscriptionUpdateParams, this.zzb);
          return subscriptionUpdateParams;
        } 
        throw new IllegalArgumentException(v416f9e89.xbd520268("15737"));
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("15736"));
    }
    
    public Builder setOldPurchaseToken(String param1String) {
      this.zza = param1String;
      return this;
    }
    
    @Deprecated
    public Builder setOldSkuPurchaseToken(String param1String) {
      this.zza = param1String;
      return this;
    }
    
    public Builder setOriginalExternalTransactionId(String param1String) {
      this.zzb = param1String;
      return this;
    }
    
    public Builder setReplaceProrationMode(int param1Int) {
      this.zzd = param1Int;
      return this;
    }
    
    @Deprecated
    public Builder setReplaceSkusProrationMode(int param1Int) {
      this.zzd = param1Int;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\BillingFlowParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */