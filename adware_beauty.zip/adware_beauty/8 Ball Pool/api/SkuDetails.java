package com.android.billingclient.api;

import android.text.TextUtils;
import h8800e55c.pc41fcc5f.v416f9e89;
import org.json.JSONException;
import org.json.JSONObject;

@Deprecated
public class SkuDetails {
  private final String zza;
  
  private final JSONObject zzb;
  
  public SkuDetails(String paramString) throws JSONException {
    this.zza = paramString;
    JSONObject jSONObject = new JSONObject(paramString);
    this.zzb = jSONObject;
    if (!TextUtils.isEmpty(jSONObject.optString(v416f9e89.xbd520268("15249")))) {
      if (!TextUtils.isEmpty(jSONObject.optString(v416f9e89.xbd520268("15250"))))
        return; 
      throw new IllegalArgumentException(v416f9e89.xbd520268("15251"));
    } 
    throw new IllegalArgumentException(v416f9e89.xbd520268("15252"));
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof SkuDetails))
      return false; 
    paramObject = paramObject;
    return TextUtils.equals(this.zza, ((SkuDetails)paramObject).zza);
  }
  
  public String getDescription() {
    return this.zzb.optString(v416f9e89.xbd520268("15253"));
  }
  
  public String getFreeTrialPeriod() {
    return this.zzb.optString(v416f9e89.xbd520268("15254"));
  }
  
  public String getIconUrl() {
    return this.zzb.optString(v416f9e89.xbd520268("15255"));
  }
  
  public String getIntroductoryPrice() {
    return this.zzb.optString(v416f9e89.xbd520268("15256"));
  }
  
  public long getIntroductoryPriceAmountMicros() {
    return this.zzb.optLong(v416f9e89.xbd520268("15257"));
  }
  
  public int getIntroductoryPriceCycles() {
    return this.zzb.optInt(v416f9e89.xbd520268("15258"));
  }
  
  public String getIntroductoryPricePeriod() {
    return this.zzb.optString(v416f9e89.xbd520268("15259"));
  }
  
  public String getOriginalJson() {
    return this.zza;
  }
  
  public String getOriginalPrice() {
    JSONObject jSONObject = this.zzb;
    String str = v416f9e89.xbd520268("15260");
    return jSONObject.has(str) ? this.zzb.optString(str) : getPrice();
  }
  
  public long getOriginalPriceAmountMicros() {
    JSONObject jSONObject = this.zzb;
    String str = v416f9e89.xbd520268("15261");
    return jSONObject.has(str) ? this.zzb.optLong(str) : getPriceAmountMicros();
  }
  
  public String getPrice() {
    return this.zzb.optString(v416f9e89.xbd520268("15262"));
  }
  
  public long getPriceAmountMicros() {
    return this.zzb.optLong(v416f9e89.xbd520268("15263"));
  }
  
  public String getPriceCurrencyCode() {
    return this.zzb.optString(v416f9e89.xbd520268("15264"));
  }
  
  public String getSku() {
    return this.zzb.optString(v416f9e89.xbd520268("15265"));
  }
  
  public String getSubscriptionPeriod() {
    return this.zzb.optString(v416f9e89.xbd520268("15266"));
  }
  
  public String getTitle() {
    return this.zzb.optString(v416f9e89.xbd520268("15267"));
  }
  
  public String getType() {
    return this.zzb.optString(v416f9e89.xbd520268("15268"));
  }
  
  public int hashCode() {
    return this.zza.hashCode();
  }
  
  public String toString() {
    String str = String.valueOf(this.zza);
    return v416f9e89.xbd520268("15269").concat(str);
  }
  
  public int zza() {
    return this.zzb.optInt(v416f9e89.xbd520268("15270"));
  }
  
  public String zzb() {
    return this.zzb.optString(v416f9e89.xbd520268("15271"));
  }
  
  public String zzc() {
    String str2 = this.zzb.optString(v416f9e89.xbd520268("15272"));
    String str1 = str2;
    if (str2.isEmpty())
      str1 = this.zzb.optString(v416f9e89.xbd520268("15273")); 
    return str1;
  }
  
  public final String zzd() {
    return this.zzb.optString(v416f9e89.xbd520268("15274"));
  }
  
  public String zze() {
    return this.zzb.optString(v416f9e89.xbd520268("15275"));
  }
  
  final String zzf() {
    return this.zzb.optString(v416f9e89.xbd520268("15276"));
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\SkuDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */