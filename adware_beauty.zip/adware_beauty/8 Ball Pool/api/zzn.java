package com.android.billingclient.api;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import com.google.android.gms.internal.play_billing.zzb;
import com.google.android.gms.internal.play_billing.zzu;
import h8800e55c.i2482f27b.i570d159d;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.List;
import org.json.JSONException;

final class zzn extends BroadcastReceiver {
  private final PurchasesUpdatedListener zzb;
  
  private final zzbf zzc;
  
  private final AlternativeBillingListener zzd;
  
  private boolean zze;
  
  private final zzbh zzf;
  
  private static final void zze(Bundle paramBundle, BillingResult paramBillingResult, int paramInt) {
    String str = v416f9e89.xbd520268("15291");
    if (paramBundle.getByteArray(str) != null)
      try {
        return;
      } finally {
        paramBundle = null;
        zzb.zzj(v416f9e89.xbd520268("15292"), v416f9e89.xbd520268("15293"));
      }  
    zzba.zza(23, paramInt, paramBillingResult);
  }
  
  public final void onReceive(Context paramContext, Intent paramIntent) {
    PurchasesUpdatedListener purchasesUpdatedListener;
    List<Purchase> list;
    Bundle bundle = paramIntent.getExtras();
    String str1 = v416f9e89.xbd520268("15294");
    if (bundle == null) {
      zzb.zzj(str1, v416f9e89.xbd520268("15295"));
      zzba.zza(11, 1, zzbc.zzj);
      purchasesUpdatedListener = this.zzb;
      if (purchasesUpdatedListener != null)
        purchasesUpdatedListener.onPurchasesUpdated(zzbc.zzj, null); 
      return;
    } 
    BillingResult billingResult = zzb.zzd(paramIntent, (String)purchasesUpdatedListener);
    String str2 = paramIntent.getAction();
    String str3 = bundle.getString(v416f9e89.xbd520268("15296"));
    String str4 = v416f9e89.xbd520268("15297");
    byte b2 = 2;
    byte b1 = b2;
    if (str3 != str4)
      if (str3 != null && str3.equals(str4)) {
        b1 = b2;
      } else {
        b1 = 1;
      }  
    if (str2.equals(v416f9e89.xbd520268("15298"))) {
      if (!bundle.getBoolean(v416f9e89.xbd520268("15299"), false) && this.zzb != null) {
        list = zzb.zzh(bundle);
        if (billingResult.getResponseCode() == 0) {
          zzba.zzb(b1);
        } else {
          zze(bundle, billingResult, b1);
        } 
        this.zzb.onPurchasesUpdated(billingResult, list);
        return;
      } 
      zzb.zzj((String)list, v416f9e89.xbd520268("15300"));
      zzba.zza(12, b1, zzbc.zzj);
      return;
    } 
    if (str2.equals(v416f9e89.xbd520268("15301"))) {
      if (billingResult.getResponseCode() != 0) {
        zze(bundle, billingResult, b1);
        this.zzb.onPurchasesUpdated(billingResult, (List<Purchase>)zzu.zzk());
        return;
      } 
      if (this.zzd == null) {
        zzb.zzj((String)list, v416f9e89.xbd520268("15302"));
        zzba.zza(15, b1, zzbc.zzj);
        this.zzb.onPurchasesUpdated(zzbc.zzj, (List<Purchase>)zzu.zzk());
        return;
      } 
      str2 = bundle.getString(v416f9e89.xbd520268("15303"));
      if (str2 == null) {
        zzb.zzj((String)list, v416f9e89.xbd520268("15304"));
        zzba.zza(16, b1, zzbc.zzj);
        this.zzb.onPurchasesUpdated(zzbc.zzj, (List<Purchase>)zzu.zzk());
        return;
      } 
      try {
        AlternativeChoiceDetails alternativeChoiceDetails = new AlternativeChoiceDetails(str2);
        zzba.zzb(b1);
        this.zzd.userSelectedAlternativeBilling(alternativeChoiceDetails);
        return;
      } catch (JSONException jSONException) {
        zzb.zzj((String)list, String.format(v416f9e89.xbd520268("15305"), new Object[] { str2 }));
        zzba.zza(17, b1, zzbc.zzj);
        this.zzb.onPurchasesUpdated(zzbc.zzj, (List<Purchase>)zzu.zzk());
      } 
    } 
  }
  
  public final void zzc(Context paramContext, IntentFilter paramIntentFilter) {
    if (!this.zze) {
      if (Build.VERSION.SDK_INT >= 33) {
        i570d159d.registerReceiver(paramContext, zzo.zza(this.zza), paramIntentFilter, 2);
      } else {
        i570d159d.registerReceiver(paramContext, zzo.zza(this.zza), paramIntentFilter);
      } 
      this.zze = true;
    } 
  }
  
  public final void zzd(Context paramContext) {
    if (this.zze) {
      i570d159d.unregisterReceiver(paramContext, zzo.zza(this.zza));
      this.zze = false;
      return;
    } 
    zzb.zzj(v416f9e89.xbd520268("15306"), v416f9e89.xbd520268("15307"));
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\zzn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */