package com.android.billingclient.api;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import com.google.android.gms.internal.play_billing.zzb;
import h8800e55c.pc41fcc5f.v416f9e89;

final class zzah extends ResultReceiver {
  zzah(BillingClientImpl paramBillingClientImpl, Handler paramHandler, PriceChangeConfirmationListener paramPriceChangeConfirmationListener) {
    super(paramHandler);
  }
  
  public final void onReceiveResult(int paramInt, Bundle paramBundle) {
    BillingResult.Builder builder = BillingResult.newBuilder();
    builder.setResponseCode(paramInt);
    builder.setDebugMessage(zzb.zzf(paramBundle, v416f9e89.xbd520268("15281")));
    BillingResult billingResult = builder.build();
    this.zza.onPriceChangeConfirmationResult(billingResult);
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\zzah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */