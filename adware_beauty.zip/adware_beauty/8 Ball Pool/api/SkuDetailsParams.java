package com.android.billingclient.api;

import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.ArrayList;
import java.util.List;

@Deprecated
public class SkuDetailsParams {
  private String zza;
  
  private List zzb;
  
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  public String getSkuType() {
    return this.zza;
  }
  
  public List<String> getSkusList() {
    return this.zzb;
  }
  
  public static class Builder {
    private String zza;
    
    private List zzb;
    
    private Builder() {}
    
    public SkuDetailsParams build() {
      String str = this.zza;
      if (str != null) {
        if (this.zzb != null) {
          SkuDetailsParams skuDetailsParams = new SkuDetailsParams();
          SkuDetailsParams.zza(skuDetailsParams, str);
          SkuDetailsParams.zzb(skuDetailsParams, this.zzb);
          return skuDetailsParams;
        } 
        throw new IllegalArgumentException(v416f9e89.xbd520268("15277"));
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("15278"));
    }
    
    public Builder setSkusList(List<String> param1List) {
      this.zzb = new ArrayList<String>(param1List);
      return this;
    }
    
    public Builder setType(String param1String) {
      this.zza = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\SkuDetailsParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */