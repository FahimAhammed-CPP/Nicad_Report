package com.android.billingclient.api;

import android.os.Bundle;
import com.google.android.gms.internal.play_billing.zzb;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.util.ArrayList;

final class zzbl {
  static BillingResult zza(Bundle paramBundle, String paramString1, String paramString2) {
    BillingResult billingResult1 = zzbc.zzj;
    String str1 = v416f9e89.xbd520268("15670");
    if (paramBundle == null) {
      zzb.zzj(str1, String.format(v416f9e89.xbd520268("15671"), new Object[] { paramString2 }));
      return billingResult1;
    } 
    int i = zzb.zzb(paramBundle, str1);
    String str2 = zzb.zzf(paramBundle, str1);
    BillingResult.Builder builder = BillingResult.newBuilder();
    builder.setResponseCode(i);
    builder.setDebugMessage(str2);
    BillingResult billingResult2 = builder.build();
    if (i != 0) {
      zzb.zzj(str1, String.format(v416f9e89.xbd520268("15672"), new Object[] { paramString2, Integer.valueOf(i) }));
      return billingResult2;
    } 
    String str3 = v416f9e89.xbd520268("15673");
    if (paramBundle.containsKey(str3)) {
      String str = v416f9e89.xbd520268("15674");
      if (paramBundle.containsKey(str)) {
        String str4 = v416f9e89.xbd520268("15675");
        if (paramBundle.containsKey(str4)) {
          ArrayList arrayList2 = paramBundle.getStringArrayList(str3);
          ArrayList arrayList3 = paramBundle.getStringArrayList(str);
          ArrayList arrayList1 = paramBundle.getStringArrayList(str4);
          if (arrayList2 == null) {
            zzb.zzj(str1, String.format(v416f9e89.xbd520268("15676"), new Object[] { paramString2 }));
            return billingResult1;
          } 
          if (arrayList3 == null) {
            zzb.zzj(str1, String.format(v416f9e89.xbd520268("15677"), new Object[] { paramString2 }));
            return billingResult1;
          } 
          if (arrayList1 == null) {
            zzb.zzj(str1, String.format(v416f9e89.xbd520268("15678"), new Object[] { paramString2 }));
            return billingResult1;
          } 
          return zzbc.zzl;
        } 
      } 
    } 
    zzb.zzj(str1, String.format(v416f9e89.xbd520268("15679"), new Object[] { paramString2 }));
    return billingResult1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\zzbl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */