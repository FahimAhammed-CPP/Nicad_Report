package com.android.billingclient.api;

import android.text.TextUtils;
import com.google.android.gms.internal.play_billing.zzu;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class ProductDetails {
  private final String zza;
  
  private final JSONObject zzb;
  
  private final String zzc;
  
  private final String zzd;
  
  private final String zze;
  
  private final String zzf;
  
  private final String zzg;
  
  private final String zzh;
  
  private final String zzi;
  
  private final String zzj;
  
  private final String zzk;
  
  private final List zzl;
  
  private final List zzm;
  
  private final zzbj zzn;
  
  ProductDetails(String paramString) throws JSONException {
    this.zza = paramString;
    JSONObject jSONObject = new JSONObject(paramString);
    this.zzb = jSONObject;
    String str = jSONObject.optString(v416f9e89.xbd520268("15931"));
    this.zzc = str;
    paramString = jSONObject.optString(v416f9e89.xbd520268("15932"));
    this.zzd = paramString;
    if (!TextUtils.isEmpty(str)) {
      if (!TextUtils.isEmpty(paramString)) {
        ArrayList<SubscriptionOfferDetails> arrayList;
        this.zze = jSONObject.optString(v416f9e89.xbd520268("15933"));
        this.zzf = jSONObject.optString(v416f9e89.xbd520268("15934"));
        this.zzg = jSONObject.optString(v416f9e89.xbd520268("15935"));
        this.zzi = jSONObject.optString(v416f9e89.xbd520268("15936"));
        this.zzj = jSONObject.optString(v416f9e89.xbd520268("15937"));
        this.zzh = jSONObject.optString(v416f9e89.xbd520268("15938"));
        this.zzk = jSONObject.optString(v416f9e89.xbd520268("15939"));
        JSONArray jSONArray = jSONObject.optJSONArray(v416f9e89.xbd520268("15940"));
        byte b = 0;
        if (jSONArray != null) {
          arrayList = new ArrayList();
          for (int i = 0; i < jSONArray.length(); i++)
            arrayList.add(new SubscriptionOfferDetails(jSONArray.getJSONObject(i))); 
          this.zzl = arrayList;
        } else {
          if (arrayList.equals(v416f9e89.xbd520268("15941")) || arrayList.equals(v416f9e89.xbd520268("15942"))) {
            arrayList = new ArrayList<SubscriptionOfferDetails>();
          } else {
            arrayList = null;
          } 
          this.zzl = arrayList;
        } 
        JSONObject jSONObject1 = this.zzb.optJSONObject(v416f9e89.xbd520268("15943"));
        jSONArray = this.zzb.optJSONArray(v416f9e89.xbd520268("15944"));
        ArrayList<OneTimePurchaseOfferDetails> arrayList1 = new ArrayList();
        if (jSONArray != null) {
          for (int i = b; i < jSONArray.length(); i++)
            arrayList1.add(new OneTimePurchaseOfferDetails(jSONArray.getJSONObject(i))); 
          this.zzm = arrayList1;
        } else if (jSONObject1 != null) {
          arrayList1.add(new OneTimePurchaseOfferDetails(jSONObject1));
          this.zzm = arrayList1;
        } else {
          this.zzm = null;
        } 
        jSONObject1 = this.zzb.optJSONObject(v416f9e89.xbd520268("15945"));
        if (jSONObject1 != null) {
          this.zzn = new zzbj(jSONObject1);
          return;
        } 
        this.zzn = null;
        return;
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("15946"));
    } 
    throw new IllegalArgumentException(v416f9e89.xbd520268("15947"));
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (!(paramObject instanceof ProductDetails))
      return false; 
    paramObject = paramObject;
    return TextUtils.equals(this.zza, ((ProductDetails)paramObject).zza);
  }
  
  public String getDescription() {
    return this.zzg;
  }
  
  public String getName() {
    return this.zzf;
  }
  
  public OneTimePurchaseOfferDetails getOneTimePurchaseOfferDetails() {
    List list = this.zzm;
    return (list != null && !list.isEmpty()) ? this.zzm.get(0) : null;
  }
  
  public String getProductId() {
    return this.zzc;
  }
  
  public String getProductType() {
    return this.zzd;
  }
  
  public List<SubscriptionOfferDetails> getSubscriptionOfferDetails() {
    return this.zzl;
  }
  
  public String getTitle() {
    return this.zze;
  }
  
  public int hashCode() {
    return this.zza.hashCode();
  }
  
  public String toString() {
    String str1 = this.zza;
    String str2 = this.zzb.toString();
    String str3 = this.zzc;
    String str4 = this.zzd;
    String str5 = this.zze;
    String str6 = this.zzh;
    String str7 = String.valueOf(this.zzl);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(v416f9e89.xbd520268("15948"));
    stringBuilder.append(str1);
    stringBuilder.append(v416f9e89.xbd520268("15949"));
    stringBuilder.append(str2);
    stringBuilder.append(v416f9e89.xbd520268("15950"));
    stringBuilder.append(str3);
    stringBuilder.append(v416f9e89.xbd520268("15951"));
    stringBuilder.append(str4);
    stringBuilder.append(v416f9e89.xbd520268("15952"));
    stringBuilder.append(str5);
    stringBuilder.append(v416f9e89.xbd520268("15953"));
    stringBuilder.append(str6);
    stringBuilder.append(v416f9e89.xbd520268("15954"));
    stringBuilder.append(str7);
    stringBuilder.append(v416f9e89.xbd520268("15955"));
    return stringBuilder.toString();
  }
  
  public final String zza() {
    return this.zzb.optString(v416f9e89.xbd520268("15956"));
  }
  
  final String zzb() {
    return this.zzh;
  }
  
  public String zzc() {
    return this.zzk;
  }
  
  public static final class OneTimePurchaseOfferDetails {
    private final String zza;
    
    private final long zzb;
    
    private final String zzc;
    
    private final String zzd;
    
    private final String zze;
    
    private final zzu zzf;
    
    OneTimePurchaseOfferDetails(JSONObject param1JSONObject) throws JSONException {
      this.zza = param1JSONObject.optString(v416f9e89.xbd520268("15845"));
      this.zzb = param1JSONObject.optLong(v416f9e89.xbd520268("15846"));
      this.zzc = param1JSONObject.optString(v416f9e89.xbd520268("15847"));
      this.zzd = param1JSONObject.optString(v416f9e89.xbd520268("15848"));
      this.zze = param1JSONObject.optString(v416f9e89.xbd520268("15849"));
      param1JSONObject.optInt(v416f9e89.xbd520268("15850"));
      JSONArray jSONArray = param1JSONObject.optJSONArray(v416f9e89.xbd520268("15851"));
      ArrayList<String> arrayList = new ArrayList();
      if (jSONArray != null)
        for (int i = 0; i < jSONArray.length(); i++)
          arrayList.add(jSONArray.getString(i));  
      this.zzf = zzu.zzj(arrayList);
    }
    
    public String getFormattedPrice() {
      return this.zza;
    }
    
    public long getPriceAmountMicros() {
      return this.zzb;
    }
    
    public String getPriceCurrencyCode() {
      return this.zzc;
    }
    
    public final String zza() {
      return this.zzd;
    }
  }
  
  public static final class PricingPhase {
    private final int billingCycleCount;
    
    private final String billingPeriod;
    
    private final String formattedPrice;
    
    private final long priceAmountMicros;
    
    private final String priceCurrencyCode;
    
    private final int recurrenceMode;
    
    PricingPhase(JSONObject param1JSONObject) {
      this.billingPeriod = param1JSONObject.optString(v416f9e89.xbd520268("15861"));
      this.priceCurrencyCode = param1JSONObject.optString(v416f9e89.xbd520268("15862"));
      this.formattedPrice = param1JSONObject.optString(v416f9e89.xbd520268("15863"));
      this.priceAmountMicros = param1JSONObject.optLong(v416f9e89.xbd520268("15864"));
      this.recurrenceMode = param1JSONObject.optInt(v416f9e89.xbd520268("15865"));
      this.billingCycleCount = param1JSONObject.optInt(v416f9e89.xbd520268("15866"));
    }
    
    public int getBillingCycleCount() {
      return this.billingCycleCount;
    }
    
    public String getBillingPeriod() {
      return this.billingPeriod;
    }
    
    public String getFormattedPrice() {
      return this.formattedPrice;
    }
    
    public long getPriceAmountMicros() {
      return this.priceAmountMicros;
    }
    
    public String getPriceCurrencyCode() {
      return this.priceCurrencyCode;
    }
    
    public int getRecurrenceMode() {
      return this.recurrenceMode;
    }
  }
  
  public static class PricingPhases {
    private final List<ProductDetails.PricingPhase> pricingPhaseList;
    
    PricingPhases(JSONArray param1JSONArray) {
      ArrayList<ProductDetails.PricingPhase> arrayList = new ArrayList();
      if (param1JSONArray != null)
        for (int i = 0; i < param1JSONArray.length(); i++) {
          JSONObject jSONObject = param1JSONArray.optJSONObject(i);
          if (jSONObject != null)
            arrayList.add(new ProductDetails.PricingPhase(jSONObject)); 
        }  
      this.pricingPhaseList = arrayList;
    }
    
    public List<ProductDetails.PricingPhase> getPricingPhaseList() {
      return this.pricingPhaseList;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface RecurrenceMode {
    public static final int FINITE_RECURRING = 2;
    
    public static final int INFINITE_RECURRING = 1;
    
    public static final int NON_RECURRING = 3;
  }
  
  public static final class SubscriptionOfferDetails {
    private final String zza;
    
    private final String zzb;
    
    private final String zzc;
    
    private final ProductDetails.PricingPhases zzd;
    
    private final List zze;
    
    private final zzbi zzf;
    
    SubscriptionOfferDetails(JSONObject param1JSONObject) throws JSONException {
      zzbi zzbi1;
      this.zza = param1JSONObject.optString(v416f9e89.xbd520268("15872"));
      String str = param1JSONObject.optString(v416f9e89.xbd520268("15873"));
      boolean bool = str.isEmpty();
      JSONObject jSONObject2 = null;
      if (true == bool)
        str = null; 
      this.zzb = str;
      this.zzc = param1JSONObject.getString(v416f9e89.xbd520268("15874"));
      this.zzd = new ProductDetails.PricingPhases(param1JSONObject.getJSONArray(v416f9e89.xbd520268("15875")));
      JSONObject jSONObject1 = param1JSONObject.optJSONObject(v416f9e89.xbd520268("15876"));
      if (jSONObject1 == null) {
        jSONObject1 = jSONObject2;
      } else {
        zzbi1 = new zzbi(jSONObject1);
      } 
      this.zzf = zzbi1;
      ArrayList<String> arrayList = new ArrayList();
      JSONArray jSONArray = param1JSONObject.optJSONArray(v416f9e89.xbd520268("15877"));
      if (jSONArray != null)
        for (int i = 0; i < jSONArray.length(); i++)
          arrayList.add(jSONArray.getString(i));  
      this.zze = arrayList;
    }
    
    public String getBasePlanId() {
      return this.zza;
    }
    
    public String getOfferId() {
      return this.zzb;
    }
    
    public List<String> getOfferTags() {
      return this.zze;
    }
    
    public String getOfferToken() {
      return this.zzc;
    }
    
    public ProductDetails.PricingPhases getPricingPhases() {
      return this.zzd;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\ProductDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */