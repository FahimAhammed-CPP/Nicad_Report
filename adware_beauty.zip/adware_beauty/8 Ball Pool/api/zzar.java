package com.android.billingclient.api;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.RemoteException;
import android.os.ResultReceiver;
import com.google.android.gms.internal.play_billing.zzb;
import com.google.android.gms.internal.play_billing.zzf;
import h8800e55c.pc41fcc5f.v416f9e89;
import java.lang.ref.WeakReference;
import java.util.concurrent.CancellationException;

final class zzar extends zzf {
  final WeakReference zza;
  
  final ResultReceiver zzb;
  
  public final void zza(Bundle paramBundle) throws RemoteException {
    ResultReceiver resultReceiver = this.zzb;
    String str = v416f9e89.xbd520268("15378");
    if (resultReceiver == null) {
      zzb.zzj(str, v416f9e89.xbd520268("15379"));
      return;
    } 
    if (paramBundle == null) {
      resultReceiver.send(0, null);
      return;
    } 
    Activity activity = this.zza.get();
    PendingIntent pendingIntent = (PendingIntent)paramBundle.getParcelable(v416f9e89.xbd520268("15380"));
    if (activity == null || pendingIntent == null) {
      this.zzb.send(0, null);
      zzb.zzj(str, v416f9e89.xbd520268("15384"));
      return;
    } 
    try {
      Intent intent = new Intent((Context)activity, ProxyBillingActivity.class);
      intent.putExtra(v416f9e89.xbd520268("15381"), (Parcelable)this.zzb);
      intent.putExtra(v416f9e89.xbd520268("15382"), (Parcelable)pendingIntent);
      activity.startActivity(intent);
      return;
    } catch (CancellationException cancellationException) {
      this.zzb.send(0, null);
      zzb.zzk(str, v416f9e89.xbd520268("15383"), cancellationException);
      return;
    } 
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\zzar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */