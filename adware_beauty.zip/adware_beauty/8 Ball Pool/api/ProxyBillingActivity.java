package com.android.billingclient.api;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.ResultReceiver;
import android.view.MotionEvent;
import com.google.android.gms.internal.play_billing.zzb;
import h8800e55c.i2482f27b.m8757aece;
import h8800e55c.j2226037f.j6f8e61ad;
import h8800e55c.pc41fcc5f.v416f9e89;

public class ProxyBillingActivity extends Activity {
  static final String KEY_IN_APP_MESSAGE_RESULT_RECEIVER = v416f9e89.xbd520268("15995");
  
  static final String KEY_PRICE_CHANGE_RESULT_RECEIVER = v416f9e89.xbd520268("15996");
  
  private static final String KEY_SEND_CANCELLED_BROADCAST_IF_FINISHED = v416f9e89.xbd520268("15997");
  
  private static final int REQUEST_CODE_FIRST_PARTY_PURCHASE_FLOW = 110;
  
  private static final int REQUEST_CODE_IN_APP_MESSAGE_FLOW = 101;
  
  private static final int REQUEST_CODE_LAUNCH_ACTIVITY = 100;
  
  private static final String TAG = v416f9e89.xbd520268("15998");
  
  private ResultReceiver inAppMessageResultReceiver;
  
  private boolean isFlowFromFirstPartyClient;
  
  private ResultReceiver priceChangeResultReceiver;
  
  private boolean sendCancelledBroadcastIfFinished;
  
  private Intent makeAlternativeBillingIntent(String paramString) {
    Intent intent = new Intent(v416f9e89.xbd520268("15999"));
    intent.setPackage(getApplicationContext().getPackageName());
    intent.putExtra(v416f9e89.xbd520268("16000"), paramString);
    return intent;
  }
  
  private Intent makePurchasesUpdatedIntent() {
    Intent intent = new Intent(v416f9e89.xbd520268("16001"));
    intent.setPackage(getApplicationContext().getPackageName());
    return intent;
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    boolean bool2 = j6f8e61ad.sfe59363d(paramMotionEvent);
    boolean bool1 = bool2;
    if (!bool2)
      bool1 = super.dispatchTouchEvent(paramMotionEvent); 
    return bool1;
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    StringBuilder stringBuilder;
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    ResultReceiver resultReceiver1 = null;
    ResultReceiver resultReceiver3 = null;
    String str = v416f9e89.xbd520268("16002");
    if (paramInt1 == 100 || paramInt1 == 110) {
      int j = zzb.zzd(paramIntent, str).getResponseCode();
      int i = paramInt2;
      if (paramInt2 == -1)
        if (j != 0) {
          i = -1;
        } else {
          paramInt2 = 0;
          resultReceiver3 = this.priceChangeResultReceiver;
        }  
      stringBuilder = new StringBuilder();
      stringBuilder.append(v416f9e89.xbd520268("16005"));
      stringBuilder.append(i);
      stringBuilder.append(v416f9e89.xbd520268("16006"));
      stringBuilder.append(j);
      zzb.zzj(str, stringBuilder.toString());
      paramInt2 = j;
    } else {
      if (paramInt1 == 101) {
        paramInt1 = zzb.zza(paramIntent, str);
        resultReceiver1 = this.inAppMessageResultReceiver;
        if (resultReceiver1 != null) {
          StringBuilder stringBuilder1;
          Bundle bundle;
          if (paramIntent == null) {
            stringBuilder1 = stringBuilder;
          } else {
            bundle = stringBuilder1.getExtras();
          } 
          resultReceiver1.send(paramInt1, bundle);
        } 
      } else {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(v416f9e89.xbd520268("16003"));
        stringBuilder1.append(paramInt1);
        stringBuilder1.append(v416f9e89.xbd520268("16004"));
        zzb.zzj(str, stringBuilder1.toString());
      } 
      this.sendCancelledBroadcastIfFinished = false;
      finish();
    } 
    ResultReceiver resultReceiver2 = this.priceChangeResultReceiver;
  }
  
  protected void onCreate(Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokestatic l0e07204e : (Landroid/app/Activity;Landroid/os/Bundle;)V
    //   5: aload_0
    //   6: aload_1
    //   7: invokespecial onCreate : (Landroid/os/Bundle;)V
    //   10: ldc_w '16018'
    //   13: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   16: astore #6
    //   18: ldc_w '16019'
    //   21: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   24: astore_3
    //   25: ldc_w '16020'
    //   28: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   31: astore #5
    //   33: ldc_w '16021'
    //   36: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   39: astore #4
    //   41: aload_1
    //   42: ifnonnull -> 395
    //   45: aload #4
    //   47: ldc_w '16022'
    //   50: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   53: invokestatic zzi : (Ljava/lang/String;Ljava/lang/String;)V
    //   56: aload_0
    //   57: invokevirtual getIntent : ()Landroid/content/Intent;
    //   60: astore_1
    //   61: ldc_w '16023'
    //   64: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   67: astore #7
    //   69: aload_1
    //   70: aload #7
    //   72: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   75: ifeq -> 133
    //   78: aload_0
    //   79: invokevirtual getIntent : ()Landroid/content/Intent;
    //   82: aload #7
    //   84: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   87: checkcast android/app/PendingIntent
    //   90: astore_3
    //   91: aload_3
    //   92: astore_1
    //   93: aload_0
    //   94: invokevirtual getIntent : ()Landroid/content/Intent;
    //   97: aload #6
    //   99: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   102: ifeq -> 184
    //   105: aload_3
    //   106: astore_1
    //   107: aload_0
    //   108: invokevirtual getIntent : ()Landroid/content/Intent;
    //   111: aload #6
    //   113: iconst_0
    //   114: invokevirtual getBooleanExtra : (Ljava/lang/String;Z)Z
    //   117: ifeq -> 184
    //   120: aload_0
    //   121: iconst_1
    //   122: putfield isFlowFromFirstPartyClient : Z
    //   125: bipush #110
    //   127: istore_2
    //   128: aload_3
    //   129: astore_1
    //   130: goto -> 251
    //   133: aload_0
    //   134: invokevirtual getIntent : ()Landroid/content/Intent;
    //   137: astore_1
    //   138: ldc_w '16024'
    //   141: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   144: astore #6
    //   146: aload_1
    //   147: aload #6
    //   149: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   152: ifeq -> 190
    //   155: aload_0
    //   156: invokevirtual getIntent : ()Landroid/content/Intent;
    //   159: aload #6
    //   161: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   164: checkcast android/app/PendingIntent
    //   167: astore_1
    //   168: aload_0
    //   169: aload_0
    //   170: invokevirtual getIntent : ()Landroid/content/Intent;
    //   173: aload #5
    //   175: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   178: checkcast android/os/ResultReceiver
    //   181: putfield priceChangeResultReceiver : Landroid/os/ResultReceiver;
    //   184: bipush #100
    //   186: istore_2
    //   187: goto -> 251
    //   190: aload_0
    //   191: invokevirtual getIntent : ()Landroid/content/Intent;
    //   194: astore_1
    //   195: ldc_w '16025'
    //   198: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   201: astore #5
    //   203: aload_1
    //   204: aload #5
    //   206: invokevirtual hasExtra : (Ljava/lang/String;)Z
    //   209: ifeq -> 246
    //   212: aload_0
    //   213: invokevirtual getIntent : ()Landroid/content/Intent;
    //   216: aload #5
    //   218: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   221: checkcast android/app/PendingIntent
    //   224: astore_1
    //   225: aload_0
    //   226: aload_0
    //   227: invokevirtual getIntent : ()Landroid/content/Intent;
    //   230: aload_3
    //   231: invokevirtual getParcelableExtra : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   234: checkcast android/os/ResultReceiver
    //   237: putfield inAppMessageResultReceiver : Landroid/os/ResultReceiver;
    //   240: bipush #101
    //   242: istore_2
    //   243: goto -> 251
    //   246: aconst_null
    //   247: astore_1
    //   248: goto -> 184
    //   251: aload_0
    //   252: iconst_1
    //   253: putfield sendCancelledBroadcastIfFinished : Z
    //   256: aload_0
    //   257: aload_1
    //   258: invokevirtual getIntentSender : ()Landroid/content/IntentSender;
    //   261: iload_2
    //   262: new android/content/Intent
    //   265: dup
    //   266: invokespecial <init> : ()V
    //   269: iconst_0
    //   270: iconst_0
    //   271: iconst_0
    //   272: invokevirtual startIntentSenderForResult : (Landroid/content/IntentSender;ILandroid/content/Intent;III)V
    //   275: return
    //   276: astore_1
    //   277: aload #4
    //   279: ldc_w '16026'
    //   282: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   285: aload_1
    //   286: invokestatic zzk : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    //   289: aload_0
    //   290: getfield priceChangeResultReceiver : Landroid/os/ResultReceiver;
    //   293: astore_1
    //   294: aload_1
    //   295: ifnull -> 308
    //   298: aload_1
    //   299: bipush #6
    //   301: aconst_null
    //   302: invokevirtual send : (ILandroid/os/Bundle;)V
    //   305: goto -> 385
    //   308: aload_0
    //   309: getfield inAppMessageResultReceiver : Landroid/os/ResultReceiver;
    //   312: astore_1
    //   313: aload_1
    //   314: ifnull -> 326
    //   317: aload_1
    //   318: iconst_0
    //   319: aconst_null
    //   320: invokevirtual send : (ILandroid/os/Bundle;)V
    //   323: goto -> 385
    //   326: aload_0
    //   327: invokespecial makePurchasesUpdatedIntent : ()Landroid/content/Intent;
    //   330: astore_1
    //   331: aload_0
    //   332: getfield isFlowFromFirstPartyClient : Z
    //   335: ifeq -> 350
    //   338: aload_1
    //   339: ldc_w '16027'
    //   342: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   345: iconst_1
    //   346: invokevirtual putExtra : (Ljava/lang/String;Z)Landroid/content/Intent;
    //   349: pop
    //   350: aload_1
    //   351: ldc_w '16028'
    //   354: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   357: bipush #6
    //   359: invokevirtual putExtra : (Ljava/lang/String;I)Landroid/content/Intent;
    //   362: pop
    //   363: aload_1
    //   364: ldc_w '16029'
    //   367: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   370: ldc_w '16030'
    //   373: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   376: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   379: pop
    //   380: aload_0
    //   381: aload_1
    //   382: invokestatic sendBroadcast : (Ljava/lang/Object;Landroid/content/Intent;)V
    //   385: aload_0
    //   386: iconst_0
    //   387: putfield sendCancelledBroadcastIfFinished : Z
    //   390: aload_0
    //   391: invokevirtual finish : ()V
    //   394: return
    //   395: aload #4
    //   397: ldc_w '16031'
    //   400: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   403: invokestatic zzi : (Ljava/lang/String;Ljava/lang/String;)V
    //   406: aload_0
    //   407: aload_1
    //   408: ldc_w '16032'
    //   411: invokestatic xbd520268 : (Ljava/lang/String;)Ljava/lang/String;
    //   414: iconst_0
    //   415: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   418: putfield sendCancelledBroadcastIfFinished : Z
    //   421: aload_1
    //   422: aload #5
    //   424: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   427: ifeq -> 446
    //   430: aload_0
    //   431: aload_1
    //   432: aload #5
    //   434: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   437: checkcast android/os/ResultReceiver
    //   440: putfield priceChangeResultReceiver : Landroid/os/ResultReceiver;
    //   443: goto -> 466
    //   446: aload_1
    //   447: aload_3
    //   448: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   451: ifeq -> 466
    //   454: aload_0
    //   455: aload_1
    //   456: aload_3
    //   457: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   460: checkcast android/os/ResultReceiver
    //   463: putfield inAppMessageResultReceiver : Landroid/os/ResultReceiver;
    //   466: aload_0
    //   467: aload_1
    //   468: aload #6
    //   470: iconst_0
    //   471: invokevirtual getBoolean : (Ljava/lang/String;Z)Z
    //   474: putfield isFlowFromFirstPartyClient : Z
    //   477: return
    // Exception table:
    //   from	to	target	type
    //   251	275	276	android/content/IntentSender$SendIntentException
  }
  
  protected void onDestroy() {
    super.onDestroy();
    if (!isFinishing())
      return; 
    if (!this.sendCancelledBroadcastIfFinished)
      return; 
    Intent intent = makePurchasesUpdatedIntent();
    intent.putExtra(v416f9e89.xbd520268("16033"), 1);
    intent.putExtra(v416f9e89.xbd520268("16034"), v416f9e89.xbd520268("16035"));
    m8757aece.sendBroadcast(this, intent);
  }
  
  public void onPause() {
    j6f8e61ad.z0aa930f8(this);
    super.onPause();
  }
  
  public void onResume() {
    j6f8e61ad.wfa3e02d7(this);
    super.onResume();
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    ResultReceiver resultReceiver = this.priceChangeResultReceiver;
    if (resultReceiver != null)
      paramBundle.putParcelable(v416f9e89.xbd520268("16036"), (Parcelable)resultReceiver); 
    resultReceiver = this.inAppMessageResultReceiver;
    if (resultReceiver != null)
      paramBundle.putParcelable(v416f9e89.xbd520268("16037"), (Parcelable)resultReceiver); 
    boolean bool = this.sendCancelledBroadcastIfFinished;
    paramBundle.putBoolean(v416f9e89.xbd520268("16038"), bool);
    bool = this.isFlowFromFirstPartyClient;
    paramBundle.putBoolean(v416f9e89.xbd520268("16039"), bool);
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    boolean bool2 = j6f8e61ad.aa6d88357(paramMotionEvent);
    boolean bool1 = bool2;
    if (!bool2)
      bool1 = super.onTouchEvent(paramMotionEvent); 
    return bool1;
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\ProxyBillingActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */