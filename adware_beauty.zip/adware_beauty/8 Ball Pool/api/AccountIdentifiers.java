package com.android.billingclient.api;

public final class AccountIdentifiers {
  private final String zza;
  
  private final String zzb;
  
  AccountIdentifiers(String paramString1, String paramString2) {
    this.zza = paramString1;
    this.zzb = paramString2;
  }
  
  public String getObfuscatedAccountId() {
    return this.zza;
  }
  
  public String getObfuscatedProfileId() {
    return this.zzb;
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\AccountIdentifiers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */