package com.android.billingclient.api;

import h8800e55c.pc41fcc5f.v416f9e89;

public final class ConsumeParams {
  private String zza;
  
  private ConsumeParams() {}
  
  public static Builder newBuilder() {
    return new Builder(null);
  }
  
  public String getPurchaseToken() {
    return this.zza;
  }
  
  public static final class Builder {
    private String zza;
    
    private Builder() {}
    
    public ConsumeParams build() {
      String str = this.zza;
      if (str != null) {
        ConsumeParams consumeParams = new ConsumeParams(null);
        ConsumeParams.zza(consumeParams, str);
        return consumeParams;
      } 
      throw new IllegalArgumentException(v416f9e89.xbd520268("15793"));
    }
    
    public Builder setPurchaseToken(String param1String) {
      this.zza = param1String;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\8 Ball Pool-dex2jar.jar!\com\android\billingclient\api\ConsumeParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */