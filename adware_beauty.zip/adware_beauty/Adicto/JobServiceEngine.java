package android.app.job;

import android.app.Service;
import android.os.IBinder;



/* Location:              C:\soft\dex2jar-2.0\Adicto_ Ai Art Generator-dex2jar.jar!\android\app\job\JobServiceEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */