package com.tencent.bugly.legu.crashreport;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import com.tencent.bugly.legu.BuglyStrategy;
import com.tencent.bugly.legu.CrashModule;
import com.tencent.bugly.legu.b;
import com.tencent.bugly.legu.crashreport.biz.b;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.crash.BuglyBroadcastRecevier;
import com.tencent.bugly.legu.crashreport.crash.h5.H5JavaScriptInterface;
import com.tencent.bugly.legu.crashreport.crash.h5.c;
import com.tencent.bugly.legu.crashreport.crash.jni.NativeCrashHandler;
import com.tencent.bugly.legu.proguard.v;
import com.tencent.bugly.legu.proguard.w;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class CrashReport {
  private static Context a;
  
  public static void closeBugly() {
    if (!b.a) {
      Log.w(w.a, "Can not close bugly because bugly is disable.");
      return;
    } 
    if (!CrashModule.hasInitialized()) {
      Log.w(w.a, "CrashReport has not been initialed! pls to call method 'initCrashReport' first!");
      return;
    } 
    if (a != null) {
      BuglyBroadcastRecevier buglyBroadcastRecevier = BuglyBroadcastRecevier.getInstance();
      if (buglyBroadcastRecevier != null)
        buglyBroadcastRecevier.unregist(a); 
      closeCrashReport();
      b.a(a);
      v v = v.a();
      if (v != null)
        v.b(); 
    } 
  }
  
  public static void closeCrashReport() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.a : Z
    //   6: ifne -> 22
    //   9: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   12: ldc 'Can not close crash report because bugly is disable.'
    //   14: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   20: monitorexit
    //   21: return
    //   22: invokestatic hasInitialized : ()Z
    //   25: ifne -> 46
    //   28: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   31: ldc 'CrashReport has not been initialed! pls to call method 'initCrashReport' first!'
    //   33: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   36: pop
    //   37: goto -> 18
    //   40: astore_0
    //   41: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   43: monitorexit
    //   44: aload_0
    //   45: athrow
    //   46: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/crash/c;
    //   49: invokevirtual d : ()V
    //   52: goto -> 18
    // Exception table:
    //   from	to	target	type
    //   3	18	40	finally
    //   22	37	40	finally
    //   46	52	40	finally
  }
  
  public static void closeNativeReport() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.a : Z
    //   6: ifne -> 22
    //   9: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   12: ldc 'Can not close native report because bugly is disable.'
    //   14: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   20: monitorexit
    //   21: return
    //   22: invokestatic hasInitialized : ()Z
    //   25: ifne -> 46
    //   28: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   31: ldc 'CrashReport has not been initialed! pls to call method 'initCrashReport' first!'
    //   33: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   36: pop
    //   37: goto -> 18
    //   40: astore_0
    //   41: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   43: monitorexit
    //   44: aload_0
    //   45: athrow
    //   46: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/crash/c;
    //   49: invokevirtual f : ()V
    //   52: goto -> 18
    // Exception table:
    //   from	to	target	type
    //   3	18	40	finally
    //   22	37	40	finally
    //   46	52	40	finally
  }
  
  public static void enableBugly(boolean paramBoolean) {
    b.a = paramBoolean;
  }
  
  public static Set<String> getAllUserDataKeys(Context paramContext) {
    if (!b.a) {
      Log.w(w.a, "Can not get all keys of user data because bugly is disable.");
      return new HashSet();
    } 
    if (paramContext == null) {
      Log.e(w.a, "getAllUserDataKeys args context should not be null");
      return new HashSet();
    } 
    return a.a(paramContext).z();
  }
  
  public static String getAppChannel() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.a : Z
    //   6: ifne -> 26
    //   9: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   12: ldc 'Can not get App channel because bugly is disable.'
    //   14: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: ldc 'unknown'
    //   20: astore_0
    //   21: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   23: monitorexit
    //   24: aload_0
    //   25: areturn
    //   26: invokestatic hasInitialized : ()Z
    //   29: ifne -> 47
    //   32: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   35: ldc 'CrashReport has not been initialed! pls to call method 'initCrashReport' first!'
    //   37: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   40: pop
    //   41: ldc 'unknown'
    //   43: astore_0
    //   44: goto -> 21
    //   47: getstatic com/tencent/bugly/legu/crashreport/CrashReport.a : Landroid/content/Context;
    //   50: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   53: getfield j : Ljava/lang/String;
    //   56: astore_0
    //   57: goto -> 21
    //   60: astore_0
    //   61: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   63: monitorexit
    //   64: aload_0
    //   65: athrow
    // Exception table:
    //   from	to	target	type
    //   3	18	60	finally
    //   26	41	60	finally
    //   47	57	60	finally
  }
  
  public static String getAppID() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.a : Z
    //   6: ifne -> 26
    //   9: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   12: ldc 'Can not get App ID because bugly is disable.'
    //   14: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: ldc 'unknown'
    //   20: astore_0
    //   21: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   23: monitorexit
    //   24: aload_0
    //   25: areturn
    //   26: invokestatic hasInitialized : ()Z
    //   29: ifne -> 47
    //   32: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   35: ldc 'CrashReport has not been initialed! pls to call method 'initCrashReport' first!'
    //   37: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   40: pop
    //   41: ldc 'unknown'
    //   43: astore_0
    //   44: goto -> 21
    //   47: getstatic com/tencent/bugly/legu/crashreport/CrashReport.a : Landroid/content/Context;
    //   50: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   53: invokevirtual e : ()Ljava/lang/String;
    //   56: astore_0
    //   57: goto -> 21
    //   60: astore_0
    //   61: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   63: monitorexit
    //   64: aload_0
    //   65: athrow
    // Exception table:
    //   from	to	target	type
    //   3	18	60	finally
    //   26	41	60	finally
    //   47	57	60	finally
  }
  
  public static String getAppVer() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.a : Z
    //   6: ifne -> 26
    //   9: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   12: ldc 'Can not get app version because bugly is disable.'
    //   14: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: ldc 'unknown'
    //   20: astore_0
    //   21: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   23: monitorexit
    //   24: aload_0
    //   25: areturn
    //   26: invokestatic hasInitialized : ()Z
    //   29: ifne -> 47
    //   32: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   35: ldc 'CrashReport has not been initialed! pls to call method 'initCrashReport' first!'
    //   37: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   40: pop
    //   41: ldc 'unknown'
    //   43: astore_0
    //   44: goto -> 21
    //   47: getstatic com/tencent/bugly/legu/crashreport/CrashReport.a : Landroid/content/Context;
    //   50: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   53: getfield i : Ljava/lang/String;
    //   56: astore_0
    //   57: goto -> 21
    //   60: astore_0
    //   61: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   63: monitorexit
    //   64: aload_0
    //   65: athrow
    // Exception table:
    //   from	to	target	type
    //   3	18	60	finally
    //   26	41	60	finally
    //   47	57	60	finally
  }
  
  public static String getBuglyVersion(Context paramContext) {
    if (paramContext == null) {
      w.d("Please call with context.", new Object[0]);
      return "unknown";
    } 
    a.a(paramContext);
    return a.b();
  }
  
  public static Map<String, String> getSdkExtraData() {
    if (!b.a) {
      Log.w(w.a, "Can not get SDK extra data because bugly is disable.");
      return (Map)new HashMap<Object, Object>();
    } 
    return b.c;
  }
  
  public static String getUserData(Context paramContext, String paramString) {
    boolean bool;
    if (!b.a) {
      Log.w(w.a, "Can not get user data because bugly is disable.");
      return "unknown";
    } 
    if (paramContext == null) {
      Log.e(w.a, "getUserDataValue args context should not be null");
      return "unknown";
    } 
    if (paramString != null && paramString.trim().length() > 0) {
      bool = false;
    } else {
      bool = true;
    } 
    return bool ? null : a.a(paramContext).g(paramString);
  }
  
  public static int getUserDatasSize(Context paramContext) {
    null = -1;
    if (!b.a) {
      Log.w(w.a, "Can not get size of user data because bugly is disable.");
      return null;
    } 
    if (paramContext == null) {
      Log.e(w.a, "getUserDatasSize args context should not be null");
      return null;
    } 
    return a.a(paramContext).y();
  }
  
  public static String getUserId() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.a : Z
    //   6: ifne -> 26
    //   9: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   12: ldc 'Can not get user ID because bugly is disable.'
    //   14: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: ldc 'unknown'
    //   20: astore_0
    //   21: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   23: monitorexit
    //   24: aload_0
    //   25: areturn
    //   26: invokestatic hasInitialized : ()Z
    //   29: ifne -> 47
    //   32: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   35: ldc 'CrashReport has not been initialed! pls to call method 'initCrashReport' first!'
    //   37: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   40: pop
    //   41: ldc 'unknown'
    //   43: astore_0
    //   44: goto -> 21
    //   47: getstatic com/tencent/bugly/legu/crashreport/CrashReport.a : Landroid/content/Context;
    //   50: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   53: invokevirtual f : ()Ljava/lang/String;
    //   56: astore_0
    //   57: goto -> 21
    //   60: astore_0
    //   61: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   63: monitorexit
    //   64: aload_0
    //   65: athrow
    // Exception table:
    //   from	to	target	type
    //   3	18	60	finally
    //   26	41	60	finally
    //   47	57	60	finally
  }
  
  public static int getUserSceneTagId(Context paramContext) {
    null = -1;
    if (!b.a) {
      Log.w(w.a, "Can not get user scene tag because bugly is disable.");
      return null;
    } 
    if (paramContext == null) {
      Log.e(w.a, "getUserSceneTagId args context should not be null");
      return null;
    } 
    return a.a(paramContext).B();
  }
  
  public static void initCrashReport(Context paramContext) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: aload_0
    //   4: putstatic com/tencent/bugly/legu/crashreport/CrashReport.a : Landroid/content/Context;
    //   7: invokestatic getInstance : ()Lcom/tencent/bugly/legu/CrashModule;
    //   10: invokestatic a : (Lcom/tencent/bugly/legu/a;)V
    //   13: aload_0
    //   14: invokestatic a : (Landroid/content/Context;)V
    //   17: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   19: monitorexit
    //   20: return
    //   21: astore_0
    //   22: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   24: monitorexit
    //   25: aload_0
    //   26: athrow
    // Exception table:
    //   from	to	target	type
    //   3	17	21	finally
  }
  
  public static void initCrashReport(Context paramContext, UserStrategy paramUserStrategy) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: aload_0
    //   4: putstatic com/tencent/bugly/legu/crashreport/CrashReport.a : Landroid/content/Context;
    //   7: invokestatic getInstance : ()Lcom/tencent/bugly/legu/CrashModule;
    //   10: invokestatic a : (Lcom/tencent/bugly/legu/a;)V
    //   13: aload_0
    //   14: aload_1
    //   15: invokestatic a : (Landroid/content/Context;Lcom/tencent/bugly/legu/BuglyStrategy;)V
    //   18: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   20: monitorexit
    //   21: return
    //   22: astore_0
    //   23: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   25: monitorexit
    //   26: aload_0
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   3	18	22	finally
  }
  
  public static void initCrashReport(Context paramContext, String paramString, boolean paramBoolean) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: aload_0
    //   4: aload_1
    //   5: iload_2
    //   6: aconst_null
    //   7: invokestatic initCrashReport : (Landroid/content/Context;Ljava/lang/String;ZLcom/tencent/bugly/legu/crashreport/CrashReport$UserStrategy;)V
    //   10: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   12: monitorexit
    //   13: return
    //   14: astore_0
    //   15: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   17: monitorexit
    //   18: aload_0
    //   19: athrow
    // Exception table:
    //   from	to	target	type
    //   3	10	14	finally
  }
  
  public static void initCrashReport(Context paramContext, String paramString, boolean paramBoolean, UserStrategy paramUserStrategy) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnonnull -> 11
    //   7: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   9: monitorexit
    //   10: return
    //   11: aload_0
    //   12: putstatic com/tencent/bugly/legu/crashreport/CrashReport.a : Landroid/content/Context;
    //   15: invokestatic getInstance : ()Lcom/tencent/bugly/legu/CrashModule;
    //   18: invokestatic a : (Lcom/tencent/bugly/legu/a;)V
    //   21: aload_0
    //   22: aload_1
    //   23: iload_2
    //   24: aload_3
    //   25: invokestatic a : (Landroid/content/Context;Ljava/lang/String;ZLcom/tencent/bugly/legu/BuglyStrategy;)V
    //   28: goto -> 7
    //   31: astore_0
    //   32: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   34: monitorexit
    //   35: aload_0
    //   36: athrow
    // Exception table:
    //   from	to	target	type
    //   11	28	31	finally
  }
  
  public static boolean isLastSessionCrash() {
    // Byte code:
    //   0: iconst_0
    //   1: istore_0
    //   2: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   4: monitorenter
    //   5: getstatic com/tencent/bugly/legu/b.a : Z
    //   8: ifne -> 25
    //   11: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   14: ldc 'The info 'isLastSessionCrash' is not accurate because bugly is disable.'
    //   16: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   19: pop
    //   20: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   22: monitorexit
    //   23: iload_0
    //   24: ireturn
    //   25: invokestatic hasInitialized : ()Z
    //   28: ifne -> 49
    //   31: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   34: ldc 'CrashReport has not been initialed! pls to call method 'initCrashReport' first!'
    //   36: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   39: pop
    //   40: goto -> 20
    //   43: astore_1
    //   44: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    //   49: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/crash/c;
    //   52: invokevirtual b : ()Z
    //   55: istore_0
    //   56: goto -> 20
    // Exception table:
    //   from	to	target	type
    //   5	20	43	finally
    //   25	40	43	finally
    //   49	56	43	finally
  }
  
  public static void postCatchedException(Throwable paramThrowable) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: aload_0
    //   4: iconst_0
    //   5: invokestatic postCatchedException : (Ljava/lang/Throwable;Z)V
    //   8: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   10: monitorexit
    //   11: return
    //   12: astore_0
    //   13: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   15: monitorexit
    //   16: aload_0
    //   17: athrow
    // Exception table:
    //   from	to	target	type
    //   3	8	12	finally
  }
  
  public static void postCatchedException(Throwable paramThrowable, boolean paramBoolean) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.a : Z
    //   6: ifne -> 22
    //   9: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   12: ldc 'Can not post crash caught because bugly is disable.'
    //   14: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   17: pop
    //   18: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   20: monitorexit
    //   21: return
    //   22: invokestatic hasInitialized : ()Z
    //   25: ifne -> 46
    //   28: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   31: ldc 'CrashReport has not been initialed! pls to call method 'initCrashReport' first!'
    //   33: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   36: pop
    //   37: goto -> 18
    //   40: astore_0
    //   41: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   43: monitorexit
    //   44: aload_0
    //   45: athrow
    //   46: aload_0
    //   47: ifnonnull -> 63
    //   50: ldc 'throwable is null, just return'
    //   52: iconst_0
    //   53: anewarray java/lang/Object
    //   56: invokestatic d : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   59: pop
    //   60: goto -> 18
    //   63: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/crash/c;
    //   66: invokestatic currentThread : ()Ljava/lang/Thread;
    //   69: aload_0
    //   70: iconst_0
    //   71: aconst_null
    //   72: aconst_null
    //   73: invokevirtual a : (Ljava/lang/Thread;Ljava/lang/Throwable;ZLjava/lang/String;[B)V
    //   76: iload_1
    //   77: ifeq -> 18
    //   80: ldc 'clear user datas'
    //   82: iconst_0
    //   83: anewarray java/lang/Object
    //   86: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   89: pop
    //   90: getstatic com/tencent/bugly/legu/crashreport/CrashReport.a : Landroid/content/Context;
    //   93: invokestatic a : (Landroid/content/Context;)Lcom/tencent/bugly/legu/crashreport/common/info/a;
    //   96: invokevirtual x : ()V
    //   99: goto -> 18
    // Exception table:
    //   from	to	target	type
    //   3	18	40	finally
    //   22	37	40	finally
    //   50	60	40	finally
    //   63	76	40	finally
    //   80	99	40	finally
  }
  
  private static void putSdkData(Context paramContext, String paramString1, String paramString2) {
    if (paramContext != null) {
      boolean bool;
      if (paramString1 != null && paramString1.trim().length() > 0) {
        bool = false;
      } else {
        bool = true;
      } 
      if (!bool) {
        if (paramString2 != null && paramString2.trim().length() > 0) {
          bool = false;
        } else {
          bool = true;
        } 
        if (!bool) {
          String str = paramString1.replace("[a-zA-Z[0-9]]+", "");
          paramString1 = str;
          if (str.length() > 100) {
            Log.w(w.a, String.format("putSdkData key length over limit %d, will be cutted.", new Object[] { Integer.valueOf(50) }));
            paramString1 = str.substring(0, 50);
          } 
          str = paramString2;
          if (paramString2.length() > 500) {
            Log.w(w.a, String.format("putSdkData value length over limit %d, will be cutted!", new Object[] { Integer.valueOf(200) }));
            str = paramString2.substring(0, 200);
          } 
          a.a(paramContext).b(paramString1, str);
          w.b(String.format("[param] putSdkData data: %s - %s", new Object[] { paramString1, str }), new Object[0]);
        } 
      } 
    } 
  }
  
  public static void putUserData(Context paramContext, String paramString1, String paramString2) {
    NativeCrashHandler nativeCrashHandler2;
    if (!b.a) {
      Log.w(w.a, "Can not put user data because bugly is disable.");
      return;
    } 
    if (paramContext == null) {
      Log.w(w.a, "putUserData args context should not be null");
      return;
    } 
    if (paramString1 == null) {
      w.d("putUserData args key should not be null or empty", new Object[0]);
      return;
    } 
    if (paramString2 == null) {
      w.d("putUserData args value should not be null", new Object[0]);
      return;
    } 
    if (!paramString1.matches("[a-zA-Z[0-9]]+")) {
      w.d("putUserData args key should match [a-zA-Z[0-9]]+  {" + paramString1 + "}", new Object[0]);
      return;
    } 
    String str2 = paramString2;
    if (paramString2.length() > 200) {
      w.d("user data value length over limit %d, it will be cutted!", new Object[] { Integer.valueOf(200) });
      str2 = paramString2.substring(0, 200);
    } 
    a a = a.a(paramContext);
    if (a.z().contains(paramString1)) {
      nativeCrashHandler2 = NativeCrashHandler.getInstance();
      if (nativeCrashHandler2 != null)
        nativeCrashHandler2.putKeyValueToNative(paramString1, str2); 
      a.a(paramContext).a(paramString1, str2);
      w.c("replace KV %s %s", new Object[] { paramString1, str2 });
      return;
    } 
    if (nativeCrashHandler2.y() >= 10) {
      w.d("user data size is over limit %d, it will be cutted!", new Object[] { Integer.valueOf(10) });
      return;
    } 
    String str1 = paramString1;
    if (paramString1.length() > 50) {
      w.d("user data key length over limit %d , will drop this new key %s", new Object[] { Integer.valueOf(50), paramString1 });
      str1 = paramString1.substring(0, 50);
    } 
    NativeCrashHandler nativeCrashHandler1 = NativeCrashHandler.getInstance();
    if (nativeCrashHandler1 != null)
      nativeCrashHandler1.putKeyValueToNative(str1, str2); 
    a.a(paramContext).a(str1, str2);
    w.b("[param] set user data: %s - %s", new Object[] { str1, str2 });
  }
  
  public static String removeUserData(Context paramContext, String paramString) {
    boolean bool;
    if (!b.a) {
      Log.w(w.a, "Can not remove user data because bugly is disable.");
      return "unknown";
    } 
    if (paramContext == null) {
      Log.e(w.a, "removeUserData args context should not be null");
      return "unknown";
    } 
    if (paramString != null && paramString.trim().length() > 0) {
      bool = false;
    } else {
      bool = true;
    } 
    if (bool)
      return null; 
    w.b("[param] remove user data: %s", new Object[] { paramString });
    return a.a(paramContext).f(paramString);
  }
  
  public static void setAppVersion(Context paramContext, String paramString) {
    if (!b.a) {
      Log.w(w.a, "Can not set APP version because bugly is disable.");
      return;
    } 
    if (paramContext == null) {
      Log.w(w.a, "setAppVersion args context should not be null");
      return;
    } 
    if (paramString == null) {
      Log.w(w.a, "Version is null, will not set");
      return;
    } 
    (a.a(paramContext)).i = paramString;
  }
  
  public static void setContext(Context paramContext) {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: aload_0
    //   4: putstatic com/tencent/bugly/legu/crashreport/CrashReport.a : Landroid/content/Context;
    //   7: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   9: monitorexit
    //   10: return
    //   11: astore_0
    //   12: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   14: monitorexit
    //   15: aload_0
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	11	finally
  }
  
  public static void setIsAppForeground(Context paramContext, boolean paramBoolean) {
    if (!b.a) {
      Log.w(w.a, "Can not set 'isAppForeground' because bugly is disable.");
      return;
    } 
    if (paramContext == null) {
      w.d("Context should not be null.", new Object[0]);
      return;
    } 
    if (paramBoolean) {
      w.c("App is in foreground.", new Object[0]);
    } else {
      w.c("App is in background.", new Object[0]);
    } 
    (a.a(paramContext)).n = paramBoolean;
  }
  
  public static void setIsDevelopmentDevice(Context paramContext, boolean paramBoolean) {
    if (!b.a) {
      Log.w(w.a, "Can not set 'isDevelopmentDevice' because bugly is disable.");
      return;
    } 
    if (paramContext == null) {
      w.d("Context should not be null.", new Object[0]);
      return;
    } 
    if (paramBoolean) {
      w.c("This is a development device.", new Object[0]);
    } else {
      w.c("This is not a development device.", new Object[0]);
    } 
    (a.a(paramContext)).x = paramBoolean;
  }
  
  public static boolean setJavascriptMonitor(WebView paramWebView, boolean paramBoolean) {
    return setJavascriptMonitor(paramWebView, paramBoolean, false);
  }
  
  @SuppressLint({"SetJavaScriptEnabled"})
  public static boolean setJavascriptMonitor(WebView paramWebView, boolean paramBoolean1, boolean paramBoolean2) {
    boolean bool1 = false;
    if (paramWebView == null) {
      Log.w(w.a, "Webview is null.");
      return bool1;
    } 
    if (!CrashModule.hasInitialized()) {
      w.e("CrashReport has not been initialed! please to call method 'initCrashReport' first!", new Object[0]);
      return bool1;
    } 
    w.a("Set Javascript exception monitor of webview.", new Object[0]);
    if (!b.a) {
      Log.w(w.a, "Can not set JavaScript monitor because bugly is disable.");
      return bool1;
    } 
    w.c("URL of webview is %s", new Object[] { paramWebView.getUrl() });
    boolean bool2 = bool1;
    if (paramWebView.getUrl() != null) {
      if (!paramBoolean2 && Build.VERSION.SDK_INT < 19) {
        w.e("This interface is only available for Android 4.4 or later.", new Object[0]);
        return bool1;
      } 
      WebSettings webSettings = paramWebView.getSettings();
      if (!webSettings.getJavaScriptEnabled()) {
        w.a("Enable the javascript needed by webview monitor.", new Object[0]);
        webSettings.setJavaScriptEnabled(true);
      } 
      H5JavaScriptInterface h5JavaScriptInterface = H5JavaScriptInterface.getInstance(paramWebView);
      if (h5JavaScriptInterface != null) {
        w.a("Add a secure javascript interface to the webview.", new Object[0]);
        paramWebView.addJavascriptInterface(h5JavaScriptInterface, "exceptionUploader");
      } 
      if (paramBoolean1) {
        w.a("Inject bugly.js(v%s) to the webview.", new Object[] { c.b() });
        String str = c.a();
        if (str == null) {
          w.e("Failed to inject Bugly.js.", new Object[] { c.b() });
          return bool1;
        } 
        paramWebView.loadUrl("javascript:" + str);
      } 
      bool2 = true;
    } 
    return bool2;
  }
  
  public static void setSdkExtraData(Context paramContext, String paramString1, String paramString2) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   4: monitorenter
    //   5: getstatic com/tencent/bugly/legu/b.a : Z
    //   8: ifne -> 25
    //   11: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   14: ldc_w 'Can not put SDK extra data because bugly is disable.'
    //   17: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   20: pop
    //   21: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   23: monitorexit
    //   24: return
    //   25: aload_0
    //   26: ifnull -> 21
    //   29: aload_1
    //   30: ifnull -> 216
    //   33: aload_1
    //   34: invokevirtual trim : ()Ljava/lang/String;
    //   37: invokevirtual length : ()I
    //   40: ifle -> 216
    //   43: iconst_0
    //   44: istore #4
    //   46: iload #4
    //   48: ifne -> 21
    //   51: aload_2
    //   52: ifnull -> 222
    //   55: aload_2
    //   56: invokevirtual trim : ()Ljava/lang/String;
    //   59: invokevirtual length : ()I
    //   62: ifle -> 222
    //   65: iload_3
    //   66: istore #4
    //   68: iload #4
    //   70: ifne -> 21
    //   73: getstatic com/tencent/bugly/legu/b.c : Ljava/util/Map;
    //   76: astore #5
    //   78: aload #5
    //   80: ifnonnull -> 250
    //   83: new java/util/HashMap
    //   86: astore #5
    //   88: aload #5
    //   90: invokespecial <init> : ()V
    //   93: aload #5
    //   95: aload_1
    //   96: aload_2
    //   97: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   102: pop
    //   103: aload #5
    //   105: invokeinterface size : ()I
    //   110: ifle -> 236
    //   113: aload #5
    //   115: invokeinterface entrySet : ()Ljava/util/Set;
    //   120: invokeinterface iterator : ()Ljava/util/Iterator;
    //   125: astore_2
    //   126: ldc ''
    //   128: astore_1
    //   129: aload_2
    //   130: invokeinterface hasNext : ()Z
    //   135: ifeq -> 228
    //   138: aload_2
    //   139: invokeinterface next : ()Ljava/lang/Object;
    //   144: checkcast java/util/Map$Entry
    //   147: astore #6
    //   149: new java/lang/StringBuilder
    //   152: astore #7
    //   154: aload #7
    //   156: invokespecial <init> : ()V
    //   159: aload #7
    //   161: aload_1
    //   162: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   165: ldc_w '['
    //   168: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   171: aload #6
    //   173: invokeinterface getKey : ()Ljava/lang/Object;
    //   178: checkcast java/lang/String
    //   181: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   184: ldc_w ','
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: aload #6
    //   192: invokeinterface getValue : ()Ljava/lang/Object;
    //   197: checkcast java/lang/String
    //   200: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   203: ldc_w '] '
    //   206: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   209: invokevirtual toString : ()Ljava/lang/String;
    //   212: astore_1
    //   213: goto -> 129
    //   216: iconst_1
    //   217: istore #4
    //   219: goto -> 46
    //   222: iconst_1
    //   223: istore #4
    //   225: goto -> 68
    //   228: aload_0
    //   229: ldc_w 'SDK_INFO'
    //   232: aload_1
    //   233: invokestatic putSdkData : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   236: aload #5
    //   238: putstatic com/tencent/bugly/legu/b.c : Ljava/util/Map;
    //   241: goto -> 21
    //   244: astore_0
    //   245: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   247: monitorexit
    //   248: aload_0
    //   249: athrow
    //   250: goto -> 93
    // Exception table:
    //   from	to	target	type
    //   5	21	244	finally
    //   33	43	244	finally
    //   55	65	244	finally
    //   73	78	244	finally
    //   83	93	244	finally
    //   93	126	244	finally
    //   129	213	244	finally
    //   228	236	244	finally
    //   236	241	244	finally
  }
  
  public static void setSessionIntervalMills(long paramLong) {
    if (!b.a) {
      Log.w(w.a, "Can not set 'SessionIntervalMills' because bugly is disable.");
      return;
    } 
    b.a(paramLong);
  }
  
  public static void setUserId(Context paramContext, String paramString) {
    if (!b.a) {
      Log.w(w.a, "Can not set user ID because bugly is disable.");
      return;
    } 
    if (paramContext == null) {
      Log.e(w.a, "Context should not be null when bugly has not been initialed!");
      return;
    } 
    if (paramString == null) {
      w.d("userId should not be null", new Object[0]);
      return;
    } 
    String str = paramString;
    if (paramString.length() > 100) {
      str = paramString.substring(0, 100);
      w.d("userId %s length is over limit %d substring to %s", new Object[] { paramString, Integer.valueOf(100), str });
    } 
    if (!str.equals(a.a(paramContext).f())) {
      a.a(paramContext).b(str);
      w.b("[user] set userId : %s", new Object[] { str });
      if (CrashModule.hasInitialized())
        b.a(); 
    } 
  }
  
  public static void setUserId(String paramString) {
    if (!b.a) {
      Log.w(w.a, "Can not set user ID because bugly is disable.");
      return;
    } 
    if (!CrashModule.hasInitialized()) {
      Log.e(w.a, "CrashReport has not been initialed! pls to call method 'initCrashReport' first!");
      return;
    } 
    setUserId(a, paramString);
  }
  
  public static void setUserSceneTag(Context paramContext, int paramInt) {
    if (!b.a) {
      Log.w(w.a, "Can not set tag caught because bugly is disable.");
      return;
    } 
    if (paramContext == null) {
      Log.e(w.a, "setTag args context should not be null");
      return;
    } 
    if (paramInt <= 0)
      w.d("setTag args tagId should > 0", new Object[0]); 
    a.a(paramContext).a(paramInt);
    w.b("[param] set user scene tag: %d", new Object[] { Integer.valueOf(paramInt) });
  }
  
  public static void startCrashReport() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.a : Z
    //   6: ifne -> 23
    //   9: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   12: ldc_w 'Can not start crash report because bugly is disable.'
    //   15: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   18: pop
    //   19: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   21: monitorexit
    //   22: return
    //   23: invokestatic hasInitialized : ()Z
    //   26: ifne -> 47
    //   29: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   32: ldc 'CrashReport has not been initialed! pls to call method 'initCrashReport' first!'
    //   34: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   37: pop
    //   38: goto -> 19
    //   41: astore_0
    //   42: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   44: monitorexit
    //   45: aload_0
    //   46: athrow
    //   47: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/crash/c;
    //   50: invokevirtual c : ()V
    //   53: goto -> 19
    // Exception table:
    //   from	to	target	type
    //   3	19	41	finally
    //   23	38	41	finally
    //   47	53	41	finally
  }
  
  public static void testANRCrash() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.a : Z
    //   6: ifne -> 23
    //   9: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   12: ldc_w 'Can not test ANR crash because bugly is disable.'
    //   15: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   18: pop
    //   19: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   21: monitorexit
    //   22: return
    //   23: invokestatic hasInitialized : ()Z
    //   26: ifne -> 47
    //   29: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   32: ldc 'CrashReport has not been initialed! pls to call method 'initCrashReport' first!'
    //   34: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   37: pop
    //   38: goto -> 19
    //   41: astore_0
    //   42: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   44: monitorexit
    //   45: aload_0
    //   46: athrow
    //   47: ldc_w 'start to create a anr crash for test!'
    //   50: iconst_0
    //   51: anewarray java/lang/Object
    //   54: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   57: pop
    //   58: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/crash/c;
    //   61: invokevirtual k : ()V
    //   64: goto -> 19
    // Exception table:
    //   from	to	target	type
    //   3	19	41	finally
    //   23	38	41	finally
    //   47	64	41	finally
  }
  
  public static void testJavaCrash() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.a : Z
    //   6: ifne -> 23
    //   9: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   12: ldc_w 'Can not test Java crash because bugly is disable.'
    //   15: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   18: pop
    //   19: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   21: monitorexit
    //   22: return
    //   23: invokestatic hasInitialized : ()Z
    //   26: ifne -> 47
    //   29: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   32: ldc 'CrashReport has not been initialed! pls to call method 'initCrashReport' first!'
    //   34: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   37: pop
    //   38: goto -> 19
    //   41: astore_0
    //   42: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   44: monitorexit
    //   45: aload_0
    //   46: athrow
    //   47: new java/lang/RuntimeException
    //   50: astore_0
    //   51: aload_0
    //   52: ldc_w 'This Crash create for Test! You can go to Bugly see more detail!'
    //   55: invokespecial <init> : (Ljava/lang/String;)V
    //   58: aload_0
    //   59: athrow
    // Exception table:
    //   from	to	target	type
    //   3	19	41	finally
    //   23	38	41	finally
    //   47	60	41	finally
  }
  
  public static void testNativeCrash() {
    // Byte code:
    //   0: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   2: monitorenter
    //   3: getstatic com/tencent/bugly/legu/b.a : Z
    //   6: ifne -> 23
    //   9: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   12: ldc_w 'Can not test native crash because bugly is disable.'
    //   15: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   18: pop
    //   19: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   21: monitorexit
    //   22: return
    //   23: invokestatic hasInitialized : ()Z
    //   26: ifne -> 47
    //   29: getstatic com/tencent/bugly/legu/proguard/w.a : Ljava/lang/String;
    //   32: ldc 'CrashReport has not been initialed! pls to call method 'initCrashReport' first!'
    //   34: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   37: pop
    //   38: goto -> 19
    //   41: astore_0
    //   42: ldc com/tencent/bugly/legu/crashreport/CrashReport
    //   44: monitorexit
    //   45: aload_0
    //   46: athrow
    //   47: ldc_w 'start to create a native crash for test!'
    //   50: iconst_0
    //   51: anewarray java/lang/Object
    //   54: invokestatic a : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   57: pop
    //   58: invokestatic a : ()Lcom/tencent/bugly/legu/crashreport/crash/c;
    //   61: invokevirtual j : ()V
    //   64: goto -> 19
    // Exception table:
    //   from	to	target	type
    //   3	19	41	finally
    //   23	38	41	finally
    //   47	64	41	finally
  }
  
  public static class CrashHandleCallback extends BuglyStrategy.a {}
  
  public static class UserStrategy extends BuglyStrategy {
    private CrashReport.CrashHandleCallback a;
    
    public UserStrategy(Context param1Context) {}
    
    public CrashReport.CrashHandleCallback getCrashHandleCallback() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield a : Lcom/tencent/bugly/legu/crashreport/CrashReport$CrashHandleCallback;
      //   6: astore_1
      //   7: aload_0
      //   8: monitorexit
      //   9: aload_1
      //   10: areturn
      //   11: astore_1
      //   12: aload_0
      //   13: monitorexit
      //   14: aload_1
      //   15: athrow
      // Exception table:
      //   from	to	target	type
      //   2	7	11	finally
    }
    
    public void setCrashHandleCallback(CrashReport.CrashHandleCallback param1CrashHandleCallback) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: aload_1
      //   4: putfield a : Lcom/tencent/bugly/legu/crashreport/CrashReport$CrashHandleCallback;
      //   7: aload_0
      //   8: monitorexit
      //   9: return
      //   10: astore_1
      //   11: aload_0
      //   12: monitorexit
      //   13: aload_1
      //   14: athrow
      // Exception table:
      //   from	to	target	type
      //   2	7	10	finally
    }
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/CrashReport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */