package com.tencent.StubShell;

import android.annotation.TargetApi;
import android.app.Application;
import android.content.Context;
import android.os.Build;
import android.util.Log;
import dalvik.system.DexClassLoader;
import dalvik.system.PathClassLoader;
import java.io.File;
import java.lang.reflect.Array;
import java.lang.reflect.Field;

public final class SystemClassLoaderInjector {
  private static final String CLASS_LOADER_ALIYUN = "dalvik.system.LexClassLoader";
  
  private static final String CLASS_LOADER_BASE_DEX = "dalvik.system.BaseDexClassLoader";
  
  private static final String LOG_TAG = "SecShell";
  
  private static Object appendArray(Object paramObject1, Object paramObject2, boolean paramBoolean) {
    byte b = 0;
    Class<?> clazz = paramObject1.getClass().getComponentType();
    int i = Array.getLength(paramObject1);
    int j = i + 1;
    Object object = Array.newInstance(clazz, j);
    if (paramBoolean) {
      Array.set(object, 0, paramObject2);
      for (b = 1; b < j; b++)
        Array.set(object, b, Array.get(paramObject1, b - 1)); 
    } else {
      while (b < j) {
        if (b < i) {
          Array.set(object, b, Array.get(paramObject1, b));
        } else {
          Array.set(object, b, paramObject2);
        } 
        b++;
      } 
    } 
    return object;
  }
  
  private static Object combineArray(Object paramObject1, Object paramObject2, boolean paramBoolean) {
    if (!paramBoolean) {
      Object object1 = paramObject1;
      paramObject1 = paramObject2;
      paramObject2 = object1;
    } 
    Class<?> clazz = paramObject2.getClass().getComponentType();
    int i = Array.getLength(paramObject2);
    int j = Array.getLength(paramObject1) + i;
    Object object = Array.newInstance(clazz, j);
    for (byte b = 0; b < j; b++) {
      if (b < i) {
        Array.set(object, b, Array.get(paramObject2, b));
      } else {
        Array.set(object, b, Array.get(paramObject1, b - i));
      } 
    } 
    return object;
  }
  
  public static void fixAndroid(Context paramContext, Application paramApplication) {
    if (Build.VERSION.SDK_INT >= 28)
      try {
        Log.e("SecShell", "fixAndroid");
        ClassLoader classLoader = paramContext.getClassLoader();
        StringBuilder stringBuilder3 = new StringBuilder();
        this();
        Log.e("SecShell", stringBuilder3.append("fixAndroid mClassLoader:").append(classLoader).toString());
        Object object2 = getPathList(classLoader);
        StringBuilder stringBuilder4 = new StringBuilder();
        this();
        Log.e("SecShell", stringBuilder4.append("fixAndroid mpathList:").append(object2).toString());
        TxAppEntry.mPClassLoader = a.a(classLoader, paramApplication);
        StringBuilder stringBuilder1 = new StringBuilder();
        this();
        Log.e("SecShell", stringBuilder1.append("fixAndroid fClassLoader:").append(TxAppEntry.mPClassLoader).toString());
        Object object1 = getPathList(TxAppEntry.mPClassLoader);
        StringBuilder stringBuilder2 = new StringBuilder();
        this();
        Log.e("SecShell", stringBuilder2.append("fixAndroid fpathList:").append(object1).toString());
      } catch (Throwable throwable) {
        throwable.printStackTrace();
      }  
  }
  
  private static Object getDexElements(Object paramObject) {
    return getField(paramObject, paramObject.getClass(), "dexElements");
  }
  
  private static Object getField(Object paramObject, Class paramClass, String paramString) {
    Field field = paramClass.getDeclaredField(paramString);
    field.setAccessible(true);
    return field.get(paramObject);
  }
  
  private static Object getPathList(Object paramObject) {
    return getField(paramObject, Class.forName("dalvik.system.BaseDexClassLoader"), "pathList");
  }
  
  private static boolean hasBaseDexClassLoader() {
    boolean bool;
    try {
      Class.forName("dalvik.system.BaseDexClassLoader");
      bool = true;
    } catch (ClassNotFoundException classNotFoundException) {
      bool = false;
    } 
    return bool;
  }
  
  public static void inject(Context paramContext, String paramString1, String paramString2, boolean paramBoolean) {
    if (paramString1 != null && (new File(paramString1)).exists()) {
      if (isAliyunOs()) {
        injectInAliyunOs(paramContext, paramString1, paramString2, paramBoolean);
        return;
      } 
      if (!hasBaseDexClassLoader())
        try {
          injectBelowApiLevel14(paramContext, paramString1, paramString2, paramBoolean);
          return;
        } catch (Throwable throwable) {
          throw new Exception(throwable);
        }  
      injectAboveEqualApiLevel14((Context)throwable, paramString1, paramString2, paramBoolean);
    } 
  }
  
  private static void injectAboveEqualApiLevel14(Context paramContext, String paramString1, String paramString2, boolean paramBoolean) {
    PathClassLoader pathClassLoader = (PathClassLoader)paramContext.getClassLoader();
    DexClassLoader dexClassLoader = new DexClassLoader(paramString1, paramContext.getDir("dex", 0).getAbsolutePath(), paramString1, paramContext.getClassLoader());
    Object object1 = combineArray(getDexElements(getPathList(pathClassLoader)), getDexElements(getPathList(dexClassLoader)), paramBoolean);
    Object object2 = getPathList(pathClassLoader);
    setField(object2, object2.getClass(), "dexElements", object1);
    pathClassLoader.loadClass(paramString2);
  }
  
  @TargetApi(14)
  private static void injectBelowApiLevel14(Context paramContext, String paramString1, String paramString2, boolean paramBoolean) {
    PathClassLoader pathClassLoader = (PathClassLoader)paramContext.getClassLoader();
    DexClassLoader dexClassLoader = new DexClassLoader(paramString1, paramContext.getDir("dex", 0).getAbsolutePath(), paramString1, paramContext.getClassLoader());
    dexClassLoader.loadClass(paramString2);
    setField(pathClassLoader, PathClassLoader.class, "mPaths", appendArray(getField(pathClassLoader, PathClassLoader.class, "mPaths"), getField(dexClassLoader, DexClassLoader.class, "mRawDexPath"), paramBoolean));
    setField(pathClassLoader, PathClassLoader.class, "mFiles", combineArray(getField(pathClassLoader, PathClassLoader.class, "mFiles"), getField(dexClassLoader, DexClassLoader.class, "mFiles"), paramBoolean));
    setField(pathClassLoader, PathClassLoader.class, "mZips", combineArray(getField(pathClassLoader, PathClassLoader.class, "mZips"), getField(dexClassLoader, DexClassLoader.class, "mZips"), paramBoolean));
    setField(pathClassLoader, PathClassLoader.class, "mDexs", combineArray(getField(pathClassLoader, PathClassLoader.class, "mDexs"), getField(dexClassLoader, DexClassLoader.class, "mDexs"), paramBoolean));
    pathClassLoader.loadClass(paramString2);
  }
  
  private static void injectInAliyunOs(Context paramContext, String paramString1, String paramString2, boolean paramBoolean) {
    PathClassLoader pathClassLoader = (PathClassLoader)paramContext.getClassLoader();
    new DexClassLoader(paramString1, paramContext.getDir("dex", 0).getAbsolutePath(), paramString1, (ClassLoader)pathClassLoader);
    String str = (new File(paramString1)).getName().replaceAll("\\.[a-zA-Z0-9]+", ".lex");
    Class<?> clazz = Class.forName("dalvik.system.LexClassLoader");
    paramContext = clazz.getConstructor(new Class[] { String.class, String.class, String.class, ClassLoader.class }).newInstance(new Object[] { paramContext.getDir("dex", 0).getAbsolutePath() + File.separator + str, paramContext.getDir("dex", 0).getAbsolutePath(), paramString1, pathClassLoader });
    clazz.getMethod("loadClass", new Class[] { String.class }).invoke(paramContext, new Object[] { paramString2 });
    setField(pathClassLoader, PathClassLoader.class, "mPaths", appendArray(getField(pathClassLoader, PathClassLoader.class, "mPaths"), getField(paramContext, clazz, "mRawDexPath"), paramBoolean));
    setField(pathClassLoader, PathClassLoader.class, "mFiles", combineArray(getField(pathClassLoader, PathClassLoader.class, "mFiles"), getField(paramContext, clazz, "mFiles"), paramBoolean));
    setField(pathClassLoader, PathClassLoader.class, "mZips", combineArray(getField(pathClassLoader, PathClassLoader.class, "mZips"), getField(paramContext, clazz, "mZips"), paramBoolean));
    setField(pathClassLoader, PathClassLoader.class, "mLexs", combineArray(getField(pathClassLoader, PathClassLoader.class, "mLexs"), getField(paramContext, clazz, "mDexs"), paramBoolean));
  }
  
  private static boolean isAliyunOs() {
    boolean bool;
    try {
      Class.forName("dalvik.system.LexClassLoader");
      bool = true;
    } catch (ClassNotFoundException classNotFoundException) {
      bool = false;
    } 
    return bool;
  }
  
  private static void setField(Object paramObject1, Class paramClass, String paramString, Object paramObject2) {
    try {
      Field field = paramClass.getDeclaredField(paramString);
      field.setAccessible(true);
      field.set(paramObject1, paramObject2);
    } catch (NoSuchFieldException noSuchFieldException) {
      noSuchFieldException.printStackTrace();
    } catch (IllegalAccessException illegalAccessException) {
      illegalAccessException.printStackTrace();
    } catch (IllegalArgumentException illegalArgumentException) {
      illegalArgumentException.printStackTrace();
    } 
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/StubShell/SystemClassLoaderInjector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */