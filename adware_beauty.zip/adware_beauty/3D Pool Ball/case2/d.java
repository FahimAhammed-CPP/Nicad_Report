package com.tencent.bugly.legu.crashreport.crash;

import android.content.Context;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.common.strategy.StrategyBean;
import com.tencent.bugly.legu.crashreport.common.strategy.a;
import com.tencent.bugly.legu.crashreport.crash.h5.b;
import com.tencent.bugly.legu.proguard.v;
import com.tencent.bugly.legu.proguard.w;
import com.tencent.bugly.legu.proguard.y;
import com.tencent.bugly.legu.proguard.z;
import java.lang.reflect.Field;
import java.util.Map;

public final class d {
  private static z a;
  
  private static y b;
  
  private static b c;
  
  public static void a(Context paramContext) {
    c c = c.a();
    if (c != null) {
      a = new z(paramContext, c.k, a.a(), a.a(), c.l);
      b = new y(paramContext, c.k, a.a(), a.a(), c.l);
      c = new b(paramContext, c.k, a.a(), a.a(), c.l);
      v.a().b(new Runnable() {
            public final void run() {
              d.a();
            }
          });
    } 
  }
  
  public static void a(StrategyBean paramStrategyBean) {
    if (b != null) {
      y y1 = b;
      boolean bool = paramStrategyBean.h;
    } 
  }
  
  public static void a(Thread paramThread, int paramInt, String paramString1, String paramString2, String paramString3) {
    if (b != null)
      v.a().b(new Runnable(paramThread, paramInt, paramString1, paramString2, paramString3) {
            public final void run() {
              try {
                d.c().a(this.a, this.b, this.c, this.d, this.e);
              } catch (Throwable throwable) {}
            }
          }); 
  }
  
  public static void a(Thread paramThread, String paramString1, String paramString2, String paramString3) {
    if (a != null)
      v.a().b(new Runnable(paramThread, paramString1, paramString2, paramString3) {
            public final void run() {
              try {
                d.b().a(this.a, this.b, this.c, this.d);
              } catch (Throwable throwable) {}
            }
          }); 
  }
  
  public static void a(Thread paramThread, String paramString1, String paramString2, String paramString3, Map<String, String> paramMap) {
    if (c != null)
      v.a().b(new Runnable(paramThread, paramString1, paramString2, paramString3, paramMap) {
            public final void run() {
              try {
                d.d().a(this.a, this.b, this.c, this.d, this.e);
              } catch (Throwable throwable) {}
            }
          }); 
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */