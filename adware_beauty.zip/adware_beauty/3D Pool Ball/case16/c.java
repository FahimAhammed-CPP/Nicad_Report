package com.tencent.StubShell;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.Arrays;

public class c {
  public static Constructor a(Object paramObject, Class... paramVarArgs) {
    Class<?> clazz = paramObject.getClass();
    while (clazz != null) {
      try {
        Constructor<?> constructor = clazz.getDeclaredConstructor(paramVarArgs);
        if (!constructor.isAccessible())
          constructor.setAccessible(true); 
        return constructor;
      } catch (NoSuchMethodException noSuchMethodException) {
        clazz = clazz.getSuperclass();
      } 
    } 
    throw new NoSuchMethodException("Constructor with parameters " + Arrays.asList(paramVarArgs) + " not found in " + paramObject.getClass());
  }
  
  public static Field a(Class paramClass, String paramString) {
    Class clazz = paramClass;
    while (clazz != null) {
      try {
        Field field = clazz.getDeclaredField(paramString);
        if (!field.isAccessible())
          field.setAccessible(true); 
        return field;
      } catch (NoSuchFieldException noSuchFieldException) {
        clazz = clazz.getSuperclass();
      } 
    } 
    throw new NoSuchFieldException("Field " + paramString + " not found in " + paramClass);
  }
  
  public static Field a(Object paramObject, String paramString) {
    Class<?> clazz = paramObject.getClass();
    while (clazz != null) {
      try {
        Field field = clazz.getDeclaredField(paramString);
        if (!field.isAccessible())
          field.setAccessible(true); 
        return field;
      } catch (NoSuchFieldException noSuchFieldException) {
        clazz = clazz.getSuperclass();
      } 
    } 
    throw new NoSuchFieldException("Field " + paramString + " not found in " + paramObject.getClass());
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/StubShell/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */