package com.tencent.bugly.legu.proguard;

import com.tencent.bugly.legu.crashreport.crash.jni.b;
import java.util.HashMap;
import java.util.Map;

public final class ap extends j implements Cloneable {
  private static ao m;
  
  private static Map<String, String> n;
  
  public boolean a = true;
  
  public boolean b = true;
  
  public boolean c = true;
  
  public String d = "";
  
  public String e = "";
  
  public ao f = null;
  
  public Map<String, String> g = null;
  
  public long h = 0L;
  
  public int i = 0;
  
  private String j = "";
  
  private String k = "";
  
  private int l = 0;
  
  static {
    boolean bool;
    if (!ap.class.desiredAssertionStatus()) {
      bool = true;
    } else {
      bool = false;
    } 
    o = bool;
    m = new ao();
    n = new HashMap<String, String>();
    n.put("", "");
  }
  
  public final void a(h paramh) {
    boolean bool = this.a;
    this.a = paramh.a(0, true);
    bool = this.b;
    this.b = paramh.a(1, true);
    bool = this.c;
    this.c = paramh.a(2, true);
    this.d = paramh.b(3, false);
    this.e = paramh.b(4, false);
    this.f = (ao)paramh.a(m, 5, false);
    this.g = (Map<String, String>)paramh.<Map<String, String>>a(n, 6, false);
    this.h = paramh.a(this.h, 7, false);
    this.j = paramh.b(8, false);
    this.k = paramh.b(9, false);
    this.l = paramh.a(this.l, 10, false);
    this.i = paramh.a(this.i, 11, false);
  }
  
  public final void a(i parami) {
    parami.a(this.a, 0);
    parami.a(this.b, 1);
    parami.a(this.c, 2);
    if (this.d != null)
      parami.a(this.d, 3); 
    if (this.e != null)
      parami.a(this.e, 4); 
    if (this.f != null)
      parami.a(this.f, 5); 
    if (this.g != null)
      parami.a(this.g, 6); 
    parami.a(this.h, 7);
    if (this.j != null)
      parami.a(this.j, 8); 
    if (this.k != null)
      parami.a(this.k, 9); 
    parami.a(this.l, 10);
    parami.a(this.i, 11);
  }
  
  public final void a(StringBuilder paramStringBuilder, int paramInt) {
    b b = new b(paramStringBuilder, paramInt);
    b.a(this.a, "enable");
    b.a(this.b, "enableUserInfo");
    b.a(this.c, "enableQuery");
    b.a(this.d, "url");
    b.a(this.e, "expUrl");
    b.a(this.f, "security");
    b.a(this.g, "valueMap");
    b.a(this.h, "strategylastUpdateTime");
    b.a(this.j, "httpsUrl");
    b.a(this.k, "httpsExpUrl");
    b.a(this.l, "eventRecordCount");
    b.a(this.i, "eventTimeInterval");
  }
  
  public final Object clone() {
    Object object = null;
    try {
      Object object1 = super.clone();
      object = object1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {}
    return object;
  }
  
  public final boolean equals(Object paramObject) {
    boolean bool1 = false;
    if (paramObject == null)
      return bool1; 
    paramObject = paramObject;
    boolean bool2 = bool1;
    if (k.a(this.a, ((ap)paramObject).a)) {
      bool2 = bool1;
      if (k.a(this.b, ((ap)paramObject).b)) {
        bool2 = bool1;
        if (k.a(this.c, ((ap)paramObject).c)) {
          bool2 = bool1;
          if (k.a(this.d, ((ap)paramObject).d)) {
            bool2 = bool1;
            if (k.a(this.e, ((ap)paramObject).e)) {
              bool2 = bool1;
              if (k.a(this.f, ((ap)paramObject).f)) {
                bool2 = bool1;
                if (k.a(this.g, ((ap)paramObject).g)) {
                  bool2 = bool1;
                  if (k.a(this.h, ((ap)paramObject).h)) {
                    bool2 = bool1;
                    if (k.a(this.j, ((ap)paramObject).j)) {
                      bool2 = bool1;
                      if (k.a(this.k, ((ap)paramObject).k)) {
                        bool2 = bool1;
                        if (k.a(this.l, ((ap)paramObject).l)) {
                          bool2 = bool1;
                          if (k.a(this.i, ((ap)paramObject).i))
                            bool2 = true; 
                        } 
                      } 
                    } 
                  } 
                } 
              } 
            } 
          } 
        } 
      } 
    } 
    return bool2;
  }
  
  public final int hashCode() {
    try {
      Exception exception = new Exception();
      this("Need define key first!");
      throw exception;
    } catch (Exception exception) {
      exception.printStackTrace();
      return 0;
    } 
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/ap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */