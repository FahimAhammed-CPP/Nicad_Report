package com.tencent.bugly.legu.proguard;

import com.tencent.bugly.legu.crashreport.crash.jni.b;
import java.util.HashMap;
import java.util.Map;

public final class f extends j {
  private static byte[] k;
  
  private static Map<String, String> l;
  
  public short a = (short)0;
  
  public int b = 0;
  
  public String c = null;
  
  public String d = null;
  
  public byte[] e;
  
  private byte f = (byte)0;
  
  private int g = 0;
  
  private int h = 0;
  
  private Map<String, String> i;
  
  private Map<String, String> j;
  
  static {
    boolean bool;
    if (!f.class.desiredAssertionStatus()) {
      bool = true;
    } else {
      bool = false;
    } 
    m = bool;
    k = null;
    l = null;
  }
  
  public final void a(h paramh) {
    try {
      this.a = paramh.a(this.a, 1, true);
      this.f = paramh.a(this.f, 2, true);
      this.g = paramh.a(this.g, 3, true);
      this.b = paramh.a(this.b, 4, true);
      this.c = paramh.b(5, true);
      this.d = paramh.b(6, true);
      if (k == null)
        k = new byte[] { 0 }; 
      byte[] arrayOfByte = k;
      this.e = paramh.c(7, true);
      this.h = paramh.a(this.h, 8, true);
      if (l == null) {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        this();
        l = (Map)hashMap;
        hashMap.put("", "");
      } 
      this.i = (Map<String, String>)paramh.<Map<String, String>>a(l, 9, true);
      if (l == null) {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        this();
        l = (Map)hashMap;
        hashMap.put("", "");
      } 
      this.j = (Map<String, String>)paramh.<Map<String, String>>a(l, 10, true);
      return;
    } catch (Exception exception) {
      exception.printStackTrace();
      System.out.println("RequestPacket decode error " + e.a(this.e));
      throw new RuntimeException(exception);
    } 
  }
  
  public final void a(i parami) {
    parami.a(this.a, 1);
    parami.a(this.f, 2);
    parami.a(this.g, 3);
    parami.a(this.b, 4);
    parami.a(this.c, 5);
    parami.a(this.d, 6);
    parami.a(this.e, 7);
    parami.a(this.h, 8);
    parami.a(this.i, 9);
    parami.a(this.j, 10);
  }
  
  public final void a(StringBuilder paramStringBuilder, int paramInt) {
    b b = new b(paramStringBuilder, paramInt);
    b.a(this.a, "iVersion");
    b.a(this.f, "cPacketType");
    b.a(this.g, "iMessageType");
    b.a(this.b, "iRequestId");
    b.a(this.c, "sServantName");
    b.a(this.d, "sFuncName");
    b.a(this.e, "sBuffer");
    b.a(this.h, "iTimeout");
    b.a(this.i, "context");
    b.a(this.j, "status");
  }
  
  public final Object clone() {
    Object object = null;
    try {
      Object object1 = super.clone();
      object = object1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {}
    return object;
  }
  
  public final boolean equals(Object paramObject) {
    boolean bool = true;
    paramObject = paramObject;
    if (!k.a(1, ((f)paramObject).a) || !k.a(1, ((f)paramObject).f) || !k.a(1, ((f)paramObject).g) || !k.a(1, ((f)paramObject).b) || !k.a(Integer.valueOf(1), ((f)paramObject).c) || !k.a(Integer.valueOf(1), ((f)paramObject).d) || !k.a(Integer.valueOf(1), ((f)paramObject).e) || !k.a(1, ((f)paramObject).h) || !k.a(Integer.valueOf(1), ((f)paramObject).i) || !k.a(Integer.valueOf(1), ((f)paramObject).j))
      bool = false; 
    return bool;
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/proguard/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */