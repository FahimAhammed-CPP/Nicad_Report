package com.tencent.bugly.legu.crashreport.crash.jni;

import android.content.Context;
import com.tencent.bugly.legu.crashreport.common.info.a;
import com.tencent.bugly.legu.crashreport.crash.CrashDetailBean;
import com.tencent.bugly.legu.proguard.a;
import com.tencent.bugly.legu.proguard.j;
import com.tencent.bugly.legu.proguard.w;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class b {
  private StringBuilder a;
  
  private int b = 0;
  
  public b(StringBuilder paramStringBuilder, int paramInt) {
    this.a = paramStringBuilder;
    this.b = paramInt;
  }
  
  public static CrashDetailBean a(Context paramContext, String paramString, NativeExceptionHandler paramNativeExceptionHandler) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_0
    //   3: ifnull -> 14
    //   6: aload_1
    //   7: ifnull -> 14
    //   10: aload_2
    //   11: ifnonnull -> 28
    //   14: ldc 'get eup record file args error'
    //   16: iconst_0
    //   17: anewarray java/lang/Object
    //   20: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   23: pop
    //   24: aload_3
    //   25: astore_1
    //   26: aload_1
    //   27: areturn
    //   28: new java/io/File
    //   31: dup
    //   32: aload_1
    //   33: ldc 'rqd_record.eup'
    //   35: invokespecial <init> : (Ljava/lang/String;Ljava/lang/String;)V
    //   38: astore #4
    //   40: aload_3
    //   41: astore_1
    //   42: aload #4
    //   44: invokevirtual exists : ()Z
    //   47: ifeq -> 26
    //   50: aload_3
    //   51: astore_1
    //   52: aload #4
    //   54: invokevirtual canRead : ()Z
    //   57: ifeq -> 26
    //   60: new java/io/FileInputStream
    //   63: astore #5
    //   65: aload #5
    //   67: aload #4
    //   69: invokespecial <init> : (Ljava/io/File;)V
    //   72: aload #5
    //   74: astore_1
    //   75: aload #5
    //   77: invokestatic a : (Ljava/io/InputStream;)Ljava/lang/String;
    //   80: astore #4
    //   82: aload #4
    //   84: ifnull -> 100
    //   87: aload #5
    //   89: astore_1
    //   90: aload #4
    //   92: ldc 'NATIVE_RQD_REPORT'
    //   94: invokevirtual equals : (Ljava/lang/Object;)Z
    //   97: ifne -> 138
    //   100: aload #5
    //   102: astore_1
    //   103: ldc 'record read fail! %s'
    //   105: iconst_1
    //   106: anewarray java/lang/Object
    //   109: dup
    //   110: iconst_0
    //   111: aload #4
    //   113: aastore
    //   114: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   117: pop
    //   118: aload #5
    //   120: invokevirtual close : ()V
    //   123: aload_3
    //   124: astore_1
    //   125: goto -> 26
    //   128: astore_0
    //   129: aload_0
    //   130: invokevirtual printStackTrace : ()V
    //   133: aload_3
    //   134: astore_1
    //   135: goto -> 26
    //   138: aload #5
    //   140: astore_1
    //   141: new java/util/HashMap
    //   144: astore #6
    //   146: aload #5
    //   148: astore_1
    //   149: aload #6
    //   151: invokespecial <init> : ()V
    //   154: aconst_null
    //   155: astore #4
    //   157: aload #5
    //   159: astore_1
    //   160: aload #5
    //   162: invokestatic a : (Ljava/io/InputStream;)Ljava/lang/String;
    //   165: astore #7
    //   167: aload #7
    //   169: ifnull -> 205
    //   172: aload #4
    //   174: ifnonnull -> 184
    //   177: aload #7
    //   179: astore #4
    //   181: goto -> 157
    //   184: aload #5
    //   186: astore_1
    //   187: aload #6
    //   189: aload #4
    //   191: aload #7
    //   193: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   198: pop
    //   199: aconst_null
    //   200: astore #4
    //   202: goto -> 157
    //   205: aload #4
    //   207: ifnull -> 248
    //   210: aload #5
    //   212: astore_1
    //   213: ldc 'record not pair! drop! %s'
    //   215: iconst_1
    //   216: anewarray java/lang/Object
    //   219: dup
    //   220: iconst_0
    //   221: aload #4
    //   223: aastore
    //   224: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   227: pop
    //   228: aload #5
    //   230: invokevirtual close : ()V
    //   233: aload_3
    //   234: astore_1
    //   235: goto -> 26
    //   238: astore_0
    //   239: aload_0
    //   240: invokevirtual printStackTrace : ()V
    //   243: aload_3
    //   244: astore_1
    //   245: goto -> 26
    //   248: aload #5
    //   250: astore_1
    //   251: aload_0
    //   252: aload #6
    //   254: aload_2
    //   255: invokestatic a : (Landroid/content/Context;Ljava/util/Map;Lcom/tencent/bugly/legu/crashreport/crash/jni/NativeExceptionHandler;)Lcom/tencent/bugly/legu/crashreport/crash/CrashDetailBean;
    //   258: astore_0
    //   259: aload_0
    //   260: astore_1
    //   261: aload #5
    //   263: invokevirtual close : ()V
    //   266: goto -> 26
    //   269: astore_0
    //   270: aload_0
    //   271: invokevirtual printStackTrace : ()V
    //   274: goto -> 26
    //   277: astore_2
    //   278: aconst_null
    //   279: astore_0
    //   280: aload_0
    //   281: astore_1
    //   282: aload_2
    //   283: invokevirtual printStackTrace : ()V
    //   286: aload_3
    //   287: astore_1
    //   288: aload_0
    //   289: ifnull -> 26
    //   292: aload_0
    //   293: invokevirtual close : ()V
    //   296: aload_3
    //   297: astore_1
    //   298: goto -> 26
    //   301: astore_0
    //   302: aload_0
    //   303: invokevirtual printStackTrace : ()V
    //   306: aload_3
    //   307: astore_1
    //   308: goto -> 26
    //   311: astore_0
    //   312: aconst_null
    //   313: astore_1
    //   314: aload_1
    //   315: ifnull -> 322
    //   318: aload_1
    //   319: invokevirtual close : ()V
    //   322: aload_0
    //   323: athrow
    //   324: astore_1
    //   325: aload_1
    //   326: invokevirtual printStackTrace : ()V
    //   329: goto -> 322
    //   332: astore_0
    //   333: goto -> 314
    //   336: astore_2
    //   337: aload #5
    //   339: astore_0
    //   340: goto -> 280
    // Exception table:
    //   from	to	target	type
    //   60	72	277	java/io/IOException
    //   60	72	311	finally
    //   75	82	336	java/io/IOException
    //   75	82	332	finally
    //   90	100	336	java/io/IOException
    //   90	100	332	finally
    //   103	118	336	java/io/IOException
    //   103	118	332	finally
    //   118	123	128	java/io/IOException
    //   141	146	336	java/io/IOException
    //   141	146	332	finally
    //   149	154	336	java/io/IOException
    //   149	154	332	finally
    //   160	167	336	java/io/IOException
    //   160	167	332	finally
    //   187	199	336	java/io/IOException
    //   187	199	332	finally
    //   213	228	336	java/io/IOException
    //   213	228	332	finally
    //   228	233	238	java/io/IOException
    //   251	259	336	java/io/IOException
    //   251	259	332	finally
    //   261	266	269	java/io/IOException
    //   282	286	332	finally
    //   292	296	301	java/io/IOException
    //   318	322	324	java/io/IOException
  }
  
  private static CrashDetailBean a(Context paramContext, Map<String, String> paramMap, NativeExceptionHandler paramNativeExceptionHandler) {
    if (paramMap == null)
      return null; 
    if (a.a(paramContext) == null) {
      w.e("abnormal com info not created", new Object[0]);
      return null;
    } 
    String str = paramMap.get("intStateStr");
    if (str == null || str.trim().length() <= 0) {
      w.e("no intStateStr", new Object[0]);
      return null;
    } 
    Map<String, Integer> map = c(str);
    if (map == null) {
      w.e("parse intSateMap fail", new Object[] { Integer.valueOf(paramMap.size()) });
      return null;
    } 
    try {
      byte[] arrayOfByte;
      String[] arrayOfString;
      int i = ((Integer)map.get("ep")).intValue();
      int j = ((Integer)map.get("et")).intValue();
      ((Integer)map.get("sino")).intValue();
      int k = ((Integer)map.get("sico")).intValue();
      int m = ((Integer)map.get("spd")).intValue();
      ((Integer)map.get("sud")).intValue();
      long l1 = ((Integer)map.get("ets")).intValue();
      long l2 = ((Integer)map.get("etms")).intValue();
      String str2 = paramMap.get("soVersion");
      if (str2 == null) {
        w.e("error format at version", new Object[0]);
        return null;
      } 
      String str3 = paramMap.get("errorAddr");
      if (str3 == null)
        str3 = "unknown2"; 
      String str1 = paramMap.get("codeMsg");
      if (str1 == null)
        str1 = "unknown2"; 
      String str4 = paramMap.get("tombPath");
      if (str4 == null)
        str4 = "unknown2"; 
      String str5 = paramMap.get("signalName");
      if (str5 == null)
        str5 = "unknown2"; 
      paramMap.get("errnoMsg");
      String str6 = paramMap.get("stack");
      if (str6 == null)
        str6 = "unknown2"; 
      String str7 = paramMap.get("jstack");
      if (str7 != null) {
        StringBuilder stringBuilder = new StringBuilder();
        this();
        str6 = stringBuilder.append(str6).append("java:\n").append(str7).toString();
      } 
      l2 /= 1000L;
      String str10 = a(str6);
      String str9 = paramMap.get("sendingProcess");
      str6 = str9;
      if (str9 == null)
        str6 = "UNKNOWN"; 
      StringBuilder stringBuilder1 = new StringBuilder();
      this();
      String str11 = stringBuilder1.append(str6).append("(").append(m).append(")").toString();
      String str8 = str5;
      str6 = str1;
      if (k > 0) {
        StringBuilder stringBuilder = new StringBuilder();
        this();
        str8 = stringBuilder.append(str5).append("(").append(str1).append(")").toString();
        str6 = "KERNEL";
      } 
      str7 = paramMap.get("nativeLog");
      str5 = null;
      str1 = str5;
      if (str7 != null) {
        str1 = str5;
        if (!str7.isEmpty())
          arrayOfByte = a.a(null, str7); 
      } 
      str5 = paramMap.get("processName");
      if (str5 == null) {
        StringBuilder stringBuilder = new StringBuilder();
        this("unknown(");
        str5 = stringBuilder.append(i).append(")").toString();
      } 
      String str12 = paramMap.get("threadName");
      str7 = str12;
      if (str12 == null)
        str7 = "unknown"; 
      StringBuilder stringBuilder2 = new StringBuilder();
      this();
      String str13 = stringBuilder2.append(str7).append("(").append(j).append(")").toString();
      str7 = null;
      String str14 = paramMap.get("key-value");
      if (str14 != null) {
        HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        this();
        String[] arrayOfString1 = str14.split("\n");
        k = arrayOfString1.length;
        i = 0;
        while (true) {
          HashMap<Object, Object> hashMap1 = hashMap;
          if (i < k) {
            arrayOfString = arrayOfString1[i].split("=");
            if (arrayOfString.length == 2)
              hashMap.put(arrayOfString[0], arrayOfString[1]); 
            i++;
            continue;
          } 
          break;
        } 
      } 
      CrashDetailBean crashDetailBean = paramNativeExceptionHandler.packageCrashDatas(str5, str13, l1 * 1000L + l2, str8, str3, str10, str6, str11, str4, str2, arrayOfByte, (Map<String, String>)arrayOfString, false);
      if (crashDetailBean != null) {
        String str16 = paramMap.get("userId");
        if (str16 != null)
          crashDetailBean.m = str16; 
        str16 = paramMap.get("sysLog");
        if (str16 != null)
          crashDetailBean.w = str16; 
        String str15 = paramMap.get("appVersion");
        if (str16 != null)
          crashDetailBean.f = str15; 
        crashDetailBean.y = null;
        crashDetailBean.k = true;
      } 
    } catch (Throwable throwable) {
      w.e("error format", new Object[0]);
      throwable.printStackTrace();
      throwable = null;
    } 
    return (CrashDetailBean)throwable;
  }
  
  private static String a(InputStream paramInputStream) throws IOException {
    String str = null;
    if (paramInputStream == null)
      return str; 
    StringBuilder stringBuilder = new StringBuilder();
    while (true) {
      int i = paramInputStream.read();
      String str1 = str;
      if (i != -1) {
        if (i == 0)
          return stringBuilder.toString(); 
        stringBuilder.append((char)i);
        continue;
      } 
      return str1;
    } 
  }
  
  protected static String a(String paramString) {
    if (paramString == null)
      return ""; 
    String[] arrayOfString = paramString.split("\n");
    String str = paramString;
    if (arrayOfString != null) {
      str = paramString;
      if (arrayOfString.length != 0) {
        StringBuilder stringBuilder = new StringBuilder();
        int i = arrayOfString.length;
        for (byte b1 = 0; b1 < i; b1++) {
          str = arrayOfString[b1];
          if (!str.contains("java.lang.Thread.getStackTrace("))
            stringBuilder.append(str).append("\n"); 
        } 
        str = stringBuilder.toString();
      } 
    } 
    return str;
  }
  
  public static void b(String paramString) {
    File file = new File(paramString, "rqd_record.eup");
    if (file.exists() && file.canWrite()) {
      file.delete();
      w.c("delete record file %s", new Object[] { file.getAbsoluteFile() });
    } 
  }
  
  private static Map<String, Integer> c(String paramString) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aload_0
    //   3: ifnonnull -> 10
    //   6: aload_1
    //   7: astore_0
    //   8: aload_0
    //   9: areturn
    //   10: new java/util/HashMap
    //   13: astore_2
    //   14: aload_2
    //   15: invokespecial <init> : ()V
    //   18: aload_0
    //   19: ldc_w ','
    //   22: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   25: astore_3
    //   26: aload_3
    //   27: arraylength
    //   28: istore #4
    //   30: iconst_0
    //   31: istore #5
    //   33: iload #5
    //   35: iload #4
    //   37: if_icmpge -> 140
    //   40: aload_3
    //   41: iload #5
    //   43: aaload
    //   44: astore #6
    //   46: aload #6
    //   48: ldc_w ':'
    //   51: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   54: astore #7
    //   56: aload #7
    //   58: arraylength
    //   59: iconst_2
    //   60: if_icmpeq -> 109
    //   63: ldc_w 'error format at %s'
    //   66: iconst_1
    //   67: anewarray java/lang/Object
    //   70: dup
    //   71: iconst_0
    //   72: aload #6
    //   74: aastore
    //   75: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   78: pop
    //   79: aload_1
    //   80: astore_0
    //   81: goto -> 8
    //   84: astore_2
    //   85: ldc_w 'error format intStateStr %s'
    //   88: iconst_1
    //   89: anewarray java/lang/Object
    //   92: dup
    //   93: iconst_0
    //   94: aload_0
    //   95: aastore
    //   96: invokestatic e : (Ljava/lang/String;[Ljava/lang/Object;)Z
    //   99: pop
    //   100: aload_2
    //   101: invokevirtual printStackTrace : ()V
    //   104: aload_1
    //   105: astore_0
    //   106: goto -> 8
    //   109: aload #7
    //   111: iconst_1
    //   112: aaload
    //   113: invokestatic parseInt : (Ljava/lang/String;)I
    //   116: istore #8
    //   118: aload_2
    //   119: aload #7
    //   121: iconst_0
    //   122: aaload
    //   123: iload #8
    //   125: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   128: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   133: pop
    //   134: iinc #5, 1
    //   137: goto -> 33
    //   140: aload_2
    //   141: astore_0
    //   142: goto -> 8
    // Exception table:
    //   from	to	target	type
    //   10	30	84	java/lang/Exception
    //   46	79	84	java/lang/Exception
    //   109	134	84	java/lang/Exception
  }
  
  private void d(String paramString) {
    for (byte b1 = 0; b1 < this.b; b1++)
      this.a.append('\t'); 
    if (paramString != null)
      this.a.append(paramString).append(": "); 
  }
  
  public b a(byte paramByte, String paramString) {
    d(paramString);
    this.a.append(paramByte).append('\n');
    return this;
  }
  
  public b a(char paramChar, String paramString) {
    d(paramString);
    this.a.append(paramChar).append('\n');
    return this;
  }
  
  public b a(double paramDouble, String paramString) {
    d(paramString);
    this.a.append(paramDouble).append('\n');
    return this;
  }
  
  public b a(float paramFloat, String paramString) {
    d(paramString);
    this.a.append(paramFloat).append('\n');
    return this;
  }
  
  public b a(int paramInt, String paramString) {
    d(paramString);
    this.a.append(paramInt).append('\n');
    return this;
  }
  
  public b a(long paramLong, String paramString) {
    d(paramString);
    this.a.append(paramLong).append('\n');
    return this;
  }
  
  public b a(j paramj, String paramString) {
    a('{', paramString);
    if (paramj == null) {
      this.a.append('\t').append("null");
      a('}', (String)null);
      return this;
    } 
    paramj.a(this.a, this.b + 1);
    a('}', (String)null);
    return this;
  }
  
  public <T> b a(T paramT, String paramString) {
    if (paramT == null) {
      this.a.append("null\n");
      return this;
    } 
    if (paramT instanceof Byte) {
      a(((Byte)paramT).byteValue(), paramString);
      return this;
    } 
    if (paramT instanceof Boolean) {
      a(((Boolean)paramT).booleanValue(), paramString);
      return this;
    } 
    if (paramT instanceof Short) {
      a(((Short)paramT).shortValue(), paramString);
      return this;
    } 
    if (paramT instanceof Integer) {
      a(((Integer)paramT).intValue(), paramString);
      return this;
    } 
    if (paramT instanceof Long) {
      a(((Long)paramT).longValue(), paramString);
      return this;
    } 
    if (paramT instanceof Float) {
      a(((Float)paramT).floatValue(), paramString);
      return this;
    } 
    if (paramT instanceof Double) {
      a(((Double)paramT).doubleValue(), paramString);
      return this;
    } 
    if (paramT instanceof String) {
      a((String)paramT, paramString);
      return this;
    } 
    if (paramT instanceof Map) {
      a((Map<?, ?>)paramT, paramString);
      return this;
    } 
    if (paramT instanceof List) {
      a((List)paramT, paramString);
      return this;
    } 
    if (paramT instanceof j) {
      a((j)paramT, paramString);
      return this;
    } 
    if (paramT instanceof byte[]) {
      a((byte[])paramT, paramString);
      return this;
    } 
    if (paramT instanceof boolean[]) {
      a((boolean[])paramT, paramString);
      return this;
    } 
    if (paramT instanceof short[]) {
      a((short[])paramT, paramString);
      return this;
    } 
    if (paramT instanceof int[]) {
      a((int[])paramT, paramString);
      return this;
    } 
    if (paramT instanceof long[]) {
      a((long[])paramT, paramString);
      return this;
    } 
    if (paramT instanceof float[]) {
      a((float[])paramT, paramString);
      return this;
    } 
    if (paramT instanceof double[]) {
      a((double[])paramT, paramString);
      return this;
    } 
    if (paramT.getClass().isArray()) {
      a((Object[])paramT, paramString);
      return this;
    } 
    throw new com.tencent.bugly.legu.proguard.b("write object error: unsupport type.");
  }
  
  public b a(String paramString1, String paramString2) {
    d(paramString2);
    if (paramString1 == null) {
      this.a.append("null\n");
      return this;
    } 
    this.a.append(paramString1).append('\n');
    return this;
  }
  
  public <T> b a(Collection<T> paramCollection, String paramString) {
    if (paramCollection == null) {
      d(paramString);
      this.a.append("null\t");
      return this;
    } 
    return a(paramCollection.toArray(), paramString);
  }
  
  public <K, V> b a(Map<K, V> paramMap, String paramString) {
    d(paramString);
    if (paramMap == null) {
      this.a.append("null\n");
      return this;
    } 
    if (paramMap.isEmpty()) {
      this.a.append(paramMap.size()).append(", {}\n");
      return this;
    } 
    this.a.append(paramMap.size()).append(", {\n");
    b b2 = new b(this.a, this.b + 1);
    b b1 = new b(this.a, this.b + 2);
    for (Map.Entry<K, V> entry : paramMap.entrySet()) {
      b2.a('(', (String)null);
      b1.a(entry.getKey(), (String)null);
      b1.a(entry.getValue(), (String)null);
      b2.a(')', (String)null);
    } 
    a('}', (String)null);
    return this;
  }
  
  public b a(short paramShort, String paramString) {
    d(paramString);
    this.a.append(paramShort).append('\n');
    return this;
  }
  
  public b a(boolean paramBoolean, String paramString) {
    d(paramString);
    StringBuilder stringBuilder = this.a;
    if (paramBoolean) {
      byte b3 = 84;
      byte b4 = b3;
      stringBuilder.append(b4).append('\n');
      return this;
    } 
    byte b1 = 70;
    byte b2 = b1;
    stringBuilder.append(b2).append('\n');
    return this;
  }
  
  public b a(byte[] paramArrayOfbyte, String paramString) {
    d(paramString);
    if (paramArrayOfbyte == null) {
      this.a.append("null\n");
      return this;
    } 
    if (paramArrayOfbyte.length == 0) {
      this.a.append(paramArrayOfbyte.length).append(", []\n");
      return this;
    } 
    this.a.append(paramArrayOfbyte.length).append(", [\n");
    b b1 = new b(this.a, this.b + 1);
    int i = paramArrayOfbyte.length;
    for (byte b2 = 0; b2 < i; b2++)
      b1.a(paramArrayOfbyte[b2], (String)null); 
    a(']', (String)null);
    return this;
  }
  
  public b a(double[] paramArrayOfdouble, String paramString) {
    d(paramString);
    if (paramArrayOfdouble == null) {
      this.a.append("null\n");
      return this;
    } 
    if (paramArrayOfdouble.length == 0) {
      this.a.append(paramArrayOfdouble.length).append(", []\n");
      return this;
    } 
    this.a.append(paramArrayOfdouble.length).append(", [\n");
    b b1 = new b(this.a, this.b + 1);
    int i = paramArrayOfdouble.length;
    for (byte b2 = 0; b2 < i; b2++)
      b1.a(paramArrayOfdouble[b2], (String)null); 
    a(']', (String)null);
    return this;
  }
  
  public b a(float[] paramArrayOffloat, String paramString) {
    d(paramString);
    if (paramArrayOffloat == null) {
      this.a.append("null\n");
      return this;
    } 
    if (paramArrayOffloat.length == 0) {
      this.a.append(paramArrayOffloat.length).append(", []\n");
      return this;
    } 
    this.a.append(paramArrayOffloat.length).append(", [\n");
    b b1 = new b(this.a, this.b + 1);
    int i = paramArrayOffloat.length;
    for (byte b2 = 0; b2 < i; b2++)
      b1.a(paramArrayOffloat[b2], (String)null); 
    a(']', (String)null);
    return this;
  }
  
  public b a(int[] paramArrayOfint, String paramString) {
    d(paramString);
    if (paramArrayOfint == null) {
      this.a.append("null\n");
      return this;
    } 
    if (paramArrayOfint.length == 0) {
      this.a.append(paramArrayOfint.length).append(", []\n");
      return this;
    } 
    this.a.append(paramArrayOfint.length).append(", [\n");
    b b1 = new b(this.a, this.b + 1);
    int i = paramArrayOfint.length;
    for (byte b2 = 0; b2 < i; b2++)
      b1.a(paramArrayOfint[b2], (String)null); 
    a(']', (String)null);
    return this;
  }
  
  public b a(long[] paramArrayOflong, String paramString) {
    d(paramString);
    if (paramArrayOflong == null) {
      this.a.append("null\n");
      return this;
    } 
    if (paramArrayOflong.length == 0) {
      this.a.append(paramArrayOflong.length).append(", []\n");
      return this;
    } 
    this.a.append(paramArrayOflong.length).append(", [\n");
    b b1 = new b(this.a, this.b + 1);
    int i = paramArrayOflong.length;
    for (byte b2 = 0; b2 < i; b2++)
      b1.a(paramArrayOflong[b2], (String)null); 
    a(']', (String)null);
    return this;
  }
  
  public <T> b a(T[] paramArrayOfT, String paramString) {
    d(paramString);
    if (paramArrayOfT == null) {
      this.a.append("null\n");
      return this;
    } 
    if (paramArrayOfT.length == 0) {
      this.a.append(paramArrayOfT.length).append(", []\n");
      return this;
    } 
    this.a.append(paramArrayOfT.length).append(", [\n");
    b b1 = new b(this.a, this.b + 1);
    int i = paramArrayOfT.length;
    for (byte b2 = 0; b2 < i; b2++)
      b1.a(paramArrayOfT[b2], (String)null); 
    a(']', (String)null);
    return this;
  }
  
  public b a(short[] paramArrayOfshort, String paramString) {
    d(paramString);
    if (paramArrayOfshort == null) {
      this.a.append("null\n");
      return this;
    } 
    if (paramArrayOfshort.length == 0) {
      this.a.append(paramArrayOfshort.length).append(", []\n");
      return this;
    } 
    this.a.append(paramArrayOfshort.length).append(", [\n");
    b b1 = new b(this.a, this.b + 1);
    int i = paramArrayOfshort.length;
    for (byte b2 = 0; b2 < i; b2++)
      b1.a(paramArrayOfshort[b2], (String)null); 
    a(']', (String)null);
    return this;
  }
}


/* Location:              /home/fahim/Desktop/3e60b0f540a13c32b66cef6436052c7b1b35d003679fc86cba8edf4a5a3ebabd-dex2jar.jar!/com/tencent/bugly/legu/crashreport/crash/jni/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */