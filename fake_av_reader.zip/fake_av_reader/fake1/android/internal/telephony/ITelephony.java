package com.android.internal.telephony;

public interface ITelephony {
  void answerRingingCall();
  
  boolean endCall();
  
  void silenceRinger();
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/android/internal/telephony/ITelephony.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */