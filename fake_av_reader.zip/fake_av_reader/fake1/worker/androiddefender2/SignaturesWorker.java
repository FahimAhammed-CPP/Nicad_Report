package com.worker.androiddefender2;

import java.util.Random;

public class SignaturesWorker {
  private static Random random = new Random();
  
  public int signatures_count = 0;
  
  public int generateSignature(int paramInt) {
    return paramInt + Math.abs(random.nextInt(100));
  }
  
  public int generateSignatureFromString(String paramString) {
    return generateSignature(Integer.parseInt(paramString));
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/androiddefender2/SignaturesWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */