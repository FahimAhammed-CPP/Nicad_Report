package com.worker.helper.DAO;

import com.j256.ormlite.dao.BaseDaoImpl;
import com.j256.ormlite.support.ConnectionSource;
import com.worker.helper.Tables.ScanHistory;
import java.sql.SQLException;
import java.util.List;

public class ScanHistoryDAO extends BaseDaoImpl<ScanHistory, Integer> {
  public ScanHistoryDAO(ConnectionSource paramConnectionSource, Class<ScanHistory> paramClass) throws SQLException {
    super(paramConnectionSource, paramClass);
  }
  
  public List<ScanHistory> getAllHistories() throws SQLException {
    return queryForAll();
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/helper/DAO/ScanHistoryDAO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */