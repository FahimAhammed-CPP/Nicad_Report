package com.worker.helper;

import android.content.Context;
import com.example.androiddefender2.DefenderApplication;
import com.j256.ormlite.android.apptools.OpenHelperManager;

public class HelperFactory {
  private static ORMDatabaseHelper databaseHelper;
  
  public static ORMDatabaseHelper getHelper() {
    if (databaseHelper == null)
      setHelper(DefenderApplication.getInstance().getApplicationContext()); 
    return databaseHelper;
  }
  
  public static void releaseHelper() {
    if (databaseHelper != null) {
      OpenHelperManager.releaseHelper();
      databaseHelper = null;
    } 
  }
  
  public static void setHelper(Context paramContext) {
    databaseHelper = (ORMDatabaseHelper)OpenHelperManager.getHelper(paramContext, ORMDatabaseHelper.class);
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/helper/HelperFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */