package com.worker.helper;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;
import com.worker.helper.DAO.ScanHistoryDAO;
import com.worker.helper.DAO.VirusesIndexDAO;
import com.worker.helper.Tables.ScanHistory;
import com.worker.helper.Tables.VirusesIndex;
import java.sql.SQLException;

public class ORMDatabaseHelper extends OrmLiteSqliteOpenHelper {
  private static final String DATABASE_NAME = "AndroidDefender.db";
  
  private static final int DATABASE_VERSION = 1;
  
  private static final String TAG = ORMDatabaseHelper.class.getSimpleName();
  
  private ScanHistoryDAO scanHistoryDao = null;
  
  private VirusesIndexDAO virusesIndexesDao = null;
  
  public ORMDatabaseHelper(Context paramContext) {
    super(paramContext, "AndroidDefender.db", null, 1);
  }
  
  public void close() {
    super.close();
    this.scanHistoryDao = null;
    this.virusesIndexesDao = null;
  }
  
  public ScanHistoryDAO getScanHistoryDAO() throws SQLException {
    if (this.scanHistoryDao == null)
      try {
        ScanHistoryDAO scanHistoryDAO = new ScanHistoryDAO();
        this(getConnectionSource(), ScanHistory.class);
        this.scanHistoryDao = scanHistoryDAO;
      } catch (SQLException sQLException) {
        sQLException.printStackTrace();
      }  
    return this.scanHistoryDao;
  }
  
  public VirusesIndexDAO getVirusesIndexesDao() throws SQLException {
    if (this.virusesIndexesDao == null)
      try {
        VirusesIndexDAO virusesIndexDAO = new VirusesIndexDAO();
        this(getConnectionSource(), VirusesIndex.class);
        this.virusesIndexesDao = virusesIndexDAO;
      } catch (SQLException sQLException) {
        sQLException.printStackTrace();
      }  
    return this.virusesIndexesDao;
  }
  
  public void onCreate(SQLiteDatabase paramSQLiteDatabase, ConnectionSource paramConnectionSource) {
    try {
      TableUtils.createTable(paramConnectionSource, ScanHistory.class);
      TableUtils.createTable(paramConnectionSource, VirusesIndex.class);
      return;
    } catch (Exception exception) {
      Log.e(TAG, "error creating DB AndroidDefender.db Error text: " + exception.getMessage());
      throw new RuntimeException(exception);
    } 
  }
  
  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, ConnectionSource paramConnectionSource, int paramInt1, int paramInt2) {
    try {
      TableUtils.dropTable(paramConnectionSource, ScanHistory.class, true);
      TableUtils.dropTable(paramConnectionSource, VirusesIndex.class, true);
      onCreate(paramSQLiteDatabase, paramConnectionSource);
      return;
    } catch (SQLException sQLException) {
      sQLException.printStackTrace();
      return;
    } catch (SQLException sQLException) {
      Log.e(TAG, "error upgrading db AndroidDefender.dbfrom ver " + paramInt1);
      throw new RuntimeException(sQLException);
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/helper/ORMDatabaseHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */