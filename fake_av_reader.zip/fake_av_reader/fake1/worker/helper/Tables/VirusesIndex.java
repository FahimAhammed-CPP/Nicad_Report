package com.worker.helper.Tables;

import com.j256.ormlite.field.DataType;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "viruses_index")
public class VirusesIndex {
  @DatabaseField(generatedId = true)
  private int Id;
  
  @DatabaseField(dataType = DataType.BOOLEAN)
  private boolean curred;
  
  @DatabaseField(dataType = DataType.INTEGER)
  private int virus_id;
  
  public boolean getCurred() {
    return this.curred;
  }
  
  public Integer getVirusID() {
    return Integer.valueOf(this.virus_id);
  }
  
  public void setCurred(boolean paramBoolean) {
    this.curred = paramBoolean;
  }
  
  public void setVirusID(Integer paramInteger) {
    this.virus_id = paramInteger.intValue();
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/helper/Tables/VirusesIndex.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */