package com.worker.helper.Tables;

import com.j256.ormlite.field.DataType;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;
import java.util.Date;

@DatabaseTable(tableName = "scan_history")
public class ScanHistory {
  public static final String SCAN_HISTORY_FIELD_NAME = "name";
  
  @DatabaseField(generatedId = true)
  private int Id;
  
  @DatabaseField(dataType = DataType.DATE)
  private Date lastScanDate;
  
  @DatabaseField(canBeNull = false, columnName = "name", dataType = DataType.STRING, useGetSet = true)
  private String name;
  
  public String getName() {
    return this.name;
  }
  
  public Date getScanDate() {
    return this.lastScanDate;
  }
  
  public void setName(String paramString) {
    this.name = paramString;
  }
  
  public void setScanDate(Date paramDate) {
    this.lastScanDate = paramDate;
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/worker/helper/Tables/ScanHistory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */