package com.example.androiddefender2;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class VirusInfoDialogActivity extends Activity {
  public void btnGoBack_Click(View paramView) {
    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
    intent.putExtra("byAppDolbal", false);
    startActivity(intent);
    finish();
  }
  
  public void butStartScan_Click(View paramView) {
    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
    intent.putExtra("byAppDolbal", true);
    startActivity(intent);
    (DefenderApplication.getInstance()).tabHost.setCurrentTab(4);
    finish();
  }
  
  public void loadStartingDolbal() {
    DefenderApplication.getInstance();
    getSharedPreferences(DefenderApplication.APP_PREF, 0);
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903055);
    int i = getIntent().getIntExtra("typePopup", 1);
    String str = getIntent().getStringExtra("virusName");
    TextView textView1 = (TextView)findViewById(2131296356);
    TextView textView2 = (TextView)findViewById(2131296355);
    TextView textView3 = (TextView)findViewById(2131296352);
    ImageView imageView1 = (ImageView)findViewById(2131296350);
    ImageView imageView2 = (ImageView)findViewById(2131296353);
    if (i == 1) {
      imageView1.setImageDrawable(getResources().getDrawable(2130837567));
      imageView2.setImageDrawable(getResources().getDrawable(2130837572));
      textView1.setText(str);
    } else if (i == 2) {
      imageView1.setImageDrawable(getResources().getDrawable(2130837507));
      imageView2.setImageDrawable(getResources().getDrawable(2130837558));
      textView3.setText(getResources().getString(2131099786));
      textView2.setText(getResources().getString(2131099787));
      textView1.setVisibility(4);
    } else if (i == 3) {
      imageView1.setImageDrawable(getResources().getDrawable(2130837581));
      imageView2.setImageDrawable(getResources().getDrawable(2130837550));
      textView3.setText(getResources().getString(2131099788));
      textView2.setText(getResources().getString(2131099791));
      textView1.setVisibility(0);
      textView1.setText(str);
    } else if (i == 4) {
      imageView1.setImageDrawable(getResources().getDrawable(2130837507));
      imageView2.setImageDrawable(getResources().getDrawable(2130837534));
      textView3.setText(getResources().getString(2131099786));
      textView2.setText(getResources().getString(2131099787));
      textView1.setVisibility(4);
    } 
    saveStartingDolbal();
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230733, paramMenu);
    return true;
  }
  
  public void saveStartingDolbal() {
    DefenderApplication.getInstance();
    SharedPreferences.Editor editor = getSharedPreferences(DefenderApplication.APP_PREF, 0).edit();
    editor.putBoolean("virusDolbal", true);
    editor.commit();
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/VirusInfoDialogActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */