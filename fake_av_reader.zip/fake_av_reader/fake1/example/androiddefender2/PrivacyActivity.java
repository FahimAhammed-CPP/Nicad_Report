package com.example.androiddefender2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import system.AppSingleton;

public class PrivacyActivity extends CustomActGroup {
  public static PrivacyActivity self;
  
  public Button btnByApp;
  
  public CheckBox chkProtectCallRec;
  
  public CheckBox chkProtectGeoLoc;
  
  public CheckBox chkProtectSMS;
  
  private ArrayList<View> history;
  
  public void btnByApp_Click(View paramView) {
    if (!(AppSingleton.getInstance()).activaten) {
      (DefenderApplication.getInstance()).tabHost.setCurrentTab(4);
      return;
    } 
    DefenderApplication.getInstance();
    SharedPreferences.Editor editor = getSharedPreferences(DefenderApplication.APP_PREF, 0).edit();
    editor.putBoolean("chkProtectSMS", this.chkProtectSMS.isChecked());
    editor.putBoolean("chkProtectCallRec", this.chkProtectCallRec.isChecked());
    editor.putBoolean("chkProtectGeoLoc", this.chkProtectGeoLoc.isChecked());
    editor.commit();
  }
  
  public void btnGoBack_Click(View paramView) {
    onBackPressed();
  }
  
  public void butBlackList_Click(View paramView) {
    startChildActivity("BlackList", new Intent((Context)this, BlackList.class), true);
  }
  
  public void loadPreferences() {
    DefenderApplication.getInstance();
    SharedPreferences sharedPreferences = getSharedPreferences(DefenderApplication.APP_PREF, 0);
    this.chkProtectSMS.setChecked(sharedPreferences.getBoolean("chkProtectSMS", false));
    this.chkProtectCallRec.setChecked(sharedPreferences.getBoolean("chkProtectCallRec", false));
    this.chkProtectGeoLoc.setChecked(sharedPreferences.getBoolean("chkProtectGeoLoc", false));
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (paramInt2 == -1)
      ((BlackList)getLocalActivityManager().getCurrentActivity()).onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903046);
    if (this.history == null)
      this.history = new ArrayList<View>(); 
    Button button = (Button)findViewById(2131296262);
    ImageView imageView = (ImageView)findViewById(2131296266);
    TextView textView = (TextView)findViewById(2131296268);
    this.chkProtectSMS = (CheckBox)findViewById(2131296296);
    this.chkProtectCallRec = (CheckBox)findViewById(2131296298);
    this.chkProtectGeoLoc = (CheckBox)findViewById(2131296297);
    if (!(AppSingleton.getInstance()).activaten) {
      ((Button)findViewById(2131296265)).setEnabled(false);
      this.chkProtectSMS.setEnabled(false);
      this.chkProtectCallRec.setEnabled(false);
      this.chkProtectGeoLoc.setEnabled(false);
      imageView.setImageResource(2130837559);
      textView.setText(2131099707);
      button.setText(getResources().getString(2131099706));
    } else {
      imageView.setImageResource(2130837506);
      textView.setText(2131099725);
      button.setText(getResources().getString(2131099758));
    } 
    self = this;
    loadPreferences();
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230724, paramMenu);
    return true;
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/PrivacyActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */