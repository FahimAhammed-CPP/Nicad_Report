package com.example.androiddefender2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import system.AppSingleton;

public class ScanActivity extends CustomActGroup {
  public static Context context;
  
  public CheckBox chkAutoScan;
  
  public CheckBox chkScanFridei;
  
  public CheckBox chkScanSand;
  
  public CheckBox chkScanSatur;
  
  public CheckBox chkScanThurs;
  
  public CheckBox chkScanTues;
  
  public CheckBox chkScanWedn;
  
  public CheckBox chkSkanMond;
  
  public CheckBox scanApplication;
  
  public CheckBox scanSDCard;
  
  public void PrepareSettings() {
    try {
      SharedPreferences sharedPreferences = getSharedPreferences("ScanSettings", 0);
      this.scanApplication.setChecked(sharedPreferences.getBoolean("scan_app", false));
      this.scanSDCard.setChecked(sharedPreferences.getBoolean("scan_sd", false));
      this.chkAutoScan.setChecked(sharedPreferences.getBoolean("auto_scan", false));
      this.chkSkanMond.setChecked(sharedPreferences.getBoolean("scan_mond", false));
      this.chkScanTues.setChecked(sharedPreferences.getBoolean("scan_tues", false));
      this.chkScanWedn.setChecked(sharedPreferences.getBoolean("scan_wedn", false));
      this.chkScanThurs.setChecked(sharedPreferences.getBoolean("scan_thurs", false));
      this.chkScanFridei.setChecked(sharedPreferences.getBoolean("scan_fridei", false));
      this.chkScanSatur.setChecked(sharedPreferences.getBoolean("scan_satur", false));
      this.chkScanSand.setChecked(sharedPreferences.getBoolean("scan_sand", false));
    } catch (Exception exception) {
      Toast.makeText(getApplicationContext(), exception.getMessage(), 1).show();
    } 
  }
  
  public void SaveSettings() {
    try {
      SharedPreferences.Editor editor = getSharedPreferences("ScanSettings", 0).edit();
      editor.putBoolean("scan_app", this.scanApplication.isChecked());
      editor.putBoolean("scan_sd", this.scanSDCard.isChecked());
      editor.putBoolean("auto_scan", this.chkAutoScan.isChecked());
      editor.putBoolean("scan_mond", this.chkSkanMond.isChecked());
      editor.putBoolean("scan_tues", this.chkScanTues.isChecked());
      editor.putBoolean("scan_wedn", this.chkScanWedn.isChecked());
      editor.putBoolean("scan_thurs", this.chkScanThurs.isChecked());
      editor.putBoolean("scan_fridei", this.chkScanFridei.isChecked());
      editor.putBoolean("scan_satur", this.chkScanSatur.isChecked());
      editor.putBoolean("scan_sand", this.chkScanSand.isChecked());
      editor.commit();
    } catch (Exception exception) {
      Toast.makeText(getApplicationContext(), exception.getMessage(), 1).show();
    } 
  }
  
  public void btnFullProtect_Click(View paramView) {
    (DefenderApplication.getInstance()).tabHost.setCurrentTab(4);
  }
  
  public void butStartScan_Click(View paramView) {
    SaveSettings();
    try {
      if (this.scanApplication.isChecked() || this.scanSDCard.isChecked()) {
        if (this.scanSDCard.isChecked() && !Boolean.valueOf(Environment.isExternalStorageRemovable()).booleanValue()) {
          Toast.makeText(getApplicationContext(), getResources().getString(2131099756), 0).show();
          return;
        } 
        Intent intent = new Intent();
        this((Context)this, SingleScanActivity.class);
        intent.putExtra("scanApplication", this.scanApplication.isChecked());
        intent.putExtra("scanSDCard", this.scanSDCard.isChecked());
        startActivity(intent);
        return;
      } 
    } catch (Exception exception) {
      Toast.makeText(getApplicationContext(), exception.getMessage(), 0).show();
      return;
    } 
    Toast.makeText(getApplicationContext(), getResources().getString(2131099755), 0).show();
  }
  
  public View getViewScan() {
    return getLocalActivityManager().startActivity("ScanMain", (new Intent((Context)this, ScanActivity.class)).addFlags(67108864)).getDecorView();
  }
  
  public void onCreate(Bundle paramBundle) {
    try {
      super.onCreate(paramBundle);
      RelativeLayout relativeLayout = (RelativeLayout)findViewById(2130903047);
      if (relativeLayout != null) {
        relativeLayout.invalidate();
        setContentView((View)relativeLayout);
      } else {
        setContentView(2130903047);
      } 
      this.scanApplication = (CheckBox)findViewById(2131296318);
      this.scanSDCard = (CheckBox)findViewById(2131296300);
      this.chkAutoScan = (CheckBox)findViewById(2131296303);
      this.chkSkanMond = (CheckBox)findViewById(2131296304);
      this.chkScanTues = (CheckBox)findViewById(2131296305);
      this.chkScanWedn = (CheckBox)findViewById(2131296306);
      this.chkScanThurs = (CheckBox)findViewById(2131296307);
      this.chkScanFridei = (CheckBox)findViewById(2131296308);
      this.chkScanSatur = (CheckBox)findViewById(2131296309);
      this.chkScanSand = (CheckBox)findViewById(2131296310);
      ImageView imageView = (ImageView)findViewById(2131296319);
      TextView textView = (TextView)findViewById(2131296320);
      Button button = (Button)findViewById(2131296301);
      if (!(AppSingleton.getInstance()).activaten) {
        imageView.setImageResource(2130837580);
        textView.setTextColor(Color.parseColor("#9b0000"));
        textView.setText(2131099721);
        button.setVisibility(0);
        this.scanSDCard.setEnabled(false);
        this.chkAutoScan.setEnabled(false);
        this.chkSkanMond.setEnabled(false);
        this.chkScanTues.setEnabled(false);
        this.chkScanWedn.setEnabled(false);
        this.chkScanThurs.setEnabled(false);
        this.chkScanFridei.setEnabled(false);
        this.chkScanSatur.setEnabled(false);
        this.chkScanSand.setEnabled(false);
      } else {
        imageView.setImageResource(2130837556);
        textView.setTextColor(Color.parseColor("#155d86"));
        textView.setText(2131099720);
        button.setVisibility(4);
      } 
      context = (Context)this;
    } catch (Exception exception) {
      Toast.makeText(getApplicationContext(), exception.getMessage(), 1).show();
    } 
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230725, paramMenu);
    return true;
  }
  
  protected void onPause() {
    super.onPause();
    SaveSettings();
  }
  
  protected void onRestart() {
    super.onRestart();
    PrepareSettings();
  }
  
  protected void onResume() {
    super.onResume();
    PrepareSettings();
  }
  
  protected void onStart() {
    super.onStart();
    try {
      PrepareSettings();
    } catch (Exception exception) {
      exception.toString();
    } 
  }
  
  protected void onStop() {
    super.onStop();
    SaveSettings();
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/ScanActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */