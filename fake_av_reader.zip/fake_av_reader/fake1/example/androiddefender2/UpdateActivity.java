package com.example.androiddefender2;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import com.worker.androiddefender2.SignaturesWorker;
import com.worker.androiddefender2.VersionWorker;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import system.AppSingleton;

public class UpdateActivity extends CustomActGroup {
  public static UpdateActivity self;
  
  public static final String[] updateUrls = new String[] { "Signature 1.xsl", "Signature 2.xsl", "Signature 3.xsl", "Signature 4.xsl", "Signature 5.xsl", "Signature 6.xsl" };
  
  public TextView baseVersion;
  
  public TextView countSignature;
  
  public TextView dateLastUpdate;
  
  private getUpdateInfo loader;
  
  public ProgressBar progressBar;
  
  public String signature_version = "150";
  
  public TextView tvFilesCount;
  
  public TextView tvProcentPr;
  
  public String update_date = "";
  
  public String update_version = "10.0.0.1";
  
  public void addRow(String paramString) {
    TableLayout tableLayout = (TableLayout)findViewById(2131296328);
    TableRow tableRow = (TableRow)((LayoutInflater)getSystemService("layout_inflater")).inflate(2130903062, null);
    ((TextView)tableRow.getChildAt(1)).setText(paramString);
    tableLayout.addView((View)tableRow);
  }
  
  public void btnGoBack_Click(View paramView) {
    onBackPressed();
  }
  
  public void butStartScan_Click(View paramView) {
    (DefenderApplication.getInstance()).tabHost.setCurrentTab(4);
  }
  
  public boolean checkDate(long paramLong) {
    DefenderApplication.getInstance();
    return !(paramLong - getSharedPreferences(DefenderApplication.APP_PREF, 0).getLong("lastTimeUpdate", 0L) < 86400000L);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (!(AppSingleton.getInstance()).activaten) {
      setContentView(2130903054);
    } else {
      setContentView(2130903053);
      Button button = (Button)findViewById(2131296299);
      button.setFocusable(true);
      button.requestFocus();
      this.progressBar = (ProgressBar)findViewById(2131296323);
      this.tvFilesCount = (TextView)findViewById(2131296330);
      this.tvProcentPr = (TextView)findViewById(2131296331);
      button.setTypeface((DefenderApplication.getInstance()).type_arial, 1);
      this.tvFilesCount.setTypeface((DefenderApplication.getInstance()).type_arial, 0);
      this.tvProcentPr.setTypeface((DefenderApplication.getInstance()).type_arial, 0);
    } 
    this.baseVersion = (TextView)findViewById(2131296345);
    this.countSignature = (TextView)findViewById(2131296346);
    this.dateLastUpdate = (TextView)findViewById(2131296348);
    this.baseVersion.setTypeface((DefenderApplication.getInstance()).type_arial, 0);
    this.countSignature.setTypeface((DefenderApplication.getInstance()).type_arial, 0);
    this.dateLastUpdate.setTypeface((DefenderApplication.getInstance()).type_arial, 0);
    updateVersionInfoInUI();
    updateCountSignatureUI();
    updateDate();
    self = this;
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230729, paramMenu);
    return true;
  }
  
  public void onResume() {
    super.onResume();
  }
  
  public void saveLastUpdateMillis(long paramLong) {
    DefenderApplication.getInstance();
    SharedPreferences.Editor editor = getSharedPreferences(DefenderApplication.APP_PREF, 0).edit();
    editor.putLong("lastTimeUpdate", paramLong);
    editor.commit();
  }
  
  public void startUpdate(View paramView) {
    if (this.loader == null || this.loader.getStatus().equals(AsyncTask.Status.FINISHED))
      try {
        Calendar calendar = Calendar.getInstance();
        long l = calendar.getTimeInMillis() + calendar.getTimeZone().getOffset(calendar.getTimeInMillis());
        if (checkDate(l)) {
          saveLastUpdateMillis(l);
          this.progressBar.setProgress(0);
          this.tvProcentPr.setText("0%");
          ((TableLayout)findViewById(2131296328)).removeAllViews();
          TextView textView = this.tvFilesCount;
          StringBuilder stringBuilder = new StringBuilder();
          this();
          textView.setText(stringBuilder.append("0/").append(updateUrls.length).toString());
          getUpdateInfo getUpdateInfo1 = new getUpdateInfo();
          this(this);
          this.loader = getUpdateInfo1;
          this.loader.execute((Object[])updateUrls);
          ((Button)findViewById(2131296299)).setEnabled(false);
          updateVersionInfoInUI();
          updateCountSignatureUI();
          updateDate();
          return;
        } 
        Toast.makeText(getApplicationContext(), getResources().getString(2131099759), 0).show();
      } catch (Exception exception) {
        exception.toString();
      }  
  }
  
  public void updateCountSignatureUI() {
    SharedPreferences sharedPreferences = getSharedPreferences("Updates", 0);
    if (sharedPreferences.contains("count_signatures")) {
      this.signature_version = sharedPreferences.getString("count_signatures", "150");
    } else {
      this.signature_version = String.valueOf((new SignaturesWorker()).generateSignatureFromString(this.signature_version));
      SharedPreferences.Editor editor = sharedPreferences.edit();
      editor.putString("count_signatures", this.signature_version);
      editor.commit();
    } 
    this.countSignature.setText(getResources().getString(2131099667) + " " + this.signature_version);
  }
  
  @SuppressLint({"SimpleDateFormat"})
  public void updateDate() {
    Date date = new Date();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy");
    SharedPreferences sharedPreferences = getSharedPreferences("Updates", 0);
    if (sharedPreferences.contains("date_last_update")) {
      this.update_date = sharedPreferences.getString("date_last_update", simpleDateFormat.format(date));
    } else {
      this.update_date = simpleDateFormat.format(date);
      SharedPreferences.Editor editor = sharedPreferences.edit();
      editor.putString("date_last_update", this.update_date);
      editor.commit();
    } 
    this.dateLastUpdate.setText(getResources().getString(2131099668) + " " + this.update_date);
  }
  
  public void updateVersionInfoInUI() {
    SharedPreferences sharedPreferences = getSharedPreferences("Updates", 0);
    if (sharedPreferences.contains("versionbase")) {
      this.update_version = sharedPreferences.getString("versionbase", "10.0.0.1");
    } else {
      String str = (new VersionWorker()).generateVersionFromString("10.0.0.0");
      this.update_version = str;
      SharedPreferences.Editor editor = sharedPreferences.edit();
      editor.putString("versionbase", str);
      editor.commit();
    } 
    this.baseVersion.setText(getResources().getString(2131099666) + " " + this.update_version);
  }
  
  class getUpdateInfo extends AsyncTask<String, Integer, Void> {
    private int count_files = 0;
    
    private int current_file = 0;
    
    private int progr = 0;
    
    protected Void doInBackground(String... param1VarArgs) {
      this.count_files = param1VarArgs.length;
      for (byte b = 0; b < param1VarArgs.length; b++) {
        try {
          Thread.sleep(1800L);
          this.progr = b;
          publishProgress((Object[])new Integer[] { Integer.valueOf(this.progr) });
          this.current_file++;
        } catch (InterruptedException interruptedException) {
          interruptedException.printStackTrace();
        } 
      } 
      return null;
    }
    
    protected void onPostExecute(Void param1Void) {
      ((Button)UpdateActivity.this.findViewById(2131296299)).setEnabled(true);
    }
    
    @SuppressLint({"SimpleDateFormat"})
    protected void onProgressUpdate(Integer... param1VarArgs) {
      try {
        int i = param1VarArgs[0].intValue();
        double d = this.count_files / 100.0D;
        int j = (int)Math.ceil((i + 1) / d);
        UpdateActivity.this.progressBar.setProgress(j);
        TextView textView1 = UpdateActivity.this.tvFilesCount;
        StringBuilder stringBuilder2 = new StringBuilder();
        this();
        textView1.setText(stringBuilder2.append(i + 1).append("/").append(this.count_files).toString());
        TextView textView2 = UpdateActivity.this.tvProcentPr;
        StringBuilder stringBuilder1 = new StringBuilder();
        this();
        textView2.setText(stringBuilder1.append(j).append("%").toString());
        TableLayout tableLayout = (TableLayout)UpdateActivity.this.findViewById(2131296328);
        if (tableLayout.getChildCount() >= UpdateActivity.updateUrls.length)
          tableLayout.removeAllViews(); 
        UpdateActivity.this.addRow(UpdateActivity.updateUrls[i].toString());
        if (j == 100) {
          VersionWorker versionWorker = new VersionWorker();
          this();
          String str = versionWorker.generateVersionFromString(UpdateActivity.this.update_version);
          SharedPreferences.Editor editor = UpdateActivity.this.getSharedPreferences("Updates", 0).edit();
          editor.putString("versionbase", str);
          UpdateActivity.this.updateVersionInfoInUI();
          SignaturesWorker signaturesWorker = new SignaturesWorker();
          this();
          editor.putString("count_signatures", String.valueOf(signaturesWorker.generateSignatureFromString(UpdateActivity.this.signature_version)));
          UpdateActivity.this.updateCountSignatureUI();
          Date date = new Date();
          this();
          SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
          this("dd.MM.yyyy");
          editor.putString("date_last_update", simpleDateFormat.format(date));
          UpdateActivity.this.updateDate();
          editor.commit();
        } 
      } catch (Exception exception) {
        exception.toString();
      } 
    }
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/UpdateActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */