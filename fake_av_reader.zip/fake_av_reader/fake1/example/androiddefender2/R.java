package com.example.androiddefender2;

public final class R {
  public static final class attr {}
  
  public static final class bool {
    public static final int isTablet = 2131034112;
  }
  
  public static final class dimen {
    public static final int activity_horizontal_margin = 2130968576;
    
    public static final int activity_vertical_margin = 2130968577;
  }
  
  public static final class drawable {
    public static final int attention_ico = 2130837504;
    
    public static final int auto_scan_settings = 2130837505;
    
    public static final int big_blue_ok = 2130837506;
    
    public static final int blue_attention = 2130837507;
    
    public static final int btn_cam_res = 2130837508;
    
    public static final int btn_full_protect = 2130837509;
    
    public static final int btn_grey_bg = 2130837510;
    
    public static final int btn_scan_act = 2130837511;
    
    public static final int btn_start_cam = 2130837512;
    
    public static final int btn_start_cam_act = 2130837513;
    
    public static final int btnfon = 2130837514;
    
    public static final int bullet = 2130837515;
    
    public static final int bullet_red = 2130837516;
    
    public static final int calendar = 2130837517;
    
    public static final int center_home_block = 2130837518;
    
    public static final int checkbox_draw = 2130837519;
    
    public static final int checkbox_draw64 = 2130837520;
    
    public static final int checked = 2130837521;
    
    public static final int checked20 = 2130837522;
    
    public static final int checked24 = 2130837523;
    
    public static final int checked48 = 2130837524;
    
    public static final int checked64 = 2130837525;
    
    public static final int chk_version = 2130837526;
    
    public static final int clicked_row_background = 2130837527;
    
    public static final int detected = 2130837528;
    
    public static final int fon = 2130837529;
    
    public static final int gray_circle = 2130837530;
    
    public static final int guard_att = 2130837531;
    
    public static final int guard_btn = 2130837532;
    
    public static final int guard_btn2 = 2130837533;
    
    public static final int hack_image = 2130837534;
    
    public static final int heder = 2130837535;
    
    public static final int heder_non_active = 2130837536;
    
    public static final int horizontal_delim = 2130837537;
    
    public static final int ic_action_search = 2130837538;
    
    public static final int ic_home = 2130837539;
    
    public static final int ic_key = 2130837540;
    
    public static final int ic_launcher = 2130837541;
    
    public static final int ic_privatnost = 2130837542;
    
    public static final int ic_settings = 2130837543;
    
    public static final int ic_support = 2130837544;
    
    public static final int ic_update = 2130837545;
    
    public static final int ico_key = 2130837546;
    
    public static final int lastscan = 2130837547;
    
    public static final int line_delimiter = 2130837548;
    
    public static final int line_white = 2130837549;
    
    public static final int message_image = 2130837550;
    
    public static final int nonchecked = 2130837551;
    
    public static final int nonchecked20 = 2130837552;
    
    public static final int nonchecked24 = 2130837553;
    
    public static final int nonchecked48 = 2130837554;
    
    public static final int nonchecked64 = 2130837555;
    
    public static final int ok_blue = 2130837556;
    
    public static final int ok_green = 2130837557;
    
    public static final int phonehack_image = 2130837558;
    
    public static final int privacy = 2130837559;
    
    public static final int progress_fon = 2130837560;
    
    public static final int progress_fon_blue = 2130837561;
    
    public static final int progress_fon_green = 2130837562;
    
    public static final int progress_fon_nonactive = 2130837563;
    
    public static final int progressbar_blue = 2130837564;
    
    public static final int progressbar_green = 2130837565;
    
    public static final int progressbar_st = 2130837566;
    
    public static final int red_attention = 2130837567;
    
    public static final int scan_status = 2130837568;
    
    public static final int scanning_proccess = 2130837569;
    
    public static final int screen_header = 2130837570;
    
    public static final int shesterenka = 2130837571;
    
    public static final int spider = 2130837572;
    
    public static final int sub_center_home_block = 2130837573;
    
    public static final int table_delimitr = 2130837574;
    
    public static final int tabs_transparent = 2130837575;
    
    public static final int text_view_grey = 2130837576;
    
    public static final int user = 2130837577;
    
    public static final int vers_check = 2130837578;
    
    public static final int virus_danger_row = 2130837579;
    
    public static final int warning = 2130837580;
    
    public static final int yellow_attention = 2130837581;
    
    public static final int zamochek = 2130837582;
  }
  
  public static final class id {
    public static final int ImageView01 = 2131296278;
    
    public static final int action_settings = 2131296372;
    
    public static final int baseVersion = 2131296345;
    
    public static final int btnBack = 2131296292;
    
    public static final int btnBlackList = 2131296265;
    
    public static final int btnByAndRemove = 2131296332;
    
    public static final int btnByApp = 2131296262;
    
    public static final int btnFullProtect = 2131296301;
    
    public static final int btnGoBack = 2131296295;
    
    public static final int btnOk = 2131296275;
    
    public static final int btnRepeat = 2131296333;
    
    public static final int btnResumeWork = 2131296276;
    
    public static final int btnResumeWorking = 2131296344;
    
    public static final int btnSaveSettings = 2131296338;
    
    public static final int btnScan = 2131296284;
    
    public static final int butActivateApp = 2131296343;
    
    public static final int butStartScan = 2131296299;
    
    public static final int button1 = 2131296270;
    
    public static final int centerHomeBlock = 2131296277;
    
    public static final int chkAutoScan = 2131296303;
    
    public static final int chkAutostart = 2131296337;
    
    public static final int chkHaveKey = 2131296342;
    
    public static final int chkMessages = 2131296339;
    
    public static final int chkMinimizeWhenStart = 2131296341;
    
    public static final int chkNotGetCall = 2131296261;
    
    public static final int chkNotGetSMS = 2131296263;
    
    public static final int chkProtectCallRec = 2131296298;
    
    public static final int chkProtectGeoLoc = 2131296297;
    
    public static final int chkProtectSMS = 2131296296;
    
    public static final int chkScanFridei = 2131296308;
    
    public static final int chkScanSand = 2131296310;
    
    public static final int chkScanSatur = 2131296309;
    
    public static final int chkScanThurs = 2131296307;
    
    public static final int chkScanTues = 2131296305;
    
    public static final int chkScanWedn = 2131296306;
    
    public static final int chkSkanMond = 2131296304;
    
    public static final int chkStartWhenStart = 2131296340;
    
    public static final int countSignature = 2131296346;
    
    public static final int custom_notification = 2131296359;
    
    public static final int dateLastUpdate = 2131296348;
    
    public static final int edtActivationCode = 2131296273;
    
    public static final int edtPhoneNumber = 2131296269;
    
    public static final int icon = 2131296366;
    
    public static final int imageView1 = 2131296290;
    
    public static final int imageView2 = 2131296271;
    
    public static final int imageView3 = 2131296283;
    
    public static final int imageView4 = 2131296280;
    
    public static final int imageView5 = 2131296336;
    
    public static final int imageView6 = 2131296354;
    
    public static final int imageView7 = 2131296357;
    
    public static final int imgAttentionIco = 2131296353;
    
    public static final int imgCenterHome = 2131296321;
    
    public static final int imgCenterHomeBlock = 2131296256;
    
    public static final int imgDelPhone = 2131296368;
    
    public static final int imgDelimetr = 2131296259;
    
    public static final int imgHeaderInfo = 2131296350;
    
    public static final int imgIcoV = 2131296369;
    
    public static final int imgIconNotif = 2131296360;
    
    public static final int imgLogo = 2131296291;
    
    public static final int imgSubCenterHomeBlock = 2131296326;
    
    public static final int imgWarning = 2131296319;
    
    public static final int imgZamocIc = 2131296260;
    
    public static final int imgZamok = 2131296266;
    
    public static final int menu_settings = 2131296371;
    
    public static final int password = 2131296364;
    
    public static final int pbProgress = 2131296362;
    
    public static final int prgbScanStat = 2131296323;
    
    public static final int privacyReklamText = 2131296268;
    
    public static final int reklmaTextScroll = 2131296267;
    
    public static final int scanApplication = 2131296318;
    
    public static final int scanSDCard = 2131296300;
    
    public static final int scanStatus = 2131296257;
    
    public static final int scrollView1 = 2131296285;
    
    public static final int subCenterBlock = 2131296264;
    
    public static final int subCenterHomeBlock = 2131296347;
    
    public static final int telephonNumbersTable = 2131296293;
    
    public static final int textView1 = 2131296302;
    
    public static final int textView2 = 2131296351;
    
    public static final int textView6 = 2131296325;
    
    public static final int textView7 = 2131296358;
    
    public static final int title = 2131296367;
    
    public static final int tvChetv = 2131296314;
    
    public static final int tvCurFile = 2131296324;
    
    public static final int tvDetected = 2131296370;
    
    public static final int tvFilesCount = 2131296330;
    
    public static final int tvHeader = 2131296279;
    
    public static final int tvKeyInfo = 2131296274;
    
    public static final int tvPn = 2131296311;
    
    public static final int tvProcentPr = 2131296331;
    
    public static final int tvPyatn = 2131296315;
    
    public static final int tvReklamInfo = 2131296327;
    
    public static final int tvScanResult = 2131296287;
    
    public static final int tvSr = 2131296313;
    
    public static final int tvSub = 2131296316;
    
    public static final int tvUpdList = 2131296349;
    
    public static final int tvVersionBase = 2131296288;
    
    public static final int tvVskres = 2131296317;
    
    public static final int tvVt = 2131296312;
    
    public static final int tvWarningMsg = 2131296320;
    
    public static final int txtFinalVirusView = 2131296329;
    
    public static final int txtHeader = 2131296258;
    
    public static final int txtHeaderMessage = 2131296352;
    
    public static final int txtStatus = 2131296361;
    
    public static final int txtStatusScan = 2131296322;
    
    public static final int txtStatusScanNew = 2131296294;
    
    public static final int txtUpdDate = 2131296282;
    
    public static final int txtUpdate = 2131296281;
    
    public static final int txtVersionBase = 2131296289;
    
    public static final int txtVirusName = 2131296356;
    
    public static final int txtWarningDef = 2131296355;
    
    public static final int txtWarningMsg = 2131296334;
    
    public static final int txtWarningMsgSec = 2131296335;
    
    public static final int understund = 2131296365;
    
    public static final int username = 2131296363;
    
    public static final int virusScanningTable = 2131296328;
    
    public static final int virusTable = 2131296286;
    
    public static final int webView = 2131296272;
  }
  
  public static final class layout {
    public static final int activity_black_list = 2130903040;
    
    public static final int activity_by_support = 2130903041;
    
    public static final int activity_home = 2130903042;
    
    public static final int activity_main = 2130903043;
    
    public static final int activity_numbers_list = 2130903044;
    
    public static final int activity_pay_form = 2130903045;
    
    public static final int activity_privacy = 2130903046;
    
    public static final int activity_scan = 2130903047;
    
    public static final int activity_scanning = 2130903048;
    
    public static final int activity_settings = 2130903049;
    
    public static final int activity_single_scan = 2130903050;
    
    public static final int activity_support = 2130903051;
    
    public static final int activity_support_activate = 2130903052;
    
    public static final int activity_update = 2130903053;
    
    public static final int activity_update_n = 2130903054;
    
    public static final int activity_virus_info_dialog = 2130903055;
    
    public static final int custom_notify = 2130903056;
    
    public static final int dialog_scan_error = 2130903057;
    
    public static final int tab_item = 2130903058;
    
    public static final int table_row = 2130903059;
    
    public static final int table_row_number = 2130903060;
    
    public static final int table_row_scan = 2130903061;
    
    public static final int table_update_row = 2130903062;
  }
  
  public static final class menu {
    public static final int activity_black_list = 2131230720;
    
    public static final int activity_home = 2131230721;
    
    public static final int activity_main = 2131230722;
    
    public static final int activity_numbers_list = 2131230723;
    
    public static final int activity_privacy = 2131230724;
    
    public static final int activity_scan = 2131230725;
    
    public static final int activity_scanning = 2131230726;
    
    public static final int activity_settings = 2131230727;
    
    public static final int activity_support = 2131230728;
    
    public static final int activity_update = 2131230729;
    
    public static final int by_support = 2131230730;
    
    public static final int pay_form = 2131230731;
    
    public static final int single_scan = 2131230732;
    
    public static final int virus_info_dialog = 2131230733;
  }
  
  public static final class string {
    public static final int Scansystem = 2131099657;
    
    public static final int action_settings = 2131099751;
    
    public static final int activate_application = 2131099726;
    
    public static final int actual_base = 2131099716;
    
    public static final int add_to_black_list = 2131099711;
    
    public static final int app_name = 2131099648;
    
    public static final int black_list = 2131099705;
    
    public static final int btnCancel = 2131099676;
    
    public static final int btn_save = 2131099675;
    
    public static final int btn_save_small = 2131099758;
    
    public static final int by_and_remove_virus = 2131099698;
    
    public static final int by_prg = 2131099706;
    
    public static final int clear_files = 2131099664;
    
    public static final int count_signaturs = 2131099667;
    
    public static final int date_last_scan_text = 2131099677;
    
    public static final int delete_from_black_list = 2131099715;
    
    public static final int empty = 2131099659;
    
    public static final int field_for_key = 2131099775;
    
    public static final int filter_incoming_header = 2131099742;
    
    public static final int filter_incoming_message = 2131099743;
    
    public static final int filter_outcoming_header = 2131099744;
    
    public static final int filter_outcoming_message = 2131099745;
    
    public static final int finded_warnings = 2131099696;
    
    public static final int full_protect = 2131099694;
    
    public static final int full_reklam_scan_text = 2131099721;
    
    public static final int go_with_virus = 2131099699;
    
    public static final int hello_world = 2131099649;
    
    public static final int i_have_key_activation = 2131099727;
    
    public static final int last_scan_date = 2131099668;
    
    public static final int list_updates = 2131099663;
    
    public static final int menu_settings = 2131099650;
    
    public static final int new_signatur_count = 2131099662;
    
    public static final int not_get_call = 2131099709;
    
    public static final int not_get_sms = 2131099710;
    
    public static final int notify_scanning = 2131099733;
    
    public static final int notify_scanning_files = 2131099735;
    
    public static final int notify_scanning_process = 2131099734;
    
    public static final int prepare_files_step = 2131099739;
    
    public static final int prepare_scan_string = 2131099736;
    
    public static final int privacy_activate = 2131099725;
    
    public static final int privacy_geolokation = 2131099704;
    
    public static final int privacy_phone = 2131099703;
    
    public static final int privacy_reklam_text = 2131099707;
    
    public static final int privacy_settings = 2131099702;
    
    public static final int privacy_sms = 2131099701;
    
    public static final int process_scan = 2131099697;
    
    public static final int push_auto_scan = 2131099685;
    
    public static final int reklam_black_list = 2131099712;
    
    public static final int resume_working = 2131099777;
    
    public static final int scan_application = 2131099691;
    
    public static final int scan_close = 2131099776;
    
    public static final int scan_result = 2131099661;
    
    public static final int scan_sd = 2131099692;
    
    public static final int scanning_deleted_defect = 2131099738;
    
    public static final int scanning_found_defect = 2131099737;
    
    public static final int scanning_sdcard_step = 2131099741;
    
    public static final int scanning_system_step = 2131099740;
    
    public static final int set_settings_app = 2131099700;
    
    public static final int settings_autostart = 2131099669;
    
    public static final int settings_message = 2131099672;
    
    public static final int settings_minimize = 2131099671;
    
    public static final int settings_startscan = 2131099670;
    
    public static final int show_black_list = 2131099713;
    
    public static final int start_auto_scan = 2131099689;
    
    public static final int start_scan_btn = 2131099690;
    
    public static final int status_scan = 2131099695;
    
    public static final int stop_scan = 2131099724;
    
    public static final int success_key_header = 2131099778;
    
    public static final int success_key_message = 2131099779;
    
    public static final int support_manager = 2131099774;
    
    public static final int test_file = 2131099732;
    
    public static final int test_test_test = 2131099790;
    
    public static final int title_activity_black_list = 2131099708;
    
    public static final int title_activity_by_support = 2131099750;
    
    public static final int title_activity_home = 2131099656;
    
    public static final int title_activity_main = 2131099651;
    
    public static final int title_activity_numbers_list = 2131099714;
    
    public static final int title_activity_pay_form = 2131099789;
    
    public static final int title_activity_privacy = 2131099654;
    
    public static final int title_activity_scan = 2131099658;
    
    public static final int title_activity_scanning = 2131099660;
    
    public static final int title_activity_settings = 2131099653;
    
    public static final int title_activity_single_scan = 2131099765;
    
    public static final int title_activity_support = 2131099655;
    
    public static final int title_activity_update = 2131099652;
    
    public static final int title_activity_virus_info_dialog = 2131099780;
    
    public static final int txtFri = 2131099682;
    
    public static final int txtMond = 2131099678;
    
    public static final int txtSand = 2131099684;
    
    public static final int txtSatur = 2131099683;
    
    public static final int txtThursd = 2131099681;
    
    public static final int txtTuesd = 2131099679;
    
    public static final int txtWedn = 2131099680;
    
    public static final int txt_activate = 2131099747;
    
    public static final int txt_add_black_error_header = 2131099769;
    
    public static final int txt_add_black_header = 2131099767;
    
    public static final int txt_add_black_message = 2131099768;
    
    public static final int txt_add_black_warning_header = 2131099770;
    
    public static final int txt_add_black_warning_message = 2131099771;
    
    public static final int txt_add_black_warning_params_header = 2131099772;
    
    public static final int txt_add_black_warning_params_message = 2131099773;
    
    public static final int txt_attention = 2131099781;
    
    public static final int txt_attention_message = 2131099783;
    
    public static final int txt_attention_process = 2131099784;
    
    public static final int txt_attention_protect = 2131099785;
    
    public static final int txt_cancel = 2131099761;
    
    public static final int txt_dark_center_block = 2131099688;
    
    public static final int txt_delete_phone = 2131099763;
    
    public static final int txt_err_activate_code_empty = 2131099748;
    
    public static final int txt_err_activate_code_incorrect = 2131099749;
    
    public static final int txt_error_scan_settings = 2131099755;
    
    public static final int txt_error_sdcard_notexists = 2131099756;
    
    public static final int txt_filtered = 2131099760;
    
    public static final int txt_full_guard = 2131099720;
    
    public static final int txt_go_scan = 2131099728;
    
    public static final int txt_hack_message = 2131099786;
    
    public static final int txt_hack_process = 2131099787;
    
    public static final int txt_img_warn = 2131099693;
    
    public static final int txt_information = 2131099762;
    
    public static final int txt_last_base_av = 2131099759;
    
    public static final int txt_logo_image = 2131099687;
    
    public static final int txt_may_infection = 2131099782;
    
    public static final int txt_ok = 2131099766;
    
    public static final int txt_pause_scan = 2131099729;
    
    public static final int txt_prepare_status_scan = 2131099730;
    
    public static final int txt_results_scan = 2131099753;
    
    public static final int txt_results_version = 2131099754;
    
    public static final int txt_scan_string = 2131099731;
    
    public static final int txt_scanning_warning = 2131099752;
    
    public static final int txt_sms_message = 2131099788;
    
    public static final int txt_sms_process = 2131099791;
    
    public static final int txt_sub_center_home_block = 2131099686;
    
    public static final int txt_succefuly_delete_phone = 2131099764;
    
    public static final int txt_sucefful_activated = 2131099757;
    
    public static final int txt_upd_reklam = 2131099718;
    
    public static final int txt_upd_string = 2131099717;
    
    public static final int txt_update_system = 2131099719;
    
    public static final int version_base = 2131099666;
    
    public static final int virus_not_remove = 2131099723;
    
    public static final int virus_remove = 2131099722;
    
    public static final int warning_msg_f = 2131099673;
    
    public static final int warning_msg_s = 2131099674;
    
    public static final int warning_you_have_virus = 2131099746;
    
    public static final int zero_percent = 2131099665;
  }
  
  public static final class style {
    public static final int AppTheme = 2131165184;
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */