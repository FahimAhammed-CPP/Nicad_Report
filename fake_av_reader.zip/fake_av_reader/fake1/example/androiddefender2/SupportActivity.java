package com.example.androiddefender2;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import system.AppSingleton;

public class SupportActivity extends CustomActGroup {
  public static SupportActivity self;
  
  public Button btnByApp;
  
  public Button btnGoBack;
  
  public Button btnResumeWorking;
  
  public Button butActivateApp;
  
  public CheckBox chkHaveKey;
  
  public EditText edtActivationCode;
  
  public void btnByApp_Click(View paramView) {
    startActivity(new Intent((Context)this, PayFormActivity.class));
  }
  
  public void btnGoBack_Click(View paramView) {
    onBackPressed();
  }
  
  public void btnOk_Click(View paramView) {
    BySupportActivity.self.btnOk_Click(paramView);
  }
  
  public void btnResumeWork_Click(View paramView) {
    BySupportActivity.self.btnResumeWork_Click(paramView);
  }
  
  public void btnResumeWorking_Click(View paramView) {
    Intent intent = new Intent((Context)this, SingleScanActivity.class);
    intent.putExtra("scanApplication", true);
    intent.putExtra("scanSDCard", false);
    startActivity(intent);
  }
  
  public void butActivateApp_Click(View paramView) {
    AlertDialog.Builder builder;
    EditText editText = (EditText)findViewById(2131296273);
    String str = editText.getText().toString();
    if (str.equals("")) {
      Toast.makeText(getApplicationContext(), getResources().getString(2131099748), 0).show();
      return;
    } 
    if ((DefenderApplication.getInstance()).activation_code.equals(str)) {
      DefenderApplication.getInstance();
      SharedPreferences.Editor editor = getSharedPreferences(DefenderApplication.APP_PREF, 0).edit();
      editor.putBoolean("appActivaten", true);
      editor.putBoolean("chkProtectSMS", true);
      editor.putBoolean("chkProtectCallRec", true);
      editor.putBoolean("chkProtectGeoLoc", true);
      editor.commit();
      (AppSingleton.getInstance()).activaten = true;
      builder = new AlertDialog.Builder((Context)getParent());
      builder.setTitle(getResources().getString(2131099778));
      builder.setMessage(getResources().getString(2131099779));
      builder.setPositiveButton(getResources().getString(2131099777), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface param1DialogInterface, int param1Int) {
              switch (param1Int) {
                default:
                  return;
                case -1:
                  break;
              } 
              SupportActivity.this.btnResumeWorking.setVisibility(0);
              SupportActivity.this.butActivateApp.setVisibility(4);
              SupportActivity.this.edtActivationCode.setText("");
              SupportActivity.this.edtActivationCode.setVisibility(4);
              SupportActivity.this.chkHaveKey.setVisibility(4);
              SupportActivity.this.btnGoBack.setEnabled(false);
              SupportActivity.this.btnByApp.setEnabled(false);
              SupportActivity.this.btnGoBack.setVisibility(4);
              SupportActivity.this.btnByApp.setVisibility(4);
            }
          });
      builder.create().show();
      return;
    } 
    Toast.makeText(getApplicationContext(), getResources().getString(2131099749), 0).show();
    builder.setText("");
  }
  
  public void chkHaveKey_Click(View paramView) {
    boolean bool2;
    boolean bool1 = true;
    CheckBox checkBox = (CheckBox)findViewById(2131296342);
    EditText editText = (EditText)findViewById(2131296273);
    Button button2 = (Button)findViewById(2131296343);
    editText.setEnabled(checkBox.isChecked());
    button2.setEnabled(checkBox.isChecked());
    Button button1 = this.btnGoBack;
    if (!checkBox.isChecked()) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    button1.setEnabled(bool2);
    button1 = this.btnByApp;
    if (!checkBox.isChecked()) {
      bool2 = bool1;
    } else {
      bool2 = false;
    } 
    button1.setEnabled(bool2);
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (!(AppSingleton.getInstance()).activaten) {
      setContentView(2130903051);
    } else {
      setContentView(LayoutInflater.from((Context)getParent()).inflate(2130903052, null));
      try {
        WebView webView = (WebView)findViewById(2131296272);
        webView.getSettings().setAppCacheEnabled(false);
        webView.getSettings().setSavePassword(false);
        webView.getSettings().setSaveFormData(false);
        WebViewClient webViewClient = new WebViewClient() {
            public void onLoadResource(WebView param1WebView, String param1String) {}
            
            public boolean shouldOverrideUrlLoading(WebView param1WebView, String param1String) {
              if (param1String.equals(param1String)) {
                param1WebView.loadUrl(param1String);
                return true;
              } 
              return false;
            }
          };
        super(this);
        webView.setWebViewClient(webViewClient);
        webView.loadUrl("http://defenderandroid.org");
      } catch (Exception exception) {
        Toast.makeText(getApplicationContext(), exception.getMessage(), 0).show();
      } 
    } 
    this.btnResumeWorking = (Button)findViewById(2131296344);
    this.butActivateApp = (Button)findViewById(2131296343);
    this.chkHaveKey = (CheckBox)findViewById(2131296342);
    this.edtActivationCode = (EditText)findViewById(2131296273);
    this.btnGoBack = (Button)findViewById(2131296295);
    this.btnByApp = (Button)findViewById(2131296262);
    self = this;
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu) {
    getMenuInflater().inflate(2131230728, paramMenu);
    return true;
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/SupportActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */