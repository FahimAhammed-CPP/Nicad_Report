package com.j256.ormlite.stmt;

import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.field.SqlType;
import java.sql.SQLException;

public abstract class BaseArgumentHolder implements ArgumentHolder {
  private String columnName = null;
  
  private FieldType fieldType = null;
  
  private SqlType sqlType = null;
  
  public BaseArgumentHolder() {}
  
  public BaseArgumentHolder(SqlType paramSqlType) {
    this.sqlType = paramSqlType;
  }
  
  public BaseArgumentHolder(String paramString) {
    this.columnName = paramString;
  }
  
  public String getColumnName() {
    return this.columnName;
  }
  
  public FieldType getFieldType() {
    return this.fieldType;
  }
  
  public Object getSqlArgValue() throws SQLException {
    if (!isValueSet())
      throw new SQLException("Column value has not been set for " + this.columnName); 
    Object object1 = getValue();
    if (object1 == null)
      return null; 
    Object object2 = object1;
    if (this.fieldType != null) {
      if (this.fieldType.isForeign() && this.fieldType.getType() == object1.getClass())
        return this.fieldType.getForeignIdField().extractJavaFieldValue(object1); 
      object2 = this.fieldType.convertJavaFieldToSqlArgValue(object1);
    } 
    return object2;
  }
  
  public SqlType getSqlType() {
    return this.sqlType;
  }
  
  protected abstract Object getValue();
  
  protected abstract boolean isValueSet();
  
  public void setMetaInfo(FieldType paramFieldType) {
    if (this.fieldType != null && this.fieldType != paramFieldType)
      throw new IllegalArgumentException("FieldType name cannot be set twice from " + this.fieldType + " to " + paramFieldType + ".  Using a SelectArg twice in query with different columns?"); 
    this.fieldType = paramFieldType;
  }
  
  public void setMetaInfo(String paramString) {
    if (this.columnName != null && !this.columnName.equals(paramString))
      throw new IllegalArgumentException("Column name cannot be set twice from " + this.columnName + " to " + paramString + ".  Using a SelectArg twice in query with different columns?"); 
    this.columnName = paramString;
  }
  
  public void setMetaInfo(String paramString, FieldType paramFieldType) {
    setMetaInfo(paramString);
    setMetaInfo(paramFieldType);
  }
  
  public abstract void setValue(Object paramObject);
  
  public String toString() {
    Object object;
    if (!isValueSet())
      return "[unset]"; 
    try {
      object = getSqlArgValue();
      if (object == null)
        return "[null]"; 
      object = object.toString();
    } catch (SQLException sQLException) {
      object = "[could not get value: " + sQLException + "]";
    } 
    return (String)object;
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/stmt/BaseArgumentHolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */