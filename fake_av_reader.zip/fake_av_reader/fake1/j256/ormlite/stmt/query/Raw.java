package com.j256.ormlite.stmt.query;

import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.stmt.ArgumentHolder;
import java.util.List;

public class Raw implements Clause {
  private final ArgumentHolder[] args;
  
  private final String statement;
  
  public Raw(String paramString, ArgumentHolder[] paramArrayOfArgumentHolder) {
    this.statement = paramString;
    this.args = paramArrayOfArgumentHolder;
  }
  
  public void appendSql(DatabaseType paramDatabaseType, String paramString, StringBuilder paramStringBuilder, List<ArgumentHolder> paramList) {
    paramStringBuilder.append(this.statement);
    paramStringBuilder.append(' ');
    ArgumentHolder[] arrayOfArgumentHolder = this.args;
    int i = arrayOfArgumentHolder.length;
    for (byte b = 0; b < i; b++)
      paramList.add(arrayOfArgumentHolder[b]); 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/stmt/query/Raw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */