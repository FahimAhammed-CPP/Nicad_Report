package com.j256.ormlite.stmt.mapped;

import com.j256.ormlite.dao.ObjectCache;
import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.misc.SqlExceptionUtil;
import com.j256.ormlite.support.DatabaseConnection;
import com.j256.ormlite.table.TableInfo;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;

public class MappedDeleteCollection<T, ID> extends BaseMappedStatement<T, ID> {
  private MappedDeleteCollection(TableInfo<T, ID> paramTableInfo, String paramString, FieldType[] paramArrayOfFieldType) {
    super(paramTableInfo, paramString, paramArrayOfFieldType);
  }
  
  private static void appendWhereIds(DatabaseType paramDatabaseType, FieldType paramFieldType, StringBuilder paramStringBuilder, int paramInt, FieldType[] paramArrayOfFieldType) {
    paramStringBuilder.append("WHERE ");
    paramDatabaseType.appendEscapedEntityName(paramStringBuilder, paramFieldType.getColumnName());
    paramStringBuilder.append(" IN (");
    boolean bool = true;
    for (byte b = 0; b < paramInt; b++) {
      if (bool) {
        bool = false;
      } else {
        paramStringBuilder.append(',');
      } 
      paramStringBuilder.append('?');
      if (paramArrayOfFieldType != null)
        paramArrayOfFieldType[b] = paramFieldType; 
    } 
    paramStringBuilder.append(") ");
  }
  
  private static <T, ID> MappedDeleteCollection<T, ID> build(DatabaseType paramDatabaseType, TableInfo<T, ID> paramTableInfo, int paramInt) throws SQLException {
    FieldType fieldType = paramTableInfo.getIdField();
    if (fieldType == null)
      throw new SQLException("Cannot delete " + paramTableInfo.getDataClass() + " because it doesn't have an id field defined"); 
    StringBuilder stringBuilder = new StringBuilder(128);
    appendTableName(paramDatabaseType, stringBuilder, "DELETE FROM ", paramTableInfo.getTableName());
    FieldType[] arrayOfFieldType = new FieldType[paramInt];
    appendWhereIds(paramDatabaseType, fieldType, stringBuilder, paramInt, arrayOfFieldType);
    return new MappedDeleteCollection<T, ID>(paramTableInfo, stringBuilder.toString(), arrayOfFieldType);
  }
  
  public static <T, ID> int deleteIds(DatabaseType paramDatabaseType, TableInfo<T, ID> paramTableInfo, DatabaseConnection paramDatabaseConnection, Collection<ID> paramCollection, ObjectCache paramObjectCache) throws SQLException {
    MappedDeleteCollection<T, ID> mappedDeleteCollection = build(paramDatabaseType, paramTableInfo, paramCollection.size());
    Object[] arrayOfObject = new Object[paramCollection.size()];
    FieldType fieldType = paramTableInfo.getIdField();
    byte b = 0;
    Iterator<ID> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      arrayOfObject[b] = fieldType.convertJavaFieldToSqlArgValue(iterator.next());
      b++;
    } 
    return updateRows(paramDatabaseConnection, paramTableInfo.getDataClass(), mappedDeleteCollection, arrayOfObject, paramObjectCache);
  }
  
  public static <T, ID> int deleteObjects(DatabaseType paramDatabaseType, TableInfo<T, ID> paramTableInfo, DatabaseConnection paramDatabaseConnection, Collection<T> paramCollection, ObjectCache paramObjectCache) throws SQLException {
    MappedDeleteCollection<T, ID> mappedDeleteCollection = build(paramDatabaseType, paramTableInfo, paramCollection.size());
    Object[] arrayOfObject = new Object[paramCollection.size()];
    FieldType fieldType = paramTableInfo.getIdField();
    byte b = 0;
    Iterator<T> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      arrayOfObject[b] = fieldType.extractJavaFieldToSqlArgValue(iterator.next());
      b++;
    } 
    return updateRows(paramDatabaseConnection, paramTableInfo.getDataClass(), mappedDeleteCollection, arrayOfObject, paramObjectCache);
  }
  
  private static <T, ID> int updateRows(DatabaseConnection paramDatabaseConnection, Class<T> paramClass, MappedDeleteCollection<T, ID> paramMappedDeleteCollection, Object[] paramArrayOfObject, ObjectCache paramObjectCache) throws SQLException {
    try {
      int i = paramDatabaseConnection.delete(paramMappedDeleteCollection.statement, paramArrayOfObject, paramMappedDeleteCollection.argFieldTypes);
      if (i > 0 && paramObjectCache != null) {
        int j = paramArrayOfObject.length;
        for (byte b = 0; b < j; b++)
          paramObjectCache.remove(paramClass, paramArrayOfObject[b]); 
      } 
      logger.debug("delete-collection with statement '{}' and {} args, changed {} rows", paramMappedDeleteCollection.statement, Integer.valueOf(paramArrayOfObject.length), Integer.valueOf(i));
      if (paramArrayOfObject.length > 0)
        logger.trace("delete-collection arguments: {}", paramArrayOfObject); 
      return i;
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("Unable to run delete collection stmt: " + paramMappedDeleteCollection.statement, sQLException);
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/stmt/mapped/MappedDeleteCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */