package com.j256.ormlite.stmt.mapped;

import com.j256.ormlite.dao.ObjectCache;
import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.support.DatabaseConnection;
import com.j256.ormlite.table.TableInfo;
import java.sql.SQLException;

public class MappedRefresh<T, ID> extends MappedQueryForId<T, ID> {
  private MappedRefresh(TableInfo<T, ID> paramTableInfo, String paramString, FieldType[] paramArrayOfFieldType1, FieldType[] paramArrayOfFieldType2) {
    super(paramTableInfo, paramString, paramArrayOfFieldType1, paramArrayOfFieldType2, "refresh");
  }
  
  public static <T, ID> MappedRefresh<T, ID> build(DatabaseType paramDatabaseType, TableInfo<T, ID> paramTableInfo) throws SQLException {
    FieldType fieldType2 = paramTableInfo.getIdField();
    if (fieldType2 == null)
      throw new SQLException("Cannot refresh " + paramTableInfo.getDataClass() + " because it doesn't have an id field"); 
    String str = buildStatement(paramDatabaseType, paramTableInfo, fieldType2);
    FieldType fieldType1 = paramTableInfo.getIdField();
    FieldType[] arrayOfFieldType = paramTableInfo.getFieldTypes();
    return new MappedRefresh<T, ID>(paramTableInfo, str, new FieldType[] { fieldType1 }, arrayOfFieldType);
  }
  
  public int executeRefresh(DatabaseConnection paramDatabaseConnection, T paramT, ObjectCache paramObjectCache) throws SQLException {
    byte b = 0;
    paramDatabaseConnection = (DatabaseConnection)execute(paramDatabaseConnection, (ID)this.idField.extractJavaFieldValue(paramT), (ObjectCache)null);
    if (paramDatabaseConnection != null) {
      for (FieldType fieldType : this.resultsFieldTypes) {
        if (fieldType != this.idField)
          fieldType.assignField(paramT, fieldType.extractJavaFieldValue(paramDatabaseConnection), false, paramObjectCache); 
      } 
      b = 1;
    } 
    return b;
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/stmt/mapped/MappedRefresh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */