package com.j256.ormlite.stmt.mapped;

import com.j256.ormlite.dao.ObjectCache;
import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.logger.Log;
import com.j256.ormlite.misc.SqlExceptionUtil;
import com.j256.ormlite.support.DatabaseConnection;
import com.j256.ormlite.support.GeneratedKeyHolder;
import com.j256.ormlite.table.TableInfo;
import java.sql.SQLException;

public class MappedCreate<T, ID> extends BaseMappedStatement<T, ID> {
  private String dataClassName;
  
  private final String queryNextSequenceStmt;
  
  private int versionFieldTypeIndex;
  
  private MappedCreate(TableInfo<T, ID> paramTableInfo, String paramString1, FieldType[] paramArrayOfFieldType, String paramString2, int paramInt) {
    super(paramTableInfo, paramString1, paramArrayOfFieldType);
    this.dataClassName = paramTableInfo.getDataClass().getSimpleName();
    this.queryNextSequenceStmt = paramString2;
    this.versionFieldTypeIndex = paramInt;
  }
  
  private void assignIdValue(T paramT, Number paramNumber, String paramString, ObjectCache paramObjectCache) throws SQLException {
    this.idField.assignIdValue(paramT, paramNumber, paramObjectCache);
    if (logger.isLevelEnabled(Log.Level.DEBUG))
      logger.debug("assigned id '{}' from {} to '{}' in {} object", new Object[] { paramNumber, paramString, this.idField.getFieldName(), this.dataClassName }); 
  }
  
  private void assignSequenceId(DatabaseConnection paramDatabaseConnection, T paramT, ObjectCache paramObjectCache) throws SQLException {
    long l = paramDatabaseConnection.queryForLong(this.queryNextSequenceStmt);
    logger.debug("queried for sequence {} using stmt: {}", Long.valueOf(l), this.queryNextSequenceStmt);
    if (l == 0L)
      throw new SQLException("Should not have returned 0 for stmt: " + this.queryNextSequenceStmt); 
    assignIdValue(paramT, Long.valueOf(l), "sequence", paramObjectCache);
  }
  
  public static <T, ID> MappedCreate<T, ID> build(DatabaseType paramDatabaseType, TableInfo<T, ID> paramTableInfo) {
    StringBuilder stringBuilder = new StringBuilder(128);
    appendTableName(paramDatabaseType, stringBuilder, "INSERT INTO ", paramTableInfo.getTableName());
    stringBuilder.append('(');
    int i = 0;
    int j = -1;
    FieldType[] arrayOfFieldType1 = paramTableInfo.getFieldTypes();
    int k = arrayOfFieldType1.length;
    byte b = 0;
    while (b < k) {
      FieldType fieldType = arrayOfFieldType1[b];
      int n = j;
      int i1 = i;
      if (isFieldCreatable(paramDatabaseType, fieldType)) {
        if (fieldType.isVersion())
          j = i; 
        i1 = i + 1;
        n = j;
      } 
      b++;
      j = n;
      i = i1;
    } 
    arrayOfFieldType1 = new FieldType[i];
    b = 1;
    FieldType[] arrayOfFieldType2 = paramTableInfo.getFieldTypes();
    k = arrayOfFieldType2.length;
    int m = 0;
    i = 0;
    while (m < k) {
      FieldType fieldType = arrayOfFieldType2[m];
      if (isFieldCreatable(paramDatabaseType, fieldType)) {
        if (b != 0) {
          b = 0;
        } else {
          stringBuilder.append(",");
        } 
        appendFieldColumnName(paramDatabaseType, stringBuilder, fieldType, null);
        int n = i + 1;
        arrayOfFieldType1[i] = fieldType;
        i = n;
      } 
      m++;
    } 
    stringBuilder.append(") VALUES (");
    i = 1;
    arrayOfFieldType2 = paramTableInfo.getFieldTypes();
    m = arrayOfFieldType2.length;
    for (b = 0; b < m; b++) {
      if (isFieldCreatable(paramDatabaseType, arrayOfFieldType2[b])) {
        if (i != 0) {
          i = 0;
        } else {
          stringBuilder.append(",");
        } 
        stringBuilder.append("?");
      } 
    } 
    stringBuilder.append(")");
    String str = buildQueryNextSequence(paramDatabaseType, paramTableInfo.getIdField());
    return new MappedCreate<T, ID>(paramTableInfo, stringBuilder.toString(), arrayOfFieldType1, str, j);
  }
  
  private static String buildQueryNextSequence(DatabaseType paramDatabaseType, FieldType paramFieldType) {
    String str1;
    FieldType fieldType = null;
    if (paramFieldType == null)
      return (String)fieldType; 
    String str2 = paramFieldType.getGeneratedIdSequence();
    paramFieldType = fieldType;
    if (str2 != null) {
      StringBuilder stringBuilder = new StringBuilder(64);
      paramDatabaseType.appendSelectNextValFromSequence(stringBuilder, str2);
      str1 = stringBuilder.toString();
    } 
    return str1;
  }
  
  private boolean foreignCollectionsAreAssigned(FieldType[] paramArrayOfFieldType, Object paramObject) throws SQLException {
    // Byte code:
    //   0: aload_1
    //   1: arraylength
    //   2: istore_3
    //   3: iconst_0
    //   4: istore #4
    //   6: iload #4
    //   8: iload_3
    //   9: if_icmpge -> 35
    //   12: aload_1
    //   13: iload #4
    //   15: aaload
    //   16: aload_2
    //   17: invokevirtual extractJavaFieldValue : (Ljava/lang/Object;)Ljava/lang/Object;
    //   20: ifnonnull -> 29
    //   23: iconst_0
    //   24: istore #5
    //   26: iload #5
    //   28: ireturn
    //   29: iinc #4, 1
    //   32: goto -> 6
    //   35: iconst_1
    //   36: istore #5
    //   38: goto -> 26
  }
  
  private static boolean isFieldCreatable(DatabaseType paramDatabaseType, FieldType paramFieldType) {
    boolean bool = false;
    if (paramFieldType.isForeignCollection())
      return bool; 
    null = bool;
    if (!paramFieldType.isReadOnly()) {
      if (paramDatabaseType.isIdSequenceNeeded() && paramDatabaseType.isSelectSequenceBeforeInsert())
        return true; 
      if (paramFieldType.isGeneratedId() && !paramFieldType.isSelfGeneratedId()) {
        null = bool;
        return paramFieldType.isAllowGeneratedIdInsert() ? true : null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  public int insert(DatabaseType paramDatabaseType, DatabaseConnection paramDatabaseConnection, T paramT, ObjectCache paramObjectCache) throws SQLException {
    int i;
    KeyHolder keyHolder1 = null;
    KeyHolder keyHolder2 = keyHolder1;
    if (this.idField != null) {
      if (this.idField.isAllowGeneratedIdInsert() && !this.idField.isObjectsFieldValueDefault(paramT)) {
        i = 0;
      } else {
        i = 1;
      } 
      if (this.idField.isSelfGeneratedId() && this.idField.isGeneratedId()) {
        keyHolder2 = keyHolder1;
        if (i) {
          this.idField.assignField(paramT, this.idField.generateId(), false, paramObjectCache);
          keyHolder2 = keyHolder1;
        } 
      } else if (this.idField.isGeneratedIdSequence() && paramDatabaseType.isSelectSequenceBeforeInsert()) {
        keyHolder2 = keyHolder1;
        if (i) {
          assignSequenceId(paramDatabaseConnection, paramT, paramObjectCache);
          keyHolder2 = keyHolder1;
        } 
      } else {
        keyHolder2 = keyHolder1;
        if (this.idField.isGeneratedId()) {
          keyHolder2 = keyHolder1;
          if (i)
            keyHolder2 = new KeyHolder(); 
        } 
      } 
    } 
    try {
      if (this.tableInfo.isForeignAutoCreate())
        for (FieldType fieldType : this.tableInfo.getFieldTypes()) {
          boolean bool = fieldType.isForeignAutoCreate();
          if (bool) {
            Object object1 = fieldType.extractRawJavaFieldValue(paramT);
            if (object1 != null && fieldType.getForeignIdField().isObjectsFieldValueDefault(object1))
              fieldType.createWithForeignDao(object1); 
          } 
        }  
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("Unable to run insert stmt on object " + paramT + ": " + this.statement, sQLException);
    } 
    Object[] arrayOfObject = getFieldObjects(paramT);
    keyHolder1 = null;
    Object object = keyHolder1;
    if (this.versionFieldTypeIndex >= 0) {
      object = keyHolder1;
      if (arrayOfObject[this.versionFieldTypeIndex] == null) {
        FieldType fieldType = this.argFieldTypes[this.versionFieldTypeIndex];
        object = fieldType.moveToNextValue(null);
        arrayOfObject[this.versionFieldTypeIndex] = fieldType.convertJavaFieldToSqlArgValue(object);
      } 
    } 
    try {
      i = paramDatabaseConnection.insert(this.statement, arrayOfObject, this.argFieldTypes, keyHolder2);
      logger.debug("insert data with statement '{}' and {} args, changed {} rows", this.statement, Integer.valueOf(arrayOfObject.length), Integer.valueOf(i));
      if (arrayOfObject.length > 0)
        logger.trace("insert arguments: {}", arrayOfObject); 
      if (i > 0) {
        if (object != null)
          this.argFieldTypes[this.versionFieldTypeIndex].assignField(paramT, object, false, null); 
        if (keyHolder2 != null) {
          object = keyHolder2.getKey();
          if (object == null) {
            object = new SQLException();
            super("generated-id key was not set by the update call");
            throw object;
          } 
          if (object.longValue() == 0L) {
            object = new SQLException();
            super("generated-id key must not be 0 value");
            throw object;
          } 
          assignIdValue(paramT, (Number)object, "keyholder", paramObjectCache);
        } 
        if (paramObjectCache != null && foreignCollectionsAreAssigned(this.tableInfo.getForeignCollections(), paramT)) {
          object = this.idField.extractJavaFieldValue(paramT);
          paramObjectCache.put(this.clazz, object, paramT);
        } 
      } 
    } catch (SQLException sQLException) {
      logger.debug("insert data with statement '{}' and {} args, threw exception: {}", this.statement, Integer.valueOf(arrayOfObject.length), sQLException);
      if (arrayOfObject.length > 0)
        logger.trace("insert arguments: {}", arrayOfObject); 
      throw sQLException;
    } 
    return i;
  }
  
  private static class KeyHolder implements GeneratedKeyHolder {
    Number key;
    
    private KeyHolder() {}
    
    public void addKey(Number param1Number) throws SQLException {
      if (this.key == null) {
        this.key = param1Number;
        return;
      } 
      throw new SQLException("generated key has already been set to " + this.key + ", now set to " + param1Number);
    }
    
    public Number getKey() {
      return this.key;
    }
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/stmt/mapped/MappedCreate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */