package com.j256.ormlite.stmt.mapped;

import com.j256.ormlite.dao.ObjectCache;
import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.misc.SqlExceptionUtil;
import com.j256.ormlite.support.DatabaseConnection;
import com.j256.ormlite.table.TableInfo;
import java.sql.SQLException;

public class MappedUpdateId<T, ID> extends BaseMappedStatement<T, ID> {
  private MappedUpdateId(TableInfo<T, ID> paramTableInfo, String paramString, FieldType[] paramArrayOfFieldType) {
    super(paramTableInfo, paramString, paramArrayOfFieldType);
  }
  
  public static <T, ID> MappedUpdateId<T, ID> build(DatabaseType paramDatabaseType, TableInfo<T, ID> paramTableInfo) throws SQLException {
    FieldType fieldType = paramTableInfo.getIdField();
    if (fieldType == null)
      throw new SQLException("Cannot update-id in " + paramTableInfo.getDataClass() + " because it doesn't have an id field"); 
    StringBuilder stringBuilder = new StringBuilder(64);
    appendTableName(paramDatabaseType, stringBuilder, "UPDATE ", paramTableInfo.getTableName());
    stringBuilder.append("SET ");
    appendFieldColumnName(paramDatabaseType, stringBuilder, fieldType, null);
    stringBuilder.append("= ? ");
    appendWhereFieldEq(paramDatabaseType, fieldType, stringBuilder, null);
    return new MappedUpdateId<T, ID>(paramTableInfo, stringBuilder.toString(), new FieldType[] { fieldType, fieldType });
  }
  
  private Object extractIdToFieldObject(T paramT) throws SQLException {
    return this.idField.extractJavaFieldToSqlArgValue(paramT);
  }
  
  public int execute(DatabaseConnection paramDatabaseConnection, T paramT, ID paramID, ObjectCache paramObjectCache) throws SQLException {
    try {
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = convertIdToFieldObject(paramID);
      arrayOfObject[1] = extractIdToFieldObject(paramT);
      int i = paramDatabaseConnection.update(this.statement, arrayOfObject, this.argFieldTypes);
      if (i > 0) {
        if (paramObjectCache != null) {
          Object object = this.idField.extractJavaFieldValue(paramT);
          object = paramObjectCache.updateId(this.clazz, object, paramID);
          if (object != null && object != paramT)
            this.idField.assignField(object, paramID, false, paramObjectCache); 
        } 
        this.idField.assignField(paramT, paramID, false, paramObjectCache);
      } 
      logger.debug("updating-id with statement '{}' and {} args, changed {} rows", this.statement, Integer.valueOf(arrayOfObject.length), Integer.valueOf(i));
      if (arrayOfObject.length > 0)
        logger.trace("updating-id arguments: {}", arrayOfObject); 
      return i;
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("Unable to run update-id stmt on object " + paramT + ": " + this.statement, sQLException);
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/stmt/mapped/MappedUpdateId.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */