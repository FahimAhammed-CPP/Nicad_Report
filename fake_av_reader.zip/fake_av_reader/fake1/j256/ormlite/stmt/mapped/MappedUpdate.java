package com.j256.ormlite.stmt.mapped;

import com.j256.ormlite.dao.ObjectCache;
import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.misc.SqlExceptionUtil;
import com.j256.ormlite.support.DatabaseConnection;
import com.j256.ormlite.table.TableInfo;
import java.sql.SQLException;

public class MappedUpdate<T, ID> extends BaseMappedStatement<T, ID> {
  private final FieldType versionFieldType;
  
  private final int versionFieldTypeIndex;
  
  private MappedUpdate(TableInfo<T, ID> paramTableInfo, String paramString, FieldType[] paramArrayOfFieldType, FieldType paramFieldType, int paramInt) {
    super(paramTableInfo, paramString, paramArrayOfFieldType);
    this.versionFieldType = paramFieldType;
    this.versionFieldTypeIndex = paramInt;
  }
  
  public static <T, ID> MappedUpdate<T, ID> build(DatabaseType paramDatabaseType, TableInfo<T, ID> paramTableInfo) throws SQLException {
    FieldType fieldType1 = paramTableInfo.getIdField();
    if (fieldType1 == null)
      throw new SQLException("Cannot update " + paramTableInfo.getDataClass() + " because it doesn't have an id field"); 
    StringBuilder stringBuilder = new StringBuilder(64);
    appendTableName(paramDatabaseType, stringBuilder, "UPDATE ", paramTableInfo.getTableName());
    boolean bool = true;
    int i = 0;
    FieldType fieldType2 = null;
    int j = -1;
    FieldType[] arrayOfFieldType1 = paramTableInfo.getFieldTypes();
    int k = arrayOfFieldType1.length;
    int m = 0;
    while (m < k) {
      FieldType fieldType3 = arrayOfFieldType1[m];
      FieldType fieldType4 = fieldType2;
      int n = j;
      int i1 = i;
      if (isFieldUpdatable(fieldType3, fieldType1)) {
        if (fieldType3.isVersion()) {
          fieldType2 = fieldType3;
          j = i;
        } 
        i1 = i + 1;
        n = j;
        fieldType4 = fieldType2;
      } 
      m++;
      fieldType2 = fieldType4;
      j = n;
      i = i1;
    } 
    m = i + 1;
    i = m;
    if (fieldType2 != null)
      i = m + 1; 
    arrayOfFieldType1 = new FieldType[i];
    FieldType[] arrayOfFieldType2 = paramTableInfo.getFieldTypes();
    k = arrayOfFieldType2.length;
    byte b = 0;
    i = 0;
    m = bool;
    while (b < k) {
      FieldType fieldType = arrayOfFieldType2[b];
      if (isFieldUpdatable(fieldType, fieldType1)) {
        if (m != 0) {
          stringBuilder.append("SET ");
          m = 0;
        } else {
          stringBuilder.append(", ");
        } 
        appendFieldColumnName(paramDatabaseType, stringBuilder, fieldType, null);
        int n = i + 1;
        arrayOfFieldType1[i] = fieldType;
        stringBuilder.append("= ?");
        i = n;
      } 
      b++;
    } 
    stringBuilder.append(' ');
    appendWhereFieldEq(paramDatabaseType, fieldType1, stringBuilder, null);
    m = i + 1;
    arrayOfFieldType1[i] = fieldType1;
    if (fieldType2 != null) {
      stringBuilder.append(" AND ");
      appendFieldColumnName(paramDatabaseType, stringBuilder, fieldType2, null);
      stringBuilder.append("= ?");
      arrayOfFieldType1[m] = fieldType2;
    } 
    return new MappedUpdate<T, ID>(paramTableInfo, stringBuilder.toString(), arrayOfFieldType1, fieldType2, j);
  }
  
  private static boolean isFieldUpdatable(FieldType paramFieldType1, FieldType paramFieldType2) {
    return !(paramFieldType1 == paramFieldType2 || (paramFieldType1.isForeignCollection() | paramFieldType1.isReadOnly()) != 0);
  }
  
  public int update(DatabaseConnection paramDatabaseConnection, T paramT, ObjectCache paramObjectCache) throws SQLException {
    try {
      if (this.argFieldTypes.length <= 1)
        return 0; 
      Object[] arrayOfObject = getFieldObjects(paramT);
      Object object = null;
      if (this.versionFieldType != null) {
        object = this.versionFieldType.extractJavaFieldValue(paramT);
        object = this.versionFieldType.moveToNextValue(object);
        arrayOfObject[this.versionFieldTypeIndex] = this.versionFieldType.convertJavaFieldToSqlArgValue(object);
      } 
      int j = paramDatabaseConnection.update(this.statement, arrayOfObject, this.argFieldTypes);
      if (j > 0) {
        if (object != null)
          this.versionFieldType.assignField(paramT, object, false, null); 
        if (paramObjectCache != null) {
          fieldType = (FieldType)this.idField.extractJavaFieldValue(paramT);
          Object object1 = paramObjectCache.get(this.clazz, fieldType);
          if (object1 != null && object1 != paramT)
            for (FieldType fieldType : this.tableInfo.getFieldTypes()) {
              if (fieldType != this.idField)
                fieldType.assignField(object1, fieldType.extractJavaFieldValue(paramT), false, paramObjectCache); 
            }  
        } 
      } 
      logger.debug("update data with statement '{}' and {} args, changed {} rows", this.statement, Integer.valueOf(arrayOfObject.length), Integer.valueOf(j));
      int i = j;
      if (arrayOfObject.length > 0) {
        logger.trace("update arguments: {}", arrayOfObject);
        i = j;
      } 
      return i;
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("Unable to run update stmt on object " + paramT + ": " + this.statement, sQLException);
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/stmt/mapped/MappedUpdate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */