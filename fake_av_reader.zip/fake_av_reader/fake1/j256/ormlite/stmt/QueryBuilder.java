package com.j256.ormlite.stmt;

import com.j256.ormlite.dao.CloseableIterator;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.GenericRawResults;
import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.stmt.query.OrderBy;
import com.j256.ormlite.table.TableInfo;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class QueryBuilder<T, ID> extends StatementBuilder<T, ID> {
  private boolean distinct;
  
  private List<String> groupByList;
  
  private String groupByRaw;
  
  private String having;
  
  private final FieldType idField;
  
  private boolean isCountOfQuery;
  
  private boolean isInnerQuery;
  
  private List<JoinInfo> joinList;
  
  private Long limit;
  
  private Long offset;
  
  private ArgumentHolder[] orderByArgs;
  
  private List<OrderBy> orderByList;
  
  private String orderByRaw;
  
  private FieldType[] resultFieldTypes;
  
  private List<String> selectColumnList;
  
  private boolean selectIdColumn = true;
  
  private List<String> selectRawList;
  
  public QueryBuilder(DatabaseType paramDatabaseType, TableInfo<T, ID> paramTableInfo, Dao<T, ID> paramDao) {
    super(paramDatabaseType, paramTableInfo, paramDao, StatementBuilder.StatementType.SELECT);
    this.idField = paramTableInfo.getIdField();
  }
  
  private void addJoinInfo(String paramString, QueryBuilder<?, ?> paramQueryBuilder) throws SQLException {
    JoinInfo joinInfo = new JoinInfo(paramString, paramQueryBuilder);
    matchJoinedFields(joinInfo, paramQueryBuilder);
    if (this.joinList == null)
      this.joinList = new ArrayList<JoinInfo>(); 
    this.joinList.add(joinInfo);
  }
  
  private void addSelectColumnToList(String paramString) {
    verifyColumnName(paramString);
    this.selectColumnList.add(paramString);
  }
  
  private void appendColumnName(StringBuilder paramStringBuilder, String paramString) {
    if (this.addTableName) {
      this.databaseType.appendEscapedEntityName(paramStringBuilder, this.tableName);
      paramStringBuilder.append('.');
    } 
    this.databaseType.appendEscapedEntityName(paramStringBuilder, paramString);
  }
  
  private void appendColumns(StringBuilder paramStringBuilder) {
    boolean bool2;
    if (this.selectColumnList == null) {
      if (this.addTableName) {
        this.databaseType.appendEscapedEntityName(paramStringBuilder, this.tableName);
        paramStringBuilder.append('.');
      } 
      paramStringBuilder.append("* ");
      this.resultFieldTypes = this.tableInfo.getFieldTypes();
      return;
    } 
    boolean bool1 = true;
    if (this.isInnerQuery) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    ArrayList<FieldType> arrayList = new ArrayList(this.selectColumnList.size() + 1);
    for (String str : this.selectColumnList) {
      boolean bool;
      FieldType fieldType = this.tableInfo.getFieldTypeByColumnName(str);
      if (fieldType.isForeignCollection()) {
        arrayList.add(fieldType);
        continue;
      } 
      if (bool1) {
        bool = false;
      } else {
        paramStringBuilder.append(',');
        bool = bool1;
      } 
      appendFieldColumnName(paramStringBuilder, fieldType, arrayList);
      bool1 = bool;
      if (fieldType == this.idField) {
        bool2 = true;
        bool1 = bool;
      } 
    } 
    if (!bool2 && this.selectIdColumn) {
      if (!bool1)
        paramStringBuilder.append(','); 
      appendFieldColumnName(paramStringBuilder, this.idField, arrayList);
    } 
    paramStringBuilder.append(' ');
    this.resultFieldTypes = arrayList.<FieldType>toArray(new FieldType[arrayList.size()]);
  }
  
  private void appendFieldColumnName(StringBuilder paramStringBuilder, FieldType paramFieldType, List<FieldType> paramList) {
    appendColumnName(paramStringBuilder, paramFieldType.getColumnName());
    if (paramList != null)
      paramList.add(paramFieldType); 
  }
  
  private void appendGroupBys(StringBuilder paramStringBuilder) {
    boolean bool = true;
    if (hasGroupStuff()) {
      appendGroupBys(paramStringBuilder, true);
      bool = false;
    } 
    if (this.joinList != null)
      for (JoinInfo joinInfo : this.joinList) {
        if (joinInfo.queryBuilder != null && joinInfo.queryBuilder.hasGroupStuff())
          joinInfo.queryBuilder.appendGroupBys(paramStringBuilder, bool); 
      }  
  }
  
  private void appendGroupBys(StringBuilder paramStringBuilder, boolean paramBoolean) {
    if (paramBoolean)
      paramStringBuilder.append("GROUP BY "); 
    if (this.groupByRaw != null) {
      if (!paramBoolean)
        paramStringBuilder.append(','); 
      paramStringBuilder.append(this.groupByRaw);
    } else {
      Iterator<String> iterator = this.groupByList.iterator();
      while (true) {
        if (iterator.hasNext()) {
          String str = iterator.next();
          if (paramBoolean) {
            paramBoolean = false;
          } else {
            paramStringBuilder.append(',');
          } 
          appendColumnName(paramStringBuilder, str);
          continue;
        } 
        paramStringBuilder.append(' ');
        return;
      } 
    } 
    paramStringBuilder.append(' ');
  }
  
  private void appendHaving(StringBuilder paramStringBuilder) {
    if (this.having != null)
      paramStringBuilder.append("HAVING ").append(this.having).append(' '); 
  }
  
  private void appendJoinSql(StringBuilder paramStringBuilder) {
    for (JoinInfo joinInfo : this.joinList) {
      paramStringBuilder.append(joinInfo.type).append(" JOIN ");
      this.databaseType.appendEscapedEntityName(paramStringBuilder, joinInfo.queryBuilder.tableName);
      paramStringBuilder.append(" ON ");
      this.databaseType.appendEscapedEntityName(paramStringBuilder, this.tableName);
      paramStringBuilder.append('.');
      this.databaseType.appendEscapedEntityName(paramStringBuilder, joinInfo.localField.getColumnName());
      paramStringBuilder.append(" = ");
      this.databaseType.appendEscapedEntityName(paramStringBuilder, joinInfo.queryBuilder.tableName);
      paramStringBuilder.append('.');
      this.databaseType.appendEscapedEntityName(paramStringBuilder, joinInfo.remoteField.getColumnName());
      paramStringBuilder.append(' ');
      if (joinInfo.queryBuilder.joinList != null)
        joinInfo.queryBuilder.appendJoinSql(paramStringBuilder); 
    } 
  }
  
  private void appendLimit(StringBuilder paramStringBuilder) {
    if (this.limit != null && this.databaseType.isLimitSqlSupported())
      this.databaseType.appendLimitValue(paramStringBuilder, this.limit.longValue(), this.offset); 
  }
  
  private void appendOffset(StringBuilder paramStringBuilder) throws SQLException {
    if (this.offset != null) {
      if (this.databaseType.isOffsetLimitArgument()) {
        if (this.limit == null)
          throw new SQLException("If the offset is specified, limit must also be specified with this database"); 
        return;
      } 
      this.databaseType.appendOffsetValue(paramStringBuilder, this.offset.longValue());
    } 
  }
  
  private void appendOrderBys(StringBuilder paramStringBuilder, List<ArgumentHolder> paramList) {
    boolean bool = true;
    if (hasOrderStuff()) {
      appendOrderBys(paramStringBuilder, true, paramList);
      bool = false;
    } 
    if (this.joinList != null)
      for (JoinInfo joinInfo : this.joinList) {
        if (joinInfo.queryBuilder != null && joinInfo.queryBuilder.hasOrderStuff())
          joinInfo.queryBuilder.appendOrderBys(paramStringBuilder, bool, paramList); 
      }  
  }
  
  private void appendOrderBys(StringBuilder paramStringBuilder, boolean paramBoolean, List<ArgumentHolder> paramList) {
    if (paramBoolean)
      paramStringBuilder.append("ORDER BY "); 
    if (this.orderByRaw != null) {
      if (!paramBoolean)
        paramStringBuilder.append(','); 
      paramStringBuilder.append(this.orderByRaw);
      if (this.orderByArgs != null) {
        ArgumentHolder[] arrayOfArgumentHolder = this.orderByArgs;
        int i = arrayOfArgumentHolder.length;
        for (byte b = 0; b < i; b++)
          paramList.add(arrayOfArgumentHolder[b]); 
      } 
    } else {
      for (OrderBy orderBy : this.orderByList) {
        boolean bool;
        if (paramBoolean) {
          bool = false;
        } else {
          paramStringBuilder.append(',');
          bool = paramBoolean;
        } 
        appendColumnName(paramStringBuilder, orderBy.getColumnName());
        paramBoolean = bool;
        if (!orderBy.isAscending()) {
          paramStringBuilder.append(" DESC");
          paramBoolean = bool;
        } 
      } 
    } 
    paramStringBuilder.append(' ');
  }
  
  private void appendSelectRaw(StringBuilder paramStringBuilder) {
    boolean bool = true;
    for (String str : this.selectRawList) {
      if (bool) {
        bool = false;
      } else {
        paramStringBuilder.append(", ");
      } 
      paramStringBuilder.append(str);
    } 
    paramStringBuilder.append(' ');
  }
  
  private boolean hasGroupStuff() {
    return ((this.groupByList != null && !this.groupByList.isEmpty()) || this.groupByRaw != null);
  }
  
  private boolean hasOrderStuff() {
    return ((this.orderByList != null && !this.orderByList.isEmpty()) || this.orderByRaw != null);
  }
  
  private void matchJoinedFields(JoinInfo paramJoinInfo, QueryBuilder<?, ?> paramQueryBuilder) throws SQLException {
    for (FieldType fieldType1 : this.tableInfo.getFieldTypes()) {
      FieldType fieldType2 = fieldType1.getForeignIdField();
      if (fieldType1.isForeign() && fieldType2.equals(paramQueryBuilder.tableInfo.getIdField())) {
        paramJoinInfo.localField = fieldType1;
        paramJoinInfo.remoteField = fieldType2;
        return;
      } 
    } 
    for (FieldType fieldType : paramQueryBuilder.tableInfo.getFieldTypes()) {
      if (fieldType.isForeign() && fieldType.getForeignIdField().equals(this.idField)) {
        paramJoinInfo.localField = this.idField;
        paramJoinInfo.remoteField = fieldType;
        return;
      } 
    } 
    throw new SQLException("Could not find a foreign " + this.tableInfo.getDataClass() + " field in " + paramQueryBuilder.tableInfo.getDataClass() + " or vice versa");
  }
  
  private void setAddTableName(boolean paramBoolean) {
    this.addTableName = paramBoolean;
    if (this.joinList != null) {
      Iterator<JoinInfo> iterator = this.joinList.iterator();
      while (iterator.hasNext())
        ((JoinInfo)iterator.next()).queryBuilder.setAddTableName(paramBoolean); 
    } 
  }
  
  protected void appendStatementEnd(StringBuilder paramStringBuilder, List<ArgumentHolder> paramList) throws SQLException {
    appendGroupBys(paramStringBuilder);
    appendHaving(paramStringBuilder);
    appendOrderBys(paramStringBuilder, paramList);
    if (!this.databaseType.isLimitAfterSelect())
      appendLimit(paramStringBuilder); 
    appendOffset(paramStringBuilder);
    setAddTableName(false);
  }
  
  protected void appendStatementStart(StringBuilder paramStringBuilder, List<ArgumentHolder> paramList) {
    if (this.joinList == null) {
      setAddTableName(false);
    } else {
      setAddTableName(true);
    } 
    paramStringBuilder.append("SELECT ");
    if (this.databaseType.isLimitAfterSelect())
      appendLimit(paramStringBuilder); 
    if (this.distinct)
      paramStringBuilder.append("DISTINCT "); 
    if (this.isCountOfQuery) {
      this.type = StatementBuilder.StatementType.SELECT_LONG;
      paramStringBuilder.append("COUNT(*) ");
    } else if (this.selectRawList != null && !this.selectRawList.isEmpty()) {
      this.type = StatementBuilder.StatementType.SELECT_RAW;
      appendSelectRaw(paramStringBuilder);
    } else {
      this.type = StatementBuilder.StatementType.SELECT;
      appendColumns(paramStringBuilder);
    } 
    paramStringBuilder.append("FROM ");
    this.databaseType.appendEscapedEntityName(paramStringBuilder, this.tableName);
    paramStringBuilder.append(' ');
    if (this.joinList != null)
      appendJoinSql(paramStringBuilder); 
  }
  
  protected void appendWhereStatement(StringBuilder paramStringBuilder, List<ArgumentHolder> paramList, boolean paramBoolean) throws SQLException {
    boolean bool = paramBoolean;
    if (this.where != null) {
      super.appendWhereStatement(paramStringBuilder, paramList, paramBoolean);
      bool = false;
    } 
    if (this.joinList != null) {
      Iterator<JoinInfo> iterator = this.joinList.iterator();
      while (iterator.hasNext()) {
        ((JoinInfo)iterator.next()).queryBuilder.appendWhereStatement(paramStringBuilder, paramList, bool);
        bool = false;
      } 
    } 
  }
  
  public void clear() {
    super.clear();
    this.distinct = false;
    this.selectIdColumn = true;
    this.selectColumnList = null;
    this.selectRawList = null;
    this.orderByList = null;
    this.orderByRaw = null;
    this.groupByList = null;
    this.groupByRaw = null;
    this.isInnerQuery = false;
    this.isCountOfQuery = false;
    this.having = null;
    this.limit = null;
    this.offset = null;
    if (this.joinList != null) {
      this.joinList.clear();
      this.joinList = null;
    } 
    this.addTableName = false;
  }
  
  public long countOf() throws SQLException {
    setCountOf(true);
    return this.dao.countOf(prepare());
  }
  
  public QueryBuilder<T, ID> distinct() {
    this.distinct = true;
    this.selectIdColumn = false;
    return this;
  }
  
  void enableInnerQuery() {
    this.isInnerQuery = true;
  }
  
  protected FieldType[] getResultFieldTypes() {
    return this.resultFieldTypes;
  }
  
  int getSelectColumnCount() {
    return this.isCountOfQuery ? 1 : ((this.selectRawList != null && !this.selectRawList.isEmpty()) ? this.selectRawList.size() : ((this.selectColumnList == null) ? 0 : this.selectColumnList.size()));
  }
  
  List<String> getSelectColumns() {
    return (List)(this.isCountOfQuery ? Collections.singletonList("COUNT(*)") : ((this.selectRawList != null && !this.selectRawList.isEmpty()) ? this.selectRawList : ((this.selectColumnList == null) ? Collections.emptyList() : this.selectColumnList)));
  }
  
  public QueryBuilder<T, ID> groupBy(String paramString) {
    if (verifyColumnName(paramString).isForeignCollection())
      throw new IllegalArgumentException("Can't groupBy foreign colletion field: " + paramString); 
    if (this.groupByList == null)
      this.groupByList = new ArrayList<String>(); 
    this.groupByList.add(paramString);
    this.selectIdColumn = false;
    return this;
  }
  
  public QueryBuilder<T, ID> groupByRaw(String paramString) {
    this.groupByRaw = paramString;
    return this;
  }
  
  public QueryBuilder<T, ID> having(String paramString) {
    this.having = paramString;
    return this;
  }
  
  public CloseableIterator<T> iterator() throws SQLException {
    return this.dao.iterator(prepare());
  }
  
  public QueryBuilder<T, ID> join(QueryBuilder<?, ?> paramQueryBuilder) throws SQLException {
    addJoinInfo("INNER", paramQueryBuilder);
    return this;
  }
  
  public QueryBuilder<T, ID> leftJoin(QueryBuilder<?, ?> paramQueryBuilder) throws SQLException {
    addJoinInfo("LEFT", paramQueryBuilder);
    return this;
  }
  
  @Deprecated
  public QueryBuilder<T, ID> limit(int paramInt) {
    return limit(Long.valueOf(paramInt));
  }
  
  public QueryBuilder<T, ID> limit(Long paramLong) {
    this.limit = paramLong;
    return this;
  }
  
  @Deprecated
  public QueryBuilder<T, ID> offset(int paramInt) throws SQLException {
    return offset(Long.valueOf(paramInt));
  }
  
  public QueryBuilder<T, ID> offset(Long paramLong) throws SQLException {
    if (this.databaseType.isOffsetSqlSupported()) {
      this.offset = paramLong;
      return this;
    } 
    throw new SQLException("Offset is not supported by this database");
  }
  
  public QueryBuilder<T, ID> orderBy(String paramString, boolean paramBoolean) {
    if (verifyColumnName(paramString).isForeignCollection())
      throw new IllegalArgumentException("Can't orderBy foreign colletion field: " + paramString); 
    if (this.orderByList == null)
      this.orderByList = new ArrayList<OrderBy>(); 
    this.orderByList.add(new OrderBy(paramString, paramBoolean));
    return this;
  }
  
  public QueryBuilder<T, ID> orderByRaw(String paramString) {
    return orderByRaw(paramString, (ArgumentHolder[])null);
  }
  
  public QueryBuilder<T, ID> orderByRaw(String paramString, ArgumentHolder... paramVarArgs) {
    this.orderByRaw = paramString;
    this.orderByArgs = paramVarArgs;
    return this;
  }
  
  public PreparedQuery<T> prepare() throws SQLException {
    return (PreparedQuery)prepareStatement(this.limit);
  }
  
  public List<T> query() throws SQLException {
    return this.dao.query(prepare());
  }
  
  public T queryForFirst() throws SQLException {
    return (T)this.dao.queryForFirst(prepare());
  }
  
  public GenericRawResults<String[]> queryRaw() throws SQLException {
    return this.dao.queryRaw(prepareStatementString(), new String[0]);
  }
  
  public String[] queryRawFirst() throws SQLException {
    return (String[])this.dao.queryRaw(prepareStatementString(), new String[0]).getFirstResult();
  }
  
  public QueryBuilder<T, ID> selectColumns(Iterable<String> paramIterable) {
    if (this.selectColumnList == null)
      this.selectColumnList = new ArrayList<String>(); 
    Iterator<String> iterator = paramIterable.iterator();
    while (iterator.hasNext())
      addSelectColumnToList(iterator.next()); 
    return this;
  }
  
  public QueryBuilder<T, ID> selectColumns(String... paramVarArgs) {
    if (this.selectColumnList == null)
      this.selectColumnList = new ArrayList<String>(); 
    int i = paramVarArgs.length;
    for (byte b = 0; b < i; b++)
      addSelectColumnToList(paramVarArgs[b]); 
    return this;
  }
  
  public QueryBuilder<T, ID> selectRaw(String... paramVarArgs) {
    if (this.selectRawList == null)
      this.selectRawList = new ArrayList<String>(); 
    int i = paramVarArgs.length;
    for (byte b = 0; b < i; b++) {
      String str = paramVarArgs[b];
      this.selectRawList.add(str);
    } 
    return this;
  }
  
  public QueryBuilder<T, ID> setCountOf(boolean paramBoolean) {
    this.isCountOfQuery = paramBoolean;
    return this;
  }
  
  protected boolean shouldPrependTableNameToColumns() {
    return (this.joinList != null);
  }
  
  public static class InternalQueryBuilderWrapper {
    private final QueryBuilder<?, ?> queryBuilder;
    
    InternalQueryBuilderWrapper(QueryBuilder<?, ?> param1QueryBuilder) {
      this.queryBuilder = param1QueryBuilder;
    }
    
    public void appendStatementString(StringBuilder param1StringBuilder, List<ArgumentHolder> param1List) throws SQLException {
      this.queryBuilder.appendStatementString(param1StringBuilder, param1List);
    }
    
    public FieldType[] getResultFieldTypes() {
      return this.queryBuilder.getResultFieldTypes();
    }
  }
  
  private class JoinInfo {
    FieldType localField;
    
    final QueryBuilder<?, ?> queryBuilder;
    
    FieldType remoteField;
    
    final String type;
    
    public JoinInfo(String param1String, QueryBuilder<?, ?> param1QueryBuilder) {
      this.type = param1String;
      this.queryBuilder = param1QueryBuilder;
    }
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/stmt/QueryBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */