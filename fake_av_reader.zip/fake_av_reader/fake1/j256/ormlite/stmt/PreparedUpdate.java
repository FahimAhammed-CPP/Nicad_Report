package com.j256.ormlite.stmt;

public interface PreparedUpdate<T> extends PreparedStmt<T> {}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/stmt/PreparedUpdate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */