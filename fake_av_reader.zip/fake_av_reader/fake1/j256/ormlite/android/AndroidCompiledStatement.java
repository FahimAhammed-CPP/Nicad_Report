package com.j256.ormlite.android;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import com.j256.ormlite.dao.ObjectCache;
import com.j256.ormlite.field.SqlType;
import com.j256.ormlite.logger.Logger;
import com.j256.ormlite.logger.LoggerFactory;
import com.j256.ormlite.misc.SqlExceptionUtil;
import com.j256.ormlite.stmt.StatementBuilder;
import com.j256.ormlite.support.CompiledStatement;
import com.j256.ormlite.support.DatabaseResults;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AndroidCompiledStatement implements CompiledStatement {
  private static final String[] NO_STRING_ARGS;
  
  private static Logger logger = LoggerFactory.getLogger(AndroidCompiledStatement.class);
  
  private List<Object> args;
  
  private Cursor cursor;
  
  private final SQLiteDatabase db;
  
  private Integer max;
  
  private final String sql;
  
  private final StatementBuilder.StatementType type;
  
  static {
    NO_STRING_ARGS = new String[0];
  }
  
  public AndroidCompiledStatement(String paramString, SQLiteDatabase paramSQLiteDatabase, StatementBuilder.StatementType paramStatementType) {
    this.sql = paramString;
    this.db = paramSQLiteDatabase;
    this.type = paramStatementType;
  }
  
  static int execSql(SQLiteDatabase paramSQLiteDatabase, String paramString1, String paramString2, Object[] paramArrayOfObject) throws SQLException {
    SQLiteStatement sQLiteStatement;
    try {
      SQLiteStatement sQLiteStatement1;
      paramSQLiteDatabase.execSQL(paramString2, paramArrayOfObject);
      sQLiteStatement = null;
      paramArrayOfObject = null;
      try {
        SQLiteStatement sQLiteStatement2 = paramSQLiteDatabase.compileStatement("SELECT CHANGES()");
        sQLiteStatement1 = sQLiteStatement2;
        sQLiteStatement = sQLiteStatement2;
        long l = sQLiteStatement2.simpleQueryForLong();
        int i = (int)l;
        int j = i;
        if (sQLiteStatement2 != null) {
          sQLiteStatement2.close();
          j = i;
        } 
        logger.trace("executing statement {} changed {} rows: {}", paramString1, Integer.valueOf(j), paramString2);
        return j;
      } catch (SQLException null) {
        boolean bool1 = true;
        boolean bool2 = bool1;
        if (sQLiteStatement1 != null) {
          sQLiteStatement1.close();
          bool2 = bool1;
        } 
        logger.trace("executing statement {} changed {} rows: {}", paramString1, Integer.valueOf(bool2), paramString2);
        return bool2;
      } finally {}
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("Problems executing " + paramString1 + " Android statement: " + paramString2, sQLException);
    } 
    if (sQLiteStatement != null)
      sQLiteStatement.close(); 
    throw sQLException;
  }
  
  private Object[] getArgArray() {
    return (Object[])((this.args == null) ? NO_STRING_ARGS : this.args.toArray(new Object[this.args.size()]));
  }
  
  private String[] getStringArray() {
    return (this.args == null) ? NO_STRING_ARGS : this.args.<String>toArray(new String[this.args.size()]);
  }
  
  private void isInPrep() throws SQLException {
    if (this.cursor != null)
      throw new SQLException("Query already run. Cannot add argument values."); 
  }
  
  public void close() throws SQLException {
    if (this.cursor != null)
      try {
        this.cursor.close();
        return;
      } catch (SQLException sQLException) {
        throw SqlExceptionUtil.create("Problems closing Android cursor", sQLException);
      }  
  }
  
  public void closeQuietly() {
    try {
      close();
    } catch (SQLException sQLException) {}
  }
  
  public int getColumnCount() throws SQLException {
    return getCursor().getColumnCount();
  }
  
  public String getColumnName(int paramInt) throws SQLException {
    return getCursor().getColumnName(paramInt);
  }
  
  public Cursor getCursor() throws SQLException {
    if (this.cursor == null) {
      String str1 = null;
      String str2 = str1;
      try {
        if (this.max == null) {
          str2 = str1;
          str1 = this.sql;
        } else {
          str2 = str1;
          StringBuilder stringBuilder = new StringBuilder();
          str2 = str1;
          this();
          str2 = str1;
          str1 = stringBuilder.append(this.sql).append(" ").append(this.max).toString();
        } 
        str2 = str1;
        this.cursor = this.db.rawQuery(str1, getStringArray());
        str2 = str1;
        this.cursor.moveToFirst();
        str2 = str1;
        logger.trace("{}: started rawQuery cursor for: {}", this, str1);
        return this.cursor;
      } catch (SQLException sQLException) {
        throw SqlExceptionUtil.create("Problems executing Android query: " + str2, sQLException);
      } 
    } 
    return this.cursor;
  }
  
  public int runExecute() throws SQLException {
    if (!this.type.isOkForExecute())
      throw new IllegalArgumentException("Cannot call execute on a " + this.type + " statement"); 
    return execSql(this.db, "runExecute", this.sql, getArgArray());
  }
  
  public DatabaseResults runQuery(ObjectCache paramObjectCache) throws SQLException {
    if (!this.type.isOkForQuery())
      throw new IllegalArgumentException("Cannot call query on a " + this.type + " statement"); 
    return new AndroidDatabaseResults(getCursor(), paramObjectCache);
  }
  
  public int runUpdate() throws SQLException {
    if (!this.type.isOkForUpdate())
      throw new IllegalArgumentException("Cannot call update on a " + this.type + " statement"); 
    if (this.max == null) {
      String str1 = this.sql;
      return execSql(this.db, "runUpdate", str1, getArgArray());
    } 
    String str = this.sql + " " + this.max;
    return execSql(this.db, "runUpdate", str, getArgArray());
  }
  
  public void setMaxRows(int paramInt) throws SQLException {
    isInPrep();
    this.max = Integer.valueOf(paramInt);
  }
  
  public void setObject(int paramInt, Object paramObject, SqlType paramSqlType) throws SQLException {
    isInPrep();
    if (this.args == null)
      this.args = new ArrayList(); 
    if (paramObject == null) {
      this.args.add(paramInt, null);
      return;
    } 
    switch (paramSqlType) {
      default:
        throw new SQLException("Unknown sql argument type: " + paramSqlType);
      case STRING:
      case LONG_STRING:
      case DATE:
      case BOOLEAN:
      case CHAR:
      case BYTE:
      case SHORT:
      case INTEGER:
      case LONG:
      case FLOAT:
      case DOUBLE:
        this.args.add(paramInt, paramObject.toString());
        return;
      case BYTE_ARRAY:
      case SERIALIZABLE:
        this.args.add(paramInt, paramObject);
        return;
      case BLOB:
      case BIG_DECIMAL:
        break;
    } 
    throw new SQLException("Invalid Android type: " + paramSqlType);
  }
  
  public void setQueryTimeout(long paramLong) {}
  
  public String toString() {
    return getClass().getSimpleName() + "@" + Integer.toHexString(hashCode());
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/android/AndroidCompiledStatement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */