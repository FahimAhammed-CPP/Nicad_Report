package com.j256.ormlite.android;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.db.SqliteAndroidDatabaseType;
import com.j256.ormlite.logger.Logger;
import com.j256.ormlite.logger.LoggerFactory;
import com.j256.ormlite.support.BaseConnectionSource;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.support.DatabaseConnection;
import java.sql.SQLException;

public class AndroidConnectionSource extends BaseConnectionSource implements ConnectionSource {
  private static final Logger logger = LoggerFactory.getLogger(AndroidConnectionSource.class);
  
  private AndroidDatabaseConnection connection = null;
  
  private final DatabaseType databaseType = (DatabaseType)new SqliteAndroidDatabaseType();
  
  private final SQLiteOpenHelper helper = null;
  
  private volatile boolean isOpen = true;
  
  private final SQLiteDatabase sqliteDatabase;
  
  public AndroidConnectionSource(SQLiteDatabase paramSQLiteDatabase) {
    this.sqliteDatabase = paramSQLiteDatabase;
  }
  
  public AndroidConnectionSource(SQLiteOpenHelper paramSQLiteOpenHelper) {
    this.sqliteDatabase = null;
  }
  
  public void clearSpecialConnection(DatabaseConnection paramDatabaseConnection) {
    clearSpecial(paramDatabaseConnection, logger);
  }
  
  public void close() {
    this.isOpen = false;
  }
  
  public void closeQuietly() {
    close();
  }
  
  public DatabaseType getDatabaseType() {
    return this.databaseType;
  }
  
  public DatabaseConnection getReadOnlyConnection() throws SQLException {
    return getReadWriteConnection();
  }
  
  public DatabaseConnection getReadWriteConnection() throws SQLException {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getSavedConnection : ()Lcom/j256/ormlite/support/DatabaseConnection;
    //   4: astore_1
    //   5: aload_1
    //   6: ifnull -> 11
    //   9: aload_1
    //   10: areturn
    //   11: aload_0
    //   12: getfield connection : Lcom/j256/ormlite/android/AndroidDatabaseConnection;
    //   15: ifnonnull -> 112
    //   18: aload_0
    //   19: getfield sqliteDatabase : Landroid/database/sqlite/SQLiteDatabase;
    //   22: ifnonnull -> 104
    //   25: aload_0
    //   26: getfield helper : Landroid/database/sqlite/SQLiteOpenHelper;
    //   29: invokevirtual getWritableDatabase : ()Landroid/database/sqlite/SQLiteDatabase;
    //   32: astore_1
    //   33: aload_0
    //   34: new com/j256/ormlite/android/AndroidDatabaseConnection
    //   37: dup
    //   38: aload_1
    //   39: iconst_1
    //   40: invokespecial <init> : (Landroid/database/sqlite/SQLiteDatabase;Z)V
    //   43: putfield connection : Lcom/j256/ormlite/android/AndroidDatabaseConnection;
    //   46: getstatic com/j256/ormlite/android/AndroidConnectionSource.logger : Lcom/j256/ormlite/logger/Logger;
    //   49: ldc 'created connection {} for db {}, helper {}'
    //   51: aload_0
    //   52: getfield connection : Lcom/j256/ormlite/android/AndroidDatabaseConnection;
    //   55: aload_1
    //   56: aload_0
    //   57: getfield helper : Landroid/database/sqlite/SQLiteOpenHelper;
    //   60: invokevirtual trace : (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   63: aload_0
    //   64: getfield connection : Lcom/j256/ormlite/android/AndroidDatabaseConnection;
    //   67: astore_1
    //   68: goto -> 9
    //   71: astore_1
    //   72: new java/lang/StringBuilder
    //   75: dup
    //   76: invokespecial <init> : ()V
    //   79: ldc 'Getting a writable database from helper '
    //   81: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: aload_0
    //   85: getfield helper : Landroid/database/sqlite/SQLiteOpenHelper;
    //   88: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   91: ldc ' failed'
    //   93: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   96: invokevirtual toString : ()Ljava/lang/String;
    //   99: aload_1
    //   100: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   103: athrow
    //   104: aload_0
    //   105: getfield sqliteDatabase : Landroid/database/sqlite/SQLiteDatabase;
    //   108: astore_1
    //   109: goto -> 33
    //   112: getstatic com/j256/ormlite/android/AndroidConnectionSource.logger : Lcom/j256/ormlite/logger/Logger;
    //   115: ldc '{}: returning read-write connection {}, helper {}'
    //   117: aload_0
    //   118: aload_0
    //   119: getfield connection : Lcom/j256/ormlite/android/AndroidDatabaseConnection;
    //   122: aload_0
    //   123: getfield helper : Landroid/database/sqlite/SQLiteOpenHelper;
    //   126: invokevirtual trace : (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   129: goto -> 63
    // Exception table:
    //   from	to	target	type
    //   25	33	71	android/database/SQLException
  }
  
  public boolean isOpen() {
    return this.isOpen;
  }
  
  public void releaseConnection(DatabaseConnection paramDatabaseConnection) {}
  
  public boolean saveSpecialConnection(DatabaseConnection paramDatabaseConnection) throws SQLException {
    return saveSpecial(paramDatabaseConnection);
  }
  
  public String toString() {
    return getClass().getSimpleName() + "@" + Integer.toHexString(hashCode());
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/android/AndroidConnectionSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */