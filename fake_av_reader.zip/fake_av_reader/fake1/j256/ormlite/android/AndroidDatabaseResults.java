package com.j256.ormlite.android;

import android.database.Cursor;
import com.j256.ormlite.dao.ObjectCache;
import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.db.SqliteAndroidDatabaseType;
import com.j256.ormlite.support.DatabaseResults;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class AndroidDatabaseResults implements DatabaseResults {
  private static final int MIN_NUM_COLUMN_NAMES_MAP = 8;
  
  private static final DatabaseType databaseType = (DatabaseType)new SqliteAndroidDatabaseType();
  
  private final Map<String, Integer> columnNameMap;
  
  private final String[] columnNames;
  
  private final Cursor cursor;
  
  private final ObjectCache objectCache;
  
  public AndroidDatabaseResults(Cursor paramCursor, ObjectCache paramObjectCache) {
    this.cursor = paramCursor;
    this.columnNames = paramCursor.getColumnNames();
    if (this.columnNames.length >= 8) {
      this.columnNameMap = new HashMap<String, Integer>();
      for (byte b = 0; b < this.columnNames.length; b++)
        this.columnNameMap.put(this.columnNames[b], Integer.valueOf(b)); 
    } else {
      this.columnNameMap = null;
    } 
    this.objectCache = paramObjectCache;
  }
  
  @Deprecated
  public AndroidDatabaseResults(Cursor paramCursor, boolean paramBoolean, ObjectCache paramObjectCache) {
    this(paramCursor, paramObjectCache);
  }
  
  private int lookupColumn(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: getfield columnNameMap : Ljava/util/Map;
    //   4: ifnonnull -> 44
    //   7: iconst_0
    //   8: istore_2
    //   9: iload_2
    //   10: aload_0
    //   11: getfield columnNames : [Ljava/lang/String;
    //   14: arraylength
    //   15: if_icmpge -> 39
    //   18: aload_0
    //   19: getfield columnNames : [Ljava/lang/String;
    //   22: iload_2
    //   23: aaload
    //   24: aload_1
    //   25: invokevirtual equals : (Ljava/lang/Object;)Z
    //   28: ifeq -> 33
    //   31: iload_2
    //   32: ireturn
    //   33: iinc #2, 1
    //   36: goto -> 9
    //   39: iconst_m1
    //   40: istore_2
    //   41: goto -> 31
    //   44: aload_0
    //   45: getfield columnNameMap : Ljava/util/Map;
    //   48: aload_1
    //   49: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   54: checkcast java/lang/Integer
    //   57: astore_1
    //   58: aload_1
    //   59: ifnonnull -> 67
    //   62: iconst_m1
    //   63: istore_2
    //   64: goto -> 31
    //   67: aload_1
    //   68: invokevirtual intValue : ()I
    //   71: istore_2
    //   72: goto -> 31
  }
  
  public void close() {
    this.cursor.close();
  }
  
  public void closeQuietly() {
    close();
  }
  
  public int findColumn(String paramString) throws SQLException {
    int i = lookupColumn(paramString);
    if (i < 0) {
      StringBuilder stringBuilder = new StringBuilder(paramString.length() + 4);
      databaseType.appendEscapedEntityName(stringBuilder, paramString);
      i = lookupColumn(stringBuilder.toString());
      if (i < 0) {
        String[] arrayOfString = this.cursor.getColumnNames();
        throw new SQLException("Unknown field '" + paramString + "' from the Android sqlite cursor, not in:" + Arrays.toString(arrayOfString));
      } 
    } 
    return i;
  }
  
  public boolean first() {
    return this.cursor.moveToFirst();
  }
  
  public BigDecimal getBigDecimal(int paramInt) throws SQLException {
    throw new SQLException("Android does not support BigDecimal type.  Use BIG_DECIMAL or BIG_DECIMAL_STRING types");
  }
  
  public InputStream getBlobStream(int paramInt) {
    return new ByteArrayInputStream(this.cursor.getBlob(paramInt));
  }
  
  public boolean getBoolean(int paramInt) {
    return !(this.cursor.isNull(paramInt) || this.cursor.getShort(paramInt) == 0);
  }
  
  public byte getByte(int paramInt) {
    return (byte)getShort(paramInt);
  }
  
  public byte[] getBytes(int paramInt) {
    return this.cursor.getBlob(paramInt);
  }
  
  public char getChar(int paramInt) throws SQLException {
    byte b = 0;
    String str = this.cursor.getString(paramInt);
    int i = b;
    if (str != null) {
      if (str.length() == 0)
        return b; 
    } else {
      return i;
    } 
    if (str.length() == 1) {
      paramInt = str.charAt(0);
      return paramInt;
    } 
    throw new SQLException("More than 1 character stored in database column: " + paramInt);
  }
  
  public int getColumnCount() {
    return this.cursor.getColumnCount();
  }
  
  public String[] getColumnNames() {
    int i = getColumnCount();
    String[] arrayOfString = new String[i];
    for (byte b = 0; b < i; b++)
      arrayOfString[b] = this.cursor.getColumnName(b); 
    return arrayOfString;
  }
  
  public int getCount() {
    return this.cursor.getCount();
  }
  
  public double getDouble(int paramInt) {
    return this.cursor.getDouble(paramInt);
  }
  
  public float getFloat(int paramInt) {
    return this.cursor.getFloat(paramInt);
  }
  
  public int getInt(int paramInt) {
    return this.cursor.getInt(paramInt);
  }
  
  public long getLong(int paramInt) {
    return this.cursor.getLong(paramInt);
  }
  
  public ObjectCache getObjectCache() {
    return this.objectCache;
  }
  
  public int getPosition() {
    return this.cursor.getPosition();
  }
  
  public Cursor getRawCursor() {
    return this.cursor;
  }
  
  public short getShort(int paramInt) {
    return this.cursor.getShort(paramInt);
  }
  
  public String getString(int paramInt) {
    return this.cursor.getString(paramInt);
  }
  
  public Timestamp getTimestamp(int paramInt) throws SQLException {
    throw new SQLException("Android does not support timestamp.  Use JAVA_DATE_LONG or JAVA_DATE_STRING types");
  }
  
  public boolean last() {
    return this.cursor.moveToLast();
  }
  
  public boolean moveAbsolute(int paramInt) {
    return this.cursor.moveToPosition(paramInt);
  }
  
  public boolean moveRelative(int paramInt) {
    return this.cursor.move(paramInt);
  }
  
  public boolean next() {
    return this.cursor.moveToNext();
  }
  
  public boolean previous() {
    return this.cursor.moveToPrevious();
  }
  
  public String toString() {
    return getClass().getSimpleName() + "@" + Integer.toHexString(hashCode());
  }
  
  public boolean wasNull(int paramInt) {
    return this.cursor.isNull(paramInt);
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/android/AndroidDatabaseResults.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */