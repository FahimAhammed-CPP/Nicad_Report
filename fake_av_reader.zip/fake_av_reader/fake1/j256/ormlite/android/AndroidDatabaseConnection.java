package com.j256.ormlite.android;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import com.j256.ormlite.dao.ObjectCache;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.field.SqlType;
import com.j256.ormlite.logger.Logger;
import com.j256.ormlite.logger.LoggerFactory;
import com.j256.ormlite.misc.SqlExceptionUtil;
import com.j256.ormlite.misc.VersionUtils;
import com.j256.ormlite.stmt.GenericRowMapper;
import com.j256.ormlite.stmt.StatementBuilder;
import com.j256.ormlite.support.CompiledStatement;
import com.j256.ormlite.support.DatabaseConnection;
import com.j256.ormlite.support.GeneratedKeyHolder;
import java.sql.SQLException;
import java.sql.Savepoint;

public class AndroidDatabaseConnection implements DatabaseConnection {
  private static final String ANDROID_VERSION = "VERSION__4.46__";
  
  private static final String[] NO_STRING_ARGS;
  
  private static Logger logger = LoggerFactory.getLogger(AndroidDatabaseConnection.class);
  
  private final SQLiteDatabase db;
  
  private final boolean readWrite;
  
  static {
    NO_STRING_ARGS = new String[0];
    VersionUtils.checkCoreVersusAndroidVersions("VERSION__4.46__");
  }
  
  public AndroidDatabaseConnection(SQLiteDatabase paramSQLiteDatabase, boolean paramBoolean) {
    this.db = paramSQLiteDatabase;
    this.readWrite = paramBoolean;
    logger.trace("{}: db {} opened, read-write = {}", this, paramSQLiteDatabase, Boolean.valueOf(paramBoolean));
  }
  
  private void bindArgs(SQLiteStatement paramSQLiteStatement, Object[] paramArrayOfObject, FieldType[] paramArrayOfFieldType) throws SQLException {
    if (paramArrayOfObject != null) {
      byte b = 0;
      while (true) {
        if (b < paramArrayOfObject.length) {
          Object object = paramArrayOfObject[b];
          if (object == null) {
            paramSQLiteStatement.bindNull(b + 1);
          } else {
            SqlType sqlType = paramArrayOfFieldType[b].getSqlType();
            switch (sqlType) {
              case STRING:
              case LONG_STRING:
              case CHAR:
                paramSQLiteStatement.bindString(b + 1, object.toString());
                b++;
                break;
              case BOOLEAN:
              case BYTE:
              case SHORT:
              case INTEGER:
              case LONG:
                paramSQLiteStatement.bindLong(b + 1, ((Number)object).longValue());
                b++;
                break;
              case FLOAT:
              case DOUBLE:
                paramSQLiteStatement.bindDouble(b + 1, ((Number)object).doubleValue());
                b++;
                break;
              case BYTE_ARRAY:
              case SERIALIZABLE:
                paramSQLiteStatement.bindBlob(b + 1, (byte[])object);
                b++;
                break;
              case DATE:
              case BLOB:
              case BIG_DECIMAL:
                throw new SQLException("Invalid Android type: " + sqlType);
            } 
            continue;
          } 
        } else {
          return;
        } 
        b++;
        break;
      } 
    } 
  }
  
  private String[] toStrings(Object[] paramArrayOfObject) {
    if (paramArrayOfObject == null || paramArrayOfObject.length == 0)
      return null; 
    String[] arrayOfString = new String[paramArrayOfObject.length];
    byte b = 0;
    while (true) {
      Object object = arrayOfString;
      if (b < paramArrayOfObject.length) {
        object = paramArrayOfObject[b];
        if (object == null) {
          arrayOfString[b] = null;
        } else {
          arrayOfString[b] = object.toString();
        } 
        b++;
        continue;
      } 
      return (String[])object;
    } 
  }
  
  private int update(String paramString1, Object[] paramArrayOfObject, FieldType[] paramArrayOfFieldType, String paramString2) throws SQLException {
    SQLiteStatement sQLiteStatement1 = null;
    SQLiteStatement sQLiteStatement2 = null;
    try {
      SQLiteStatement sQLiteStatement5 = this.db.compileStatement(paramString1);
      sQLiteStatement2 = sQLiteStatement5;
      sQLiteStatement1 = sQLiteStatement5;
      bindArgs(sQLiteStatement5, paramArrayOfObject, paramArrayOfFieldType);
      sQLiteStatement2 = sQLiteStatement5;
      sQLiteStatement1 = sQLiteStatement5;
      sQLiteStatement5.execute();
      SQLiteStatement sQLiteStatement3 = sQLiteStatement5;
      if (sQLiteStatement5 != null) {
        sQLiteStatement5.close();
        sQLiteStatement3 = null;
      } 
      SQLiteStatement sQLiteStatement4 = sQLiteStatement3;
    } catch (SQLException sQLException) {
      sQLiteStatement1 = sQLiteStatement2;
      StringBuilder stringBuilder = new StringBuilder();
      sQLiteStatement1 = sQLiteStatement2;
      this();
      sQLiteStatement1 = sQLiteStatement2;
      throw SqlExceptionUtil.create(stringBuilder.append("updating database failed: ").append(paramString1).toString(), sQLException);
    } finally {
      if (sQLiteStatement1 != null)
        sQLiteStatement1.close(); 
    } 
    if (sQLException != null)
      sQLException.close(); 
    throw paramString1;
  }
  
  public void close() throws SQLException {
    try {
      this.db.close();
      logger.trace("{}: db {} closed", this, this.db);
      return;
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("problems closing the database connection", sQLException);
    } 
  }
  
  public void closeQuietly() {
    try {
      close();
    } catch (SQLException sQLException) {}
  }
  
  public void commit(Savepoint paramSavepoint) throws SQLException {
    try {
      this.db.setTransactionSuccessful();
      this.db.endTransaction();
      if (paramSavepoint == null) {
        logger.trace("{}: transaction is successfuly ended", this);
        return;
      } 
      logger.trace("{}: transaction {} is successfuly ended", this, paramSavepoint.getSavepointName());
      return;
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("problems commiting transaction " + paramSavepoint.getSavepointName(), sQLException);
    } 
  }
  
  public CompiledStatement compileStatement(String paramString, StatementBuilder.StatementType paramStatementType, FieldType[] paramArrayOfFieldType) {
    AndroidCompiledStatement androidCompiledStatement = new AndroidCompiledStatement(paramString, this.db, paramStatementType);
    logger.trace("{}: compiled statement got {}: {}", this, androidCompiledStatement, paramString);
    return androidCompiledStatement;
  }
  
  public CompiledStatement compileStatement(String paramString, StatementBuilder.StatementType paramStatementType, FieldType[] paramArrayOfFieldType, int paramInt) {
    return compileStatement(paramString, paramStatementType, paramArrayOfFieldType);
  }
  
  public int delete(String paramString, Object[] paramArrayOfObject, FieldType[] paramArrayOfFieldType) throws SQLException {
    return update(paramString, paramArrayOfObject, paramArrayOfFieldType, "deleted");
  }
  
  public int executeStatement(String paramString, int paramInt) throws SQLException {
    return AndroidCompiledStatement.execSql(this.db, paramString, paramString, (Object[])NO_STRING_ARGS);
  }
  
  public int insert(String paramString, Object[] paramArrayOfObject, FieldType[] paramArrayOfFieldType, GeneratedKeyHolder paramGeneratedKeyHolder) throws SQLException {
    SQLiteStatement sQLiteStatement1 = null;
    SQLiteStatement sQLiteStatement2 = null;
    try {
      SQLiteStatement sQLiteStatement = this.db.compileStatement(paramString);
      sQLiteStatement2 = sQLiteStatement;
      sQLiteStatement1 = sQLiteStatement;
      bindArgs(sQLiteStatement, paramArrayOfObject, paramArrayOfFieldType);
      sQLiteStatement2 = sQLiteStatement;
      sQLiteStatement1 = sQLiteStatement;
      long l = sQLiteStatement.executeInsert();
      if (paramGeneratedKeyHolder != null) {
        sQLiteStatement2 = sQLiteStatement;
        sQLiteStatement1 = sQLiteStatement;
        paramGeneratedKeyHolder.addKey(Long.valueOf(l));
      } 
      sQLiteStatement2 = sQLiteStatement;
      sQLiteStatement1 = sQLiteStatement;
      logger.trace("{}: insert statement is compiled and executed, changed {}: {}", this, Integer.valueOf(1), paramString);
      return 1;
    } catch (SQLException sQLException) {
      sQLiteStatement1 = sQLiteStatement2;
      StringBuilder stringBuilder = new StringBuilder();
      sQLiteStatement1 = sQLiteStatement2;
      this();
      sQLiteStatement1 = sQLiteStatement2;
      throw SqlExceptionUtil.create(stringBuilder.append("inserting to database failed: ").append(paramString).toString(), sQLException);
    } finally {
      if (sQLiteStatement1 != null)
        sQLiteStatement1.close(); 
    } 
  }
  
  public boolean isAutoCommit() throws SQLException {
    try {
      null = this.db.inTransaction();
      logger.trace("{}: in transaction is {}", this, Boolean.valueOf(null));
      return !null;
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("problems getting auto-commit from database", sQLException);
    } 
  }
  
  public boolean isAutoCommitSupported() {
    return true;
  }
  
  public boolean isClosed() throws SQLException {
    try {
      null = this.db.isOpen();
      logger.trace("{}: db {} isOpen returned {}", this, this.db, Boolean.valueOf(null));
      return !null;
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("problems detecting if the database is closed", sQLException);
    } 
  }
  
  public boolean isReadWrite() {
    return this.readWrite;
  }
  
  public boolean isTableExists(String paramString) {
    Cursor cursor = this.db.rawQuery("SELECT DISTINCT tbl_name FROM sqlite_master WHERE tbl_name = '" + paramString + "'", null);
    if (cursor != null)
      try {
        if (cursor.getCount() > 0) {
          boolean bool2 = true;
          logger.trace("{}: isTableExists '{}' returned {}", this, paramString, Boolean.valueOf(bool2));
          return bool2;
        } 
        boolean bool1 = false;
        logger.trace("{}: isTableExists '{}' returned {}", this, paramString, Boolean.valueOf(bool1));
        return bool1;
      } finally {
        cursor.close();
      }  
    boolean bool = false;
    logger.trace("{}: isTableExists '{}' returned {}", this, paramString, Boolean.valueOf(bool));
    cursor.close();
    return bool;
  }
  
  public long queryForLong(String paramString) throws SQLException {
    SQLiteStatement sQLiteStatement1 = null;
    SQLiteStatement sQLiteStatement2 = null;
    try {
      SQLiteStatement sQLiteStatement = this.db.compileStatement(paramString);
      sQLiteStatement2 = sQLiteStatement;
      sQLiteStatement1 = sQLiteStatement;
      long l = sQLiteStatement.simpleQueryForLong();
      sQLiteStatement2 = sQLiteStatement;
      sQLiteStatement1 = sQLiteStatement;
      logger.trace("{}: query for long simple query returned {}: {}", this, Long.valueOf(l), paramString);
      return l;
    } catch (SQLException sQLException) {
      sQLiteStatement1 = sQLiteStatement2;
      StringBuilder stringBuilder = new StringBuilder();
      sQLiteStatement1 = sQLiteStatement2;
      this();
      sQLiteStatement1 = sQLiteStatement2;
      throw SqlExceptionUtil.create(stringBuilder.append("queryForLong from database failed: ").append(paramString).toString(), sQLException);
    } finally {
      if (sQLiteStatement1 != null)
        sQLiteStatement1.close(); 
    } 
  }
  
  public long queryForLong(String paramString, Object[] paramArrayOfObject, FieldType[] paramArrayOfFieldType) throws SQLException {
    Cursor cursor1;
    Cursor cursor2 = null;
    paramArrayOfFieldType = null;
    try {
      long l;
      Cursor cursor = this.db.rawQuery(paramString, toStrings(paramArrayOfObject));
      cursor1 = cursor;
      cursor2 = cursor;
      AndroidDatabaseResults androidDatabaseResults = new AndroidDatabaseResults();
      cursor1 = cursor;
      cursor2 = cursor;
      this(cursor, null);
      cursor1 = cursor;
      cursor2 = cursor;
      if (androidDatabaseResults.first()) {
        cursor1 = cursor;
        cursor2 = cursor;
        l = androidDatabaseResults.getLong(0);
      } else {
        l = 0L;
      } 
      cursor1 = cursor;
      cursor2 = cursor;
      logger.trace("{}: query for long raw query returned {}: {}", this, Long.valueOf(l), paramString);
      return l;
    } catch (SQLException sQLException) {
      cursor2 = cursor1;
      StringBuilder stringBuilder = new StringBuilder();
      cursor2 = cursor1;
      this();
      cursor2 = cursor1;
      throw SqlExceptionUtil.create(stringBuilder.append("queryForLong from database failed: ").append(paramString).toString(), sQLException);
    } finally {
      if (cursor2 != null)
        cursor2.close(); 
    } 
  }
  
  public <T> Object queryForOne(String paramString, Object[] paramArrayOfObject, FieldType[] paramArrayOfFieldType, GenericRowMapper<T> paramGenericRowMapper, ObjectCache paramObjectCache) throws SQLException {
    Cursor cursor1;
    paramArrayOfFieldType = null;
    Cursor cursor2 = null;
    try {
      Cursor cursor = this.db.rawQuery(paramString, toStrings(paramArrayOfObject));
      cursor2 = cursor;
      cursor1 = cursor;
      AndroidDatabaseResults androidDatabaseResults = new AndroidDatabaseResults();
      cursor2 = cursor;
      cursor1 = cursor;
      this(cursor, paramObjectCache);
      cursor2 = cursor;
      cursor1 = cursor;
      logger.trace("{}: queried for one result: {}", this, paramString);
      cursor2 = cursor;
      cursor1 = cursor;
      boolean bool = androidDatabaseResults.first();
      if (!bool) {
        cursor1 = null;
        Cursor cursor3 = cursor1;
        return cursor3;
      } 
      cursor2 = cursor;
      cursor1 = cursor;
      Object object = paramGenericRowMapper.mapRow(androidDatabaseResults);
      cursor2 = cursor;
      cursor1 = cursor;
      if (androidDatabaseResults.next()) {
        cursor2 = cursor;
        cursor1 = cursor;
        object = MORE_THAN_ONE;
        Object object1 = object;
        return object1;
      } 
      null = object;
      return null;
    } catch (SQLException sQLException) {
      cursor1 = cursor2;
      StringBuilder stringBuilder = new StringBuilder();
      cursor1 = cursor2;
      this();
      cursor1 = cursor2;
      throw SqlExceptionUtil.create(stringBuilder.append("queryForOne from database failed: ").append(null).toString(), sQLException);
    } finally {
      if (cursor1 != null)
        cursor1.close(); 
    } 
  }
  
  public void rollback(Savepoint paramSavepoint) throws SQLException {
    try {
      this.db.endTransaction();
      if (paramSavepoint == null) {
        logger.trace("{}: transaction is ended, unsuccessfuly", this);
        return;
      } 
      logger.trace("{}: transaction {} is ended, unsuccessfuly", this, paramSavepoint.getSavepointName());
      return;
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("problems rolling back transaction " + paramSavepoint.getSavepointName(), sQLException);
    } 
  }
  
  public void setAutoCommit(boolean paramBoolean) {
    if (paramBoolean) {
      if (this.db.inTransaction()) {
        this.db.setTransactionSuccessful();
        this.db.endTransaction();
      } 
      return;
    } 
    if (!this.db.inTransaction())
      this.db.beginTransaction(); 
  }
  
  public Savepoint setSavePoint(String paramString) throws SQLException {
    try {
      this.db.beginTransaction();
      logger.trace("{}: save-point set with name {}", this, paramString);
      return new OurSavePoint(paramString);
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("problems beginning transaction " + paramString, sQLException);
    } 
  }
  
  public String toString() {
    return getClass().getSimpleName() + "@" + Integer.toHexString(hashCode());
  }
  
  public int update(String paramString, Object[] paramArrayOfObject, FieldType[] paramArrayOfFieldType) throws SQLException {
    return update(paramString, paramArrayOfObject, paramArrayOfFieldType, "updated");
  }
  
  private static class OurSavePoint implements Savepoint {
    private String name;
    
    public OurSavePoint(String param1String) {
      this.name = param1String;
    }
    
    public int getSavepointId() {
      return 0;
    }
    
    public String getSavepointName() {
      return this.name;
    }
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/android/AndroidDatabaseConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */