package com.j256.ormlite.android.apptools;

import android.content.Context;
import android.content.res.Resources;
import com.j256.ormlite.dao.BaseDaoImpl;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.logger.Logger;
import com.j256.ormlite.logger.LoggerFactory;
import java.lang.reflect.Constructor;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public class OpenHelperManager {
  private static final String HELPER_CLASS_RESOURCE_NAME = "open_helper_classname";
  
  private static volatile OrmLiteSqliteOpenHelper helper;
  
  private static Class<? extends OrmLiteSqliteOpenHelper> helperClass;
  
  private static int instanceCount;
  
  private static Logger logger = LoggerFactory.getLogger(OpenHelperManager.class);
  
  private static boolean wasClosed;
  
  static {
    helperClass = null;
    helper = null;
    wasClosed = false;
    instanceCount = 0;
  }
  
  private static OrmLiteSqliteOpenHelper constructHelper(Context paramContext, Class<? extends OrmLiteSqliteOpenHelper> paramClass) {
    try {
      Constructor<? extends OrmLiteSqliteOpenHelper> constructor = paramClass.getConstructor(new Class[] { Context.class });
      try {
        return constructor.newInstance(new Object[] { paramContext });
      } catch (Exception exception) {
        throw new IllegalStateException("Could not construct instance of helper class " + paramClass, exception);
      } 
    } catch (Exception exception) {
      throw new IllegalStateException("Could not find public constructor that has a single (Context) argument for helper class " + paramClass, exception);
    } 
  }
  
  @Deprecated
  public static OrmLiteSqliteOpenHelper getHelper(Context paramContext) {
    // Byte code:
    //   0: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   2: monitorenter
    //   3: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.helperClass : Ljava/lang/Class;
    //   6: ifnonnull -> 45
    //   9: aload_0
    //   10: ifnonnull -> 31
    //   13: new java/lang/IllegalArgumentException
    //   16: astore_0
    //   17: aload_0
    //   18: ldc 'context argument is null'
    //   20: invokespecial <init> : (Ljava/lang/String;)V
    //   23: aload_0
    //   24: athrow
    //   25: astore_0
    //   26: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   28: monitorexit
    //   29: aload_0
    //   30: athrow
    //   31: aload_0
    //   32: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   35: aload_0
    //   36: invokevirtual getClass : ()Ljava/lang/Class;
    //   39: invokestatic lookupHelperClass : (Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Class;
    //   42: invokestatic innerSetHelperClass : (Ljava/lang/Class;)V
    //   45: aload_0
    //   46: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.helperClass : Ljava/lang/Class;
    //   49: invokestatic loadHelper : (Landroid/content/Context;Ljava/lang/Class;)Lcom/j256/ormlite/android/apptools/OrmLiteSqliteOpenHelper;
    //   52: astore_0
    //   53: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   55: monitorexit
    //   56: aload_0
    //   57: areturn
    // Exception table:
    //   from	to	target	type
    //   3	9	25	finally
    //   13	25	25	finally
    //   31	45	25	finally
    //   45	53	25	finally
  }
  
  public static <T extends OrmLiteSqliteOpenHelper> T getHelper(Context paramContext, Class<T> paramClass) {
    // Byte code:
    //   0: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   2: monitorenter
    //   3: aload_1
    //   4: invokestatic innerSetHelperClass : (Ljava/lang/Class;)V
    //   7: aload_0
    //   8: aload_1
    //   9: invokestatic loadHelper : (Landroid/content/Context;Ljava/lang/Class;)Lcom/j256/ormlite/android/apptools/OrmLiteSqliteOpenHelper;
    //   12: astore_0
    //   13: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   15: monitorexit
    //   16: aload_0
    //   17: areturn
    //   18: astore_0
    //   19: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   21: monitorexit
    //   22: aload_0
    //   23: athrow
    // Exception table:
    //   from	to	target	type
    //   3	13	18	finally
  }
  
  private static void innerSetHelperClass(Class<? extends OrmLiteSqliteOpenHelper> paramClass) {
    if (helperClass == null) {
      helperClass = paramClass;
      return;
    } 
    if (helperClass != paramClass)
      throw new IllegalStateException("Helper class was " + helperClass + " but is trying to be reset to " + paramClass); 
  }
  
  private static <T extends OrmLiteSqliteOpenHelper> T loadHelper(Context paramContext, Class<T> paramClass) {
    if (helper == null) {
      if (wasClosed)
        logger.info("helper was already closed and is being re-opened"); 
      if (paramContext == null)
        throw new IllegalArgumentException("context argument is null"); 
      helper = constructHelper(paramContext.getApplicationContext(), helperClass);
      logger.trace("zero instances, created helper {}", helper);
      BaseDaoImpl.clearAllInternalObjectCaches();
      DaoManager.clearDaoCache();
      instanceCount = 0;
    } 
    instanceCount++;
    logger.trace("returning helper {}, instance count = {} ", helper, Integer.valueOf(instanceCount));
    return (T)helper;
  }
  
  private static Class<? extends OrmLiteSqliteOpenHelper> lookupHelperClass(Context paramContext, Class<?> paramClass) {
    String str2;
    Resources resources = paramContext.getResources();
    int i = resources.getIdentifier("open_helper_classname", "string", paramContext.getPackageName());
    if (i != 0) {
      str2 = resources.getString(i);
      try {
        return (Class)Class.forName(str2);
      } catch (Exception exception) {
        throw new IllegalStateException("Could not create helper instance for class " + str2, exception);
      } 
    } 
    String str1 = str2;
    label31: while (str1 != null) {
      Type type = str1.getGenericSuperclass();
      if (type != null) {
        if (!(type instanceof ParameterizedType))
          continue; 
        Type[] arrayOfType = ((ParameterizedType)type).getActualTypeArguments();
        if (arrayOfType != null) {
          if (arrayOfType.length != 0) {
            int j = arrayOfType.length;
            i = 0;
            while (true) {
              if (i < j) {
                type = arrayOfType[i];
                if (type instanceof Class) {
                  type = type;
                  if (OrmLiteSqliteOpenHelper.class.isAssignableFrom((Class<?>)type))
                    return (Class<? extends OrmLiteSqliteOpenHelper>)type; 
                } 
                i++;
                continue;
              } 
              Class clazz = str1.getSuperclass();
              continue label31;
            } 
          } 
          continue;
        } 
        continue;
      } 
      continue;
    } 
    throw new IllegalStateException("Could not find OpenHelperClass because none of the generic parameters of class " + str2 + " extends OrmLiteSqliteOpenHelper.  You should use getHelper(Context, Class) instead.");
  }
  
  @Deprecated
  public static void release() {
    releaseHelper();
  }
  
  public static void releaseHelper() {
    // Byte code:
    //   0: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   2: monitorenter
    //   3: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.instanceCount : I
    //   6: iconst_1
    //   7: isub
    //   8: putstatic com/j256/ormlite/android/apptools/OpenHelperManager.instanceCount : I
    //   11: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   14: ldc 'releasing helper {}, instance count = {}'
    //   16: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.helper : Lcom/j256/ormlite/android/apptools/OrmLiteSqliteOpenHelper;
    //   19: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.instanceCount : I
    //   22: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   25: invokevirtual trace : (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
    //   28: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.instanceCount : I
    //   31: ifgt -> 85
    //   34: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.helper : Lcom/j256/ormlite/android/apptools/OrmLiteSqliteOpenHelper;
    //   37: ifnull -> 65
    //   40: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   43: ldc 'zero instances, closing helper {}'
    //   45: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.helper : Lcom/j256/ormlite/android/apptools/OrmLiteSqliteOpenHelper;
    //   48: invokevirtual trace : (Ljava/lang/String;Ljava/lang/Object;)V
    //   51: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.helper : Lcom/j256/ormlite/android/apptools/OrmLiteSqliteOpenHelper;
    //   54: invokevirtual close : ()V
    //   57: aconst_null
    //   58: putstatic com/j256/ormlite/android/apptools/OpenHelperManager.helper : Lcom/j256/ormlite/android/apptools/OrmLiteSqliteOpenHelper;
    //   61: iconst_1
    //   62: putstatic com/j256/ormlite/android/apptools/OpenHelperManager.wasClosed : Z
    //   65: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.instanceCount : I
    //   68: ifge -> 85
    //   71: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   74: ldc 'too many calls to release helper, instance count = {}'
    //   76: getstatic com/j256/ormlite/android/apptools/OpenHelperManager.instanceCount : I
    //   79: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   82: invokevirtual error : (Ljava/lang/String;Ljava/lang/Object;)V
    //   85: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   87: monitorexit
    //   88: return
    //   89: astore_0
    //   90: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   92: monitorexit
    //   93: aload_0
    //   94: athrow
    // Exception table:
    //   from	to	target	type
    //   3	65	89	finally
    //   65	85	89	finally
  }
  
  public static void setHelper(OrmLiteSqliteOpenHelper paramOrmLiteSqliteOpenHelper) {
    // Byte code:
    //   0: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   2: monitorenter
    //   3: aload_0
    //   4: putstatic com/j256/ormlite/android/apptools/OpenHelperManager.helper : Lcom/j256/ormlite/android/apptools/OrmLiteSqliteOpenHelper;
    //   7: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   9: monitorexit
    //   10: return
    //   11: astore_0
    //   12: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   14: monitorexit
    //   15: aload_0
    //   16: athrow
    // Exception table:
    //   from	to	target	type
    //   3	7	11	finally
  }
  
  public static void setOpenHelperClass(Class<? extends OrmLiteSqliteOpenHelper> paramClass) {
    // Byte code:
    //   0: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnonnull -> 15
    //   7: aconst_null
    //   8: putstatic com/j256/ormlite/android/apptools/OpenHelperManager.helperClass : Ljava/lang/Class;
    //   11: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   13: monitorexit
    //   14: return
    //   15: aload_0
    //   16: invokestatic innerSetHelperClass : (Ljava/lang/Class;)V
    //   19: goto -> 11
    //   22: astore_0
    //   23: ldc com/j256/ormlite/android/apptools/OpenHelperManager
    //   25: monitorexit
    //   26: aload_0
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   7	11	22	finally
    //   15	19	22	finally
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/android/apptools/OpenHelperManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */