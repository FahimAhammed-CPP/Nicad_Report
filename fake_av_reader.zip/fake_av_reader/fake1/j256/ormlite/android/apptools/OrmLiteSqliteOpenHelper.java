package com.j256.ormlite.android.apptools;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.j256.ormlite.android.AndroidConnectionSource;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.dao.RuntimeExceptionDao;
import com.j256.ormlite.logger.Logger;
import com.j256.ormlite.logger.LoggerFactory;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.DatabaseTableConfigLoader;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.SQLException;

public abstract class OrmLiteSqliteOpenHelper extends SQLiteOpenHelper {
  protected static Logger logger = LoggerFactory.getLogger(OrmLiteSqliteOpenHelper.class);
  
  protected AndroidConnectionSource connectionSource = new AndroidConnectionSource(this);
  
  private volatile boolean isOpen = true;
  
  public OrmLiteSqliteOpenHelper(Context paramContext, String paramString, SQLiteDatabase.CursorFactory paramCursorFactory, int paramInt) {
    super(paramContext, paramString, paramCursorFactory, paramInt);
    logger.trace("{}: constructed connectionSource {}", this, this.connectionSource);
  }
  
  public OrmLiteSqliteOpenHelper(Context paramContext, String paramString, SQLiteDatabase.CursorFactory paramCursorFactory, int paramInt1, int paramInt2) {
    this(paramContext, paramString, paramCursorFactory, paramInt1, openFileId(paramContext, paramInt2));
  }
  
  public OrmLiteSqliteOpenHelper(Context paramContext, String paramString, SQLiteDatabase.CursorFactory paramCursorFactory, int paramInt, File paramFile) {
    this(paramContext, paramString, paramCursorFactory, paramInt, openFile(paramFile));
  }
  
  public OrmLiteSqliteOpenHelper(Context paramContext, String paramString, SQLiteDatabase.CursorFactory paramCursorFactory, int paramInt, InputStream paramInputStream) {
    super(paramContext, paramString, paramCursorFactory, paramInt);
    if (paramInputStream != null)
      try {
        BufferedReader bufferedReader = new BufferedReader();
        InputStreamReader inputStreamReader = new InputStreamReader();
        this(paramInputStream);
        this(inputStreamReader, 4096);
        DaoManager.addCachedDatabaseConfigs(DatabaseTableConfigLoader.loadDatabaseConfigFromReader(bufferedReader));
        return;
      } catch (SQLException sQLException) {
        IllegalStateException illegalStateException = new IllegalStateException();
        this("Could not load object config file", sQLException);
        throw illegalStateException;
      } finally {
        try {
          paramInputStream.close();
        } catch (IOException iOException) {}
      }  
  }
  
  private static InputStream openFile(File paramFile) {
    if (paramFile == null)
      return null; 
    try {
      return new FileInputStream(paramFile);
    } catch (FileNotFoundException fileNotFoundException) {
      throw new IllegalArgumentException("Could not open config file " + paramFile, fileNotFoundException);
    } 
  }
  
  private static InputStream openFileId(Context paramContext, int paramInt) {
    InputStream inputStream = paramContext.getResources().openRawResource(paramInt);
    if (inputStream == null)
      throw new IllegalStateException("Could not find object config file with id " + paramInt); 
    return inputStream;
  }
  
  public void close() {
    super.close();
    this.connectionSource.close();
    this.isOpen = false;
  }
  
  public ConnectionSource getConnectionSource() {
    if (!this.isOpen)
      logger.warn(new IllegalStateException(), "Getting connectionSource was called after closed"); 
    return (ConnectionSource)this.connectionSource;
  }
  
  public <D extends com.j256.ormlite.dao.Dao<T, ?>, T> D getDao(Class<T> paramClass) throws SQLException {
    return (D)DaoManager.createDao(getConnectionSource(), paramClass);
  }
  
  public <D extends RuntimeExceptionDao<T, ?>, T> D getRuntimeExceptionDao(Class<T> paramClass) {
    try {
      return (D)new RuntimeExceptionDao(getDao(paramClass));
    } catch (SQLException sQLException) {
      throw new RuntimeException("Could not create RuntimeExcepitionDao for class " + paramClass, sQLException);
    } 
  }
  
  public boolean isOpen() {
    return this.isOpen;
  }
  
  public final void onCreate(SQLiteDatabase paramSQLiteDatabase) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getConnectionSource : ()Lcom/j256/ormlite/support/ConnectionSource;
    //   4: astore_2
    //   5: aload_2
    //   6: invokeinterface getSpecialConnection : ()Lcom/j256/ormlite/support/DatabaseConnection;
    //   11: astore_3
    //   12: iconst_0
    //   13: istore #4
    //   15: aload_3
    //   16: astore #5
    //   18: aload_3
    //   19: ifnonnull -> 45
    //   22: new com/j256/ormlite/android/AndroidDatabaseConnection
    //   25: dup
    //   26: aload_1
    //   27: iconst_1
    //   28: invokespecial <init> : (Landroid/database/sqlite/SQLiteDatabase;Z)V
    //   31: astore #5
    //   33: aload_2
    //   34: aload #5
    //   36: invokeinterface saveSpecialConnection : (Lcom/j256/ormlite/support/DatabaseConnection;)Z
    //   41: pop
    //   42: iconst_1
    //   43: istore #4
    //   45: aload_0
    //   46: aload_1
    //   47: aload_2
    //   48: invokevirtual onCreate : (Landroid/database/sqlite/SQLiteDatabase;Lcom/j256/ormlite/support/ConnectionSource;)V
    //   51: iload #4
    //   53: ifeq -> 64
    //   56: aload_2
    //   57: aload #5
    //   59: invokeinterface clearSpecialConnection : (Lcom/j256/ormlite/support/DatabaseConnection;)V
    //   64: return
    //   65: astore_1
    //   66: new java/lang/IllegalStateException
    //   69: dup
    //   70: ldc 'Could not save special connection'
    //   72: aload_1
    //   73: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   76: athrow
    //   77: astore_1
    //   78: iload #4
    //   80: ifeq -> 91
    //   83: aload_2
    //   84: aload #5
    //   86: invokeinterface clearSpecialConnection : (Lcom/j256/ormlite/support/DatabaseConnection;)V
    //   91: aload_1
    //   92: athrow
    // Exception table:
    //   from	to	target	type
    //   33	42	65	java/sql/SQLException
    //   45	51	77	finally
  }
  
  public abstract void onCreate(SQLiteDatabase paramSQLiteDatabase, ConnectionSource paramConnectionSource);
  
  public final void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getConnectionSource : ()Lcom/j256/ormlite/support/ConnectionSource;
    //   4: astore #4
    //   6: aload #4
    //   8: invokeinterface getSpecialConnection : ()Lcom/j256/ormlite/support/DatabaseConnection;
    //   13: astore #5
    //   15: iconst_0
    //   16: istore #6
    //   18: aload #5
    //   20: astore #7
    //   22: aload #5
    //   24: ifnonnull -> 51
    //   27: new com/j256/ormlite/android/AndroidDatabaseConnection
    //   30: dup
    //   31: aload_1
    //   32: iconst_1
    //   33: invokespecial <init> : (Landroid/database/sqlite/SQLiteDatabase;Z)V
    //   36: astore #7
    //   38: aload #4
    //   40: aload #7
    //   42: invokeinterface saveSpecialConnection : (Lcom/j256/ormlite/support/DatabaseConnection;)Z
    //   47: pop
    //   48: iconst_1
    //   49: istore #6
    //   51: aload_0
    //   52: aload_1
    //   53: aload #4
    //   55: iload_2
    //   56: iload_3
    //   57: invokevirtual onUpgrade : (Landroid/database/sqlite/SQLiteDatabase;Lcom/j256/ormlite/support/ConnectionSource;II)V
    //   60: iload #6
    //   62: ifeq -> 74
    //   65: aload #4
    //   67: aload #7
    //   69: invokeinterface clearSpecialConnection : (Lcom/j256/ormlite/support/DatabaseConnection;)V
    //   74: return
    //   75: astore_1
    //   76: new java/lang/IllegalStateException
    //   79: dup
    //   80: ldc 'Could not save special connection'
    //   82: aload_1
    //   83: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   86: athrow
    //   87: astore_1
    //   88: iload #6
    //   90: ifeq -> 102
    //   93: aload #4
    //   95: aload #7
    //   97: invokeinterface clearSpecialConnection : (Lcom/j256/ormlite/support/DatabaseConnection;)V
    //   102: aload_1
    //   103: athrow
    // Exception table:
    //   from	to	target	type
    //   38	48	75	java/sql/SQLException
    //   51	60	87	finally
  }
  
  public abstract void onUpgrade(SQLiteDatabase paramSQLiteDatabase, ConnectionSource paramConnectionSource, int paramInt1, int paramInt2);
  
  public String toString() {
    return getClass().getSimpleName() + "@" + Integer.toHexString(hashCode());
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/android/apptools/OrmLiteSqliteOpenHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */