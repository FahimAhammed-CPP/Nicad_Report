package com.j256.ormlite.android.apptools;

import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.db.SqliteAndroidDatabaseType;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.field.DatabaseFieldConfig;
import com.j256.ormlite.field.ForeignCollectionField;
import com.j256.ormlite.table.DatabaseTable;
import com.j256.ormlite.table.DatabaseTableConfig;
import com.j256.ormlite.table.DatabaseTableConfigLoader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrmLiteConfigUtil {
  protected static final String RAW_DIR_NAME = "raw";
  
  protected static final String RESOURCE_DIR_NAME = "res";
  
  private static final DatabaseType databaseType;
  
  protected static int maxFindSourceLevel = 20;
  
  static {
    databaseType = (DatabaseType)new SqliteAndroidDatabaseType();
  }
  
  private static boolean classHasAnnotations(Class<?> paramClass) {
    boolean bool = true;
    while (paramClass != null) {
      if (paramClass.getAnnotation(DatabaseTable.class) != null) {
        boolean bool1 = bool;
        continue;
      } 
      try {
        Field[] arrayOfField = paramClass.getDeclaredFields();
        int i = arrayOfField.length;
        byte b = 0;
        while (b < i) {
          Field field = arrayOfField[b];
          boolean bool1 = bool;
          if (field.getAnnotation(DatabaseField.class) == null) {
            bool1 = bool;
            if (field.getAnnotation(ForeignCollectionField.class) == null) {
              b++;
              continue;
            } 
          } 
          return bool1;
        } 
      } catch (Throwable throwable) {
        System.err.println("Could not load get delcared fields from: " + paramClass);
        System.err.println("     " + throwable);
        boolean bool1 = false;
        continue;
      } 
      try {
        Class<?> clazz = paramClass.getSuperclass();
        paramClass = clazz;
      } catch (Throwable throwable) {
        System.err.println("Could not get super class for: " + paramClass);
        System.err.println("     " + throwable);
        boolean bool1 = false;
        continue;
      } 
    } 
    return false;
  }
  
  private static void findAnnotatedClasses(List<Class<?>> paramList, File paramFile, int paramInt) throws SQLException, IOException {
    File[] arrayOfFile = paramFile.listFiles();
    int i = arrayOfFile.length;
    byte b = 0;
    label34: while (b < i) {
      File file = arrayOfFile[b];
      if (file.isDirectory()) {
        if (paramInt < maxFindSourceLevel) {
          findAnnotatedClasses(paramList, file, paramInt + 1);
          continue;
        } 
        continue;
      } 
      if (file.getName().endsWith(".java")) {
        String str1 = getPackageOfClass(file);
        if (str1 == null) {
          System.err.println("Could not find package name for: " + file);
          continue;
        } 
        String str2 = file.getName();
        str2 = str2.substring(0, str2.length() - ".java".length());
        str1 = str1 + "." + str2;
        try {
          Class<?> clazz = Class.forName(str1);
          if (classHasAnnotations(clazz))
            paramList.add(clazz); 
          try {
            Class[] arrayOfClass = clazz.getDeclaredClasses();
            int j = arrayOfClass.length;
            byte b1 = 0;
            while (true) {
              if (b1 < j) {
                Class<?> clazz1 = arrayOfClass[b1];
                if (classHasAnnotations(clazz1))
                  paramList.add(clazz1); 
                b1++;
                continue;
              } 
              b++;
              continue label34;
            } 
          } catch (Throwable throwable) {
            System.err.println("Could not load inner classes for: " + clazz);
            System.err.println("     " + throwable);
          } 
        } catch (Throwable throwable1) {
          System.err.println("Could not load class file for: " + throwable);
          System.err.println("     " + throwable1);
          continue;
        } 
        continue;
      } 
      continue;
    } 
  }
  
  protected static File findRawDir(File paramFile) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: ifnull -> 36
    //   6: iload_1
    //   7: bipush #20
    //   9: if_icmpge -> 36
    //   12: aload_0
    //   13: invokestatic findResRawDir : (Ljava/io/File;)Ljava/io/File;
    //   16: astore_2
    //   17: aload_2
    //   18: ifnull -> 25
    //   21: aload_2
    //   22: astore_0
    //   23: aload_0
    //   24: areturn
    //   25: aload_0
    //   26: invokevirtual getParentFile : ()Ljava/io/File;
    //   29: astore_0
    //   30: iinc #1, 1
    //   33: goto -> 2
    //   36: aconst_null
    //   37: astore_0
    //   38: goto -> 23
  }
  
  private static File findResRawDir(File paramFile) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual listFiles : ()[Ljava/io/File;
    //   4: astore_0
    //   5: aload_0
    //   6: arraylength
    //   7: istore_1
    //   8: iconst_0
    //   9: istore_2
    //   10: iload_2
    //   11: iload_1
    //   12: if_icmpge -> 68
    //   15: aload_0
    //   16: iload_2
    //   17: aaload
    //   18: astore_3
    //   19: aload_3
    //   20: invokevirtual getName : ()Ljava/lang/String;
    //   23: ldc 'res'
    //   25: invokevirtual equals : (Ljava/lang/Object;)Z
    //   28: ifeq -> 62
    //   31: aload_3
    //   32: invokevirtual isDirectory : ()Z
    //   35: ifeq -> 62
    //   38: aload_3
    //   39: new com/j256/ormlite/android/apptools/OrmLiteConfigUtil$1
    //   42: dup
    //   43: invokespecial <init> : ()V
    //   46: invokevirtual listFiles : (Ljava/io/FileFilter;)[Ljava/io/File;
    //   49: astore_3
    //   50: aload_3
    //   51: arraylength
    //   52: iconst_1
    //   53: if_icmpne -> 62
    //   56: aload_3
    //   57: iconst_0
    //   58: aaload
    //   59: astore_0
    //   60: aload_0
    //   61: areturn
    //   62: iinc #2, 1
    //   65: goto -> 10
    //   68: aconst_null
    //   69: astore_0
    //   70: goto -> 60
  }
  
  private static String getPackageOfClass(File paramFile) throws IOException {
    BufferedReader bufferedReader = new BufferedReader(new FileReader(paramFile));
    try {
      while (true) {
        String str = bufferedReader.readLine();
        if (str == null) {
          str = null;
          return str;
        } 
        if (str.contains("package")) {
          String[] arrayOfString = str.split("[ \t;]");
          if (arrayOfString.length > 1 && arrayOfString[0].equals("package"))
            return arrayOfString[1]; 
        } 
      } 
    } finally {
      bufferedReader.close();
    } 
  }
  
  public static void main(String[] paramArrayOfString) throws Exception {
    if (paramArrayOfString.length != 1)
      throw new IllegalArgumentException("Main can take a single file-name argument."); 
    writeConfigFile(paramArrayOfString[0]);
  }
  
  public static void writeConfigFile(File paramFile) throws SQLException, IOException {
    writeConfigFile(paramFile, new File("."));
  }
  
  public static void writeConfigFile(File paramFile1, File paramFile2) throws SQLException, IOException {
    ArrayList<Class<?>> arrayList = new ArrayList();
    findAnnotatedClasses(arrayList, paramFile2, 0);
    writeConfigFile(paramFile1, (Class[])arrayList.<Class<?>[]>toArray((Class<?>[][])new Class[arrayList.size()]));
  }
  
  public static void writeConfigFile(File paramFile, Class<?>[] paramArrayOfClass) throws SQLException, IOException {
    System.out.println("Writing configurations to " + paramFile.getAbsolutePath());
    writeConfigFile(new FileOutputStream(paramFile), paramArrayOfClass);
  }
  
  public static void writeConfigFile(OutputStream paramOutputStream, File paramFile) throws SQLException, IOException {
    ArrayList<Class<?>> arrayList = new ArrayList();
    findAnnotatedClasses(arrayList, paramFile, 0);
    writeConfigFile(paramOutputStream, (Class[])arrayList.<Class<?>[]>toArray((Class<?>[][])new Class[arrayList.size()]));
  }
  
  public static void writeConfigFile(OutputStream paramOutputStream, Class<?>[] paramArrayOfClass) throws SQLException, IOException {
    BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(paramOutputStream), 4096);
    try {
      writeHeader(bufferedWriter);
      int i = paramArrayOfClass.length;
      for (byte b = 0; b < i; b++)
        writeConfigForTable(bufferedWriter, paramArrayOfClass[b]); 
      System.out.println("Done.");
      return;
    } finally {
      bufferedWriter.close();
    } 
  }
  
  public static void writeConfigFile(String paramString) throws SQLException, IOException {
    ArrayList<Class<?>> arrayList = new ArrayList();
    findAnnotatedClasses(arrayList, new File("."), 0);
    writeConfigFile(paramString, (Class[])arrayList.<Class<?>[]>toArray((Class<?>[][])new Class[arrayList.size()]));
  }
  
  public static void writeConfigFile(String paramString, Class<?>[] paramArrayOfClass) throws SQLException, IOException {
    File file = findRawDir(new File("."));
    if (file == null) {
      System.err.println("Could not find raw directory");
      return;
    } 
    writeConfigFile(new File(file, paramString), paramArrayOfClass);
  }
  
  private static void writeConfigForTable(BufferedWriter paramBufferedWriter, Class<?> paramClass) throws SQLException, IOException {
    String str = DatabaseTableConfig.extractTableName(paramClass);
    ArrayList<DatabaseFieldConfig> arrayList = new ArrayList();
    Class<?> clazz = paramClass;
    while (clazz != null) {
      try {
        for (Field field : clazz.getDeclaredFields()) {
          DatabaseFieldConfig databaseFieldConfig = DatabaseFieldConfig.fromField(databaseType, str, field);
          if (databaseFieldConfig != null)
            arrayList.add(databaseFieldConfig); 
        } 
        clazz = clazz.getSuperclass();
      } catch (Error error) {
        System.err.println("Skipping " + paramClass + " because we got an error finding its definition: " + error.getMessage());
        continue;
      } 
    } 
    if (arrayList.isEmpty()) {
      System.out.println("Skipping " + paramClass + " because no annotated fields found");
      return;
    } 
    DatabaseTableConfigLoader.write((BufferedWriter)error, new DatabaseTableConfig(paramClass, str, arrayList));
    error.append("#################################");
    error.newLine();
    System.out.println("Wrote config for " + paramClass);
  }
  
  private static void writeHeader(BufferedWriter paramBufferedWriter) throws IOException {
    paramBufferedWriter.append('#');
    paramBufferedWriter.newLine();
    paramBufferedWriter.append("# generated on ").append((new SimpleDateFormat("yyyy/MM/dd hh:mm:ss")).format(new Date()));
    paramBufferedWriter.newLine();
    paramBufferedWriter.append('#');
    paramBufferedWriter.newLine();
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/android/apptools/OrmLiteConfigUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */