package com.j256.ormlite.table;

import com.j256.ormlite.dao.BaseDaoImpl;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.misc.BaseDaoEnabled;
import com.j256.ormlite.misc.SqlExceptionUtil;
import com.j256.ormlite.support.ConnectionSource;
import java.lang.reflect.Constructor;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class TableInfo<T, ID> {
  private static final FieldType[] NO_FOREIGN_COLLECTIONS = new FieldType[0];
  
  private final BaseDaoImpl<T, ID> baseDaoImpl;
  
  private final Constructor<T> constructor;
  
  private final Class<T> dataClass;
  
  private Map<String, FieldType> fieldNameMap;
  
  private final FieldType[] fieldTypes;
  
  private final boolean foreignAutoCreate;
  
  private final FieldType[] foreignCollections;
  
  private final FieldType idField;
  
  private final String tableName;
  
  public TableInfo(DatabaseType paramDatabaseType, BaseDaoImpl<T, ID> paramBaseDaoImpl, DatabaseTableConfig<T> paramDatabaseTableConfig) throws SQLException {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_0
    //   5: aload_2
    //   6: putfield baseDaoImpl : Lcom/j256/ormlite/dao/BaseDaoImpl;
    //   9: aload_0
    //   10: aload_3
    //   11: invokevirtual getDataClass : ()Ljava/lang/Class;
    //   14: putfield dataClass : Ljava/lang/Class;
    //   17: aload_0
    //   18: aload_3
    //   19: invokevirtual getTableName : ()Ljava/lang/String;
    //   22: putfield tableName : Ljava/lang/String;
    //   25: aload_0
    //   26: aload_3
    //   27: aload_1
    //   28: invokevirtual getFieldTypes : (Lcom/j256/ormlite/db/DatabaseType;)[Lcom/j256/ormlite/field/FieldType;
    //   31: putfield fieldTypes : [Lcom/j256/ormlite/field/FieldType;
    //   34: aconst_null
    //   35: astore_2
    //   36: iconst_0
    //   37: istore #4
    //   39: iconst_0
    //   40: istore #5
    //   42: aload_0
    //   43: getfield fieldTypes : [Lcom/j256/ormlite/field/FieldType;
    //   46: astore #6
    //   48: aload #6
    //   50: arraylength
    //   51: istore #7
    //   53: iconst_0
    //   54: istore #8
    //   56: iload #8
    //   58: iload #7
    //   60: if_icmpge -> 198
    //   63: aload #6
    //   65: iload #8
    //   67: aaload
    //   68: astore #9
    //   70: aload #9
    //   72: invokevirtual isId : ()Z
    //   75: ifne -> 96
    //   78: aload #9
    //   80: invokevirtual isGeneratedId : ()Z
    //   83: ifne -> 96
    //   86: aload_2
    //   87: astore_1
    //   88: aload #9
    //   90: invokevirtual isGeneratedIdSequence : ()Z
    //   93: ifeq -> 157
    //   96: aload_2
    //   97: ifnull -> 154
    //   100: new java/sql/SQLException
    //   103: dup
    //   104: new java/lang/StringBuilder
    //   107: dup
    //   108: invokespecial <init> : ()V
    //   111: ldc 'More than 1 idField configured for class '
    //   113: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   116: aload_0
    //   117: getfield dataClass : Ljava/lang/Class;
    //   120: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   123: ldc ' ('
    //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: aload_2
    //   129: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   132: ldc ','
    //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   137: aload #9
    //   139: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   142: ldc ')'
    //   144: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   147: invokevirtual toString : ()Ljava/lang/String;
    //   150: invokespecial <init> : (Ljava/lang/String;)V
    //   153: athrow
    //   154: aload #9
    //   156: astore_1
    //   157: aload #9
    //   159: invokevirtual isForeignAutoCreate : ()Z
    //   162: ifeq -> 168
    //   165: iconst_1
    //   166: istore #4
    //   168: iload #5
    //   170: istore #10
    //   172: aload #9
    //   174: invokevirtual isForeignCollection : ()Z
    //   177: ifeq -> 186
    //   180: iload #5
    //   182: iconst_1
    //   183: iadd
    //   184: istore #10
    //   186: iinc #8, 1
    //   189: aload_1
    //   190: astore_2
    //   191: iload #10
    //   193: istore #5
    //   195: goto -> 56
    //   198: aload_0
    //   199: aload_2
    //   200: putfield idField : Lcom/j256/ormlite/field/FieldType;
    //   203: aload_0
    //   204: aload_3
    //   205: invokevirtual getConstructor : ()Ljava/lang/reflect/Constructor;
    //   208: putfield constructor : Ljava/lang/reflect/Constructor;
    //   211: aload_0
    //   212: iload #4
    //   214: putfield foreignAutoCreate : Z
    //   217: iload #5
    //   219: ifne -> 230
    //   222: aload_0
    //   223: getstatic com/j256/ormlite/table/TableInfo.NO_FOREIGN_COLLECTIONS : [Lcom/j256/ormlite/field/FieldType;
    //   226: putfield foreignCollections : [Lcom/j256/ormlite/field/FieldType;
    //   229: return
    //   230: aload_0
    //   231: iload #5
    //   233: anewarray com/j256/ormlite/field/FieldType
    //   236: putfield foreignCollections : [Lcom/j256/ormlite/field/FieldType;
    //   239: iconst_0
    //   240: istore #10
    //   242: aload_0
    //   243: getfield fieldTypes : [Lcom/j256/ormlite/field/FieldType;
    //   246: astore_2
    //   247: aload_2
    //   248: arraylength
    //   249: istore #7
    //   251: iconst_0
    //   252: istore #8
    //   254: iload #8
    //   256: iload #7
    //   258: if_icmpge -> 229
    //   261: aload_2
    //   262: iload #8
    //   264: aaload
    //   265: astore_1
    //   266: iload #10
    //   268: istore #5
    //   270: aload_1
    //   271: invokevirtual isForeignCollection : ()Z
    //   274: ifeq -> 291
    //   277: aload_0
    //   278: getfield foreignCollections : [Lcom/j256/ormlite/field/FieldType;
    //   281: iload #10
    //   283: aload_1
    //   284: aastore
    //   285: iload #10
    //   287: iconst_1
    //   288: iadd
    //   289: istore #5
    //   291: iinc #8, 1
    //   294: iload #5
    //   296: istore #10
    //   298: goto -> 254
  }
  
  public TableInfo(ConnectionSource paramConnectionSource, BaseDaoImpl<T, ID> paramBaseDaoImpl, Class<T> paramClass) throws SQLException {
    this(paramConnectionSource.getDatabaseType(), paramBaseDaoImpl, DatabaseTableConfig.fromClass(paramConnectionSource, paramClass));
  }
  
  private static <T, ID> void wireNewInstance(BaseDaoImpl<T, ID> paramBaseDaoImpl, T paramT) {
    if (paramT instanceof BaseDaoEnabled)
      ((BaseDaoEnabled)paramT).setDao((Dao)paramBaseDaoImpl); 
  }
  
  public T createObject() throws SQLException {
    ObjectFactory<ObjectFactory> objectFactory = null;
    try {
      if (this.baseDaoImpl != null)
        objectFactory = this.baseDaoImpl.getObjectFactory(); 
      if (objectFactory == null) {
        objectFactory = (ObjectFactory<ObjectFactory>)this.constructor.newInstance(new Object[0]);
        wireNewInstance(this.baseDaoImpl, (T)objectFactory);
        return (T)objectFactory;
      } 
      objectFactory = objectFactory.createObject((Constructor)this.constructor, this.baseDaoImpl.getDataClass());
      wireNewInstance(this.baseDaoImpl, (T)objectFactory);
      return (T)objectFactory;
    } catch (Exception exception) {
      throw SqlExceptionUtil.create("Could not create object for " + this.constructor.getDeclaringClass(), exception);
    } 
  }
  
  public Constructor<T> getConstructor() {
    return this.constructor;
  }
  
  public Class<T> getDataClass() {
    return this.dataClass;
  }
  
  public FieldType getFieldTypeByColumnName(String paramString) {
    if (this.fieldNameMap == null) {
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      for (FieldType fieldType1 : this.fieldTypes)
        hashMap.put(fieldType1.getColumnName(), fieldType1); 
      this.fieldNameMap = (Map)hashMap;
    } 
    fieldType = this.fieldNameMap.get(paramString);
    if (fieldType != null)
      return fieldType; 
    for (FieldType fieldType : this.fieldTypes) {
      if (fieldType.getFieldName().equals(paramString))
        throw new IllegalArgumentException("You should use columnName '" + fieldType.getColumnName() + "' for table " + this.tableName + " instead of fieldName '" + fieldType.getFieldName() + "'"); 
    } 
    throw new IllegalArgumentException("Unknown column name '" + paramString + "' in table " + this.tableName);
  }
  
  public FieldType[] getFieldTypes() {
    return this.fieldTypes;
  }
  
  public FieldType[] getForeignCollections() {
    return this.foreignCollections;
  }
  
  public FieldType getIdField() {
    return this.idField;
  }
  
  public String getTableName() {
    return this.tableName;
  }
  
  public boolean hasColumnName(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: getfield fieldTypes : [Lcom/j256/ormlite/field/FieldType;
    //   4: astore_2
    //   5: aload_2
    //   6: arraylength
    //   7: istore_3
    //   8: iconst_0
    //   9: istore #4
    //   11: iload #4
    //   13: iload_3
    //   14: if_icmpge -> 43
    //   17: aload_2
    //   18: iload #4
    //   20: aaload
    //   21: invokevirtual getColumnName : ()Ljava/lang/String;
    //   24: aload_1
    //   25: invokevirtual equals : (Ljava/lang/Object;)Z
    //   28: ifeq -> 37
    //   31: iconst_1
    //   32: istore #5
    //   34: iload #5
    //   36: ireturn
    //   37: iinc #4, 1
    //   40: goto -> 11
    //   43: iconst_0
    //   44: istore #5
    //   46: goto -> 34
  }
  
  public boolean isForeignAutoCreate() {
    return this.foreignAutoCreate;
  }
  
  public boolean isUpdatable() {
    boolean bool = true;
    if (this.idField == null || this.fieldTypes.length <= 1)
      bool = false; 
    return bool;
  }
  
  public String objectToString(T paramT) {
    StringBuilder stringBuilder = new StringBuilder(64);
    stringBuilder.append(paramT.getClass().getSimpleName());
    FieldType[] arrayOfFieldType = this.fieldTypes;
    int i = arrayOfFieldType.length;
    byte b = 0;
    while (b < i) {
      FieldType fieldType = arrayOfFieldType[b];
      stringBuilder.append(' ').append(fieldType.getColumnName()).append("=");
      try {
        stringBuilder.append(fieldType.extractJavaFieldValue(paramT));
        b++;
      } catch (Exception exception) {
        throw new IllegalStateException("Could not generate toString of field " + fieldType, exception);
      } 
    } 
    return stringBuilder.toString();
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/table/TableInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */