package com.j256.ormlite.table;

import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.field.DatabaseFieldConfig;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.misc.JavaxPersistence;
import com.j256.ormlite.support.ConnectionSource;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DatabaseTableConfig<T> {
  private Constructor<T> constructor;
  
  private Class<T> dataClass;
  
  private List<DatabaseFieldConfig> fieldConfigs;
  
  private FieldType[] fieldTypes;
  
  private String tableName;
  
  public DatabaseTableConfig() {}
  
  public DatabaseTableConfig(Class<T> paramClass, String paramString, List<DatabaseFieldConfig> paramList) {
    this.dataClass = paramClass;
    this.tableName = paramString;
    this.fieldConfigs = paramList;
  }
  
  private DatabaseTableConfig(Class<T> paramClass, String paramString, FieldType[] paramArrayOfFieldType) {
    this.dataClass = paramClass;
    this.tableName = paramString;
    this.fieldTypes = paramArrayOfFieldType;
  }
  
  public DatabaseTableConfig(Class<T> paramClass, List<DatabaseFieldConfig> paramList) {
    this(paramClass, extractTableName(paramClass), paramList);
  }
  
  private FieldType[] convertFieldConfigs(ConnectionSource paramConnectionSource, String paramString, List<DatabaseFieldConfig> paramList) throws SQLException {
    ArrayList<Object> arrayList = new ArrayList();
    for (DatabaseFieldConfig databaseFieldConfig : paramList) {
      Object object = null;
      Class<T> clazz = this.dataClass;
      while (true) {
        Object object1 = object;
        arrayList.add(SYNTHETIC_LOCAL_VARIABLE_8);
      } 
    } 
    if (arrayList.isEmpty())
      throw new SQLException("No fields were configured for class " + this.dataClass); 
    return arrayList.<FieldType>toArray(new FieldType[arrayList.size()]);
  }
  
  private static <T> FieldType[] extractFieldTypes(ConnectionSource paramConnectionSource, Class<T> paramClass, String paramString) throws SQLException {
    ArrayList<FieldType> arrayList = new ArrayList();
    for (Class<T> clazz = paramClass; clazz != null; clazz = (Class)clazz.getSuperclass()) {
      Field[] arrayOfField = clazz.getDeclaredFields();
      int i = arrayOfField.length;
      for (byte b = 0; b < i; b++) {
        FieldType fieldType = FieldType.createFieldType(paramConnectionSource, paramString, arrayOfField[b], paramClass);
        if (fieldType != null)
          arrayList.add(fieldType); 
      } 
    } 
    if (arrayList.isEmpty())
      throw new IllegalArgumentException("No fields have a " + DatabaseField.class.getSimpleName() + " annotation in " + paramClass); 
    return arrayList.<FieldType>toArray(new FieldType[arrayList.size()]);
  }
  
  public static <T> String extractTableName(Class<T> paramClass) {
    DatabaseTable databaseTable = paramClass.<DatabaseTable>getAnnotation(DatabaseTable.class);
    if (databaseTable != null && databaseTable.tableName() != null && databaseTable.tableName().length() > 0)
      return databaseTable.tableName(); 
    String str2 = JavaxPersistence.getEntityName(paramClass);
    String str1 = str2;
    if (str2 == null)
      str1 = paramClass.getSimpleName().toLowerCase(); 
    return str1;
  }
  
  public static <T> Constructor<T> findNoArgConstructor(Class<T> paramClass) {
    try {
      for (Constructor<T> constructor : (Constructor[])paramClass.getDeclaredConstructors()) {
        if ((constructor.getParameterTypes()).length == 0) {
          if (!constructor.isAccessible())
            try {
              constructor.setAccessible(true);
              return constructor;
            } catch (SecurityException securityException) {
              throw new IllegalArgumentException("Could not open access to constructor for " + paramClass);
            }  
          return constructor;
        } 
      } 
    } catch (Exception exception) {
      throw new IllegalArgumentException("Can't lookup declared constructors for " + paramClass, exception);
    } 
    if (paramClass.getEnclosingClass() == null)
      throw new IllegalArgumentException("Can't find a no-arg constructor for " + paramClass); 
    throw new IllegalArgumentException("Can't find a no-arg constructor for " + paramClass + ".  Missing static on inner class?");
  }
  
  public static <T> DatabaseTableConfig<T> fromClass(ConnectionSource paramConnectionSource, Class<T> paramClass) throws SQLException {
    String str1 = extractTableName(paramClass);
    String str2 = str1;
    if (paramConnectionSource.getDatabaseType().isEntityNamesMustBeUpCase())
      str2 = str1.toUpperCase(); 
    return new DatabaseTableConfig<T>(paramClass, str2, extractFieldTypes(paramConnectionSource, paramClass, str2));
  }
  
  public void extractFieldTypes(ConnectionSource paramConnectionSource) throws SQLException {
    if (this.fieldTypes == null) {
      if (this.fieldConfigs == null) {
        this.fieldTypes = extractFieldTypes(paramConnectionSource, this.dataClass, this.tableName);
        return;
      } 
    } else {
      return;
    } 
    this.fieldTypes = convertFieldConfigs(paramConnectionSource, this.tableName, this.fieldConfigs);
  }
  
  public Constructor<T> getConstructor() {
    if (this.constructor == null)
      this.constructor = findNoArgConstructor(this.dataClass); 
    return this.constructor;
  }
  
  public Class<T> getDataClass() {
    return this.dataClass;
  }
  
  public List<DatabaseFieldConfig> getFieldConfigs() {
    return this.fieldConfigs;
  }
  
  public FieldType[] getFieldTypes(DatabaseType paramDatabaseType) throws SQLException {
    if (this.fieldTypes == null)
      throw new SQLException("Field types have not been extracted in table config"); 
    return this.fieldTypes;
  }
  
  public String getTableName() {
    return this.tableName;
  }
  
  public void initialize() {
    if (this.dataClass == null)
      throw new IllegalStateException("dataClass was never set on " + getClass().getSimpleName()); 
    if (this.tableName == null)
      this.tableName = extractTableName(this.dataClass); 
  }
  
  public void setConstructor(Constructor<T> paramConstructor) {
    this.constructor = paramConstructor;
  }
  
  public void setDataClass(Class<T> paramClass) {
    this.dataClass = paramClass;
  }
  
  public void setFieldConfigs(List<DatabaseFieldConfig> paramList) {
    this.fieldConfigs = paramList;
  }
  
  public void setTableName(String paramString) {
    this.tableName = paramString;
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/table/DatabaseTableConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */