package com.j256.ormlite.table;

import com.j256.ormlite.dao.BaseDaoImpl;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.logger.Logger;
import com.j256.ormlite.logger.LoggerFactory;
import com.j256.ormlite.misc.SqlExceptionUtil;
import com.j256.ormlite.stmt.StatementBuilder;
import com.j256.ormlite.support.CompiledStatement;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.support.DatabaseConnection;
import com.j256.ormlite.support.DatabaseResults;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class TableUtils {
  private static Logger logger = LoggerFactory.getLogger(TableUtils.class);
  
  private static final FieldType[] noFieldTypes = new FieldType[0];
  
  private static <T, ID> void addCreateIndexStatements(DatabaseType paramDatabaseType, TableInfo<T, ID> paramTableInfo, List<String> paramList, boolean paramBoolean1, boolean paramBoolean2) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (FieldType fieldType : paramTableInfo.getFieldTypes()) {
      String str;
      if (paramBoolean2) {
        str = fieldType.getUniqueIndexName();
      } else {
        str = fieldType.getIndexName();
      } 
      if (str != null) {
        List<String> list1 = (List)hashMap.get(str);
        List<String> list2 = list1;
        if (list1 == null) {
          list2 = new ArrayList();
          hashMap.put(str, list2);
        } 
        list2.add(fieldType.getColumnName());
      } 
    } 
    StringBuilder stringBuilder = new StringBuilder(128);
    for (Map.Entry<Object, Object> entry : hashMap.entrySet()) {
      logger.info("creating index '{}' for table '{}", entry.getKey(), paramTableInfo.getTableName());
      stringBuilder.append("CREATE ");
      if (paramBoolean2)
        stringBuilder.append("UNIQUE "); 
      stringBuilder.append("INDEX ");
      if (paramBoolean1 && paramDatabaseType.isCreateIndexIfNotExistsSupported())
        stringBuilder.append("IF NOT EXISTS "); 
      paramDatabaseType.appendEscapedEntityName(stringBuilder, (String)entry.getKey());
      stringBuilder.append(" ON ");
      paramDatabaseType.appendEscapedEntityName(stringBuilder, paramTableInfo.getTableName());
      stringBuilder.append(" ( ");
      boolean bool = true;
      for (String str : entry.getValue()) {
        if (bool) {
          bool = false;
        } else {
          stringBuilder.append(", ");
        } 
        paramDatabaseType.appendEscapedEntityName(stringBuilder, str);
      } 
      stringBuilder.append(" )");
      paramList.add(stringBuilder.toString());
      stringBuilder.setLength(0);
    } 
  }
  
  private static <T, ID> List<String> addCreateTableStatements(ConnectionSource paramConnectionSource, TableInfo<T, ID> paramTableInfo, boolean paramBoolean) throws SQLException {
    ArrayList<String> arrayList1 = new ArrayList();
    ArrayList<String> arrayList2 = new ArrayList();
    addCreateTableStatements(paramConnectionSource.getDatabaseType(), paramTableInfo, arrayList1, arrayList2, paramBoolean);
    return arrayList1;
  }
  
  private static <T, ID> void addCreateTableStatements(DatabaseType paramDatabaseType, TableInfo<T, ID> paramTableInfo, List<String> paramList1, List<String> paramList2, boolean paramBoolean) throws SQLException {
    StringBuilder stringBuilder = new StringBuilder(256);
    stringBuilder.append("CREATE TABLE ");
    if (paramBoolean && paramDatabaseType.isCreateIfNotExistsSupported())
      stringBuilder.append("IF NOT EXISTS "); 
    paramDatabaseType.appendEscapedEntityName(stringBuilder, paramTableInfo.getTableName());
    stringBuilder.append(" (");
    ArrayList arrayList = new ArrayList();
    ArrayList<? extends String> arrayList1 = new ArrayList();
    ArrayList<? extends String> arrayList2 = new ArrayList();
    boolean bool = true;
    for (FieldType fieldType : paramTableInfo.getFieldTypes()) {
      if (!fieldType.isForeignCollection()) {
        if (bool) {
          bool = false;
        } else {
          stringBuilder.append(", ");
        } 
        String str = fieldType.getColumnDefinition();
        if (str == null) {
          paramDatabaseType.appendColumnArg(paramTableInfo.getTableName(), stringBuilder, fieldType, arrayList, arrayList1, arrayList2, paramList2);
        } else {
          paramDatabaseType.appendEscapedEntityName(stringBuilder, fieldType.getColumnName());
          stringBuilder.append(' ').append(str).append(' ');
        } 
      } 
    } 
    paramDatabaseType.addPrimaryKeySql(paramTableInfo.getFieldTypes(), arrayList, arrayList1, arrayList2, paramList2);
    paramDatabaseType.addUniqueComboSql(paramTableInfo.getFieldTypes(), arrayList, arrayList1, arrayList2, paramList2);
    for (String str : arrayList)
      stringBuilder.append(", ").append(str); 
    stringBuilder.append(") ");
    paramDatabaseType.appendCreateTableSuffix(stringBuilder);
    paramList1.addAll(arrayList1);
    paramList1.add(stringBuilder.toString());
    paramList1.addAll(arrayList2);
    addCreateIndexStatements(paramDatabaseType, paramTableInfo, paramList1, paramBoolean, false);
    addCreateIndexStatements(paramDatabaseType, paramTableInfo, paramList1, paramBoolean, true);
  }
  
  private static <T, ID> void addDropIndexStatements(DatabaseType paramDatabaseType, TableInfo<T, ID> paramTableInfo, List<String> paramList) {
    HashSet<String> hashSet = new HashSet();
    for (FieldType fieldType : paramTableInfo.getFieldTypes()) {
      String str2 = fieldType.getIndexName();
      if (str2 != null)
        hashSet.add(str2); 
      String str1 = fieldType.getUniqueIndexName();
      if (str1 != null)
        hashSet.add(str1); 
    } 
    StringBuilder stringBuilder = new StringBuilder(48);
    for (String str : hashSet) {
      logger.info("dropping index '{}' for table '{}", str, paramTableInfo.getTableName());
      stringBuilder.append("DROP INDEX ");
      paramDatabaseType.appendEscapedEntityName(stringBuilder, str);
      paramList.add(stringBuilder.toString());
      stringBuilder.setLength(0);
    } 
  }
  
  private static <T, ID> void addDropTableStatements(DatabaseType paramDatabaseType, TableInfo<T, ID> paramTableInfo, List<String> paramList) {
    ArrayList<? extends String> arrayList1 = new ArrayList();
    ArrayList<? extends String> arrayList2 = new ArrayList();
    FieldType[] arrayOfFieldType = paramTableInfo.getFieldTypes();
    int i = arrayOfFieldType.length;
    for (byte b = 0; b < i; b++)
      paramDatabaseType.dropColumnArg(arrayOfFieldType[b], arrayList1, arrayList2); 
    StringBuilder stringBuilder = new StringBuilder(64);
    stringBuilder.append("DROP TABLE ");
    paramDatabaseType.appendEscapedEntityName(stringBuilder, paramTableInfo.getTableName());
    stringBuilder.append(' ');
    paramList.addAll(arrayList1);
    paramList.add(stringBuilder.toString());
    paramList.addAll(arrayList2);
  }
  
  public static <T> int clearTable(ConnectionSource paramConnectionSource, DatabaseTableConfig<T> paramDatabaseTableConfig) throws SQLException {
    return clearTable(paramConnectionSource, paramDatabaseTableConfig.getTableName());
  }
  
  public static <T> int clearTable(ConnectionSource paramConnectionSource, Class<T> paramClass) throws SQLException {
    String str2 = DatabaseTableConfig.extractTableName(paramClass);
    String str1 = str2;
    if (paramConnectionSource.getDatabaseType().isEntityNamesMustBeUpCase())
      str1 = str2.toUpperCase(); 
    return clearTable(paramConnectionSource, str1);
  }
  
  private static <T> int clearTable(ConnectionSource paramConnectionSource, String paramString) throws SQLException {
    CompiledStatement compiledStatement;
    DatabaseType databaseType = paramConnectionSource.getDatabaseType();
    StringBuilder stringBuilder = new StringBuilder(48);
    if (databaseType.isTruncateSupported()) {
      stringBuilder.append("TRUNCATE TABLE ");
    } else {
      stringBuilder.append("DELETE FROM ");
    } 
    databaseType.appendEscapedEntityName(stringBuilder, paramString);
    null = stringBuilder.toString();
    logger.info("clearing table '{}' with '{}", paramString, null);
    paramString = null;
    DatabaseConnection databaseConnection = paramConnectionSource.getReadWriteConnection();
    try {
      CompiledStatement compiledStatement1 = databaseConnection.compileStatement(null, StatementBuilder.StatementType.EXECUTE, noFieldTypes);
      compiledStatement = compiledStatement1;
      return compiledStatement1.runExecute();
    } finally {
      if (compiledStatement != null)
        compiledStatement.close(); 
      paramConnectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public static <T> int createTable(ConnectionSource paramConnectionSource, DatabaseTableConfig<T> paramDatabaseTableConfig) throws SQLException {
    return createTable(paramConnectionSource, paramDatabaseTableConfig, false);
  }
  
  private static <T, ID> int createTable(ConnectionSource paramConnectionSource, DatabaseTableConfig<T> paramDatabaseTableConfig, boolean paramBoolean) throws SQLException {
    Dao dao = DaoManager.createDao(paramConnectionSource, paramDatabaseTableConfig);
    if (dao instanceof BaseDaoImpl)
      return doCreateTable(paramConnectionSource, ((BaseDaoImpl)dao).getTableInfo(), paramBoolean); 
    paramDatabaseTableConfig.extractFieldTypes(paramConnectionSource);
    return doCreateTable(paramConnectionSource, new TableInfo<Object, Object>(paramConnectionSource.getDatabaseType(), null, paramDatabaseTableConfig), paramBoolean);
  }
  
  public static <T> int createTable(ConnectionSource paramConnectionSource, Class<T> paramClass) throws SQLException {
    return createTable(paramConnectionSource, paramClass, false);
  }
  
  private static <T, ID> int createTable(ConnectionSource paramConnectionSource, Class<T> paramClass, boolean paramBoolean) throws SQLException {
    Dao dao = DaoManager.createDao(paramConnectionSource, paramClass);
    return (dao instanceof BaseDaoImpl) ? doCreateTable(paramConnectionSource, ((BaseDaoImpl)dao).getTableInfo(), paramBoolean) : doCreateTable(paramConnectionSource, new TableInfo<Object, Object>(paramConnectionSource, null, paramClass), paramBoolean);
  }
  
  public static <T> int createTableIfNotExists(ConnectionSource paramConnectionSource, DatabaseTableConfig<T> paramDatabaseTableConfig) throws SQLException {
    return createTable(paramConnectionSource, paramDatabaseTableConfig, true);
  }
  
  public static <T> int createTableIfNotExists(ConnectionSource paramConnectionSource, Class<T> paramClass) throws SQLException {
    return createTable(paramConnectionSource, paramClass, true);
  }
  
  private static <T, ID> int doCreateTable(ConnectionSource paramConnectionSource, TableInfo<T, ID> paramTableInfo, boolean paramBoolean) throws SQLException {
    null = paramConnectionSource.getDatabaseType();
    logger.info("creating table '{}'", paramTableInfo.getTableName());
    ArrayList<String> arrayList1 = new ArrayList();
    ArrayList<String> arrayList2 = new ArrayList();
    addCreateTableStatements(null, paramTableInfo, arrayList1, arrayList2, paramBoolean);
    DatabaseConnection databaseConnection = paramConnectionSource.getReadWriteConnection();
    try {
      int i = doStatements(databaseConnection, "create", arrayList1, false, null.isCreateTableReturnsNegative(), null.isCreateTableReturnsZero());
      int j = doCreateTestQueries(databaseConnection, null, arrayList2);
      return i + j;
    } finally {
      paramConnectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  private static int doCreateTestQueries(DatabaseConnection paramDatabaseConnection, DatabaseType paramDatabaseType, List<String> paramList) throws SQLException {
    byte b = 0;
    for (String str : paramList) {
      CompiledStatement compiledStatement1;
      CompiledStatement compiledStatement2;
      paramList = null;
      paramDatabaseType = null;
      try {
        CompiledStatement compiledStatement = paramDatabaseConnection.compileStatement(str, StatementBuilder.StatementType.SELECT, noFieldTypes);
        compiledStatement1 = compiledStatement;
        compiledStatement2 = compiledStatement;
        DatabaseResults databaseResults = compiledStatement.runQuery(null);
        byte b1 = 0;
        compiledStatement1 = compiledStatement;
        compiledStatement2 = compiledStatement;
        boolean bool;
        for (bool = databaseResults.first(); bool; bool = databaseResults.next()) {
          b1++;
          compiledStatement1 = compiledStatement;
          compiledStatement2 = compiledStatement;
        } 
        compiledStatement1 = compiledStatement;
        compiledStatement2 = compiledStatement;
        logger.info("executing create table after-query got {} results: {}", Integer.valueOf(b1), str);
        if (compiledStatement != null)
          compiledStatement.close(); 
      } catch (SQLException sQLException) {
        compiledStatement2 = compiledStatement1;
        StringBuilder stringBuilder = new StringBuilder();
        compiledStatement2 = compiledStatement1;
        this();
        compiledStatement2 = compiledStatement1;
        throw SqlExceptionUtil.create(stringBuilder.append("executing create table after-query failed: ").append(str).toString(), sQLException);
      } finally {
        if (compiledStatement2 != null)
          compiledStatement2.close(); 
      } 
    } 
    return b;
  }
  
  private static <T, ID> int doDropTable(DatabaseType paramDatabaseType, ConnectionSource paramConnectionSource, TableInfo<T, ID> paramTableInfo, boolean paramBoolean) throws SQLException {
    logger.info("dropping table '{}'", paramTableInfo.getTableName());
    ArrayList<String> arrayList = new ArrayList();
    addDropIndexStatements(paramDatabaseType, paramTableInfo, arrayList);
    addDropTableStatements(paramDatabaseType, paramTableInfo, arrayList);
    DatabaseConnection databaseConnection = paramConnectionSource.getReadWriteConnection();
    try {
      return doStatements(databaseConnection, "drop", arrayList, paramBoolean, paramDatabaseType.isCreateTableReturnsNegative(), false);
    } finally {
      paramConnectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  private static int doStatements(DatabaseConnection paramDatabaseConnection, String paramString, Collection<String> paramCollection, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) throws SQLException {
    // Byte code:
    //   0: iconst_0
    //   1: istore #6
    //   3: aload_2
    //   4: invokeinterface iterator : ()Ljava/util/Iterator;
    //   9: astore #7
    //   11: aload #7
    //   13: invokeinterface hasNext : ()Z
    //   18: ifeq -> 338
    //   21: aload #7
    //   23: invokeinterface next : ()Ljava/lang/Object;
    //   28: checkcast java/lang/String
    //   31: astore #8
    //   33: iconst_0
    //   34: istore #9
    //   36: aconst_null
    //   37: astore #10
    //   39: aconst_null
    //   40: astore_2
    //   41: iload #9
    //   43: istore #11
    //   45: aload_0
    //   46: aload #8
    //   48: getstatic com/j256/ormlite/stmt/StatementBuilder$StatementType.EXECUTE : Lcom/j256/ormlite/stmt/StatementBuilder$StatementType;
    //   51: getstatic com/j256/ormlite/table/TableUtils.noFieldTypes : [Lcom/j256/ormlite/field/FieldType;
    //   54: invokeinterface compileStatement : (Ljava/lang/String;Lcom/j256/ormlite/stmt/StatementBuilder$StatementType;[Lcom/j256/ormlite/field/FieldType;)Lcom/j256/ormlite/support/CompiledStatement;
    //   59: astore #12
    //   61: aload #12
    //   63: astore_2
    //   64: iload #9
    //   66: istore #11
    //   68: aload #12
    //   70: astore #10
    //   72: aload #12
    //   74: invokeinterface runExecute : ()I
    //   79: istore #13
    //   81: aload #12
    //   83: astore_2
    //   84: iload #13
    //   86: istore #11
    //   88: aload #12
    //   90: astore #10
    //   92: getstatic com/j256/ormlite/table/TableUtils.logger : Lcom/j256/ormlite/logger/Logger;
    //   95: ldc_w 'executed {} table statement changed {} rows: {}'
    //   98: aload_1
    //   99: iload #13
    //   101: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   104: aload #8
    //   106: invokevirtual info : (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   109: iload #13
    //   111: istore #9
    //   113: aload #12
    //   115: ifnull -> 129
    //   118: aload #12
    //   120: invokeinterface close : ()V
    //   125: iload #13
    //   127: istore #9
    //   129: iload #9
    //   131: ifge -> 282
    //   134: iload #4
    //   136: ifne -> 332
    //   139: new java/sql/SQLException
    //   142: dup
    //   143: new java/lang/StringBuilder
    //   146: dup
    //   147: invokespecial <init> : ()V
    //   150: ldc_w 'SQL statement '
    //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: aload #8
    //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: ldc_w ' updated '
    //   164: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: iload #9
    //   169: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   172: ldc_w ' rows, we were expecting >= 0'
    //   175: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   178: invokevirtual toString : ()Ljava/lang/String;
    //   181: invokespecial <init> : (Ljava/lang/String;)V
    //   184: athrow
    //   185: astore #12
    //   187: iload_3
    //   188: ifeq -> 229
    //   191: aload_2
    //   192: astore #10
    //   194: getstatic com/j256/ormlite/table/TableUtils.logger : Lcom/j256/ormlite/logger/Logger;
    //   197: ldc_w 'ignoring {} error '{}' for statement: {}'
    //   200: aload_1
    //   201: aload #12
    //   203: aload #8
    //   205: invokevirtual info : (Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   208: iload #11
    //   210: istore #9
    //   212: aload_2
    //   213: ifnull -> 129
    //   216: aload_2
    //   217: invokeinterface close : ()V
    //   222: iload #11
    //   224: istore #9
    //   226: goto -> 129
    //   229: aload_2
    //   230: astore #10
    //   232: new java/lang/StringBuilder
    //   235: astore_0
    //   236: aload_2
    //   237: astore #10
    //   239: aload_0
    //   240: invokespecial <init> : ()V
    //   243: aload_2
    //   244: astore #10
    //   246: aload_0
    //   247: ldc_w 'SQL statement failed: '
    //   250: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: aload #8
    //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   258: invokevirtual toString : ()Ljava/lang/String;
    //   261: aload #12
    //   263: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   266: athrow
    //   267: astore_0
    //   268: aload #10
    //   270: ifnull -> 280
    //   273: aload #10
    //   275: invokeinterface close : ()V
    //   280: aload_0
    //   281: athrow
    //   282: iload #9
    //   284: ifle -> 332
    //   287: iload #5
    //   289: ifeq -> 332
    //   292: new java/sql/SQLException
    //   295: dup
    //   296: new java/lang/StringBuilder
    //   299: dup
    //   300: invokespecial <init> : ()V
    //   303: ldc_w 'SQL statement updated '
    //   306: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   309: iload #9
    //   311: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   314: ldc_w ' rows, we were expecting == 0: '
    //   317: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   320: aload #8
    //   322: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   325: invokevirtual toString : ()Ljava/lang/String;
    //   328: invokespecial <init> : (Ljava/lang/String;)V
    //   331: athrow
    //   332: iinc #6, 1
    //   335: goto -> 11
    //   338: iload #6
    //   340: ireturn
    // Exception table:
    //   from	to	target	type
    //   45	61	185	java/sql/SQLException
    //   45	61	267	finally
    //   72	81	185	java/sql/SQLException
    //   72	81	267	finally
    //   92	109	185	java/sql/SQLException
    //   92	109	267	finally
    //   194	208	267	finally
    //   232	236	267	finally
    //   239	243	267	finally
    //   246	267	267	finally
  }
  
  public static <T, ID> int dropTable(ConnectionSource paramConnectionSource, DatabaseTableConfig<T> paramDatabaseTableConfig, boolean paramBoolean) throws SQLException {
    DatabaseType databaseType = paramConnectionSource.getDatabaseType();
    Dao dao = DaoManager.createDao(paramConnectionSource, paramDatabaseTableConfig);
    if (dao instanceof BaseDaoImpl)
      return doDropTable(databaseType, paramConnectionSource, ((BaseDaoImpl)dao).getTableInfo(), paramBoolean); 
    paramDatabaseTableConfig.extractFieldTypes(paramConnectionSource);
    return doDropTable(databaseType, paramConnectionSource, new TableInfo<Object, Object>(databaseType, null, paramDatabaseTableConfig), paramBoolean);
  }
  
  public static <T, ID> int dropTable(ConnectionSource paramConnectionSource, Class<T> paramClass, boolean paramBoolean) throws SQLException {
    DatabaseType databaseType = paramConnectionSource.getDatabaseType();
    Dao dao = DaoManager.createDao(paramConnectionSource, paramClass);
    return (dao instanceof BaseDaoImpl) ? doDropTable(databaseType, paramConnectionSource, ((BaseDaoImpl)dao).getTableInfo(), paramBoolean) : doDropTable(databaseType, paramConnectionSource, new TableInfo<Object, Object>(paramConnectionSource, null, paramClass), paramBoolean);
  }
  
  public static <T, ID> List<String> getCreateTableStatements(ConnectionSource paramConnectionSource, DatabaseTableConfig<T> paramDatabaseTableConfig) throws SQLException {
    Dao dao = DaoManager.createDao(paramConnectionSource, paramDatabaseTableConfig);
    if (dao instanceof BaseDaoImpl)
      return addCreateTableStatements(paramConnectionSource, ((BaseDaoImpl)dao).getTableInfo(), false); 
    paramDatabaseTableConfig.extractFieldTypes(paramConnectionSource);
    return addCreateTableStatements(paramConnectionSource, new TableInfo<Object, Object>(paramConnectionSource.getDatabaseType(), null, paramDatabaseTableConfig), false);
  }
  
  public static <T, ID> List<String> getCreateTableStatements(ConnectionSource paramConnectionSource, Class<T> paramClass) throws SQLException {
    Dao dao = DaoManager.createDao(paramConnectionSource, paramClass);
    return (dao instanceof BaseDaoImpl) ? addCreateTableStatements(paramConnectionSource, ((BaseDaoImpl)dao).getTableInfo(), false) : addCreateTableStatements(paramConnectionSource, new TableInfo<Object, Object>(paramConnectionSource, null, paramClass), false);
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/table/TableUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */