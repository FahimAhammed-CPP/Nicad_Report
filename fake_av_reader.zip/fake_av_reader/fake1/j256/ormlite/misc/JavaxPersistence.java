package com.j256.ormlite.misc;

import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.field.DatabaseFieldConfig;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.sql.SQLException;

public class JavaxPersistence {
  public static DatabaseFieldConfig createFieldConfig(DatabaseType paramDatabaseType, Field paramField) throws SQLException {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aconst_null
    //   3: astore_3
    //   4: aconst_null
    //   5: astore #4
    //   7: aconst_null
    //   8: astore #5
    //   10: aconst_null
    //   11: astore #6
    //   13: aconst_null
    //   14: astore #7
    //   16: aconst_null
    //   17: astore #8
    //   19: aconst_null
    //   20: astore #9
    //   22: aconst_null
    //   23: astore #10
    //   25: aload_1
    //   26: invokevirtual getAnnotations : ()[Ljava/lang/annotation/Annotation;
    //   29: astore #11
    //   31: aload #11
    //   33: arraylength
    //   34: istore #12
    //   36: iconst_0
    //   37: istore #13
    //   39: iload #13
    //   41: iload #12
    //   43: if_icmpge -> 219
    //   46: aload #11
    //   48: iload #13
    //   50: aaload
    //   51: astore #14
    //   53: aload #14
    //   55: invokeinterface annotationType : ()Ljava/lang/Class;
    //   60: astore #15
    //   62: aload #15
    //   64: invokevirtual getName : ()Ljava/lang/String;
    //   67: ldc 'javax.persistence.Column'
    //   69: invokevirtual equals : (Ljava/lang/Object;)Z
    //   72: ifeq -> 78
    //   75: aload #14
    //   77: astore_2
    //   78: aload #15
    //   80: invokevirtual getName : ()Ljava/lang/String;
    //   83: ldc 'javax.persistence.Basic'
    //   85: invokevirtual equals : (Ljava/lang/Object;)Z
    //   88: ifeq -> 94
    //   91: aload #14
    //   93: astore_3
    //   94: aload #15
    //   96: invokevirtual getName : ()Ljava/lang/String;
    //   99: ldc 'javax.persistence.Id'
    //   101: invokevirtual equals : (Ljava/lang/Object;)Z
    //   104: ifeq -> 111
    //   107: aload #14
    //   109: astore #4
    //   111: aload #15
    //   113: invokevirtual getName : ()Ljava/lang/String;
    //   116: ldc 'javax.persistence.GeneratedValue'
    //   118: invokevirtual equals : (Ljava/lang/Object;)Z
    //   121: ifeq -> 128
    //   124: aload #14
    //   126: astore #5
    //   128: aload #15
    //   130: invokevirtual getName : ()Ljava/lang/String;
    //   133: ldc 'javax.persistence.OneToOne'
    //   135: invokevirtual equals : (Ljava/lang/Object;)Z
    //   138: ifeq -> 145
    //   141: aload #14
    //   143: astore #6
    //   145: aload #15
    //   147: invokevirtual getName : ()Ljava/lang/String;
    //   150: ldc 'javax.persistence.ManyToOne'
    //   152: invokevirtual equals : (Ljava/lang/Object;)Z
    //   155: ifeq -> 162
    //   158: aload #14
    //   160: astore #7
    //   162: aload #15
    //   164: invokevirtual getName : ()Ljava/lang/String;
    //   167: ldc 'javax.persistence.JoinColumn'
    //   169: invokevirtual equals : (Ljava/lang/Object;)Z
    //   172: ifeq -> 179
    //   175: aload #14
    //   177: astore #8
    //   179: aload #15
    //   181: invokevirtual getName : ()Ljava/lang/String;
    //   184: ldc 'javax.persistence.Enumerated'
    //   186: invokevirtual equals : (Ljava/lang/Object;)Z
    //   189: ifeq -> 196
    //   192: aload #14
    //   194: astore #9
    //   196: aload #15
    //   198: invokevirtual getName : ()Ljava/lang/String;
    //   201: ldc 'javax.persistence.Version'
    //   203: invokevirtual equals : (Ljava/lang/Object;)Z
    //   206: ifeq -> 213
    //   209: aload #14
    //   211: astore #10
    //   213: iinc #13, 1
    //   216: goto -> 39
    //   219: aload_2
    //   220: ifnonnull -> 256
    //   223: aload_3
    //   224: ifnonnull -> 256
    //   227: aload #4
    //   229: ifnonnull -> 256
    //   232: aload #6
    //   234: ifnonnull -> 256
    //   237: aload #7
    //   239: ifnonnull -> 256
    //   242: aload #9
    //   244: ifnonnull -> 256
    //   247: aload #10
    //   249: ifnonnull -> 256
    //   252: aconst_null
    //   253: astore_0
    //   254: aload_0
    //   255: areturn
    //   256: new com/j256/ormlite/field/DatabaseFieldConfig
    //   259: dup
    //   260: invokespecial <init> : ()V
    //   263: astore #11
    //   265: aload_1
    //   266: invokevirtual getName : ()Ljava/lang/String;
    //   269: astore #15
    //   271: aload #15
    //   273: astore #14
    //   275: aload_0
    //   276: invokeinterface isEntityNamesMustBeUpCase : ()Z
    //   281: ifeq -> 291
    //   284: aload #15
    //   286: invokevirtual toUpperCase : ()Ljava/lang/String;
    //   289: astore #14
    //   291: aload #11
    //   293: aload #14
    //   295: invokevirtual setFieldName : (Ljava/lang/String;)V
    //   298: aload_2
    //   299: ifnull -> 494
    //   302: aload_2
    //   303: invokevirtual getClass : ()Ljava/lang/Class;
    //   306: ldc 'name'
    //   308: iconst_0
    //   309: anewarray java/lang/Class
    //   312: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   315: aload_2
    //   316: iconst_0
    //   317: anewarray java/lang/Object
    //   320: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   323: checkcast java/lang/String
    //   326: astore_0
    //   327: aload_0
    //   328: ifnull -> 344
    //   331: aload_0
    //   332: invokevirtual length : ()I
    //   335: ifle -> 344
    //   338: aload #11
    //   340: aload_0
    //   341: invokevirtual setColumnName : (Ljava/lang/String;)V
    //   344: aload_2
    //   345: invokevirtual getClass : ()Ljava/lang/Class;
    //   348: ldc 'columnDefinition'
    //   350: iconst_0
    //   351: anewarray java/lang/Class
    //   354: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   357: aload_2
    //   358: iconst_0
    //   359: anewarray java/lang/Object
    //   362: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   365: checkcast java/lang/String
    //   368: astore_0
    //   369: aload_0
    //   370: ifnull -> 386
    //   373: aload_0
    //   374: invokevirtual length : ()I
    //   377: ifle -> 386
    //   380: aload #11
    //   382: aload_0
    //   383: invokevirtual setColumnDefinition : (Ljava/lang/String;)V
    //   386: aload #11
    //   388: aload_2
    //   389: invokevirtual getClass : ()Ljava/lang/Class;
    //   392: ldc 'length'
    //   394: iconst_0
    //   395: anewarray java/lang/Class
    //   398: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   401: aload_2
    //   402: iconst_0
    //   403: anewarray java/lang/Object
    //   406: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   409: checkcast java/lang/Integer
    //   412: invokevirtual intValue : ()I
    //   415: invokevirtual setWidth : (I)V
    //   418: aload_2
    //   419: invokevirtual getClass : ()Ljava/lang/Class;
    //   422: ldc 'nullable'
    //   424: iconst_0
    //   425: anewarray java/lang/Class
    //   428: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   431: aload_2
    //   432: iconst_0
    //   433: anewarray java/lang/Object
    //   436: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   439: checkcast java/lang/Boolean
    //   442: astore_0
    //   443: aload_0
    //   444: ifnull -> 456
    //   447: aload #11
    //   449: aload_0
    //   450: invokevirtual booleanValue : ()Z
    //   453: invokevirtual setCanBeNull : (Z)V
    //   456: aload_2
    //   457: invokevirtual getClass : ()Ljava/lang/Class;
    //   460: ldc 'unique'
    //   462: iconst_0
    //   463: anewarray java/lang/Class
    //   466: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   469: aload_2
    //   470: iconst_0
    //   471: anewarray java/lang/Object
    //   474: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   477: checkcast java/lang/Boolean
    //   480: astore_0
    //   481: aload_0
    //   482: ifnull -> 494
    //   485: aload #11
    //   487: aload_0
    //   488: invokevirtual booleanValue : ()Z
    //   491: invokevirtual setUnique : (Z)V
    //   494: aload_3
    //   495: ifnull -> 533
    //   498: aload_3
    //   499: invokevirtual getClass : ()Ljava/lang/Class;
    //   502: ldc 'optional'
    //   504: iconst_0
    //   505: anewarray java/lang/Class
    //   508: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   511: aload_3
    //   512: iconst_0
    //   513: anewarray java/lang/Object
    //   516: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   519: checkcast java/lang/Boolean
    //   522: astore_0
    //   523: aload_0
    //   524: ifnonnull -> 822
    //   527: aload #11
    //   529: iconst_1
    //   530: invokevirtual setCanBeNull : (Z)V
    //   533: aload #4
    //   535: ifnull -> 549
    //   538: aload #5
    //   540: ifnonnull -> 859
    //   543: aload #11
    //   545: iconst_1
    //   546: invokevirtual setId : (Z)V
    //   549: aload #6
    //   551: ifnonnull -> 559
    //   554: aload #7
    //   556: ifnull -> 684
    //   559: ldc java/util/Collection
    //   561: aload_1
    //   562: invokevirtual getType : ()Ljava/lang/Class;
    //   565: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   568: ifne -> 583
    //   571: ldc com/j256/ormlite/dao/ForeignCollection
    //   573: aload_1
    //   574: invokevirtual getType : ()Ljava/lang/Class;
    //   577: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   580: ifeq -> 893
    //   583: aload #11
    //   585: iconst_1
    //   586: invokevirtual setForeignCollection : (Z)V
    //   589: aload #8
    //   591: ifnull -> 684
    //   594: aload #8
    //   596: invokevirtual getClass : ()Ljava/lang/Class;
    //   599: ldc 'name'
    //   601: iconst_0
    //   602: anewarray java/lang/Class
    //   605: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   608: aload #8
    //   610: iconst_0
    //   611: anewarray java/lang/Object
    //   614: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   617: checkcast java/lang/String
    //   620: astore_0
    //   621: aload_0
    //   622: ifnull -> 638
    //   625: aload_0
    //   626: invokevirtual length : ()I
    //   629: ifle -> 638
    //   632: aload #11
    //   634: aload_0
    //   635: invokevirtual setForeignCollectionColumnName : (Ljava/lang/String;)V
    //   638: aload #8
    //   640: invokevirtual getClass : ()Ljava/lang/Class;
    //   643: ldc 'fetch'
    //   645: iconst_0
    //   646: anewarray java/lang/Class
    //   649: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   652: aload #8
    //   654: iconst_0
    //   655: anewarray java/lang/Object
    //   658: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   661: astore_0
    //   662: aload_0
    //   663: ifnull -> 684
    //   666: aload_0
    //   667: invokevirtual toString : ()Ljava/lang/String;
    //   670: ldc 'EAGER'
    //   672: invokevirtual equals : (Ljava/lang/Object;)Z
    //   675: ifeq -> 684
    //   678: aload #11
    //   680: iconst_1
    //   681: invokevirtual setForeignCollectionEager : (Z)V
    //   684: aload #9
    //   686: ifnull -> 737
    //   689: aload #9
    //   691: invokevirtual getClass : ()Ljava/lang/Class;
    //   694: ldc 'value'
    //   696: iconst_0
    //   697: anewarray java/lang/Class
    //   700: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   703: aload #9
    //   705: iconst_0
    //   706: anewarray java/lang/Object
    //   709: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   712: astore_0
    //   713: aload_0
    //   714: ifnull -> 1056
    //   717: aload_0
    //   718: invokevirtual toString : ()Ljava/lang/String;
    //   721: ldc 'STRING'
    //   723: invokevirtual equals : (Ljava/lang/Object;)Z
    //   726: ifeq -> 1056
    //   729: aload #11
    //   731: getstatic com/j256/ormlite/field/DataType.ENUM_STRING : Lcom/j256/ormlite/field/DataType;
    //   734: invokevirtual setDataType : (Lcom/j256/ormlite/field/DataType;)V
    //   737: aload #10
    //   739: ifnull -> 748
    //   742: aload #11
    //   744: iconst_1
    //   745: invokevirtual setVersion : (Z)V
    //   748: aload #11
    //   750: invokevirtual getDataPersister : ()Lcom/j256/ormlite/field/DataPersister;
    //   753: ifnonnull -> 765
    //   756: aload #11
    //   758: aload_1
    //   759: invokestatic lookupForField : (Ljava/lang/reflect/Field;)Lcom/j256/ormlite/field/DataPersister;
    //   762: invokevirtual setDataPersister : (Lcom/j256/ormlite/field/DataPersister;)V
    //   765: aload_1
    //   766: iconst_0
    //   767: invokestatic findGetMethod : (Ljava/lang/reflect/Field;Z)Ljava/lang/reflect/Method;
    //   770: ifnull -> 1092
    //   773: aload_1
    //   774: iconst_0
    //   775: invokestatic findSetMethod : (Ljava/lang/reflect/Field;Z)Ljava/lang/reflect/Method;
    //   778: ifnull -> 1092
    //   781: iconst_1
    //   782: istore #16
    //   784: aload #11
    //   786: iload #16
    //   788: invokevirtual setUseGetSet : (Z)V
    //   791: aload #11
    //   793: astore_0
    //   794: goto -> 254
    //   797: astore_0
    //   798: new java/lang/StringBuilder
    //   801: dup
    //   802: invokespecial <init> : ()V
    //   805: ldc 'Problem accessing fields from the @Column annotation for field '
    //   807: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   810: aload_1
    //   811: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   814: invokevirtual toString : ()Ljava/lang/String;
    //   817: aload_0
    //   818: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   821: athrow
    //   822: aload #11
    //   824: aload_0
    //   825: invokevirtual booleanValue : ()Z
    //   828: invokevirtual setCanBeNull : (Z)V
    //   831: goto -> 533
    //   834: astore_0
    //   835: new java/lang/StringBuilder
    //   838: dup
    //   839: invokespecial <init> : ()V
    //   842: ldc 'Problem accessing fields from the @Basic annotation for field '
    //   844: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   847: aload_1
    //   848: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   851: invokevirtual toString : ()Ljava/lang/String;
    //   854: aload_0
    //   855: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   858: athrow
    //   859: aload #11
    //   861: iconst_1
    //   862: invokevirtual setGeneratedId : (Z)V
    //   865: goto -> 549
    //   868: astore_0
    //   869: new java/lang/StringBuilder
    //   872: dup
    //   873: invokespecial <init> : ()V
    //   876: ldc 'Problem accessing fields from the @JoinColumn annotation for field '
    //   878: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   881: aload_1
    //   882: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   885: invokevirtual toString : ()Ljava/lang/String;
    //   888: aload_0
    //   889: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   892: athrow
    //   893: aload #11
    //   895: iconst_1
    //   896: invokevirtual setForeign : (Z)V
    //   899: aload #8
    //   901: ifnull -> 684
    //   904: aload #8
    //   906: invokevirtual getClass : ()Ljava/lang/Class;
    //   909: ldc 'name'
    //   911: iconst_0
    //   912: anewarray java/lang/Class
    //   915: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   918: aload #8
    //   920: iconst_0
    //   921: anewarray java/lang/Object
    //   924: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   927: checkcast java/lang/String
    //   930: astore_0
    //   931: aload_0
    //   932: ifnull -> 948
    //   935: aload_0
    //   936: invokevirtual length : ()I
    //   939: ifle -> 948
    //   942: aload #11
    //   944: aload_0
    //   945: invokevirtual setColumnName : (Ljava/lang/String;)V
    //   948: aload #8
    //   950: invokevirtual getClass : ()Ljava/lang/Class;
    //   953: ldc 'nullable'
    //   955: iconst_0
    //   956: anewarray java/lang/Class
    //   959: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   962: aload #8
    //   964: iconst_0
    //   965: anewarray java/lang/Object
    //   968: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   971: checkcast java/lang/Boolean
    //   974: astore_0
    //   975: aload_0
    //   976: ifnull -> 988
    //   979: aload #11
    //   981: aload_0
    //   982: invokevirtual booleanValue : ()Z
    //   985: invokevirtual setCanBeNull : (Z)V
    //   988: aload #8
    //   990: invokevirtual getClass : ()Ljava/lang/Class;
    //   993: ldc 'unique'
    //   995: iconst_0
    //   996: anewarray java/lang/Class
    //   999: invokevirtual getMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   1002: aload #8
    //   1004: iconst_0
    //   1005: anewarray java/lang/Object
    //   1008: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   1011: checkcast java/lang/Boolean
    //   1014: astore_0
    //   1015: aload_0
    //   1016: ifnull -> 684
    //   1019: aload #11
    //   1021: aload_0
    //   1022: invokevirtual booleanValue : ()Z
    //   1025: invokevirtual setUnique : (Z)V
    //   1028: goto -> 684
    //   1031: astore_0
    //   1032: new java/lang/StringBuilder
    //   1035: dup
    //   1036: invokespecial <init> : ()V
    //   1039: ldc 'Problem accessing fields from the @JoinColumn annotation for field '
    //   1041: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1044: aload_1
    //   1045: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1048: invokevirtual toString : ()Ljava/lang/String;
    //   1051: aload_0
    //   1052: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   1055: athrow
    //   1056: aload #11
    //   1058: getstatic com/j256/ormlite/field/DataType.ENUM_INTEGER : Lcom/j256/ormlite/field/DataType;
    //   1061: invokevirtual setDataType : (Lcom/j256/ormlite/field/DataType;)V
    //   1064: goto -> 737
    //   1067: astore_0
    //   1068: new java/lang/StringBuilder
    //   1071: dup
    //   1072: invokespecial <init> : ()V
    //   1075: ldc 'Problem accessing fields from the @Enumerated annotation for field '
    //   1077: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1080: aload_1
    //   1081: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1084: invokevirtual toString : ()Ljava/lang/String;
    //   1087: aload_0
    //   1088: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   1091: athrow
    //   1092: iconst_0
    //   1093: istore #16
    //   1095: goto -> 784
    // Exception table:
    //   from	to	target	type
    //   302	327	797	java/lang/Exception
    //   331	344	797	java/lang/Exception
    //   344	369	797	java/lang/Exception
    //   373	386	797	java/lang/Exception
    //   386	443	797	java/lang/Exception
    //   447	456	797	java/lang/Exception
    //   456	481	797	java/lang/Exception
    //   485	494	797	java/lang/Exception
    //   498	523	834	java/lang/Exception
    //   527	533	834	java/lang/Exception
    //   594	621	868	java/lang/Exception
    //   625	638	868	java/lang/Exception
    //   638	662	868	java/lang/Exception
    //   666	684	868	java/lang/Exception
    //   689	713	1067	java/lang/Exception
    //   717	737	1067	java/lang/Exception
    //   822	831	834	java/lang/Exception
    //   904	931	1031	java/lang/Exception
    //   935	948	1031	java/lang/Exception
    //   948	975	1031	java/lang/Exception
    //   979	988	1031	java/lang/Exception
    //   988	1015	1031	java/lang/Exception
    //   1019	1028	1031	java/lang/Exception
    //   1056	1064	1067	java/lang/Exception
  }
  
  public static String getEntityName(Class<?> paramClass) {
    Annotation annotation = null;
    for (Annotation annotation1 : paramClass.getAnnotations()) {
      if (annotation1.annotationType().getName().equals("javax.persistence.Entity"))
        annotation = annotation1; 
    } 
    if (annotation == null)
      return null; 
    try {
      String str = (String)annotation.getClass().getMethod("name", new Class[0]).invoke(annotation, new Object[0]);
      if (str != null) {
        int i = str.length();
        String str1 = str;
        return (i <= 0) ? null : str1;
      } 
      return null;
    } catch (Exception exception) {
      throw new IllegalStateException("Could not get entity name from class " + paramClass, exception);
    } 
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/misc/JavaxPersistence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */