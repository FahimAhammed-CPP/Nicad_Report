package com.j256.ormlite.misc;

import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.logger.Logger;
import com.j256.ormlite.logger.LoggerFactory;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.support.DatabaseConnection;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicInteger;

public class TransactionManager {
  private static final String SAVE_POINT_PREFIX = "ORMLITE";
  
  private static final Logger logger = LoggerFactory.getLogger(TransactionManager.class);
  
  private static AtomicInteger savePointCounter = new AtomicInteger();
  
  private ConnectionSource connectionSource;
  
  public TransactionManager() {}
  
  public TransactionManager(ConnectionSource paramConnectionSource) {
    this.connectionSource = paramConnectionSource;
    initialize();
  }
  
  public static <T> T callInTransaction(ConnectionSource paramConnectionSource, Callable<T> paramCallable) throws SQLException {
    DatabaseConnection databaseConnection = paramConnectionSource.getReadWriteConnection();
    try {
      paramCallable = callInTransaction(databaseConnection, paramConnectionSource.saveSpecialConnection(databaseConnection), paramConnectionSource.getDatabaseType(), (Callable)paramCallable);
      return (T)paramCallable;
    } finally {
      paramConnectionSource.clearSpecialConnection(databaseConnection);
      paramConnectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public static <T> T callInTransaction(DatabaseConnection paramDatabaseConnection, DatabaseType paramDatabaseType, Callable<T> paramCallable) throws SQLException {
    return callInTransaction(paramDatabaseConnection, false, paramDatabaseType, paramCallable);
  }
  
  public static <T> T callInTransaction(DatabaseConnection paramDatabaseConnection, boolean paramBoolean, DatabaseType paramDatabaseType, Callable<T> paramCallable) throws SQLException {
    // Byte code:
    //   0: iconst_0
    //   1: istore #4
    //   3: iconst_0
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #6
    //   9: iconst_0
    //   10: istore #7
    //   12: aconst_null
    //   13: astore #8
    //   15: iload_1
    //   16: ifne -> 31
    //   19: iload #5
    //   21: istore_1
    //   22: aload_2
    //   23: invokeinterface isNestedSavePointsSupported : ()Z
    //   28: ifeq -> 154
    //   31: iload #6
    //   33: istore #4
    //   35: iload #5
    //   37: istore_1
    //   38: aload_0
    //   39: invokeinterface isAutoCommitSupported : ()Z
    //   44: ifeq -> 92
    //   47: iload #5
    //   49: istore_1
    //   50: aload_0
    //   51: invokeinterface isAutoCommit : ()Z
    //   56: istore #5
    //   58: iload #5
    //   60: istore #4
    //   62: iload #5
    //   64: ifeq -> 92
    //   67: iload #5
    //   69: istore_1
    //   70: aload_0
    //   71: iconst_0
    //   72: invokeinterface setAutoCommit : (Z)V
    //   77: iload #5
    //   79: istore_1
    //   80: getstatic com/j256/ormlite/misc/TransactionManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   83: ldc 'had to set auto-commit to false'
    //   85: invokevirtual debug : (Ljava/lang/String;)V
    //   88: iload #5
    //   90: istore #4
    //   92: iload #4
    //   94: istore_1
    //   95: new java/lang/StringBuilder
    //   98: astore_2
    //   99: iload #4
    //   101: istore_1
    //   102: aload_2
    //   103: invokespecial <init> : ()V
    //   106: iload #4
    //   108: istore_1
    //   109: aload_0
    //   110: aload_2
    //   111: ldc 'ORMLITE'
    //   113: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   116: getstatic com/j256/ormlite/misc/TransactionManager.savePointCounter : Ljava/util/concurrent/atomic/AtomicInteger;
    //   119: invokevirtual incrementAndGet : ()I
    //   122: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   125: invokevirtual toString : ()Ljava/lang/String;
    //   128: invokeinterface setSavePoint : (Ljava/lang/String;)Ljava/sql/Savepoint;
    //   133: astore #8
    //   135: aload #8
    //   137: ifnonnull -> 200
    //   140: iload #4
    //   142: istore_1
    //   143: getstatic com/j256/ormlite/misc/TransactionManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   146: ldc 'started savePoint transaction'
    //   148: invokevirtual debug : (Ljava/lang/String;)V
    //   151: iconst_1
    //   152: istore #7
    //   154: iload #4
    //   156: istore_1
    //   157: aload_3
    //   158: invokeinterface call : ()Ljava/lang/Object;
    //   163: astore_2
    //   164: iload #7
    //   166: ifeq -> 178
    //   169: iload #4
    //   171: istore_1
    //   172: aload_0
    //   173: aload #8
    //   175: invokestatic commit : (Lcom/j256/ormlite/support/DatabaseConnection;Ljava/sql/Savepoint;)V
    //   178: iload #4
    //   180: ifeq -> 198
    //   183: aload_0
    //   184: iconst_1
    //   185: invokeinterface setAutoCommit : (Z)V
    //   190: getstatic com/j256/ormlite/misc/TransactionManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   193: ldc 'restored auto-commit to true'
    //   195: invokevirtual debug : (Ljava/lang/String;)V
    //   198: aload_2
    //   199: areturn
    //   200: iload #4
    //   202: istore_1
    //   203: getstatic com/j256/ormlite/misc/TransactionManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   206: ldc 'started savePoint transaction {}'
    //   208: aload #8
    //   210: invokeinterface getSavepointName : ()Ljava/lang/String;
    //   215: invokevirtual debug : (Ljava/lang/String;Ljava/lang/Object;)V
    //   218: goto -> 151
    //   221: astore_2
    //   222: iload_1
    //   223: ifeq -> 241
    //   226: aload_0
    //   227: iconst_1
    //   228: invokeinterface setAutoCommit : (Z)V
    //   233: getstatic com/j256/ormlite/misc/TransactionManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   236: ldc 'restored auto-commit to true'
    //   238: invokevirtual debug : (Ljava/lang/String;)V
    //   241: aload_2
    //   242: athrow
    //   243: astore_2
    //   244: iload #7
    //   246: ifeq -> 258
    //   249: iload #4
    //   251: istore_1
    //   252: aload_0
    //   253: aload #8
    //   255: invokestatic rollBack : (Lcom/j256/ormlite/support/DatabaseConnection;Ljava/sql/Savepoint;)V
    //   258: iload #4
    //   260: istore_1
    //   261: aload_2
    //   262: athrow
    //   263: astore_3
    //   264: iload #4
    //   266: istore_1
    //   267: getstatic com/j256/ormlite/misc/TransactionManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   270: aload_2
    //   271: ldc 'after commit exception, rolling back to save-point also threw exception'
    //   273: invokevirtual error : (Ljava/lang/Throwable;Ljava/lang/String;)V
    //   276: goto -> 258
    //   279: astore_2
    //   280: iload #7
    //   282: ifeq -> 294
    //   285: iload #4
    //   287: istore_1
    //   288: aload_0
    //   289: aload #8
    //   291: invokestatic rollBack : (Lcom/j256/ormlite/support/DatabaseConnection;Ljava/sql/Savepoint;)V
    //   294: iload #4
    //   296: istore_1
    //   297: ldc 'Transaction callable threw non-SQL exception'
    //   299: aload_2
    //   300: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   303: athrow
    //   304: astore_3
    //   305: iload #4
    //   307: istore_1
    //   308: getstatic com/j256/ormlite/misc/TransactionManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   311: aload_2
    //   312: ldc 'after commit exception, rolling back to save-point also threw exception'
    //   314: invokevirtual error : (Ljava/lang/Throwable;Ljava/lang/String;)V
    //   317: goto -> 294
    // Exception table:
    //   from	to	target	type
    //   22	31	221	finally
    //   38	47	221	finally
    //   50	58	221	finally
    //   70	77	221	finally
    //   80	88	221	finally
    //   95	99	221	finally
    //   102	106	221	finally
    //   109	135	221	finally
    //   143	151	221	finally
    //   157	164	243	java/sql/SQLException
    //   157	164	279	java/lang/Exception
    //   157	164	221	finally
    //   172	178	243	java/sql/SQLException
    //   172	178	279	java/lang/Exception
    //   172	178	221	finally
    //   203	218	221	finally
    //   252	258	263	java/sql/SQLException
    //   252	258	221	finally
    //   261	263	221	finally
    //   267	276	221	finally
    //   288	294	304	java/sql/SQLException
    //   288	294	221	finally
    //   297	304	221	finally
    //   308	317	221	finally
  }
  
  private static void commit(DatabaseConnection paramDatabaseConnection, Savepoint paramSavepoint) throws SQLException {
    String str;
    if (paramSavepoint == null) {
      str = null;
    } else {
      str = paramSavepoint.getSavepointName();
    } 
    paramDatabaseConnection.commit(paramSavepoint);
    if (str == null) {
      logger.debug("committed savePoint transaction");
      return;
    } 
    logger.debug("committed savePoint transaction {}", str);
  }
  
  private static void rollBack(DatabaseConnection paramDatabaseConnection, Savepoint paramSavepoint) throws SQLException {
    String str;
    if (paramSavepoint == null) {
      str = null;
    } else {
      str = paramSavepoint.getSavepointName();
    } 
    paramDatabaseConnection.rollback(paramSavepoint);
    if (str == null) {
      logger.debug("rolled back savePoint transaction");
      return;
    } 
    logger.debug("rolled back savePoint transaction {}", str);
  }
  
  public <T> T callInTransaction(Callable<T> paramCallable) throws SQLException {
    return callInTransaction(this.connectionSource, paramCallable);
  }
  
  public void initialize() {
    if (this.connectionSource == null)
      throw new IllegalStateException("dataSource was not set on " + getClass().getSimpleName()); 
  }
  
  public void setConnectionSource(ConnectionSource paramConnectionSource) {
    this.connectionSource = paramConnectionSource;
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/misc/TransactionManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */