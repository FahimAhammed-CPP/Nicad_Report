package com.j256.ormlite.field.types;

import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.field.SqlType;
import java.lang.reflect.Field;
import java.sql.SQLException;

public abstract class BaseEnumType extends BaseDataType {
  protected BaseEnumType(SqlType paramSqlType, Class<?>[] paramArrayOfClass) {
    super(paramSqlType, paramArrayOfClass);
  }
  
  protected static Enum<?> enumVal(FieldType paramFieldType, Object paramObject, Enum<?> paramEnum1, Enum<?> paramEnum2) throws SQLException {
    if (paramEnum1 == null) {
      if (paramEnum2 == null)
        throw new SQLException("Cannot get enum value of '" + paramObject + "' for field " + paramFieldType); 
      paramEnum1 = paramEnum2;
    } 
    return paramEnum1;
  }
  
  public boolean isValidForField(Field paramField) {
    return paramField.getType().isEnum();
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/field/types/BaseEnumType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */