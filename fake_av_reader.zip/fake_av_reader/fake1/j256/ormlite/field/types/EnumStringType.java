package com.j256.ormlite.field.types;

import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.field.SqlType;
import com.j256.ormlite.support.DatabaseResults;
import java.sql.SQLException;
import java.util.HashMap;

public class EnumStringType extends BaseEnumType {
  public static int DEFAULT_WIDTH = 100;
  
  private static final EnumStringType singleTon = new EnumStringType();
  
  private EnumStringType() {
    super(SqlType.STRING, new Class[] { Enum.class });
  }
  
  protected EnumStringType(SqlType paramSqlType, Class<?>[] paramArrayOfClass) {
    super(paramSqlType, paramArrayOfClass);
  }
  
  public static EnumStringType getSingleton() {
    return singleTon;
  }
  
  public int getDefaultWidth() {
    return DEFAULT_WIDTH;
  }
  
  public Object javaToSqlArg(FieldType paramFieldType, Object paramObject) {
    return ((Enum)paramObject).name();
  }
  
  public Object makeConfigObject(FieldType paramFieldType) throws SQLException {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Enum[] arrayOfEnum = paramFieldType.getType().getEnumConstants();
    if (arrayOfEnum == null)
      throw new SQLException("Field " + paramFieldType + " improperly configured as type " + this); 
    int i = arrayOfEnum.length;
    for (byte b = 0; b < i; b++) {
      Enum enum_ = arrayOfEnum[b];
      hashMap.put(enum_.name(), enum_);
    } 
    return hashMap;
  }
  
  public Object parseDefaultString(FieldType paramFieldType, String paramString) {
    return paramString;
  }
  
  public Object resultStringToJava(FieldType paramFieldType, String paramString, int paramInt) throws SQLException {
    return sqlArgToJava(paramFieldType, paramString, paramInt);
  }
  
  public Object resultToSqlArg(FieldType paramFieldType, DatabaseResults paramDatabaseResults, int paramInt) throws SQLException {
    return paramDatabaseResults.getString(paramInt);
  }
  
  public Object sqlArgToJava(FieldType paramFieldType, Object<?> paramObject, int paramInt) throws SQLException {
    if (paramFieldType != null) {
      String str = (String)paramObject;
      paramObject = (Object<?>)paramFieldType.getDataTypeConfigObj();
      if (paramObject == null)
        return enumVal(paramFieldType, str, null, paramFieldType.getUnknownEnumVal()); 
      paramObject = (Object<?>)enumVal(paramFieldType, str, paramObject.get(str), paramFieldType.getUnknownEnumVal());
    } 
    return paramObject;
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/field/types/EnumStringType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */