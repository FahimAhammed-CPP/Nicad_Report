package com.j256.ormlite.field.types;

import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.field.SqlType;
import com.j256.ormlite.support.DatabaseResults;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.sql.SQLException;

public class SerializableType extends BaseDataType {
  private static final SerializableType singleTon = new SerializableType();
  
  private SerializableType() {
    super(SqlType.SERIALIZABLE, new Class[0]);
  }
  
  protected SerializableType(SqlType paramSqlType, Class<?>[] paramArrayOfClass) {
    super(paramSqlType, paramArrayOfClass);
  }
  
  public static SerializableType getSingleton() {
    return singleTon;
  }
  
  public Class<?> getPrimaryClass() {
    return Serializable.class;
  }
  
  public boolean isAppropriateId() {
    return false;
  }
  
  public boolean isArgumentHolderRequired() {
    return true;
  }
  
  public boolean isComparable() {
    return false;
  }
  
  public boolean isStreamType() {
    return true;
  }
  
  public boolean isValidForField(Field paramField) {
    return Serializable.class.isAssignableFrom(paramField.getType());
  }
  
  public Object javaToSqlArg(FieldType paramFieldType, Object paramObject) throws SQLException {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_3
    //   3: astore_1
    //   4: new java/io/ByteArrayOutputStream
    //   7: astore #4
    //   9: aload_3
    //   10: astore_1
    //   11: aload #4
    //   13: invokespecial <init> : ()V
    //   16: aload_3
    //   17: astore_1
    //   18: new java/io/ObjectOutputStream
    //   21: astore #5
    //   23: aload_3
    //   24: astore_1
    //   25: aload #5
    //   27: aload #4
    //   29: invokespecial <init> : (Ljava/io/OutputStream;)V
    //   32: aload #5
    //   34: aload_2
    //   35: invokevirtual writeObject : (Ljava/lang/Object;)V
    //   38: aload #5
    //   40: invokevirtual close : ()V
    //   43: aconst_null
    //   44: astore_1
    //   45: aload #4
    //   47: invokevirtual toByteArray : ()[B
    //   50: astore #5
    //   52: iconst_0
    //   53: ifeq -> 64
    //   56: new java/lang/NullPointerException
    //   59: dup
    //   60: invokespecial <init> : ()V
    //   63: athrow
    //   64: aload #5
    //   66: areturn
    //   67: aconst_null
    //   68: astore #5
    //   70: astore_3
    //   71: aload #5
    //   73: astore_1
    //   74: new java/lang/StringBuilder
    //   77: astore #4
    //   79: aload #5
    //   81: astore_1
    //   82: aload #4
    //   84: invokespecial <init> : ()V
    //   87: aload #5
    //   89: astore_1
    //   90: aload #4
    //   92: ldc 'Could not write serialized object to byte array: '
    //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: aload_2
    //   98: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   101: invokevirtual toString : ()Ljava/lang/String;
    //   104: aload_3
    //   105: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   108: athrow
    //   109: astore_2
    //   110: aload_1
    //   111: astore #5
    //   113: aload #5
    //   115: ifnull -> 123
    //   118: aload #5
    //   120: invokevirtual close : ()V
    //   123: aload_2
    //   124: athrow
    //   125: astore_1
    //   126: goto -> 64
    //   129: astore_1
    //   130: goto -> 123
    //   133: astore_1
    //   134: aload_1
    //   135: astore_2
    //   136: goto -> 113
    //   139: astore_3
    //   140: goto -> 71
    // Exception table:
    //   from	to	target	type
    //   4	9	67	java/lang/Exception
    //   4	9	109	finally
    //   11	16	67	java/lang/Exception
    //   11	16	109	finally
    //   18	23	67	java/lang/Exception
    //   18	23	109	finally
    //   25	32	67	java/lang/Exception
    //   25	32	109	finally
    //   32	43	139	java/lang/Exception
    //   32	43	133	finally
    //   45	52	67	java/lang/Exception
    //   45	52	109	finally
    //   56	64	125	java/io/IOException
    //   74	79	109	finally
    //   82	87	109	finally
    //   90	109	109	finally
    //   118	123	129	java/io/IOException
  }
  
  public Object parseDefaultString(FieldType paramFieldType, String paramString) throws SQLException {
    throw new SQLException("Default values for serializable types are not supported");
  }
  
  public Object resultStringToJava(FieldType paramFieldType, String paramString, int paramInt) throws SQLException {
    throw new SQLException("Serializable type cannot be converted from string to Java");
  }
  
  public Object resultToSqlArg(FieldType paramFieldType, DatabaseResults paramDatabaseResults, int paramInt) throws SQLException {
    return paramDatabaseResults.getBytes(paramInt);
  }
  
  public Object sqlArgToJava(FieldType paramFieldType, Object paramObject, int paramInt) throws SQLException {
    // Byte code:
    //   0: aload_2
    //   1: checkcast [B
    //   4: astore #4
    //   6: aconst_null
    //   7: astore #5
    //   9: aconst_null
    //   10: astore #6
    //   12: aload #5
    //   14: astore_1
    //   15: new java/io/ObjectInputStream
    //   18: astore_2
    //   19: aload #5
    //   21: astore_1
    //   22: new java/io/ByteArrayInputStream
    //   25: astore #7
    //   27: aload #5
    //   29: astore_1
    //   30: aload #7
    //   32: aload #4
    //   34: invokespecial <init> : ([B)V
    //   37: aload #5
    //   39: astore_1
    //   40: aload_2
    //   41: aload #7
    //   43: invokespecial <init> : (Ljava/io/InputStream;)V
    //   46: aload_2
    //   47: invokevirtual readObject : ()Ljava/lang/Object;
    //   50: astore_1
    //   51: aload_2
    //   52: ifnull -> 59
    //   55: aload_2
    //   56: invokevirtual close : ()V
    //   59: aload_1
    //   60: areturn
    //   61: astore #5
    //   63: aload #6
    //   65: astore_2
    //   66: aload_2
    //   67: astore_1
    //   68: new java/lang/StringBuilder
    //   71: astore #6
    //   73: aload_2
    //   74: astore_1
    //   75: aload #6
    //   77: invokespecial <init> : ()V
    //   80: aload_2
    //   81: astore_1
    //   82: aload #6
    //   84: ldc 'Could not read serialized object from byte array: '
    //   86: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   89: aload #4
    //   91: invokestatic toString : ([B)Ljava/lang/String;
    //   94: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   97: ldc '(len '
    //   99: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   102: aload #4
    //   104: arraylength
    //   105: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   108: ldc ')'
    //   110: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: invokevirtual toString : ()Ljava/lang/String;
    //   116: aload #5
    //   118: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   121: athrow
    //   122: astore_2
    //   123: aload_1
    //   124: astore #5
    //   126: aload #5
    //   128: ifnull -> 136
    //   131: aload #5
    //   133: invokevirtual close : ()V
    //   136: aload_2
    //   137: athrow
    //   138: astore_2
    //   139: goto -> 59
    //   142: astore_1
    //   143: goto -> 136
    //   146: astore_1
    //   147: aload_2
    //   148: astore #5
    //   150: aload_1
    //   151: astore_2
    //   152: goto -> 126
    //   155: astore #5
    //   157: goto -> 66
    // Exception table:
    //   from	to	target	type
    //   15	19	61	java/lang/Exception
    //   15	19	122	finally
    //   22	27	61	java/lang/Exception
    //   22	27	122	finally
    //   30	37	61	java/lang/Exception
    //   30	37	122	finally
    //   40	46	61	java/lang/Exception
    //   40	46	122	finally
    //   46	51	155	java/lang/Exception
    //   46	51	146	finally
    //   55	59	138	java/io/IOException
    //   68	73	122	finally
    //   75	80	122	finally
    //   82	122	122	finally
    //   131	136	142	java/io/IOException
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/field/types/SerializableType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */