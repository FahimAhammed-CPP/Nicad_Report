package com.j256.ormlite.field.types;

import com.j256.ormlite.field.BaseFieldConverter;
import com.j256.ormlite.field.DataPersister;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.field.SqlType;
import com.j256.ormlite.support.DatabaseResults;
import java.lang.reflect.Field;
import java.sql.SQLException;

public abstract class BaseDataType extends BaseFieldConverter implements DataPersister {
  private final Class<?>[] classes;
  
  private final SqlType sqlType;
  
  public BaseDataType(SqlType paramSqlType, Class<?>[] paramArrayOfClass) {
    this.sqlType = paramSqlType;
    this.classes = paramArrayOfClass;
  }
  
  public Object convertIdNumber(Number paramNumber) {
    return null;
  }
  
  public boolean dataIsEqual(Object paramObject1, Object paramObject2) {
    boolean bool = false;
    if (paramObject1 == null) {
      if (paramObject2 == null)
        bool = true; 
      return bool;
    } 
    if (paramObject2 != null)
      bool = paramObject1.equals(paramObject2); 
    return bool;
  }
  
  public Object generateId() {
    throw new IllegalStateException("Should not have tried to generate this type");
  }
  
  public String[] getAssociatedClassNames() {
    return null;
  }
  
  public Class<?>[] getAssociatedClasses() {
    return this.classes;
  }
  
  public int getDefaultWidth() {
    return 0;
  }
  
  public Class<?> getPrimaryClass() {
    return (this.classes.length == 0) ? null : this.classes[0];
  }
  
  public SqlType getSqlType() {
    return this.sqlType;
  }
  
  public boolean isAppropriateId() {
    return true;
  }
  
  public boolean isArgumentHolderRequired() {
    return false;
  }
  
  public boolean isComparable() {
    return true;
  }
  
  public boolean isEscapedDefaultValue() {
    return isEscapedValue();
  }
  
  public boolean isEscapedValue() {
    return true;
  }
  
  public boolean isPrimitive() {
    return false;
  }
  
  public boolean isSelfGeneratedId() {
    return false;
  }
  
  public boolean isValidForField(Field paramField) {
    // Byte code:
    //   0: iconst_1
    //   1: istore_2
    //   2: aload_0
    //   3: getfield classes : [Ljava/lang/Class;
    //   6: arraylength
    //   7: ifne -> 14
    //   10: iload_2
    //   11: istore_3
    //   12: iload_3
    //   13: ireturn
    //   14: aload_0
    //   15: getfield classes : [Ljava/lang/Class;
    //   18: astore #4
    //   20: aload #4
    //   22: arraylength
    //   23: istore #5
    //   25: iconst_0
    //   26: istore #6
    //   28: iload #6
    //   30: iload #5
    //   32: if_icmpge -> 58
    //   35: iload_2
    //   36: istore_3
    //   37: aload #4
    //   39: iload #6
    //   41: aaload
    //   42: aload_1
    //   43: invokevirtual getType : ()Ljava/lang/Class;
    //   46: invokevirtual isAssignableFrom : (Ljava/lang/Class;)Z
    //   49: ifne -> 12
    //   52: iinc #6, 1
    //   55: goto -> 28
    //   58: iconst_0
    //   59: istore_3
    //   60: goto -> 12
  }
  
  public boolean isValidForVersion() {
    return false;
  }
  
  public boolean isValidGeneratedType() {
    return false;
  }
  
  public Object makeConfigObject(FieldType paramFieldType) throws SQLException {
    return null;
  }
  
  public Object moveToNextValue(Object paramObject) {
    return null;
  }
  
  public abstract Object parseDefaultString(FieldType paramFieldType, String paramString) throws SQLException;
  
  public Object resultStringToJava(FieldType paramFieldType, String paramString, int paramInt) throws SQLException {
    return parseDefaultString(paramFieldType, paramString);
  }
  
  public abstract Object resultToSqlArg(FieldType paramFieldType, DatabaseResults paramDatabaseResults, int paramInt) throws SQLException;
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/field/types/BaseDataType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */