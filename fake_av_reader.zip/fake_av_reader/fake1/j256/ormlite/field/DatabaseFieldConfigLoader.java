package com.j256.ormlite.field;

import com.j256.ormlite.misc.SqlExceptionUtil;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.sql.SQLException;

public class DatabaseFieldConfigLoader {
  private static final String CONFIG_FILE_END_MARKER = "# --field-end--";
  
  private static final String CONFIG_FILE_START_MARKER = "# --field-start--";
  
  private static final DataPersister DEFAULT_DATA_PERSISTER = DatabaseFieldConfig.DEFAULT_DATA_TYPE.getDataPersister();
  
  private static final int DEFAULT_MAX_EAGER_FOREIGN_COLLECTION_LEVEL = 1;
  
  private static final String FIELD_NAME_ALLOW_GENERATED_ID_INSERT = "allowGeneratedIdInsert";
  
  private static final String FIELD_NAME_CAN_BE_NULL = "canBeNull";
  
  private static final String FIELD_NAME_COLUMN_DEFINITION = "columnDefinition";
  
  private static final String FIELD_NAME_COLUMN_NAME = "columnName";
  
  private static final String FIELD_NAME_DATA_PERSISTER = "dataPersister";
  
  private static final String FIELD_NAME_DEFAULT_VALUE = "defaultValue";
  
  private static final String FIELD_NAME_FIELD_NAME = "fieldName";
  
  private static final String FIELD_NAME_FOREIGN = "foreign";
  
  private static final String FIELD_NAME_FOREIGN_AUTO_CREATE = "foreignAutoCreate";
  
  private static final String FIELD_NAME_FOREIGN_AUTO_REFRESH = "foreignAutoRefresh";
  
  private static final String FIELD_NAME_FOREIGN_COLLECTION = "foreignCollection";
  
  private static final String FIELD_NAME_FOREIGN_COLLECTION_COLUMN_NAME = "foreignCollectionColumnName";
  
  private static final String FIELD_NAME_FOREIGN_COLLECTION_EAGER = "foreignCollectionEager";
  
  private static final String FIELD_NAME_FOREIGN_COLLECTION_FOREIGN_FIELD_NAME = "foreignCollectionForeignFieldName";
  
  private static final String FIELD_NAME_FOREIGN_COLLECTION_FOREIGN_FIELD_NAME_OLD = "foreignCollectionForeignColumnName";
  
  private static final String FIELD_NAME_FOREIGN_COLLECTION_ORDER_ASCENDING = "foreignCollectionOrderAscending";
  
  private static final String FIELD_NAME_FOREIGN_COLLECTION_ORDER_COLUMN_NAME = "foreignCollectionOrderColumnName";
  
  private static final String FIELD_NAME_FOREIGN_COLLECTION_ORDER_COLUMN_NAME_OLD = "foreignCollectionOrderColumn";
  
  private static final String FIELD_NAME_FOREIGN_COLUMN_NAME = "foreignColumnName";
  
  private static final String FIELD_NAME_FORMAT = "format";
  
  private static final String FIELD_NAME_GENERATED_ID = "generatedId";
  
  private static final String FIELD_NAME_GENERATED_ID_SEQUENCE = "generatedIdSequence";
  
  private static final String FIELD_NAME_ID = "id";
  
  private static final String FIELD_NAME_INDEX = "index";
  
  private static final String FIELD_NAME_INDEX_NAME = "indexName";
  
  private static final String FIELD_NAME_MAX_EAGER_FOREIGN_COLLECTION_LEVEL = "foreignCollectionMaxEagerLevel";
  
  private static final String FIELD_NAME_MAX_EAGER_FOREIGN_COLLECTION_LEVEL_OLD = "maxEagerForeignCollectionLevel";
  
  private static final String FIELD_NAME_MAX_FOREIGN_AUTO_REFRESH_LEVEL = "maxForeignAutoRefreshLevel";
  
  private static final String FIELD_NAME_PERSISTER_CLASS = "persisterClass";
  
  private static final String FIELD_NAME_READ_ONLY = "readOnly";
  
  private static final String FIELD_NAME_THROW_IF_NULL = "throwIfNull";
  
  private static final String FIELD_NAME_UNIQUE = "unique";
  
  private static final String FIELD_NAME_UNIQUE_COMBO = "uniqueCombo";
  
  private static final String FIELD_NAME_UNIQUE_INDEX = "uniqueIndex";
  
  private static final String FIELD_NAME_UNIQUE_INDEX_NAME = "uniqueIndexName";
  
  private static final String FIELD_NAME_UNKNOWN_ENUM_VALUE = "unknownEnumValue";
  
  private static final String FIELD_NAME_USE_GET_SET = "useGetSet";
  
  private static final String FIELD_NAME_VERSION = "version";
  
  private static final String FIELD_NAME_WIDTH = "width";
  
  public static DatabaseFieldConfig fromReader(BufferedReader paramBufferedReader) throws SQLException {
    DatabaseFieldConfig databaseFieldConfig = new DatabaseFieldConfig();
    boolean bool = false;
    while (true) {
      try {
        String str = paramBufferedReader.readLine();
        if (str != null && !str.equals("# --field-end--")) {
          if (str.length() != 0 && !str.startsWith("#") && !str.equals("# --field-start--")) {
            String[] arrayOfString = str.split("=", -2);
            if (arrayOfString.length != 2)
              throw new SQLException("DatabaseFieldConfig reading from stream cannot parse line: " + str); 
            readField(databaseFieldConfig, arrayOfString[0], arrayOfString[1]);
            bool = true;
          } 
          continue;
        } 
        if (bool)
          return databaseFieldConfig; 
      } catch (IOException iOException) {
        throw SqlExceptionUtil.create("Could not read DatabaseFieldConfig from stream", iOException);
      } 
      return null;
    } 
  }
  
  private static void readField(DatabaseFieldConfig paramDatabaseFieldConfig, String paramString1, String paramString2) {
    // Byte code:
    //   0: aload_1
    //   1: ldc 'fieldName'
    //   3: invokevirtual equals : (Ljava/lang/Object;)Z
    //   6: ifeq -> 15
    //   9: aload_0
    //   10: aload_2
    //   11: invokevirtual setFieldName : (Ljava/lang/String;)V
    //   14: return
    //   15: aload_1
    //   16: ldc 'columnName'
    //   18: invokevirtual equals : (Ljava/lang/Object;)Z
    //   21: ifeq -> 32
    //   24: aload_0
    //   25: aload_2
    //   26: invokevirtual setColumnName : (Ljava/lang/String;)V
    //   29: goto -> 14
    //   32: aload_1
    //   33: ldc 'dataPersister'
    //   35: invokevirtual equals : (Ljava/lang/Object;)Z
    //   38: ifeq -> 55
    //   41: aload_0
    //   42: aload_2
    //   43: invokestatic valueOf : (Ljava/lang/String;)Lcom/j256/ormlite/field/DataType;
    //   46: invokevirtual getDataPersister : ()Lcom/j256/ormlite/field/DataPersister;
    //   49: invokevirtual setDataPersister : (Lcom/j256/ormlite/field/DataPersister;)V
    //   52: goto -> 14
    //   55: aload_1
    //   56: ldc 'defaultValue'
    //   58: invokevirtual equals : (Ljava/lang/Object;)Z
    //   61: ifeq -> 72
    //   64: aload_0
    //   65: aload_2
    //   66: invokevirtual setDefaultValue : (Ljava/lang/String;)V
    //   69: goto -> 14
    //   72: aload_1
    //   73: ldc 'width'
    //   75: invokevirtual equals : (Ljava/lang/Object;)Z
    //   78: ifeq -> 92
    //   81: aload_0
    //   82: aload_2
    //   83: invokestatic parseInt : (Ljava/lang/String;)I
    //   86: invokevirtual setWidth : (I)V
    //   89: goto -> 14
    //   92: aload_1
    //   93: ldc 'canBeNull'
    //   95: invokevirtual equals : (Ljava/lang/Object;)Z
    //   98: ifeq -> 112
    //   101: aload_0
    //   102: aload_2
    //   103: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   106: invokevirtual setCanBeNull : (Z)V
    //   109: goto -> 14
    //   112: aload_1
    //   113: ldc 'id'
    //   115: invokevirtual equals : (Ljava/lang/Object;)Z
    //   118: ifeq -> 132
    //   121: aload_0
    //   122: aload_2
    //   123: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   126: invokevirtual setId : (Z)V
    //   129: goto -> 14
    //   132: aload_1
    //   133: ldc 'generatedId'
    //   135: invokevirtual equals : (Ljava/lang/Object;)Z
    //   138: ifeq -> 152
    //   141: aload_0
    //   142: aload_2
    //   143: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   146: invokevirtual setGeneratedId : (Z)V
    //   149: goto -> 14
    //   152: aload_1
    //   153: ldc 'generatedIdSequence'
    //   155: invokevirtual equals : (Ljava/lang/Object;)Z
    //   158: ifeq -> 169
    //   161: aload_0
    //   162: aload_2
    //   163: invokevirtual setGeneratedIdSequence : (Ljava/lang/String;)V
    //   166: goto -> 14
    //   169: aload_1
    //   170: ldc 'foreign'
    //   172: invokevirtual equals : (Ljava/lang/Object;)Z
    //   175: ifeq -> 189
    //   178: aload_0
    //   179: aload_2
    //   180: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   183: invokevirtual setForeign : (Z)V
    //   186: goto -> 14
    //   189: aload_1
    //   190: ldc 'useGetSet'
    //   192: invokevirtual equals : (Ljava/lang/Object;)Z
    //   195: ifeq -> 209
    //   198: aload_0
    //   199: aload_2
    //   200: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   203: invokevirtual setUseGetSet : (Z)V
    //   206: goto -> 14
    //   209: aload_1
    //   210: ldc 'unknownEnumValue'
    //   212: invokevirtual equals : (Ljava/lang/Object;)Z
    //   215: ifeq -> 424
    //   218: aload_2
    //   219: ldc '#'
    //   221: bipush #-2
    //   223: invokevirtual split : (Ljava/lang/String;I)[Ljava/lang/String;
    //   226: astore_1
    //   227: aload_1
    //   228: arraylength
    //   229: iconst_2
    //   230: if_icmpeq -> 261
    //   233: new java/lang/IllegalArgumentException
    //   236: dup
    //   237: new java/lang/StringBuilder
    //   240: dup
    //   241: invokespecial <init> : ()V
    //   244: ldc_w 'Invalid value for unknownEnumValue which should be in class#name format: '
    //   247: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   250: aload_2
    //   251: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   254: invokevirtual toString : ()Ljava/lang/String;
    //   257: invokespecial <init> : (Ljava/lang/String;)V
    //   260: athrow
    //   261: aload_1
    //   262: iconst_0
    //   263: aaload
    //   264: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   267: astore_3
    //   268: aload_3
    //   269: invokevirtual getEnumConstants : ()[Ljava/lang/Object;
    //   272: astore_3
    //   273: aload_3
    //   274: ifnonnull -> 334
    //   277: new java/lang/IllegalArgumentException
    //   280: dup
    //   281: new java/lang/StringBuilder
    //   284: dup
    //   285: invokespecial <init> : ()V
    //   288: ldc_w 'Invalid class is not an Enum for unknownEnumValue: '
    //   291: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   294: aload_2
    //   295: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   298: invokevirtual toString : ()Ljava/lang/String;
    //   301: invokespecial <init> : (Ljava/lang/String;)V
    //   304: athrow
    //   305: astore_0
    //   306: new java/lang/IllegalArgumentException
    //   309: dup
    //   310: new java/lang/StringBuilder
    //   313: dup
    //   314: invokespecial <init> : ()V
    //   317: ldc_w 'Unknown class specified for unknownEnumValue: '
    //   320: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   323: aload_2
    //   324: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   327: invokevirtual toString : ()Ljava/lang/String;
    //   330: invokespecial <init> : (Ljava/lang/String;)V
    //   333: athrow
    //   334: aload_3
    //   335: checkcast [Ljava/lang/Enum;
    //   338: astore #4
    //   340: iconst_0
    //   341: istore #5
    //   343: aload #4
    //   345: arraylength
    //   346: istore #6
    //   348: iconst_0
    //   349: istore #7
    //   351: iload #7
    //   353: iload #6
    //   355: if_icmpge -> 391
    //   358: aload #4
    //   360: iload #7
    //   362: aaload
    //   363: astore_3
    //   364: aload_3
    //   365: invokevirtual name : ()Ljava/lang/String;
    //   368: aload_1
    //   369: iconst_1
    //   370: aaload
    //   371: invokevirtual equals : (Ljava/lang/Object;)Z
    //   374: ifeq -> 385
    //   377: aload_0
    //   378: aload_3
    //   379: invokevirtual setUnknownEnumValue : (Ljava/lang/Enum;)V
    //   382: iconst_1
    //   383: istore #5
    //   385: iinc #7, 1
    //   388: goto -> 351
    //   391: iload #5
    //   393: ifne -> 14
    //   396: new java/lang/IllegalArgumentException
    //   399: dup
    //   400: new java/lang/StringBuilder
    //   403: dup
    //   404: invokespecial <init> : ()V
    //   407: ldc_w 'Invalid enum value name for unknownEnumvalue: '
    //   410: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   413: aload_2
    //   414: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   417: invokevirtual toString : ()Ljava/lang/String;
    //   420: invokespecial <init> : (Ljava/lang/String;)V
    //   423: athrow
    //   424: aload_1
    //   425: ldc 'throwIfNull'
    //   427: invokevirtual equals : (Ljava/lang/Object;)Z
    //   430: ifeq -> 444
    //   433: aload_0
    //   434: aload_2
    //   435: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   438: invokevirtual setThrowIfNull : (Z)V
    //   441: goto -> 14
    //   444: aload_1
    //   445: ldc 'format'
    //   447: invokevirtual equals : (Ljava/lang/Object;)Z
    //   450: ifeq -> 461
    //   453: aload_0
    //   454: aload_2
    //   455: invokevirtual setFormat : (Ljava/lang/String;)V
    //   458: goto -> 14
    //   461: aload_1
    //   462: ldc 'unique'
    //   464: invokevirtual equals : (Ljava/lang/Object;)Z
    //   467: ifeq -> 481
    //   470: aload_0
    //   471: aload_2
    //   472: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   475: invokevirtual setUnique : (Z)V
    //   478: goto -> 14
    //   481: aload_1
    //   482: ldc 'uniqueCombo'
    //   484: invokevirtual equals : (Ljava/lang/Object;)Z
    //   487: ifeq -> 501
    //   490: aload_0
    //   491: aload_2
    //   492: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   495: invokevirtual setUniqueCombo : (Z)V
    //   498: goto -> 14
    //   501: aload_1
    //   502: ldc 'index'
    //   504: invokevirtual equals : (Ljava/lang/Object;)Z
    //   507: ifeq -> 521
    //   510: aload_0
    //   511: aload_2
    //   512: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   515: invokevirtual setIndex : (Z)V
    //   518: goto -> 14
    //   521: aload_1
    //   522: ldc 'indexName'
    //   524: invokevirtual equals : (Ljava/lang/Object;)Z
    //   527: ifeq -> 543
    //   530: aload_0
    //   531: iconst_1
    //   532: invokevirtual setIndex : (Z)V
    //   535: aload_0
    //   536: aload_2
    //   537: invokevirtual setIndexName : (Ljava/lang/String;)V
    //   540: goto -> 14
    //   543: aload_1
    //   544: ldc 'uniqueIndex'
    //   546: invokevirtual equals : (Ljava/lang/Object;)Z
    //   549: ifeq -> 563
    //   552: aload_0
    //   553: aload_2
    //   554: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   557: invokevirtual setUniqueIndex : (Z)V
    //   560: goto -> 14
    //   563: aload_1
    //   564: ldc 'uniqueIndexName'
    //   566: invokevirtual equals : (Ljava/lang/Object;)Z
    //   569: ifeq -> 585
    //   572: aload_0
    //   573: iconst_1
    //   574: invokevirtual setUniqueIndex : (Z)V
    //   577: aload_0
    //   578: aload_2
    //   579: invokevirtual setUniqueIndexName : (Ljava/lang/String;)V
    //   582: goto -> 14
    //   585: aload_1
    //   586: ldc 'foreignAutoRefresh'
    //   588: invokevirtual equals : (Ljava/lang/Object;)Z
    //   591: ifeq -> 605
    //   594: aload_0
    //   595: aload_2
    //   596: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   599: invokevirtual setForeignAutoRefresh : (Z)V
    //   602: goto -> 14
    //   605: aload_1
    //   606: ldc 'maxForeignAutoRefreshLevel'
    //   608: invokevirtual equals : (Ljava/lang/Object;)Z
    //   611: ifeq -> 625
    //   614: aload_0
    //   615: aload_2
    //   616: invokestatic parseInt : (Ljava/lang/String;)I
    //   619: invokevirtual setMaxForeignAutoRefreshLevel : (I)V
    //   622: goto -> 14
    //   625: aload_1
    //   626: ldc 'persisterClass'
    //   628: invokevirtual equals : (Ljava/lang/Object;)Z
    //   631: ifeq -> 674
    //   634: aload_0
    //   635: aload_2
    //   636: invokestatic forName : (Ljava/lang/String;)Ljava/lang/Class;
    //   639: invokevirtual setPersisterClass : (Ljava/lang/Class;)V
    //   642: goto -> 14
    //   645: astore_0
    //   646: new java/lang/IllegalArgumentException
    //   649: dup
    //   650: new java/lang/StringBuilder
    //   653: dup
    //   654: invokespecial <init> : ()V
    //   657: ldc_w 'Could not find persisterClass: '
    //   660: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   663: aload_2
    //   664: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   667: invokevirtual toString : ()Ljava/lang/String;
    //   670: invokespecial <init> : (Ljava/lang/String;)V
    //   673: athrow
    //   674: aload_1
    //   675: ldc 'allowGeneratedIdInsert'
    //   677: invokevirtual equals : (Ljava/lang/Object;)Z
    //   680: ifeq -> 694
    //   683: aload_0
    //   684: aload_2
    //   685: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   688: invokevirtual setAllowGeneratedIdInsert : (Z)V
    //   691: goto -> 14
    //   694: aload_1
    //   695: ldc 'columnDefinition'
    //   697: invokevirtual equals : (Ljava/lang/Object;)Z
    //   700: ifeq -> 711
    //   703: aload_0
    //   704: aload_2
    //   705: invokevirtual setColumnDefinition : (Ljava/lang/String;)V
    //   708: goto -> 14
    //   711: aload_1
    //   712: ldc 'foreignAutoCreate'
    //   714: invokevirtual equals : (Ljava/lang/Object;)Z
    //   717: ifeq -> 731
    //   720: aload_0
    //   721: aload_2
    //   722: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   725: invokevirtual setForeignAutoCreate : (Z)V
    //   728: goto -> 14
    //   731: aload_1
    //   732: ldc 'version'
    //   734: invokevirtual equals : (Ljava/lang/Object;)Z
    //   737: ifeq -> 751
    //   740: aload_0
    //   741: aload_2
    //   742: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   745: invokevirtual setVersion : (Z)V
    //   748: goto -> 14
    //   751: aload_1
    //   752: ldc 'foreignColumnName'
    //   754: invokevirtual equals : (Ljava/lang/Object;)Z
    //   757: ifeq -> 768
    //   760: aload_0
    //   761: aload_2
    //   762: invokevirtual setForeignColumnName : (Ljava/lang/String;)V
    //   765: goto -> 14
    //   768: aload_1
    //   769: ldc 'readOnly'
    //   771: invokevirtual equals : (Ljava/lang/Object;)Z
    //   774: ifeq -> 788
    //   777: aload_0
    //   778: aload_2
    //   779: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   782: invokevirtual setReadOnly : (Z)V
    //   785: goto -> 14
    //   788: aload_1
    //   789: ldc 'foreignCollection'
    //   791: invokevirtual equals : (Ljava/lang/Object;)Z
    //   794: ifeq -> 808
    //   797: aload_0
    //   798: aload_2
    //   799: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   802: invokevirtual setForeignCollection : (Z)V
    //   805: goto -> 14
    //   808: aload_1
    //   809: ldc 'foreignCollectionEager'
    //   811: invokevirtual equals : (Ljava/lang/Object;)Z
    //   814: ifeq -> 828
    //   817: aload_0
    //   818: aload_2
    //   819: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   822: invokevirtual setForeignCollectionEager : (Z)V
    //   825: goto -> 14
    //   828: aload_1
    //   829: ldc 'maxEagerForeignCollectionLevel'
    //   831: invokevirtual equals : (Ljava/lang/Object;)Z
    //   834: ifeq -> 848
    //   837: aload_0
    //   838: aload_2
    //   839: invokestatic parseInt : (Ljava/lang/String;)I
    //   842: invokevirtual setForeignCollectionMaxEagerLevel : (I)V
    //   845: goto -> 14
    //   848: aload_1
    //   849: ldc 'foreignCollectionMaxEagerLevel'
    //   851: invokevirtual equals : (Ljava/lang/Object;)Z
    //   854: ifeq -> 868
    //   857: aload_0
    //   858: aload_2
    //   859: invokestatic parseInt : (Ljava/lang/String;)I
    //   862: invokevirtual setForeignCollectionMaxEagerLevel : (I)V
    //   865: goto -> 14
    //   868: aload_1
    //   869: ldc 'foreignCollectionColumnName'
    //   871: invokevirtual equals : (Ljava/lang/Object;)Z
    //   874: ifeq -> 885
    //   877: aload_0
    //   878: aload_2
    //   879: invokevirtual setForeignCollectionColumnName : (Ljava/lang/String;)V
    //   882: goto -> 14
    //   885: aload_1
    //   886: ldc 'foreignCollectionOrderColumn'
    //   888: invokevirtual equals : (Ljava/lang/Object;)Z
    //   891: ifeq -> 902
    //   894: aload_0
    //   895: aload_2
    //   896: invokevirtual setForeignCollectionOrderColumnName : (Ljava/lang/String;)V
    //   899: goto -> 14
    //   902: aload_1
    //   903: ldc 'foreignCollectionOrderColumnName'
    //   905: invokevirtual equals : (Ljava/lang/Object;)Z
    //   908: ifeq -> 919
    //   911: aload_0
    //   912: aload_2
    //   913: invokevirtual setForeignCollectionOrderColumnName : (Ljava/lang/String;)V
    //   916: goto -> 14
    //   919: aload_1
    //   920: ldc 'foreignCollectionOrderAscending'
    //   922: invokevirtual equals : (Ljava/lang/Object;)Z
    //   925: ifeq -> 939
    //   928: aload_0
    //   929: aload_2
    //   930: invokestatic parseBoolean : (Ljava/lang/String;)Z
    //   933: invokevirtual setForeignCollectionOrderAscending : (Z)V
    //   936: goto -> 14
    //   939: aload_1
    //   940: ldc 'foreignCollectionForeignColumnName'
    //   942: invokevirtual equals : (Ljava/lang/Object;)Z
    //   945: ifeq -> 956
    //   948: aload_0
    //   949: aload_2
    //   950: invokevirtual setForeignCollectionForeignFieldName : (Ljava/lang/String;)V
    //   953: goto -> 14
    //   956: aload_1
    //   957: ldc 'foreignCollectionForeignFieldName'
    //   959: invokevirtual equals : (Ljava/lang/Object;)Z
    //   962: ifeq -> 14
    //   965: aload_0
    //   966: aload_2
    //   967: invokevirtual setForeignCollectionForeignFieldName : (Ljava/lang/String;)V
    //   970: goto -> 14
    // Exception table:
    //   from	to	target	type
    //   261	268	305	java/lang/ClassNotFoundException
    //   634	642	645	java/lang/ClassNotFoundException
  }
  
  public static void write(BufferedWriter paramBufferedWriter, DatabaseFieldConfig paramDatabaseFieldConfig, String paramString) throws SQLException {
    try {
      writeConfig(paramBufferedWriter, paramDatabaseFieldConfig, paramString);
      return;
    } catch (IOException iOException) {
      throw SqlExceptionUtil.create("Could not write config to writer", iOException);
    } 
  }
  
  public static void writeConfig(BufferedWriter paramBufferedWriter, DatabaseFieldConfig paramDatabaseFieldConfig, String paramString) throws IOException {
    paramBufferedWriter.append("# --field-start--");
    paramBufferedWriter.newLine();
    if (paramDatabaseFieldConfig.getFieldName() != null) {
      paramBufferedWriter.append("fieldName").append('=').append(paramDatabaseFieldConfig.getFieldName());
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getColumnName() != null) {
      paramBufferedWriter.append("columnName").append('=').append(paramDatabaseFieldConfig.getColumnName());
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getDataPersister() != DEFAULT_DATA_PERSISTER) {
      boolean bool = false;
      DataType[] arrayOfDataType = DataType.values();
      int i = arrayOfDataType.length;
      byte b = 0;
      while (true) {
        boolean bool1 = bool;
        if (b < i) {
          DataType dataType = arrayOfDataType[b];
          if (dataType.getDataPersister() == paramDatabaseFieldConfig.getDataPersister()) {
            paramBufferedWriter.append("dataPersister").append('=').append(dataType.name());
            paramBufferedWriter.newLine();
            bool1 = true;
          } else {
            b++;
            continue;
          } 
        } 
        if (!bool1)
          throw new IllegalArgumentException("Unknown data persister field: " + paramDatabaseFieldConfig.getDataPersister()); 
        break;
      } 
    } 
    if (paramDatabaseFieldConfig.getDefaultValue() != null) {
      paramBufferedWriter.append("defaultValue").append('=').append(paramDatabaseFieldConfig.getDefaultValue());
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getWidth() != 0) {
      paramBufferedWriter.append("width").append('=').append(Integer.toString(paramDatabaseFieldConfig.getWidth()));
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isCanBeNull() != true) {
      paramBufferedWriter.append("canBeNull").append('=').append(Boolean.toString(paramDatabaseFieldConfig.isCanBeNull()));
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isId()) {
      paramBufferedWriter.append("id").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isGeneratedId()) {
      paramBufferedWriter.append("generatedId").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getGeneratedIdSequence() != null) {
      paramBufferedWriter.append("generatedIdSequence").append('=').append(paramDatabaseFieldConfig.getGeneratedIdSequence());
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isForeign()) {
      paramBufferedWriter.append("foreign").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isUseGetSet()) {
      paramBufferedWriter.append("useGetSet").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getUnknownEnumValue() != null) {
      paramBufferedWriter.append("unknownEnumValue").append('=').append(paramDatabaseFieldConfig.getUnknownEnumValue().getClass().getName()).append("#").append(paramDatabaseFieldConfig.getUnknownEnumValue().name());
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isThrowIfNull()) {
      paramBufferedWriter.append("throwIfNull").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getFormat() != null) {
      paramBufferedWriter.append("format").append('=').append(paramDatabaseFieldConfig.getFormat());
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isUnique()) {
      paramBufferedWriter.append("unique").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isUniqueCombo()) {
      paramBufferedWriter.append("uniqueCombo").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    String str = paramDatabaseFieldConfig.getIndexName(paramString);
    if (str != null) {
      paramBufferedWriter.append("indexName").append('=').append(str);
      paramBufferedWriter.newLine();
    } 
    paramString = paramDatabaseFieldConfig.getUniqueIndexName(paramString);
    if (paramString != null) {
      paramBufferedWriter.append("uniqueIndexName").append('=').append(paramString);
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isForeignAutoRefresh()) {
      paramBufferedWriter.append("foreignAutoRefresh").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getMaxForeignAutoRefreshLevel() != -1) {
      paramBufferedWriter.append("maxForeignAutoRefreshLevel").append('=').append(Integer.toString(paramDatabaseFieldConfig.getMaxForeignAutoRefreshLevel()));
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getPersisterClass() != DatabaseFieldConfig.DEFAULT_PERSISTER_CLASS) {
      paramBufferedWriter.append("persisterClass").append('=').append(paramDatabaseFieldConfig.getPersisterClass().getName());
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isAllowGeneratedIdInsert()) {
      paramBufferedWriter.append("allowGeneratedIdInsert").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getColumnDefinition() != null) {
      paramBufferedWriter.append("columnDefinition").append('=').append(paramDatabaseFieldConfig.getColumnDefinition());
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isForeignAutoCreate()) {
      paramBufferedWriter.append("foreignAutoCreate").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isVersion()) {
      paramBufferedWriter.append("version").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    paramString = paramDatabaseFieldConfig.getForeignColumnName();
    if (paramString != null) {
      paramBufferedWriter.append("foreignColumnName").append('=').append(paramString);
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isReadOnly()) {
      paramBufferedWriter.append("readOnly").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isForeignCollection()) {
      paramBufferedWriter.append("foreignCollection").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isForeignCollectionEager()) {
      paramBufferedWriter.append("foreignCollectionEager").append('=').append("true");
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getForeignCollectionMaxEagerLevel() != 1) {
      paramBufferedWriter.append("foreignCollectionMaxEagerLevel").append('=').append(Integer.toString(paramDatabaseFieldConfig.getForeignCollectionMaxEagerLevel()));
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getForeignCollectionColumnName() != null) {
      paramBufferedWriter.append("foreignCollectionColumnName").append('=').append(paramDatabaseFieldConfig.getForeignCollectionColumnName());
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getForeignCollectionOrderColumnName() != null) {
      paramBufferedWriter.append("foreignCollectionOrderColumnName").append('=').append(paramDatabaseFieldConfig.getForeignCollectionOrderColumnName());
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.isForeignCollectionOrderAscending() != true) {
      paramBufferedWriter.append("foreignCollectionOrderAscending").append('=').append(Boolean.toString(paramDatabaseFieldConfig.isForeignCollectionOrderAscending()));
      paramBufferedWriter.newLine();
    } 
    if (paramDatabaseFieldConfig.getForeignCollectionForeignFieldName() != null) {
      paramBufferedWriter.append("foreignCollectionForeignFieldName").append('=').append(paramDatabaseFieldConfig.getForeignCollectionForeignFieldName());
      paramBufferedWriter.newLine();
    } 
    paramBufferedWriter.append("# --field-end--");
    paramBufferedWriter.newLine();
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/field/DatabaseFieldConfigLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */