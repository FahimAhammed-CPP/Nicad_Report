package com.j256.ormlite.field;

import com.j256.ormlite.dao.BaseDaoImpl;
import com.j256.ormlite.dao.BaseForeignCollection;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DaoManager;
import com.j256.ormlite.dao.EagerForeignCollection;
import com.j256.ormlite.dao.ForeignCollection;
import com.j256.ormlite.dao.LazyForeignCollection;
import com.j256.ormlite.dao.ObjectCache;
import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.field.types.VoidType;
import com.j256.ormlite.misc.SqlExceptionUtil;
import com.j256.ormlite.stmt.mapped.MappedQueryForId;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.support.DatabaseResults;
import com.j256.ormlite.table.DatabaseTableConfig;
import com.j256.ormlite.table.TableInfo;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Map;

public class FieldType {
  private static boolean DEFAULT_VALUE_BOOLEAN = false;
  
  private static byte DEFAULT_VALUE_BYTE = 0;
  
  private static char DEFAULT_VALUE_CHAR = '\000';
  
  private static double DEFAULT_VALUE_DOUBLE = 0.0D;
  
  private static float DEFAULT_VALUE_FLOAT = 0.0F;
  
  private static int DEFAULT_VALUE_INT = 0;
  
  private static long DEFAULT_VALUE_LONG = 0L;
  
  private static short DEFAULT_VALUE_SHORT = 0;
  
  public static final String FOREIGN_ID_FIELD_SUFFIX = "_id";
  
  private static final ThreadLocal<LevelCounters> threadLevelCounters = new ThreadLocal<LevelCounters>() {
      protected FieldType.LevelCounters initialValue() {
        return new FieldType.LevelCounters();
      }
    };
  
  private final String columnName;
  
  private final ConnectionSource connectionSource;
  
  private DataPersister dataPersister;
  
  private Object dataTypeConfigObj;
  
  private Object defaultValue;
  
  private final Field field;
  
  private final DatabaseFieldConfig fieldConfig;
  
  private FieldConverter fieldConverter;
  
  private final Method fieldGetMethod;
  
  private final Method fieldSetMethod;
  
  private BaseDaoImpl<?, ?> foreignDao;
  
  private FieldType foreignFieldType;
  
  private FieldType foreignIdField;
  
  private TableInfo<?, ?> foreignTableInfo;
  
  private final String generatedIdSequence;
  
  private final boolean isGeneratedId;
  
  private final boolean isId;
  
  private MappedQueryForId<Object, Object> mappedQueryForId;
  
  private final String tableName;
  
  public FieldType(ConnectionSource paramConnectionSource, String paramString, Field paramField, DatabaseFieldConfig paramDatabaseFieldConfig, Class<?> paramClass) throws SQLException {
    Object object;
    this.connectionSource = paramConnectionSource;
    this.tableName = paramString;
    DatabaseType databaseType = paramConnectionSource.getDatabaseType();
    this.field = paramField;
    paramDatabaseFieldConfig.postProcess();
    Class<?> clazz = paramField.getType();
    if (paramDatabaseFieldConfig.getDataPersister() == null) {
      paramClass = paramDatabaseFieldConfig.getPersisterClass();
      if (paramClass == null || paramClass == VoidType.class) {
        DataPersister dataPersister = DataPersisterManager.lookupForField(paramField);
      } else {
        try {
          Method method = paramClass.getDeclaredMethod("getSingleton", new Class[0]);
          try {
            object = method.invoke(null, new Object[0]);
            if (object == null)
              throw new SQLException("Static getSingleton method should not return null on class " + paramClass); 
          } catch (InvocationTargetException null) {
            throw SqlExceptionUtil.create("Could not run getSingleton method on class " + paramClass, object.getTargetException());
          } catch (Exception null) {
            throw SqlExceptionUtil.create("Could not run getSingleton method on class " + paramClass, object);
          } 
        } catch (Exception null) {
          throw SqlExceptionUtil.create("Could not find getSingleton static method on class " + paramClass, object);
        } 
      } 
    } else {
      DataPersister dataPersister = paramDatabaseFieldConfig.getDataPersister();
      object = dataPersister;
      if (!dataPersister.isValidForField(paramField)) {
        object = new StringBuilder();
        object.append("Field class ").append(clazz.getName());
        object.append(" for field ").append(this);
        object.append(" is not valid for type ").append(dataPersister);
        Class<?> clazz1 = dataPersister.getPrimaryClass();
        if (clazz1 != null)
          object.append(", maybe should be " + clazz1); 
        throw new IllegalArgumentException(object.toString());
      } 
    } 
    String str1 = paramDatabaseFieldConfig.getForeignColumnName();
    String str2 = paramField.getName();
    if (paramDatabaseFieldConfig.isForeign() || paramDatabaseFieldConfig.isForeignAutoRefresh() || str1 != null) {
      if (object != null && object.isPrimitive())
        throw new IllegalArgumentException("Field " + this + " is a primitive class " + clazz + " but marked as foreign"); 
      if (str1 == null) {
        str1 = str2 + "_id";
      } else {
        str1 = str2 + "_" + str1;
      } 
      if (ForeignCollection.class.isAssignableFrom(clazz))
        throw new SQLException("Field '" + paramField.getName() + "' in class " + clazz + "' should use the @" + ForeignCollectionField.class.getSimpleName() + " annotation not foreign=true"); 
    } else {
      Type type;
      if (paramDatabaseFieldConfig.isForeignCollection()) {
        if (clazz != Collection.class && !ForeignCollection.class.isAssignableFrom(clazz))
          throw new SQLException("Field class for '" + paramField.getName() + "' must be of class " + ForeignCollection.class.getSimpleName() + " or Collection."); 
        type = paramField.getGenericType();
        if (!(type instanceof ParameterizedType))
          throw new SQLException("Field class for '" + paramField.getName() + "' must be a parameterized Collection."); 
        str1 = str2;
        if ((((ParameterizedType)type).getActualTypeArguments()).length == 0)
          throw new SQLException("Field class for '" + paramField.getName() + "' must be a parameterized Collection with at least 1 type."); 
      } else {
        str1 = str2;
        if (object == null) {
          str1 = str2;
          if (!paramDatabaseFieldConfig.isForeignCollection()) {
            if (byte[].class.isAssignableFrom((Class<?>)type))
              throw new SQLException("ORMLite does not know how to store " + type + " for field '" + paramField.getName() + "'. byte[] fields must specify dataType=DataType.BYTE_ARRAY or SERIALIZABLE"); 
            if (Serializable.class.isAssignableFrom((Class<?>)type))
              throw new SQLException("ORMLite does not know how to store " + type + " for field '" + paramField.getName() + "'.  Use another class, custom persister, or to serialize it use " + "dataType=DataType.SERIALIZABLE"); 
            throw new IllegalArgumentException("ORMLite does not know how to store " + type + " for field " + paramField.getName() + ". Use another class or a custom persister.");
          } 
        } 
      } 
    } 
  }
  
  private void assignDataType(DatabaseType paramDatabaseType, DataPersister paramDataPersister) throws SQLException {
    this.dataPersister = paramDataPersister;
    if (paramDataPersister == null) {
      if (!this.fieldConfig.isForeign() && !this.fieldConfig.isForeignCollection())
        throw new SQLException("Data persister for field " + this + " is null but the field is not a foreign or foreignCollection"); 
    } else {
      this.fieldConverter = paramDatabaseType.getFieldConverter(paramDataPersister);
      if (this.isGeneratedId && !paramDataPersister.isValidGeneratedType()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Generated-id field '").append(this.field.getName());
        stringBuilder.append("' in ").append(this.field.getDeclaringClass().getSimpleName());
        stringBuilder.append(" can't be type ").append(this.dataPersister.getSqlType());
        stringBuilder.append(".  Must be one of: ");
        for (DataType dataType : DataType.values()) {
          DataPersister dataPersister = dataType.getDataPersister();
          if (dataPersister != null && dataPersister.isValidGeneratedType())
            stringBuilder.append(dataType).append(' '); 
        } 
        throw new IllegalArgumentException(stringBuilder.toString());
      } 
      if (this.fieldConfig.isThrowIfNull() && !dataType.isPrimitive())
        throw new SQLException("Field " + this.field.getName() + " must be a primitive if set with throwIfNull"); 
      if (this.isId && !dataType.isAppropriateId())
        throw new SQLException("Field '" + this.field.getName() + "' is of data type " + dataType + " which cannot be the ID field"); 
      this.dataTypeConfigObj = dataType.makeConfigObject(this);
      String str = this.fieldConfig.getDefaultValue();
      if (str == null || str.equals("")) {
        this.defaultValue = null;
        return;
      } 
      if (this.isGeneratedId)
        throw new SQLException("Field '" + this.field.getName() + "' cannot be a generatedId and have a default value '" + str + "'"); 
      this.defaultValue = this.fieldConverter.parseDefaultString(this, str);
    } 
  }
  
  public static FieldType createFieldType(ConnectionSource paramConnectionSource, String paramString, Field paramField, Class<?> paramClass) throws SQLException {
    DatabaseFieldConfig databaseFieldConfig = DatabaseFieldConfig.fromField(paramConnectionSource.getDatabaseType(), paramString, paramField);
    return (databaseFieldConfig == null) ? null : new FieldType(paramConnectionSource, paramString, paramField, databaseFieldConfig, paramClass);
  }
  
  private FieldType findForeignFieldType(Class<?> paramClass1, Class<?> paramClass2, BaseDaoImpl<?, ?> paramBaseDaoImpl) throws SQLException {
    String str = this.fieldConfig.getForeignCollectionForeignFieldName();
    FieldType[] arrayOfFieldType = paramBaseDaoImpl.getTableInfo().getFieldTypes();
    int i = arrayOfFieldType.length;
    byte b = 0;
    while (b < i) {
      FieldType fieldType = arrayOfFieldType[b];
      if (fieldType.getType() == paramClass2 && (str == null || fieldType.getField().getName().equals(str))) {
        if (!fieldType.fieldConfig.isForeign() && !fieldType.fieldConfig.isForeignAutoRefresh())
          throw new SQLException("Foreign collection object " + paramClass1 + " for field '" + this.field.getName() + "' contains a field of class " + paramClass2 + " but it's not foreign"); 
      } else {
        b++;
        continue;
      } 
      return fieldType;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Foreign collection class ").append(paramClass1.getName());
    stringBuilder.append(" for field '").append(this.field.getName()).append("' column-name does not contain a foreign field");
    if (str != null)
      stringBuilder.append(" named '").append(str).append('\''); 
    stringBuilder.append(" of class ").append(paramClass2.getName());
    throw new SQLException(stringBuilder.toString());
  }
  
  private boolean isFieldValueDefault(Object paramObject) {
    return (paramObject == null) ? true : paramObject.equals(getJavaDefaultValueDefault());
  }
  
  public void assignField(Object paramObject1, Object paramObject2, boolean paramBoolean, ObjectCache paramObjectCache) throws SQLException {
    // Byte code:
    //   0: aload_2
    //   1: astore #5
    //   3: aload_0
    //   4: getfield foreignIdField : Lcom/j256/ormlite/field/FieldType;
    //   7: ifnull -> 118
    //   10: aload_2
    //   11: astore #5
    //   13: aload_2
    //   14: ifnull -> 118
    //   17: aload_0
    //   18: aload_1
    //   19: invokevirtual extractJavaFieldValue : (Ljava/lang/Object;)Ljava/lang/Object;
    //   22: astore #5
    //   24: aload #5
    //   26: ifnull -> 39
    //   29: aload #5
    //   31: aload_2
    //   32: invokevirtual equals : (Ljava/lang/Object;)Z
    //   35: ifeq -> 39
    //   38: return
    //   39: aload_2
    //   40: astore #5
    //   42: iload_3
    //   43: ifne -> 118
    //   46: getstatic com/j256/ormlite/field/FieldType.threadLevelCounters : Ljava/lang/ThreadLocal;
    //   49: invokevirtual get : ()Ljava/lang/Object;
    //   52: checkcast com/j256/ormlite/field/FieldType$LevelCounters
    //   55: astore #5
    //   57: aload #5
    //   59: getfield autoRefreshLevel : I
    //   62: ifne -> 77
    //   65: aload #5
    //   67: aload_0
    //   68: getfield fieldConfig : Lcom/j256/ormlite/field/DatabaseFieldConfig;
    //   71: invokevirtual getMaxForeignAutoRefreshLevel : ()I
    //   74: putfield autoRefreshLevelMax : I
    //   77: aload #5
    //   79: getfield autoRefreshLevel : I
    //   82: aload #5
    //   84: getfield autoRefreshLevelMax : I
    //   87: if_icmplt -> 175
    //   90: aload_0
    //   91: getfield foreignTableInfo : Lcom/j256/ormlite/table/TableInfo;
    //   94: invokevirtual createObject : ()Ljava/lang/Object;
    //   97: astore #5
    //   99: aload_0
    //   100: getfield foreignIdField : Lcom/j256/ormlite/field/FieldType;
    //   103: aload #5
    //   105: aload_2
    //   106: iconst_0
    //   107: aload #4
    //   109: invokevirtual assignField : (Ljava/lang/Object;Ljava/lang/Object;ZLcom/j256/ormlite/dao/ObjectCache;)V
    //   112: aload #5
    //   114: astore_2
    //   115: aload_2
    //   116: astore #5
    //   118: aload_0
    //   119: getfield fieldSetMethod : Ljava/lang/reflect/Method;
    //   122: ifnonnull -> 337
    //   125: aload_0
    //   126: getfield field : Ljava/lang/reflect/Field;
    //   129: aload_1
    //   130: aload #5
    //   132: invokevirtual set : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   135: goto -> 38
    //   138: astore_1
    //   139: new java/lang/StringBuilder
    //   142: dup
    //   143: invokespecial <init> : ()V
    //   146: ldc_w 'Could not assign object ''
    //   149: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   152: aload #5
    //   154: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   157: ldc_w '' to field '
    //   160: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   163: aload_0
    //   164: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   167: invokevirtual toString : ()Ljava/lang/String;
    //   170: aload_1
    //   171: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   174: athrow
    //   175: aload_0
    //   176: getfield mappedQueryForId : Lcom/j256/ormlite/stmt/mapped/MappedQueryForId;
    //   179: ifnonnull -> 209
    //   182: aload_0
    //   183: aload_0
    //   184: getfield connectionSource : Lcom/j256/ormlite/support/ConnectionSource;
    //   187: invokeinterface getDatabaseType : ()Lcom/j256/ormlite/db/DatabaseType;
    //   192: aload_0
    //   193: getfield foreignDao : Lcom/j256/ormlite/dao/BaseDaoImpl;
    //   196: invokevirtual getTableInfo : ()Lcom/j256/ormlite/table/TableInfo;
    //   199: aload_0
    //   200: getfield foreignIdField : Lcom/j256/ormlite/field/FieldType;
    //   203: invokestatic build : (Lcom/j256/ormlite/db/DatabaseType;Lcom/j256/ormlite/table/TableInfo;Lcom/j256/ormlite/field/FieldType;)Lcom/j256/ormlite/stmt/mapped/MappedQueryForId;
    //   206: putfield mappedQueryForId : Lcom/j256/ormlite/stmt/mapped/MappedQueryForId;
    //   209: aload #5
    //   211: aload #5
    //   213: getfield autoRefreshLevel : I
    //   216: iconst_1
    //   217: iadd
    //   218: putfield autoRefreshLevel : I
    //   221: aload_0
    //   222: getfield connectionSource : Lcom/j256/ormlite/support/ConnectionSource;
    //   225: invokeinterface getReadOnlyConnection : ()Lcom/j256/ormlite/support/DatabaseConnection;
    //   230: astore #6
    //   232: aload_0
    //   233: getfield mappedQueryForId : Lcom/j256/ormlite/stmt/mapped/MappedQueryForId;
    //   236: aload #6
    //   238: aload_2
    //   239: aload #4
    //   241: invokevirtual execute : (Lcom/j256/ormlite/support/DatabaseConnection;Ljava/lang/Object;Lcom/j256/ormlite/dao/ObjectCache;)Ljava/lang/Object;
    //   244: astore_2
    //   245: aload_0
    //   246: getfield connectionSource : Lcom/j256/ormlite/support/ConnectionSource;
    //   249: aload #6
    //   251: invokeinterface releaseConnection : (Lcom/j256/ormlite/support/DatabaseConnection;)V
    //   256: aload #5
    //   258: aload #5
    //   260: getfield autoRefreshLevel : I
    //   263: iconst_1
    //   264: isub
    //   265: putfield autoRefreshLevel : I
    //   268: goto -> 115
    //   271: astore_1
    //   272: aload_0
    //   273: getfield connectionSource : Lcom/j256/ormlite/support/ConnectionSource;
    //   276: aload #6
    //   278: invokeinterface releaseConnection : (Lcom/j256/ormlite/support/DatabaseConnection;)V
    //   283: aload_1
    //   284: athrow
    //   285: astore_1
    //   286: aload #5
    //   288: aload #5
    //   290: getfield autoRefreshLevel : I
    //   293: iconst_1
    //   294: isub
    //   295: putfield autoRefreshLevel : I
    //   298: aload_1
    //   299: athrow
    //   300: astore_1
    //   301: new java/lang/StringBuilder
    //   304: dup
    //   305: invokespecial <init> : ()V
    //   308: ldc_w 'Could not assign object ''
    //   311: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   314: aload #5
    //   316: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   319: ldc_w '' to field '
    //   322: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   325: aload_0
    //   326: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   329: invokevirtual toString : ()Ljava/lang/String;
    //   332: aload_1
    //   333: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   336: athrow
    //   337: aload_0
    //   338: getfield fieldSetMethod : Ljava/lang/reflect/Method;
    //   341: aload_1
    //   342: iconst_1
    //   343: anewarray java/lang/Object
    //   346: dup
    //   347: iconst_0
    //   348: aload #5
    //   350: aastore
    //   351: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   354: pop
    //   355: goto -> 38
    //   358: astore_1
    //   359: new java/lang/StringBuilder
    //   362: dup
    //   363: invokespecial <init> : ()V
    //   366: ldc_w 'Could not call '
    //   369: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   372: aload_0
    //   373: getfield fieldSetMethod : Ljava/lang/reflect/Method;
    //   376: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   379: ldc_w ' on object with ''
    //   382: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   385: aload #5
    //   387: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   390: ldc_w '' for '
    //   393: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   396: aload_0
    //   397: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   400: invokevirtual toString : ()Ljava/lang/String;
    //   403: aload_1
    //   404: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   407: athrow
    // Exception table:
    //   from	to	target	type
    //   125	135	138	java/lang/IllegalArgumentException
    //   125	135	300	java/lang/IllegalAccessException
    //   221	232	285	finally
    //   232	245	271	finally
    //   245	256	285	finally
    //   272	285	285	finally
    //   337	355	358	java/lang/Exception
  }
  
  public Object assignIdValue(Object paramObject, Number paramNumber, ObjectCache paramObjectCache) throws SQLException {
    Object object = this.dataPersister.convertIdNumber(paramNumber);
    if (object == null)
      throw new SQLException("Invalid class " + this.dataPersister + " for sequence-id " + this); 
    assignField(paramObject, object, false, paramObjectCache);
    return object;
  }
  
  public <FT, FID> BaseForeignCollection<FT, FID> buildForeignCollection(Object paramObject, FID paramFID) throws SQLException {
    if (this.foreignFieldType == null)
      return null; 
    BaseDaoImpl<?, ?> baseDaoImpl = this.foreignDao;
    if (!this.fieldConfig.isForeignCollectionEager())
      return (BaseForeignCollection<FT, FID>)new LazyForeignCollection((Dao)baseDaoImpl, paramObject, paramFID, this.foreignFieldType, this.fieldConfig.getForeignCollectionOrderColumnName(), this.fieldConfig.isForeignCollectionOrderAscending()); 
    LevelCounters levelCounters = threadLevelCounters.get();
    if (levelCounters.foreignCollectionLevel == 0)
      levelCounters.foreignCollectionLevelMax = this.fieldConfig.getForeignCollectionMaxEagerLevel(); 
    if (levelCounters.foreignCollectionLevel >= levelCounters.foreignCollectionLevelMax)
      return (BaseForeignCollection<FT, FID>)new LazyForeignCollection((Dao)baseDaoImpl, paramObject, paramFID, this.foreignFieldType, this.fieldConfig.getForeignCollectionOrderColumnName(), this.fieldConfig.isForeignCollectionOrderAscending()); 
    levelCounters.foreignCollectionLevel++;
    try {
      paramObject = new EagerForeignCollection((Dao)baseDaoImpl, paramObject, paramFID, this.foreignFieldType, this.fieldConfig.getForeignCollectionOrderColumnName(), this.fieldConfig.isForeignCollectionOrderAscending());
    } finally {
      levelCounters.foreignCollectionLevel--;
    } 
    return (BaseForeignCollection<FT, FID>)paramObject;
  }
  
  public void configDaoInformation(ConnectionSource paramConnectionSource, Class<?> paramClass) throws SQLException {
    BaseDaoImpl<?, ?> baseDaoImpl;
    DatabaseTableConfig<?> databaseTableConfig;
    MappedQueryForId<Object, Object> mappedQueryForId;
    TableInfo tableInfo;
    FieldType fieldType;
    Class<?> clazz = this.field.getType();
    DatabaseType databaseType = paramConnectionSource.getDatabaseType();
    String str = this.fieldConfig.getForeignColumnName();
    if (this.fieldConfig.isForeignAutoRefresh() || str != null) {
      databaseTableConfig = this.fieldConfig.getForeignTableConfig();
      if (databaseTableConfig == null) {
        baseDaoImpl = (BaseDaoImpl)DaoManager.createDao(paramConnectionSource, clazz);
        tableInfo = baseDaoImpl.getTableInfo();
      } else {
        databaseTableConfig.extractFieldTypes((ConnectionSource)baseDaoImpl);
        baseDaoImpl = (BaseDaoImpl)DaoManager.createDao((ConnectionSource)baseDaoImpl, databaseTableConfig);
        tableInfo = baseDaoImpl.getTableInfo();
      } 
      if (str == null) {
        FieldType fieldType1 = tableInfo.getIdField();
        fieldType = fieldType1;
        if (fieldType1 == null)
          throw new IllegalArgumentException("Foreign field " + clazz + " does not have id field"); 
      } else {
        FieldType fieldType1 = tableInfo.getFieldTypeByColumnName(str);
        fieldType = fieldType1;
        if (fieldType1 == null)
          throw new IllegalArgumentException("Foreign field " + clazz + " does not have field named '" + str + "'"); 
      } 
      mappedQueryForId = MappedQueryForId.build(databaseType, tableInfo, fieldType);
      databaseTableConfig = null;
    } else if (this.fieldConfig.isForeign()) {
      if (this.dataPersister != null && this.dataPersister.isPrimitive())
        throw new IllegalArgumentException("Field " + this + " is a primitive class " + mappedQueryForId + " but marked as foreign"); 
      databaseTableConfig = this.fieldConfig.getForeignTableConfig();
      if (databaseTableConfig != null) {
        databaseTableConfig.extractFieldTypes((ConnectionSource)baseDaoImpl);
        baseDaoImpl = (BaseDaoImpl)DaoManager.createDao((ConnectionSource)baseDaoImpl, databaseTableConfig);
      } else {
        baseDaoImpl = (BaseDaoImpl)DaoManager.createDao((ConnectionSource)baseDaoImpl, (Class)mappedQueryForId);
      } 
      tableInfo = baseDaoImpl.getTableInfo();
      fieldType = tableInfo.getIdField();
      if (fieldType == null)
        throw new IllegalArgumentException("Foreign field " + mappedQueryForId + " does not have id field"); 
      if (isForeignAutoCreate() && !fieldType.isGeneratedId())
        throw new IllegalArgumentException("Field " + this.field.getName() + ", if foreignAutoCreate = true then class " + mappedQueryForId.getSimpleName() + " must have id field with generatedId = true"); 
      databaseTableConfig = null;
      mappedQueryForId = null;
    } else if (this.fieldConfig.isForeignCollection()) {
      if (mappedQueryForId != Collection.class && !ForeignCollection.class.isAssignableFrom((Class<?>)mappedQueryForId))
        throw new SQLException("Field class for '" + this.field.getName() + "' must be of class " + ForeignCollection.class.getSimpleName() + " or Collection."); 
      Type type = this.field.getGenericType();
      if (!(type instanceof ParameterizedType))
        throw new SQLException("Field class for '" + this.field.getName() + "' must be a parameterized Collection."); 
      Type[] arrayOfType = ((ParameterizedType)type).getActualTypeArguments();
      if (arrayOfType.length == 0)
        throw new SQLException("Field class for '" + this.field.getName() + "' must be a parameterized Collection with at least 1 type."); 
      tableInfo = (TableInfo)arrayOfType[0];
      DatabaseTableConfig<?> databaseTableConfig1 = this.fieldConfig.getForeignTableConfig();
      if (databaseTableConfig1 == null) {
        baseDaoImpl = (BaseDaoImpl)DaoManager.createDao((ConnectionSource)baseDaoImpl, (Class)tableInfo);
      } else {
        baseDaoImpl = (BaseDaoImpl)DaoManager.createDao((ConnectionSource)baseDaoImpl, databaseTableConfig1);
      } 
      BaseDaoImpl<?, ?> baseDaoImpl1 = baseDaoImpl;
      FieldType fieldType1 = findForeignFieldType((Class<?>)tableInfo, (Class<?>)databaseTableConfig, baseDaoImpl);
      str = null;
      tableInfo = null;
      mappedQueryForId = null;
      baseDaoImpl = baseDaoImpl1;
      fieldType = (FieldType)str;
    } else {
      tableInfo = null;
      fieldType = null;
      databaseTableConfig = null;
      baseDaoImpl = null;
      mappedQueryForId = null;
    } 
    this.mappedQueryForId = mappedQueryForId;
    this.foreignTableInfo = tableInfo;
    this.foreignFieldType = (FieldType)databaseTableConfig;
    this.foreignDao = baseDaoImpl;
    this.foreignIdField = fieldType;
    if (this.foreignIdField != null)
      assignDataType(databaseType, this.foreignIdField.getDataPersister()); 
  }
  
  public Object convertJavaFieldToSqlArgValue(Object paramObject) throws SQLException {
    return (paramObject == null) ? null : this.fieldConverter.javaToSqlArg(this, paramObject);
  }
  
  public Object convertStringToJavaField(String paramString, int paramInt) throws SQLException {
    return (paramString == null) ? null : this.fieldConverter.resultStringToJava(this, paramString, paramInt);
  }
  
  public <T> int createWithForeignDao(T paramT) throws SQLException {
    return this.foreignDao.create(paramT);
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == null || paramObject.getClass() != getClass())
      return false; 
    paramObject = paramObject;
    return this.field.equals(((FieldType)paramObject).field);
  }
  
  public Object extractJavaFieldToSqlArgValue(Object paramObject) throws SQLException {
    return convertJavaFieldToSqlArgValue(extractJavaFieldValue(paramObject));
  }
  
  public Object extractJavaFieldValue(Object paramObject) throws SQLException {
    Object object = extractRawJavaFieldValue(paramObject);
    paramObject = object;
    if (this.foreignIdField != null) {
      paramObject = object;
      if (object != null)
        paramObject = this.foreignIdField.extractRawJavaFieldValue(object); 
    } 
    return paramObject;
  }
  
  public <FV> FV extractRawJavaFieldValue(Object paramObject) throws SQLException {
    if (this.fieldGetMethod == null)
      try {
        return (FV)this.field.get(paramObject);
      } catch (Exception null) {
        throw SqlExceptionUtil.create("Could not get field value for " + this, exception);
      }  
    try {
      Object object = this.fieldGetMethod.invoke(exception, new Object[0]);
    } catch (Exception exception) {
      throw SqlExceptionUtil.create("Could not call " + this.fieldGetMethod + " for " + this, exception);
    } 
    return (FV)exception;
  }
  
  public Object generateId() {
    return this.dataPersister.generateId();
  }
  
  public String getColumnDefinition() {
    return this.fieldConfig.getColumnDefinition();
  }
  
  public String getColumnName() {
    return this.columnName;
  }
  
  public DataPersister getDataPersister() {
    return this.dataPersister;
  }
  
  public Object getDataTypeConfigObj() {
    return this.dataTypeConfigObj;
  }
  
  public Object getDefaultValue() {
    return this.defaultValue;
  }
  
  public Field getField() {
    return this.field;
  }
  
  public String getFieldName() {
    return this.field.getName();
  }
  
  public <FV> FV getFieldValueIfNotDefault(Object paramObject) throws SQLException {
    Object object = extractJavaFieldValue(paramObject);
    paramObject = object;
    if (isFieldValueDefault(object))
      paramObject = null; 
    return (FV)paramObject;
  }
  
  public FieldType getForeignIdField() {
    return this.foreignIdField;
  }
  
  public String getFormat() {
    return this.fieldConfig.getFormat();
  }
  
  public String getGeneratedIdSequence() {
    return this.generatedIdSequence;
  }
  
  public String getIndexName() {
    return this.fieldConfig.getIndexName(this.tableName);
  }
  
  public Object getJavaDefaultValueDefault() {
    return (this.field.getType() == boolean.class) ? Boolean.valueOf(DEFAULT_VALUE_BOOLEAN) : ((this.field.getType() == byte.class || this.field.getType() == Byte.class) ? Byte.valueOf(DEFAULT_VALUE_BYTE) : ((this.field.getType() == char.class || this.field.getType() == Character.class) ? Character.valueOf(DEFAULT_VALUE_CHAR) : ((this.field.getType() == short.class || this.field.getType() == Short.class) ? Short.valueOf(DEFAULT_VALUE_SHORT) : ((this.field.getType() == int.class || this.field.getType() == Integer.class) ? Integer.valueOf(DEFAULT_VALUE_INT) : ((this.field.getType() == long.class || this.field.getType() == Long.class) ? Long.valueOf(DEFAULT_VALUE_LONG) : ((this.field.getType() == float.class || this.field.getType() == Float.class) ? Float.valueOf(DEFAULT_VALUE_FLOAT) : ((this.field.getType() == double.class || this.field.getType() == Double.class) ? Double.valueOf(DEFAULT_VALUE_DOUBLE) : null)))))));
  }
  
  public SqlType getSqlType() {
    return this.fieldConverter.getSqlType();
  }
  
  public String getTableName() {
    return this.tableName;
  }
  
  public Class<?> getType() {
    return this.field.getType();
  }
  
  public String getUniqueIndexName() {
    return this.fieldConfig.getUniqueIndexName(this.tableName);
  }
  
  public Enum<?> getUnknownEnumVal() {
    return this.fieldConfig.getUnknownEnumValue();
  }
  
  public int getWidth() {
    return this.fieldConfig.getWidth();
  }
  
  public int hashCode() {
    return this.field.hashCode();
  }
  
  public boolean isAllowGeneratedIdInsert() {
    return this.fieldConfig.isAllowGeneratedIdInsert();
  }
  
  public boolean isArgumentHolderRequired() {
    return this.dataPersister.isArgumentHolderRequired();
  }
  
  public boolean isCanBeNull() {
    return this.fieldConfig.isCanBeNull();
  }
  
  public boolean isComparable() throws SQLException {
    if (this.fieldConfig.isForeignCollection())
      return false; 
    if (this.dataPersister == null)
      throw new SQLException("Internal error.  Data-persister is not configured for field.  Please post _full_ exception with associated data objects to mailing list: " + this); 
    return this.dataPersister.isComparable();
  }
  
  public boolean isEscapedDefaultValue() {
    return this.dataPersister.isEscapedDefaultValue();
  }
  
  public boolean isEscapedValue() {
    return this.dataPersister.isEscapedValue();
  }
  
  public boolean isForeign() {
    return this.fieldConfig.isForeign();
  }
  
  public boolean isForeignAutoCreate() {
    return this.fieldConfig.isForeignAutoCreate();
  }
  
  public boolean isForeignCollection() {
    return this.fieldConfig.isForeignCollection();
  }
  
  public boolean isGeneratedId() {
    return this.isGeneratedId;
  }
  
  public boolean isGeneratedIdSequence() {
    return (this.generatedIdSequence != null);
  }
  
  public boolean isId() {
    return this.isId;
  }
  
  public boolean isObjectsFieldValueDefault(Object paramObject) throws SQLException {
    return isFieldValueDefault(extractJavaFieldValue(paramObject));
  }
  
  public boolean isReadOnly() {
    return this.fieldConfig.isReadOnly();
  }
  
  public boolean isSelfGeneratedId() {
    return this.dataPersister.isSelfGeneratedId();
  }
  
  public boolean isUnique() {
    return this.fieldConfig.isUnique();
  }
  
  public boolean isUniqueCombo() {
    return this.fieldConfig.isUniqueCombo();
  }
  
  public boolean isVersion() {
    return this.fieldConfig.isVersion();
  }
  
  public Object moveToNextValue(Object paramObject) {
    return (this.dataPersister == null) ? null : this.dataPersister.moveToNextValue(paramObject);
  }
  
  public <T> T resultToJava(DatabaseResults paramDatabaseResults, Map<String, Integer> paramMap) throws SQLException {
    Integer integer1 = paramMap.get(this.columnName);
    Integer integer2 = integer1;
    if (integer1 == null) {
      integer2 = Integer.valueOf(paramDatabaseResults.findColumn(this.columnName));
      paramMap.put(this.columnName, integer2);
    } 
    Object object2 = this.fieldConverter.resultToJava(this, paramDatabaseResults, integer2.intValue());
    if (this.fieldConfig.isForeign()) {
      Object object = object2;
      if (paramDatabaseResults.wasNull(integer2.intValue()))
        object = null; 
      return (T)object;
    } 
    if (this.dataPersister.isPrimitive()) {
      Object object = object2;
      if (this.fieldConfig.isThrowIfNull()) {
        object = object2;
        if (paramDatabaseResults.wasNull(integer2.intValue()))
          throw new SQLException("Results value for primitive field '" + this.field.getName() + "' was an invalid null value"); 
      } 
      return (T)object;
    } 
    Object object1 = object2;
    if (!this.fieldConverter.isStreamType()) {
      object1 = object2;
      if (paramDatabaseResults.wasNull(integer2.intValue()))
        object1 = null; 
    } 
    return (T)object1;
  }
  
  public String toString() {
    return getClass().getSimpleName() + ":name=" + this.field.getName() + ",class=" + this.field.getDeclaringClass().getSimpleName();
  }
  
  private static class LevelCounters {
    int autoRefreshLevel;
    
    int autoRefreshLevelMax;
    
    int foreignCollectionLevel;
    
    int foreignCollectionLevelMax;
    
    private LevelCounters() {}
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/field/FieldType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */