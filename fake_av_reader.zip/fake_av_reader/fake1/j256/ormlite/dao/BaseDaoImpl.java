package com.j256.ormlite.dao;

import com.j256.ormlite.db.DatabaseType;
import com.j256.ormlite.field.DataType;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.misc.BaseDaoEnabled;
import com.j256.ormlite.misc.SqlExceptionUtil;
import com.j256.ormlite.stmt.DeleteBuilder;
import com.j256.ormlite.stmt.GenericRowMapper;
import com.j256.ormlite.stmt.PreparedDelete;
import com.j256.ormlite.stmt.PreparedQuery;
import com.j256.ormlite.stmt.PreparedStmt;
import com.j256.ormlite.stmt.PreparedUpdate;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.stmt.SelectArg;
import com.j256.ormlite.stmt.StatementBuilder;
import com.j256.ormlite.stmt.StatementExecutor;
import com.j256.ormlite.stmt.UpdateBuilder;
import com.j256.ormlite.stmt.Where;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.support.DatabaseConnection;
import com.j256.ormlite.support.DatabaseResults;
import com.j256.ormlite.table.DatabaseTableConfig;
import com.j256.ormlite.table.ObjectFactory;
import com.j256.ormlite.table.TableInfo;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

public abstract class BaseDaoImpl<T, ID> implements Dao<T, ID> {
  private static final ThreadLocal<DaoConfigArray> daoConfigLevelLocal = new ThreadLocal<DaoConfigArray>() {
      protected BaseDaoImpl.DaoConfigArray initialValue() {
        return new BaseDaoImpl.DaoConfigArray();
      }
    };
  
  private static ReferenceObjectCache defaultObjectCache;
  
  protected ConnectionSource connectionSource;
  
  protected final Class<T> dataClass;
  
  protected DatabaseType databaseType;
  
  private boolean initialized;
  
  protected CloseableIterator<T> lastIterator;
  
  private ObjectCache objectCache;
  
  protected ObjectFactory<T> objectFactory;
  
  protected StatementExecutor<T, ID> statementExecutor;
  
  protected DatabaseTableConfig<T> tableConfig;
  
  protected TableInfo<T, ID> tableInfo;
  
  protected BaseDaoImpl(ConnectionSource paramConnectionSource, DatabaseTableConfig<T> paramDatabaseTableConfig) throws SQLException {
    this(paramConnectionSource, paramDatabaseTableConfig.getDataClass(), paramDatabaseTableConfig);
  }
  
  protected BaseDaoImpl(ConnectionSource paramConnectionSource, Class<T> paramClass) throws SQLException {
    this(paramConnectionSource, paramClass, null);
  }
  
  private BaseDaoImpl(ConnectionSource paramConnectionSource, Class<T> paramClass, DatabaseTableConfig<T> paramDatabaseTableConfig) throws SQLException {
    this.dataClass = paramClass;
    this.tableConfig = paramDatabaseTableConfig;
    if (paramConnectionSource != null) {
      this.connectionSource = paramConnectionSource;
      initialize();
    } 
  }
  
  protected BaseDaoImpl(Class<T> paramClass) throws SQLException {
    this(null, paramClass, null);
  }
  
  public static void clearAllInternalObjectCaches() {
    // Byte code:
    //   0: ldc com/j256/ormlite/dao/BaseDaoImpl
    //   2: monitorenter
    //   3: getstatic com/j256/ormlite/dao/BaseDaoImpl.defaultObjectCache : Lcom/j256/ormlite/dao/ReferenceObjectCache;
    //   6: ifnull -> 19
    //   9: getstatic com/j256/ormlite/dao/BaseDaoImpl.defaultObjectCache : Lcom/j256/ormlite/dao/ReferenceObjectCache;
    //   12: invokevirtual clearAll : ()V
    //   15: aconst_null
    //   16: putstatic com/j256/ormlite/dao/BaseDaoImpl.defaultObjectCache : Lcom/j256/ormlite/dao/ReferenceObjectCache;
    //   19: ldc com/j256/ormlite/dao/BaseDaoImpl
    //   21: monitorexit
    //   22: return
    //   23: astore_0
    //   24: ldc com/j256/ormlite/dao/BaseDaoImpl
    //   26: monitorexit
    //   27: aload_0
    //   28: athrow
    // Exception table:
    //   from	to	target	type
    //   3	19	23	finally
  }
  
  static <T, ID> Dao<T, ID> createDao(ConnectionSource paramConnectionSource, DatabaseTableConfig<T> paramDatabaseTableConfig) throws SQLException {
    return new BaseDaoImpl<T, ID>(paramConnectionSource, paramDatabaseTableConfig) {
      
      };
  }
  
  static <T, ID> Dao<T, ID> createDao(ConnectionSource paramConnectionSource, Class<T> paramClass) throws SQLException {
    return new BaseDaoImpl<T, ID>(paramConnectionSource, paramClass) {
      
      };
  }
  
  private CloseableIterator<T> createIterator(int paramInt) {
    try {
      return (CloseableIterator<T>)this.statementExecutor.buildIterator(this, this.connectionSource, paramInt, this.objectCache);
    } catch (Exception exception) {
      throw new IllegalStateException("Could not build iterator for " + this.dataClass, exception);
    } 
  }
  
  private CloseableIterator<T> createIterator(PreparedQuery<T> paramPreparedQuery, int paramInt) throws SQLException {
    try {
      return (CloseableIterator<T>)this.statementExecutor.buildIterator(this, this.connectionSource, (PreparedStmt)paramPreparedQuery, this.objectCache, paramInt);
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("Could not build prepared-query iterator for " + this.dataClass, sQLException);
    } 
  }
  
  private <FT> ForeignCollection<FT> makeEmptyForeignCollection(T paramT, String paramString) throws SQLException {
    BaseForeignCollection<FT> baseForeignCollection;
    ID iD;
    checkForInitialized();
    if (paramT == null) {
      Object object = null;
    } else {
      iD = extractId(paramT);
    } 
    for (FieldType fieldType : this.tableInfo.getFieldTypes()) {
      if (fieldType.getColumnName().equals(paramString)) {
        baseForeignCollection = fieldType.buildForeignCollection(paramT, iD);
        if (paramT != null)
          fieldType.assignField(paramT, baseForeignCollection, true, null); 
        return baseForeignCollection;
      } 
    } 
    throw new IllegalArgumentException("Could not find a field named " + baseForeignCollection);
  }
  
  private List<T> queryForFieldValues(Map<String, Object> paramMap, boolean paramBoolean) throws SQLException {
    checkForInitialized();
    QueryBuilder<T, ID> queryBuilder = queryBuilder();
    Where where = queryBuilder.where();
    for (Map.Entry<String, Object> entry : paramMap.entrySet()) {
      Object object1 = entry.getValue();
      Object object2 = object1;
      if (paramBoolean)
        object2 = new SelectArg(object1); 
      where.eq((String)entry.getKey(), object2);
    } 
    if (paramMap.size() == 0)
      return (List)Collections.emptyList(); 
    where.and(paramMap.size());
    return queryBuilder.query();
  }
  
  private List<T> queryForMatching(T paramT, boolean paramBoolean) throws SQLException {
    checkForInitialized();
    QueryBuilder<T, ID> queryBuilder = queryBuilder();
    Where where = queryBuilder.where();
    int i = 0;
    FieldType[] arrayOfFieldType = this.tableInfo.getFieldTypes();
    int j = arrayOfFieldType.length;
    byte b = 0;
    while (b < j) {
      FieldType fieldType = arrayOfFieldType[b];
      Object object = fieldType.getFieldValueIfNotDefault(paramT);
      int k = i;
      if (object != null) {
        Object object1 = object;
        if (paramBoolean)
          object1 = new SelectArg(object); 
        where.eq(fieldType.getColumnName(), object1);
        k = i + 1;
      } 
      b++;
      i = k;
    } 
    if (i == 0)
      return (List)Collections.emptyList(); 
    where.and(i);
    return queryBuilder.query();
  }
  
  public void assignEmptyForeignCollection(T paramT, String paramString) throws SQLException {
    makeEmptyForeignCollection(paramT, paramString);
  }
  
  public <CT> CT callBatchTasks(Callable<CT> paramCallable) throws SQLException {
    checkForInitialized();
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      boolean bool = this.connectionSource.saveSpecialConnection(databaseConnection);
      return (CT)this.statementExecutor.callBatchTasks(databaseConnection, bool, paramCallable);
    } finally {
      this.connectionSource.clearSpecialConnection(databaseConnection);
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  protected void checkForInitialized() {
    if (!this.initialized)
      throw new IllegalStateException("you must call initialize() before you can use the dao"); 
  }
  
  public void clearObjectCache() {
    if (this.objectCache != null)
      this.objectCache.clear(this.dataClass); 
  }
  
  public void closeLastIterator() throws SQLException {
    if (this.lastIterator != null) {
      this.lastIterator.close();
      this.lastIterator = null;
    } 
  }
  
  public CloseableIterator<T> closeableIterator() {
    return iterator(-1);
  }
  
  public void commit(DatabaseConnection paramDatabaseConnection) throws SQLException {
    paramDatabaseConnection.commit(null);
  }
  
  public long countOf() throws SQLException {
    checkForInitialized();
    DatabaseConnection databaseConnection = this.connectionSource.getReadOnlyConnection();
    try {
      return this.statementExecutor.queryForCountStar(databaseConnection);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public long countOf(PreparedQuery<T> paramPreparedQuery) throws SQLException {
    checkForInitialized();
    if (paramPreparedQuery.getType() != StatementBuilder.StatementType.SELECT_LONG)
      throw new IllegalArgumentException("Prepared query is not of type " + StatementBuilder.StatementType.SELECT_LONG + ", did you call QueryBuilder.setCountOf(true)?"); 
    DatabaseConnection databaseConnection = this.connectionSource.getReadOnlyConnection();
    try {
      return this.statementExecutor.queryForLong(databaseConnection, (PreparedStmt)paramPreparedQuery);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public int create(T paramT) throws SQLException {
    int i;
    checkForInitialized();
    if (paramT == null)
      return 0; 
    if (paramT instanceof BaseDaoEnabled)
      ((BaseDaoEnabled)paramT).setDao(this); 
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      i = this.statementExecutor.create(databaseConnection, paramT, this.objectCache);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
    return i;
  }
  
  public T createIfNotExists(T paramT) throws SQLException {
    if (paramT == null)
      return null; 
    T t = queryForSameId(paramT);
    if (t == null) {
      create(paramT);
      return paramT;
    } 
    return t;
  }
  
  public Dao.CreateOrUpdateStatus createOrUpdate(T paramT) throws SQLException {
    if (paramT == null)
      return new Dao.CreateOrUpdateStatus(false, false, 0); 
    ID iD = extractId(paramT);
    return (iD == null || !idExists(iD)) ? new Dao.CreateOrUpdateStatus(true, false, create(paramT)) : new Dao.CreateOrUpdateStatus(false, true, update(paramT));
  }
  
  public int delete(PreparedDelete<T> paramPreparedDelete) throws SQLException {
    checkForInitialized();
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      return this.statementExecutor.delete(databaseConnection, paramPreparedDelete);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public int delete(T paramT) throws SQLException {
    int i;
    checkForInitialized();
    if (paramT == null)
      return 0; 
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      i = this.statementExecutor.delete(databaseConnection, paramT, this.objectCache);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
    return i;
  }
  
  public int delete(Collection<T> paramCollection) throws SQLException {
    int i;
    checkForInitialized();
    if (paramCollection == null || paramCollection.isEmpty())
      return 0; 
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      i = this.statementExecutor.deleteObjects(databaseConnection, paramCollection, this.objectCache);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
    return i;
  }
  
  public DeleteBuilder<T, ID> deleteBuilder() {
    checkForInitialized();
    return new DeleteBuilder(this.databaseType, this.tableInfo, this);
  }
  
  public int deleteById(ID paramID) throws SQLException {
    int i;
    checkForInitialized();
    if (paramID == null)
      return 0; 
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      i = this.statementExecutor.deleteById(databaseConnection, paramID, this.objectCache);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
    return i;
  }
  
  public int deleteIds(Collection<ID> paramCollection) throws SQLException {
    int i;
    checkForInitialized();
    if (paramCollection == null || paramCollection.isEmpty())
      return 0; 
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      i = this.statementExecutor.deleteIds(databaseConnection, paramCollection, this.objectCache);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
    return i;
  }
  
  public void endThreadConnection(DatabaseConnection paramDatabaseConnection) throws SQLException {
    this.connectionSource.clearSpecialConnection(paramDatabaseConnection);
    this.connectionSource.releaseConnection(paramDatabaseConnection);
  }
  
  public int executeRaw(String paramString, String... paramVarArgs) throws SQLException {
    checkForInitialized();
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      return this.statementExecutor.executeRaw(databaseConnection, paramString, paramVarArgs);
    } catch (SQLException sQLException) {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      throw SqlExceptionUtil.create(stringBuilder.append("Could not run raw execute statement ").append(paramString).toString(), sQLException);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public int executeRawNoArgs(String paramString) throws SQLException {
    checkForInitialized();
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      return this.statementExecutor.executeRawNoArgs(databaseConnection, paramString);
    } catch (SQLException sQLException) {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      throw SqlExceptionUtil.create(stringBuilder.append("Could not run raw execute statement ").append(paramString).toString(), sQLException);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public ID extractId(T paramT) throws SQLException {
    checkForInitialized();
    FieldType fieldType = this.tableInfo.getIdField();
    if (fieldType == null)
      throw new SQLException("Class " + this.dataClass + " does not have an id field"); 
    return (ID)fieldType.extractJavaFieldValue(paramT);
  }
  
  public FieldType findForeignFieldType(Class<?> paramClass) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual checkForInitialized : ()V
    //   4: aload_0
    //   5: getfield tableInfo : Lcom/j256/ormlite/table/TableInfo;
    //   8: invokevirtual getFieldTypes : ()[Lcom/j256/ormlite/field/FieldType;
    //   11: astore_2
    //   12: aload_2
    //   13: arraylength
    //   14: istore_3
    //   15: iconst_0
    //   16: istore #4
    //   18: iload #4
    //   20: iload_3
    //   21: if_icmpge -> 50
    //   24: aload_2
    //   25: iload #4
    //   27: aaload
    //   28: astore #5
    //   30: aload #5
    //   32: invokevirtual getType : ()Ljava/lang/Class;
    //   35: aload_1
    //   36: if_acmpne -> 44
    //   39: aload #5
    //   41: astore_1
    //   42: aload_1
    //   43: areturn
    //   44: iinc #4, 1
    //   47: goto -> 18
    //   50: aconst_null
    //   51: astore_1
    //   52: goto -> 42
  }
  
  public ConnectionSource getConnectionSource() {
    return this.connectionSource;
  }
  
  public Class<T> getDataClass() {
    return this.dataClass;
  }
  
  public <FT> ForeignCollection<FT> getEmptyForeignCollection(String paramString) throws SQLException {
    return makeEmptyForeignCollection(null, paramString);
  }
  
  public ObjectCache getObjectCache() {
    return this.objectCache;
  }
  
  public ObjectFactory<T> getObjectFactory() {
    return this.objectFactory;
  }
  
  public RawRowMapper<T> getRawRowMapper() {
    return this.statementExecutor.getRawRowMapper();
  }
  
  public GenericRowMapper<T> getSelectStarRowMapper() throws SQLException {
    return this.statementExecutor.getSelectStarRowMapper();
  }
  
  public DatabaseTableConfig<T> getTableConfig() {
    return this.tableConfig;
  }
  
  public TableInfo<T, ID> getTableInfo() {
    return this.tableInfo;
  }
  
  public CloseableWrappedIterable<T> getWrappedIterable() {
    checkForInitialized();
    return new CloseableWrappedIterableImpl<T>(new CloseableIterable<T>() {
          public CloseableIterator<T> closeableIterator() {
            try {
              return BaseDaoImpl.this.createIterator(-1);
            } catch (Exception exception) {
              throw new IllegalStateException("Could not build iterator for " + BaseDaoImpl.this.dataClass, exception);
            } 
          }
          
          public Iterator<T> iterator() {
            return closeableIterator();
          }
        });
  }
  
  public CloseableWrappedIterable<T> getWrappedIterable(final PreparedQuery<T> preparedQuery) {
    checkForInitialized();
    return new CloseableWrappedIterableImpl<T>(new CloseableIterable<T>() {
          public CloseableIterator<T> closeableIterator() {
            try {
              return BaseDaoImpl.this.createIterator(preparedQuery, -1);
            } catch (Exception exception) {
              throw new IllegalStateException("Could not build prepared-query iterator for " + BaseDaoImpl.this.dataClass, exception);
            } 
          }
          
          public Iterator<T> iterator() {
            return closeableIterator();
          }
        });
  }
  
  public boolean idExists(ID paramID) throws SQLException {
    DatabaseConnection databaseConnection = this.connectionSource.getReadOnlyConnection();
    try {
      return this.statementExecutor.ifExists(databaseConnection, paramID);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public void initialize() throws SQLException {
    if (!this.initialized) {
      if (this.connectionSource == null)
        throw new IllegalStateException("connectionSource was never set on " + getClass().getSimpleName()); 
      this.databaseType = this.connectionSource.getDatabaseType();
      if (this.databaseType == null)
        throw new IllegalStateException("connectionSource is getting a null DatabaseType in " + getClass().getSimpleName()); 
      if (this.tableConfig == null) {
        this.tableInfo = new TableInfo(this.connectionSource, this, this.dataClass);
      } else {
        this.tableConfig.extractFieldTypes(this.connectionSource);
        this.tableInfo = new TableInfo(this.databaseType, this, this.tableConfig);
      } 
      this.statementExecutor = new StatementExecutor(this.databaseType, this.tableInfo, this);
      DaoConfigArray daoConfigArray = daoConfigLevelLocal.get();
      if (daoConfigArray.size() > 0) {
        daoConfigArray.addDao(this);
        return;
      } 
      daoConfigArray.addDao(this);
      byte b = 0;
      while (true) {
        try {
          if (b < daoConfigArray.size()) {
            BaseDaoImpl<?, ?> baseDaoImpl = daoConfigArray.get(b);
            DaoManager.registerDao(this.connectionSource, baseDaoImpl);
            try {
              FieldType[] arrayOfFieldType = baseDaoImpl.getTableInfo().getFieldTypes();
              int i = arrayOfFieldType.length;
              for (byte b1 = 0; b1 < i; b1++)
                arrayOfFieldType[b1].configDaoInformation(this.connectionSource, baseDaoImpl.getDataClass()); 
            } catch (SQLException sQLException) {
              DaoManager.unregisterDao(this.connectionSource, baseDaoImpl);
              throw sQLException;
            } 
            baseDaoImpl.initialized = true;
            b++;
            continue;
          } 
        } finally {
          daoConfigArray.clear();
        } 
        // Byte code: goto -> 7
      } 
    } 
  }
  
  public boolean isAutoCommit() throws SQLException {
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      return isAutoCommit(databaseConnection);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public boolean isAutoCommit(DatabaseConnection paramDatabaseConnection) throws SQLException {
    return paramDatabaseConnection.isAutoCommit();
  }
  
  public boolean isTableExists() throws SQLException {
    checkForInitialized();
    DatabaseConnection databaseConnection = this.connectionSource.getReadOnlyConnection();
    try {
      return databaseConnection.isTableExists(this.tableInfo.getTableName());
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public boolean isUpdatable() {
    return this.tableInfo.isUpdatable();
  }
  
  public CloseableIterator<T> iterator() {
    return iterator(-1);
  }
  
  public CloseableIterator<T> iterator(int paramInt) {
    checkForInitialized();
    this.lastIterator = createIterator(paramInt);
    return this.lastIterator;
  }
  
  public CloseableIterator<T> iterator(PreparedQuery<T> paramPreparedQuery) throws SQLException {
    return iterator(paramPreparedQuery, -1);
  }
  
  public CloseableIterator<T> iterator(PreparedQuery<T> paramPreparedQuery, int paramInt) throws SQLException {
    checkForInitialized();
    this.lastIterator = createIterator(paramPreparedQuery, paramInt);
    return this.lastIterator;
  }
  
  public T mapSelectStarRow(DatabaseResults paramDatabaseResults) throws SQLException {
    return (T)this.statementExecutor.getSelectStarRowMapper().mapRow(paramDatabaseResults);
  }
  
  public String objectToString(T paramT) {
    checkForInitialized();
    return this.tableInfo.objectToString(paramT);
  }
  
  public boolean objectsEqual(T paramT1, T paramT2) throws SQLException {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual checkForInitialized : ()V
    //   4: aload_0
    //   5: getfield tableInfo : Lcom/j256/ormlite/table/TableInfo;
    //   8: invokevirtual getFieldTypes : ()[Lcom/j256/ormlite/field/FieldType;
    //   11: astore_3
    //   12: aload_3
    //   13: arraylength
    //   14: istore #4
    //   16: iconst_0
    //   17: istore #5
    //   19: iload #5
    //   21: iload #4
    //   23: if_icmpge -> 77
    //   26: aload_3
    //   27: iload #5
    //   29: aaload
    //   30: astore #6
    //   32: aload #6
    //   34: aload_1
    //   35: invokevirtual extractJavaFieldValue : (Ljava/lang/Object;)Ljava/lang/Object;
    //   38: astore #7
    //   40: aload #6
    //   42: aload_2
    //   43: invokevirtual extractJavaFieldValue : (Ljava/lang/Object;)Ljava/lang/Object;
    //   46: astore #8
    //   48: aload #6
    //   50: invokevirtual getDataPersister : ()Lcom/j256/ormlite/field/DataPersister;
    //   53: aload #7
    //   55: aload #8
    //   57: invokeinterface dataIsEqual : (Ljava/lang/Object;Ljava/lang/Object;)Z
    //   62: ifne -> 71
    //   65: iconst_0
    //   66: istore #9
    //   68: iload #9
    //   70: ireturn
    //   71: iinc #5, 1
    //   74: goto -> 19
    //   77: iconst_1
    //   78: istore #9
    //   80: goto -> 68
  }
  
  public List<T> query(PreparedQuery<T> paramPreparedQuery) throws SQLException {
    checkForInitialized();
    return this.statementExecutor.query(this.connectionSource, (PreparedStmt)paramPreparedQuery, this.objectCache);
  }
  
  public QueryBuilder<T, ID> queryBuilder() {
    checkForInitialized();
    return new QueryBuilder(this.databaseType, this.tableInfo, this);
  }
  
  public List<T> queryForAll() throws SQLException {
    checkForInitialized();
    return this.statementExecutor.queryForAll(this.connectionSource, this.objectCache);
  }
  
  public List<T> queryForEq(String paramString, Object paramObject) throws SQLException {
    return queryBuilder().where().eq(paramString, paramObject).query();
  }
  
  public List<T> queryForFieldValues(Map<String, Object> paramMap) throws SQLException {
    return queryForFieldValues(paramMap, false);
  }
  
  public List<T> queryForFieldValuesArgs(Map<String, Object> paramMap) throws SQLException {
    return queryForFieldValues(paramMap, true);
  }
  
  public T queryForFirst(PreparedQuery<T> paramPreparedQuery) throws SQLException {
    checkForInitialized();
    DatabaseConnection databaseConnection = this.connectionSource.getReadOnlyConnection();
    try {
      return (T)this.statementExecutor.queryForFirst(databaseConnection, (PreparedStmt)paramPreparedQuery, this.objectCache);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public T queryForId(ID paramID) throws SQLException {
    checkForInitialized();
    DatabaseConnection databaseConnection = this.connectionSource.getReadOnlyConnection();
    try {
      paramID = (ID)this.statementExecutor.queryForId(databaseConnection, paramID, this.objectCache);
      return (T)paramID;
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public List<T> queryForMatching(T paramT) throws SQLException {
    return queryForMatching(paramT, false);
  }
  
  public List<T> queryForMatchingArgs(T paramT) throws SQLException {
    return queryForMatching(paramT, true);
  }
  
  public T queryForSameId(T paramT) throws SQLException {
    T t = null;
    checkForInitialized();
    if (paramT == null)
      return t; 
    ID iD = extractId(paramT);
    paramT = t;
    if (iD != null)
      paramT = queryForId(iD); 
    return paramT;
  }
  
  public <GR> GenericRawResults<GR> queryRaw(String paramString, RawRowMapper<GR> paramRawRowMapper, String... paramVarArgs) throws SQLException {
    checkForInitialized();
    try {
      return this.statementExecutor.queryRaw(this.connectionSource, paramString, paramRawRowMapper, paramVarArgs, this.objectCache);
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("Could not perform raw query for " + paramString, sQLException);
    } 
  }
  
  public GenericRawResults<Object[]> queryRaw(String paramString, DataType[] paramArrayOfDataType, String... paramVarArgs) throws SQLException {
    checkForInitialized();
    try {
      return this.statementExecutor.queryRaw(this.connectionSource, paramString, paramArrayOfDataType, paramVarArgs, this.objectCache);
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("Could not perform raw query for " + paramString, sQLException);
    } 
  }
  
  public GenericRawResults<String[]> queryRaw(String paramString, String... paramVarArgs) throws SQLException {
    checkForInitialized();
    try {
      return this.statementExecutor.queryRaw(this.connectionSource, paramString, paramVarArgs, this.objectCache);
    } catch (SQLException sQLException) {
      throw SqlExceptionUtil.create("Could not perform raw query for " + paramString, sQLException);
    } 
  }
  
  public long queryRawValue(String paramString, String... paramVarArgs) throws SQLException {
    checkForInitialized();
    DatabaseConnection databaseConnection = this.connectionSource.getReadOnlyConnection();
    try {
      return this.statementExecutor.queryForLong(databaseConnection, paramString, paramVarArgs);
    } catch (SQLException sQLException) {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      throw SqlExceptionUtil.create(stringBuilder.append("Could not perform raw value query for ").append(paramString).toString(), sQLException);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public int refresh(T paramT) throws SQLException {
    int i;
    checkForInitialized();
    if (paramT == null)
      return 0; 
    if (paramT instanceof BaseDaoEnabled)
      ((BaseDaoEnabled)paramT).setDao(this); 
    DatabaseConnection databaseConnection = this.connectionSource.getReadOnlyConnection();
    try {
      i = this.statementExecutor.refresh(databaseConnection, paramT, this.objectCache);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
    return i;
  }
  
  public void rollBack(DatabaseConnection paramDatabaseConnection) throws SQLException {
    paramDatabaseConnection.rollback(null);
  }
  
  public void setAutoCommit(DatabaseConnection paramDatabaseConnection, boolean paramBoolean) throws SQLException {
    paramDatabaseConnection.setAutoCommit(paramBoolean);
  }
  
  public void setAutoCommit(boolean paramBoolean) throws SQLException {
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      setAutoCommit(databaseConnection, paramBoolean);
      return;
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public void setConnectionSource(ConnectionSource paramConnectionSource) {
    this.connectionSource = paramConnectionSource;
  }
  
  public void setObjectCache(ObjectCache paramObjectCache) throws SQLException {
    if (paramObjectCache == null) {
      if (this.objectCache != null) {
        this.objectCache.clear(this.dataClass);
        this.objectCache = null;
      } 
      return;
    } 
    if (this.objectCache != null && this.objectCache != paramObjectCache)
      this.objectCache.clear(this.dataClass); 
    if (this.tableInfo.getIdField() == null)
      throw new SQLException("Class " + this.dataClass + " must have an id field to enable the object cache"); 
    this.objectCache = paramObjectCache;
    this.objectCache.registerClass(this.dataClass);
  }
  
  public void setObjectCache(boolean paramBoolean) throws SQLException {
    if (paramBoolean) {
      if (this.objectCache == null) {
        if (this.tableInfo.getIdField() == null)
          throw new SQLException("Class " + this.dataClass + " must have an id field to enable the object cache"); 
        synchronized (getClass()) {
          if (defaultObjectCache == null)
            defaultObjectCache = ReferenceObjectCache.makeWeakCache(); 
          this.objectCache = defaultObjectCache;
          this.objectCache.registerClass(this.dataClass);
          return;
        } 
      } 
      return;
    } 
    if (this.objectCache != null) {
      this.objectCache.clear(this.dataClass);
      this.objectCache = null;
    } 
  }
  
  public void setObjectFactory(ObjectFactory<T> paramObjectFactory) {
    checkForInitialized();
    this.objectFactory = paramObjectFactory;
  }
  
  public void setTableConfig(DatabaseTableConfig<T> paramDatabaseTableConfig) {
    this.tableConfig = paramDatabaseTableConfig;
  }
  
  public DatabaseConnection startThreadConnection() throws SQLException {
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    this.connectionSource.saveSpecialConnection(databaseConnection);
    return databaseConnection;
  }
  
  public int update(PreparedUpdate<T> paramPreparedUpdate) throws SQLException {
    checkForInitialized();
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      return this.statementExecutor.update(databaseConnection, paramPreparedUpdate);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  public int update(T paramT) throws SQLException {
    int i;
    checkForInitialized();
    if (paramT == null)
      return 0; 
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      i = this.statementExecutor.update(databaseConnection, paramT, this.objectCache);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
    return i;
  }
  
  public UpdateBuilder<T, ID> updateBuilder() {
    checkForInitialized();
    return new UpdateBuilder(this.databaseType, this.tableInfo, this);
  }
  
  public int updateId(T paramT, ID paramID) throws SQLException {
    int i;
    checkForInitialized();
    if (paramT == null)
      return 0; 
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      i = this.statementExecutor.updateId(databaseConnection, paramT, paramID, this.objectCache);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
    return i;
  }
  
  public int updateRaw(String paramString, String... paramVarArgs) throws SQLException {
    checkForInitialized();
    DatabaseConnection databaseConnection = this.connectionSource.getReadWriteConnection();
    try {
      return this.statementExecutor.updateRaw(databaseConnection, paramString, paramVarArgs);
    } catch (SQLException sQLException) {
      StringBuilder stringBuilder = new StringBuilder();
      this();
      throw SqlExceptionUtil.create(stringBuilder.append("Could not run raw update statement ").append(paramString).toString(), sQLException);
    } finally {
      this.connectionSource.releaseConnection(databaseConnection);
    } 
  }
  
  private static class DaoConfigArray {
    private BaseDaoImpl<?, ?>[] daoArray = (BaseDaoImpl<?, ?>[])new BaseDaoImpl[10];
    
    private int daoArrayC = 0;
    
    private DaoConfigArray() {}
    
    public void addDao(BaseDaoImpl<?, ?> param1BaseDaoImpl) {
      if (this.daoArrayC == this.daoArray.length) {
        BaseDaoImpl[] arrayOfBaseDaoImpl1 = new BaseDaoImpl[this.daoArray.length * 2];
        for (byte b = 0; b < this.daoArray.length; b++) {
          arrayOfBaseDaoImpl1[b] = this.daoArray[b];
          this.daoArray[b] = null;
        } 
        this.daoArray = (BaseDaoImpl<?, ?>[])arrayOfBaseDaoImpl1;
      } 
      BaseDaoImpl<?, ?>[] arrayOfBaseDaoImpl = this.daoArray;
      int i = this.daoArrayC;
      this.daoArrayC = i + 1;
      arrayOfBaseDaoImpl[i] = param1BaseDaoImpl;
    }
    
    public void clear() {
      for (byte b = 0; b < this.daoArrayC; b++)
        this.daoArray[b] = null; 
      this.daoArrayC = 0;
    }
    
    public BaseDaoImpl<?, ?> get(int param1Int) {
      return this.daoArray[param1Int];
    }
    
    public int size() {
      return this.daoArrayC;
    }
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/dao/BaseDaoImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */