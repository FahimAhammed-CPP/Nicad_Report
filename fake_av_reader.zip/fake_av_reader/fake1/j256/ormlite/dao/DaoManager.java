package com.j256.ormlite.dao;

import com.j256.ormlite.logger.Logger;
import com.j256.ormlite.logger.LoggerFactory;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.DatabaseTableConfig;
import java.lang.reflect.Constructor;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class DaoManager {
  private static Map<ClassConnectionSource, Dao<?, ?>> classMap;
  
  private static Map<Class<?>, DatabaseTableConfig<?>> configMap = null;
  
  private static Logger logger;
  
  private static Map<TableConfigConnectionSource, Dao<?, ?>> tableConfigMap;
  
  static {
    classMap = null;
    tableConfigMap = null;
    logger = LoggerFactory.getLogger(DaoManager.class);
  }
  
  public static void addCachedDatabaseConfigs(Collection<DatabaseTableConfig<?>> paramCollection) {
    // Byte code:
    //   0: ldc com/j256/ormlite/dao/DaoManager
    //   2: monitorenter
    //   3: getstatic com/j256/ormlite/dao/DaoManager.configMap : Ljava/util/Map;
    //   6: ifnonnull -> 76
    //   9: new java/util/HashMap
    //   12: astore_1
    //   13: aload_1
    //   14: invokespecial <init> : ()V
    //   17: aload_0
    //   18: invokeinterface iterator : ()Ljava/util/Iterator;
    //   23: astore_0
    //   24: aload_0
    //   25: invokeinterface hasNext : ()Z
    //   30: ifeq -> 90
    //   33: aload_0
    //   34: invokeinterface next : ()Ljava/lang/Object;
    //   39: checkcast com/j256/ormlite/table/DatabaseTableConfig
    //   42: astore_2
    //   43: aload_1
    //   44: aload_2
    //   45: invokevirtual getDataClass : ()Ljava/lang/Class;
    //   48: aload_2
    //   49: invokeinterface put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   54: pop
    //   55: getstatic com/j256/ormlite/dao/DaoManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   58: ldc 'Loaded configuration for {}'
    //   60: aload_2
    //   61: invokevirtual getDataClass : ()Ljava/lang/Class;
    //   64: invokevirtual info : (Ljava/lang/String;Ljava/lang/Object;)V
    //   67: goto -> 24
    //   70: astore_0
    //   71: ldc com/j256/ormlite/dao/DaoManager
    //   73: monitorexit
    //   74: aload_0
    //   75: athrow
    //   76: new java/util/HashMap
    //   79: dup
    //   80: getstatic com/j256/ormlite/dao/DaoManager.configMap : Ljava/util/Map;
    //   83: invokespecial <init> : (Ljava/util/Map;)V
    //   86: astore_1
    //   87: goto -> 17
    //   90: aload_1
    //   91: putstatic com/j256/ormlite/dao/DaoManager.configMap : Ljava/util/Map;
    //   94: ldc com/j256/ormlite/dao/DaoManager
    //   96: monitorexit
    //   97: return
    // Exception table:
    //   from	to	target	type
    //   3	17	70	finally
    //   17	24	70	finally
    //   24	67	70	finally
    //   76	87	70	finally
    //   90	94	70	finally
  }
  
  private static void addDaoToClassMap(ClassConnectionSource paramClassConnectionSource, Dao<?, ?> paramDao) {
    if (classMap == null)
      classMap = new HashMap<ClassConnectionSource, Dao<?, ?>>(); 
    classMap.put(paramClassConnectionSource, paramDao);
  }
  
  private static void addDaoToTableMap(TableConfigConnectionSource paramTableConfigConnectionSource, Dao<?, ?> paramDao) {
    if (tableConfigMap == null)
      tableConfigMap = new HashMap<TableConfigConnectionSource, Dao<?, ?>>(); 
    tableConfigMap.put(paramTableConfigConnectionSource, paramDao);
  }
  
  public static void clearCache() {
    // Byte code:
    //   0: ldc com/j256/ormlite/dao/DaoManager
    //   2: monitorenter
    //   3: getstatic com/j256/ormlite/dao/DaoManager.configMap : Ljava/util/Map;
    //   6: ifnull -> 21
    //   9: getstatic com/j256/ormlite/dao/DaoManager.configMap : Ljava/util/Map;
    //   12: invokeinterface clear : ()V
    //   17: aconst_null
    //   18: putstatic com/j256/ormlite/dao/DaoManager.configMap : Ljava/util/Map;
    //   21: invokestatic clearDaoCache : ()V
    //   24: ldc com/j256/ormlite/dao/DaoManager
    //   26: monitorexit
    //   27: return
    //   28: astore_0
    //   29: ldc com/j256/ormlite/dao/DaoManager
    //   31: monitorexit
    //   32: aload_0
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	28	finally
    //   21	24	28	finally
  }
  
  public static void clearDaoCache() {
    // Byte code:
    //   0: ldc com/j256/ormlite/dao/DaoManager
    //   2: monitorenter
    //   3: getstatic com/j256/ormlite/dao/DaoManager.classMap : Ljava/util/Map;
    //   6: ifnull -> 21
    //   9: getstatic com/j256/ormlite/dao/DaoManager.classMap : Ljava/util/Map;
    //   12: invokeinterface clear : ()V
    //   17: aconst_null
    //   18: putstatic com/j256/ormlite/dao/DaoManager.classMap : Ljava/util/Map;
    //   21: getstatic com/j256/ormlite/dao/DaoManager.tableConfigMap : Ljava/util/Map;
    //   24: ifnull -> 39
    //   27: getstatic com/j256/ormlite/dao/DaoManager.tableConfigMap : Ljava/util/Map;
    //   30: invokeinterface clear : ()V
    //   35: aconst_null
    //   36: putstatic com/j256/ormlite/dao/DaoManager.tableConfigMap : Ljava/util/Map;
    //   39: ldc com/j256/ormlite/dao/DaoManager
    //   41: monitorexit
    //   42: return
    //   43: astore_0
    //   44: ldc com/j256/ormlite/dao/DaoManager
    //   46: monitorexit
    //   47: aload_0
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   3	21	43	finally
    //   21	39	43	finally
  }
  
  public static <D extends Dao<T, ?>, T> D createDao(ConnectionSource paramConnectionSource, DatabaseTableConfig<T> paramDatabaseTableConfig) throws SQLException {
    // Byte code:
    //   0: ldc com/j256/ormlite/dao/DaoManager
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnonnull -> 25
    //   7: new java/lang/IllegalArgumentException
    //   10: astore_0
    //   11: aload_0
    //   12: ldc 'connectionSource argument cannot be null'
    //   14: invokespecial <init> : (Ljava/lang/String;)V
    //   17: aload_0
    //   18: athrow
    //   19: astore_0
    //   20: ldc com/j256/ormlite/dao/DaoManager
    //   22: monitorexit
    //   23: aload_0
    //   24: athrow
    //   25: aload_0
    //   26: aload_1
    //   27: invokestatic doCreateDao : (Lcom/j256/ormlite/support/ConnectionSource;Lcom/j256/ormlite/table/DatabaseTableConfig;)Lcom/j256/ormlite/dao/Dao;
    //   30: astore_0
    //   31: ldc com/j256/ormlite/dao/DaoManager
    //   33: monitorexit
    //   34: aload_0
    //   35: areturn
    // Exception table:
    //   from	to	target	type
    //   7	19	19	finally
    //   25	31	19	finally
  }
  
  public static <D extends Dao<T, ?>, T> D createDao(ConnectionSource paramConnectionSource, Class<T> paramClass) throws SQLException {
    // Byte code:
    //   0: ldc com/j256/ormlite/dao/DaoManager
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnonnull -> 25
    //   7: new java/lang/IllegalArgumentException
    //   10: astore_0
    //   11: aload_0
    //   12: ldc 'connectionSource argument cannot be null'
    //   14: invokespecial <init> : (Ljava/lang/String;)V
    //   17: aload_0
    //   18: athrow
    //   19: astore_0
    //   20: ldc com/j256/ormlite/dao/DaoManager
    //   22: monitorexit
    //   23: aload_0
    //   24: athrow
    //   25: new com/j256/ormlite/dao/DaoManager$ClassConnectionSource
    //   28: astore_2
    //   29: aload_2
    //   30: aload_0
    //   31: aload_1
    //   32: invokespecial <init> : (Lcom/j256/ormlite/support/ConnectionSource;Ljava/lang/Class;)V
    //   35: aload_2
    //   36: invokestatic lookupDao : (Lcom/j256/ormlite/dao/DaoManager$ClassConnectionSource;)Lcom/j256/ormlite/dao/Dao;
    //   39: astore_2
    //   40: aload_2
    //   41: ifnull -> 51
    //   44: aload_2
    //   45: astore_0
    //   46: ldc com/j256/ormlite/dao/DaoManager
    //   48: monitorexit
    //   49: aload_0
    //   50: areturn
    //   51: aload_0
    //   52: aload_1
    //   53: invokestatic createDaoFromConfig : (Lcom/j256/ormlite/support/ConnectionSource;Ljava/lang/Class;)Ljava/lang/Object;
    //   56: checkcast com/j256/ormlite/dao/Dao
    //   59: astore_2
    //   60: aload_2
    //   61: ifnull -> 69
    //   64: aload_2
    //   65: astore_0
    //   66: goto -> 46
    //   69: aload_1
    //   70: ldc com/j256/ormlite/table/DatabaseTable
    //   72: invokevirtual getAnnotation : (Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    //   75: checkcast com/j256/ormlite/table/DatabaseTable
    //   78: astore_2
    //   79: aload_2
    //   80: ifnull -> 105
    //   83: aload_2
    //   84: invokeinterface daoClass : ()Ljava/lang/Class;
    //   89: ldc java/lang/Void
    //   91: if_acmpeq -> 105
    //   94: aload_2
    //   95: invokeinterface daoClass : ()Ljava/lang/Class;
    //   100: ldc com/j256/ormlite/dao/BaseDaoImpl
    //   102: if_acmpne -> 159
    //   105: aload_0
    //   106: invokeinterface getDatabaseType : ()Lcom/j256/ormlite/db/DatabaseType;
    //   111: aload_0
    //   112: aload_1
    //   113: invokeinterface extractDatabaseTableConfig : (Lcom/j256/ormlite/support/ConnectionSource;Ljava/lang/Class;)Lcom/j256/ormlite/table/DatabaseTableConfig;
    //   118: astore_2
    //   119: aload_2
    //   120: ifnonnull -> 150
    //   123: aload_0
    //   124: aload_1
    //   125: invokestatic createDao : (Lcom/j256/ormlite/support/ConnectionSource;Ljava/lang/Class;)Lcom/j256/ormlite/dao/Dao;
    //   128: astore_2
    //   129: getstatic com/j256/ormlite/dao/DaoManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   132: ldc 'created dao for class {} with reflection'
    //   134: aload_1
    //   135: invokevirtual debug : (Ljava/lang/String;Ljava/lang/Object;)V
    //   138: aload_2
    //   139: astore_1
    //   140: aload_0
    //   141: aload_1
    //   142: invokestatic registerDao : (Lcom/j256/ormlite/support/ConnectionSource;Lcom/j256/ormlite/dao/Dao;)V
    //   145: aload_1
    //   146: astore_0
    //   147: goto -> 46
    //   150: aload_0
    //   151: aload_2
    //   152: invokestatic createDao : (Lcom/j256/ormlite/support/ConnectionSource;Lcom/j256/ormlite/table/DatabaseTableConfig;)Lcom/j256/ormlite/dao/Dao;
    //   155: astore_2
    //   156: goto -> 129
    //   159: aload_2
    //   160: invokeinterface daoClass : ()Ljava/lang/Class;
    //   165: astore_3
    //   166: iconst_2
    //   167: anewarray java/lang/Object
    //   170: astore #4
    //   172: aload #4
    //   174: iconst_0
    //   175: aload_0
    //   176: aastore
    //   177: aload #4
    //   179: iconst_1
    //   180: aload_1
    //   181: aastore
    //   182: aload_3
    //   183: aload #4
    //   185: invokestatic findConstructor : (Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/reflect/Constructor;
    //   188: astore #5
    //   190: aload #5
    //   192: astore_2
    //   193: aload #5
    //   195: ifnonnull -> 261
    //   198: iconst_1
    //   199: anewarray java/lang/Object
    //   202: astore #4
    //   204: aload #4
    //   206: iconst_0
    //   207: aload_0
    //   208: aastore
    //   209: aload_3
    //   210: aload #4
    //   212: invokestatic findConstructor : (Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/reflect/Constructor;
    //   215: astore #5
    //   217: aload #5
    //   219: astore_2
    //   220: aload #5
    //   222: ifnonnull -> 261
    //   225: new java/sql/SQLException
    //   228: astore_0
    //   229: new java/lang/StringBuilder
    //   232: astore_1
    //   233: aload_1
    //   234: invokespecial <init> : ()V
    //   237: aload_0
    //   238: aload_1
    //   239: ldc 'Could not find public constructor with ConnectionSource and optional Class parameters '
    //   241: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   244: aload_3
    //   245: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   248: ldc '.  Missing static on class?'
    //   250: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   253: invokevirtual toString : ()Ljava/lang/String;
    //   256: invokespecial <init> : (Ljava/lang/String;)V
    //   259: aload_0
    //   260: athrow
    //   261: aload_2
    //   262: aload #4
    //   264: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
    //   267: checkcast com/j256/ormlite/dao/Dao
    //   270: astore_2
    //   271: getstatic com/j256/ormlite/dao/DaoManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   274: ldc 'created dao for class {} from constructor'
    //   276: aload_1
    //   277: invokevirtual debug : (Ljava/lang/String;Ljava/lang/Object;)V
    //   280: aload_2
    //   281: astore_1
    //   282: goto -> 140
    //   285: astore_0
    //   286: new java/lang/StringBuilder
    //   289: astore_1
    //   290: aload_1
    //   291: invokespecial <init> : ()V
    //   294: aload_1
    //   295: ldc 'Could not call the constructor in class '
    //   297: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   300: aload_3
    //   301: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   304: invokevirtual toString : ()Ljava/lang/String;
    //   307: aload_0
    //   308: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   311: athrow
    // Exception table:
    //   from	to	target	type
    //   7	19	19	finally
    //   25	40	19	finally
    //   51	60	19	finally
    //   69	79	19	finally
    //   83	105	19	finally
    //   105	119	19	finally
    //   123	129	19	finally
    //   129	138	19	finally
    //   140	145	19	finally
    //   150	156	19	finally
    //   159	172	19	finally
    //   182	190	19	finally
    //   198	204	19	finally
    //   209	217	19	finally
    //   225	261	19	finally
    //   261	280	285	java/lang/Exception
    //   261	280	19	finally
    //   286	312	19	finally
  }
  
  private static <D, T> D createDaoFromConfig(ConnectionSource paramConnectionSource, Class<T> paramClass) throws SQLException {
    Class<T> clazz = null;
    if (configMap == null)
      return (D)clazz; 
    DatabaseTableConfig<?> databaseTableConfig = configMap.get(paramClass);
    paramClass = clazz;
    if (databaseTableConfig != null)
      paramClass = doCreateDao(paramConnectionSource, databaseTableConfig); 
    return (D)paramClass;
  }
  
  private static <D extends Dao<T, ?>, T> D doCreateDao(ConnectionSource paramConnectionSource, DatabaseTableConfig<T> paramDatabaseTableConfig) throws SQLException {
    // Byte code:
    //   0: new com/j256/ormlite/dao/DaoManager$TableConfigConnectionSource
    //   3: dup
    //   4: aload_0
    //   5: aload_1
    //   6: invokespecial <init> : (Lcom/j256/ormlite/support/ConnectionSource;Lcom/j256/ormlite/table/DatabaseTableConfig;)V
    //   9: astore_2
    //   10: aload_2
    //   11: invokestatic lookupDao : (Lcom/j256/ormlite/dao/DaoManager$TableConfigConnectionSource;)Lcom/j256/ormlite/dao/Dao;
    //   14: astore_3
    //   15: aload_3
    //   16: ifnull -> 23
    //   19: aload_3
    //   20: astore_0
    //   21: aload_0
    //   22: areturn
    //   23: aload_1
    //   24: invokevirtual getDataClass : ()Ljava/lang/Class;
    //   27: astore #4
    //   29: new com/j256/ormlite/dao/DaoManager$ClassConnectionSource
    //   32: dup
    //   33: aload_0
    //   34: aload #4
    //   36: invokespecial <init> : (Lcom/j256/ormlite/support/ConnectionSource;Ljava/lang/Class;)V
    //   39: astore #5
    //   41: aload #5
    //   43: invokestatic lookupDao : (Lcom/j256/ormlite/dao/DaoManager$ClassConnectionSource;)Lcom/j256/ormlite/dao/Dao;
    //   46: astore_3
    //   47: aload_3
    //   48: ifnull -> 61
    //   51: aload_2
    //   52: aload_3
    //   53: invokestatic addDaoToTableMap : (Lcom/j256/ormlite/dao/DaoManager$TableConfigConnectionSource;Lcom/j256/ormlite/dao/Dao;)V
    //   56: aload_3
    //   57: astore_0
    //   58: goto -> 21
    //   61: aload_1
    //   62: invokevirtual getDataClass : ()Ljava/lang/Class;
    //   65: ldc com/j256/ormlite/table/DatabaseTable
    //   67: invokevirtual getAnnotation : (Ljava/lang/Class;)Ljava/lang/annotation/Annotation;
    //   70: checkcast com/j256/ormlite/table/DatabaseTable
    //   73: astore_3
    //   74: aload_3
    //   75: ifnull -> 100
    //   78: aload_3
    //   79: invokeinterface daoClass : ()Ljava/lang/Class;
    //   84: ldc java/lang/Void
    //   86: if_acmpeq -> 100
    //   89: aload_3
    //   90: invokeinterface daoClass : ()Ljava/lang/Class;
    //   95: ldc com/j256/ormlite/dao/BaseDaoImpl
    //   97: if_acmpne -> 138
    //   100: aload_0
    //   101: aload_1
    //   102: invokestatic createDao : (Lcom/j256/ormlite/support/ConnectionSource;Lcom/j256/ormlite/table/DatabaseTableConfig;)Lcom/j256/ormlite/dao/Dao;
    //   105: astore_0
    //   106: aload_2
    //   107: aload_0
    //   108: invokestatic addDaoToTableMap : (Lcom/j256/ormlite/dao/DaoManager$TableConfigConnectionSource;Lcom/j256/ormlite/dao/Dao;)V
    //   111: getstatic com/j256/ormlite/dao/DaoManager.logger : Lcom/j256/ormlite/logger/Logger;
    //   114: ldc 'created dao for class {} from table config'
    //   116: aload #4
    //   118: invokevirtual debug : (Ljava/lang/String;Ljava/lang/Object;)V
    //   121: aload #5
    //   123: invokestatic lookupDao : (Lcom/j256/ormlite/dao/DaoManager$ClassConnectionSource;)Lcom/j256/ormlite/dao/Dao;
    //   126: ifnonnull -> 135
    //   129: aload #5
    //   131: aload_0
    //   132: invokestatic addDaoToClassMap : (Lcom/j256/ormlite/dao/DaoManager$ClassConnectionSource;Lcom/j256/ormlite/dao/Dao;)V
    //   135: goto -> 21
    //   138: aload_3
    //   139: invokeinterface daoClass : ()Ljava/lang/Class;
    //   144: astore_3
    //   145: iconst_2
    //   146: anewarray java/lang/Object
    //   149: astore #6
    //   151: aload #6
    //   153: iconst_0
    //   154: aload_0
    //   155: aastore
    //   156: aload #6
    //   158: iconst_1
    //   159: aload_1
    //   160: aastore
    //   161: aload_3
    //   162: aload #6
    //   164: invokestatic findConstructor : (Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/reflect/Constructor;
    //   167: astore_0
    //   168: aload_0
    //   169: ifnonnull -> 199
    //   172: new java/sql/SQLException
    //   175: dup
    //   176: new java/lang/StringBuilder
    //   179: dup
    //   180: invokespecial <init> : ()V
    //   183: ldc 'Could not find public constructor with ConnectionSource, DatabaseTableConfig parameters in class '
    //   185: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   188: aload_3
    //   189: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   192: invokevirtual toString : ()Ljava/lang/String;
    //   195: invokespecial <init> : (Ljava/lang/String;)V
    //   198: athrow
    //   199: aload_0
    //   200: aload #6
    //   202: invokevirtual newInstance : ([Ljava/lang/Object;)Ljava/lang/Object;
    //   205: checkcast com/j256/ormlite/dao/Dao
    //   208: astore_0
    //   209: goto -> 106
    //   212: astore_0
    //   213: new java/lang/StringBuilder
    //   216: dup
    //   217: invokespecial <init> : ()V
    //   220: ldc 'Could not call the constructor in class '
    //   222: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: aload_3
    //   226: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   229: invokevirtual toString : ()Ljava/lang/String;
    //   232: aload_0
    //   233: invokestatic create : (Ljava/lang/String;Ljava/lang/Throwable;)Ljava/sql/SQLException;
    //   236: athrow
    // Exception table:
    //   from	to	target	type
    //   199	209	212	java/lang/Exception
  }
  
  private static Constructor<?> findConstructor(Class<?> paramClass, Object[] paramArrayOfObject) {
    for (Constructor<?> constructor : paramClass.getConstructors()) {
      Class[] arrayOfClass = constructor.getParameterTypes();
      if (arrayOfClass.length == paramArrayOfObject.length) {
        boolean bool = true;
        byte b = 0;
        while (true) {
          boolean bool1 = bool;
          if (b < arrayOfClass.length)
            if (!arrayOfClass[b].isAssignableFrom(paramArrayOfObject[b].getClass())) {
              bool1 = false;
            } else {
              b++;
              continue;
            }  
          if (bool1)
            return constructor; 
          break;
        } 
      } 
    } 
    return null;
  }
  
  private static <T> Dao<?, ?> lookupDao(ClassConnectionSource paramClassConnectionSource) {
    if (classMap == null)
      classMap = new HashMap<ClassConnectionSource, Dao<?, ?>>(); 
    Dao<?, ?> dao2 = classMap.get(paramClassConnectionSource);
    Dao<?, ?> dao1 = dao2;
    if (dao2 == null)
      dao1 = null; 
    return dao1;
  }
  
  private static <T> Dao<?, ?> lookupDao(TableConfigConnectionSource paramTableConfigConnectionSource) {
    if (tableConfigMap == null)
      tableConfigMap = new HashMap<TableConfigConnectionSource, Dao<?, ?>>(); 
    Dao<?, ?> dao2 = tableConfigMap.get(paramTableConfigConnectionSource);
    Dao<?, ?> dao1 = dao2;
    if (dao2 == null)
      dao1 = null; 
    return dao1;
  }
  
  public static <D extends Dao<T, ?>, T> D lookupDao(ConnectionSource paramConnectionSource, DatabaseTableConfig<T> paramDatabaseTableConfig) {
    // Byte code:
    //   0: ldc com/j256/ormlite/dao/DaoManager
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnonnull -> 25
    //   7: new java/lang/IllegalArgumentException
    //   10: astore_0
    //   11: aload_0
    //   12: ldc 'connectionSource argument cannot be null'
    //   14: invokespecial <init> : (Ljava/lang/String;)V
    //   17: aload_0
    //   18: athrow
    //   19: astore_0
    //   20: ldc com/j256/ormlite/dao/DaoManager
    //   22: monitorexit
    //   23: aload_0
    //   24: athrow
    //   25: new com/j256/ormlite/dao/DaoManager$TableConfigConnectionSource
    //   28: astore_2
    //   29: aload_2
    //   30: aload_0
    //   31: aload_1
    //   32: invokespecial <init> : (Lcom/j256/ormlite/support/ConnectionSource;Lcom/j256/ormlite/table/DatabaseTableConfig;)V
    //   35: aload_2
    //   36: invokestatic lookupDao : (Lcom/j256/ormlite/dao/DaoManager$TableConfigConnectionSource;)Lcom/j256/ormlite/dao/Dao;
    //   39: astore_0
    //   40: aload_0
    //   41: ifnonnull -> 51
    //   44: aconst_null
    //   45: astore_0
    //   46: ldc com/j256/ormlite/dao/DaoManager
    //   48: monitorexit
    //   49: aload_0
    //   50: areturn
    //   51: goto -> 46
    // Exception table:
    //   from	to	target	type
    //   7	19	19	finally
    //   25	40	19	finally
  }
  
  public static <D extends Dao<T, ?>, T> D lookupDao(ConnectionSource paramConnectionSource, Class<T> paramClass) {
    // Byte code:
    //   0: ldc com/j256/ormlite/dao/DaoManager
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnonnull -> 25
    //   7: new java/lang/IllegalArgumentException
    //   10: astore_0
    //   11: aload_0
    //   12: ldc 'connectionSource argument cannot be null'
    //   14: invokespecial <init> : (Ljava/lang/String;)V
    //   17: aload_0
    //   18: athrow
    //   19: astore_0
    //   20: ldc com/j256/ormlite/dao/DaoManager
    //   22: monitorexit
    //   23: aload_0
    //   24: athrow
    //   25: new com/j256/ormlite/dao/DaoManager$ClassConnectionSource
    //   28: astore_2
    //   29: aload_2
    //   30: aload_0
    //   31: aload_1
    //   32: invokespecial <init> : (Lcom/j256/ormlite/support/ConnectionSource;Ljava/lang/Class;)V
    //   35: aload_2
    //   36: invokestatic lookupDao : (Lcom/j256/ormlite/dao/DaoManager$ClassConnectionSource;)Lcom/j256/ormlite/dao/Dao;
    //   39: astore_0
    //   40: ldc com/j256/ormlite/dao/DaoManager
    //   42: monitorexit
    //   43: aload_0
    //   44: areturn
    // Exception table:
    //   from	to	target	type
    //   7	19	19	finally
    //   25	40	19	finally
  }
  
  public static void registerDao(ConnectionSource paramConnectionSource, Dao<?, ?> paramDao) {
    // Byte code:
    //   0: ldc com/j256/ormlite/dao/DaoManager
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnonnull -> 25
    //   7: new java/lang/IllegalArgumentException
    //   10: astore_0
    //   11: aload_0
    //   12: ldc 'connectionSource argument cannot be null'
    //   14: invokespecial <init> : (Ljava/lang/String;)V
    //   17: aload_0
    //   18: athrow
    //   19: astore_0
    //   20: ldc com/j256/ormlite/dao/DaoManager
    //   22: monitorexit
    //   23: aload_0
    //   24: athrow
    //   25: new com/j256/ormlite/dao/DaoManager$ClassConnectionSource
    //   28: astore_2
    //   29: aload_2
    //   30: aload_0
    //   31: aload_1
    //   32: invokeinterface getDataClass : ()Ljava/lang/Class;
    //   37: invokespecial <init> : (Lcom/j256/ormlite/support/ConnectionSource;Ljava/lang/Class;)V
    //   40: aload_2
    //   41: aload_1
    //   42: invokestatic addDaoToClassMap : (Lcom/j256/ormlite/dao/DaoManager$ClassConnectionSource;Lcom/j256/ormlite/dao/Dao;)V
    //   45: ldc com/j256/ormlite/dao/DaoManager
    //   47: monitorexit
    //   48: return
    // Exception table:
    //   from	to	target	type
    //   7	19	19	finally
    //   25	45	19	finally
  }
  
  public static void registerDaoWithTableConfig(ConnectionSource paramConnectionSource, Dao<?, ?> paramDao) {
    // Byte code:
    //   0: ldc com/j256/ormlite/dao/DaoManager
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnonnull -> 25
    //   7: new java/lang/IllegalArgumentException
    //   10: astore_0
    //   11: aload_0
    //   12: ldc 'connectionSource argument cannot be null'
    //   14: invokespecial <init> : (Ljava/lang/String;)V
    //   17: aload_0
    //   18: athrow
    //   19: astore_0
    //   20: ldc com/j256/ormlite/dao/DaoManager
    //   22: monitorexit
    //   23: aload_0
    //   24: athrow
    //   25: aload_1
    //   26: instanceof com/j256/ormlite/dao/BaseDaoImpl
    //   29: ifeq -> 63
    //   32: aload_1
    //   33: checkcast com/j256/ormlite/dao/BaseDaoImpl
    //   36: invokevirtual getTableConfig : ()Lcom/j256/ormlite/table/DatabaseTableConfig;
    //   39: astore_2
    //   40: aload_2
    //   41: ifnull -> 63
    //   44: new com/j256/ormlite/dao/DaoManager$TableConfigConnectionSource
    //   47: astore_3
    //   48: aload_3
    //   49: aload_0
    //   50: aload_2
    //   51: invokespecial <init> : (Lcom/j256/ormlite/support/ConnectionSource;Lcom/j256/ormlite/table/DatabaseTableConfig;)V
    //   54: aload_3
    //   55: aload_1
    //   56: invokestatic addDaoToTableMap : (Lcom/j256/ormlite/dao/DaoManager$TableConfigConnectionSource;Lcom/j256/ormlite/dao/Dao;)V
    //   59: ldc com/j256/ormlite/dao/DaoManager
    //   61: monitorexit
    //   62: return
    //   63: new com/j256/ormlite/dao/DaoManager$ClassConnectionSource
    //   66: astore_2
    //   67: aload_2
    //   68: aload_0
    //   69: aload_1
    //   70: invokeinterface getDataClass : ()Ljava/lang/Class;
    //   75: invokespecial <init> : (Lcom/j256/ormlite/support/ConnectionSource;Ljava/lang/Class;)V
    //   78: aload_2
    //   79: aload_1
    //   80: invokestatic addDaoToClassMap : (Lcom/j256/ormlite/dao/DaoManager$ClassConnectionSource;Lcom/j256/ormlite/dao/Dao;)V
    //   83: goto -> 59
    // Exception table:
    //   from	to	target	type
    //   7	19	19	finally
    //   25	40	19	finally
    //   44	59	19	finally
    //   63	83	19	finally
  }
  
  private static void removeDaoToClassMap(ClassConnectionSource paramClassConnectionSource, Dao<?, ?> paramDao) {
    if (classMap != null)
      classMap.remove(paramClassConnectionSource); 
  }
  
  public static void unregisterDao(ConnectionSource paramConnectionSource, Dao<?, ?> paramDao) {
    // Byte code:
    //   0: ldc com/j256/ormlite/dao/DaoManager
    //   2: monitorenter
    //   3: aload_0
    //   4: ifnonnull -> 25
    //   7: new java/lang/IllegalArgumentException
    //   10: astore_0
    //   11: aload_0
    //   12: ldc 'connectionSource argument cannot be null'
    //   14: invokespecial <init> : (Ljava/lang/String;)V
    //   17: aload_0
    //   18: athrow
    //   19: astore_0
    //   20: ldc com/j256/ormlite/dao/DaoManager
    //   22: monitorexit
    //   23: aload_0
    //   24: athrow
    //   25: new com/j256/ormlite/dao/DaoManager$ClassConnectionSource
    //   28: astore_2
    //   29: aload_2
    //   30: aload_0
    //   31: aload_1
    //   32: invokeinterface getDataClass : ()Ljava/lang/Class;
    //   37: invokespecial <init> : (Lcom/j256/ormlite/support/ConnectionSource;Ljava/lang/Class;)V
    //   40: aload_2
    //   41: aload_1
    //   42: invokestatic removeDaoToClassMap : (Lcom/j256/ormlite/dao/DaoManager$ClassConnectionSource;Lcom/j256/ormlite/dao/Dao;)V
    //   45: ldc com/j256/ormlite/dao/DaoManager
    //   47: monitorexit
    //   48: return
    // Exception table:
    //   from	to	target	type
    //   7	19	19	finally
    //   25	45	19	finally
  }
  
  private static class ClassConnectionSource {
    Class<?> clazz;
    
    ConnectionSource connectionSource;
    
    public ClassConnectionSource(ConnectionSource param1ConnectionSource, Class<?> param1Class) {
      this.connectionSource = param1ConnectionSource;
      this.clazz = param1Class;
    }
    
    public boolean equals(Object param1Object) {
      boolean bool1 = false;
      boolean bool2 = bool1;
      if (param1Object != null) {
        if (getClass() != param1Object.getClass())
          return bool1; 
      } else {
        return bool2;
      } 
      param1Object = param1Object;
      bool2 = bool1;
      if (this.clazz.equals(((ClassConnectionSource)param1Object).clazz)) {
        bool2 = bool1;
        if (this.connectionSource.equals(((ClassConnectionSource)param1Object).connectionSource))
          bool2 = true; 
      } 
      return bool2;
    }
    
    public int hashCode() {
      return (this.clazz.hashCode() + 31) * 31 + this.connectionSource.hashCode();
    }
  }
  
  private static class TableConfigConnectionSource {
    ConnectionSource connectionSource;
    
    DatabaseTableConfig<?> tableConfig;
    
    public TableConfigConnectionSource(ConnectionSource param1ConnectionSource, DatabaseTableConfig<?> param1DatabaseTableConfig) {
      this.connectionSource = param1ConnectionSource;
      this.tableConfig = param1DatabaseTableConfig;
    }
    
    public boolean equals(Object param1Object) {
      boolean bool1 = false;
      boolean bool2 = bool1;
      if (param1Object != null) {
        if (getClass() != param1Object.getClass())
          return bool1; 
      } else {
        return bool2;
      } 
      param1Object = param1Object;
      bool2 = bool1;
      if (this.tableConfig.equals(((TableConfigConnectionSource)param1Object).tableConfig)) {
        bool2 = bool1;
        if (this.connectionSource.equals(((TableConfigConnectionSource)param1Object).connectionSource))
          bool2 = true; 
      } 
      return bool2;
    }
    
    public int hashCode() {
      return (this.tableConfig.hashCode() + 31) * 31 + this.connectionSource.hashCode();
    }
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/dao/DaoManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */