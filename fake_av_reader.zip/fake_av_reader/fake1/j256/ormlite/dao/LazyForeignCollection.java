package com.j256.ormlite.dao;

import com.j256.ormlite.field.FieldType;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public class LazyForeignCollection<T, ID> extends BaseForeignCollection<T, ID> implements ForeignCollection<T>, Serializable {
  private static final long serialVersionUID = -5460708106909626233L;
  
  private transient CloseableIterator<T> lastIterator;
  
  public LazyForeignCollection(Dao<T, ID> paramDao, Object paramObject1, Object paramObject2, FieldType paramFieldType, String paramString, boolean paramBoolean) {
    super(paramDao, paramObject1, paramObject2, paramFieldType, paramString, paramBoolean);
  }
  
  public void closeLastIterator() throws SQLException {
    if (this.lastIterator != null) {
      this.lastIterator.close();
      this.lastIterator = null;
    } 
  }
  
  public CloseableIterator<T> closeableIterator() {
    try {
      return iteratorThrow();
    } catch (SQLException sQLException) {
      throw new IllegalStateException("Could not build lazy iterator for " + this.dao.getDataClass(), sQLException);
    } 
  }
  
  public boolean contains(Object paramObject) {
    CloseableIterator<T> closeableIterator = iterator();
    try {
      while (closeableIterator.hasNext()) {
        boolean bool = closeableIterator.next().equals(paramObject);
        if (bool) {
          bool = true;
          return bool;
        } 
      } 
      return false;
    } finally {
      try {
        closeableIterator.close();
      } catch (SQLException sQLException) {}
    } 
  }
  
  public boolean containsAll(Collection<?> paramCollection) {
    boolean bool;
    paramCollection = new HashSet(paramCollection);
    CloseableIterator<T> closeableIterator = iterator();
    try {
      while (closeableIterator.hasNext())
        paramCollection.remove(closeableIterator.next()); 
    } finally {
      try {
        closeableIterator.close();
      } catch (SQLException sQLException) {}
    } 
    try {
      sQLException.close();
    } catch (SQLException sQLException1) {}
    return bool;
  }
  
  public boolean equals(Object paramObject) {
    return super.equals(paramObject);
  }
  
  public CloseableWrappedIterable<T> getWrappedIterable() {
    return new CloseableWrappedIterableImpl<T>(new CloseableIterable<T>() {
          public CloseableIterator<T> closeableIterator() {
            try {
              return LazyForeignCollection.this.seperateIteratorThrow();
            } catch (Exception exception) {
              throw new IllegalStateException("Could not build lazy iterator for " + LazyForeignCollection.this.dao.getDataClass(), exception);
            } 
          }
          
          public CloseableIterator<T> iterator() {
            return closeableIterator();
          }
        });
  }
  
  public int hashCode() {
    return super.hashCode();
  }
  
  public boolean isEager() {
    return false;
  }
  
  public boolean isEmpty() {
    CloseableIterator<T> closeableIterator = iterator();
    try {
      boolean bool = closeableIterator.hasNext();
      if (!bool) {
        bool = true;
      } else {
        bool = false;
      } 
    } finally {
      try {
        closeableIterator.close();
      } catch (SQLException sQLException) {}
    } 
  }
  
  public CloseableIterator<T> iterator() {
    return closeableIterator();
  }
  
  public CloseableIterator<T> iteratorThrow() throws SQLException {
    this.lastIterator = seperateIteratorThrow();
    return this.lastIterator;
  }
  
  public int refreshAll() {
    throw new UnsupportedOperationException("Cannot call updateAll() on a lazy collection.");
  }
  
  public int refreshCollection() {
    return 0;
  }
  
  public boolean remove(Object paramObject) {
    CloseableIterator<T> closeableIterator = iterator();
    try {
      while (closeableIterator.hasNext()) {
        if (closeableIterator.next().equals(paramObject)) {
          closeableIterator.remove();
          return true;
        } 
      } 
      return false;
    } finally {
      try {
        closeableIterator.close();
      } catch (SQLException sQLException) {}
    } 
  }
  
  public boolean removeAll(Collection<?> paramCollection) {
    boolean bool = false;
    CloseableIterator<T> closeableIterator = iterator();
    try {
      while (closeableIterator.hasNext()) {
        if (paramCollection.contains(closeableIterator.next())) {
          closeableIterator.remove();
          bool = true;
        } 
      } 
    } finally {
      try {
        closeableIterator.close();
      } catch (SQLException sQLException) {}
    } 
  }
  
  public CloseableIterator<T> seperateIteratorThrow() throws SQLException {
    if (this.dao == null)
      throw new IllegalStateException("Internal DAO object is null.  Lazy collections cannot be used if they have been deserialized."); 
    return this.dao.iterator(getPreparedQuery());
  }
  
  public int size() {
    CloseableIterator<T> closeableIterator = iterator();
    byte b = 0;
    try {
      while (closeableIterator.hasNext()) {
        closeableIterator.moveToNext();
        b++;
      } 
    } finally {
      try {
        closeableIterator.close();
      } catch (SQLException sQLException) {}
    } 
  }
  
  public Object[] toArray() {
    Object[] arrayOfObject;
    null = new ArrayList();
    CloseableIterator<T> closeableIterator = iterator();
    try {
      while (closeableIterator.hasNext())
        null.add(closeableIterator.next()); 
    } finally {
      try {
        closeableIterator.close();
      } catch (SQLException sQLException) {}
    } 
    try {
      sQLException.close();
    } catch (SQLException sQLException1) {}
    return arrayOfObject;
  }
  
  public <E> E[] toArray(E[] paramArrayOfE) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: invokevirtual iterator : ()Lcom/j256/ormlite/dao/CloseableIterator;
    //   6: astore_3
    //   7: aconst_null
    //   8: astore #4
    //   10: aload_3
    //   11: invokeinterface hasNext : ()Z
    //   16: ifeq -> 108
    //   19: aload_3
    //   20: invokeinterface next : ()Ljava/lang/Object;
    //   25: astore #5
    //   27: iload_2
    //   28: aload_1
    //   29: arraylength
    //   30: if_icmplt -> 100
    //   33: aload #4
    //   35: ifnonnull -> 84
    //   38: new java/util/ArrayList
    //   41: astore #6
    //   43: aload #6
    //   45: invokespecial <init> : ()V
    //   48: aload_1
    //   49: arraylength
    //   50: istore #7
    //   52: iconst_0
    //   53: istore #8
    //   55: aload #6
    //   57: astore #4
    //   59: iload #8
    //   61: iload #7
    //   63: if_icmpge -> 84
    //   66: aload #6
    //   68: aload_1
    //   69: iload #8
    //   71: aaload
    //   72: invokeinterface add : (Ljava/lang/Object;)Z
    //   77: pop
    //   78: iinc #8, 1
    //   81: goto -> 55
    //   84: aload #4
    //   86: aload #5
    //   88: invokeinterface add : (Ljava/lang/Object;)Z
    //   93: pop
    //   94: iinc #2, 1
    //   97: goto -> 10
    //   100: aload_1
    //   101: iload_2
    //   102: aload #5
    //   104: aastore
    //   105: goto -> 94
    //   108: aload_3
    //   109: invokeinterface close : ()V
    //   114: aload #4
    //   116: ifnonnull -> 149
    //   119: aload_1
    //   120: astore #4
    //   122: iload_2
    //   123: aload_1
    //   124: arraylength
    //   125: iconst_1
    //   126: isub
    //   127: if_icmpge -> 137
    //   130: aload_1
    //   131: iload_2
    //   132: aconst_null
    //   133: aastore
    //   134: aload_1
    //   135: astore #4
    //   137: aload #4
    //   139: areturn
    //   140: astore_1
    //   141: aload_3
    //   142: invokeinterface close : ()V
    //   147: aload_1
    //   148: athrow
    //   149: aload #4
    //   151: aload_1
    //   152: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
    //   157: astore #4
    //   159: goto -> 137
    //   162: astore #6
    //   164: goto -> 114
    //   167: astore #4
    //   169: goto -> 147
    //   172: astore_1
    //   173: goto -> 141
    // Exception table:
    //   from	to	target	type
    //   10	33	140	finally
    //   38	48	140	finally
    //   48	52	172	finally
    //   66	78	172	finally
    //   84	94	172	finally
    //   108	114	162	java/sql/SQLException
    //   141	147	167	java/sql/SQLException
  }
  
  public int updateAll() {
    throw new UnsupportedOperationException("Cannot call updateAll() on a lazy collection.");
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/dao/LazyForeignCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */