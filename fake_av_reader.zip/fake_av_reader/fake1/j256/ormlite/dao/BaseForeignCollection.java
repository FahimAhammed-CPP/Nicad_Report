package com.j256.ormlite.dao;

import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.stmt.PreparedQuery;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.stmt.SelectArg;
import com.j256.ormlite.stmt.mapped.MappedPreparedStmt;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;

public abstract class BaseForeignCollection<T, ID> implements ForeignCollection<T>, Serializable {
  private static final long serialVersionUID = -5158840898186237589L;
  
  protected final transient Dao<T, ID> dao;
  
  private final transient FieldType foreignFieldType;
  
  private final transient boolean orderAscending;
  
  private final transient String orderColumn;
  
  private final transient Object parent;
  
  private final transient Object parentId;
  
  private transient PreparedQuery<T> preparedQuery;
  
  protected BaseForeignCollection(Dao<T, ID> paramDao, Object paramObject1, Object paramObject2, FieldType paramFieldType, String paramString, boolean paramBoolean) {
    this.dao = paramDao;
    this.foreignFieldType = paramFieldType;
    this.parentId = paramObject2;
    this.orderColumn = paramString;
    this.orderAscending = paramBoolean;
    this.parent = paramObject1;
  }
  
  public boolean add(T paramT) {
    boolean bool = true;
    try {
      if (this.parent != null && this.foreignFieldType.getFieldValueIfNotDefault(paramT) == null)
        this.foreignFieldType.assignField(paramT, this.parent, true, null); 
      if (this.dao == null)
        return false; 
      this.dao.create(paramT);
      return bool;
    } catch (SQLException sQLException) {
      throw new IllegalStateException("Could not create data element in dao", sQLException);
    } 
  }
  
  public boolean addAll(Collection<? extends T> paramCollection) {
    if (this.dao == null)
      return false; 
    boolean bool = false;
    Iterator<? extends T> iterator = paramCollection.iterator();
    while (true) {
      if (iterator.hasNext()) {
        paramCollection = (Collection<? extends T>)iterator.next();
        try {
          this.dao.create((T)paramCollection);
          bool = true;
        } catch (SQLException sQLException) {
          throw new IllegalStateException("Could not create data elements in dao", sQLException);
        } 
        continue;
      } 
      return bool;
    } 
  }
  
  public void clear() {
    if (this.dao != null) {
      CloseableIterator<T> closeableIterator = closeableIterator();
      try {
        while (closeableIterator.hasNext()) {
          closeableIterator.next();
          closeableIterator.remove();
        } 
      } finally {
        try {
          closeableIterator.close();
        } catch (SQLException sQLException) {}
      } 
    } 
  }
  
  protected PreparedQuery<T> getPreparedQuery() throws SQLException {
    if (this.dao == null)
      return null; 
    if (this.preparedQuery == null) {
      SelectArg selectArg = new SelectArg();
      selectArg.setValue(this.parentId);
      QueryBuilder<T, ID> queryBuilder = this.dao.queryBuilder();
      if (this.orderColumn != null)
        queryBuilder.orderBy(this.orderColumn, this.orderAscending); 
      this.preparedQuery = queryBuilder.where().eq(this.foreignFieldType.getColumnName(), selectArg).prepare();
      if (this.preparedQuery instanceof MappedPreparedStmt)
        ((MappedPreparedStmt)this.preparedQuery).setParentInformation(this.parent, this.parentId); 
    } 
    return this.preparedQuery;
  }
  
  public int refresh(T paramT) throws SQLException {
    return (this.dao == null) ? 0 : this.dao.refresh(paramT);
  }
  
  public abstract boolean remove(Object paramObject);
  
  public abstract boolean removeAll(Collection<?> paramCollection);
  
  public boolean retainAll(Collection<?> paramCollection) {
    if (this.dao == null)
      return false; 
    boolean bool = false;
    CloseableIterator<T> closeableIterator = closeableIterator();
    try {
      while (closeableIterator.hasNext()) {
        if (!paramCollection.contains(closeableIterator.next())) {
          closeableIterator.remove();
          bool = true;
        } 
      } 
      try {
        closeableIterator.close();
      } catch (SQLException sQLException) {}
    } finally {}
    return bool;
  }
  
  public int update(T paramT) throws SQLException {
    return (this.dao == null) ? 0 : this.dao.update(paramT);
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/dao/BaseForeignCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */