package com.j256.ormlite.dao;

import java.sql.SQLException;
import java.util.Collection;

public interface ForeignCollection<T> extends Collection<T>, CloseableIterable<T> {
  boolean add(T paramT);
  
  void closeLastIterator() throws SQLException;
  
  CloseableWrappedIterable<T> getWrappedIterable();
  
  boolean isEager();
  
  CloseableIterator<T> iteratorThrow() throws SQLException;
  
  int refresh(T paramT) throws SQLException;
  
  int refreshAll() throws SQLException;
  
  int refreshCollection() throws SQLException;
  
  int update(T paramT) throws SQLException;
  
  int updateAll() throws SQLException;
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/dao/ForeignCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */