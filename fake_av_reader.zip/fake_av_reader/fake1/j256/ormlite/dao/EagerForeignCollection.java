package com.j256.ormlite.dao;

import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.support.DatabaseResults;
import java.io.Serializable;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class EagerForeignCollection<T, ID> extends BaseForeignCollection<T, ID> implements ForeignCollection<T>, CloseableWrappedIterable<T>, Serializable {
  private static final long serialVersionUID = -2523335606983317721L;
  
  private List<T> results;
  
  public EagerForeignCollection(Dao<T, ID> paramDao, Object paramObject1, Object paramObject2, FieldType paramFieldType, String paramString, boolean paramBoolean) throws SQLException {
    super(paramDao, paramObject1, paramObject2, paramFieldType, paramString, paramBoolean);
    if (paramObject2 == null) {
      this.results = new ArrayList<T>();
      return;
    } 
    this.results = paramDao.query(getPreparedQuery());
  }
  
  public boolean add(T paramT) {
    return this.results.add(paramT) ? super.add(paramT) : false;
  }
  
  public boolean addAll(Collection<? extends T> paramCollection) {
    return this.results.addAll(paramCollection) ? super.addAll(paramCollection) : false;
  }
  
  public void close() {}
  
  public void closeLastIterator() {}
  
  public CloseableIterator<T> closeableIterator() {
    return iteratorThrow();
  }
  
  public boolean contains(Object paramObject) {
    return this.results.contains(paramObject);
  }
  
  public boolean containsAll(Collection<?> paramCollection) {
    return this.results.containsAll(paramCollection);
  }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof EagerForeignCollection))
      return false; 
    paramObject = paramObject;
    return this.results.equals(((EagerForeignCollection)paramObject).results);
  }
  
  public CloseableWrappedIterable<T> getWrappedIterable() {
    return this;
  }
  
  public int hashCode() {
    return this.results.hashCode();
  }
  
  public boolean isEager() {
    return true;
  }
  
  public boolean isEmpty() {
    return this.results.isEmpty();
  }
  
  public CloseableIterator<T> iterator() {
    return iteratorThrow();
  }
  
  public CloseableIterator<T> iteratorThrow() {
    return new CloseableIterator<T>() {
        private int offset = -1;
        
        public void close() {}
        
        public void closeQuietly() {}
        
        public T current() {
          if (this.offset < 0)
            this.offset = 0; 
          return (T)((this.offset >= EagerForeignCollection.this.results.size()) ? null : EagerForeignCollection.this.results.get(this.offset));
        }
        
        public T first() {
          this.offset = 0;
          return (T)((this.offset >= EagerForeignCollection.this.results.size()) ? null : EagerForeignCollection.this.results.get(0));
        }
        
        public DatabaseResults getRawResults() {
          return null;
        }
        
        public boolean hasNext() {
          return (this.offset + 1 < EagerForeignCollection.this.results.size());
        }
        
        public T moveRelative(int param1Int) {
          this.offset += param1Int;
          return (T)((this.offset < 0 || this.offset >= EagerForeignCollection.this.results.size()) ? null : EagerForeignCollection.this.results.get(this.offset));
        }
        
        public void moveToNext() {
          this.offset++;
        }
        
        public T next() {
          this.offset++;
          return (T)EagerForeignCollection.this.results.get(this.offset);
        }
        
        public T nextThrow() {
          this.offset++;
          return (T)((this.offset >= EagerForeignCollection.this.results.size()) ? null : EagerForeignCollection.this.results.get(this.offset));
        }
        
        public T previous() {
          this.offset--;
          return (T)((this.offset < 0 || this.offset >= EagerForeignCollection.this.results.size()) ? null : EagerForeignCollection.this.results.get(this.offset));
        }
        
        public void remove() {
          if (this.offset < 0)
            throw new IllegalStateException("next() must be called before remove()"); 
          if (this.offset >= EagerForeignCollection.this.results.size())
            throw new IllegalStateException("current results position (" + this.offset + ") is out of bounds"); 
          Object object = EagerForeignCollection.this.results.remove(this.offset);
          this.offset--;
          if (EagerForeignCollection.this.dao != null)
            try {
              EagerForeignCollection.this.dao.delete(object);
              return;
            } catch (SQLException sQLException) {
              throw new RuntimeException(sQLException);
            }  
        }
      };
  }
  
  public int refreshAll() throws SQLException {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: getfield results : Ljava/util/List;
    //   6: invokeinterface iterator : ()Ljava/util/Iterator;
    //   11: astore_2
    //   12: aload_2
    //   13: invokeinterface hasNext : ()Z
    //   18: ifeq -> 44
    //   21: aload_2
    //   22: invokeinterface next : ()Ljava/lang/Object;
    //   27: astore_3
    //   28: iload_1
    //   29: aload_0
    //   30: getfield dao : Lcom/j256/ormlite/dao/Dao;
    //   33: aload_3
    //   34: invokeinterface refresh : (Ljava/lang/Object;)I
    //   39: iadd
    //   40: istore_1
    //   41: goto -> 12
    //   44: iload_1
    //   45: ireturn
  }
  
  public int refreshCollection() throws SQLException {
    this.results = this.dao.query(getPreparedQuery());
    return this.results.size();
  }
  
  public boolean remove(Object paramObject) {
    boolean bool = true;
    if (!this.results.remove(paramObject) || this.dao == null)
      return false; 
    try {
      int i = this.dao.delete((T)paramObject);
      if (i != 1)
        bool = false; 
      return bool;
    } catch (SQLException sQLException) {
      throw new IllegalStateException("Could not delete data element from dao", sQLException);
    } 
  }
  
  public boolean removeAll(Collection<?> paramCollection) {
    boolean bool = false;
    Iterator<?> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      if (remove(iterator.next()))
        bool = true; 
    } 
    return bool;
  }
  
  public boolean retainAll(Collection<?> paramCollection) {
    return super.retainAll(paramCollection);
  }
  
  public int size() {
    return this.results.size();
  }
  
  public Object[] toArray() {
    return this.results.toArray();
  }
  
  public <E> E[] toArray(E[] paramArrayOfE) {
    return this.results.toArray(paramArrayOfE);
  }
  
  public int updateAll() throws SQLException {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: getfield results : Ljava/util/List;
    //   6: invokeinterface iterator : ()Ljava/util/Iterator;
    //   11: astore_2
    //   12: aload_2
    //   13: invokeinterface hasNext : ()Z
    //   18: ifeq -> 44
    //   21: aload_2
    //   22: invokeinterface next : ()Ljava/lang/Object;
    //   27: astore_3
    //   28: iload_1
    //   29: aload_0
    //   30: getfield dao : Lcom/j256/ormlite/dao/Dao;
    //   33: aload_3
    //   34: invokeinterface update : (Ljava/lang/Object;)I
    //   39: iadd
    //   40: istore_1
    //   41: goto -> 12
    //   44: iload_1
    //   45: ireturn
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/dao/EagerForeignCollection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */