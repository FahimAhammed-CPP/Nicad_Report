package com.j256.ormlite.dao;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class LruObjectCache implements ObjectCache {
  private final int capacity;
  
  private final ConcurrentHashMap<Class<?>, Map<Object, Object>> classMaps = new ConcurrentHashMap<Class<?>, Map<Object, Object>>();
  
  public LruObjectCache(int paramInt) {
    this.capacity = paramInt;
  }
  
  private Map<Object, Object> getMapForClass(Class<?> paramClass) {
    Map<Object, Object> map2 = this.classMaps.get(paramClass);
    Map<Object, Object> map1 = map2;
    if (map2 == null)
      map1 = null; 
    return map1;
  }
  
  public <T> void clear(Class<T> paramClass) {
    Map<Object, Object> map = getMapForClass(paramClass);
    if (map != null)
      map.clear(); 
  }
  
  public void clearAll() {
    Iterator<Map> iterator = this.classMaps.values().iterator();
    while (iterator.hasNext())
      ((Map)iterator.next()).clear(); 
  }
  
  public <T, ID> T get(Class<T> paramClass, ID paramID) {
    null = getMapForClass(paramClass);
    return (T)((null == null) ? null : null.get(paramID));
  }
  
  public <T, ID> void put(Class<T> paramClass, ID paramID, T paramT) {
    Map<Object, Object> map = getMapForClass(paramClass);
    if (map != null)
      map.put(paramID, paramT); 
  }
  
  public <T> void registerClass(Class<T> paramClass) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield classMaps : Ljava/util/concurrent/ConcurrentHashMap;
    //   6: aload_1
    //   7: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   10: checkcast java/util/Map
    //   13: ifnonnull -> 43
    //   16: new com/j256/ormlite/dao/LruObjectCache$LimitedLinkedHashMap
    //   19: astore_2
    //   20: aload_2
    //   21: aload_0
    //   22: getfield capacity : I
    //   25: invokespecial <init> : (I)V
    //   28: aload_2
    //   29: invokestatic synchronizedMap : (Ljava/util/Map;)Ljava/util/Map;
    //   32: astore_2
    //   33: aload_0
    //   34: getfield classMaps : Ljava/util/concurrent/ConcurrentHashMap;
    //   37: aload_1
    //   38: aload_2
    //   39: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   42: pop
    //   43: aload_0
    //   44: monitorexit
    //   45: return
    //   46: astore_1
    //   47: aload_0
    //   48: monitorexit
    //   49: aload_1
    //   50: athrow
    // Exception table:
    //   from	to	target	type
    //   2	43	46	finally
  }
  
  public <T, ID> void remove(Class<T> paramClass, ID paramID) {
    Map<Object, Object> map = getMapForClass(paramClass);
    if (map != null)
      map.remove(paramID); 
  }
  
  public <T> int size(Class<T> paramClass) {
    Map<Object, Object> map = getMapForClass(paramClass);
    return (map == null) ? 0 : map.size();
  }
  
  public int sizeAll() {
    int i = 0;
    Iterator<Map> iterator = this.classMaps.values().iterator();
    while (iterator.hasNext())
      i += ((Map)iterator.next()).size(); 
    return i;
  }
  
  public <T, ID> T updateId(Class<T> paramClass, ID paramID1, ID paramID2) {
    ID iD;
    Class<T> clazz = null;
    Map<Object, Object> map = getMapForClass(paramClass);
    if (map == null)
      return (T)clazz; 
    paramID1 = (ID)map.remove(paramID1);
    paramClass = clazz;
    if (paramID1 != null) {
      map.put(paramID2, paramID1);
      iD = paramID1;
    } 
    return (T)iD;
  }
  
  private static class LimitedLinkedHashMap<K, V> extends LinkedHashMap<K, V> {
    private static final long serialVersionUID = -4566528080395573236L;
    
    private final int capacity;
    
    public LimitedLinkedHashMap(int param1Int) {
      super(param1Int, 0.75F, true);
      this.capacity = param1Int;
    }
    
    protected boolean removeEldestEntry(Map.Entry<K, V> param1Entry) {
      return (size() > this.capacity);
    }
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/dao/LruObjectCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */