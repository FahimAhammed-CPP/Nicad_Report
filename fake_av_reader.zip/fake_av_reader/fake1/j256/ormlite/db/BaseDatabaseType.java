package com.j256.ormlite.db;

import com.j256.ormlite.field.BaseFieldConverter;
import com.j256.ormlite.field.DataPersister;
import com.j256.ormlite.field.FieldConverter;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.field.SqlType;
import com.j256.ormlite.misc.SqlExceptionUtil;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.support.DatabaseResults;
import com.j256.ormlite.table.DatabaseTableConfig;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.List;

public abstract class BaseDatabaseType implements DatabaseType {
  protected static String DEFAULT_SEQUENCE_SUFFIX = "_id_seq";
  
  protected Driver driver;
  
  private void addSingleUnique(StringBuilder paramStringBuilder, FieldType paramFieldType, List<String> paramList1, List<String> paramList2) {
    paramStringBuilder = new StringBuilder();
    paramStringBuilder.append(" UNIQUE (");
    appendEscapedEntityName(paramStringBuilder, paramFieldType.getColumnName());
    paramStringBuilder.append(")");
    paramList1.add(paramStringBuilder.toString());
  }
  
  private void appendCanBeNull(StringBuilder paramStringBuilder, FieldType paramFieldType) {}
  
  private void appendDefaultValue(StringBuilder paramStringBuilder, FieldType paramFieldType, Object paramObject) {
    if (paramFieldType.isEscapedDefaultValue()) {
      appendEscapedWord(paramStringBuilder, paramObject.toString());
      return;
    } 
    paramStringBuilder.append(paramObject);
  }
  
  private void appendDoubleType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("DOUBLE PRECISION");
  }
  
  private void appendFloatType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("FLOAT");
  }
  
  private void appendIntegerType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("INTEGER");
  }
  
  public void addPrimaryKeySql(FieldType[] paramArrayOfFieldType, List<String> paramList1, List<String> paramList2, List<String> paramList3, List<String> paramList4) {
    StringBuilder stringBuilder;
    paramList2 = null;
    int i = paramArrayOfFieldType.length;
    byte b = 0;
    while (b < i) {
      StringBuilder stringBuilder1;
      FieldType fieldType = paramArrayOfFieldType[b];
      if (fieldType.isGeneratedId() && !generatedIdSqlAtEnd() && !fieldType.isSelfGeneratedId()) {
        paramList3 = paramList2;
      } else {
        paramList3 = paramList2;
        if (fieldType.isId()) {
          StringBuilder stringBuilder2;
          if (paramList2 == null) {
            stringBuilder2 = new StringBuilder(48);
            stringBuilder2.append("PRIMARY KEY (");
          } else {
            stringBuilder2.append(',');
          } 
          appendEscapedEntityName(stringBuilder2, fieldType.getColumnName());
          stringBuilder1 = stringBuilder2;
        } 
      } 
      b++;
      stringBuilder = stringBuilder1;
    } 
    if (stringBuilder != null) {
      stringBuilder.append(") ");
      paramList1.add(stringBuilder.toString());
    } 
  }
  
  public void addUniqueComboSql(FieldType[] paramArrayOfFieldType, List<String> paramList1, List<String> paramList2, List<String> paramList3, List<String> paramList4) {
    StringBuilder stringBuilder;
    paramList2 = null;
    int i = paramArrayOfFieldType.length;
    byte b = 0;
    while (b < i) {
      StringBuilder stringBuilder1;
      FieldType fieldType = paramArrayOfFieldType[b];
      paramList3 = paramList2;
      if (fieldType.isUniqueCombo()) {
        StringBuilder stringBuilder2;
        if (paramList2 == null) {
          stringBuilder2 = new StringBuilder(48);
          stringBuilder2.append("UNIQUE (");
        } else {
          stringBuilder2.append(',');
        } 
        appendEscapedEntityName(stringBuilder2, fieldType.getColumnName());
        stringBuilder1 = stringBuilder2;
      } 
      b++;
      stringBuilder = stringBuilder1;
    } 
    if (stringBuilder != null) {
      stringBuilder.append(") ");
      paramList1.add(stringBuilder.toString());
    } 
  }
  
  protected void appendBigDecimalNumericType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("NUMERIC");
  }
  
  protected void appendBooleanType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("BOOLEAN");
  }
  
  protected void appendByteArrayType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("BLOB");
  }
  
  protected void appendByteType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("TINYINT");
  }
  
  protected void appendCharType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("CHAR");
  }
  
  public void appendColumnArg(String paramString, StringBuilder paramStringBuilder, FieldType paramFieldType, List<String> paramList1, List<String> paramList2, List<String> paramList3, List<String> paramList4) throws SQLException {
    // Byte code:
    //   0: aload_0
    //   1: aload_2
    //   2: aload_3
    //   3: invokevirtual getColumnName : ()Ljava/lang/String;
    //   6: invokevirtual appendEscapedEntityName : (Ljava/lang/StringBuilder;Ljava/lang/String;)V
    //   9: aload_2
    //   10: bipush #32
    //   12: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload_3
    //   17: invokevirtual getDataPersister : ()Lcom/j256/ormlite/field/DataPersister;
    //   20: astore #8
    //   22: aload_3
    //   23: invokevirtual getWidth : ()I
    //   26: istore #9
    //   28: iload #9
    //   30: istore #10
    //   32: iload #9
    //   34: ifne -> 46
    //   37: aload #8
    //   39: invokeinterface getDefaultWidth : ()I
    //   44: istore #10
    //   46: getstatic com/j256/ormlite/db/BaseDatabaseType$1.$SwitchMap$com$j256$ormlite$field$SqlType : [I
    //   49: aload #8
    //   51: invokeinterface getSqlType : ()Lcom/j256/ormlite/field/SqlType;
    //   56: invokevirtual ordinal : ()I
    //   59: iaload
    //   60: tableswitch default -> 132, 1 -> 165, 2 -> 274, 3 -> 285, 4 -> 296, 5 -> 307, 6 -> 318, 7 -> 329, 8 -> 340, 9 -> 351, 10 -> 362, 11 -> 373, 12 -> 384, 13 -> 395, 14 -> 406
    //   132: new java/lang/IllegalArgumentException
    //   135: dup
    //   136: new java/lang/StringBuilder
    //   139: dup
    //   140: invokespecial <init> : ()V
    //   143: ldc 'Unknown SQL-type '
    //   145: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: aload #8
    //   150: invokeinterface getSqlType : ()Lcom/j256/ormlite/field/SqlType;
    //   155: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   158: invokevirtual toString : ()Ljava/lang/String;
    //   161: invokespecial <init> : (Ljava/lang/String;)V
    //   164: athrow
    //   165: aload_0
    //   166: aload_2
    //   167: aload_3
    //   168: iload #10
    //   170: invokevirtual appendStringType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   173: aload_2
    //   174: bipush #32
    //   176: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   179: pop
    //   180: aload_3
    //   181: invokevirtual isGeneratedIdSequence : ()Z
    //   184: ifeq -> 417
    //   187: aload_3
    //   188: invokevirtual isSelfGeneratedId : ()Z
    //   191: ifne -> 417
    //   194: aload_0
    //   195: aload_2
    //   196: aload_3
    //   197: aload #5
    //   199: aload #4
    //   201: aload #7
    //   203: invokevirtual configureGeneratedIdSequence : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    //   206: aload_3
    //   207: invokevirtual isGeneratedId : ()Z
    //   210: ifne -> 273
    //   213: aload_3
    //   214: invokevirtual getDefaultValue : ()Ljava/lang/Object;
    //   217: astore_1
    //   218: aload_1
    //   219: ifnull -> 243
    //   222: aload_2
    //   223: ldc 'DEFAULT '
    //   225: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   228: pop
    //   229: aload_0
    //   230: aload_2
    //   231: aload_3
    //   232: aload_1
    //   233: invokespecial appendDefaultValue : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;Ljava/lang/Object;)V
    //   236: aload_2
    //   237: bipush #32
    //   239: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   242: pop
    //   243: aload_3
    //   244: invokevirtual isCanBeNull : ()Z
    //   247: ifeq -> 471
    //   250: aload_0
    //   251: aload_2
    //   252: aload_3
    //   253: invokespecial appendCanBeNull : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;)V
    //   256: aload_3
    //   257: invokevirtual isUnique : ()Z
    //   260: ifeq -> 273
    //   263: aload_0
    //   264: aload_2
    //   265: aload_3
    //   266: aload #4
    //   268: aload #6
    //   270: invokespecial addSingleUnique : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;Ljava/util/List;Ljava/util/List;)V
    //   273: return
    //   274: aload_0
    //   275: aload_2
    //   276: aload_3
    //   277: iload #10
    //   279: invokevirtual appendLongStringType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   282: goto -> 173
    //   285: aload_0
    //   286: aload_2
    //   287: aload_3
    //   288: iload #10
    //   290: invokevirtual appendBooleanType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   293: goto -> 173
    //   296: aload_0
    //   297: aload_2
    //   298: aload_3
    //   299: iload #10
    //   301: invokevirtual appendDateType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   304: goto -> 173
    //   307: aload_0
    //   308: aload_2
    //   309: aload_3
    //   310: iload #10
    //   312: invokevirtual appendCharType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   315: goto -> 173
    //   318: aload_0
    //   319: aload_2
    //   320: aload_3
    //   321: iload #10
    //   323: invokevirtual appendByteType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   326: goto -> 173
    //   329: aload_0
    //   330: aload_2
    //   331: aload_3
    //   332: iload #10
    //   334: invokevirtual appendByteArrayType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   337: goto -> 173
    //   340: aload_0
    //   341: aload_2
    //   342: aload_3
    //   343: iload #10
    //   345: invokevirtual appendShortType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   348: goto -> 173
    //   351: aload_0
    //   352: aload_2
    //   353: aload_3
    //   354: iload #10
    //   356: invokespecial appendIntegerType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   359: goto -> 173
    //   362: aload_0
    //   363: aload_2
    //   364: aload_3
    //   365: iload #10
    //   367: invokevirtual appendLongType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   370: goto -> 173
    //   373: aload_0
    //   374: aload_2
    //   375: aload_3
    //   376: iload #10
    //   378: invokespecial appendFloatType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   381: goto -> 173
    //   384: aload_0
    //   385: aload_2
    //   386: aload_3
    //   387: iload #10
    //   389: invokespecial appendDoubleType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   392: goto -> 173
    //   395: aload_0
    //   396: aload_2
    //   397: aload_3
    //   398: iload #10
    //   400: invokevirtual appendSerializableType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   403: goto -> 173
    //   406: aload_0
    //   407: aload_2
    //   408: aload_3
    //   409: iload #10
    //   411: invokevirtual appendBigDecimalNumericType : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;I)V
    //   414: goto -> 173
    //   417: aload_3
    //   418: invokevirtual isGeneratedId : ()Z
    //   421: ifeq -> 449
    //   424: aload_3
    //   425: invokevirtual isSelfGeneratedId : ()Z
    //   428: ifne -> 449
    //   431: aload_0
    //   432: aload_1
    //   433: aload_2
    //   434: aload_3
    //   435: aload #5
    //   437: aload #6
    //   439: aload #4
    //   441: aload #7
    //   443: invokevirtual configureGeneratedId : (Ljava/lang/String;Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    //   446: goto -> 206
    //   449: aload_3
    //   450: invokevirtual isId : ()Z
    //   453: ifeq -> 206
    //   456: aload_0
    //   457: aload_2
    //   458: aload_3
    //   459: aload #5
    //   461: aload #4
    //   463: aload #7
    //   465: invokevirtual configureId : (Ljava/lang/StringBuilder;Lcom/j256/ormlite/field/FieldType;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    //   468: goto -> 206
    //   471: aload_2
    //   472: ldc 'NOT NULL '
    //   474: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   477: pop
    //   478: goto -> 256
  }
  
  public void appendCreateTableSuffix(StringBuilder paramStringBuilder) {}
  
  protected void appendDateType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("TIMESTAMP");
  }
  
  public void appendEscapedEntityName(StringBuilder paramStringBuilder, String paramString) {
    paramStringBuilder.append('`').append(paramString).append('`');
  }
  
  public void appendEscapedWord(StringBuilder paramStringBuilder, String paramString) {
    paramStringBuilder.append('\'').append(paramString).append('\'');
  }
  
  public void appendLimitValue(StringBuilder paramStringBuilder, long paramLong, Long paramLong1) {
    paramStringBuilder.append("LIMIT ").append(paramLong).append(' ');
  }
  
  protected void appendLongStringType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("TEXT");
  }
  
  protected void appendLongType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("BIGINT");
  }
  
  public void appendOffsetValue(StringBuilder paramStringBuilder, long paramLong) {
    paramStringBuilder.append("OFFSET ").append(paramLong).append(' ');
  }
  
  public void appendSelectNextValFromSequence(StringBuilder paramStringBuilder, String paramString) {}
  
  protected void appendSerializableType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("BLOB");
  }
  
  protected void appendShortType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    paramStringBuilder.append("SMALLINT");
  }
  
  protected void appendStringType(StringBuilder paramStringBuilder, FieldType paramFieldType, int paramInt) {
    if (isVarcharFieldWidthSupported()) {
      paramStringBuilder.append("VARCHAR(").append(paramInt).append(")");
      return;
    } 
    paramStringBuilder.append("VARCHAR");
  }
  
  protected void configureGeneratedId(String paramString, StringBuilder paramStringBuilder, FieldType paramFieldType, List<String> paramList1, List<String> paramList2, List<String> paramList3, List<String> paramList4) {
    throw new IllegalStateException("GeneratedId is not supported by database " + getDatabaseName() + " for field " + paramFieldType);
  }
  
  protected void configureGeneratedIdSequence(StringBuilder paramStringBuilder, FieldType paramFieldType, List<String> paramList1, List<String> paramList2, List<String> paramList3) throws SQLException {
    throw new SQLException("GeneratedIdSequence is not supported by database " + getDatabaseName() + " for field " + paramFieldType);
  }
  
  protected void configureId(StringBuilder paramStringBuilder, FieldType paramFieldType, List<String> paramList1, List<String> paramList2, List<String> paramList3) {}
  
  public void dropColumnArg(FieldType paramFieldType, List<String> paramList1, List<String> paramList2) {}
  
  public <T> DatabaseTableConfig<T> extractDatabaseTableConfig(ConnectionSource paramConnectionSource, Class<T> paramClass) throws SQLException {
    return null;
  }
  
  public String generateIdSequenceName(String paramString, FieldType paramFieldType) {
    String str = paramString + DEFAULT_SEQUENCE_SUFFIX;
    paramString = str;
    if (isEntityNamesMustBeUpCase())
      paramString = str.toUpperCase(); 
    return paramString;
  }
  
  protected boolean generatedIdSqlAtEnd() {
    return true;
  }
  
  public String getCommentLinePrefix() {
    return "-- ";
  }
  
  protected abstract String getDriverClassName();
  
  public FieldConverter getFieldConverter(DataPersister paramDataPersister) {
    return (FieldConverter)paramDataPersister;
  }
  
  public String getPingStatement() {
    return "SELECT 1";
  }
  
  public boolean isAllowGeneratedIdInsertSupported() {
    return true;
  }
  
  public boolean isBatchUseTransaction() {
    return false;
  }
  
  public boolean isCreateIfNotExistsSupported() {
    return false;
  }
  
  public boolean isCreateIndexIfNotExistsSupported() {
    return isCreateIfNotExistsSupported();
  }
  
  public boolean isCreateTableReturnsNegative() {
    return false;
  }
  
  public boolean isCreateTableReturnsZero() {
    return true;
  }
  
  public boolean isEntityNamesMustBeUpCase() {
    return false;
  }
  
  public boolean isIdSequenceNeeded() {
    return false;
  }
  
  public boolean isLimitAfterSelect() {
    return false;
  }
  
  public boolean isLimitSqlSupported() {
    return true;
  }
  
  public boolean isNestedSavePointsSupported() {
    return true;
  }
  
  public boolean isOffsetLimitArgument() {
    return false;
  }
  
  public boolean isOffsetSqlSupported() {
    return true;
  }
  
  public boolean isSelectSequenceBeforeInsert() {
    return false;
  }
  
  public boolean isTruncateSupported() {
    return false;
  }
  
  public boolean isVarcharFieldWidthSupported() {
    return true;
  }
  
  public void loadDriver() throws SQLException {
    String str = getDriverClassName();
    if (str != null)
      try {
        Class.forName(str);
        return;
      } catch (ClassNotFoundException classNotFoundException) {
        throw SqlExceptionUtil.create("Driver class was not found for " + getDatabaseName() + " database.  Missing jar with class " + str + ".", classNotFoundException);
      }  
  }
  
  public void setDriver(Driver paramDriver) {
    this.driver = paramDriver;
  }
  
  protected static class BooleanNumberFieldConverter extends BaseFieldConverter {
    public SqlType getSqlType() {
      return SqlType.BOOLEAN;
    }
    
    public Object javaToSqlArg(FieldType param1FieldType, Object param1Object) {
      return ((Boolean)param1Object).booleanValue() ? Byte.valueOf((byte)1) : Byte.valueOf((byte)0);
    }
    
    public Object parseDefaultString(FieldType param1FieldType, String param1String) {
      return Boolean.parseBoolean(param1String) ? Byte.valueOf((byte)1) : Byte.valueOf((byte)0);
    }
    
    public Object resultStringToJava(FieldType param1FieldType, String param1String, int param1Int) {
      return sqlArgToJava(param1FieldType, Byte.valueOf(Byte.parseByte(param1String)), param1Int);
    }
    
    public Object resultToSqlArg(FieldType param1FieldType, DatabaseResults param1DatabaseResults, int param1Int) throws SQLException {
      return Byte.valueOf(param1DatabaseResults.getByte(param1Int));
    }
    
    public Object sqlArgToJava(FieldType param1FieldType, Object param1Object, int param1Int) {
      return (((Byte)param1Object).byteValue() == 1) ? Boolean.valueOf(true) : Boolean.valueOf(false);
    }
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/db/BaseDatabaseType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */