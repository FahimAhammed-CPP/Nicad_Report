package com.j256.ormlite.logger;

public class LoggerFactory {
  public static final String LOG_TYPE_SYSTEM_PROPERTY = "com.j256.ormlite.logger.type";
  
  private static LogType logType;
  
  private static LogType findLogType() {
    // Byte code:
    //   0: ldc 'com.j256.ormlite.logger.type'
    //   2: invokestatic getProperty : (Ljava/lang/String;)Ljava/lang/String;
    //   5: astore_0
    //   6: aload_0
    //   7: ifnull -> 62
    //   10: aload_0
    //   11: invokestatic valueOf : (Ljava/lang/String;)Lcom/j256/ormlite/logger/LoggerFactory$LogType;
    //   14: astore_1
    //   15: aload_1
    //   16: areturn
    //   17: astore_1
    //   18: new com/j256/ormlite/logger/LocalLog
    //   21: dup
    //   22: ldc com/j256/ormlite/logger/LoggerFactory
    //   24: invokevirtual getName : ()Ljava/lang/String;
    //   27: invokespecial <init> : (Ljava/lang/String;)V
    //   30: getstatic com/j256/ormlite/logger/Log$Level.WARNING : Lcom/j256/ormlite/logger/Log$Level;
    //   33: new java/lang/StringBuilder
    //   36: dup
    //   37: invokespecial <init> : ()V
    //   40: ldc 'Could not find valid log-type from system property 'com.j256.ormlite.logger.type', value ''
    //   42: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: aload_0
    //   46: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   49: ldc '''
    //   51: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   54: invokevirtual toString : ()Ljava/lang/String;
    //   57: invokeinterface log : (Lcom/j256/ormlite/logger/Log$Level;Ljava/lang/String;)V
    //   62: invokestatic values : ()[Lcom/j256/ormlite/logger/LoggerFactory$LogType;
    //   65: astore_2
    //   66: aload_2
    //   67: arraylength
    //   68: istore_3
    //   69: iconst_0
    //   70: istore #4
    //   72: iload #4
    //   74: iload_3
    //   75: if_icmpge -> 98
    //   78: aload_2
    //   79: iload #4
    //   81: aaload
    //   82: astore_0
    //   83: aload_0
    //   84: astore_1
    //   85: aload_0
    //   86: invokevirtual isAvailable : ()Z
    //   89: ifne -> 15
    //   92: iinc #4, 1
    //   95: goto -> 72
    //   98: getstatic com/j256/ormlite/logger/LoggerFactory$LogType.LOCAL : Lcom/j256/ormlite/logger/LoggerFactory$LogType;
    //   101: astore_1
    //   102: goto -> 15
    // Exception table:
    //   from	to	target	type
    //   10	15	17	java/lang/IllegalArgumentException
  }
  
  public static Logger getLogger(Class<?> paramClass) {
    return getLogger(paramClass.getName());
  }
  
  public static Logger getLogger(String paramString) {
    if (logType == null)
      logType = findLogType(); 
    return new Logger(logType.createLog(paramString));
  }
  
  public static String getSimpleClassName(String paramString) {
    String[] arrayOfString = paramString.split("\\.");
    if (arrayOfString.length > 1)
      paramString = arrayOfString[arrayOfString.length - 1]; 
    return paramString;
  }
  
  public enum LogType {
    ANDROID("android.util.Log", "com.j256.ormlite.android.AndroidLog"),
    COMMONS_LOGGING("android.util.Log", "com.j256.ormlite.android.AndroidLog"),
    LOCAL("android.util.Log", "com.j256.ormlite.android.AndroidLog"),
    LOG4J("android.util.Log", "com.j256.ormlite.android.AndroidLog"),
    LOG4J2("android.util.Log", "com.j256.ormlite.android.AndroidLog"),
    SLF4J("org.slf4j.LoggerFactory", "com.j256.ormlite.logger.Slf4jLoggingLog");
    
    private final String detectClassName;
    
    private final String logClassName;
    
    static {
      LOG4J = new LogType("LOG4J", 4, "org.apache.log4j.Logger", "com.j256.ormlite.logger.Log4jLog");
      LOCAL = new null("LOCAL", 5, LocalLog.class.getName(), LocalLog.class.getName());
      $VALUES = new LogType[] { ANDROID, SLF4J, COMMONS_LOGGING, LOG4J2, LOG4J, LOCAL };
    }
    
    LogType(String param1String1, String param1String2) {
      this.detectClassName = param1String1;
      this.logClassName = param1String2;
    }
    
    public Log createLog(String param1String) {
      Log log;
      try {
        Log log1 = createLogFromClassName(param1String);
        log = log1;
      } catch (Exception exception) {
        log = new LocalLog((String)log);
        log.log(Log.Level.WARNING, "Unable to call constructor with single String argument for class " + this.logClassName + ", so had to use local log: " + exception.getMessage());
      } 
      return log;
    }
    
    Log createLogFromClassName(String param1String) throws Exception {
      return Class.forName(this.logClassName).getConstructor(new Class[] { String.class }).newInstance(new Object[] { param1String });
    }
    
    public boolean isAvailable() {
      boolean bool = false;
      if (isAvailableTestClass())
        try {
          createLogFromClassName(getClass().getName()).isLevelEnabled(Log.Level.INFO);
          bool = true;
        } catch (Exception exception) {} 
      return bool;
    }
    
    boolean isAvailableTestClass() {
      boolean bool;
      try {
        Class.forName(this.detectClassName);
        bool = true;
      } catch (Exception exception) {
        bool = false;
      } 
      return bool;
    }
  }
  
  enum null {
    public Log createLog(String param1String) {
      return new LocalLog(param1String);
    }
    
    public boolean isAvailable() {
      return true;
    }
  }
}


/* Location:              /home/fahim/Desktop/fake_av_reader-dex2jar.jar!/com/j256/ormlite/logger/LoggerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */