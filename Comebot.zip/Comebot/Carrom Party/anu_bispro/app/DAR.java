package anu_bispro.app;

import android.app.admin.DeviceAdminReceiver;

public class DAR extends DeviceAdminReceiver {}


/* Location:              /home/fahim/Desktop/Comebot2-dex2jar.jar!/anu_bispro/app/DAR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */