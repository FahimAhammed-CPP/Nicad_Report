package org.andengine.opengl.shader.source;

import org.andengine.opengl.shader.exception.ShaderProgramException;
import org.andengine.opengl.util.GLState;
import org.andengine.opengl.util.criteria.IGLCriteria;

public class CriteriaShaderSource implements IShaderSource {
  private final CriteriaShaderSourceEntry[] mCriteriaShaderSourceEntries;
  
  public CriteriaShaderSource(CriteriaShaderSourceEntry... paramVarArgs) {
    this.mCriteriaShaderSourceEntries = paramVarArgs;
  }
  
  public String getShaderSource(GLState paramGLState) {
    for (byte b = 0;; b++) {
      if (b >= this.mCriteriaShaderSourceEntries.length)
        throw new ShaderProgramException("No " + CriteriaShaderSourceEntry.class.getSimpleName() + " met!"); 
      CriteriaShaderSourceEntry criteriaShaderSourceEntry = this.mCriteriaShaderSourceEntries[b];
      if (criteriaShaderSourceEntry.isMet(paramGLState))
        return criteriaShaderSourceEntry.getShaderSource(); 
    } 
  }
  
  public static class CriteriaShaderSourceEntry {
    private final IGLCriteria[] mGLCriterias;
    
    private final String mShaderSource;
    
    public CriteriaShaderSourceEntry(String param1String) {
      this(param1String, null);
    }
    
    public CriteriaShaderSourceEntry(String param1String, IGLCriteria... param1VarArgs) {
      this.mGLCriterias = param1VarArgs;
      this.mShaderSource = param1String;
    }
    
    public String getShaderSource() {
      return this.mShaderSource;
    }
    
    public boolean isMet(GLState param1GLState) {
      boolean bool = false;
      if (this.mGLCriterias != null) {
        IGLCriteria[] arrayOfIGLCriteria = this.mGLCriterias;
        int i = arrayOfIGLCriteria.length;
        byte b = 0;
        while (true) {
          if (b >= i)
            return true; 
          boolean bool1 = bool;
          if (arrayOfIGLCriteria[b].isMet(param1GLState)) {
            b++;
            continue;
          } 
          return bool1;
        } 
      } 
      return true;
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/shader/source/CriteriaShaderSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */