package org.andengine.opengl.shader.source;

import org.andengine.opengl.util.GLState;

public interface IShaderSource {
  String getShaderSource(GLState paramGLState);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/shader/source/IShaderSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */