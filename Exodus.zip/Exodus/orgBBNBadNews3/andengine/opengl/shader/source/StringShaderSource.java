package org.andengine.opengl.shader.source;

import org.andengine.opengl.util.GLState;

public class StringShaderSource implements IShaderSource {
  private final String mShaderSource;
  
  public StringShaderSource(String paramString) {
    this.mShaderSource = paramString;
  }
  
  public String getShaderSource(GLState paramGLState) {
    return this.mShaderSource;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/shader/source/StringShaderSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */