package org.andengine.opengl.shader;

import android.opengl.GLES20;
import org.andengine.opengl.shader.exception.ShaderProgramLinkException;
import org.andengine.opengl.util.GLState;
import org.andengine.opengl.vbo.attribute.VertexBufferObjectAttributes;

public class PositionTextureCoordinatesShaderProgram extends ShaderProgram {
  public static final String FRAGMENTSHADER = "precision lowp float;\nuniform sampler2D u_texture_0;\nvarying mediump vec2 v_textureCoordinates;\nvoid main() {\n\tgl_FragColor = texture2D(u_texture_0, v_textureCoordinates);\n}";
  
  private static PositionTextureCoordinatesShaderProgram INSTANCE;
  
  public static final String VERTEXSHADER = "uniform mat4 u_modelViewProjectionMatrix;\nattribute vec4 a_position;\nattribute vec2 a_textureCoordinates;\nvarying vec2 v_textureCoordinates;\nvoid main() {\n\tv_textureCoordinates = a_textureCoordinates;\n\tgl_Position = u_modelViewProjectionMatrix * a_position;\n}";
  
  public static int sUniformModelViewPositionMatrixLocation = -1;
  
  public static int sUniformTexture0Location = -1;
  
  private PositionTextureCoordinatesShaderProgram() {
    super("uniform mat4 u_modelViewProjectionMatrix;\nattribute vec4 a_position;\nattribute vec2 a_textureCoordinates;\nvarying vec2 v_textureCoordinates;\nvoid main() {\n\tv_textureCoordinates = a_textureCoordinates;\n\tgl_Position = u_modelViewProjectionMatrix * a_position;\n}", "precision lowp float;\nuniform sampler2D u_texture_0;\nvarying mediump vec2 v_textureCoordinates;\nvoid main() {\n\tgl_FragColor = texture2D(u_texture_0, v_textureCoordinates);\n}");
  }
  
  public static PositionTextureCoordinatesShaderProgram getInstance() {
    if (INSTANCE == null)
      INSTANCE = new PositionTextureCoordinatesShaderProgram(); 
    return INSTANCE;
  }
  
  public void bind(GLState paramGLState, VertexBufferObjectAttributes paramVertexBufferObjectAttributes) {
    GLES20.glDisableVertexAttribArray(1);
    super.bind(paramGLState, paramVertexBufferObjectAttributes);
    GLES20.glUniformMatrix4fv(sUniformModelViewPositionMatrixLocation, 1, false, paramGLState.getModelViewProjectionGLMatrix(), 0);
    GLES20.glUniform1i(sUniformTexture0Location, 0);
  }
  
  protected void link(GLState paramGLState) throws ShaderProgramLinkException {
    GLES20.glBindAttribLocation(this.mProgramID, 0, "a_position");
    GLES20.glBindAttribLocation(this.mProgramID, 3, "a_textureCoordinates");
    super.link(paramGLState);
    sUniformModelViewPositionMatrixLocation = getUniformLocation("u_modelViewProjectionMatrix");
    sUniformTexture0Location = getUniformLocation("u_texture_0");
  }
  
  public void unbind(GLState paramGLState) {
    GLES20.glEnableVertexAttribArray(1);
    super.unbind(paramGLState);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/shader/PositionTextureCoordinatesShaderProgram.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */