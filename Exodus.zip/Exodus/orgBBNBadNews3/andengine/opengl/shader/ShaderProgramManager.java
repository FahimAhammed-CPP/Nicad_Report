package org.andengine.opengl.shader;

import java.util.ArrayList;

public class ShaderProgramManager {
  private final ArrayList<ShaderProgram> mShaderProgramsManaged = new ArrayList<ShaderProgram>();
  
  public void loadShaderProgram(ShaderProgram paramShaderProgram) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 23
    //   6: new java/lang/IllegalArgumentException
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'pShaderProgram must not be null!'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: aload_1
    //   17: athrow
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    //   23: aload_1
    //   24: invokevirtual isCompiled : ()Z
    //   27: ifeq -> 95
    //   30: new java/lang/StringBuilder
    //   33: astore_2
    //   34: aload_2
    //   35: ldc 'Loading an already compiled '
    //   37: invokespecial <init> : (Ljava/lang/String;)V
    //   40: aload_2
    //   41: ldc org/andengine/opengl/shader/ShaderProgram
    //   43: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   46: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   49: ldc ': ''
    //   51: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   54: aload_1
    //   55: invokevirtual getClass : ()Ljava/lang/Class;
    //   58: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   61: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: ldc ''. ''
    //   66: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   69: aload_1
    //   70: invokevirtual getClass : ()Ljava/lang/Class;
    //   73: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   76: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   79: ldc '' will be recompiled.'
    //   81: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: invokevirtual toString : ()Ljava/lang/String;
    //   87: invokestatic w : (Ljava/lang/String;)V
    //   90: aload_1
    //   91: iconst_0
    //   92: invokevirtual setCompiled : (Z)V
    //   95: aload_0
    //   96: getfield mShaderProgramsManaged : Ljava/util/ArrayList;
    //   99: aload_1
    //   100: invokevirtual contains : (Ljava/lang/Object;)Z
    //   103: ifeq -> 154
    //   106: new java/lang/StringBuilder
    //   109: astore_2
    //   110: aload_2
    //   111: ldc 'Loading an already loaded '
    //   113: invokespecial <init> : (Ljava/lang/String;)V
    //   116: aload_2
    //   117: ldc org/andengine/opengl/shader/ShaderProgram
    //   119: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   122: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   125: ldc ': ''
    //   127: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   130: aload_1
    //   131: invokevirtual getClass : ()Ljava/lang/Class;
    //   134: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   137: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   140: ldc ''.'
    //   142: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   145: invokevirtual toString : ()Ljava/lang/String;
    //   148: invokestatic w : (Ljava/lang/String;)V
    //   151: aload_0
    //   152: monitorexit
    //   153: return
    //   154: aload_0
    //   155: getfield mShaderProgramsManaged : Ljava/util/ArrayList;
    //   158: aload_1
    //   159: invokevirtual add : (Ljava/lang/Object;)Z
    //   162: pop
    //   163: goto -> 151
    // Exception table:
    //   from	to	target	type
    //   6	18	18	finally
    //   23	95	18	finally
    //   95	151	18	finally
    //   154	163	18	finally
  }
  
  public void loadShaderPrograms(ShaderProgram... paramVarArgs) {
    for (int i = paramVarArgs.length - 1;; i--) {
      if (i < 0)
        return; 
      loadShaderProgram(paramVarArgs[i]);
    } 
  }
  
  public void onCreate() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokestatic getInstance : ()Lorg/andengine/opengl/shader/PositionColorTextureCoordinatesShaderProgram;
    //   6: invokevirtual loadShaderProgram : (Lorg/andengine/opengl/shader/ShaderProgram;)V
    //   9: aload_0
    //   10: invokestatic getInstance : ()Lorg/andengine/opengl/shader/PositionTextureCoordinatesShaderProgram;
    //   13: invokevirtual loadShaderProgram : (Lorg/andengine/opengl/shader/ShaderProgram;)V
    //   16: aload_0
    //   17: invokestatic getInstance : ()Lorg/andengine/opengl/shader/PositionTextureCoordinatesUniformColorShaderProgram;
    //   20: invokevirtual loadShaderProgram : (Lorg/andengine/opengl/shader/ShaderProgram;)V
    //   23: aload_0
    //   24: invokestatic getInstance : ()Lorg/andengine/opengl/shader/PositionColorShaderProgram;
    //   27: invokevirtual loadShaderProgram : (Lorg/andengine/opengl/shader/ShaderProgram;)V
    //   30: aload_0
    //   31: invokestatic getInstance : ()Lorg/andengine/opengl/shader/PositionTextureCoordinatesTextureSelectShaderProgram;
    //   34: invokevirtual loadShaderProgram : (Lorg/andengine/opengl/shader/ShaderProgram;)V
    //   37: aload_0
    //   38: invokestatic getInstance : ()Lorg/andengine/opengl/shader/PositionTextureCoordinatesPositionInterpolationTextureSelectShaderProgram;
    //   41: invokevirtual loadShaderProgram : (Lorg/andengine/opengl/shader/ShaderProgram;)V
    //   44: aload_0
    //   45: monitorexit
    //   46: return
    //   47: astore_1
    //   48: aload_0
    //   49: monitorexit
    //   50: aload_1
    //   51: athrow
    // Exception table:
    //   from	to	target	type
    //   2	44	47	finally
  }
  
  public void onDestroy() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mShaderProgramsManaged : Ljava/util/ArrayList;
    //   6: astore_1
    //   7: aload_1
    //   8: invokevirtual size : ()I
    //   11: iconst_1
    //   12: isub
    //   13: istore_2
    //   14: iload_2
    //   15: ifge -> 28
    //   18: aload_0
    //   19: getfield mShaderProgramsManaged : Ljava/util/ArrayList;
    //   22: invokevirtual clear : ()V
    //   25: aload_0
    //   26: monitorexit
    //   27: return
    //   28: aload_1
    //   29: iload_2
    //   30: invokevirtual get : (I)Ljava/lang/Object;
    //   33: checkcast org/andengine/opengl/shader/ShaderProgram
    //   36: iconst_0
    //   37: invokevirtual setCompiled : (Z)V
    //   40: iinc #2, -1
    //   43: goto -> 14
    //   46: astore_1
    //   47: aload_0
    //   48: monitorexit
    //   49: aload_1
    //   50: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	46	finally
    //   18	25	46	finally
    //   28	40	46	finally
  }
  
  public void onReload() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mShaderProgramsManaged : Ljava/util/ArrayList;
    //   6: astore_1
    //   7: aload_1
    //   8: invokevirtual size : ()I
    //   11: istore_2
    //   12: iinc #2, -1
    //   15: iload_2
    //   16: ifge -> 22
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: aload_1
    //   23: iload_2
    //   24: invokevirtual get : (I)Ljava/lang/Object;
    //   27: checkcast org/andengine/opengl/shader/ShaderProgram
    //   30: iconst_0
    //   31: invokevirtual setCompiled : (Z)V
    //   34: iinc #2, -1
    //   37: goto -> 15
    //   40: astore_1
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_1
    //   44: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	40	finally
    //   22	34	40	finally
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/shader/ShaderProgramManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */