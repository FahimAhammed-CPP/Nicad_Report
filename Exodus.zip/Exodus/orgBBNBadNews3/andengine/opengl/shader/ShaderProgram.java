package org.andengine.opengl.shader;

import android.opengl.GLES20;
import java.util.HashMap;
import org.andengine.opengl.shader.exception.ShaderProgramCompileException;
import org.andengine.opengl.shader.exception.ShaderProgramException;
import org.andengine.opengl.shader.exception.ShaderProgramLinkException;
import org.andengine.opengl.shader.source.IShaderSource;
import org.andengine.opengl.shader.source.StringShaderSource;
import org.andengine.opengl.util.GLState;
import org.andengine.opengl.vbo.attribute.VertexBufferObjectAttributes;

public class ShaderProgram {
  private static final int[] HARDWAREID_CONTAINER = new int[1];
  
  private static final int[] LENGTH_CONTAINER;
  
  private static final byte[] NAME_CONTAINER;
  
  private static final int NAME_CONTAINER_SIZE = 64;
  
  private static final int[] PARAMETERS_CONTAINER = new int[1];
  
  private static final int[] SIZE_CONTAINER;
  
  private static final int[] TYPE_CONTAINER;
  
  protected final HashMap<String, Integer> mAttributeLocations = new HashMap<String, Integer>();
  
  protected boolean mCompiled;
  
  protected final IShaderSource mFragmentShaderSource;
  
  protected int mProgramID = -1;
  
  protected final HashMap<String, Integer> mUniformLocations = new HashMap<String, Integer>();
  
  protected final IShaderSource mVertexShaderSource;
  
  static {
    LENGTH_CONTAINER = new int[1];
    SIZE_CONTAINER = new int[1];
    TYPE_CONTAINER = new int[1];
    NAME_CONTAINER = new byte[64];
  }
  
  public ShaderProgram(String paramString1, String paramString2) {
    this((IShaderSource)new StringShaderSource(paramString1), (IShaderSource)new StringShaderSource(paramString2));
  }
  
  public ShaderProgram(IShaderSource paramIShaderSource1, IShaderSource paramIShaderSource2) {
    this.mVertexShaderSource = paramIShaderSource1;
    this.mFragmentShaderSource = paramIShaderSource2;
  }
  
  private static int compileShader(String paramString, int paramInt) throws ShaderProgramException {
    int i = GLES20.glCreateShader(paramInt);
    if (i == 0)
      throw new ShaderProgramException("Could not create Shader of type: '" + paramInt + '"'); 
    GLES20.glShaderSource(i, paramString);
    GLES20.glCompileShader(i);
    GLES20.glGetShaderiv(i, 35713, HARDWAREID_CONTAINER, 0);
    if (HARDWAREID_CONTAINER[0] == 0)
      throw new ShaderProgramCompileException(GLES20.glGetShaderInfoLog(i), paramString); 
    return i;
  }
  
  @Deprecated
  private void initAttributeLocations() {
    this.mAttributeLocations.clear();
    PARAMETERS_CONTAINER[0] = 0;
    GLES20.glGetProgramiv(this.mProgramID, 35721, PARAMETERS_CONTAINER, 0);
    int i = PARAMETERS_CONTAINER[0];
    byte b = 0;
    while (true) {
      if (b >= i)
        return; 
      GLES20.glGetActiveAttrib(this.mProgramID, b, 64, LENGTH_CONTAINER, 0, SIZE_CONTAINER, 0, TYPE_CONTAINER, 0, NAME_CONTAINER, 0);
      int j = LENGTH_CONTAINER[0];
      int k = j;
      if (j == 0) {
        String str;
        while (true) {
          k = j;
          if (j < 64)
            if (NAME_CONTAINER[j] == 0) {
              k = j;
            } else {
              j++;
              continue;
            }  
          str = new String(NAME_CONTAINER, 0, k);
          k = GLES20.glGetAttribLocation(this.mProgramID, str);
          j = k;
          if (k == -1)
            for (j = 0;; j++) {
              if (j >= 64 || NAME_CONTAINER[j] == 0) {
                String str1 = new String(NAME_CONTAINER, 0, j);
                k = GLES20.glGetAttribLocation(this.mProgramID, str1);
                j = k;
                str = str1;
                if (k == -1)
                  throw new ShaderProgramLinkException("Invalid location for attribute: '" + str1 + "'."); 
                break;
              } 
            }  
          break;
        } 
        this.mAttributeLocations.put(str, Integer.valueOf(j));
        b++;
        continue;
      } 
      continue;
    } 
  }
  
  private void initUniformLocations() throws ShaderProgramLinkException {
    this.mUniformLocations.clear();
    PARAMETERS_CONTAINER[0] = 0;
    GLES20.glGetProgramiv(this.mProgramID, 35718, PARAMETERS_CONTAINER, 0);
    int i = PARAMETERS_CONTAINER[0];
    byte b = 0;
    while (true) {
      if (b >= i)
        return; 
      GLES20.glGetActiveUniform(this.mProgramID, b, 64, LENGTH_CONTAINER, 0, SIZE_CONTAINER, 0, TYPE_CONTAINER, 0, NAME_CONTAINER, 0);
      int j = LENGTH_CONTAINER[0];
      int k = j;
      if (j == 0) {
        String str;
        while (true) {
          k = j;
          if (j < 64)
            if (NAME_CONTAINER[j] == 0) {
              k = j;
            } else {
              j++;
              continue;
            }  
          str = new String(NAME_CONTAINER, 0, k);
          k = GLES20.glGetUniformLocation(this.mProgramID, str);
          j = k;
          if (k == -1)
            for (j = 0;; j++) {
              if (j >= 64 || NAME_CONTAINER[j] == 0) {
                String str1 = new String(NAME_CONTAINER, 0, j);
                k = GLES20.glGetUniformLocation(this.mProgramID, str1);
                j = k;
                str = str1;
                if (k == -1)
                  throw new ShaderProgramLinkException("Invalid location for uniform: '" + str1 + "'."); 
                break;
              } 
            }  
          break;
        } 
        this.mUniformLocations.put(str, Integer.valueOf(j));
        b++;
        continue;
      } 
      continue;
    } 
  }
  
  public void bind(GLState paramGLState, VertexBufferObjectAttributes paramVertexBufferObjectAttributes) throws ShaderProgramException {
    if (!this.mCompiled)
      compile(paramGLState); 
    paramGLState.useProgram(this.mProgramID);
    paramVertexBufferObjectAttributes.glVertexAttribPointers();
  }
  
  protected void compile(GLState paramGLState) throws ShaderProgramException {
    String str1 = this.mVertexShaderSource.getShaderSource(paramGLState);
    int i = compileShader(str1, 35633);
    String str2 = this.mFragmentShaderSource.getShaderSource(paramGLState);
    int j = compileShader(str2, 35632);
    this.mProgramID = GLES20.glCreateProgram();
    GLES20.glAttachShader(this.mProgramID, i);
    GLES20.glAttachShader(this.mProgramID, j);
    try {
      link(paramGLState);
      GLES20.glDeleteShader(i);
      GLES20.glDeleteShader(j);
      return;
    } catch (ShaderProgramLinkException shaderProgramLinkException) {
      throw new ShaderProgramLinkException("VertexShaderSource:\n##########################\n" + str1 + "\n##########################" + "\n\nFragmentShaderSource:\n##########################\n" + str2 + "\n##########################", shaderProgramLinkException);
    } 
  }
  
  public void delete(GLState paramGLState) {
    if (this.mCompiled) {
      this.mCompiled = false;
      paramGLState.deleteProgram(this.mProgramID);
      this.mProgramID = -1;
    } 
  }
  
  public int getAttributeLocation(String paramString) {
    Integer integer = this.mAttributeLocations.get(paramString);
    if (integer != null)
      return integer.intValue(); 
    throw new ShaderProgramException("Unexpected attribute: '" + paramString + "'. Existing attributes: " + this.mAttributeLocations.toString());
  }
  
  public int getAttributeLocationOptional(String paramString) {
    Integer integer = this.mAttributeLocations.get(paramString);
    return (integer != null) ? integer.intValue() : -1;
  }
  
  public int getUniformLocation(String paramString) {
    Integer integer = this.mUniformLocations.get(paramString);
    if (integer != null)
      return integer.intValue(); 
    throw new ShaderProgramException("Unexpected uniform: '" + paramString + "'. Existing uniforms: " + this.mUniformLocations.toString());
  }
  
  public int getUniformLocationOptional(String paramString) {
    Integer integer = this.mUniformLocations.get(paramString);
    return (integer != null) ? integer.intValue() : -1;
  }
  
  public boolean isCompiled() {
    return this.mCompiled;
  }
  
  protected void link(GLState paramGLState) throws ShaderProgramLinkException {
    GLES20.glLinkProgram(this.mProgramID);
    GLES20.glGetProgramiv(this.mProgramID, 35714, HARDWAREID_CONTAINER, 0);
    if (HARDWAREID_CONTAINER[0] == 0)
      throw new ShaderProgramLinkException(GLES20.glGetProgramInfoLog(this.mProgramID)); 
    initAttributeLocations();
    initUniformLocations();
    this.mCompiled = true;
  }
  
  public void setCompiled(boolean paramBoolean) {
    this.mCompiled = paramBoolean;
  }
  
  public void setTexture(String paramString, int paramInt) {
    GLES20.glUniform1i(getUniformLocation(paramString), paramInt);
  }
  
  public void setTextureOptional(String paramString, int paramInt) {
    int i = getUniformLocationOptional(paramString);
    if (i != -1)
      GLES20.glUniform1i(i, paramInt); 
  }
  
  public void setUniform(String paramString, float paramFloat) {
    GLES20.glUniform1f(getUniformLocation(paramString), paramFloat);
  }
  
  public void setUniform(String paramString, float paramFloat1, float paramFloat2) {
    GLES20.glUniform2f(getUniformLocation(paramString), paramFloat1, paramFloat2);
  }
  
  public void setUniform(String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
    GLES20.glUniform3f(getUniformLocation(paramString), paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void setUniform(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    GLES20.glUniform4f(getUniformLocation(paramString), paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void setUniform(String paramString, float[] paramArrayOffloat) {
    GLES20.glUniformMatrix4fv(getUniformLocation(paramString), 1, false, paramArrayOffloat, 0);
  }
  
  public void setUniformOptional(String paramString, float paramFloat) {
    if (getUniformLocationOptional(paramString) != -1)
      GLES20.glUniform1f(getUniformLocationOptional(paramString), paramFloat); 
  }
  
  public void setUniformOptional(String paramString, float paramFloat1, float paramFloat2) {
    if (getUniformLocationOptional(paramString) != -1)
      GLES20.glUniform2f(getUniformLocationOptional(paramString), paramFloat1, paramFloat2); 
  }
  
  public void setUniformOptional(String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
    if (getUniformLocationOptional(paramString) != -1)
      GLES20.glUniform3f(getUniformLocationOptional(paramString), paramFloat1, paramFloat2, paramFloat3); 
  }
  
  public void setUniformOptional(String paramString, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    if (getUniformLocationOptional(paramString) != -1)
      GLES20.glUniform4f(getUniformLocationOptional(paramString), paramFloat1, paramFloat2, paramFloat3, paramFloat4); 
  }
  
  public void setUniformOptional(String paramString, float[] paramArrayOffloat) {
    if (getUniformLocationOptional(paramString) != -1)
      GLES20.glUniformMatrix4fv(getUniformLocationOptional(paramString), 1, false, paramArrayOffloat, 0); 
  }
  
  public void unbind(GLState paramGLState) throws ShaderProgramException {}
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/shader/ShaderProgram.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */