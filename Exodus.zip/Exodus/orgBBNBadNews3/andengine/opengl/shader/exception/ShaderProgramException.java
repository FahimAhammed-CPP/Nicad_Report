package org.andengine.opengl.shader.exception;

import org.andengine.util.exception.AndEngineRuntimeException;

public class ShaderProgramException extends AndEngineRuntimeException {
  private static final long serialVersionUID = 2377158902169370516L;
  
  public ShaderProgramException(String paramString) {
    super(paramString);
  }
  
  public ShaderProgramException(String paramString, ShaderProgramException paramShaderProgramException) {
    super(paramString, (Throwable)paramShaderProgramException);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/shader/exception/ShaderProgramException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */