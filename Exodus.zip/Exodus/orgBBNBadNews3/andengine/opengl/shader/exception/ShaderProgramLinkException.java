package org.andengine.opengl.shader.exception;

public class ShaderProgramLinkException extends ShaderProgramException {
  private static final long serialVersionUID = 5418521931032742504L;
  
  public ShaderProgramLinkException(String paramString) {
    super(paramString);
  }
  
  public ShaderProgramLinkException(String paramString, ShaderProgramException paramShaderProgramException) {
    super(paramString, paramShaderProgramException);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/shader/exception/ShaderProgramLinkException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */