package org.andengine.opengl.vbo;

import org.andengine.opengl.shader.ShaderProgram;
import org.andengine.opengl.util.GLState;
import org.andengine.util.IDisposable;

public interface IVertexBufferObject extends IDisposable {
  public static final int HARDWARE_BUFFER_ID_INVALID = -1;
  
  void bind(GLState paramGLState);
  
  void bind(GLState paramGLState, ShaderProgram paramShaderProgram);
  
  void draw(int paramInt1, int paramInt2);
  
  void draw(int paramInt1, int paramInt2, int paramInt3);
  
  int getByteCapacity();
  
  int getCapacity();
  
  int getGPUMemoryByteSize();
  
  int getHardwareBufferID();
  
  int getHeapMemoryByteSize();
  
  int getNativeHeapMemoryByteSize();
  
  VertexBufferObjectManager getVertexBufferObjectManager();
  
  boolean isAutoDispose();
  
  boolean isDirtyOnHardware();
  
  boolean isLoadedToHardware();
  
  void setDirtyOnHardware();
  
  void setNotLoadedToHardware();
  
  void unbind(GLState paramGLState, ShaderProgram paramShaderProgram);
  
  void unloadFromHardware(GLState paramGLState);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/vbo/IVertexBufferObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */