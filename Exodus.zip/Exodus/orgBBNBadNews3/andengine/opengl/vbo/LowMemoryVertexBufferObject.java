package org.andengine.opengl.vbo;

import android.opengl.GLES20;
import java.nio.FloatBuffer;
import org.andengine.opengl.vbo.attribute.VertexBufferObjectAttributes;

public class LowMemoryVertexBufferObject extends VertexBufferObject {
  protected final FloatBuffer mFloatBuffer = this.mByteBuffer.asFloatBuffer();
  
  public LowMemoryVertexBufferObject(VertexBufferObjectManager paramVertexBufferObjectManager, int paramInt, DrawType paramDrawType, boolean paramBoolean, VertexBufferObjectAttributes paramVertexBufferObjectAttributes) {
    super(paramVertexBufferObjectManager, paramInt, paramDrawType, paramBoolean, paramVertexBufferObjectAttributes);
  }
  
  public FloatBuffer getFloatBuffer() {
    return this.mFloatBuffer;
  }
  
  public int getHeapMemoryByteSize() {
    return 0;
  }
  
  public int getNativeHeapMemoryByteSize() {
    return getByteCapacity();
  }
  
  protected void onBufferData() {
    GLES20.glBufferData(34962, this.mByteBuffer.limit(), this.mByteBuffer, this.mUsage);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/vbo/LowMemoryVertexBufferObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */