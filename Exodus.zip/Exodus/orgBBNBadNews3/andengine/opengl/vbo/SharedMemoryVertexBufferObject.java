package org.andengine.opengl.vbo;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.locks.ReentrantLock;
import org.andengine.opengl.util.BufferUtils;
import org.andengine.opengl.vbo.attribute.VertexBufferObjectAttributes;

public abstract class SharedMemoryVertexBufferObject extends ZeroMemoryVertexBufferObject {
  private static ByteBuffer sSharedByteBuffer;
  
  private static ReentrantLock sSharedByteBufferLock = new ReentrantLock(true);
  
  public SharedMemoryVertexBufferObject(VertexBufferObjectManager paramVertexBufferObjectManager, int paramInt, DrawType paramDrawType, VertexBufferObjectAttributes paramVertexBufferObjectAttributes) {
    super(paramVertexBufferObjectManager, paramInt, paramDrawType, false, paramVertexBufferObjectAttributes);
  }
  
  public static int getSharedByteBufferByteCapacity() {
    try {
      sSharedByteBufferLock.lock();
      ByteBuffer byteBuffer = sSharedByteBuffer;
      if (byteBuffer == null)
        return 0; 
      return byteBuffer.capacity();
    } finally {
      sSharedByteBufferLock.unlock();
    } 
  }
  
  protected ByteBuffer aquireByteBuffer() {
    sSharedByteBufferLock.lock();
    int i = getByteCapacity();
    if (sSharedByteBuffer == null || sSharedByteBuffer.capacity() < i) {
      if (sSharedByteBuffer != null)
        BufferUtils.freeDirectByteBuffer(sSharedByteBuffer); 
      sSharedByteBuffer = BufferUtils.allocateDirectByteBuffer(i);
      sSharedByteBuffer.order(ByteOrder.nativeOrder());
    } 
    sSharedByteBuffer.limit(i);
    return sSharedByteBuffer;
  }
  
  public void dispose() {
    super.dispose();
    try {
      sSharedByteBufferLock.lock();
      if (sSharedByteBuffer != null) {
        BufferUtils.freeDirectByteBuffer(sSharedByteBuffer);
        sSharedByteBuffer = null;
      } 
      return;
    } finally {
      sSharedByteBufferLock.unlock();
    } 
  }
  
  protected void releaseByteBuffer(ByteBuffer paramByteBuffer) {
    sSharedByteBufferLock.unlock();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/vbo/SharedMemoryVertexBufferObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */