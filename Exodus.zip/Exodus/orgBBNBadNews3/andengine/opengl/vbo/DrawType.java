package org.andengine.opengl.vbo;

public enum DrawType {
  DYNAMIC,
  STATIC(35044),
  STREAM(35044);
  
  private final int mUsage;
  
  static {
    DYNAMIC = new DrawType("DYNAMIC", 1, 35048);
    STREAM = new DrawType("STREAM", 2, 35040);
    ENUM$VALUES = new DrawType[] { STATIC, DYNAMIC, STREAM };
  }
  
  DrawType(int paramInt1) {
    this.mUsage = paramInt1;
  }
  
  public int getUsage() {
    return this.mUsage;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/vbo/DrawType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */