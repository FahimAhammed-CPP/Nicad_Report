package org.andengine.opengl.vbo;

import java.util.ArrayList;
import org.andengine.opengl.util.GLState;

public class VertexBufferObjectManager {
  private final ArrayList<IVertexBufferObject> mVertexBufferObjectsLoaded = new ArrayList<IVertexBufferObject>();
  
  private final ArrayList<IVertexBufferObject> mVertexBufferObjectsToBeUnloaded = new ArrayList<IVertexBufferObject>();
  
  public int getGPUHeapMemoryByteSize() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore_1
    //   4: aload_0
    //   5: getfield mVertexBufferObjectsLoaded : Ljava/util/ArrayList;
    //   8: astore_2
    //   9: aload_2
    //   10: invokevirtual size : ()I
    //   13: istore_3
    //   14: iinc #3, -1
    //   17: iload_3
    //   18: ifge -> 25
    //   21: aload_0
    //   22: monitorexit
    //   23: iload_1
    //   24: ireturn
    //   25: aload_2
    //   26: iload_3
    //   27: invokevirtual get : (I)Ljava/lang/Object;
    //   30: checkcast org/andengine/opengl/vbo/IVertexBufferObject
    //   33: invokeinterface getGPUMemoryByteSize : ()I
    //   38: istore #4
    //   40: iload_1
    //   41: iload #4
    //   43: iadd
    //   44: istore_1
    //   45: iinc #3, -1
    //   48: goto -> 17
    //   51: astore_2
    //   52: aload_0
    //   53: monitorexit
    //   54: aload_2
    //   55: athrow
    // Exception table:
    //   from	to	target	type
    //   4	14	51	finally
    //   25	40	51	finally
  }
  
  public int getHeapMemoryByteSize() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore_1
    //   4: aload_0
    //   5: getfield mVertexBufferObjectsLoaded : Ljava/util/ArrayList;
    //   8: astore_2
    //   9: aload_2
    //   10: invokevirtual size : ()I
    //   13: istore_3
    //   14: iinc #3, -1
    //   17: iload_3
    //   18: ifge -> 25
    //   21: aload_0
    //   22: monitorexit
    //   23: iload_1
    //   24: ireturn
    //   25: aload_2
    //   26: iload_3
    //   27: invokevirtual get : (I)Ljava/lang/Object;
    //   30: checkcast org/andengine/opengl/vbo/IVertexBufferObject
    //   33: invokeinterface getHeapMemoryByteSize : ()I
    //   38: istore #4
    //   40: iload_1
    //   41: iload #4
    //   43: iadd
    //   44: istore_1
    //   45: iinc #3, -1
    //   48: goto -> 17
    //   51: astore_2
    //   52: aload_0
    //   53: monitorexit
    //   54: aload_2
    //   55: athrow
    // Exception table:
    //   from	to	target	type
    //   4	14	51	finally
    //   25	40	51	finally
  }
  
  public int getNativeHeapMemoryByteSize() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore_1
    //   4: aload_0
    //   5: getfield mVertexBufferObjectsLoaded : Ljava/util/ArrayList;
    //   8: astore_2
    //   9: aload_2
    //   10: invokevirtual size : ()I
    //   13: istore_3
    //   14: iinc #3, -1
    //   17: iload_3
    //   18: ifge -> 25
    //   21: aload_0
    //   22: monitorexit
    //   23: iload_1
    //   24: ireturn
    //   25: aload_2
    //   26: iload_3
    //   27: invokevirtual get : (I)Ljava/lang/Object;
    //   30: checkcast org/andengine/opengl/vbo/IVertexBufferObject
    //   33: invokeinterface getNativeHeapMemoryByteSize : ()I
    //   38: istore #4
    //   40: iload_1
    //   41: iload #4
    //   43: iadd
    //   44: istore_1
    //   45: iinc #3, -1
    //   48: goto -> 17
    //   51: astore_2
    //   52: aload_0
    //   53: monitorexit
    //   54: aload_2
    //   55: athrow
    // Exception table:
    //   from	to	target	type
    //   4	14	51	finally
    //   25	40	51	finally
  }
  
  public void onCreate() {}
  
  public void onDestroy() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mVertexBufferObjectsLoaded : Ljava/util/ArrayList;
    //   6: astore_1
    //   7: aload_1
    //   8: invokevirtual size : ()I
    //   11: iconst_1
    //   12: isub
    //   13: istore_2
    //   14: iload_2
    //   15: ifge -> 25
    //   18: aload_1
    //   19: invokevirtual clear : ()V
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: aload_1
    //   26: iload_2
    //   27: invokevirtual get : (I)Ljava/lang/Object;
    //   30: checkcast org/andengine/opengl/vbo/IVertexBufferObject
    //   33: invokeinterface setNotLoadedToHardware : ()V
    //   38: iinc #2, -1
    //   41: goto -> 14
    //   44: astore_1
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	44	finally
    //   18	22	44	finally
    //   25	38	44	finally
  }
  
  public void onReload() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mVertexBufferObjectsLoaded : Ljava/util/ArrayList;
    //   6: astore_1
    //   7: aload_1
    //   8: invokevirtual size : ()I
    //   11: iconst_1
    //   12: isub
    //   13: istore_2
    //   14: iload_2
    //   15: ifge -> 25
    //   18: aload_1
    //   19: invokevirtual clear : ()V
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: aload_1
    //   26: iload_2
    //   27: invokevirtual get : (I)Ljava/lang/Object;
    //   30: checkcast org/andengine/opengl/vbo/IVertexBufferObject
    //   33: invokeinterface setNotLoadedToHardware : ()V
    //   38: iinc #2, -1
    //   41: goto -> 14
    //   44: astore_1
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	44	finally
    //   18	22	44	finally
    //   25	38	44	finally
  }
  
  public void onUnloadVertexBufferObject(IVertexBufferObject paramIVertexBufferObject) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mVertexBufferObjectsLoaded : Ljava/util/ArrayList;
    //   6: aload_1
    //   7: invokevirtual remove : (Ljava/lang/Object;)Z
    //   10: ifeq -> 22
    //   13: aload_0
    //   14: getfield mVertexBufferObjectsToBeUnloaded : Ljava/util/ArrayList;
    //   17: aload_1
    //   18: invokevirtual add : (Ljava/lang/Object;)Z
    //   21: pop
    //   22: aload_0
    //   23: monitorexit
    //   24: return
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	25	finally
  }
  
  public void onVertexBufferObjectLoaded(IVertexBufferObject paramIVertexBufferObject) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mVertexBufferObjectsLoaded : Ljava/util/ArrayList;
    //   6: aload_1
    //   7: invokevirtual add : (Ljava/lang/Object;)Z
    //   10: pop
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: astore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: aload_1
    //   18: athrow
    // Exception table:
    //   from	to	target	type
    //   2	11	14	finally
  }
  
  public void updateVertexBufferObjects(GLState paramGLState) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mVertexBufferObjectsLoaded : Ljava/util/ArrayList;
    //   6: astore_2
    //   7: aload_0
    //   8: getfield mVertexBufferObjectsToBeUnloaded : Ljava/util/ArrayList;
    //   11: astore_3
    //   12: aload_3
    //   13: invokevirtual size : ()I
    //   16: istore #4
    //   18: iinc #4, -1
    //   21: iload #4
    //   23: ifge -> 29
    //   26: aload_0
    //   27: monitorexit
    //   28: return
    //   29: aload_3
    //   30: iload #4
    //   32: invokevirtual remove : (I)Ljava/lang/Object;
    //   35: checkcast org/andengine/opengl/vbo/IVertexBufferObject
    //   38: astore #5
    //   40: aload #5
    //   42: invokeinterface isLoadedToHardware : ()Z
    //   47: ifeq -> 58
    //   50: aload #5
    //   52: aload_1
    //   53: invokeinterface unloadFromHardware : (Lorg/andengine/opengl/util/GLState;)V
    //   58: aload_2
    //   59: aload #5
    //   61: invokevirtual remove : (Ljava/lang/Object;)Z
    //   64: pop
    //   65: iinc #4, -1
    //   68: goto -> 21
    //   71: astore_1
    //   72: aload_0
    //   73: monitorexit
    //   74: aload_1
    //   75: athrow
    // Exception table:
    //   from	to	target	type
    //   2	18	71	finally
    //   29	58	71	finally
    //   58	65	71	finally
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/vbo/VertexBufferObjectManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */