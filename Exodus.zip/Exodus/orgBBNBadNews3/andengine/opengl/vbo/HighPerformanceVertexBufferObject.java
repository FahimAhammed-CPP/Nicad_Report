package org.andengine.opengl.vbo;

import android.opengl.GLES20;
import java.nio.FloatBuffer;
import org.andengine.opengl.util.BufferUtils;
import org.andengine.opengl.vbo.attribute.VertexBufferObjectAttributes;
import org.andengine.util.system.SystemUtils;

public class HighPerformanceVertexBufferObject extends VertexBufferObject {
  protected final float[] mBufferData;
  
  protected final FloatBuffer mFloatBuffer;
  
  public HighPerformanceVertexBufferObject(VertexBufferObjectManager paramVertexBufferObjectManager, int paramInt, DrawType paramDrawType, boolean paramBoolean, VertexBufferObjectAttributes paramVertexBufferObjectAttributes) {
    super(paramVertexBufferObjectManager, paramInt, paramDrawType, paramBoolean, paramVertexBufferObjectAttributes);
    this.mBufferData = new float[paramInt];
    if (SystemUtils.SDK_VERSION_HONEYCOMB_OR_LATER) {
      this.mFloatBuffer = this.mByteBuffer.asFloatBuffer();
      return;
    } 
    this.mFloatBuffer = null;
  }
  
  public HighPerformanceVertexBufferObject(VertexBufferObjectManager paramVertexBufferObjectManager, float[] paramArrayOffloat, DrawType paramDrawType, boolean paramBoolean, VertexBufferObjectAttributes paramVertexBufferObjectAttributes) {
    super(paramVertexBufferObjectManager, paramArrayOffloat.length, paramDrawType, paramBoolean, paramVertexBufferObjectAttributes);
    this.mBufferData = paramArrayOffloat;
    if (SystemUtils.SDK_VERSION_HONEYCOMB_OR_LATER) {
      this.mFloatBuffer = this.mByteBuffer.asFloatBuffer();
      return;
    } 
    this.mFloatBuffer = null;
  }
  
  public float[] getBufferData() {
    return this.mBufferData;
  }
  
  public int getHeapMemoryByteSize() {
    return getByteCapacity();
  }
  
  public int getNativeHeapMemoryByteSize() {
    return getByteCapacity();
  }
  
  protected void onBufferData() {
    if (SystemUtils.SDK_VERSION_HONEYCOMB_OR_LATER) {
      this.mFloatBuffer.position(0);
      this.mFloatBuffer.put(this.mBufferData);
      GLES20.glBufferData(34962, this.mByteBuffer.capacity(), this.mByteBuffer, this.mUsage);
      return;
    } 
    BufferUtils.put(this.mByteBuffer, this.mBufferData, this.mBufferData.length, 0);
    GLES20.glBufferData(34962, this.mByteBuffer.limit(), this.mByteBuffer, this.mUsage);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/vbo/HighPerformanceVertexBufferObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */