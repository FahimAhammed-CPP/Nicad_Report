package org.andengine.opengl.vbo.attribute;

import org.andengine.opengl.GLES20Fix;

public class VertexBufferObjectAttributeFix extends VertexBufferObjectAttribute {
  public VertexBufferObjectAttributeFix(int paramInt1, String paramString, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4) {
    super(paramInt1, paramString, paramInt2, paramInt3, paramBoolean, paramInt4);
  }
  
  public void glVertexAttribPointer(int paramInt) {
    GLES20Fix.glVertexAttribPointer(this.mLocation, this.mSize, this.mType, this.mNormalized, paramInt, this.mOffset);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/vbo/attribute/VertexBufferObjectAttributeFix.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */