package org.andengine.opengl.vbo.attribute;

import org.andengine.util.exception.AndEngineRuntimeException;
import org.andengine.util.system.SystemUtils;

public class VertexBufferObjectAttributesBuilder {
  private static final boolean WORAROUND_GLES2_GLVERTEXATTRIBPOINTER_MISSING = SystemUtils.isAndroidVersionOrLower(8);
  
  private int mIndex;
  
  private int mOffset;
  
  private final VertexBufferObjectAttribute[] mVertexBufferObjectAttributes;
  
  public VertexBufferObjectAttributesBuilder(int paramInt) {
    this.mVertexBufferObjectAttributes = new VertexBufferObjectAttribute[paramInt];
  }
  
  public VertexBufferObjectAttributesBuilder add(int paramInt1, String paramString, int paramInt2, int paramInt3, boolean paramBoolean) {
    if (WORAROUND_GLES2_GLVERTEXATTRIBPOINTER_MISSING) {
      this.mVertexBufferObjectAttributes[this.mIndex] = new VertexBufferObjectAttributeFix(paramInt1, paramString, paramInt2, paramInt3, paramBoolean, this.mOffset);
    } else {
      this.mVertexBufferObjectAttributes[this.mIndex] = new VertexBufferObjectAttribute(paramInt1, paramString, paramInt2, paramInt3, paramBoolean, this.mOffset);
    } 
    switch (paramInt3) {
      default:
        throw new IllegalArgumentException("Unexpected pType: '" + paramInt3 + "'.");
      case 5126:
        this.mOffset += paramInt2 * 4;
        this.mIndex++;
        return this;
      case 5121:
        break;
    } 
    this.mOffset += paramInt2 * 1;
    this.mIndex++;
    return this;
  }
  
  public VertexBufferObjectAttributes build() {
    if (this.mIndex != this.mVertexBufferObjectAttributes.length)
      throw new AndEngineRuntimeException("Not enough " + VertexBufferObjectAttribute.class.getSimpleName() + "s added to this " + getClass().getSimpleName() + "."); 
    return new VertexBufferObjectAttributes(this.mOffset, this.mVertexBufferObjectAttributes);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/vbo/attribute/VertexBufferObjectAttributesBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */