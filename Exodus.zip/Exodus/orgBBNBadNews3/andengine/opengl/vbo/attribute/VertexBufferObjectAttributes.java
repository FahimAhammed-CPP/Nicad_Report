package org.andengine.opengl.vbo.attribute;

public class VertexBufferObjectAttributes {
  private final int mStride;
  
  private final VertexBufferObjectAttribute[] mVertexBufferObjectAttributes;
  
  public VertexBufferObjectAttributes(int paramInt, VertexBufferObjectAttribute... paramVarArgs) {
    this.mVertexBufferObjectAttributes = paramVarArgs;
    this.mStride = paramInt;
  }
  
  public void glVertexAttribPointers() {
    VertexBufferObjectAttribute[] arrayOfVertexBufferObjectAttribute = this.mVertexBufferObjectAttributes;
    int i = this.mStride;
    int j = arrayOfVertexBufferObjectAttribute.length;
    for (byte b = 0;; b++) {
      if (b >= j)
        return; 
      arrayOfVertexBufferObjectAttribute[b].glVertexAttribPointer(i);
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/vbo/attribute/VertexBufferObjectAttributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */