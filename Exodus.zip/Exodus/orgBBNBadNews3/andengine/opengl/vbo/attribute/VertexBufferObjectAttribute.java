package org.andengine.opengl.vbo.attribute;

import android.opengl.GLES20;

public class VertexBufferObjectAttribute {
  final int mLocation;
  
  final String mName;
  
  final boolean mNormalized;
  
  final int mOffset;
  
  final int mSize;
  
  final int mType;
  
  public VertexBufferObjectAttribute(int paramInt1, String paramString, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4) {
    this.mLocation = paramInt1;
    this.mName = paramString;
    this.mSize = paramInt2;
    this.mType = paramInt3;
    this.mNormalized = paramBoolean;
    this.mOffset = paramInt4;
  }
  
  public int getLocation() {
    return this.mLocation;
  }
  
  public String getName() {
    return this.mName;
  }
  
  public int getOffset() {
    return this.mOffset;
  }
  
  public int getSize() {
    return this.mSize;
  }
  
  public int getType() {
    return this.mType;
  }
  
  public void glVertexAttribPointer(int paramInt) {
    GLES20.glVertexAttribPointer(this.mLocation, this.mSize, this.mType, this.mNormalized, paramInt, this.mOffset);
  }
  
  public boolean isNormalized() {
    return this.mNormalized;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/vbo/attribute/VertexBufferObjectAttribute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */