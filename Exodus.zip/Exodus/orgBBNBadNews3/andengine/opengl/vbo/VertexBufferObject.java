package org.andengine.opengl.vbo;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.andengine.opengl.shader.ShaderProgram;
import org.andengine.opengl.util.BufferUtils;
import org.andengine.opengl.util.GLState;
import org.andengine.opengl.vbo.attribute.VertexBufferObjectAttributes;
import org.andengine.util.IDisposable;

public abstract class VertexBufferObject implements IVertexBufferObject {
  protected final boolean mAutoDispose;
  
  protected final ByteBuffer mByteBuffer;
  
  protected final int mCapacity;
  
  protected boolean mDirtyOnHardware = true;
  
  protected boolean mDisposed;
  
  protected int mHardwareBufferID = -1;
  
  protected final int mUsage;
  
  protected final VertexBufferObjectAttributes mVertexBufferObjectAttributes;
  
  protected final VertexBufferObjectManager mVertexBufferObjectManager;
  
  public VertexBufferObject(VertexBufferObjectManager paramVertexBufferObjectManager, int paramInt, DrawType paramDrawType, boolean paramBoolean, VertexBufferObjectAttributes paramVertexBufferObjectAttributes) {
    this.mVertexBufferObjectManager = paramVertexBufferObjectManager;
    this.mCapacity = paramInt;
    this.mUsage = paramDrawType.getUsage();
    this.mAutoDispose = paramBoolean;
    this.mVertexBufferObjectAttributes = paramVertexBufferObjectAttributes;
    this.mByteBuffer = BufferUtils.allocateDirectByteBuffer(paramInt * 4);
    this.mByteBuffer.order(ByteOrder.nativeOrder());
  }
  
  private void loadToHardware(GLState paramGLState) {
    this.mHardwareBufferID = paramGLState.generateBuffer();
    this.mDirtyOnHardware = true;
  }
  
  public void bind(GLState paramGLState) {
    if (this.mHardwareBufferID == -1) {
      loadToHardware(paramGLState);
      if (this.mVertexBufferObjectManager != null)
        this.mVertexBufferObjectManager.onVertexBufferObjectLoaded(this); 
    } 
    paramGLState.bindArrayBuffer(this.mHardwareBufferID);
    if (this.mDirtyOnHardware) {
      onBufferData();
      this.mDirtyOnHardware = false;
    } 
  }
  
  public void bind(GLState paramGLState, ShaderProgram paramShaderProgram) {
    bind(paramGLState);
    paramShaderProgram.bind(paramGLState, this.mVertexBufferObjectAttributes);
  }
  
  public void dispose() {
    if (!this.mDisposed) {
      this.mDisposed = true;
      if (this.mVertexBufferObjectManager != null)
        this.mVertexBufferObjectManager.onUnloadVertexBufferObject(this); 
      BufferUtils.freeDirectByteBuffer(this.mByteBuffer);
      return;
    } 
    throw new IDisposable.AlreadyDisposedException();
  }
  
  public void draw(int paramInt1, int paramInt2) {
    GLES20.glDrawArrays(paramInt1, 0, paramInt2);
  }
  
  public void draw(int paramInt1, int paramInt2, int paramInt3) {
    GLES20.glDrawArrays(paramInt1, paramInt2, paramInt3);
  }
  
  protected void finalize() throws Throwable {
    super.finalize();
    if (!this.mDisposed)
      dispose(); 
  }
  
  public int getByteCapacity() {
    return this.mByteBuffer.capacity();
  }
  
  public int getCapacity() {
    return this.mCapacity;
  }
  
  public int getGPUMemoryByteSize() {
    return isLoadedToHardware() ? getByteCapacity() : 0;
  }
  
  public int getHardwareBufferID() {
    return this.mHardwareBufferID;
  }
  
  public VertexBufferObjectManager getVertexBufferObjectManager() {
    return this.mVertexBufferObjectManager;
  }
  
  public boolean isAutoDispose() {
    return this.mAutoDispose;
  }
  
  public boolean isDirtyOnHardware() {
    return this.mDirtyOnHardware;
  }
  
  public boolean isDisposed() {
    return this.mDisposed;
  }
  
  public boolean isLoadedToHardware() {
    return (this.mHardwareBufferID != -1);
  }
  
  protected abstract void onBufferData();
  
  public void setDirtyOnHardware() {
    this.mDirtyOnHardware = true;
  }
  
  public void setNotLoadedToHardware() {
    this.mHardwareBufferID = -1;
    this.mDirtyOnHardware = true;
  }
  
  public void unbind(GLState paramGLState, ShaderProgram paramShaderProgram) {
    paramShaderProgram.unbind(paramGLState);
  }
  
  public void unloadFromHardware(GLState paramGLState) {
    paramGLState.deleteArrayBuffer(this.mHardwareBufferID);
    this.mHardwareBufferID = -1;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/vbo/VertexBufferObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */