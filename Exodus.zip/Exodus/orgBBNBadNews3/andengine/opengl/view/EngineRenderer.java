package org.andengine.opengl.view;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import org.andengine.engine.Engine;
import org.andengine.opengl.util.GLState;

public class EngineRenderer implements GLSurfaceView.Renderer {
  final ConfigChooser mConfigChooser;
  
  final Engine mEngine;
  
  final GLState mGLState;
  
  final boolean mMultiSampling;
  
  final IRendererListener mRendererListener;
  
  public EngineRenderer(Engine paramEngine, ConfigChooser paramConfigChooser, IRendererListener paramIRendererListener) {
    this.mEngine = paramEngine;
    this.mConfigChooser = paramConfigChooser;
    this.mRendererListener = paramIRendererListener;
    this.mGLState = new GLState();
    this.mMultiSampling = this.mEngine.getEngineOptions().getRenderOptions().isMultiSampling();
  }
  
  public void onDrawFrame(GL10 paramGL10) {
    // Byte code:
    //   0: ldc org/andengine/opengl/util/GLState
    //   2: monitorenter
    //   3: aload_0
    //   4: getfield mMultiSampling : Z
    //   7: ifeq -> 25
    //   10: aload_0
    //   11: getfield mConfigChooser : Lorg/andengine/opengl/view/ConfigChooser;
    //   14: invokevirtual isCoverageMultiSampling : ()Z
    //   17: ifeq -> 25
    //   20: ldc 32768
    //   22: invokestatic glClear : (I)V
    //   25: aload_0
    //   26: getfield mEngine : Lorg/andengine/engine/Engine;
    //   29: aload_0
    //   30: getfield mGLState : Lorg/andengine/opengl/util/GLState;
    //   33: invokevirtual onDrawFrame : (Lorg/andengine/opengl/util/GLState;)V
    //   36: ldc org/andengine/opengl/util/GLState
    //   38: monitorexit
    //   39: return
    //   40: astore_1
    //   41: ldc 'GLThread interrupted!'
    //   43: aload_1
    //   44: invokestatic e : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   47: goto -> 36
    //   50: astore_1
    //   51: ldc org/andengine/opengl/util/GLState
    //   53: monitorexit
    //   54: aload_1
    //   55: athrow
    // Exception table:
    //   from	to	target	type
    //   3	25	50	finally
    //   25	36	40	java/lang/InterruptedException
    //   25	36	50	finally
    //   36	39	50	finally
    //   41	47	50	finally
    //   51	54	50	finally
  }
  
  public void onSurfaceChanged(GL10 paramGL10, int paramInt1, int paramInt2) {
    this.mEngine.setSurfaceSize(paramInt1, paramInt2);
    GLES20.glViewport(0, 0, paramInt1, paramInt2);
    this.mGLState.loadProjectionGLMatrixIdentity();
    if (this.mRendererListener != null)
      this.mRendererListener.onSurfaceChanged(this.mGLState, paramInt1, paramInt2); 
  }
  
  public void onSurfaceCreated(GL10 paramGL10, EGLConfig paramEGLConfig) {
    // Byte code:
    //   0: ldc org/andengine/opengl/util/GLState
    //   2: monitorenter
    //   3: aload_0
    //   4: getfield mEngine : Lorg/andengine/engine/Engine;
    //   7: invokevirtual getEngineOptions : ()Lorg/andengine/engine/options/EngineOptions;
    //   10: invokevirtual getRenderOptions : ()Lorg/andengine/engine/options/RenderOptions;
    //   13: astore_1
    //   14: aload_0
    //   15: getfield mGLState : Lorg/andengine/opengl/util/GLState;
    //   18: aload_1
    //   19: aload_0
    //   20: getfield mConfigChooser : Lorg/andengine/opengl/view/ConfigChooser;
    //   23: aload_2
    //   24: invokevirtual reset : (Lorg/andengine/engine/options/RenderOptions;Lorg/andengine/opengl/view/ConfigChooser;Ljavax/microedition/khronos/egl/EGLConfig;)V
    //   27: aload_0
    //   28: getfield mGLState : Lorg/andengine/opengl/util/GLState;
    //   31: invokevirtual disableDepthTest : ()Z
    //   34: pop
    //   35: aload_0
    //   36: getfield mGLState : Lorg/andengine/opengl/util/GLState;
    //   39: invokevirtual enableBlend : ()Z
    //   42: pop
    //   43: aload_0
    //   44: getfield mGLState : Lorg/andengine/opengl/util/GLState;
    //   47: aload_1
    //   48: invokevirtual isDithering : ()Z
    //   51: invokevirtual setDitherEnabled : (Z)Z
    //   54: pop
    //   55: aload_0
    //   56: getfield mRendererListener : Lorg/andengine/opengl/view/IRendererListener;
    //   59: ifnull -> 75
    //   62: aload_0
    //   63: getfield mRendererListener : Lorg/andengine/opengl/view/IRendererListener;
    //   66: aload_0
    //   67: getfield mGLState : Lorg/andengine/opengl/util/GLState;
    //   70: invokeinterface onSurfaceCreated : (Lorg/andengine/opengl/util/GLState;)V
    //   75: ldc org/andengine/opengl/util/GLState
    //   77: monitorexit
    //   78: return
    //   79: astore_1
    //   80: ldc org/andengine/opengl/util/GLState
    //   82: monitorexit
    //   83: aload_1
    //   84: athrow
    // Exception table:
    //   from	to	target	type
    //   3	75	79	finally
    //   75	78	79	finally
    //   80	83	79	finally
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/view/EngineRenderer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */