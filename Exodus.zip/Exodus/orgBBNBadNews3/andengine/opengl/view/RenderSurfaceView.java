package org.andengine.opengl.view;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.util.AttributeSet;
import android.view.View;
import org.andengine.engine.Engine;

public class RenderSurfaceView extends GLSurfaceView {
  private ConfigChooser mConfigChooser;
  
  private EngineRenderer mEngineRenderer;
  
  public RenderSurfaceView(Context paramContext) {
    super(paramContext);
    setEGLContextClientVersion(2);
  }
  
  public RenderSurfaceView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setEGLContextClientVersion(2);
  }
  
  public ConfigChooser getConfigChooser() throws IllegalStateException {
    if (this.mConfigChooser == null)
      throw new IllegalStateException(String.valueOf(ConfigChooser.class.getSimpleName()) + " not yet set."); 
    return this.mConfigChooser;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (isInEditMode()) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    this.mEngineRenderer.mEngine.getEngineOptions().getResolutionPolicy().onMeasure(this, paramInt1, paramInt2);
  }
  
  public void setMeasuredDimensionProxy(int paramInt1, int paramInt2) {
    setMeasuredDimension(paramInt1, paramInt2);
  }
  
  public void setRenderer(Engine paramEngine, IRendererListener paramIRendererListener) {
    if (this.mConfigChooser == null)
      this.mConfigChooser = new ConfigChooser(paramEngine.getEngineOptions().getRenderOptions().isMultiSampling()); 
    setEGLConfigChooser(this.mConfigChooser);
    setOnTouchListener((View.OnTouchListener)paramEngine);
    this.mEngineRenderer = new EngineRenderer(paramEngine, this.mConfigChooser, paramIRendererListener);
    setRenderer(this.mEngineRenderer);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/view/RenderSurfaceView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */