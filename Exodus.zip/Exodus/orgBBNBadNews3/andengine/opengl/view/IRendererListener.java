package org.andengine.opengl.view;

import org.andengine.opengl.util.GLState;

public interface IRendererListener {
  void onSurfaceChanged(GLState paramGLState, int paramInt1, int paramInt2);
  
  void onSurfaceCreated(GLState paramGLState);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/view/IRendererListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */