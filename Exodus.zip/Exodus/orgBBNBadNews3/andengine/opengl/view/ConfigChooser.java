package org.andengine.opengl.view;

import android.opengl.GLSurfaceView;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLDisplay;

public class ConfigChooser implements GLSurfaceView.EGLConfigChooser {
  private static final int ALPHA_SIZE = 0;
  
  private static final int BLUE_SIZE = 5;
  
  private static final int[] BUFFER = new int[1];
  
  private static final int DEPTH_SIZE = 0;
  
  private static final int[] EGLCONFIG_ATTRIBUTES_COVERAGEMULTISAMPLE_NVIDIA;
  
  private static final int[] EGLCONFIG_ATTRIBUTES_FALLBACK;
  
  private static final int[] EGLCONFIG_ATTRIBUTES_MULTISAMPLE;
  
  private static final int EGL_COVERAGE_BUFFERS_NV = 12512;
  
  private static final int EGL_COVERAGE_SAMPLES_NV = 12513;
  
  private static final int EGL_GLES2_BIT = 4;
  
  private static final int GREEN_SIZE = 6;
  
  private static final int MULTISAMPLE_COUNT = 2;
  
  private static final int RED_SIZE = 5;
  
  private static final int STENCIL_SIZE = 0;
  
  private int mAlphaSize = -1;
  
  private int mBlueSize = -1;
  
  private boolean mCoverageMultiSampling;
  
  private int mDepthSize = -1;
  
  private int mGreenSize = -1;
  
  private boolean mMultiSampling;
  
  private final boolean mMultiSamplingRequested;
  
  private int mRedSize = -1;
  
  private int mStencilSize = -1;
  
  static {
    int[] arrayOfInt = new int[19];
    arrayOfInt[0] = 12324;
    arrayOfInt[1] = 5;
    arrayOfInt[2] = 12323;
    arrayOfInt[3] = 6;
    arrayOfInt[4] = 12322;
    arrayOfInt[5] = 5;
    arrayOfInt[6] = 12321;
    arrayOfInt[8] = 12325;
    arrayOfInt[10] = 12326;
    arrayOfInt[12] = 12352;
    arrayOfInt[13] = 4;
    arrayOfInt[14] = 12338;
    arrayOfInt[15] = 1;
    arrayOfInt[16] = 12337;
    arrayOfInt[17] = 2;
    arrayOfInt[18] = 12344;
    EGLCONFIG_ATTRIBUTES_MULTISAMPLE = arrayOfInt;
    arrayOfInt = new int[19];
    arrayOfInt[0] = 12324;
    arrayOfInt[1] = 5;
    arrayOfInt[2] = 12323;
    arrayOfInt[3] = 6;
    arrayOfInt[4] = 12322;
    arrayOfInt[5] = 5;
    arrayOfInt[6] = 12321;
    arrayOfInt[8] = 12325;
    arrayOfInt[10] = 12326;
    arrayOfInt[12] = 12352;
    arrayOfInt[13] = 4;
    arrayOfInt[14] = 12512;
    arrayOfInt[15] = 1;
    arrayOfInt[16] = 12513;
    arrayOfInt[17] = 2;
    arrayOfInt[18] = 12344;
    EGLCONFIG_ATTRIBUTES_COVERAGEMULTISAMPLE_NVIDIA = arrayOfInt;
    arrayOfInt = new int[15];
    arrayOfInt[0] = 12324;
    arrayOfInt[1] = 5;
    arrayOfInt[2] = 12323;
    arrayOfInt[3] = 6;
    arrayOfInt[4] = 12322;
    arrayOfInt[5] = 5;
    arrayOfInt[6] = 12321;
    arrayOfInt[8] = 12325;
    arrayOfInt[10] = 12326;
    arrayOfInt[12] = 12352;
    arrayOfInt[13] = 4;
    arrayOfInt[14] = 12344;
    EGLCONFIG_ATTRIBUTES_FALLBACK = arrayOfInt;
  }
  
  public ConfigChooser(boolean paramBoolean) {
    this.mMultiSamplingRequested = paramBoolean;
  }
  
  private EGLConfig chooseConfig(EGL10 paramEGL10, EGLDisplay paramEGLDisplay, ConfigChooserMatcher paramConfigChooserMatcher) throws IllegalArgumentException {
    BUFFER[0] = 0;
    if (this.mMultiSamplingRequested) {
      int j = getEGLConfigCount(paramEGL10, paramEGLDisplay, EGLCONFIG_ATTRIBUTES_MULTISAMPLE);
      if (j > 0) {
        this.mMultiSampling = true;
        return findEGLConfig(paramEGL10, paramEGLDisplay, EGLCONFIG_ATTRIBUTES_MULTISAMPLE, j, paramConfigChooserMatcher);
      } 
      j = getEGLConfigCount(paramEGL10, paramEGLDisplay, EGLCONFIG_ATTRIBUTES_COVERAGEMULTISAMPLE_NVIDIA);
      if (j > 0) {
        this.mCoverageMultiSampling = true;
        return findEGLConfig(paramEGL10, paramEGLDisplay, EGLCONFIG_ATTRIBUTES_COVERAGEMULTISAMPLE_NVIDIA, j, paramConfigChooserMatcher);
      } 
    } 
    int i = getEGLConfigCount(paramEGL10, paramEGLDisplay, EGLCONFIG_ATTRIBUTES_FALLBACK);
    if (i > 0)
      return findEGLConfig(paramEGL10, paramEGLDisplay, EGLCONFIG_ATTRIBUTES_FALLBACK, i, paramConfigChooserMatcher); 
    throw new IllegalArgumentException("No " + EGLConfig.class.getSimpleName() + " found!");
  }
  
  private EGLConfig findEGLConfig(EGL10 paramEGL10, EGLDisplay paramEGLDisplay, int[] paramArrayOfint, int paramInt, ConfigChooserMatcher paramConfigChooserMatcher) {
    EGLConfig[] arrayOfEGLConfig = new EGLConfig[paramInt];
    if (!paramEGL10.eglChooseConfig(paramEGLDisplay, paramArrayOfint, arrayOfEGLConfig, paramInt, BUFFER))
      throw new IllegalArgumentException("findEGLConfig failed!"); 
    return findEGLConfig(paramEGL10, paramEGLDisplay, arrayOfEGLConfig, paramConfigChooserMatcher);
  }
  
  private EGLConfig findEGLConfig(EGL10 paramEGL10, EGLDisplay paramEGLDisplay, EGLConfig[] paramArrayOfEGLConfig, ConfigChooserMatcher paramConfigChooserMatcher) {
    for (byte b = 0;; b++) {
      if (b >= paramArrayOfEGLConfig.length)
        throw new IllegalArgumentException("No EGLConfig found!"); 
      EGLConfig eGLConfig = paramArrayOfEGLConfig[b];
      if (eGLConfig != null) {
        int i = getConfigAttrib(paramEGL10, paramEGLDisplay, eGLConfig, 12324, 0);
        int j = getConfigAttrib(paramEGL10, paramEGLDisplay, eGLConfig, 12323, 0);
        int k = getConfigAttrib(paramEGL10, paramEGLDisplay, eGLConfig, 12322, 0);
        int m = getConfigAttrib(paramEGL10, paramEGLDisplay, eGLConfig, 12321, 0);
        int n = getConfigAttrib(paramEGL10, paramEGLDisplay, eGLConfig, 12325, 0);
        int i1 = getConfigAttrib(paramEGL10, paramEGLDisplay, eGLConfig, 12326, 0);
        if (paramConfigChooserMatcher.matches(i, j, k, m, n, i1)) {
          this.mRedSize = i;
          this.mGreenSize = j;
          this.mBlueSize = k;
          this.mAlphaSize = m;
          this.mDepthSize = n;
          this.mStencilSize = i1;
          return eGLConfig;
        } 
      } 
    } 
  }
  
  private static int getConfigAttrib(EGL10 paramEGL10, EGLDisplay paramEGLDisplay, EGLConfig paramEGLConfig, int paramInt1, int paramInt2) {
    if (paramEGL10.eglGetConfigAttrib(paramEGLDisplay, paramEGLConfig, paramInt1, BUFFER))
      paramInt2 = BUFFER[0]; 
    return paramInt2;
  }
  
  private static int getEGLConfigCount(EGL10 paramEGL10, EGLDisplay paramEGLDisplay, int[] paramArrayOfint) {
    if (!paramEGL10.eglChooseConfig(paramEGLDisplay, paramArrayOfint, null, 0, BUFFER))
      throw new IllegalArgumentException("EGLCONFIG_FALLBACK failed!"); 
    return BUFFER[0];
  }
  
  public EGLConfig chooseConfig(EGL10 paramEGL10, EGLDisplay paramEGLDisplay) {
    EGLConfig eGLConfig;
    try {
      EGLConfig eGLConfig1 = chooseConfig(paramEGL10, paramEGLDisplay, ConfigChooserMatcher.STRICT);
      eGLConfig = eGLConfig1;
    } catch (IllegalArgumentException illegalArgumentException) {}
    return eGLConfig;
  }
  
  public int getAlphaSize() {
    return this.mAlphaSize;
  }
  
  public int getBlueSize() {
    return this.mBlueSize;
  }
  
  public int getDepthSize() {
    return this.mDepthSize;
  }
  
  public int getGreenSize() {
    return this.mGreenSize;
  }
  
  public int getRedSize() {
    return this.mRedSize;
  }
  
  public int getStencilSize() {
    return this.mStencilSize;
  }
  
  public boolean isCoverageMultiSampling() {
    return this.mCoverageMultiSampling;
  }
  
  public boolean isMultiSampling() {
    return this.mMultiSampling;
  }
  
  public enum ConfigChooserMatcher {
    ANY,
    LOOSE_DEPTH_AND_STENCIL,
    LOOSE_STENCIL,
    STRICT {
      public boolean matches(int param2Int1, int param2Int2, int param2Int3, int param2Int4, int param2Int5, int param2Int6) {
        return (param2Int5 == 0 && param2Int6 == 0 && param2Int1 == 5 && param2Int2 == 6 && param2Int3 == 5 && param2Int4 == 0);
      }
    };
    
    static {
      LOOSE_DEPTH_AND_STENCIL = new null("LOOSE_DEPTH_AND_STENCIL", 2);
      ANY = new null("ANY", 3);
      ENUM$VALUES = new ConfigChooserMatcher[] { STRICT, LOOSE_STENCIL, LOOSE_DEPTH_AND_STENCIL, ANY };
    }
    
    public abstract boolean matches(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6);
  }
  
  enum null {
    public boolean matches(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      return (param1Int5 == 0 && param1Int6 == 0 && param1Int1 == 5 && param1Int2 == 6 && param1Int3 == 5 && param1Int4 == 0);
    }
  }
  
  enum null {
    public boolean matches(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      return (param1Int5 == 0 && param1Int6 >= 0 && param1Int1 == 5 && param1Int2 == 6 && param1Int3 == 5 && param1Int4 == 0);
    }
  }
  
  enum null {
    public boolean matches(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      return (param1Int5 >= 0 && param1Int6 >= 0 && param1Int1 == 5 && param1Int2 == 6 && param1Int3 == 5 && param1Int4 == 0);
    }
  }
  
  enum null {
    public boolean matches(int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      return true;
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/view/ConfigChooser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */