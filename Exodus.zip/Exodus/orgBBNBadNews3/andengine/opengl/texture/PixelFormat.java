package org.andengine.opengl.texture;

public enum PixelFormat {
  AI_88,
  A_8,
  I_8,
  RGBA_4444,
  RGBA_5551,
  RGBA_8888,
  RGB_565,
  UNDEFINED(-1, -1, -1, -1);
  
  private final int mBitsPerPixel;
  
  private final int mGLFormat;
  
  private final int mGLInternalFormat;
  
  private final int mGLType;
  
  static {
    RGBA_4444 = new PixelFormat("RGBA_4444", 1, 6408, 6408, 32819, 16);
    RGBA_5551 = new PixelFormat("RGBA_5551", 2, 6407, 6408, 32820, 16);
    RGBA_8888 = new PixelFormat("RGBA_8888", 3, 6408, 6408, 5121, 32);
    RGB_565 = new PixelFormat("RGB_565", 4, 6407, 6407, 33635, 16);
    A_8 = new PixelFormat("A_8", 5, 6406, 6406, 5121, 8);
    I_8 = new PixelFormat("I_8", 6, 6409, 6409, 5121, 8);
    AI_88 = new PixelFormat("AI_88", 7, 6410, 6410, 5121, 16);
    ENUM$VALUES = new PixelFormat[] { UNDEFINED, RGBA_4444, RGBA_5551, RGBA_8888, RGB_565, A_8, I_8, AI_88 };
  }
  
  PixelFormat(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mGLInternalFormat = paramInt1;
    this.mGLFormat = paramInt2;
    this.mGLType = paramInt3;
    this.mBitsPerPixel = paramInt4;
  }
  
  public int getBitsPerPixel() {
    return this.mBitsPerPixel;
  }
  
  public int getGLFormat() {
    return this.mGLFormat;
  }
  
  public int getGLInternalFormat() {
    return this.mGLInternalFormat;
  }
  
  public int getGLType() {
    return this.mGLType;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/PixelFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */