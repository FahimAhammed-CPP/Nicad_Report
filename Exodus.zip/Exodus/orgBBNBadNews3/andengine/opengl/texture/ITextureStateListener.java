package org.andengine.opengl.texture;

public interface ITextureStateListener {
  void onLoadedToHardware(ITexture paramITexture);
  
  void onUnloadedFromHardware(ITexture paramITexture);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/ITextureStateListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */