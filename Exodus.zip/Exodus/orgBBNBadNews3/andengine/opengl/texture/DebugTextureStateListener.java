package org.andengine.opengl.texture;

import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.util.debug.Debug;

public class DebugTextureStateListener<T extends ITextureAtlasSource> implements ITextureStateListener {
  public void onLoadedToHardware(ITexture paramITexture) {
    Debug.d("Texture loaded: " + paramITexture.toString());
  }
  
  public void onUnloadedFromHardware(ITexture paramITexture) {
    Debug.d("Texture unloaded: " + paramITexture.toString());
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/DebugTextureStateListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */