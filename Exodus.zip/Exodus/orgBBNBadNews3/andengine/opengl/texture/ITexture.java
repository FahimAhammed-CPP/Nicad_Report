package org.andengine.opengl.texture;

import java.io.IOException;
import org.andengine.opengl.util.GLState;

public interface ITexture {
  void bind(GLState paramGLState);
  
  void bind(GLState paramGLState, int paramInt);
  
  int getHardwareTextureID();
  
  int getHeight();
  
  PixelFormat getPixelFormat();
  
  TextureOptions getTextureOptions();
  
  ITextureStateListener getTextureStateListener();
  
  int getWidth();
  
  boolean hasTextureStateListener();
  
  boolean isLoadedToHardware();
  
  boolean isUpdateOnHardwareNeeded();
  
  void load();
  
  void load(GLState paramGLState) throws IOException;
  
  void loadToHardware(GLState paramGLState) throws IOException;
  
  void reloadToHardware(GLState paramGLState) throws IOException;
  
  void setNotLoadedToHardware();
  
  void setTextureStateListener(ITextureStateListener paramITextureStateListener);
  
  void setUpdateOnHardwareNeeded(boolean paramBoolean);
  
  void unload();
  
  void unload(GLState paramGLState);
  
  void unloadFromHardware(GLState paramGLState);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/ITexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */