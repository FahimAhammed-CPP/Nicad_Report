package org.andengine.opengl.texture;

import android.content.res.AssetManager;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import org.andengine.opengl.texture.bitmap.BitmapTextureFormat;
import org.andengine.opengl.util.GLState;
import org.andengine.util.adt.io.in.IInputStreamOpener;

public class TextureManager {
  private TextureWarmUpVertexBufferObject mTextureWarmUpVertexBufferObject;
  
  private final ArrayList<ITexture> mTexturesLoaded = new ArrayList<ITexture>();
  
  private final HashSet<ITexture> mTexturesManaged = new HashSet<ITexture>();
  
  private final HashMap<String, ITexture> mTexturesMapped = new HashMap<String, ITexture>();
  
  private final ArrayList<ITexture> mTexturesToBeLoaded = new ArrayList<ITexture>();
  
  private final ArrayList<ITexture> mTexturesToBeUnloaded = new ArrayList<ITexture>();
  
  public void addMappedTexture(String paramString, ITexture paramITexture) throws IllegalArgumentException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 23
    //   6: new java/lang/IllegalArgumentException
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'pID must not be null!'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: aload_1
    //   17: athrow
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    //   23: aload_2
    //   24: ifnonnull -> 39
    //   27: new java/lang/IllegalArgumentException
    //   30: astore_1
    //   31: aload_1
    //   32: ldc 'pTexture must not be null!'
    //   34: invokespecial <init> : (Ljava/lang/String;)V
    //   37: aload_1
    //   38: athrow
    //   39: aload_0
    //   40: getfield mTexturesMapped : Ljava/util/HashMap;
    //   43: aload_1
    //   44: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   47: ifeq -> 83
    //   50: new java/lang/IllegalArgumentException
    //   53: astore_2
    //   54: new java/lang/StringBuilder
    //   57: astore_3
    //   58: aload_3
    //   59: ldc 'Collision for pID: ''
    //   61: invokespecial <init> : (Ljava/lang/String;)V
    //   64: aload_2
    //   65: aload_3
    //   66: aload_1
    //   67: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   70: ldc ''.'
    //   72: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   75: invokevirtual toString : ()Ljava/lang/String;
    //   78: invokespecial <init> : (Ljava/lang/String;)V
    //   81: aload_2
    //   82: athrow
    //   83: aload_0
    //   84: getfield mTexturesMapped : Ljava/util/HashMap;
    //   87: aload_1
    //   88: aload_2
    //   89: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   92: pop
    //   93: aload_0
    //   94: monitorexit
    //   95: return
    // Exception table:
    //   from	to	target	type
    //   6	18	18	finally
    //   27	39	18	finally
    //   39	83	18	finally
    //   83	93	18	finally
  }
  
  public ITexture getMappedTexture(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 23
    //   6: new java/lang/IllegalArgumentException
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'pID must not be null!'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: aload_1
    //   17: athrow
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    //   23: aload_0
    //   24: getfield mTexturesMapped : Ljava/util/HashMap;
    //   27: aload_1
    //   28: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   31: checkcast org/andengine/opengl/texture/ITexture
    //   34: astore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: aload_1
    //   38: areturn
    // Exception table:
    //   from	to	target	type
    //   6	18	18	finally
    //   23	35	18	finally
  }
  
  public ITexture getTexture(String paramString1, AssetManager paramAssetManager, String paramString2) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: aload_2
    //   5: aload_3
    //   6: getstatic org/andengine/opengl/texture/TextureOptions.DEFAULT : Lorg/andengine/opengl/texture/TextureOptions;
    //   9: invokevirtual getTexture : (Ljava/lang/String;Landroid/content/res/AssetManager;Ljava/lang/String;Lorg/andengine/opengl/texture/TextureOptions;)Lorg/andengine/opengl/texture/ITexture;
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: areturn
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	17	finally
  }
  
  public ITexture getTexture(String paramString1, AssetManager paramAssetManager, String paramString2, TextureOptions paramTextureOptions) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokevirtual hasMappedTexture : (Ljava/lang/String;)Z
    //   7: ifeq -> 20
    //   10: aload_0
    //   11: aload_1
    //   12: invokevirtual getMappedTexture : (Ljava/lang/String;)Lorg/andengine/opengl/texture/ITexture;
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: areturn
    //   20: new org/andengine/opengl/texture/bitmap/BitmapTexture
    //   23: astore #5
    //   25: new org/andengine/util/adt/io/in/AssetInputStreamOpener
    //   28: astore #6
    //   30: aload #6
    //   32: aload_2
    //   33: aload_3
    //   34: invokespecial <init> : (Landroid/content/res/AssetManager;Ljava/lang/String;)V
    //   37: aload #5
    //   39: aload_0
    //   40: aload #6
    //   42: aload #4
    //   44: invokespecial <init> : (Lorg/andengine/opengl/texture/TextureManager;Lorg/andengine/util/adt/io/in/IInputStreamOpener;Lorg/andengine/opengl/texture/TextureOptions;)V
    //   47: aload_0
    //   48: aload #5
    //   50: invokevirtual loadTexture : (Lorg/andengine/opengl/texture/ITexture;)Z
    //   53: pop
    //   54: aload_0
    //   55: aload_1
    //   56: aload #5
    //   58: invokevirtual addMappedTexture : (Ljava/lang/String;Lorg/andengine/opengl/texture/ITexture;)V
    //   61: aload #5
    //   63: astore_1
    //   64: goto -> 16
    //   67: astore_1
    //   68: aload_0
    //   69: monitorexit
    //   70: aload_1
    //   71: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	67	finally
    //   20	61	67	finally
  }
  
  public ITexture getTexture(String paramString, IInputStreamOpener paramIInputStreamOpener) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: aload_2
    //   5: getstatic org/andengine/opengl/texture/TextureOptions.DEFAULT : Lorg/andengine/opengl/texture/TextureOptions;
    //   8: invokevirtual getTexture : (Ljava/lang/String;Lorg/andengine/util/adt/io/in/IInputStreamOpener;Lorg/andengine/opengl/texture/TextureOptions;)Lorg/andengine/opengl/texture/ITexture;
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: areturn
    //   16: astore_1
    //   17: aload_0
    //   18: monitorexit
    //   19: aload_1
    //   20: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	16	finally
  }
  
  public ITexture getTexture(String paramString, IInputStreamOpener paramIInputStreamOpener, TextureOptions paramTextureOptions) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: aload_2
    //   5: getstatic org/andengine/opengl/texture/bitmap/BitmapTextureFormat.RGBA_8888 : Lorg/andengine/opengl/texture/bitmap/BitmapTextureFormat;
    //   8: aload_3
    //   9: invokevirtual getTexture : (Ljava/lang/String;Lorg/andengine/util/adt/io/in/IInputStreamOpener;Lorg/andengine/opengl/texture/bitmap/BitmapTextureFormat;Lorg/andengine/opengl/texture/TextureOptions;)Lorg/andengine/opengl/texture/ITexture;
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: areturn
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	17	finally
  }
  
  public ITexture getTexture(String paramString, IInputStreamOpener paramIInputStreamOpener, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: aload_2
    //   5: aload_3
    //   6: aload #4
    //   8: iconst_1
    //   9: invokevirtual getTexture : (Ljava/lang/String;Lorg/andengine/util/adt/io/in/IInputStreamOpener;Lorg/andengine/opengl/texture/bitmap/BitmapTextureFormat;Lorg/andengine/opengl/texture/TextureOptions;Z)Lorg/andengine/opengl/texture/ITexture;
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: areturn
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: athrow
    // Exception table:
    //   from	to	target	type
    //   2	13	17	finally
  }
  
  public ITexture getTexture(String paramString, IInputStreamOpener paramIInputStreamOpener, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions, boolean paramBoolean) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: aload_1
    //   4: invokevirtual hasMappedTexture : (Ljava/lang/String;)Z
    //   7: ifeq -> 20
    //   10: aload_0
    //   11: aload_1
    //   12: invokevirtual getMappedTexture : (Ljava/lang/String;)Lorg/andengine/opengl/texture/ITexture;
    //   15: astore_1
    //   16: aload_0
    //   17: monitorexit
    //   18: aload_1
    //   19: areturn
    //   20: new org/andengine/opengl/texture/bitmap/BitmapTexture
    //   23: astore #6
    //   25: aload #6
    //   27: aload_0
    //   28: aload_2
    //   29: aload_3
    //   30: aload #4
    //   32: invokespecial <init> : (Lorg/andengine/opengl/texture/TextureManager;Lorg/andengine/util/adt/io/in/IInputStreamOpener;Lorg/andengine/opengl/texture/bitmap/BitmapTextureFormat;Lorg/andengine/opengl/texture/TextureOptions;)V
    //   35: iload #5
    //   37: ifeq -> 47
    //   40: aload_0
    //   41: aload #6
    //   43: invokevirtual loadTexture : (Lorg/andengine/opengl/texture/ITexture;)Z
    //   46: pop
    //   47: aload_0
    //   48: aload_1
    //   49: aload #6
    //   51: invokevirtual addMappedTexture : (Ljava/lang/String;Lorg/andengine/opengl/texture/ITexture;)V
    //   54: aload #6
    //   56: astore_1
    //   57: goto -> 16
    //   60: astore_1
    //   61: aload_0
    //   62: monitorexit
    //   63: aload_1
    //   64: athrow
    // Exception table:
    //   from	to	target	type
    //   2	16	60	finally
    //   20	35	60	finally
    //   40	47	60	finally
    //   47	54	60	finally
  }
  
  public boolean hasMappedTexture(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 23
    //   6: new java/lang/IllegalArgumentException
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'pID must not be null!'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: aload_1
    //   17: athrow
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    //   23: aload_0
    //   24: getfield mTexturesMapped : Ljava/util/HashMap;
    //   27: aload_1
    //   28: invokevirtual containsKey : (Ljava/lang/Object;)Z
    //   31: istore_2
    //   32: aload_0
    //   33: monitorexit
    //   34: iload_2
    //   35: ireturn
    // Exception table:
    //   from	to	target	type
    //   6	18	18	finally
    //   23	32	18	finally
  }
  
  public boolean loadTexture(ITexture paramITexture) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 23
    //   6: new java/lang/IllegalArgumentException
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'pTexture must not be null!'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: aload_1
    //   17: athrow
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    //   23: aload_0
    //   24: getfield mTexturesManaged : Ljava/util/HashSet;
    //   27: aload_1
    //   28: invokevirtual contains : (Ljava/lang/Object;)Z
    //   31: ifeq -> 49
    //   34: aload_0
    //   35: getfield mTexturesToBeUnloaded : Ljava/util/ArrayList;
    //   38: aload_1
    //   39: invokevirtual remove : (Ljava/lang/Object;)Z
    //   42: pop
    //   43: iconst_0
    //   44: istore_2
    //   45: aload_0
    //   46: monitorexit
    //   47: iload_2
    //   48: ireturn
    //   49: aload_0
    //   50: getfield mTexturesManaged : Ljava/util/HashSet;
    //   53: aload_1
    //   54: invokevirtual add : (Ljava/lang/Object;)Z
    //   57: pop
    //   58: aload_0
    //   59: getfield mTexturesToBeLoaded : Ljava/util/ArrayList;
    //   62: aload_1
    //   63: invokevirtual add : (Ljava/lang/Object;)Z
    //   66: pop
    //   67: iconst_1
    //   68: istore_2
    //   69: goto -> 45
    // Exception table:
    //   from	to	target	type
    //   6	18	18	finally
    //   23	43	18	finally
    //   49	67	18	finally
  }
  
  public boolean loadTexture(GLState paramGLState, ITexture paramITexture) throws IOException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_2
    //   3: ifnonnull -> 23
    //   6: new java/lang/IllegalArgumentException
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'pTexture must not be null!'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: aload_1
    //   17: athrow
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    //   23: aload_2
    //   24: invokeinterface isLoadedToHardware : ()Z
    //   29: ifne -> 65
    //   32: aload_2
    //   33: aload_1
    //   34: invokeinterface loadToHardware : (Lorg/andengine/opengl/util/GLState;)V
    //   39: aload_0
    //   40: getfield mTexturesManaged : Ljava/util/HashSet;
    //   43: aload_2
    //   44: invokevirtual contains : (Ljava/lang/Object;)Z
    //   47: ifeq -> 84
    //   50: aload_0
    //   51: getfield mTexturesToBeUnloaded : Ljava/util/ArrayList;
    //   54: aload_2
    //   55: invokevirtual remove : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: iconst_0
    //   60: istore_3
    //   61: aload_0
    //   62: monitorexit
    //   63: iload_3
    //   64: ireturn
    //   65: aload_2
    //   66: invokeinterface isUpdateOnHardwareNeeded : ()Z
    //   71: ifeq -> 39
    //   74: aload_2
    //   75: aload_1
    //   76: invokeinterface reloadToHardware : (Lorg/andengine/opengl/util/GLState;)V
    //   81: goto -> 39
    //   84: aload_0
    //   85: getfield mTexturesManaged : Ljava/util/HashSet;
    //   88: aload_2
    //   89: invokevirtual add : (Ljava/lang/Object;)Z
    //   92: pop
    //   93: aload_0
    //   94: getfield mTexturesLoaded : Ljava/util/ArrayList;
    //   97: aload_2
    //   98: invokevirtual add : (Ljava/lang/Object;)Z
    //   101: pop
    //   102: iconst_1
    //   103: istore_3
    //   104: goto -> 61
    // Exception table:
    //   from	to	target	type
    //   6	18	18	finally
    //   23	39	18	finally
    //   39	59	18	finally
    //   65	81	18	finally
    //   84	102	18	finally
  }
  
  public void onCreate() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new org/andengine/opengl/texture/TextureWarmUpVertexBufferObject
    //   5: astore_1
    //   6: aload_1
    //   7: invokespecial <init> : ()V
    //   10: aload_0
    //   11: aload_1
    //   12: putfield mTextureWarmUpVertexBufferObject : Lorg/andengine/opengl/texture/TextureWarmUpVertexBufferObject;
    //   15: aload_0
    //   16: monitorexit
    //   17: return
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	15	18	finally
  }
  
  public void onDestroy() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mTexturesManaged : Ljava/util/HashSet;
    //   6: invokevirtual iterator : ()Ljava/util/Iterator;
    //   9: astore_1
    //   10: aload_1
    //   11: invokeinterface hasNext : ()Z
    //   16: ifne -> 62
    //   19: aload_0
    //   20: getfield mTexturesToBeLoaded : Ljava/util/ArrayList;
    //   23: invokevirtual clear : ()V
    //   26: aload_0
    //   27: getfield mTexturesLoaded : Ljava/util/ArrayList;
    //   30: invokevirtual clear : ()V
    //   33: aload_0
    //   34: getfield mTexturesManaged : Ljava/util/HashSet;
    //   37: invokevirtual clear : ()V
    //   40: aload_0
    //   41: getfield mTexturesMapped : Ljava/util/HashMap;
    //   44: invokevirtual clear : ()V
    //   47: aload_0
    //   48: getfield mTextureWarmUpVertexBufferObject : Lorg/andengine/opengl/texture/TextureWarmUpVertexBufferObject;
    //   51: invokevirtual dispose : ()V
    //   54: aload_0
    //   55: aconst_null
    //   56: putfield mTextureWarmUpVertexBufferObject : Lorg/andengine/opengl/texture/TextureWarmUpVertexBufferObject;
    //   59: aload_0
    //   60: monitorexit
    //   61: return
    //   62: aload_1
    //   63: invokeinterface next : ()Ljava/lang/Object;
    //   68: checkcast org/andengine/opengl/texture/ITexture
    //   71: invokeinterface setNotLoadedToHardware : ()V
    //   76: goto -> 10
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   2	10	79	finally
    //   10	59	79	finally
    //   62	76	79	finally
  }
  
  public void onReload() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mTexturesManaged : Ljava/util/HashSet;
    //   6: astore_1
    //   7: aload_1
    //   8: invokevirtual isEmpty : ()Z
    //   11: ifne -> 28
    //   14: aload_1
    //   15: invokevirtual iterator : ()Ljava/util/Iterator;
    //   18: astore_1
    //   19: aload_1
    //   20: invokeinterface hasNext : ()Z
    //   25: ifne -> 96
    //   28: aload_0
    //   29: getfield mTexturesLoaded : Ljava/util/ArrayList;
    //   32: invokevirtual isEmpty : ()Z
    //   35: ifne -> 57
    //   38: aload_0
    //   39: getfield mTexturesToBeLoaded : Ljava/util/ArrayList;
    //   42: aload_0
    //   43: getfield mTexturesLoaded : Ljava/util/ArrayList;
    //   46: invokevirtual addAll : (Ljava/util/Collection;)Z
    //   49: pop
    //   50: aload_0
    //   51: getfield mTexturesLoaded : Ljava/util/ArrayList;
    //   54: invokevirtual clear : ()V
    //   57: aload_0
    //   58: getfield mTexturesToBeUnloaded : Ljava/util/ArrayList;
    //   61: invokevirtual isEmpty : ()Z
    //   64: ifne -> 86
    //   67: aload_0
    //   68: getfield mTexturesManaged : Ljava/util/HashSet;
    //   71: aload_0
    //   72: getfield mTexturesToBeUnloaded : Ljava/util/ArrayList;
    //   75: invokevirtual removeAll : (Ljava/util/Collection;)Z
    //   78: pop
    //   79: aload_0
    //   80: getfield mTexturesToBeUnloaded : Ljava/util/ArrayList;
    //   83: invokevirtual clear : ()V
    //   86: aload_0
    //   87: getfield mTextureWarmUpVertexBufferObject : Lorg/andengine/opengl/texture/TextureWarmUpVertexBufferObject;
    //   90: invokevirtual setNotLoadedToHardware : ()V
    //   93: aload_0
    //   94: monitorexit
    //   95: return
    //   96: aload_1
    //   97: invokeinterface next : ()Ljava/lang/Object;
    //   102: checkcast org/andengine/opengl/texture/ITexture
    //   105: invokeinterface setNotLoadedToHardware : ()V
    //   110: goto -> 19
    //   113: astore_1
    //   114: aload_0
    //   115: monitorexit
    //   116: aload_1
    //   117: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	113	finally
    //   19	28	113	finally
    //   28	57	113	finally
    //   57	86	113	finally
    //   86	93	113	finally
    //   96	110	113	finally
  }
  
  public ITexture removedMappedTexture(String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 23
    //   6: new java/lang/IllegalArgumentException
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'pID must not be null!'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: aload_1
    //   17: athrow
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    //   23: aload_0
    //   24: getfield mTexturesMapped : Ljava/util/HashMap;
    //   27: aload_1
    //   28: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   31: checkcast org/andengine/opengl/texture/ITexture
    //   34: astore_1
    //   35: aload_0
    //   36: monitorexit
    //   37: aload_1
    //   38: areturn
    // Exception table:
    //   from	to	target	type
    //   6	18	18	finally
    //   23	35	18	finally
  }
  
  public boolean unloadTexture(ITexture paramITexture) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 23
    //   6: new java/lang/IllegalArgumentException
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'pTexture must not be null!'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: aload_1
    //   17: athrow
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    //   23: aload_0
    //   24: getfield mTexturesManaged : Ljava/util/HashSet;
    //   27: aload_1
    //   28: invokevirtual contains : (Ljava/lang/Object;)Z
    //   31: ifeq -> 83
    //   34: aload_0
    //   35: getfield mTexturesLoaded : Ljava/util/ArrayList;
    //   38: aload_1
    //   39: invokevirtual contains : (Ljava/lang/Object;)Z
    //   42: ifeq -> 60
    //   45: aload_0
    //   46: getfield mTexturesToBeUnloaded : Ljava/util/ArrayList;
    //   49: aload_1
    //   50: invokevirtual add : (Ljava/lang/Object;)Z
    //   53: pop
    //   54: iconst_1
    //   55: istore_2
    //   56: aload_0
    //   57: monitorexit
    //   58: iload_2
    //   59: ireturn
    //   60: aload_0
    //   61: getfield mTexturesToBeLoaded : Ljava/util/ArrayList;
    //   64: aload_1
    //   65: invokevirtual remove : (Ljava/lang/Object;)Z
    //   68: ifeq -> 54
    //   71: aload_0
    //   72: getfield mTexturesManaged : Ljava/util/HashSet;
    //   75: aload_1
    //   76: invokevirtual remove : (Ljava/lang/Object;)Z
    //   79: pop
    //   80: goto -> 54
    //   83: iconst_0
    //   84: istore_2
    //   85: goto -> 56
    // Exception table:
    //   from	to	target	type
    //   6	18	18	finally
    //   23	54	18	finally
    //   60	80	18	finally
  }
  
  public boolean unloadTexture(GLState paramGLState, ITexture paramITexture) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_2
    //   3: ifnonnull -> 23
    //   6: new java/lang/IllegalArgumentException
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'pTexture must not be null!'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: aload_1
    //   17: athrow
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    //   23: aload_2
    //   24: invokeinterface isLoadedToHardware : ()Z
    //   29: ifeq -> 39
    //   32: aload_2
    //   33: aload_1
    //   34: invokeinterface unloadFromHardware : (Lorg/andengine/opengl/util/GLState;)V
    //   39: aload_0
    //   40: getfield mTexturesManaged : Ljava/util/HashSet;
    //   43: aload_2
    //   44: invokevirtual contains : (Ljava/lang/Object;)Z
    //   47: ifeq -> 74
    //   50: aload_0
    //   51: getfield mTexturesLoaded : Ljava/util/ArrayList;
    //   54: aload_2
    //   55: invokevirtual remove : (Ljava/lang/Object;)Z
    //   58: pop
    //   59: aload_0
    //   60: getfield mTexturesToBeLoaded : Ljava/util/ArrayList;
    //   63: aload_2
    //   64: invokevirtual remove : (Ljava/lang/Object;)Z
    //   67: pop
    //   68: iconst_1
    //   69: istore_3
    //   70: aload_0
    //   71: monitorexit
    //   72: iload_3
    //   73: ireturn
    //   74: iconst_0
    //   75: istore_3
    //   76: goto -> 70
    // Exception table:
    //   from	to	target	type
    //   6	18	18	finally
    //   23	39	18	finally
    //   39	68	18	finally
  }
  
  public void updateTextures(GLState paramGLState) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mTexturesManaged : Ljava/util/HashSet;
    //   6: astore_2
    //   7: aload_0
    //   8: getfield mTexturesLoaded : Ljava/util/ArrayList;
    //   11: astore_3
    //   12: aload_0
    //   13: getfield mTexturesToBeLoaded : Ljava/util/ArrayList;
    //   16: astore #4
    //   18: aload_0
    //   19: getfield mTexturesToBeUnloaded : Ljava/util/ArrayList;
    //   22: astore #5
    //   24: aload_3
    //   25: invokevirtual size : ()I
    //   28: iconst_1
    //   29: isub
    //   30: istore #6
    //   32: iload #6
    //   34: ifge -> 99
    //   37: aload #4
    //   39: invokevirtual size : ()I
    //   42: istore #7
    //   44: iload #7
    //   46: ifle -> 60
    //   49: iload #7
    //   51: iconst_1
    //   52: isub
    //   53: istore #6
    //   55: iload #6
    //   57: ifge -> 153
    //   60: aload #5
    //   62: invokevirtual size : ()I
    //   65: istore #8
    //   67: iload #8
    //   69: ifle -> 83
    //   72: iload #8
    //   74: iconst_1
    //   75: isub
    //   76: istore #6
    //   78: iload #6
    //   80: ifge -> 220
    //   83: iload #7
    //   85: ifgt -> 93
    //   88: iload #8
    //   90: ifle -> 96
    //   93: invokestatic gc : ()V
    //   96: aload_0
    //   97: monitorexit
    //   98: return
    //   99: aload_3
    //   100: iload #6
    //   102: invokevirtual get : (I)Ljava/lang/Object;
    //   105: checkcast org/andengine/opengl/texture/ITexture
    //   108: astore #9
    //   110: aload #9
    //   112: invokeinterface isUpdateOnHardwareNeeded : ()Z
    //   117: istore #10
    //   119: iload #10
    //   121: ifeq -> 132
    //   124: aload #9
    //   126: aload_1
    //   127: invokeinterface reloadToHardware : (Lorg/andengine/opengl/util/GLState;)V
    //   132: iinc #6, -1
    //   135: goto -> 32
    //   138: astore #9
    //   140: aload #9
    //   142: invokestatic e : (Ljava/lang/Throwable;)V
    //   145: goto -> 132
    //   148: astore_1
    //   149: aload_0
    //   150: monitorexit
    //   151: aload_1
    //   152: athrow
    //   153: aload #4
    //   155: iload #6
    //   157: invokevirtual remove : (I)Ljava/lang/Object;
    //   160: checkcast org/andengine/opengl/texture/ITexture
    //   163: astore #11
    //   165: aload #11
    //   167: invokeinterface isLoadedToHardware : ()Z
    //   172: istore #10
    //   174: iload #10
    //   176: ifne -> 197
    //   179: aload #11
    //   181: aload_1
    //   182: invokeinterface loadToHardware : (Lorg/andengine/opengl/util/GLState;)V
    //   187: aload_0
    //   188: getfield mTextureWarmUpVertexBufferObject : Lorg/andengine/opengl/texture/TextureWarmUpVertexBufferObject;
    //   191: aload_1
    //   192: aload #11
    //   194: invokevirtual warmup : (Lorg/andengine/opengl/util/GLState;Lorg/andengine/opengl/texture/ITexture;)V
    //   197: aload_3
    //   198: aload #11
    //   200: invokevirtual add : (Ljava/lang/Object;)Z
    //   203: pop
    //   204: iinc #6, -1
    //   207: goto -> 55
    //   210: astore #9
    //   212: aload #9
    //   214: invokestatic e : (Ljava/lang/Throwable;)V
    //   217: goto -> 197
    //   220: aload #5
    //   222: iload #6
    //   224: invokevirtual remove : (I)Ljava/lang/Object;
    //   227: checkcast org/andengine/opengl/texture/ITexture
    //   230: astore #4
    //   232: aload #4
    //   234: invokeinterface isLoadedToHardware : ()Z
    //   239: ifeq -> 250
    //   242: aload #4
    //   244: aload_1
    //   245: invokeinterface unloadFromHardware : (Lorg/andengine/opengl/util/GLState;)V
    //   250: aload_3
    //   251: aload #4
    //   253: invokevirtual remove : (Ljava/lang/Object;)Z
    //   256: pop
    //   257: aload_2
    //   258: aload #4
    //   260: invokevirtual remove : (Ljava/lang/Object;)Z
    //   263: pop
    //   264: iinc #6, -1
    //   267: goto -> 78
    // Exception table:
    //   from	to	target	type
    //   2	32	148	finally
    //   37	44	148	finally
    //   60	67	148	finally
    //   93	96	148	finally
    //   99	119	148	finally
    //   124	132	138	java/io/IOException
    //   124	132	148	finally
    //   140	145	148	finally
    //   153	174	148	finally
    //   179	197	210	java/io/IOException
    //   179	197	148	finally
    //   197	204	148	finally
    //   212	217	148	finally
    //   220	250	148	finally
    //   250	264	148	finally
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/TextureManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */