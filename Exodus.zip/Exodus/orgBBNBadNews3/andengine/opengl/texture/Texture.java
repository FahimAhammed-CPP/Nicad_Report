package org.andengine.opengl.texture;

import java.io.IOException;
import org.andengine.opengl.util.GLState;

public abstract class Texture implements ITexture {
  public static final int HARDWARE_TEXTURE_ID_INVALID = -1;
  
  protected int mHardwareTextureID = -1;
  
  protected final PixelFormat mPixelFormat;
  
  protected final TextureManager mTextureManager;
  
  protected final TextureOptions mTextureOptions;
  
  protected ITextureStateListener mTextureStateListener;
  
  protected boolean mUpdateOnHardwareNeeded = false;
  
  public Texture(TextureManager paramTextureManager, PixelFormat paramPixelFormat, TextureOptions paramTextureOptions, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException {
    this.mTextureManager = paramTextureManager;
    this.mPixelFormat = paramPixelFormat;
    this.mTextureOptions = paramTextureOptions;
    this.mTextureStateListener = paramITextureStateListener;
  }
  
  public void bind(GLState paramGLState) {
    paramGLState.bindTexture(this.mHardwareTextureID);
  }
  
  public void bind(GLState paramGLState, int paramInt) {
    paramGLState.activeTexture(paramInt);
    paramGLState.bindTexture(this.mHardwareTextureID);
  }
  
  public int getHardwareTextureID() {
    return this.mHardwareTextureID;
  }
  
  public PixelFormat getPixelFormat() {
    return this.mPixelFormat;
  }
  
  public TextureOptions getTextureOptions() {
    return this.mTextureOptions;
  }
  
  public ITextureStateListener getTextureStateListener() {
    return this.mTextureStateListener;
  }
  
  public boolean hasTextureStateListener() {
    return (this.mTextureStateListener != null);
  }
  
  public boolean isLoadedToHardware() {
    return (this.mHardwareTextureID != -1);
  }
  
  public boolean isUpdateOnHardwareNeeded() {
    return this.mUpdateOnHardwareNeeded;
  }
  
  public void load() {
    this.mTextureManager.loadTexture(this);
  }
  
  public void load(GLState paramGLState) throws IOException {
    this.mTextureManager.loadTexture(paramGLState, this);
  }
  
  public void loadToHardware(GLState paramGLState) throws IOException {
    this.mHardwareTextureID = paramGLState.generateTexture();
    paramGLState.bindTexture(this.mHardwareTextureID);
    writeTextureToHardware(paramGLState);
    this.mTextureOptions.apply();
    this.mUpdateOnHardwareNeeded = false;
    if (this.mTextureStateListener != null)
      this.mTextureStateListener.onLoadedToHardware(this); 
  }
  
  public void reloadToHardware(GLState paramGLState) throws IOException {
    unloadFromHardware(paramGLState);
    loadToHardware(paramGLState);
  }
  
  public void setNotLoadedToHardware() {
    this.mHardwareTextureID = -1;
  }
  
  public void setTextureStateListener(ITextureStateListener paramITextureStateListener) {
    this.mTextureStateListener = paramITextureStateListener;
  }
  
  public void setUpdateOnHardwareNeeded(boolean paramBoolean) {
    this.mUpdateOnHardwareNeeded = paramBoolean;
  }
  
  public void unload() {
    this.mTextureManager.unloadTexture(this);
  }
  
  public void unload(GLState paramGLState) {
    this.mTextureManager.unloadTexture(paramGLState, this);
  }
  
  public void unloadFromHardware(GLState paramGLState) {
    paramGLState.deleteTexture(this.mHardwareTextureID);
    this.mHardwareTextureID = -1;
    if (this.mTextureStateListener != null)
      this.mTextureStateListener.onUnloadedFromHardware(this); 
  }
  
  protected abstract void writeTextureToHardware(GLState paramGLState) throws IOException;
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/Texture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */