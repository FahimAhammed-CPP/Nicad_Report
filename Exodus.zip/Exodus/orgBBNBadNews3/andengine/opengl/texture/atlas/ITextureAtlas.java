package org.andengine.opengl.texture.atlas;

import org.andengine.opengl.texture.ITexture;
import org.andengine.opengl.texture.ITextureStateListener;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.util.debug.Debug;

public interface ITextureAtlas<T extends ITextureAtlasSource> extends ITexture {
  void addEmptyTextureAtlasSource(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  void addTextureAtlasSource(T paramT, int paramInt1, int paramInt2) throws IllegalArgumentException;
  
  void addTextureAtlasSource(T paramT, int paramInt1, int paramInt2, int paramInt3) throws IllegalArgumentException;
  
  void clearTextureAtlasSources();
  
  ITextureAtlasStateListener<T> getTextureAtlasStateListener();
  
  @Deprecated
  ITextureAtlasStateListener<T> getTextureStateListener();
  
  boolean hasTextureAtlasStateListener();
  
  @Deprecated
  boolean hasTextureStateListener();
  
  void removeTextureAtlasSource(T paramT, int paramInt1, int paramInt2);
  
  void setTextureAtlasStateListener(ITextureAtlasStateListener<T> paramITextureAtlasStateListener);
  
  @Deprecated
  void setTextureStateListener(ITextureStateListener paramITextureStateListener);
  
  public static interface ITextureAtlasStateListener<T extends ITextureAtlasSource> extends ITextureStateListener {
    void onTextureAtlasSourceLoadExeption(ITextureAtlas<T> param1ITextureAtlas, T param1T, Throwable param1Throwable);
    
    void onTextureAtlasSourceLoaded(ITextureAtlas<T> param1ITextureAtlas, T param1T);
    
    public static class DebugTextureAtlasStateListener<T extends ITextureAtlasSource> implements ITextureAtlasStateListener<T> {
      public void onLoadedToHardware(ITexture param2ITexture) {
        Debug.d("Texture loaded: " + param2ITexture.toString());
      }
      
      public void onTextureAtlasSourceLoadExeption(ITextureAtlas<T> param2ITextureAtlas, T param2T, Throwable param2Throwable) {
        Debug.e("Exception loading TextureAtlasSource. TextureAtlas: " + param2ITextureAtlas.toString() + " TextureAtlasSource: " + param2T.toString(), param2Throwable);
      }
      
      public void onTextureAtlasSourceLoaded(ITextureAtlas<T> param2ITextureAtlas, T param2T) {
        Debug.e("Loaded TextureAtlasSource. TextureAtlas: " + param2ITextureAtlas.toString() + " TextureAtlasSource: " + param2T.toString());
      }
      
      public void onUnloadedFromHardware(ITexture param2ITexture) {
        Debug.d("Texture unloaded: " + param2ITexture.toString());
      }
    }
    
    public static class TextureAtlasStateAdapter<T extends ITextureAtlasSource> implements ITextureAtlasStateListener<T> {
      public void onLoadedToHardware(ITexture param2ITexture) {}
      
      public void onTextureAtlasSourceLoadExeption(ITextureAtlas<T> param2ITextureAtlas, T param2T, Throwable param2Throwable) {}
      
      public void onTextureAtlasSourceLoaded(ITextureAtlas<T> param2ITextureAtlas, T param2T) {}
      
      public void onUnloadedFromHardware(ITexture param2ITexture) {}
    }
  }
  
  public static class DebugTextureAtlasStateListener<T extends ITextureAtlasSource> implements ITextureAtlasStateListener<T> {
    public void onLoadedToHardware(ITexture param1ITexture) {
      Debug.d("Texture loaded: " + param1ITexture.toString());
    }
    
    public void onTextureAtlasSourceLoadExeption(ITextureAtlas<T> param1ITextureAtlas, T param1T, Throwable param1Throwable) {
      Debug.e("Exception loading TextureAtlasSource. TextureAtlas: " + param1ITextureAtlas.toString() + " TextureAtlasSource: " + param1T.toString(), param1Throwable);
    }
    
    public void onTextureAtlasSourceLoaded(ITextureAtlas<T> param1ITextureAtlas, T param1T) {
      Debug.e("Loaded TextureAtlasSource. TextureAtlas: " + param1ITextureAtlas.toString() + " TextureAtlasSource: " + param1T.toString());
    }
    
    public void onUnloadedFromHardware(ITexture param1ITexture) {
      Debug.d("Texture unloaded: " + param1ITexture.toString());
    }
  }
  
  public static class TextureAtlasStateAdapter<T extends ITextureAtlasSource> implements ITextureAtlasStateListener<T> {
    public void onLoadedToHardware(ITexture param1ITexture) {}
    
    public void onTextureAtlasSourceLoadExeption(ITextureAtlas<T> param1ITextureAtlas, T param1T, Throwable param1Throwable) {}
    
    public void onTextureAtlasSourceLoaded(ITextureAtlas<T> param1ITextureAtlas, T param1T) {}
    
    public void onUnloadedFromHardware(ITexture param1ITexture) {}
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/ITextureAtlas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */