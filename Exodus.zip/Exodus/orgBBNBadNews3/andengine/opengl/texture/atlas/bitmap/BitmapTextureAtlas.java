package org.andengine.opengl.texture.atlas.bitmap;

import android.graphics.Bitmap;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import java.util.ArrayList;
import org.andengine.opengl.texture.PixelFormat;
import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.atlas.ITextureAtlas;
import org.andengine.opengl.texture.atlas.TextureAtlas;
import org.andengine.opengl.texture.atlas.bitmap.source.EmptyBitmapTextureAtlasSource;
import org.andengine.opengl.texture.atlas.bitmap.source.IBitmapTextureAtlasSource;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.opengl.texture.bitmap.BitmapTextureFormat;
import org.andengine.opengl.util.GLState;
import org.andengine.util.exception.NullBitmapException;
import org.andengine.util.math.MathUtils;

public class BitmapTextureAtlas extends TextureAtlas<IBitmapTextureAtlasSource> {
  private final BitmapTextureFormat mBitmapTextureFormat;
  
  public BitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2) {
    this(paramTextureManager, paramInt1, paramInt2, BitmapTextureFormat.RGBA_8888);
  }
  
  public BitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, TextureOptions paramTextureOptions) throws IllegalArgumentException {
    this(paramTextureManager, paramInt1, paramInt2, BitmapTextureFormat.RGBA_8888, paramTextureOptions, (ITextureAtlas.ITextureAtlasStateListener<IBitmapTextureAtlasSource>)null);
  }
  
  public BitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, TextureOptions paramTextureOptions, ITextureAtlas.ITextureAtlasStateListener<IBitmapTextureAtlasSource> paramITextureAtlasStateListener) throws IllegalArgumentException {
    this(paramTextureManager, paramInt1, paramInt2, BitmapTextureFormat.RGBA_8888, paramTextureOptions, paramITextureAtlasStateListener);
  }
  
  public BitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, ITextureAtlas.ITextureAtlasStateListener<IBitmapTextureAtlasSource> paramITextureAtlasStateListener) {
    this(paramTextureManager, paramInt1, paramInt2, BitmapTextureFormat.RGBA_8888, TextureOptions.DEFAULT, paramITextureAtlasStateListener);
  }
  
  public BitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat) {
    this(paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat, TextureOptions.DEFAULT, (ITextureAtlas.ITextureAtlasStateListener<IBitmapTextureAtlasSource>)null);
  }
  
  public BitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions) throws IllegalArgumentException {
    this(paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat, paramTextureOptions, (ITextureAtlas.ITextureAtlasStateListener<IBitmapTextureAtlasSource>)null);
  }
  
  public BitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions, ITextureAtlas.ITextureAtlasStateListener<IBitmapTextureAtlasSource> paramITextureAtlasStateListener) throws IllegalArgumentException {
    super(paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat.getPixelFormat(), paramTextureOptions, paramITextureAtlasStateListener);
    this.mBitmapTextureFormat = paramBitmapTextureFormat;
  }
  
  public BitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat, ITextureAtlas.ITextureAtlasStateListener<IBitmapTextureAtlasSource> paramITextureAtlasStateListener) {
    this(paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat, TextureOptions.DEFAULT, paramITextureAtlasStateListener);
  }
  
  public void addEmptyTextureAtlasSource(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    addTextureAtlasSource((ITextureAtlasSource)new EmptyBitmapTextureAtlasSource(paramInt3, paramInt4), paramInt1, paramInt2);
  }
  
  public BitmapTextureFormat getBitmapTextureFormat() {
    return this.mBitmapTextureFormat;
  }
  
  protected void writeTextureToHardware(GLState paramGLState) {
    Bitmap.Config config;
    PixelFormat pixelFormat = this.mBitmapTextureFormat.getPixelFormat();
    int i = pixelFormat.getGLInternalFormat();
    int j = pixelFormat.getGLFormat();
    int k = pixelFormat.getGLType();
    GLES20.glTexImage2D(3553, 0, i, this.mWidth, this.mHeight, 0, j, k, null);
    boolean bool = this.mTextureOptions.mPreMultiplyAlpha;
    if (bool) {
      config = this.mBitmapTextureFormat.getBitmapConfig();
    } else {
      config = Bitmap.Config.ARGB_8888;
    } 
    ArrayList<IBitmapTextureAtlasSource> arrayList = this.mTextureAtlasSources;
    int m = arrayList.size();
    ITextureAtlas.ITextureAtlasStateListener iTextureAtlasStateListener = getTextureAtlasStateListener();
    for (i = 0;; i++) {
      boolean bool1;
      if (i >= m)
        return; 
      IBitmapTextureAtlasSource iBitmapTextureAtlasSource = arrayList.get(i);
      try {
        Bitmap bitmap = iBitmapTextureAtlasSource.onLoadBitmap(config);
        if (bitmap == null) {
          nullBitmapException = new NullBitmapException();
          StringBuilder stringBuilder = new StringBuilder();
          this("Caused by: ");
          this(stringBuilder.append(iBitmapTextureAtlasSource.getClass().toString()).append(" --> ").append(iBitmapTextureAtlasSource.toString()).append(" returned a null Bitmap.").toString());
          throw nullBitmapException;
        } 
      } catch (NullBitmapException nullBitmapException) {
        if (iTextureAtlasStateListener != null) {
          iTextureAtlasStateListener.onTextureAtlasSourceLoadExeption((ITextureAtlas)this, (ITextureAtlasSource)iBitmapTextureAtlasSource, (Throwable)nullBitmapException);
        } else {
          throw nullBitmapException;
        } 
        i++;
        continue;
      } 
      if (MathUtils.isPowerOfTwo(nullBitmapException.getWidth()) && MathUtils.isPowerOfTwo(nullBitmapException.getHeight()) && pixelFormat == PixelFormat.RGBA_8888) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (!bool1)
        GLES20.glPixelStorei(3317, 1); 
      if (bool) {
        GLUtils.texSubImage2D(3553, 0, iBitmapTextureAtlasSource.getTextureX(), iBitmapTextureAtlasSource.getTextureY(), (Bitmap)nullBitmapException, j, k);
      } else {
        paramGLState.glTexSubImage2D(3553, 0, iBitmapTextureAtlasSource.getTextureX(), iBitmapTextureAtlasSource.getTextureY(), (Bitmap)nullBitmapException, this.mPixelFormat);
      } 
      if (!bool1)
        GLES20.glPixelStorei(3317, 4); 
      nullBitmapException.recycle();
      if (iTextureAtlasStateListener != null)
        iTextureAtlasStateListener.onTextureAtlasSourceLoaded((ITextureAtlas)this, (ITextureAtlasSource)iBitmapTextureAtlasSource); 
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/BitmapTextureAtlas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */