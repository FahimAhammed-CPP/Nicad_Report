package org.andengine.opengl.texture.atlas.bitmap.source.decorator;

import android.graphics.AvoidXfermode;
import android.graphics.Xfermode;
import org.andengine.opengl.texture.atlas.bitmap.source.IBitmapTextureAtlasSource;
import org.andengine.opengl.texture.atlas.bitmap.source.decorator.shape.IBitmapTextureAtlasSourceDecoratorShape;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.util.color.Color;

public class ColorSwapBitmapTextureAtlasSourceDecorator extends BaseShapeBitmapTextureAtlasSourceDecorator {
  private static final int TOLERANCE_DEFAULT = 0;
  
  protected final int mColorKeyColorARGBPackedInt;
  
  protected final int mColorSwapColorARGBPackedInt;
  
  protected final int mTolerance;
  
  public ColorSwapBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, int paramInt1, int paramInt2) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramInt1, 0, paramInt2, (BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions)null);
  }
  
  public ColorSwapBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, int paramInt1, int paramInt2, int paramInt3) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramInt1, paramInt2, paramInt3, (BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions)null);
  }
  
  public ColorSwapBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, int paramInt1, int paramInt2, int paramInt3, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    super(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramTextureAtlasSourceDecoratorOptions);
    this.mColorKeyColorARGBPackedInt = paramInt1;
    this.mTolerance = paramInt2;
    this.mColorSwapColorARGBPackedInt = paramInt3;
    this.mPaint.setXfermode((Xfermode)new AvoidXfermode(paramInt1, paramInt2, AvoidXfermode.Mode.TARGET));
    this.mPaint.setColor(paramInt3);
  }
  
  public ColorSwapBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, int paramInt1, int paramInt2, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramInt1, 0, paramInt2, paramTextureAtlasSourceDecoratorOptions);
  }
  
  public ColorSwapBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, Color paramColor1, int paramInt, Color paramColor2) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramColor1.getARGBPackedInt(), paramInt, paramColor2.getARGBPackedInt());
  }
  
  public ColorSwapBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, Color paramColor1, int paramInt, Color paramColor2, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramColor1.getARGBPackedInt(), paramInt, paramColor2.getARGBPackedInt(), paramTextureAtlasSourceDecoratorOptions);
  }
  
  public ColorSwapBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, Color paramColor1, Color paramColor2) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramColor1.getARGBPackedInt(), paramColor2.getARGBPackedInt());
  }
  
  public ColorSwapBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, Color paramColor1, Color paramColor2, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramColor1.getARGBPackedInt(), paramColor2.getARGBPackedInt(), paramTextureAtlasSourceDecoratorOptions);
  }
  
  public ColorSwapBitmapTextureAtlasSourceDecorator deepCopy() {
    return new ColorSwapBitmapTextureAtlasSourceDecorator(this.mBitmapTextureAtlasSource, this.mBitmapTextureAtlasSourceDecoratorShape, this.mColorKeyColorARGBPackedInt, this.mTolerance, this.mColorSwapColorARGBPackedInt, this.mTextureAtlasSourceDecoratorOptions);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/decorator/ColorSwapBitmapTextureAtlasSourceDecorator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */