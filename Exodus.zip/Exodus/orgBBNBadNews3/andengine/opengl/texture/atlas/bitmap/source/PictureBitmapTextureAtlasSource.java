package org.andengine.opengl.texture.atlas.bitmap.source;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Picture;
import org.andengine.opengl.texture.atlas.source.BaseTextureAtlasSource;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.util.debug.Debug;

public abstract class PictureBitmapTextureAtlasSource extends BaseTextureAtlasSource implements IBitmapTextureAtlasSource {
  protected final Picture mPicture;
  
  public PictureBitmapTextureAtlasSource(Picture paramPicture) {
    this(paramPicture, 0, 0);
  }
  
  public PictureBitmapTextureAtlasSource(Picture paramPicture, int paramInt1, int paramInt2) {
    this(paramPicture, paramInt1, paramInt2, paramPicture.getWidth(), paramPicture.getHeight());
  }
  
  public PictureBitmapTextureAtlasSource(Picture paramPicture, int paramInt1, int paramInt2, float paramFloat) {
    this(paramPicture, paramInt1, paramInt2, Math.round(paramPicture.getWidth() * paramFloat), Math.round(paramPicture.getHeight() * paramFloat));
  }
  
  public PictureBitmapTextureAtlasSource(Picture paramPicture, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramInt1, paramInt2, paramInt3, paramInt4);
    this.mPicture = paramPicture;
  }
  
  public abstract PictureBitmapTextureAtlasSource deepCopy();
  
  public Bitmap onLoadBitmap(Bitmap.Config paramConfig) {
    Picture picture = this.mPicture;
    if (picture == null) {
      Debug.e("Failed loading Bitmap in " + getClass().getSimpleName() + ".");
      return null;
    } 
    Bitmap bitmap = Bitmap.createBitmap(this.mTextureWidth, this.mTextureHeight, paramConfig);
    Canvas canvas = new Canvas(bitmap);
    canvas.scale(this.mTextureWidth / this.mPicture.getWidth(), this.mTextureHeight / this.mPicture.getHeight(), 0.0F, 0.0F);
    picture.draw(canvas);
    return bitmap;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/PictureBitmapTextureAtlasSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */