package org.andengine.opengl.texture.atlas.bitmap.source.decorator.shape;

import android.graphics.Canvas;
import android.graphics.Paint;
import org.andengine.opengl.texture.atlas.bitmap.source.decorator.BaseBitmapTextureAtlasSourceDecorator;

public class CircleBitmapTextureAtlasSourceDecoratorShape implements IBitmapTextureAtlasSourceDecoratorShape {
  private static CircleBitmapTextureAtlasSourceDecoratorShape sDefaultInstance;
  
  public static CircleBitmapTextureAtlasSourceDecoratorShape getDefaultInstance() {
    if (sDefaultInstance == null)
      sDefaultInstance = new CircleBitmapTextureAtlasSourceDecoratorShape(); 
    return sDefaultInstance;
  }
  
  public void onDecorateBitmap(Canvas paramCanvas, Paint paramPaint, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    float f1 = paramCanvas.getWidth();
    float f2 = paramTextureAtlasSourceDecoratorOptions.getInsetLeft();
    float f3 = paramTextureAtlasSourceDecoratorOptions.getInsetRight();
    float f4 = paramCanvas.getHeight();
    float f5 = paramTextureAtlasSourceDecoratorOptions.getInsetTop();
    float f6 = paramTextureAtlasSourceDecoratorOptions.getInsetBottom();
    paramCanvas.drawCircle((paramCanvas.getWidth() + paramTextureAtlasSourceDecoratorOptions.getInsetLeft() - paramTextureAtlasSourceDecoratorOptions.getInsetRight()) * 0.5F, (paramCanvas.getHeight() + paramTextureAtlasSourceDecoratorOptions.getInsetTop() - paramTextureAtlasSourceDecoratorOptions.getInsetBottom()) * 0.5F, Math.min((f1 - f2 - f3) * 0.5F, (f4 - f5 - f6) * 0.5F), paramPaint);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/decorator/shape/CircleBitmapTextureAtlasSourceDecoratorShape.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */