package org.andengine.opengl.texture.atlas.bitmap.source.decorator.shape;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import org.andengine.opengl.texture.atlas.bitmap.source.decorator.BaseBitmapTextureAtlasSourceDecorator;

public class EllipseBitmapTextureAtlasSourceDecoratorShape implements IBitmapTextureAtlasSourceDecoratorShape {
  private static EllipseBitmapTextureAtlasSourceDecoratorShape sDefaultInstance;
  
  private final RectF mRectF = new RectF();
  
  public static EllipseBitmapTextureAtlasSourceDecoratorShape getDefaultInstance() {
    if (sDefaultInstance == null)
      sDefaultInstance = new EllipseBitmapTextureAtlasSourceDecoratorShape(); 
    return sDefaultInstance;
  }
  
  public void onDecorateBitmap(Canvas paramCanvas, Paint paramPaint, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    float f1 = paramTextureAtlasSourceDecoratorOptions.getInsetLeft();
    float f2 = paramTextureAtlasSourceDecoratorOptions.getInsetTop();
    float f3 = paramCanvas.getWidth();
    float f4 = paramTextureAtlasSourceDecoratorOptions.getInsetRight();
    float f5 = paramCanvas.getHeight();
    float f6 = paramTextureAtlasSourceDecoratorOptions.getInsetBottom();
    this.mRectF.set(f1, f2, f3 - f4, f5 - f6);
    paramCanvas.drawOval(this.mRectF, paramPaint);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/decorator/shape/EllipseBitmapTextureAtlasSourceDecoratorShape.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */