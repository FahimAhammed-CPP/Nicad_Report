package org.andengine.opengl.texture.atlas.bitmap.source;

import android.content.Context;
import android.graphics.Bitmap;
import java.io.File;
import org.andengine.opengl.texture.atlas.source.BaseTextureAtlasSource;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.util.FileUtils;

public class FileBitmapTextureAtlasSource extends BaseTextureAtlasSource implements IBitmapTextureAtlasSource {
  private final File mFile;
  
  FileBitmapTextureAtlasSource(File paramFile, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramInt1, paramInt2, paramInt3, paramInt4);
    this.mFile = paramFile;
  }
  
  public static FileBitmapTextureAtlasSource create(File paramFile) {
    return create(paramFile, 0, 0);
  }
  
  public static FileBitmapTextureAtlasSource create(File paramFile, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: new android/graphics/BitmapFactory$Options
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore_3
    //   8: aload_3
    //   9: iconst_1
    //   10: putfield inJustDecodeBounds : Z
    //   13: aconst_null
    //   14: astore #4
    //   16: aconst_null
    //   17: astore #5
    //   19: aload #4
    //   21: astore #6
    //   23: new java/io/FileInputStream
    //   26: astore #7
    //   28: aload #4
    //   30: astore #6
    //   32: aload #7
    //   34: aload_0
    //   35: invokespecial <init> : (Ljava/io/File;)V
    //   38: aload #7
    //   40: aconst_null
    //   41: aload_3
    //   42: invokestatic decodeStream : (Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    //   45: pop
    //   46: aload #7
    //   48: invokestatic close : (Ljava/io/Closeable;)V
    //   51: new org/andengine/opengl/texture/atlas/bitmap/source/FileBitmapTextureAtlasSource
    //   54: dup
    //   55: aload_0
    //   56: iload_1
    //   57: iload_2
    //   58: aload_3
    //   59: getfield outWidth : I
    //   62: aload_3
    //   63: getfield outHeight : I
    //   66: invokespecial <init> : (Ljava/io/File;IIII)V
    //   69: areturn
    //   70: astore #4
    //   72: aload #5
    //   74: astore #7
    //   76: aload #7
    //   78: astore #6
    //   80: new java/lang/StringBuilder
    //   83: astore #5
    //   85: aload #7
    //   87: astore #6
    //   89: aload #5
    //   91: ldc 'Failed loading Bitmap in '
    //   93: invokespecial <init> : (Ljava/lang/String;)V
    //   96: aload #7
    //   98: astore #6
    //   100: aload #5
    //   102: ldc org/andengine/opengl/texture/atlas/bitmap/source/FileBitmapTextureAtlasSource
    //   104: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   110: ldc '. File: '
    //   112: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   115: aload_0
    //   116: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   119: invokevirtual toString : ()Ljava/lang/String;
    //   122: aload #4
    //   124: invokestatic e : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   127: aload #7
    //   129: invokestatic close : (Ljava/io/Closeable;)V
    //   132: goto -> 51
    //   135: astore_0
    //   136: aload #6
    //   138: invokestatic close : (Ljava/io/Closeable;)V
    //   141: aload_0
    //   142: athrow
    //   143: astore_0
    //   144: aload #7
    //   146: astore #6
    //   148: goto -> 136
    //   151: astore #4
    //   153: goto -> 76
    // Exception table:
    //   from	to	target	type
    //   23	28	70	java/io/IOException
    //   23	28	135	finally
    //   32	38	70	java/io/IOException
    //   32	38	135	finally
    //   38	46	151	java/io/IOException
    //   38	46	143	finally
    //   80	85	135	finally
    //   89	96	135	finally
    //   100	127	135	finally
  }
  
  public static FileBitmapTextureAtlasSource createFromExternalStorage(Context paramContext, String paramString, int paramInt1, int paramInt2) {
    return create(new File(FileUtils.getAbsolutePathOnExternalStorage(paramContext, paramString)), paramInt1, paramInt2);
  }
  
  public static FileBitmapTextureAtlasSource createFromInternalStorage(Context paramContext, String paramString, int paramInt1, int paramInt2) {
    return create(new File(FileUtils.getAbsolutePathOnInternalStorage(paramContext, paramString)), paramInt1, paramInt2);
  }
  
  public FileBitmapTextureAtlasSource deepCopy() {
    return new FileBitmapTextureAtlasSource(this.mFile, this.mTextureX, this.mTextureY, this.mTextureWidth, this.mTextureHeight);
  }
  
  public Bitmap onLoadBitmap(Bitmap.Config paramConfig) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: new android/graphics/BitmapFactory$Options
    //   5: dup
    //   6: invokespecial <init> : ()V
    //   9: astore_3
    //   10: aload_3
    //   11: aload_1
    //   12: putfield inPreferredConfig : Landroid/graphics/Bitmap$Config;
    //   15: aconst_null
    //   16: astore #4
    //   18: aconst_null
    //   19: astore #5
    //   21: aload #4
    //   23: astore_1
    //   24: new java/io/FileInputStream
    //   27: astore #6
    //   29: aload #4
    //   31: astore_1
    //   32: aload #6
    //   34: aload_0
    //   35: getfield mFile : Ljava/io/File;
    //   38: invokespecial <init> : (Ljava/io/File;)V
    //   41: aload #6
    //   43: aconst_null
    //   44: aload_3
    //   45: invokestatic decodeStream : (Ljava/io/InputStream;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;
    //   48: astore_1
    //   49: aload #6
    //   51: invokestatic close : (Ljava/io/Closeable;)V
    //   54: aload_1
    //   55: areturn
    //   56: astore #4
    //   58: aload #5
    //   60: astore #6
    //   62: aload #6
    //   64: astore_1
    //   65: new java/lang/StringBuilder
    //   68: astore #5
    //   70: aload #6
    //   72: astore_1
    //   73: aload #5
    //   75: ldc 'Failed loading Bitmap in '
    //   77: invokespecial <init> : (Ljava/lang/String;)V
    //   80: aload #6
    //   82: astore_1
    //   83: aload #5
    //   85: aload_0
    //   86: invokevirtual getClass : ()Ljava/lang/Class;
    //   89: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   92: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: ldc '. File: '
    //   97: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: aload_0
    //   101: getfield mFile : Ljava/io/File;
    //   104: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   107: invokevirtual toString : ()Ljava/lang/String;
    //   110: aload #4
    //   112: invokestatic e : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   115: aload #6
    //   117: invokestatic close : (Ljava/io/Closeable;)V
    //   120: aload_2
    //   121: astore_1
    //   122: goto -> 54
    //   125: astore #6
    //   127: aload_1
    //   128: astore #4
    //   130: aload #4
    //   132: invokestatic close : (Ljava/io/Closeable;)V
    //   135: aload #6
    //   137: athrow
    //   138: astore_1
    //   139: aload #6
    //   141: astore #4
    //   143: aload_1
    //   144: astore #6
    //   146: goto -> 130
    //   149: astore #4
    //   151: goto -> 62
    // Exception table:
    //   from	to	target	type
    //   24	29	56	java/io/IOException
    //   24	29	125	finally
    //   32	41	56	java/io/IOException
    //   32	41	125	finally
    //   41	49	149	java/io/IOException
    //   41	49	138	finally
    //   65	70	125	finally
    //   73	80	125	finally
    //   83	115	125	finally
  }
  
  public String toString() {
    return String.valueOf(getClass().getSimpleName()) + "(" + this.mFile + ")";
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/FileBitmapTextureAtlasSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */