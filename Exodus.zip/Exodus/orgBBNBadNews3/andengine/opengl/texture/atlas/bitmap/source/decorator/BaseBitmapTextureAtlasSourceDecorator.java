package org.andengine.opengl.texture.atlas.bitmap.source.decorator;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import org.andengine.opengl.texture.atlas.bitmap.source.IBitmapTextureAtlasSource;
import org.andengine.opengl.texture.atlas.source.BaseTextureAtlasSource;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.util.debug.Debug;

public abstract class BaseBitmapTextureAtlasSourceDecorator extends BaseTextureAtlasSource implements IBitmapTextureAtlasSource {
  protected final IBitmapTextureAtlasSource mBitmapTextureAtlasSource;
  
  protected Paint mPaint = new Paint();
  
  protected TextureAtlasSourceDecoratorOptions mTextureAtlasSourceDecoratorOptions;
  
  public BaseBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource) {
    this(paramIBitmapTextureAtlasSource, new TextureAtlasSourceDecoratorOptions());
  }
  
  public BaseBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    super(paramIBitmapTextureAtlasSource.getTextureX(), paramIBitmapTextureAtlasSource.getTextureY(), paramIBitmapTextureAtlasSource.getTextureWidth(), paramIBitmapTextureAtlasSource.getTextureHeight());
    this.mBitmapTextureAtlasSource = paramIBitmapTextureAtlasSource;
    TextureAtlasSourceDecoratorOptions textureAtlasSourceDecoratorOptions = paramTextureAtlasSourceDecoratorOptions;
    if (paramTextureAtlasSourceDecoratorOptions == null)
      textureAtlasSourceDecoratorOptions = new TextureAtlasSourceDecoratorOptions(); 
    this.mTextureAtlasSourceDecoratorOptions = textureAtlasSourceDecoratorOptions;
    this.mPaint.setAntiAlias(this.mTextureAtlasSourceDecoratorOptions.getAntiAliasing());
  }
  
  private static Bitmap ensureLoadedBitmapIsMutable(Bitmap paramBitmap) {
    if (!paramBitmap.isMutable()) {
      Bitmap bitmap = paramBitmap.copy(paramBitmap.getConfig(), true);
      paramBitmap.recycle();
      paramBitmap = bitmap;
    } 
    return paramBitmap;
  }
  
  public abstract BaseBitmapTextureAtlasSourceDecorator deepCopy();
  
  public Paint getPaint() {
    return this.mPaint;
  }
  
  public TextureAtlasSourceDecoratorOptions getTextureAtlasSourceDecoratorOptions() {
    return this.mTextureAtlasSourceDecoratorOptions;
  }
  
  public int getTextureHeight() {
    return this.mBitmapTextureAtlasSource.getTextureHeight();
  }
  
  public int getTextureWidth() {
    return this.mBitmapTextureAtlasSource.getTextureWidth();
  }
  
  protected abstract void onDecorateBitmap(Canvas paramCanvas) throws Exception;
  
  public Bitmap onLoadBitmap(Bitmap.Config paramConfig) {
    Bitmap bitmap = ensureLoadedBitmapIsMutable(this.mBitmapTextureAtlasSource.onLoadBitmap(paramConfig));
    Canvas canvas = new Canvas(bitmap);
    try {
      onDecorateBitmap(canvas);
    } catch (Exception exception) {
      Debug.e(exception);
    } 
    return bitmap;
  }
  
  public void setPaint(Paint paramPaint) {
    this.mPaint = paramPaint;
  }
  
  public void setTextureAtlasSourceDecoratorOptions(TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    this.mTextureAtlasSourceDecoratorOptions = paramTextureAtlasSourceDecoratorOptions;
  }
  
  public static class TextureAtlasSourceDecoratorOptions {
    public static final TextureAtlasSourceDecoratorOptions DEFAULT = new TextureAtlasSourceDecoratorOptions();
    
    private boolean mAntiAliasing;
    
    private float mInsetBottom = 0.25F;
    
    private float mInsetLeft = 0.25F;
    
    private float mInsetRight = 0.25F;
    
    private float mInsetTop = 0.25F;
    
    protected TextureAtlasSourceDecoratorOptions deepCopy() {
      TextureAtlasSourceDecoratorOptions textureAtlasSourceDecoratorOptions = new TextureAtlasSourceDecoratorOptions();
      textureAtlasSourceDecoratorOptions.setInsets(this.mInsetLeft, this.mInsetTop, this.mInsetRight, this.mInsetBottom);
      textureAtlasSourceDecoratorOptions.setAntiAliasing(this.mAntiAliasing);
      return textureAtlasSourceDecoratorOptions;
    }
    
    public boolean getAntiAliasing() {
      return this.mAntiAliasing;
    }
    
    public float getInsetBottom() {
      return this.mInsetBottom;
    }
    
    public float getInsetLeft() {
      return this.mInsetLeft;
    }
    
    public float getInsetRight() {
      return this.mInsetRight;
    }
    
    public float getInsetTop() {
      return this.mInsetTop;
    }
    
    public TextureAtlasSourceDecoratorOptions setAntiAliasing(boolean param1Boolean) {
      this.mAntiAliasing = param1Boolean;
      return this;
    }
    
    public TextureAtlasSourceDecoratorOptions setInsetBottom(float param1Float) {
      this.mInsetBottom = param1Float;
      return this;
    }
    
    public TextureAtlasSourceDecoratorOptions setInsetLeft(float param1Float) {
      this.mInsetLeft = param1Float;
      return this;
    }
    
    public TextureAtlasSourceDecoratorOptions setInsetRight(float param1Float) {
      this.mInsetRight = param1Float;
      return this;
    }
    
    public TextureAtlasSourceDecoratorOptions setInsetTop(float param1Float) {
      this.mInsetTop = param1Float;
      return this;
    }
    
    public TextureAtlasSourceDecoratorOptions setInsets(float param1Float) {
      return setInsets(param1Float, param1Float, param1Float, param1Float);
    }
    
    public TextureAtlasSourceDecoratorOptions setInsets(float param1Float1, float param1Float2, float param1Float3, float param1Float4) {
      this.mInsetLeft = param1Float1;
      this.mInsetTop = param1Float2;
      this.mInsetRight = param1Float3;
      this.mInsetBottom = param1Float4;
      return this;
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/decorator/BaseBitmapTextureAtlasSourceDecorator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */