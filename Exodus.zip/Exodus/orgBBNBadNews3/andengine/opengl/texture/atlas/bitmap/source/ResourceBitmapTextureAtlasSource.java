package org.andengine.opengl.texture.atlas.bitmap.source;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import org.andengine.opengl.texture.atlas.source.BaseTextureAtlasSource;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;

public class ResourceBitmapTextureAtlasSource extends BaseTextureAtlasSource implements IBitmapTextureAtlasSource {
  private final int mDrawableResourceID;
  
  private final Resources mResources;
  
  public ResourceBitmapTextureAtlasSource(Resources paramResources, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    super(paramInt2, paramInt3, paramInt4, paramInt5);
    this.mResources = paramResources;
    this.mDrawableResourceID = paramInt1;
  }
  
  public static ResourceBitmapTextureAtlasSource create(Resources paramResources, int paramInt) {
    return create(paramResources, paramInt, 0, 0);
  }
  
  public static ResourceBitmapTextureAtlasSource create(Resources paramResources, int paramInt1, int paramInt2, int paramInt3) {
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inJustDecodeBounds = true;
    BitmapFactory.decodeResource(paramResources, paramInt1, options);
    return new ResourceBitmapTextureAtlasSource(paramResources, paramInt1, paramInt2, paramInt3, options.outWidth, options.outHeight);
  }
  
  public ResourceBitmapTextureAtlasSource deepCopy() {
    return new ResourceBitmapTextureAtlasSource(this.mResources, this.mDrawableResourceID, this.mTextureX, this.mTextureY, this.mTextureWidth, this.mTextureHeight);
  }
  
  public Bitmap onLoadBitmap(Bitmap.Config paramConfig) {
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inPreferredConfig = paramConfig;
    return BitmapFactory.decodeResource(this.mResources, this.mDrawableResourceID, options);
  }
  
  public String toString() {
    return String.valueOf(getClass().getSimpleName()) + "(" + this.mDrawableResourceID + ")";
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/ResourceBitmapTextureAtlasSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */