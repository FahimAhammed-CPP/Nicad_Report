package org.andengine.opengl.texture.atlas.bitmap.source;

import android.graphics.Bitmap;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;

public interface IBitmapTextureAtlasSource extends ITextureAtlasSource {
  IBitmapTextureAtlasSource deepCopy();
  
  Bitmap onLoadBitmap(Bitmap.Config paramConfig);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/IBitmapTextureAtlasSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */