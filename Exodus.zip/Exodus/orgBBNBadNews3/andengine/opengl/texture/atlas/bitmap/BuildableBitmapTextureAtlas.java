package org.andengine.opengl.texture.atlas.bitmap;

import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.atlas.ITextureAtlas;
import org.andengine.opengl.texture.atlas.bitmap.source.IBitmapTextureAtlasSource;
import org.andengine.opengl.texture.atlas.buildable.BuildableTextureAtlas;
import org.andengine.opengl.texture.bitmap.BitmapTextureFormat;

public class BuildableBitmapTextureAtlas extends BuildableTextureAtlas<IBitmapTextureAtlasSource, BitmapTextureAtlas> {
  public BuildableBitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2) {
    this(paramTextureManager, paramInt1, paramInt2, BitmapTextureFormat.RGBA_8888);
  }
  
  public BuildableBitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, TextureOptions paramTextureOptions) throws IllegalArgumentException {
    this(paramTextureManager, paramInt1, paramInt2, BitmapTextureFormat.RGBA_8888, paramTextureOptions, null);
  }
  
  public BuildableBitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, TextureOptions paramTextureOptions, ITextureAtlas.ITextureAtlasStateListener<IBitmapTextureAtlasSource> paramITextureAtlasStateListener) throws IllegalArgumentException {
    this(paramTextureManager, paramInt1, paramInt2, BitmapTextureFormat.RGBA_8888, paramTextureOptions, paramITextureAtlasStateListener);
  }
  
  public BuildableBitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, ITextureAtlas.ITextureAtlasStateListener<IBitmapTextureAtlasSource> paramITextureAtlasStateListener) {
    this(paramTextureManager, paramInt1, paramInt2, BitmapTextureFormat.RGBA_8888, TextureOptions.DEFAULT, paramITextureAtlasStateListener);
  }
  
  public BuildableBitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat) {
    this(paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat, TextureOptions.DEFAULT, null);
  }
  
  public BuildableBitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions) throws IllegalArgumentException {
    this(paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat, paramTextureOptions, null);
  }
  
  public BuildableBitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions, ITextureAtlas.ITextureAtlasStateListener<IBitmapTextureAtlasSource> paramITextureAtlasStateListener) throws IllegalArgumentException {
    super((ITextureAtlas)new BitmapTextureAtlas(paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat, paramTextureOptions, paramITextureAtlasStateListener));
  }
  
  public BuildableBitmapTextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat, ITextureAtlas.ITextureAtlasStateListener<IBitmapTextureAtlasSource> paramITextureAtlasStateListener) {
    this(paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat, TextureOptions.DEFAULT, paramITextureAtlasStateListener);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/BuildableBitmapTextureAtlas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */