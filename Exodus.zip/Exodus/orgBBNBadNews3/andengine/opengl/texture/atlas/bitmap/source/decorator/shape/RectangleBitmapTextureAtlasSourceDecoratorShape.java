package org.andengine.opengl.texture.atlas.bitmap.source.decorator.shape;

import android.graphics.Canvas;
import android.graphics.Paint;
import org.andengine.opengl.texture.atlas.bitmap.source.decorator.BaseBitmapTextureAtlasSourceDecorator;

public class RectangleBitmapTextureAtlasSourceDecoratorShape implements IBitmapTextureAtlasSourceDecoratorShape {
  private static RectangleBitmapTextureAtlasSourceDecoratorShape sDefaultInstance;
  
  public static RectangleBitmapTextureAtlasSourceDecoratorShape getDefaultInstance() {
    if (sDefaultInstance == null)
      sDefaultInstance = new RectangleBitmapTextureAtlasSourceDecoratorShape(); 
    return sDefaultInstance;
  }
  
  public void onDecorateBitmap(Canvas paramCanvas, Paint paramPaint, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    paramCanvas.drawRect(paramTextureAtlasSourceDecoratorOptions.getInsetLeft(), paramTextureAtlasSourceDecoratorOptions.getInsetTop(), paramCanvas.getWidth() - paramTextureAtlasSourceDecoratorOptions.getInsetRight(), paramCanvas.getHeight() - paramTextureAtlasSourceDecoratorOptions.getInsetBottom(), paramPaint);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/decorator/shape/RectangleBitmapTextureAtlasSourceDecoratorShape.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */