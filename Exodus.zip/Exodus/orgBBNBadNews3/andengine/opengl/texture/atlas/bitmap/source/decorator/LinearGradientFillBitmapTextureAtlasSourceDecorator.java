package org.andengine.opengl.texture.atlas.bitmap.source.decorator;

import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import org.andengine.opengl.texture.atlas.bitmap.source.IBitmapTextureAtlasSource;
import org.andengine.opengl.texture.atlas.bitmap.source.decorator.shape.IBitmapTextureAtlasSourceDecoratorShape;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;

public class LinearGradientFillBitmapTextureAtlasSourceDecorator extends BaseShapeBitmapTextureAtlasSourceDecorator {
  protected final int[] mColors;
  
  protected final LinearGradientDirection mLinearGradientDirection;
  
  protected final float[] mPositions;
  
  public LinearGradientFillBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, int paramInt1, int paramInt2, LinearGradientDirection paramLinearGradientDirection) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramInt1, paramInt2, paramLinearGradientDirection, (BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions)null);
  }
  
  public LinearGradientFillBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, int paramInt1, int paramInt2, LinearGradientDirection paramLinearGradientDirection, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, new int[] { paramInt1, paramInt2 }, (float[])null, paramLinearGradientDirection, paramTextureAtlasSourceDecoratorOptions);
  }
  
  public LinearGradientFillBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, int[] paramArrayOfint, float[] paramArrayOffloat, LinearGradientDirection paramLinearGradientDirection) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramArrayOfint, paramArrayOffloat, paramLinearGradientDirection, (BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions)null);
  }
  
  public LinearGradientFillBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, int[] paramArrayOfint, float[] paramArrayOffloat, LinearGradientDirection paramLinearGradientDirection, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    super(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramTextureAtlasSourceDecoratorOptions);
    this.mColors = paramArrayOfint;
    this.mPositions = paramArrayOffloat;
    this.mLinearGradientDirection = paramLinearGradientDirection;
    this.mPaint.setStyle(Paint.Style.FILL);
    int i = paramIBitmapTextureAtlasSource.getTextureWidth() - 1;
    int j = paramIBitmapTextureAtlasSource.getTextureHeight() - 1;
    float f1 = paramLinearGradientDirection.getFromX(i);
    float f2 = paramLinearGradientDirection.getFromY(j);
    float f3 = paramLinearGradientDirection.getToX(i);
    float f4 = paramLinearGradientDirection.getToY(j);
    this.mPaint.setShader((Shader)new LinearGradient(f1, f2, f3, f4, paramArrayOfint, paramArrayOffloat, Shader.TileMode.CLAMP));
  }
  
  public LinearGradientFillBitmapTextureAtlasSourceDecorator deepCopy() {
    return new LinearGradientFillBitmapTextureAtlasSourceDecorator(this.mBitmapTextureAtlasSource, this.mBitmapTextureAtlasSourceDecoratorShape, this.mColors, this.mPositions, this.mLinearGradientDirection, this.mTextureAtlasSourceDecoratorOptions);
  }
  
  public enum LinearGradientDirection {
    BOTTOMLEFT_TO_TOPRIGHT,
    BOTTOMRIGHT_TO_TOPLEFT,
    BOTTOM_TO_TOP,
    LEFT_TO_RIGHT(1, 0, 0, 0),
    RIGHT_TO_LEFT(0, 0, 1, 0),
    TOPLEFT_TO_BOTTOMRIGHT(0, 0, 1, 0),
    TOPRIGHT_TO_BOTTOMLEFT(0, 0, 1, 0),
    TOP_TO_BOTTOM(0, 0, 1, 0);
    
    private final int mFromX;
    
    private final int mFromY;
    
    private final int mToX;
    
    private final int mToY;
    
    static {
      TOPLEFT_TO_BOTTOMRIGHT = new LinearGradientDirection("TOPLEFT_TO_BOTTOMRIGHT", 4, 0, 0, 1, 1);
      BOTTOMRIGHT_TO_TOPLEFT = new LinearGradientDirection("BOTTOMRIGHT_TO_TOPLEFT", 5, 1, 1, 0, 0);
      TOPRIGHT_TO_BOTTOMLEFT = new LinearGradientDirection("TOPRIGHT_TO_BOTTOMLEFT", 6, 1, 0, 0, 1);
      BOTTOMLEFT_TO_TOPRIGHT = new LinearGradientDirection("BOTTOMLEFT_TO_TOPRIGHT", 7, 0, 1, 1, 0);
      ENUM$VALUES = new LinearGradientDirection[] { LEFT_TO_RIGHT, RIGHT_TO_LEFT, BOTTOM_TO_TOP, TOP_TO_BOTTOM, TOPLEFT_TO_BOTTOMRIGHT, BOTTOMRIGHT_TO_TOPLEFT, TOPRIGHT_TO_BOTTOMLEFT, BOTTOMLEFT_TO_TOPRIGHT };
    }
    
    LinearGradientDirection(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.mFromX = param1Int1;
      this.mFromY = param1Int2;
      this.mToX = param1Int3;
      this.mToY = param1Int4;
    }
    
    final int getFromX(int param1Int) {
      return this.mFromX * param1Int;
    }
    
    final int getFromY(int param1Int) {
      return this.mFromY * param1Int;
    }
    
    final int getToX(int param1Int) {
      return this.mToX * param1Int;
    }
    
    final int getToY(int param1Int) {
      return this.mToY * param1Int;
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/decorator/LinearGradientFillBitmapTextureAtlasSourceDecorator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */