package org.andengine.opengl.texture.atlas.bitmap.source.decorator;

import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import org.andengine.opengl.texture.atlas.bitmap.source.IBitmapTextureAtlasSource;
import org.andengine.opengl.texture.atlas.bitmap.source.decorator.shape.IBitmapTextureAtlasSourceDecoratorShape;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.util.adt.array.ArrayUtils;

public class RadialGradientFillBitmapTextureAtlasSourceDecorator extends BaseShapeBitmapTextureAtlasSourceDecorator {
  private static final float[] POSITIONS_DEFAULT = new float[] { 0.0F, 1.0F };
  
  protected final int[] mColors;
  
  protected final float[] mPositions;
  
  protected final RadialGradientDirection mRadialGradientDirection;
  
  public RadialGradientFillBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, int paramInt1, int paramInt2, RadialGradientDirection paramRadialGradientDirection) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramInt1, paramInt2, paramRadialGradientDirection, (BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions)null);
  }
  
  public RadialGradientFillBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, int paramInt1, int paramInt2, RadialGradientDirection paramRadialGradientDirection, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, new int[] { paramInt1, paramInt2 }, arrayOfFloat, paramRadialGradientDirection, paramTextureAtlasSourceDecoratorOptions);
  }
  
  public RadialGradientFillBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, int[] paramArrayOfint, float[] paramArrayOffloat, RadialGradientDirection paramRadialGradientDirection) {
    this(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramArrayOfint, paramArrayOffloat, paramRadialGradientDirection, (BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions)null);
  }
  
  public RadialGradientFillBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, int[] paramArrayOfint, float[] paramArrayOffloat, RadialGradientDirection paramRadialGradientDirection, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    super(paramIBitmapTextureAtlasSource, paramIBitmapTextureAtlasSourceDecoratorShape, paramTextureAtlasSourceDecoratorOptions);
    this.mColors = paramArrayOfint;
    this.mPositions = paramArrayOffloat;
    this.mRadialGradientDirection = paramRadialGradientDirection;
    this.mPaint.setStyle(Paint.Style.FILL);
    int i = paramIBitmapTextureAtlasSource.getTextureWidth();
    int j = paramIBitmapTextureAtlasSource.getTextureHeight();
    float f1 = i * 0.5F;
    float f2 = j * 0.5F;
    float f3 = Math.max(f1, f2);
    switch (paramRadialGradientDirection) {
      default:
        return;
      case null:
        this.mPaint.setShader((Shader)new RadialGradient(f1, f2, f3, paramArrayOfint, paramArrayOffloat, Shader.TileMode.CLAMP));
      case null:
        break;
    } 
    ArrayUtils.reverse(paramArrayOfint);
    this.mPaint.setShader((Shader)new RadialGradient(f1, f2, f3, paramArrayOfint, paramArrayOffloat, Shader.TileMode.CLAMP));
  }
  
  public RadialGradientFillBitmapTextureAtlasSourceDecorator deepCopy() {
    return new RadialGradientFillBitmapTextureAtlasSourceDecorator(this.mBitmapTextureAtlasSource, this.mBitmapTextureAtlasSourceDecoratorShape, this.mColors, this.mPositions, this.mRadialGradientDirection, this.mTextureAtlasSourceDecoratorOptions);
  }
  
  public enum RadialGradientDirection {
    INSIDE_OUT, OUTSIDE_IN;
    
    static {
    
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/decorator/RadialGradientFillBitmapTextureAtlasSourceDecorator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */