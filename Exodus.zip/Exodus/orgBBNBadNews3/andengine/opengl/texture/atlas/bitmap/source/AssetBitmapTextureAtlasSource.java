package org.andengine.opengl.texture.atlas.bitmap.source;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.IOException;
import java.io.InputStream;
import org.andengine.opengl.texture.atlas.source.BaseTextureAtlasSource;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.util.StreamUtils;
import org.andengine.util.debug.Debug;

public class AssetBitmapTextureAtlasSource extends BaseTextureAtlasSource implements IBitmapTextureAtlasSource {
  private final AssetManager mAssetManager;
  
  private final String mAssetPath;
  
  AssetBitmapTextureAtlasSource(AssetManager paramAssetManager, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramInt1, paramInt2, paramInt3, paramInt4);
    this.mAssetManager = paramAssetManager;
    this.mAssetPath = paramString;
  }
  
  public static AssetBitmapTextureAtlasSource create(AssetManager paramAssetManager, String paramString) {
    return create(paramAssetManager, paramString, 0, 0);
  }
  
  public static AssetBitmapTextureAtlasSource create(AssetManager paramAssetManager, String paramString, int paramInt1, int paramInt2) {
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inJustDecodeBounds = true;
    InputStream inputStream1 = null;
    InputStream inputStream2 = null;
    try {
      InputStream inputStream = paramAssetManager.open(paramString);
      inputStream2 = inputStream;
      inputStream1 = inputStream;
      BitmapFactory.decodeStream(inputStream, null, options);
      return new AssetBitmapTextureAtlasSource(paramAssetManager, paramString, paramInt1, paramInt2, options.outWidth, options.outHeight);
    } catch (IOException iOException) {
      inputStream1 = inputStream2;
      StringBuilder stringBuilder = new StringBuilder();
      inputStream1 = inputStream2;
      this("Failed loading Bitmap in AssetBitmapTextureAtlasSource. AssetPath: ");
      inputStream1 = inputStream2;
      Debug.e(stringBuilder.append(paramString).toString(), iOException);
      return new AssetBitmapTextureAtlasSource(paramAssetManager, paramString, paramInt1, paramInt2, options.outWidth, options.outHeight);
    } finally {
      StreamUtils.close(inputStream1);
    } 
  }
  
  public AssetBitmapTextureAtlasSource deepCopy() {
    return new AssetBitmapTextureAtlasSource(this.mAssetManager, this.mAssetPath, this.mTextureX, this.mTextureY, this.mTextureWidth, this.mTextureHeight);
  }
  
  public Bitmap onLoadBitmap(Bitmap.Config paramConfig) {
    InputStream inputStream1 = null;
    InputStream inputStream2 = null;
    InputStream inputStream3 = null;
    InputStream inputStream4 = inputStream3;
    InputStream inputStream5 = inputStream2;
    try {
      BitmapFactory.Options options = new BitmapFactory.Options();
      inputStream4 = inputStream3;
      inputStream5 = inputStream2;
      this();
      inputStream4 = inputStream3;
      inputStream5 = inputStream2;
      options.inPreferredConfig = paramConfig;
      inputStream4 = inputStream3;
      inputStream5 = inputStream2;
      InputStream inputStream = this.mAssetManager.open(this.mAssetPath);
      inputStream4 = inputStream;
      inputStream5 = inputStream;
      Bitmap bitmap = BitmapFactory.decodeStream(inputStream, null, options);
      return bitmap;
    } catch (IOException iOException) {
      inputStream5 = inputStream4;
      StringBuilder stringBuilder = new StringBuilder();
      inputStream5 = inputStream4;
      this("Failed loading Bitmap in ");
      inputStream5 = inputStream4;
      Debug.e(stringBuilder.append(getClass().getSimpleName()).append(". AssetPath: ").append(this.mAssetPath).toString(), iOException);
      return (Bitmap)inputStream1;
    } finally {
      StreamUtils.close(inputStream5);
    } 
  }
  
  public String toString() {
    return String.valueOf(getClass().getSimpleName()) + "(" + this.mAssetPath + ")";
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/AssetBitmapTextureAtlasSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */