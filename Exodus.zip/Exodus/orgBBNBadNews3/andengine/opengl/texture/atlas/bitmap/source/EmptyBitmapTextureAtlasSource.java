package org.andengine.opengl.texture.atlas.bitmap.source;

import android.graphics.Bitmap;
import org.andengine.opengl.texture.atlas.source.BaseTextureAtlasSource;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;

public class EmptyBitmapTextureAtlasSource extends BaseTextureAtlasSource implements IBitmapTextureAtlasSource {
  public EmptyBitmapTextureAtlasSource(int paramInt1, int paramInt2) {
    this(0, 0, paramInt1, paramInt2);
  }
  
  public EmptyBitmapTextureAtlasSource(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public EmptyBitmapTextureAtlasSource deepCopy() {
    return new EmptyBitmapTextureAtlasSource(this.mTextureX, this.mTextureY, this.mTextureWidth, this.mTextureHeight);
  }
  
  public Bitmap onLoadBitmap(Bitmap.Config paramConfig) {
    return Bitmap.createBitmap(this.mTextureWidth, this.mTextureHeight, paramConfig);
  }
  
  public String toString() {
    return String.valueOf(getClass().getSimpleName()) + "(" + this.mTextureWidth + " x " + this.mTextureHeight + ")";
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/EmptyBitmapTextureAtlasSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */