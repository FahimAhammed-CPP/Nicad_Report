package org.andengine.opengl.texture.atlas.bitmap.source.decorator.shape;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import org.andengine.opengl.texture.atlas.bitmap.source.decorator.BaseBitmapTextureAtlasSourceDecorator;

public class RoundedRectangleBitmapTextureAtlasSourceDecoratorShape implements IBitmapTextureAtlasSourceDecoratorShape {
  private static final float CORNER_RADIUS_DEFAULT = 1.0F;
  
  private static RoundedRectangleBitmapTextureAtlasSourceDecoratorShape sDefaultInstance;
  
  private final float mCornerRadiusX;
  
  private final float mCornerRadiusY;
  
  private final RectF mRectF = new RectF();
  
  public RoundedRectangleBitmapTextureAtlasSourceDecoratorShape() {
    this(1.0F, 1.0F);
  }
  
  public RoundedRectangleBitmapTextureAtlasSourceDecoratorShape(float paramFloat1, float paramFloat2) {
    this.mCornerRadiusX = paramFloat1;
    this.mCornerRadiusY = paramFloat2;
  }
  
  public static RoundedRectangleBitmapTextureAtlasSourceDecoratorShape getDefaultInstance() {
    if (sDefaultInstance == null)
      sDefaultInstance = new RoundedRectangleBitmapTextureAtlasSourceDecoratorShape(); 
    return sDefaultInstance;
  }
  
  public void onDecorateBitmap(Canvas paramCanvas, Paint paramPaint, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    float f1 = paramTextureAtlasSourceDecoratorOptions.getInsetLeft();
    float f2 = paramTextureAtlasSourceDecoratorOptions.getInsetTop();
    float f3 = paramCanvas.getWidth();
    float f4 = paramTextureAtlasSourceDecoratorOptions.getInsetRight();
    float f5 = paramCanvas.getHeight();
    float f6 = paramTextureAtlasSourceDecoratorOptions.getInsetBottom();
    this.mRectF.set(f1, f2, f3 - f4, f5 - f6);
    paramCanvas.drawRoundRect(this.mRectF, this.mCornerRadiusX, this.mCornerRadiusY, paramPaint);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/decorator/shape/RoundedRectangleBitmapTextureAtlasSourceDecoratorShape.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */