package org.andengine.opengl.texture.atlas.bitmap;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import java.io.IOException;
import org.andengine.opengl.texture.ITexture;
import org.andengine.opengl.texture.atlas.ITextureAtlas;
import org.andengine.opengl.texture.atlas.bitmap.source.AssetBitmapTextureAtlasSource;
import org.andengine.opengl.texture.atlas.bitmap.source.IBitmapTextureAtlasSource;
import org.andengine.opengl.texture.atlas.bitmap.source.ResourceBitmapTextureAtlasSource;
import org.andengine.opengl.texture.atlas.buildable.BuildableTextureAtlasTextureRegionFactory;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.opengl.texture.region.ITextureRegion;
import org.andengine.opengl.texture.region.TextureRegion;
import org.andengine.opengl.texture.region.TextureRegionFactory;
import org.andengine.opengl.texture.region.TiledTextureRegion;
import org.andengine.util.exception.AndEngineRuntimeException;

public class BitmapTextureAtlasTextureRegionFactory {
  private static String sAssetBasePath = "";
  
  public static TextureRegion createFromAsset(BitmapTextureAtlas paramBitmapTextureAtlas, Context paramContext, String paramString, int paramInt1, int paramInt2) {
    return createFromAsset(paramBitmapTextureAtlas, paramContext.getAssets(), paramString, paramInt1, paramInt2);
  }
  
  public static TextureRegion createFromAsset(BitmapTextureAtlas paramBitmapTextureAtlas, AssetManager paramAssetManager, String paramString, int paramInt1, int paramInt2) {
    return createFromSource(paramBitmapTextureAtlas, (IBitmapTextureAtlasSource)AssetBitmapTextureAtlasSource.create(paramAssetManager, String.valueOf(sAssetBasePath) + paramString), paramInt1, paramInt2);
  }
  
  public static TextureRegion createFromAsset(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, Context paramContext, String paramString) {
    return createFromAsset(paramBuildableBitmapTextureAtlas, paramContext.getAssets(), paramString);
  }
  
  public static TextureRegion createFromAsset(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, Context paramContext, String paramString, boolean paramBoolean) {
    return createFromAsset(paramBuildableBitmapTextureAtlas, paramContext.getAssets(), paramString, paramBoolean);
  }
  
  public static TextureRegion createFromAsset(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, AssetManager paramAssetManager, String paramString) {
    return createFromAsset(paramBuildableBitmapTextureAtlas, paramAssetManager, paramString, false);
  }
  
  public static TextureRegion createFromAsset(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, AssetManager paramAssetManager, String paramString, boolean paramBoolean) {
    return createFromSource(paramBuildableBitmapTextureAtlas, (IBitmapTextureAtlasSource)AssetBitmapTextureAtlasSource.create(paramAssetManager, String.valueOf(sAssetBasePath) + paramString), paramBoolean);
  }
  
  public static TextureRegion createFromResource(BitmapTextureAtlas paramBitmapTextureAtlas, Context paramContext, int paramInt1, int paramInt2, int paramInt3) {
    return createFromResource(paramBitmapTextureAtlas, paramContext.getResources(), paramInt1, paramInt2, paramInt3);
  }
  
  public static TextureRegion createFromResource(BitmapTextureAtlas paramBitmapTextureAtlas, Resources paramResources, int paramInt1, int paramInt2, int paramInt3) {
    return createFromSource(paramBitmapTextureAtlas, (IBitmapTextureAtlasSource)ResourceBitmapTextureAtlasSource.create(paramResources, paramInt1), paramInt2, paramInt3);
  }
  
  public static TextureRegion createFromResource(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, Context paramContext, int paramInt) {
    return createFromResource(paramBuildableBitmapTextureAtlas, paramContext.getResources(), paramInt);
  }
  
  public static TextureRegion createFromResource(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, Context paramContext, int paramInt, boolean paramBoolean) {
    return createFromResource(paramBuildableBitmapTextureAtlas, paramContext.getResources(), paramInt, paramBoolean);
  }
  
  public static TextureRegion createFromResource(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, Resources paramResources, int paramInt) {
    return createFromResource(paramBuildableBitmapTextureAtlas, paramResources, paramInt, false);
  }
  
  public static TextureRegion createFromResource(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, Resources paramResources, int paramInt, boolean paramBoolean) {
    return createFromSource(paramBuildableBitmapTextureAtlas, (IBitmapTextureAtlasSource)ResourceBitmapTextureAtlasSource.create(paramResources, paramInt), paramBoolean);
  }
  
  public static TextureRegion createFromSource(BitmapTextureAtlas paramBitmapTextureAtlas, IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, int paramInt1, int paramInt2) {
    return TextureRegionFactory.createFromSource((ITextureAtlas)paramBitmapTextureAtlas, (ITextureAtlasSource)paramIBitmapTextureAtlasSource, paramInt1, paramInt2);
  }
  
  public static TextureRegion createFromSource(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource) {
    return createFromSource(paramBuildableBitmapTextureAtlas, paramIBitmapTextureAtlasSource, false);
  }
  
  public static TextureRegion createFromSource(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, boolean paramBoolean) {
    return BuildableTextureAtlasTextureRegionFactory.createFromSource(paramBuildableBitmapTextureAtlas, (ITextureAtlasSource)paramIBitmapTextureAtlasSource, paramBoolean);
  }
  
  public static TiledTextureRegion createTiledFromAsset(BitmapTextureAtlas paramBitmapTextureAtlas, Context paramContext, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return createTiledFromAsset(paramBitmapTextureAtlas, paramContext.getAssets(), paramString, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static TiledTextureRegion createTiledFromAsset(BitmapTextureAtlas paramBitmapTextureAtlas, AssetManager paramAssetManager, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return createTiledFromSource(paramBitmapTextureAtlas, (IBitmapTextureAtlasSource)AssetBitmapTextureAtlasSource.create(paramAssetManager, String.valueOf(sAssetBasePath) + paramString), paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static TiledTextureRegion createTiledFromAsset(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, Context paramContext, String paramString, int paramInt1, int paramInt2) {
    return createTiledFromAsset(paramBuildableBitmapTextureAtlas, paramContext.getAssets(), paramString, paramInt1, paramInt2);
  }
  
  public static TiledTextureRegion createTiledFromAsset(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, AssetManager paramAssetManager, String paramString, int paramInt1, int paramInt2) {
    return createTiledFromSource(paramBuildableBitmapTextureAtlas, (IBitmapTextureAtlasSource)AssetBitmapTextureAtlasSource.create(paramAssetManager, String.valueOf(sAssetBasePath) + paramString), paramInt1, paramInt2);
  }
  
  public static TiledTextureRegion createTiledFromAssetDirectory(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, AssetManager paramAssetManager, String paramString) {
    try {
      StringBuilder stringBuilder = new StringBuilder();
      this(String.valueOf(sAssetBasePath));
      String[] arrayOfString = paramAssetManager.list(stringBuilder.append(paramString).toString());
      int i = arrayOfString.length;
      TextureRegion[] arrayOfTextureRegion = new TextureRegion[i];
      for (byte b = 0;; b++) {
        if (b >= i)
          return new TiledTextureRegion((ITexture)paramBuildableBitmapTextureAtlas, (ITextureRegion[])arrayOfTextureRegion); 
        arrayOfTextureRegion[b] = createFromAsset(paramBuildableBitmapTextureAtlas, paramAssetManager, String.valueOf(paramString) + "/" + arrayOfString[b]);
      } 
    } catch (IOException iOException) {
      throw new AndEngineRuntimeException("Listing assets subdirectory: '" + sAssetBasePath + paramString + "' failed. Does it exist?", iOException);
    } 
  }
  
  public static TiledTextureRegion createTiledFromResource(BitmapTextureAtlas paramBitmapTextureAtlas, Context paramContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    return createTiledFromResource(paramBitmapTextureAtlas, paramContext.getResources(), paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public static TiledTextureRegion createTiledFromResource(BitmapTextureAtlas paramBitmapTextureAtlas, Resources paramResources, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    return createTiledFromSource(paramBitmapTextureAtlas, (IBitmapTextureAtlasSource)ResourceBitmapTextureAtlasSource.create(paramResources, paramInt1), paramInt2, paramInt3, paramInt4, paramInt5);
  }
  
  public static TiledTextureRegion createTiledFromResource(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, Context paramContext, int paramInt1, int paramInt2, int paramInt3) {
    return createTiledFromResource(paramBuildableBitmapTextureAtlas, paramContext.getResources(), paramInt1, paramInt2, paramInt3);
  }
  
  public static TiledTextureRegion createTiledFromResource(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, Resources paramResources, int paramInt1, int paramInt2, int paramInt3) {
    return createTiledFromSource(paramBuildableBitmapTextureAtlas, (IBitmapTextureAtlasSource)ResourceBitmapTextureAtlasSource.create(paramResources, paramInt1), paramInt2, paramInt3);
  }
  
  public static TiledTextureRegion createTiledFromSource(BitmapTextureAtlas paramBitmapTextureAtlas, IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return TextureRegionFactory.createTiledFromSource((ITextureAtlas)paramBitmapTextureAtlas, (ITextureAtlasSource)paramIBitmapTextureAtlasSource, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static TiledTextureRegion createTiledFromSource(BuildableBitmapTextureAtlas paramBuildableBitmapTextureAtlas, IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, int paramInt1, int paramInt2) {
    return BuildableTextureAtlasTextureRegionFactory.createTiledFromSource(paramBuildableBitmapTextureAtlas, (ITextureAtlasSource)paramIBitmapTextureAtlasSource, paramInt1, paramInt2);
  }
  
  public static String getAssetBasePath() {
    return sAssetBasePath;
  }
  
  public static void reset() {
    setAssetBasePath("");
  }
  
  public static void setAssetBasePath(String paramString) {
    if (paramString.endsWith("/") || paramString.length() == 0) {
      sAssetBasePath = paramString;
      return;
    } 
    throw new IllegalArgumentException("pAssetBasePath must end with '/' or be lenght zero.");
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/BitmapTextureAtlasTextureRegionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */