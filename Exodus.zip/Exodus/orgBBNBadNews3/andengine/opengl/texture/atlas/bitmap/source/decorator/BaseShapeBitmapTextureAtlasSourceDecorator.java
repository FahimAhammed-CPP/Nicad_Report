package org.andengine.opengl.texture.atlas.bitmap.source.decorator;

import android.graphics.Canvas;
import android.graphics.Paint;
import org.andengine.opengl.texture.atlas.bitmap.source.IBitmapTextureAtlasSource;
import org.andengine.opengl.texture.atlas.bitmap.source.decorator.shape.IBitmapTextureAtlasSourceDecoratorShape;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;

public abstract class BaseShapeBitmapTextureAtlasSourceDecorator extends BaseBitmapTextureAtlasSourceDecorator {
  protected final IBitmapTextureAtlasSourceDecoratorShape mBitmapTextureAtlasSourceDecoratorShape;
  
  public BaseShapeBitmapTextureAtlasSourceDecorator(IBitmapTextureAtlasSource paramIBitmapTextureAtlasSource, IBitmapTextureAtlasSourceDecoratorShape paramIBitmapTextureAtlasSourceDecoratorShape, BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions paramTextureAtlasSourceDecoratorOptions) {
    super(paramIBitmapTextureAtlasSource, paramTextureAtlasSourceDecoratorOptions);
    this.mBitmapTextureAtlasSourceDecoratorShape = paramIBitmapTextureAtlasSourceDecoratorShape;
  }
  
  public abstract BaseShapeBitmapTextureAtlasSourceDecorator deepCopy();
  
  protected void onDecorateBitmap(Canvas paramCanvas) {
    BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions textureAtlasSourceDecoratorOptions;
    IBitmapTextureAtlasSourceDecoratorShape iBitmapTextureAtlasSourceDecoratorShape = this.mBitmapTextureAtlasSourceDecoratorShape;
    Paint paint = this.mPaint;
    if (this.mTextureAtlasSourceDecoratorOptions == null) {
      textureAtlasSourceDecoratorOptions = BaseBitmapTextureAtlasSourceDecorator.TextureAtlasSourceDecoratorOptions.DEFAULT;
    } else {
      textureAtlasSourceDecoratorOptions = this.mTextureAtlasSourceDecoratorOptions;
    } 
    iBitmapTextureAtlasSourceDecoratorShape.onDecorateBitmap(paramCanvas, paint, textureAtlasSourceDecoratorOptions);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/bitmap/source/decorator/BaseShapeBitmapTextureAtlasSourceDecorator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */