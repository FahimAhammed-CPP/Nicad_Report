package org.andengine.opengl.texture.atlas;

import java.util.ArrayList;
import org.andengine.opengl.texture.ITextureStateListener;
import org.andengine.opengl.texture.PixelFormat;
import org.andengine.opengl.texture.Texture;
import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;

public abstract class TextureAtlas<T extends ITextureAtlasSource> extends Texture implements ITextureAtlas<T> {
  protected final int mHeight;
  
  protected final ArrayList<T> mTextureAtlasSources = new ArrayList<T>();
  
  protected final int mWidth;
  
  public TextureAtlas(TextureManager paramTextureManager, int paramInt1, int paramInt2, PixelFormat paramPixelFormat, TextureOptions paramTextureOptions, ITextureAtlas.ITextureAtlasStateListener<T> paramITextureAtlasStateListener) {
    super(paramTextureManager, paramPixelFormat, paramTextureOptions, paramITextureAtlasStateListener);
    this.mWidth = paramInt1;
    this.mHeight = paramInt2;
  }
  
  private void checkTextureAtlasSourcePosition(T paramT, int paramInt1, int paramInt2) throws IllegalArgumentException {
    if (paramInt1 < 0)
      throw new IllegalArgumentException("Illegal negative pTextureX supplied: '" + paramInt1 + "'"); 
    if (paramInt2 < 0)
      throw new IllegalArgumentException("Illegal negative pTextureY supplied: '" + paramInt2 + "'"); 
    if (paramT.getTextureWidth() + paramInt1 > getWidth() || paramT.getTextureHeight() + paramInt2 > getHeight())
      throw new IllegalArgumentException("Supplied pTextureAtlasSource must not exceed bounds of Texture."); 
  }
  
  public void addTextureAtlasSource(T paramT, int paramInt1, int paramInt2) throws IllegalArgumentException {
    checkTextureAtlasSourcePosition(paramT, paramInt1, paramInt2);
    paramT.setTextureX(paramInt1);
    paramT.setTextureY(paramInt2);
    this.mTextureAtlasSources.add(paramT);
    this.mUpdateOnHardwareNeeded = true;
  }
  
  public void addTextureAtlasSource(T paramT, int paramInt1, int paramInt2, int paramInt3) throws IllegalArgumentException {
    addTextureAtlasSource(paramT, paramInt1, paramInt2);
    if (paramInt3 > 0) {
      if (paramInt1 >= paramInt3)
        addEmptyTextureAtlasSource(paramInt1 - paramInt3, paramInt2, paramInt3, paramT.getTextureHeight()); 
      if (paramInt2 >= paramInt3)
        addEmptyTextureAtlasSource(paramInt1, paramInt2 - paramInt3, paramT.getTextureWidth(), paramInt3); 
      if (paramT.getTextureWidth() + paramInt1 - 1 + paramInt3 <= getWidth())
        addEmptyTextureAtlasSource(paramT.getTextureWidth() + paramInt1, paramInt2, paramInt3, paramT.getTextureHeight()); 
      if (paramT.getTextureHeight() + paramInt2 - 1 + paramInt3 <= getHeight())
        addEmptyTextureAtlasSource(paramInt1, paramT.getTextureHeight() + paramInt2, paramT.getTextureWidth(), paramInt3); 
    } 
  }
  
  public void clearTextureAtlasSources() {
    this.mTextureAtlasSources.clear();
    this.mUpdateOnHardwareNeeded = true;
  }
  
  public int getHeight() {
    return this.mHeight;
  }
  
  public ITextureAtlas.ITextureAtlasStateListener<T> getTextureAtlasStateListener() {
    return (ITextureAtlas.ITextureAtlasStateListener<T>)super.getTextureStateListener();
  }
  
  @Deprecated
  public ITextureAtlas.ITextureAtlasStateListener<T> getTextureStateListener() {
    return getTextureAtlasStateListener();
  }
  
  public int getWidth() {
    return this.mWidth;
  }
  
  public boolean hasTextureAtlasStateListener() {
    return super.hasTextureStateListener();
  }
  
  @Deprecated
  public boolean hasTextureStateListener() {
    return super.hasTextureStateListener();
  }
  
  public void removeTextureAtlasSource(T paramT, int paramInt1, int paramInt2) {
    ArrayList<T> arrayList = this.mTextureAtlasSources;
    int i = arrayList.size() - 1;
    while (true) {
      if (i >= 0) {
        ITextureAtlasSource iTextureAtlasSource = (ITextureAtlasSource)arrayList.get(i);
        if (iTextureAtlasSource == paramT && iTextureAtlasSource.getTextureX() == paramInt1 && iTextureAtlasSource.getTextureY() == paramInt2) {
          arrayList.remove(i);
          this.mUpdateOnHardwareNeeded = true;
          return;
        } 
        i--;
        continue;
      } 
      return;
    } 
  }
  
  public void setTextureAtlasStateListener(ITextureAtlas.ITextureAtlasStateListener<T> paramITextureAtlasStateListener) {
    super.setTextureStateListener(paramITextureAtlasStateListener);
  }
  
  @Deprecated
  public void setTextureStateListener(ITextureStateListener paramITextureStateListener) {
    super.setTextureStateListener(paramITextureStateListener);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/TextureAtlas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */