package org.andengine.opengl.texture.atlas.buildable.builder;

import java.util.ArrayList;
import org.andengine.opengl.texture.atlas.buildable.BuildableTextureAtlas;

public interface ITextureAtlasBuilder<T extends org.andengine.opengl.texture.atlas.source.ITextureAtlasSource, A extends org.andengine.opengl.texture.atlas.ITextureAtlas<T>> {
  void build(A paramA, ArrayList<BuildableTextureAtlas.TextureAtlasSourceWithWithLocationCallback<T>> paramArrayList) throws TextureAtlasBuilderException;
  
  public static class TextureAtlasBuilderException extends Exception {
    private static final long serialVersionUID = 4700734424214372671L;
    
    public TextureAtlasBuilderException(String param1String) {
      super(param1String);
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/buildable/builder/ITextureAtlasBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */