package org.andengine.opengl.texture.atlas.buildable;

import org.andengine.opengl.texture.ITexture;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.opengl.texture.region.TextureRegion;
import org.andengine.opengl.texture.region.TiledTextureRegion;
import org.andengine.util.call.Callback;

public class BuildableTextureAtlasTextureRegionFactory {
  public static <T extends ITextureAtlasSource, A extends org.andengine.opengl.texture.atlas.ITextureAtlas<T>> TextureRegion createFromSource(BuildableTextureAtlas<T, A> paramBuildableTextureAtlas, T paramT, boolean paramBoolean) {
    final TextureRegion textureRegion = new TextureRegion((ITexture)paramBuildableTextureAtlas, 0.0F, 0.0F, paramT.getTextureWidth(), paramT.getTextureHeight(), paramBoolean);
    paramBuildableTextureAtlas.addTextureAtlasSource(paramT, new Callback<T>() {
          public void onCallback(T param1T) {
            textureRegion.setTexturePosition(param1T.getTextureX(), param1T.getTextureY());
          }
        });
    return textureRegion;
  }
  
  public static <T extends ITextureAtlasSource, A extends org.andengine.opengl.texture.atlas.ITextureAtlas<T>> TiledTextureRegion createTiledFromSource(BuildableTextureAtlas<T, A> paramBuildableTextureAtlas, final T pTextureAtlasSource, final int pTileColumns, final int pTileRows) {
    final TiledTextureRegion tiledTextureRegion = TiledTextureRegion.create((ITexture)paramBuildableTextureAtlas, 0, 0, pTextureAtlasSource.getTextureWidth(), pTextureAtlasSource.getTextureHeight(), pTileColumns, pTileRows);
    paramBuildableTextureAtlas.addTextureAtlasSource(pTextureAtlasSource, new Callback<T>() {
          public void onCallback(T param1T) {
            int i = pTextureAtlasSource.getTextureWidth() / pTileColumns;
            int j = pTextureAtlasSource.getTextureHeight() / pTileRows;
            byte b = 0;
            label12: while (true) {
              if (b >= pTileColumns)
                return; 
              for (byte b1 = 0;; b1++) {
                if (b1 >= pTileRows) {
                  b++;
                  continue label12;
                } 
                int k = pTileColumns;
                int m = param1T.getTextureX();
                int n = param1T.getTextureY();
                tiledTextureRegion.setTexturePosition(k * b1 + b, (m + b * i), (n + b1 * j));
              } 
              break;
            } 
          }
        });
    return tiledTextureRegion;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/buildable/BuildableTextureAtlasTextureRegionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */