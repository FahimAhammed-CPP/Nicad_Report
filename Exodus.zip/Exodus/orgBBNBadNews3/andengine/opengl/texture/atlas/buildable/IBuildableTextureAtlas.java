package org.andengine.opengl.texture.atlas.buildable;

import org.andengine.opengl.texture.atlas.ITextureAtlas;
import org.andengine.opengl.texture.atlas.buildable.builder.ITextureAtlasBuilder;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.util.call.Callback;

public interface IBuildableTextureAtlas<S extends ITextureAtlasSource, T extends ITextureAtlas<S>> extends ITextureAtlas<S> {
  @Deprecated
  void addTextureAtlasSource(S paramS, int paramInt1, int paramInt2);
  
  @Deprecated
  void addTextureAtlasSource(S paramS, int paramInt1, int paramInt2, int paramInt3);
  
  void addTextureAtlasSource(S paramS, Callback<S> paramCallback);
  
  IBuildableTextureAtlas<S, T> build(ITextureAtlasBuilder<S, T> paramITextureAtlasBuilder) throws ITextureAtlasBuilder.TextureAtlasBuilderException;
  
  void removeTextureAtlasSource(ITextureAtlasSource paramITextureAtlasSource);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/buildable/IBuildableTextureAtlas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */