package org.andengine.opengl.texture.atlas.buildable.builder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import org.andengine.opengl.texture.atlas.ITextureAtlas;
import org.andengine.opengl.texture.atlas.buildable.BuildableTextureAtlas;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;

public class BlackPawnTextureAtlasBuilder<T extends ITextureAtlasSource, A extends ITextureAtlas<T>> implements ITextureAtlasBuilder<T, A> {
  private static final Comparator<BuildableTextureAtlas.TextureAtlasSourceWithWithLocationCallback<?>> TEXTURESOURCE_COMPARATOR = new Comparator<BuildableTextureAtlas.TextureAtlasSourceWithWithLocationCallback<?>>() {
      public int compare(BuildableTextureAtlas.TextureAtlasSourceWithWithLocationCallback<?> param1TextureAtlasSourceWithWithLocationCallback1, BuildableTextureAtlas.TextureAtlasSourceWithWithLocationCallback<?> param1TextureAtlasSourceWithWithLocationCallback2) {
        int i = param1TextureAtlasSourceWithWithLocationCallback2.getTextureAtlasSource().getTextureWidth() - param1TextureAtlasSourceWithWithLocationCallback1.getTextureAtlasSource().getTextureWidth();
        if (i == 0)
          i = param1TextureAtlasSourceWithWithLocationCallback2.getTextureAtlasSource().getTextureHeight() - param1TextureAtlasSourceWithWithLocationCallback1.getTextureAtlasSource().getTextureHeight(); 
        return i;
      }
    };
  
  private final int mTextureAtlasBorderSpacing;
  
  private final int mTextureAtlasSourcePadding;
  
  private final int mTextureAtlasSourceSpacing;
  
  public BlackPawnTextureAtlasBuilder(int paramInt1, int paramInt2, int paramInt3) {
    this.mTextureAtlasBorderSpacing = paramInt1;
    this.mTextureAtlasSourceSpacing = paramInt2;
    this.mTextureAtlasSourcePadding = paramInt3;
  }
  
  public void build(A paramA, ArrayList<BuildableTextureAtlas.TextureAtlasSourceWithWithLocationCallback<T>> paramArrayList) throws ITextureAtlasBuilder.TextureAtlasBuilderException {
    Collections.sort(paramArrayList, TEXTURESOURCE_COMPARATOR);
    int i = paramA.getWidth() - this.mTextureAtlasBorderSpacing * 2;
    int j = paramA.getHeight() - this.mTextureAtlasBorderSpacing * 2;
    Node node = new Node(new Rect(0, 0, i, j));
    int k = paramArrayList.size();
    for (byte b = 0;; b++) {
      if (b >= k)
        return; 
      BuildableTextureAtlas.TextureAtlasSourceWithWithLocationCallback textureAtlasSourceWithWithLocationCallback = paramArrayList.get(b);
      ITextureAtlasSource iTextureAtlasSource = textureAtlasSourceWithWithLocationCallback.getTextureAtlasSource();
      Node node1 = node.insert(iTextureAtlasSource, i, j, this.mTextureAtlasSourceSpacing, this.mTextureAtlasSourcePadding);
      if (node1 == null)
        throw new ITextureAtlasBuilder.TextureAtlasBuilderException("Could not build: '" + iTextureAtlasSource.toString() + "' into: '" + paramA.getClass().getSimpleName() + "'."); 
      int m = node1.mRect.mLeft + this.mTextureAtlasBorderSpacing + this.mTextureAtlasSourcePadding;
      int n = node1.mRect.mTop + this.mTextureAtlasBorderSpacing + this.mTextureAtlasSourcePadding;
      if (this.mTextureAtlasSourcePadding == 0) {
        paramA.addTextureAtlasSource(iTextureAtlasSource, m, n);
      } else {
        paramA.addTextureAtlasSource(iTextureAtlasSource, m, n, this.mTextureAtlasSourcePadding);
      } 
      textureAtlasSourceWithWithLocationCallback.getCallback().onCallback(iTextureAtlasSource);
    } 
  }
  
  protected static class Node {
    private Node mChildA;
    
    private Node mChildB;
    
    private final BlackPawnTextureAtlasBuilder.Rect mRect;
    
    private ITextureAtlasSource mTextureAtlasSource;
    
    public Node(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this(new BlackPawnTextureAtlasBuilder.Rect(param1Int1, param1Int2, param1Int3, param1Int4));
    }
    
    public Node(BlackPawnTextureAtlasBuilder.Rect param1Rect) {
      this.mRect = param1Rect;
    }
    
    private Node createChildren(ITextureAtlasSource param1ITextureAtlasSource, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6) {
      BlackPawnTextureAtlasBuilder.Rect rect = this.mRect;
      if (param1Int5 >= param1Int6) {
        this.mChildA = new Node(rect.getLeft(), rect.getTop(), param1ITextureAtlasSource.getTextureWidth() + param1Int3 + param1Int4 * 2, rect.getHeight());
        this.mChildB = new Node(rect.getLeft() + param1ITextureAtlasSource.getTextureWidth() + param1Int3 + param1Int4 * 2, rect.getTop(), rect.getWidth() - param1ITextureAtlasSource.getTextureWidth() + param1Int3 + param1Int4 * 2, rect.getHeight());
        return this.mChildA.insert(param1ITextureAtlasSource, param1Int1, param1Int2, param1Int3, param1Int4);
      } 
      this.mChildA = new Node(rect.getLeft(), rect.getTop(), rect.getWidth(), param1ITextureAtlasSource.getTextureHeight() + param1Int3 + param1Int4 * 2);
      this.mChildB = new Node(rect.getLeft(), rect.getTop() + param1ITextureAtlasSource.getTextureHeight() + param1Int3 + param1Int4 * 2, rect.getWidth(), rect.getHeight() - param1ITextureAtlasSource.getTextureHeight() + param1Int3 + param1Int4 * 2);
      return this.mChildA.insert(param1ITextureAtlasSource, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public Node getChildA() {
      return this.mChildA;
    }
    
    public Node getChildB() {
      return this.mChildB;
    }
    
    public BlackPawnTextureAtlasBuilder.Rect getRect() {
      return this.mRect;
    }
    
    public Node insert(ITextureAtlasSource param1ITextureAtlasSource, int param1Int1, int param1Int2, int param1Int3, int param1Int4) throws IllegalArgumentException {
      if (this.mChildA != null && this.mChildB != null) {
        Node node = this.mChildA.insert(param1ITextureAtlasSource, param1Int1, param1Int2, param1Int3, param1Int4);
        return (node != null) ? node : this.mChildB.insert(param1ITextureAtlasSource, param1Int1, param1Int2, param1Int3, param1Int4);
      } 
      if (this.mTextureAtlasSource != null)
        return null; 
      int i = param1ITextureAtlasSource.getTextureWidth() + param1Int4 * 2;
      int j = param1ITextureAtlasSource.getTextureHeight() + param1Int4 * 2;
      int k = this.mRect.getWidth();
      int m = this.mRect.getHeight();
      if (i > k || j > m)
        return null; 
      int n = i + param1Int3;
      int i1 = j + param1Int3;
      int i2 = this.mRect.getLeft();
      int i3 = this.mRect.getTop();
      if (j == m && i3 + j == param1Int2) {
        i3 = 1;
      } else {
        i3 = 0;
      } 
      if (i == k && i2 + i == param1Int1) {
        i2 = 1;
      } else {
        i2 = 0;
      } 
      if (n == k) {
        if (i1 == m) {
          this.mTextureAtlasSource = param1ITextureAtlasSource;
          return this;
        } 
        if (i3 != 0) {
          this.mTextureAtlasSource = param1ITextureAtlasSource;
          return this;
        } 
      } 
      if (i2 != 0) {
        if (i1 == m) {
          this.mTextureAtlasSource = param1ITextureAtlasSource;
          return this;
        } 
        if (i3 != 0) {
          this.mTextureAtlasSource = param1ITextureAtlasSource;
          return this;
        } 
        return (i1 > m) ? null : createChildren(param1ITextureAtlasSource, param1Int1, param1Int2, param1Int3, param1Int4, k - i, m - i1);
      } 
      if (i3 != 0) {
        if (n == k) {
          this.mTextureAtlasSource = param1ITextureAtlasSource;
          return this;
        } 
        return (n > k) ? null : createChildren(param1ITextureAtlasSource, param1Int1, param1Int2, param1Int3, param1Int4, k - n, m - j);
      } 
      return (n > k || i1 > m) ? null : createChildren(param1ITextureAtlasSource, param1Int1, param1Int2, param1Int3, param1Int4, k - n, m - i1);
    }
  }
  
  protected static class Rect {
    private final int mHeight;
    
    private final int mLeft;
    
    private final int mTop;
    
    private final int mWidth;
    
    public Rect(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.mLeft = param1Int1;
      this.mTop = param1Int2;
      this.mWidth = param1Int3;
      this.mHeight = param1Int4;
    }
    
    public int getBottom() {
      return this.mTop + this.mHeight;
    }
    
    public int getHeight() {
      return this.mHeight;
    }
    
    public int getLeft() {
      return this.mLeft;
    }
    
    public int getRight() {
      return this.mLeft + this.mWidth;
    }
    
    public int getTop() {
      return this.mTop;
    }
    
    public int getWidth() {
      return this.mWidth;
    }
    
    public String toString() {
      return "@: " + this.mLeft + "/" + this.mTop + " * " + this.mWidth + "x" + this.mHeight;
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/buildable/builder/BlackPawnTextureAtlasBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */