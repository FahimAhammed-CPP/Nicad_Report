package org.andengine.opengl.texture.atlas.buildable;

import java.io.IOException;
import java.util.ArrayList;
import org.andengine.opengl.texture.ITextureStateListener;
import org.andengine.opengl.texture.PixelFormat;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.atlas.ITextureAtlas;
import org.andengine.opengl.texture.atlas.buildable.builder.ITextureAtlasBuilder;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;
import org.andengine.opengl.util.GLState;
import org.andengine.util.call.Callback;

public class BuildableTextureAtlas<S extends ITextureAtlasSource, T extends ITextureAtlas<S>> implements IBuildableTextureAtlas<S, T> {
  private final T mTextureAtlas;
  
  private final ArrayList<TextureAtlasSourceWithWithLocationCallback<S>> mTextureAtlasSourcesToPlace = new ArrayList<TextureAtlasSourceWithWithLocationCallback<S>>();
  
  public BuildableTextureAtlas(T paramT) {
    this.mTextureAtlas = paramT;
  }
  
  public void addEmptyTextureAtlasSource(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mTextureAtlas.addEmptyTextureAtlasSource(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void addTextureAtlasSource(S paramS, int paramInt1, int paramInt2) {
    this.mTextureAtlas.addTextureAtlasSource((ITextureAtlasSource)paramS, paramInt1, paramInt2);
  }
  
  @Deprecated
  public void addTextureAtlasSource(S paramS, int paramInt1, int paramInt2, int paramInt3) {
    this.mTextureAtlas.addTextureAtlasSource((ITextureAtlasSource)paramS, paramInt1, paramInt2, paramInt3);
  }
  
  public void addTextureAtlasSource(S paramS, Callback<S> paramCallback) {
    this.mTextureAtlasSourcesToPlace.add(new TextureAtlasSourceWithWithLocationCallback<S>(paramS, paramCallback));
  }
  
  public void bind(GLState paramGLState) {
    this.mTextureAtlas.bind(paramGLState);
  }
  
  public void bind(GLState paramGLState, int paramInt) {
    this.mTextureAtlas.bind(paramGLState, paramInt);
  }
  
  public IBuildableTextureAtlas<S, T> build(ITextureAtlasBuilder<S, T> paramITextureAtlasBuilder) throws ITextureAtlasBuilder.TextureAtlasBuilderException {
    paramITextureAtlasBuilder.build((ITextureAtlas)this.mTextureAtlas, this.mTextureAtlasSourcesToPlace);
    this.mTextureAtlasSourcesToPlace.clear();
    this.mTextureAtlas.setUpdateOnHardwareNeeded(true);
    return this;
  }
  
  public void clearTextureAtlasSources() {
    this.mTextureAtlas.clearTextureAtlasSources();
    this.mTextureAtlasSourcesToPlace.clear();
  }
  
  public int getHardwareTextureID() {
    return this.mTextureAtlas.getHardwareTextureID();
  }
  
  public int getHeight() {
    return this.mTextureAtlas.getHeight();
  }
  
  public PixelFormat getPixelFormat() {
    return this.mTextureAtlas.getPixelFormat();
  }
  
  public ITextureAtlas.ITextureAtlasStateListener<S> getTextureAtlasStateListener() {
    return this.mTextureAtlas.getTextureAtlasStateListener();
  }
  
  public TextureOptions getTextureOptions() {
    return this.mTextureAtlas.getTextureOptions();
  }
  
  @Deprecated
  public ITextureAtlas.ITextureAtlasStateListener<S> getTextureStateListener() {
    return this.mTextureAtlas.getTextureStateListener();
  }
  
  public int getWidth() {
    return this.mTextureAtlas.getWidth();
  }
  
  public boolean hasTextureAtlasStateListener() {
    return this.mTextureAtlas.hasTextureAtlasStateListener();
  }
  
  @Deprecated
  public boolean hasTextureStateListener() {
    return this.mTextureAtlas.hasTextureStateListener();
  }
  
  public boolean isLoadedToHardware() {
    return this.mTextureAtlas.isLoadedToHardware();
  }
  
  public boolean isUpdateOnHardwareNeeded() {
    return this.mTextureAtlas.isUpdateOnHardwareNeeded();
  }
  
  public void load() {
    this.mTextureAtlas.load();
  }
  
  public void load(GLState paramGLState) throws IOException {
    this.mTextureAtlas.load(paramGLState);
  }
  
  public void loadToHardware(GLState paramGLState) throws IOException {
    this.mTextureAtlas.loadToHardware(paramGLState);
  }
  
  public void reloadToHardware(GLState paramGLState) throws IOException {
    this.mTextureAtlas.reloadToHardware(paramGLState);
  }
  
  public void removeTextureAtlasSource(ITextureAtlasSource paramITextureAtlasSource) {
    ArrayList<TextureAtlasSourceWithWithLocationCallback<S>> arrayList = this.mTextureAtlasSourcesToPlace;
    int i = arrayList.size() - 1;
    while (true) {
      if (i >= 0) {
        if ((arrayList.get(i)).mTextureAtlasSource == paramITextureAtlasSource) {
          arrayList.remove(i);
          this.mTextureAtlas.setUpdateOnHardwareNeeded(true);
          return;
        } 
        i--;
        continue;
      } 
      return;
    } 
  }
  
  public void removeTextureAtlasSource(S paramS, int paramInt1, int paramInt2) {
    this.mTextureAtlas.removeTextureAtlasSource((ITextureAtlasSource)paramS, paramInt1, paramInt2);
  }
  
  public void setNotLoadedToHardware() {
    this.mTextureAtlas.setNotLoadedToHardware();
  }
  
  public void setTextureAtlasStateListener(ITextureAtlas.ITextureAtlasStateListener<S> paramITextureAtlasStateListener) {
    this.mTextureAtlas.setTextureAtlasStateListener(paramITextureAtlasStateListener);
  }
  
  @Deprecated
  public void setTextureStateListener(ITextureStateListener paramITextureStateListener) {
    this.mTextureAtlas.setTextureStateListener(paramITextureStateListener);
  }
  
  public void setUpdateOnHardwareNeeded(boolean paramBoolean) {
    this.mTextureAtlas.setUpdateOnHardwareNeeded(paramBoolean);
  }
  
  public void unload() {
    this.mTextureAtlas.unload();
  }
  
  public void unload(GLState paramGLState) {
    this.mTextureAtlas.unload(paramGLState);
  }
  
  public void unloadFromHardware(GLState paramGLState) {
    this.mTextureAtlas.unloadFromHardware(paramGLState);
  }
  
  public static class TextureAtlasSourceWithWithLocationCallback<T extends ITextureAtlasSource> {
    private final Callback<T> mCallback;
    
    private final T mTextureAtlasSource;
    
    public TextureAtlasSourceWithWithLocationCallback(T param1T, Callback<T> param1Callback) {
      this.mTextureAtlasSource = param1T;
      this.mCallback = param1Callback;
    }
    
    public Callback<T> getCallback() {
      return this.mCallback;
    }
    
    public T getTextureAtlasSource() {
      return this.mTextureAtlasSource;
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/buildable/BuildableTextureAtlas.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */