package org.andengine.opengl.texture.atlas.source;

public interface ITextureAtlasSource {
  ITextureAtlasSource deepCopy();
  
  int getTextureHeight();
  
  int getTextureWidth();
  
  int getTextureX();
  
  int getTextureY();
  
  void setTextureHeight(int paramInt);
  
  void setTextureWidth(int paramInt);
  
  void setTextureX(int paramInt);
  
  void setTextureY(int paramInt);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/source/ITextureAtlasSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */