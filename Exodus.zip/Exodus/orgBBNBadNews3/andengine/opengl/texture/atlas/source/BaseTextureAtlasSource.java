package org.andengine.opengl.texture.atlas.source;

public abstract class BaseTextureAtlasSource implements ITextureAtlasSource {
  protected int mTextureHeight;
  
  protected int mTextureWidth;
  
  protected int mTextureX;
  
  protected int mTextureY;
  
  public BaseTextureAtlasSource(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mTextureX = paramInt1;
    this.mTextureY = paramInt2;
    this.mTextureWidth = paramInt3;
    this.mTextureHeight = paramInt4;
  }
  
  public int getTextureHeight() {
    return this.mTextureHeight;
  }
  
  public int getTextureWidth() {
    return this.mTextureWidth;
  }
  
  public int getTextureX() {
    return this.mTextureX;
  }
  
  public int getTextureY() {
    return this.mTextureY;
  }
  
  public void setTextureHeight(int paramInt) {
    this.mTextureHeight = paramInt;
  }
  
  public void setTextureWidth(int paramInt) {
    this.mTextureWidth = paramInt;
  }
  
  public void setTextureX(int paramInt) {
    this.mTextureX = paramInt;
  }
  
  public void setTextureY(int paramInt) {
    this.mTextureY = paramInt;
  }
  
  public String toString() {
    return String.valueOf(getClass().getSimpleName()) + "( " + getTextureWidth() + "x" + getTextureHeight() + " @ " + this.mTextureX + "/" + this.mTextureY + " )";
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/atlas/source/BaseTextureAtlasSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */