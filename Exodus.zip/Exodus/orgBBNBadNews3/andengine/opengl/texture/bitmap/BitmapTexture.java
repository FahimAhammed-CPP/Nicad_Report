package org.andengine.opengl.texture.bitmap;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import java.io.IOException;
import org.andengine.opengl.texture.ITextureStateListener;
import org.andengine.opengl.texture.PixelFormat;
import org.andengine.opengl.texture.Texture;
import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.util.GLState;
import org.andengine.util.StreamUtils;
import org.andengine.util.adt.io.in.IInputStreamOpener;
import org.andengine.util.exception.NullBitmapException;
import org.andengine.util.math.MathUtils;

public class BitmapTexture extends Texture {
  private final BitmapTextureFormat mBitmapTextureFormat;
  
  private final int mHeight;
  
  private final IInputStreamOpener mInputStreamOpener;
  
  private final int mWidth;
  
  public BitmapTexture(TextureManager paramTextureManager, IInputStreamOpener paramIInputStreamOpener) throws IOException {
    this(paramTextureManager, paramIInputStreamOpener, BitmapTextureFormat.RGBA_8888, TextureOptions.DEFAULT, (ITextureStateListener)null);
  }
  
  public BitmapTexture(TextureManager paramTextureManager, IInputStreamOpener paramIInputStreamOpener, TextureOptions paramTextureOptions) throws IOException {
    this(paramTextureManager, paramIInputStreamOpener, BitmapTextureFormat.RGBA_8888, paramTextureOptions, (ITextureStateListener)null);
  }
  
  public BitmapTexture(TextureManager paramTextureManager, IInputStreamOpener paramIInputStreamOpener, BitmapTextureFormat paramBitmapTextureFormat) throws IOException {
    this(paramTextureManager, paramIInputStreamOpener, paramBitmapTextureFormat, TextureOptions.DEFAULT, (ITextureStateListener)null);
  }
  
  public BitmapTexture(TextureManager paramTextureManager, IInputStreamOpener paramIInputStreamOpener, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions) throws IOException {
    this(paramTextureManager, paramIInputStreamOpener, paramBitmapTextureFormat, paramTextureOptions, (ITextureStateListener)null);
  }
  
  public BitmapTexture(TextureManager paramTextureManager, IInputStreamOpener paramIInputStreamOpener, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions, ITextureStateListener paramITextureStateListener) throws IOException {
    super(paramTextureManager, paramBitmapTextureFormat.getPixelFormat(), paramTextureOptions, paramITextureStateListener);
    this.mInputStreamOpener = paramIInputStreamOpener;
    this.mBitmapTextureFormat = paramBitmapTextureFormat;
    null = new BitmapFactory.Options();
    null.inJustDecodeBounds = true;
    try {
      BitmapFactory.decodeStream(paramIInputStreamOpener.open(), null, null);
      StreamUtils.close(null);
      this.mWidth = null.outWidth;
      return;
    } finally {
      StreamUtils.close(null);
    } 
  }
  
  public int getHeight() {
    return this.mHeight;
  }
  
  public int getWidth() {
    return this.mWidth;
  }
  
  protected Bitmap onGetBitmap(Bitmap.Config paramConfig) throws IOException {
    BitmapFactory.Options options = new BitmapFactory.Options();
    options.inPreferredConfig = paramConfig;
    return BitmapFactory.decodeStream(this.mInputStreamOpener.open(), null, options);
  }
  
  protected void writeTextureToHardware(GLState paramGLState) throws IOException {
    boolean bool;
    Bitmap bitmap = onGetBitmap(this.mBitmapTextureFormat.getBitmapConfig());
    if (bitmap == null)
      throw new NullBitmapException("Caused by: '" + toString() + "'."); 
    if (MathUtils.isPowerOfTwo(bitmap.getWidth()) && MathUtils.isPowerOfTwo(bitmap.getHeight()) && this.mPixelFormat == PixelFormat.RGBA_8888) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool)
      GLES20.glPixelStorei(3317, 1); 
    if (this.mTextureOptions.mPreMultiplyAlpha) {
      GLUtils.texImage2D(3553, 0, bitmap, 0);
    } else {
      paramGLState.glTexImage2D(3553, 0, bitmap, 0, this.mPixelFormat);
    } 
    if (!bool)
      GLES20.glPixelStorei(3317, 4); 
    bitmap.recycle();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/bitmap/BitmapTexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */