package org.andengine.opengl.texture.bitmap;

import android.graphics.Bitmap;
import org.andengine.opengl.texture.PixelFormat;

public enum BitmapTextureFormat {
  A_8,
  RGBA_4444,
  RGBA_8888(Bitmap.Config.ARGB_8888, PixelFormat.RGBA_8888),
  RGB_565(Bitmap.Config.RGB_565, PixelFormat.RGB_565);
  
  private final Bitmap.Config mBitmapConfig;
  
  private final PixelFormat mPixelFormat;
  
  static {
    RGBA_4444 = new BitmapTextureFormat("RGBA_4444", 2, Bitmap.Config.ARGB_4444, PixelFormat.RGBA_4444);
    A_8 = new BitmapTextureFormat("A_8", 3, Bitmap.Config.ALPHA_8, PixelFormat.A_8);
    ENUM$VALUES = new BitmapTextureFormat[] { RGBA_8888, RGB_565, RGBA_4444, A_8 };
  }
  
  BitmapTextureFormat(Bitmap.Config paramConfig, PixelFormat paramPixelFormat) {
    this.mBitmapConfig = paramConfig;
    this.mPixelFormat = paramPixelFormat;
  }
  
  public static BitmapTextureFormat fromPixelFormat(PixelFormat paramPixelFormat) {
    switch (paramPixelFormat) {
      default:
        throw new IllegalArgumentException("Unsupported " + PixelFormat.class.getName() + ": '" + paramPixelFormat + "'.");
      case null:
        return RGBA_8888;
      case null:
        return RGBA_4444;
      case null:
        return RGB_565;
      case null:
        break;
    } 
    return A_8;
  }
  
  public Bitmap.Config getBitmapConfig() {
    return this.mBitmapConfig;
  }
  
  public PixelFormat getPixelFormat() {
    return this.mPixelFormat;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/bitmap/BitmapTextureFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */