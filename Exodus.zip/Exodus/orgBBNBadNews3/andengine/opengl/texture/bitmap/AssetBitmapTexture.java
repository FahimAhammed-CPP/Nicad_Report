package org.andengine.opengl.texture.bitmap;

import android.content.res.AssetManager;
import java.io.IOException;
import org.andengine.opengl.texture.ITextureStateListener;
import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.util.adt.io.in.AssetInputStreamOpener;
import org.andengine.util.adt.io.in.IInputStreamOpener;

public class AssetBitmapTexture extends BitmapTexture {
  public AssetBitmapTexture(TextureManager paramTextureManager, AssetManager paramAssetManager, String paramString) throws IOException {
    super(paramTextureManager, (IInputStreamOpener)new AssetInputStreamOpener(paramAssetManager, paramString));
  }
  
  public AssetBitmapTexture(TextureManager paramTextureManager, AssetManager paramAssetManager, String paramString, TextureOptions paramTextureOptions) throws IOException {
    super(paramTextureManager, (IInputStreamOpener)new AssetInputStreamOpener(paramAssetManager, paramString), paramTextureOptions);
  }
  
  public AssetBitmapTexture(TextureManager paramTextureManager, AssetManager paramAssetManager, String paramString, BitmapTextureFormat paramBitmapTextureFormat) throws IOException {
    super(paramTextureManager, (IInputStreamOpener)new AssetInputStreamOpener(paramAssetManager, paramString), paramBitmapTextureFormat);
  }
  
  public AssetBitmapTexture(TextureManager paramTextureManager, AssetManager paramAssetManager, String paramString, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions) throws IOException {
    super(paramTextureManager, (IInputStreamOpener)new AssetInputStreamOpener(paramAssetManager, paramString), paramBitmapTextureFormat, paramTextureOptions);
  }
  
  public AssetBitmapTexture(TextureManager paramTextureManager, AssetManager paramAssetManager, String paramString, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions, ITextureStateListener paramITextureStateListener) throws IOException {
    super(paramTextureManager, (IInputStreamOpener)new AssetInputStreamOpener(paramAssetManager, paramString), paramBitmapTextureFormat, paramTextureOptions, paramITextureStateListener);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/bitmap/AssetBitmapTexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */