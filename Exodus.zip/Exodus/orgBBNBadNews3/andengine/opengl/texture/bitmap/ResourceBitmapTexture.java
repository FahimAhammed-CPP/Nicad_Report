package org.andengine.opengl.texture.bitmap;

import android.content.res.Resources;
import java.io.IOException;
import org.andengine.opengl.texture.ITextureStateListener;
import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.util.adt.io.in.IInputStreamOpener;
import org.andengine.util.adt.io.in.ResourceInputStreamOpener;

public class ResourceBitmapTexture extends BitmapTexture {
  public ResourceBitmapTexture(TextureManager paramTextureManager, Resources paramResources, int paramInt) throws IOException {
    super(paramTextureManager, (IInputStreamOpener)new ResourceInputStreamOpener(paramResources, paramInt));
  }
  
  public ResourceBitmapTexture(TextureManager paramTextureManager, Resources paramResources, int paramInt, TextureOptions paramTextureOptions) throws IOException {
    super(paramTextureManager, (IInputStreamOpener)new ResourceInputStreamOpener(paramResources, paramInt), paramTextureOptions);
  }
  
  public ResourceBitmapTexture(TextureManager paramTextureManager, Resources paramResources, int paramInt, BitmapTextureFormat paramBitmapTextureFormat) throws IOException {
    super(paramTextureManager, (IInputStreamOpener)new ResourceInputStreamOpener(paramResources, paramInt), paramBitmapTextureFormat);
  }
  
  public ResourceBitmapTexture(TextureManager paramTextureManager, Resources paramResources, int paramInt, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions) throws IOException {
    super(paramTextureManager, (IInputStreamOpener)new ResourceInputStreamOpener(paramResources, paramInt), paramBitmapTextureFormat, paramTextureOptions);
  }
  
  public ResourceBitmapTexture(TextureManager paramTextureManager, Resources paramResources, int paramInt, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions, ITextureStateListener paramITextureStateListener) throws IOException {
    super(paramTextureManager, (IInputStreamOpener)new ResourceInputStreamOpener(paramResources, paramInt), paramBitmapTextureFormat, paramTextureOptions, paramITextureStateListener);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/bitmap/ResourceBitmapTexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */