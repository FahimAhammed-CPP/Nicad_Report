package org.andengine.opengl.texture;

import android.opengl.GLES20;

public class TextureOptions {
  public static final TextureOptions BILINEAR;
  
  public static final TextureOptions BILINEAR_PREMULTIPLYALPHA;
  
  public static final TextureOptions DEFAULT;
  
  public static final TextureOptions NEAREST = new TextureOptions(9728, 9728, 33071, 33071, false);
  
  public static final TextureOptions NEAREST_PREMULTIPLYALPHA;
  
  public static final TextureOptions REPEATING_BILINEAR;
  
  public static final TextureOptions REPEATING_BILINEAR_PREMULTIPLYALPHA;
  
  public static final TextureOptions REPEATING_NEAREST;
  
  public static final TextureOptions REPEATING_NEAREST_PREMULTIPLYALPHA;
  
  public final int mMagFilter;
  
  public final int mMinFilter;
  
  public final boolean mPreMultiplyAlpha;
  
  public final float mWrapS;
  
  public final float mWrapT;
  
  static {
    BILINEAR = new TextureOptions(9729, 9729, 33071, 33071, false);
    REPEATING_NEAREST = new TextureOptions(9728, 9728, 10497, 10497, false);
    REPEATING_BILINEAR = new TextureOptions(9729, 9729, 10497, 10497, false);
    NEAREST_PREMULTIPLYALPHA = new TextureOptions(9728, 9728, 33071, 33071, true);
    BILINEAR_PREMULTIPLYALPHA = new TextureOptions(9729, 9729, 33071, 33071, true);
    REPEATING_NEAREST_PREMULTIPLYALPHA = new TextureOptions(9728, 9728, 10497, 10497, true);
    REPEATING_BILINEAR_PREMULTIPLYALPHA = new TextureOptions(9729, 9729, 10497, 10497, true);
    DEFAULT = NEAREST;
  }
  
  public TextureOptions(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    this.mMinFilter = paramInt1;
    this.mMagFilter = paramInt2;
    this.mWrapT = paramInt3;
    this.mWrapS = paramInt4;
    this.mPreMultiplyAlpha = paramBoolean;
  }
  
  public void apply() {
    GLES20.glTexParameterf(3553, 10241, this.mMinFilter);
    GLES20.glTexParameterf(3553, 10240, this.mMagFilter);
    GLES20.glTexParameterf(3553, 10242, this.mWrapS);
    GLES20.glTexParameterf(3553, 10243, this.mWrapT);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/TextureOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */