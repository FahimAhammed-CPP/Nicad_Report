package org.andengine.opengl.texture.region;

import org.andengine.opengl.texture.ITexture;
import org.andengine.opengl.texture.atlas.ITextureAtlas;
import org.andengine.opengl.texture.atlas.source.ITextureAtlasSource;

public class TextureRegionFactory {
  public static <T extends ITextureAtlasSource> TextureRegion createFromSource(ITextureAtlas<T> paramITextureAtlas, T paramT, int paramInt1, int paramInt2) {
    return createFromSource(paramITextureAtlas, paramT, paramInt1, paramInt2, false);
  }
  
  public static <T extends ITextureAtlasSource> TextureRegion createFromSource(ITextureAtlas<T> paramITextureAtlas, T paramT, int paramInt1, int paramInt2, boolean paramBoolean) {
    TextureRegion textureRegion = new TextureRegion((ITexture)paramITextureAtlas, paramInt1, paramInt2, paramT.getTextureWidth(), paramT.getTextureHeight(), paramBoolean);
    paramITextureAtlas.addTextureAtlasSource((ITextureAtlasSource)paramT, paramInt1, paramInt2);
    return textureRegion;
  }
  
  public static <T extends ITextureAtlasSource> TiledTextureRegion createTiledFromSource(ITextureAtlas<T> paramITextureAtlas, T paramT, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return createTiledFromSource(paramITextureAtlas, paramT, paramInt1, paramInt2, paramInt3, paramInt4, false);
  }
  
  public static <T extends ITextureAtlasSource> TiledTextureRegion createTiledFromSource(ITextureAtlas<T> paramITextureAtlas, T paramT, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    TiledTextureRegion tiledTextureRegion = TiledTextureRegion.create((ITexture)paramITextureAtlas, paramInt1, paramInt2, paramT.getTextureWidth(), paramT.getTextureHeight(), paramInt3, paramInt4, paramBoolean);
    paramITextureAtlas.addTextureAtlasSource((ITextureAtlasSource)paramT, paramInt1, paramInt2);
    return tiledTextureRegion;
  }
  
  public static TextureRegion extractFromTexture(ITexture paramITexture) {
    return extractFromTexture(paramITexture, false);
  }
  
  public static TextureRegion extractFromTexture(ITexture paramITexture, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return extractFromTexture(paramITexture, paramInt1, paramInt2, paramInt3, paramInt4, false);
  }
  
  public static TextureRegion extractFromTexture(ITexture paramITexture, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
    return new TextureRegion(paramITexture, paramInt1, paramInt2, paramInt3, paramInt4, paramBoolean);
  }
  
  public static TextureRegion extractFromTexture(ITexture paramITexture, boolean paramBoolean) {
    return new TextureRegion(paramITexture, 0.0F, 0.0F, paramITexture.getWidth(), paramITexture.getHeight(), paramBoolean);
  }
  
  public static TiledTextureRegion extractTiledFromTexture(ITexture paramITexture, int paramInt1, int paramInt2) {
    return TiledTextureRegion.create(paramITexture, 0, 0, paramITexture.getWidth(), paramITexture.getHeight(), paramInt1, paramInt2);
  }
  
  public static TiledTextureRegion extractTiledFromTexture(ITexture paramITexture, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    return TiledTextureRegion.create(paramITexture, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/region/TextureRegionFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */