package org.andengine.opengl.texture.region;

import org.andengine.opengl.texture.ITexture;

public class TextureRegion extends BaseTextureRegion {
  private static final float SCALE_DEFAULT = 1.0F;
  
  protected final boolean mRotated;
  
  protected final float mScale;
  
  protected float mTextureHeight;
  
  protected float mTextureWidth;
  
  protected float mTextureX;
  
  protected float mTextureY;
  
  protected float mU;
  
  protected float mU2;
  
  protected float mV;
  
  protected float mV2;
  
  public TextureRegion(ITexture paramITexture, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this(paramITexture, paramFloat1, paramFloat2, paramFloat3, paramFloat4, false);
  }
  
  public TextureRegion(ITexture paramITexture, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5) {
    this(paramITexture, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, false);
  }
  
  public TextureRegion(ITexture paramITexture, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, boolean paramBoolean) {
    super(paramITexture);
    this.mTextureX = paramFloat1;
    this.mTextureY = paramFloat2;
    if (paramBoolean) {
      this.mRotated = true;
      this.mTextureWidth = paramFloat4;
      this.mTextureHeight = paramFloat3;
    } else {
      this.mRotated = false;
      this.mTextureWidth = paramFloat3;
      this.mTextureHeight = paramFloat4;
    } 
    this.mScale = paramFloat5;
    updateUV();
  }
  
  public TextureRegion(ITexture paramITexture, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, boolean paramBoolean) {
    this(paramITexture, paramFloat1, paramFloat2, paramFloat3, paramFloat4, 1.0F, paramBoolean);
  }
  
  public TextureRegion deepCopy() {
    return this.mRotated ? new TextureRegion(this.mTexture, this.mTextureX, this.mTextureY, this.mTextureHeight, this.mTextureWidth, this.mScale, this.mRotated) : new TextureRegion(this.mTexture, this.mTextureX, this.mTextureY, this.mTextureWidth, this.mTextureHeight, this.mScale, this.mRotated);
  }
  
  public float getHeight() {
    return this.mRotated ? (this.mTextureWidth * this.mScale) : (this.mTextureHeight * this.mScale);
  }
  
  public float getScale() {
    return this.mScale;
  }
  
  public float getTextureX() {
    return this.mTextureX;
  }
  
  public float getTextureY() {
    return this.mTextureY;
  }
  
  public float getU() {
    return this.mU;
  }
  
  public float getU2() {
    return this.mU2;
  }
  
  public float getV() {
    return this.mV;
  }
  
  public float getV2() {
    return this.mV2;
  }
  
  public float getWidth() {
    return this.mRotated ? (this.mTextureHeight * this.mScale) : (this.mTextureWidth * this.mScale);
  }
  
  public boolean isRotated() {
    return this.mRotated;
  }
  
  public boolean isScaled() {
    return (this.mScale != 1.0F);
  }
  
  public void set(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.mTextureX = paramFloat1;
    this.mTextureY = paramFloat2;
    this.mTextureWidth = paramFloat3;
    this.mTextureHeight = paramFloat4;
    updateUV();
  }
  
  public void setTextureHeight(float paramFloat) {
    this.mTextureHeight = paramFloat;
    updateUV();
  }
  
  public void setTexturePosition(float paramFloat1, float paramFloat2) {
    this.mTextureX = paramFloat1;
    this.mTextureY = paramFloat2;
    updateUV();
  }
  
  public void setTextureSize(float paramFloat1, float paramFloat2) {
    this.mTextureWidth = paramFloat1;
    this.mTextureHeight = paramFloat2;
    updateUV();
  }
  
  public void setTextureWidth(float paramFloat) {
    this.mTextureWidth = paramFloat;
    updateUV();
  }
  
  public void setTextureX(float paramFloat) {
    this.mTextureX = paramFloat;
    updateUV();
  }
  
  public void setTextureY(float paramFloat) {
    this.mTextureY = paramFloat;
    updateUV();
  }
  
  public void updateUV() {
    ITexture iTexture = this.mTexture;
    float f1 = iTexture.getWidth();
    float f2 = iTexture.getHeight();
    float f3 = getTextureX();
    float f4 = getTextureY();
    this.mU = f3 / f1;
    this.mU2 = (this.mTextureWidth + f3) / f1;
    this.mV = f4 / f2;
    this.mV2 = (this.mTextureHeight + f4) / f2;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/region/TextureRegion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */