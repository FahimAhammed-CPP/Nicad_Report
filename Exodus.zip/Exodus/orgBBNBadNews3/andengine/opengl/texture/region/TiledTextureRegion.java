package org.andengine.opengl.texture.region;

import org.andengine.opengl.texture.ITexture;

public class TiledTextureRegion extends BaseTextureRegion implements ITiledTextureRegion {
  protected int mCurrentTileIndex;
  
  protected final ITextureRegion[] mTextureRegions;
  
  protected final int mTileCount;
  
  public TiledTextureRegion(ITexture paramITexture, boolean paramBoolean, ITextureRegion... paramVarArgs) {
    super(paramITexture);
    this.mTextureRegions = paramVarArgs;
    this.mTileCount = this.mTextureRegions.length;
    if (paramBoolean) {
      int i = this.mTileCount - 1;
      while (true) {
        if (i >= 0) {
          if (paramVarArgs[i].getTexture() != paramITexture)
            throw new IllegalArgumentException("The " + ITextureRegion.class.getSimpleName() + ": '" + paramVarArgs[i].toString() + "' at index: '" + i + "' is not on the same " + ITexture.class.getSimpleName() + ": '" + paramVarArgs[i].getTexture().toString() + "' as the supplied " + ITexture.class.getSimpleName() + ": '" + paramITexture.toString() + "'."); 
          i--;
          continue;
        } 
        return;
      } 
    } 
  }
  
  public TiledTextureRegion(ITexture paramITexture, ITextureRegion... paramVarArgs) {
    this(paramITexture, true, paramVarArgs);
  }
  
  public static TiledTextureRegion create(ITexture paramITexture, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
    return create(paramITexture, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, false);
  }
  
  public static TiledTextureRegion create(ITexture paramITexture, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean) {
    ITextureRegion[] arrayOfITextureRegion = new ITextureRegion[paramInt5 * paramInt6];
    int i = paramInt3 / paramInt5;
    int j = paramInt4 / paramInt6;
    paramInt3 = 0;
    label12: while (true) {
      if (paramInt3 >= paramInt5)
        return new TiledTextureRegion(paramITexture, false, arrayOfITextureRegion); 
      for (paramInt4 = 0;; paramInt4++) {
        if (paramInt4 >= paramInt6) {
          paramInt3++;
          continue label12;
        } 
        arrayOfITextureRegion[paramInt4 * paramInt5 + paramInt3] = new TextureRegion(paramITexture, (paramInt1 + paramInt3 * i), (paramInt2 + paramInt4 * j), i, j, paramBoolean);
      } 
      break;
    } 
  }
  
  public TiledTextureRegion deepCopy() {
    int i = this.mTileCount;
    ITextureRegion[] arrayOfITextureRegion = new ITextureRegion[i];
    for (byte b = 0;; b++) {
      if (b >= i)
        return new TiledTextureRegion(this.mTexture, false, arrayOfITextureRegion); 
      arrayOfITextureRegion[b] = this.mTextureRegions[b].deepCopy();
    } 
  }
  
  public int getCurrentTileIndex() {
    return this.mCurrentTileIndex;
  }
  
  public float getHeight() {
    return this.mTextureRegions[this.mCurrentTileIndex].getHeight();
  }
  
  public float getHeight(int paramInt) {
    return this.mTextureRegions[paramInt].getHeight();
  }
  
  public float getScale() {
    return this.mTextureRegions[this.mCurrentTileIndex].getScale();
  }
  
  public float getScale(int paramInt) {
    return this.mTextureRegions[paramInt].getScale();
  }
  
  public ITextureRegion getTextureRegion(int paramInt) {
    return this.mTextureRegions[paramInt];
  }
  
  public float getTextureX() {
    return this.mTextureRegions[this.mCurrentTileIndex].getTextureX();
  }
  
  public float getTextureX(int paramInt) {
    return this.mTextureRegions[paramInt].getTextureX();
  }
  
  public float getTextureY() {
    return this.mTextureRegions[this.mCurrentTileIndex].getTextureY();
  }
  
  public float getTextureY(int paramInt) {
    return this.mTextureRegions[paramInt].getTextureY();
  }
  
  public int getTileCount() {
    return this.mTileCount;
  }
  
  public float getU() {
    return this.mTextureRegions[this.mCurrentTileIndex].getU();
  }
  
  public float getU(int paramInt) {
    return this.mTextureRegions[paramInt].getU();
  }
  
  public float getU2() {
    return this.mTextureRegions[this.mCurrentTileIndex].getU2();
  }
  
  public float getU2(int paramInt) {
    return this.mTextureRegions[paramInt].getU2();
  }
  
  public float getV() {
    return this.mTextureRegions[this.mCurrentTileIndex].getV();
  }
  
  public float getV(int paramInt) {
    return this.mTextureRegions[paramInt].getV();
  }
  
  public float getV2() {
    return this.mTextureRegions[this.mCurrentTileIndex].getV2();
  }
  
  public float getV2(int paramInt) {
    return this.mTextureRegions[paramInt].getV2();
  }
  
  public float getWidth() {
    return this.mTextureRegions[this.mCurrentTileIndex].getWidth();
  }
  
  public float getWidth(int paramInt) {
    return this.mTextureRegions[paramInt].getWidth();
  }
  
  public boolean isRotated() {
    return this.mTextureRegions[this.mCurrentTileIndex].isRotated();
  }
  
  public boolean isRotated(int paramInt) {
    return this.mTextureRegions[paramInt].isRotated();
  }
  
  public boolean isScaled() {
    return this.mTextureRegions[this.mCurrentTileIndex].isScaled();
  }
  
  public boolean isScaled(int paramInt) {
    return this.mTextureRegions[paramInt].isScaled();
  }
  
  public void nextTile() {
    this.mCurrentTileIndex++;
    if (this.mCurrentTileIndex >= this.mTileCount)
      this.mCurrentTileIndex %= this.mTileCount; 
  }
  
  public void set(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.mTextureRegions[this.mCurrentTileIndex].set(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void set(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.mTextureRegions[paramInt].set(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void setCurrentTileIndex(int paramInt) {
    this.mCurrentTileIndex = paramInt;
  }
  
  public void setTextureHeight(float paramFloat) {
    this.mTextureRegions[this.mCurrentTileIndex].setTextureHeight(paramFloat);
  }
  
  public void setTextureHeight(int paramInt, float paramFloat) {
    this.mTextureRegions[paramInt].setTextureHeight(paramFloat);
  }
  
  public void setTexturePosition(float paramFloat1, float paramFloat2) {
    this.mTextureRegions[this.mCurrentTileIndex].setTexturePosition(paramFloat1, paramFloat2);
  }
  
  public void setTexturePosition(int paramInt, float paramFloat1, float paramFloat2) {
    this.mTextureRegions[paramInt].setTexturePosition(paramFloat1, paramFloat2);
  }
  
  public void setTextureSize(float paramFloat1, float paramFloat2) {
    this.mTextureRegions[this.mCurrentTileIndex].setTextureSize(paramFloat1, paramFloat2);
  }
  
  public void setTextureSize(int paramInt, float paramFloat1, float paramFloat2) {
    this.mTextureRegions[paramInt].setTextureSize(paramFloat1, paramFloat2);
  }
  
  public void setTextureWidth(float paramFloat) {
    this.mTextureRegions[this.mCurrentTileIndex].setTextureWidth(paramFloat);
  }
  
  public void setTextureWidth(int paramInt, float paramFloat) {
    this.mTextureRegions[paramInt].setTextureWidth(paramFloat);
  }
  
  public void setTextureX(float paramFloat) {
    this.mTextureRegions[this.mCurrentTileIndex].setTextureX(paramFloat);
  }
  
  public void setTextureX(int paramInt, float paramFloat) {
    this.mTextureRegions[paramInt].setTextureY(paramFloat);
  }
  
  public void setTextureY(float paramFloat) {
    this.mTextureRegions[this.mCurrentTileIndex].setTextureY(paramFloat);
  }
  
  public void setTextureY(int paramInt, float paramFloat) {
    this.mTextureRegions[paramInt].setTextureY(paramFloat);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/region/TiledTextureRegion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */