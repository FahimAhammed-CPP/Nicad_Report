package org.andengine.opengl.texture.region;

public interface ITiledTextureRegion extends ITextureRegion {
  ITiledTextureRegion deepCopy();
  
  int getCurrentTileIndex();
  
  float getHeight(int paramInt);
  
  float getScale(int paramInt);
  
  ITextureRegion getTextureRegion(int paramInt);
  
  float getTextureX(int paramInt);
  
  float getTextureY(int paramInt);
  
  int getTileCount();
  
  float getU(int paramInt);
  
  float getU2(int paramInt);
  
  float getV(int paramInt);
  
  float getV2(int paramInt);
  
  float getWidth(int paramInt);
  
  boolean isRotated(int paramInt);
  
  boolean isScaled(int paramInt);
  
  void nextTile();
  
  void set(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  
  void setCurrentTileIndex(int paramInt);
  
  void setTextureHeight(int paramInt, float paramFloat);
  
  void setTexturePosition(int paramInt, float paramFloat1, float paramFloat2);
  
  void setTextureSize(int paramInt, float paramFloat1, float paramFloat2);
  
  void setTextureWidth(int paramInt, float paramFloat);
  
  void setTextureX(int paramInt, float paramFloat);
  
  void setTextureY(int paramInt, float paramFloat);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/region/ITiledTextureRegion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */