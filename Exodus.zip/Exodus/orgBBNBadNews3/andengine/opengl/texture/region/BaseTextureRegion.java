package org.andengine.opengl.texture.region;

import org.andengine.opengl.texture.ITexture;

public abstract class BaseTextureRegion implements ITextureRegion {
  protected final ITexture mTexture;
  
  public BaseTextureRegion(ITexture paramITexture) {
    this.mTexture = paramITexture;
  }
  
  public abstract ITextureRegion deepCopy();
  
  public ITexture getTexture() {
    return this.mTexture;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/region/BaseTextureRegion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */