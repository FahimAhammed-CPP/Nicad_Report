package org.andengine.opengl.texture.region;

import org.andengine.util.adt.map.Library;

public class TextureRegionLibrary extends Library<ITextureRegion> {
  public TextureRegionLibrary(int paramInt) {
    super(paramInt);
  }
  
  public TextureRegion get(int paramInt) {
    return (TextureRegion)super.get(paramInt);
  }
  
  public TiledTextureRegion getTiled(int paramInt) {
    return (TiledTextureRegion)this.mItems.get(paramInt);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/region/TextureRegionLibrary.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */