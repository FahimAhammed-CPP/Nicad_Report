package org.andengine.opengl.texture.region;

import org.andengine.opengl.texture.ITexture;

public interface ITextureRegion {
  ITextureRegion deepCopy();
  
  float getHeight();
  
  float getScale();
  
  ITexture getTexture();
  
  float getTextureX();
  
  float getTextureY();
  
  float getU();
  
  float getU2();
  
  float getV();
  
  float getV2();
  
  float getWidth();
  
  boolean isRotated();
  
  boolean isScaled();
  
  void set(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  
  void setTextureHeight(float paramFloat);
  
  void setTexturePosition(float paramFloat1, float paramFloat2);
  
  void setTextureSize(float paramFloat1, float paramFloat2);
  
  void setTextureWidth(float paramFloat);
  
  void setTextureX(float paramFloat);
  
  void setTextureY(float paramFloat);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/region/ITextureRegion.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */