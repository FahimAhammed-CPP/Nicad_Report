package org.andengine.opengl.texture.compressed.pvr.pixelbufferstrategy;

import android.opengl.GLES20;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.andengine.opengl.texture.PixelFormat;
import org.andengine.opengl.texture.compressed.pvr.PVRTexture;
import org.andengine.util.StreamUtils;
import org.andengine.util.exception.AndEngineRuntimeException;

public class SmartPVRTexturePixelBufferStrategy implements IPVRTexturePixelBufferStrategy {
  private final int mAllocationSizeMaximum;
  
  public SmartPVRTexturePixelBufferStrategy(int paramInt) {
    this.mAllocationSizeMaximum = paramInt;
  }
  
  public void loadPVRTextureData(IPVRTexturePixelBufferStrategy.IPVRTexturePixelBufferStrategyBufferManager paramIPVRTexturePixelBufferStrategyBufferManager, int paramInt1, int paramInt2, int paramInt3, PixelFormat paramPixelFormat, int paramInt4, int paramInt5, int paramInt6) throws IOException {
    paramInt6 = paramPixelFormat.getGLFormat();
    int i = paramPixelFormat.getGLType();
    GLES20.glTexImage2D(3553, paramInt4, paramPixelFormat.getGLInternalFormat(), paramInt1, paramInt2, 0, paramInt6, i, null);
    int j = paramInt1 * paramInt3;
    int k = Math.max(1, this.mAllocationSizeMaximum / j);
    for (paramInt3 = 0;; paramInt3 += m) {
      if (paramInt3 >= paramInt2)
        return; 
      int m = Math.min(paramInt2 - paramInt3, k);
      int n = m * j;
      GLES20.glTexSubImage2D(3553, paramInt4, 0, paramInt3, paramInt1, m, paramInt6, i, paramIPVRTexturePixelBufferStrategyBufferManager.getPixelBuffer(paramInt5 + 52, n));
      paramInt5 += n;
    } 
  }
  
  public IPVRTexturePixelBufferStrategy.IPVRTexturePixelBufferStrategyBufferManager newPVRTexturePixelBufferStrategyManager(PVRTexture paramPVRTexture) throws IOException {
    return new SmartPVRTexturePixelBufferStrategyBufferManager(paramPVRTexture);
  }
  
  public static class SmartPVRTexturePixelBufferStrategyBufferManager implements IPVRTexturePixelBufferStrategy.IPVRTexturePixelBufferStrategyBufferManager {
    private byte[] mData;
    
    private final InputStream mInputStream;
    
    private int mInputStreamPosition;
    
    public SmartPVRTexturePixelBufferStrategyBufferManager(PVRTexture param1PVRTexture) throws IOException {
      this.mInputStream = param1PVRTexture.getInputStream();
    }
    
    public ByteBuffer getPixelBuffer(int param1Int1, int param1Int2) throws IOException {
      if (param1Int1 < this.mInputStreamPosition)
        throw new AndEngineRuntimeException("Cannot read data that has been read already. (pStart: '" + param1Int1 + "', this.mInputStreamPosition: '" + this.mInputStreamPosition + "')"); 
      if (this.mData == null || this.mData.length < param1Int2)
        this.mData = new byte[param1Int2]; 
      if (this.mInputStreamPosition < param1Int1) {
        int i = param1Int1 - this.mInputStreamPosition;
        long l = this.mInputStream.skip(i);
        this.mInputStreamPosition = (int)(this.mInputStreamPosition + l);
        if (i != l)
          throw new AndEngineRuntimeException("Skipped: '" + l + "' instead of '" + i + "'."); 
      } 
      param1Int1 = param1Int1 + param1Int2 - this.mInputStreamPosition;
      StreamUtils.streamToBytes(this.mInputStream, param1Int1, this.mData);
      this.mInputStreamPosition += param1Int1;
      return ByteBuffer.wrap(this.mData, 0, param1Int2);
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/compressed/pvr/pixelbufferstrategy/SmartPVRTexturePixelBufferStrategy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */