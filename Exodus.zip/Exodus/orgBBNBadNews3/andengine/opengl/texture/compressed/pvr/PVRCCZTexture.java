package org.andengine.opengl.texture.compressed.pvr;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.zip.GZIPInputStream;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;
import org.andengine.opengl.texture.ITextureStateListener;
import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.compressed.pvr.pixelbufferstrategy.IPVRTexturePixelBufferStrategy;
import org.andengine.util.StreamUtils;
import org.andengine.util.adt.array.ArrayUtils;

public abstract class PVRCCZTexture extends PVRTexture {
  private CCZHeader mCCZHeader;
  
  public PVRCCZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat);
  }
  
  public PVRCCZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramITextureStateListener);
  }
  
  public PVRCCZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, TextureOptions paramTextureOptions) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramTextureOptions);
  }
  
  public PVRCCZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, TextureOptions paramTextureOptions, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramTextureOptions, paramITextureStateListener);
  }
  
  public PVRCCZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, IPVRTexturePixelBufferStrategy paramIPVRTexturePixelBufferStrategy) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramIPVRTexturePixelBufferStrategy);
  }
  
  public PVRCCZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, IPVRTexturePixelBufferStrategy paramIPVRTexturePixelBufferStrategy, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramIPVRTexturePixelBufferStrategy, paramITextureStateListener);
  }
  
  public PVRCCZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, IPVRTexturePixelBufferStrategy paramIPVRTexturePixelBufferStrategy, TextureOptions paramTextureOptions) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramIPVRTexturePixelBufferStrategy, paramTextureOptions);
  }
  
  public PVRCCZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, IPVRTexturePixelBufferStrategy paramIPVRTexturePixelBufferStrategy, TextureOptions paramTextureOptions, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramIPVRTexturePixelBufferStrategy, paramTextureOptions, paramITextureStateListener);
  }
  
  public final InflaterInputStream getInputStream() throws IOException {
    InputStream inputStream = onGetInputStream();
    this.mCCZHeader = new CCZHeader(StreamUtils.streamToBytes(inputStream, 16));
    return this.mCCZHeader.getCCZCompressionFormat().wrap(inputStream);
  }
  
  public ByteBuffer getPVRTextureBuffer() throws IOException {
    InflaterInputStream inflaterInputStream = getInputStream();
    try {
      byte[] arrayOfByte = new byte[this.mCCZHeader.getUncompressedSize()];
      StreamUtils.copy(inflaterInputStream, arrayOfByte);
      return ByteBuffer.wrap(arrayOfByte);
    } finally {
      StreamUtils.close(inflaterInputStream);
    } 
  }
  
  public enum CCZCompressionFormat {
    BZIP2,
    GZIP,
    NONE,
    ZLIB((short)0);
    
    private final short mID;
    
    static {
      ENUM$VALUES = new CCZCompressionFormat[] { ZLIB, BZIP2, GZIP, NONE };
    }
    
    CCZCompressionFormat(short param1Short) {
      this.mID = (short)param1Short;
    }
    
    public static CCZCompressionFormat fromID(short param1Short) {
      CCZCompressionFormat[] arrayOfCCZCompressionFormat = values();
      int i = arrayOfCCZCompressionFormat.length;
      for (byte b = 0;; b++) {
        if (b >= i)
          throw new IllegalArgumentException("Unexpected " + CCZCompressionFormat.class.getSimpleName() + "-ID: '" + param1Short + "'."); 
        CCZCompressionFormat cCZCompressionFormat = arrayOfCCZCompressionFormat[b];
        if (cCZCompressionFormat.mID == param1Short)
          return cCZCompressionFormat; 
      } 
    }
    
    public InflaterInputStream wrap(InputStream param1InputStream) throws IOException {
      switch (this) {
        default:
          throw new IllegalArgumentException("Unexpected " + CCZCompressionFormat.class.getSimpleName() + ": '" + this + "'.");
        case null:
          return new GZIPInputStream(param1InputStream);
        case null:
          break;
      } 
      return new InflaterInputStream(param1InputStream, new Inflater());
    }
  }
  
  public static class CCZHeader {
    static final byte[] MAGIC_IDENTIFIER = new byte[] { 67, 67, 90, 33 };
    
    public static final int SIZE = 16;
    
    private final PVRCCZTexture.CCZCompressionFormat mCCZCompressionFormat;
    
    private final ByteBuffer mDataByteBuffer;
    
    public CCZHeader(byte[] param1ArrayOfbyte) {
      this.mDataByteBuffer = ByteBuffer.wrap(param1ArrayOfbyte);
      this.mDataByteBuffer.rewind();
      this.mDataByteBuffer.order(ByteOrder.BIG_ENDIAN);
      if (!ArrayUtils.equals(param1ArrayOfbyte, 0, MAGIC_IDENTIFIER, 0, MAGIC_IDENTIFIER.length))
        throw new IllegalArgumentException("Invalid " + getClass().getSimpleName() + "!"); 
      this.mCCZCompressionFormat = PVRCCZTexture.CCZCompressionFormat.fromID(getCCZCompressionFormatID());
    }
    
    private short getCCZCompressionFormatID() {
      return this.mDataByteBuffer.getShort(4);
    }
    
    public PVRCCZTexture.CCZCompressionFormat getCCZCompressionFormat() {
      return this.mCCZCompressionFormat;
    }
    
    public int getUncompressedSize() {
      return this.mDataByteBuffer.getInt(12);
    }
    
    public int getUserdata() {
      return this.mDataByteBuffer.getInt(8);
    }
    
    public short getVersion() {
      return this.mDataByteBuffer.getShort(6);
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/compressed/pvr/PVRCCZTexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */