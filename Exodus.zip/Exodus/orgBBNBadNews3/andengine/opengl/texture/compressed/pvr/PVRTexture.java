package org.andengine.opengl.texture.compressed.pvr;

import android.opengl.GLES20;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.andengine.opengl.texture.ITextureStateListener;
import org.andengine.opengl.texture.PixelFormat;
import org.andengine.opengl.texture.Texture;
import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.compressed.pvr.pixelbufferstrategy.GreedyPVRTexturePixelBufferStrategy;
import org.andengine.opengl.texture.compressed.pvr.pixelbufferstrategy.IPVRTexturePixelBufferStrategy;
import org.andengine.opengl.util.GLState;
import org.andengine.util.StreamUtils;
import org.andengine.util.adt.array.ArrayUtils;
import org.andengine.util.adt.io.out.ByteBufferOutputStream;
import org.andengine.util.debug.Debug;
import org.andengine.util.math.MathUtils;

public abstract class PVRTexture extends Texture {
  public static final int FLAG_ALPHA = 32768;
  
  public static final int FLAG_BUMPMAP = 1024;
  
  public static final int FLAG_CUBEMAP = 4096;
  
  public static final int FLAG_FALSEMIPCOL = 8192;
  
  public static final int FLAG_MIPMAP = 256;
  
  public static final int FLAG_TILING = 2048;
  
  public static final int FLAG_TWIDDLE = 512;
  
  public static final int FLAG_VERTICALFLIP = 65536;
  
  public static final int FLAG_VOLUME = 16384;
  
  private final PVRTextureHeader mPVRTextureHeader;
  
  private final IPVRTexturePixelBufferStrategy mPVRTexturePixelBufferStrategy;
  
  public PVRTexture(TextureManager paramTextureManager, PVRTextureFormat paramPVRTextureFormat) throws IllegalArgumentException, IOException {
    this(paramTextureManager, paramPVRTextureFormat, (IPVRTexturePixelBufferStrategy)new GreedyPVRTexturePixelBufferStrategy(), TextureOptions.DEFAULT, (ITextureStateListener)null);
  }
  
  public PVRTexture(TextureManager paramTextureManager, PVRTextureFormat paramPVRTextureFormat, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException, IOException {
    this(paramTextureManager, paramPVRTextureFormat, (IPVRTexturePixelBufferStrategy)new GreedyPVRTexturePixelBufferStrategy(), TextureOptions.DEFAULT, paramITextureStateListener);
  }
  
  public PVRTexture(TextureManager paramTextureManager, PVRTextureFormat paramPVRTextureFormat, TextureOptions paramTextureOptions) throws IllegalArgumentException, IOException {
    this(paramTextureManager, paramPVRTextureFormat, (IPVRTexturePixelBufferStrategy)new GreedyPVRTexturePixelBufferStrategy(), paramTextureOptions, (ITextureStateListener)null);
  }
  
  public PVRTexture(TextureManager paramTextureManager, PVRTextureFormat paramPVRTextureFormat, TextureOptions paramTextureOptions, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException, IOException {
    this(paramTextureManager, paramPVRTextureFormat, (IPVRTexturePixelBufferStrategy)new GreedyPVRTexturePixelBufferStrategy(), paramTextureOptions, paramITextureStateListener);
  }
  
  public PVRTexture(TextureManager paramTextureManager, PVRTextureFormat paramPVRTextureFormat, IPVRTexturePixelBufferStrategy paramIPVRTexturePixelBufferStrategy) throws IllegalArgumentException, IOException {
    this(paramTextureManager, paramPVRTextureFormat, paramIPVRTexturePixelBufferStrategy, TextureOptions.DEFAULT, (ITextureStateListener)null);
  }
  
  public PVRTexture(TextureManager paramTextureManager, PVRTextureFormat paramPVRTextureFormat, IPVRTexturePixelBufferStrategy paramIPVRTexturePixelBufferStrategy, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException, IOException {
    this(paramTextureManager, paramPVRTextureFormat, paramIPVRTexturePixelBufferStrategy, TextureOptions.DEFAULT, paramITextureStateListener);
  }
  
  public PVRTexture(TextureManager paramTextureManager, PVRTextureFormat paramPVRTextureFormat, IPVRTexturePixelBufferStrategy paramIPVRTexturePixelBufferStrategy, TextureOptions paramTextureOptions) throws IllegalArgumentException, IOException {
    this(paramTextureManager, paramPVRTextureFormat, paramIPVRTexturePixelBufferStrategy, paramTextureOptions, (ITextureStateListener)null);
  }
  
  public PVRTexture(TextureManager paramTextureManager, PVRTextureFormat paramPVRTextureFormat, IPVRTexturePixelBufferStrategy paramIPVRTexturePixelBufferStrategy, TextureOptions paramTextureOptions, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat.getPixelFormat(), paramTextureOptions, paramITextureStateListener);
    InputStream inputStream;
    this.mPVRTexturePixelBufferStrategy = paramIPVRTexturePixelBufferStrategy;
    paramTextureManager = null;
    try {
      InputStream inputStream1 = getInputStream();
      inputStream = inputStream1;
      PVRTextureHeader pVRTextureHeader = new PVRTextureHeader();
      inputStream = inputStream1;
      this(StreamUtils.streamToBytes(inputStream1, 52));
      inputStream = inputStream1;
      this.mPVRTextureHeader = pVRTextureHeader;
      StreamUtils.close(inputStream1);
    } finally {
      StreamUtils.close(inputStream);
    } 
    if (this.mPVRTextureHeader.getPVRTextureFormat().isCompressed())
      throw new IllegalArgumentException("Invalid PVRTextureFormat: '" + this.mPVRTextureHeader.getPVRTextureFormat() + "'."); 
    if (hasMipMaps())
      switch (paramTextureOptions.mMinFilter) {
        default:
          Debug.w("This '" + getClass().getSimpleName() + "' contains mipmaps, but the provided '" + paramTextureOptions.getClass().getSimpleName() + "' don't have MipMaps enabled on the MinFilter!");
          break;
        case 9984:
        case 9985:
        case 9986:
        case 9987:
          break;
      }  
    this.mUpdateOnHardwareNeeded = true;
  }
  
  public int getHeight() {
    return this.mPVRTextureHeader.getHeight();
  }
  
  public InputStream getInputStream() throws IOException {
    return onGetInputStream();
  }
  
  public ByteBuffer getPVRTextureBuffer() throws IOException {
    InputStream inputStream = getInputStream();
    try {
      ByteBufferOutputStream byteBufferOutputStream = new ByteBufferOutputStream();
      this(1024, 524288);
      StreamUtils.copy(inputStream, (OutputStream)byteBufferOutputStream);
      return byteBufferOutputStream.toByteBuffer();
    } finally {
      StreamUtils.close(inputStream);
    } 
  }
  
  public PVRTextureHeader getPVRTextureHeader() {
    return this.mPVRTextureHeader;
  }
  
  public int getWidth() {
    return this.mPVRTextureHeader.getWidth();
  }
  
  public boolean hasMipMaps() {
    return (this.mPVRTextureHeader.getNumMipmaps() > 0);
  }
  
  protected abstract InputStream onGetInputStream() throws IOException;
  
  protected void writeTextureToHardware(GLState paramGLState) throws IOException {
    IPVRTexturePixelBufferStrategy.IPVRTexturePixelBufferStrategyBufferManager iPVRTexturePixelBufferStrategyBufferManager = this.mPVRTexturePixelBufferStrategy.newPVRTexturePixelBufferStrategyManager(this);
    int i = getWidth();
    int j = getHeight();
    int k = this.mPVRTextureHeader.getDataLength();
    int m = this.mPVRTextureHeader.getBitsPerPixel() / 8;
    GLES20.glPixelStorei(3317, 1);
    byte b = 0;
    int n = 0;
    while (true) {
      if (n >= k) {
        GLES20.glPixelStorei(3317, 4);
        return;
      } 
      if (b && (i != j || MathUtils.nextPowerOfTwo(i) != i))
        Debug.w("Mipmap level '" + b + "' is not squared. Width: '" + i + "', height: '" + j + "'. Texture won't render correctly."); 
      int i1 = j * i * m;
      this.mPVRTexturePixelBufferStrategy.loadPVRTextureData(iPVRTexturePixelBufferStrategyBufferManager, i, j, m, this.mPixelFormat, b, n, i1);
      n += i1;
      i = Math.max(i / 2, 1);
      j = Math.max(j / 2, 1);
      b++;
    } 
  }
  
  public enum PVRTextureFormat {
    AI_88,
    A_8,
    I_8,
    RGBA_4444(16, false, PixelFormat.RGBA_4444),
    RGBA_5551(17, false, PixelFormat.RGBA_5551),
    RGBA_8888(18, false, PixelFormat.RGBA_8888),
    RGB_565(19, false, PixelFormat.RGB_565);
    
    private final boolean mCompressed;
    
    private final int mID;
    
    private final PixelFormat mPixelFormat;
    
    static {
      AI_88 = new PVRTextureFormat("AI_88", 5, 23, false, PixelFormat.AI_88);
      A_8 = new PVRTextureFormat("A_8", 6, 27, false, PixelFormat.A_8);
      ENUM$VALUES = new PVRTextureFormat[] { RGBA_4444, RGBA_5551, RGBA_8888, RGB_565, I_8, AI_88, A_8 };
    }
    
    PVRTextureFormat(int param1Int1, boolean param1Boolean, PixelFormat param1PixelFormat) {
      this.mID = param1Int1;
      this.mCompressed = param1Boolean;
      this.mPixelFormat = param1PixelFormat;
    }
    
    public static PVRTextureFormat fromID(int param1Int) {
      PVRTextureFormat[] arrayOfPVRTextureFormat = values();
      int i = arrayOfPVRTextureFormat.length;
      for (byte b = 0;; b++) {
        if (b >= i)
          throw new IllegalArgumentException("Unexpected " + PVRTextureFormat.class.getSimpleName() + "-ID: '" + param1Int + "'."); 
        PVRTextureFormat pVRTextureFormat = arrayOfPVRTextureFormat[b];
        if (pVRTextureFormat.mID == param1Int)
          return pVRTextureFormat; 
      } 
    }
    
    public static PVRTextureFormat fromPixelFormat(PixelFormat param1PixelFormat) throws IllegalArgumentException {
      switch (param1PixelFormat) {
        default:
          throw new IllegalArgumentException("Unsupported " + PixelFormat.class.getName() + ": '" + param1PixelFormat + "'.");
        case null:
          return RGBA_8888;
        case null:
          return RGBA_4444;
        case null:
          break;
      } 
      return RGB_565;
    }
    
    public int getID() {
      return this.mID;
    }
    
    public PixelFormat getPixelFormat() {
      return this.mPixelFormat;
    }
    
    public boolean isCompressed() {
      return this.mCompressed;
    }
  }
  
  public static class PVRTextureHeader {
    private static final int FORMAT_FLAG_MASK = 255;
    
    static final byte[] MAGIC_IDENTIFIER = new byte[] { 80, 86, 82, 33 };
    
    public static final int SIZE = 52;
    
    private final ByteBuffer mDataByteBuffer;
    
    private final PVRTexture.PVRTextureFormat mPVRTextureFormat;
    
    public PVRTextureHeader(byte[] param1ArrayOfbyte) {
      this.mDataByteBuffer = ByteBuffer.wrap(param1ArrayOfbyte);
      this.mDataByteBuffer.rewind();
      this.mDataByteBuffer.order(ByteOrder.LITTLE_ENDIAN);
      if (!ArrayUtils.equals(param1ArrayOfbyte, 44, MAGIC_IDENTIFIER, 0, MAGIC_IDENTIFIER.length))
        throw new IllegalArgumentException("Invalid " + getClass().getSimpleName() + "!"); 
      this.mPVRTextureFormat = PVRTexture.PVRTextureFormat.fromID(getFlags() & 0xFF);
    }
    
    public int getBitmaskAlpha() {
      return this.mDataByteBuffer.getInt(40);
    }
    
    public int getBitmaskBlue() {
      return this.mDataByteBuffer.getInt(36);
    }
    
    public int getBitmaskGreen() {
      return this.mDataByteBuffer.getInt(32);
    }
    
    public int getBitmaskRed() {
      return this.mDataByteBuffer.getInt(28);
    }
    
    public int getBitsPerPixel() {
      return this.mDataByteBuffer.getInt(24);
    }
    
    public int getDataLength() {
      return this.mDataByteBuffer.getInt(20);
    }
    
    public int getFlags() {
      return this.mDataByteBuffer.getInt(16);
    }
    
    public int getHeight() {
      return this.mDataByteBuffer.getInt(4);
    }
    
    public int getNumMipmaps() {
      return this.mDataByteBuffer.getInt(12);
    }
    
    public int getPVRTag() {
      return this.mDataByteBuffer.getInt(44);
    }
    
    public PVRTexture.PVRTextureFormat getPVRTextureFormat() {
      return this.mPVRTextureFormat;
    }
    
    public int getWidth() {
      return this.mDataByteBuffer.getInt(8);
    }
    
    public boolean hasAlpha() {
      return (getBitmaskAlpha() != 0);
    }
    
    public int headerLength() {
      return this.mDataByteBuffer.getInt(0);
    }
    
    public int numSurfs() {
      return this.mDataByteBuffer.getInt(48);
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/compressed/pvr/PVRTexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */