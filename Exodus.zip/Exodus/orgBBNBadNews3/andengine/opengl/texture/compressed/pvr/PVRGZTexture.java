package org.andengine.opengl.texture.compressed.pvr;

import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;
import org.andengine.opengl.texture.ITextureStateListener;
import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.compressed.pvr.pixelbufferstrategy.IPVRTexturePixelBufferStrategy;

public abstract class PVRGZTexture extends PVRTexture {
  public PVRGZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat);
  }
  
  public PVRGZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramITextureStateListener);
  }
  
  public PVRGZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, TextureOptions paramTextureOptions) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramTextureOptions);
  }
  
  public PVRGZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, TextureOptions paramTextureOptions, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramTextureOptions, paramITextureStateListener);
  }
  
  public PVRGZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, IPVRTexturePixelBufferStrategy paramIPVRTexturePixelBufferStrategy) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramIPVRTexturePixelBufferStrategy);
  }
  
  public PVRGZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, IPVRTexturePixelBufferStrategy paramIPVRTexturePixelBufferStrategy, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramIPVRTexturePixelBufferStrategy, paramITextureStateListener);
  }
  
  public PVRGZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, IPVRTexturePixelBufferStrategy paramIPVRTexturePixelBufferStrategy, TextureOptions paramTextureOptions) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramIPVRTexturePixelBufferStrategy, paramTextureOptions);
  }
  
  public PVRGZTexture(TextureManager paramTextureManager, PVRTexture.PVRTextureFormat paramPVRTextureFormat, IPVRTexturePixelBufferStrategy paramIPVRTexturePixelBufferStrategy, TextureOptions paramTextureOptions, ITextureStateListener paramITextureStateListener) throws IllegalArgumentException, IOException {
    super(paramTextureManager, paramPVRTextureFormat, paramIPVRTexturePixelBufferStrategy, paramTextureOptions, paramITextureStateListener);
  }
  
  public GZIPInputStream getInputStream() throws IOException {
    return new GZIPInputStream(onGetInputStream());
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/compressed/pvr/PVRGZTexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */