package org.andengine.opengl.texture.compressed.pvr.pixelbufferstrategy;

import java.io.IOException;
import java.nio.ByteBuffer;
import org.andengine.opengl.texture.PixelFormat;
import org.andengine.opengl.texture.compressed.pvr.PVRTexture;

public interface IPVRTexturePixelBufferStrategy {
  void loadPVRTextureData(IPVRTexturePixelBufferStrategyBufferManager paramIPVRTexturePixelBufferStrategyBufferManager, int paramInt1, int paramInt2, int paramInt3, PixelFormat paramPixelFormat, int paramInt4, int paramInt5, int paramInt6) throws IOException;
  
  IPVRTexturePixelBufferStrategyBufferManager newPVRTexturePixelBufferStrategyManager(PVRTexture paramPVRTexture) throws IOException;
  
  public static interface IPVRTexturePixelBufferStrategyBufferManager {
    ByteBuffer getPixelBuffer(int param1Int1, int param1Int2) throws IOException;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/compressed/pvr/pixelbufferstrategy/IPVRTexturePixelBufferStrategy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */