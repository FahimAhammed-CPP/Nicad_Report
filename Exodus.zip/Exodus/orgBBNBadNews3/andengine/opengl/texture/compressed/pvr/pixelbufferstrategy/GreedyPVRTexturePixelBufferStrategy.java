package org.andengine.opengl.texture.compressed.pvr.pixelbufferstrategy;

import android.opengl.GLES20;
import java.io.IOException;
import java.nio.ByteBuffer;
import org.andengine.opengl.texture.PixelFormat;
import org.andengine.opengl.texture.compressed.pvr.PVRTexture;

public class GreedyPVRTexturePixelBufferStrategy implements IPVRTexturePixelBufferStrategy {
  public void loadPVRTextureData(IPVRTexturePixelBufferStrategy.IPVRTexturePixelBufferStrategyBufferManager paramIPVRTexturePixelBufferStrategyBufferManager, int paramInt1, int paramInt2, int paramInt3, PixelFormat paramPixelFormat, int paramInt4, int paramInt5, int paramInt6) throws IOException {
    ByteBuffer byteBuffer = paramIPVRTexturePixelBufferStrategyBufferManager.getPixelBuffer(paramInt5 + 52, paramInt6);
    GLES20.glTexImage2D(3553, paramInt4, paramPixelFormat.getGLInternalFormat(), paramInt1, paramInt2, 0, paramPixelFormat.getGLFormat(), paramPixelFormat.getGLType(), byteBuffer);
  }
  
  public IPVRTexturePixelBufferStrategy.IPVRTexturePixelBufferStrategyBufferManager newPVRTexturePixelBufferStrategyManager(PVRTexture paramPVRTexture) throws IOException {
    return new GreedyPVRTexturePixelBufferStrategyBufferManager(paramPVRTexture);
  }
  
  public static class GreedyPVRTexturePixelBufferStrategyBufferManager implements IPVRTexturePixelBufferStrategy.IPVRTexturePixelBufferStrategyBufferManager {
    private final ByteBuffer mByteBuffer;
    
    public GreedyPVRTexturePixelBufferStrategyBufferManager(PVRTexture param1PVRTexture) throws IOException {
      this.mByteBuffer = param1PVRTexture.getPVRTextureBuffer();
    }
    
    public ByteBuffer getPixelBuffer(int param1Int1, int param1Int2) {
      this.mByteBuffer.position(param1Int1);
      this.mByteBuffer.limit(param1Int1 + param1Int2);
      return this.mByteBuffer.slice();
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/compressed/pvr/pixelbufferstrategy/GreedyPVRTexturePixelBufferStrategy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */