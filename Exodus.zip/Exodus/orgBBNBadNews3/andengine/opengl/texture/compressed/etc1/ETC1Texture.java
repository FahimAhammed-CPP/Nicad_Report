package org.andengine.opengl.texture.compressed.etc1;

import android.opengl.ETC1;
import android.opengl.ETC1Util;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import org.andengine.opengl.texture.ITextureStateListener;
import org.andengine.opengl.texture.PixelFormat;
import org.andengine.opengl.texture.Texture;
import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.util.GLState;
import org.andengine.util.StreamUtils;

public abstract class ETC1Texture extends Texture {
  private ETC1TextureHeader mETC1TextureHeader;
  
  public ETC1Texture(TextureManager paramTextureManager) throws IOException {
    this(paramTextureManager, TextureOptions.DEFAULT, null);
  }
  
  public ETC1Texture(TextureManager paramTextureManager, ITextureStateListener paramITextureStateListener) throws IOException {
    this(paramTextureManager, TextureOptions.DEFAULT, paramITextureStateListener);
  }
  
  public ETC1Texture(TextureManager paramTextureManager, TextureOptions paramTextureOptions) throws IOException {
    this(paramTextureManager, paramTextureOptions, null);
  }
  
  public ETC1Texture(TextureManager paramTextureManager, TextureOptions paramTextureOptions, ITextureStateListener paramITextureStateListener) throws IOException {
    super(paramTextureManager, PixelFormat.RGB_565, paramTextureOptions, paramITextureStateListener);
    InputStream inputStream;
    paramTextureManager = null;
    try {
      InputStream inputStream1 = getInputStream();
      inputStream = inputStream1;
      ETC1TextureHeader eTC1TextureHeader = new ETC1TextureHeader();
      inputStream = inputStream1;
      this(StreamUtils.streamToBytes(inputStream1, 16));
      inputStream = inputStream1;
      this.mETC1TextureHeader = eTC1TextureHeader;
      return;
    } finally {
      StreamUtils.close(inputStream);
    } 
  }
  
  public int getHeight() {
    return this.mETC1TextureHeader.getHeight();
  }
  
  protected abstract InputStream getInputStream() throws IOException;
  
  public int getWidth() {
    return this.mETC1TextureHeader.getWidth();
  }
  
  protected void writeTextureToHardware(GLState paramGLState) throws IOException {
    InputStream inputStream = getInputStream();
    ETC1Util.loadTexture(3553, 0, 0, this.mPixelFormat.getGLFormat(), this.mPixelFormat.getGLType(), inputStream);
  }
  
  public static class ETC1TextureHeader {
    private final ByteBuffer mDataByteBuffer;
    
    private final int mHeight;
    
    private final int mWidth;
    
    public ETC1TextureHeader(byte[] param1ArrayOfbyte) {
      if (param1ArrayOfbyte.length != 16)
        throw new IllegalArgumentException("Invalid " + getClass().getSimpleName() + "!"); 
      this.mDataByteBuffer = ByteBuffer.allocateDirect(16).order(ByteOrder.nativeOrder());
      this.mDataByteBuffer.put(param1ArrayOfbyte, 0, 16);
      this.mDataByteBuffer.position(0);
      if (!ETC1.isValid(this.mDataByteBuffer))
        throw new IllegalArgumentException("Invalid " + getClass().getSimpleName() + "!"); 
      this.mWidth = ETC1.getWidth(this.mDataByteBuffer);
      this.mHeight = ETC1.getHeight(this.mDataByteBuffer);
    }
    
    public int getHeight() {
      return this.mHeight;
    }
    
    public int getWidth() {
      return this.mWidth;
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/compressed/etc1/ETC1Texture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */