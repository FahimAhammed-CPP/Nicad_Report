package org.andengine.opengl.texture.render;

import android.graphics.Bitmap;
import android.opengl.GLES20;
import java.io.IOException;
import java.nio.IntBuffer;
import org.andengine.opengl.exception.GLException;
import org.andengine.opengl.exception.GLFrameBufferException;
import org.andengine.opengl.exception.RenderTextureInitializationException;
import org.andengine.opengl.texture.ITextureStateListener;
import org.andengine.opengl.texture.PixelFormat;
import org.andengine.opengl.texture.Texture;
import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.util.GLHelper;
import org.andengine.opengl.util.GLState;
import org.andengine.util.color.Color;

public class RenderTexture extends Texture {
  private static final float[] CLEARCOLOR_CONTAINER;
  
  private static final int CLEARCOLOR_CONTAINER_ALPHA_INDEX = 3;
  
  private static final int CLEARCOLOR_CONTAINER_BLUE_INDEX = 2;
  
  private static final int CLEARCOLOR_CONTAINER_GREEN_INDEX = 1;
  
  private static final int CLEARCOLOR_CONTAINER_RED_INDEX = 0;
  
  private static final int[] VIEWPORT_CONTAINER = new int[4];
  
  private static final int VIEWPORT_CONTAINER_HEIGHT_INDEX = 3;
  
  private static final int VIEWPORT_CONTAINER_WIDTH_INDEX = 2;
  
  private static final int VIEWPORT_CONTAINER_X_INDEX = 0;
  
  private static final int VIEWPORT_CONTAINER_Y_INDEX = 1;
  
  protected int mFramebufferObjectID;
  
  protected final int mHeight;
  
  private boolean mInitialized;
  
  protected final PixelFormat mPixelFormat;
  
  private int mPreviousFramebufferObjectID;
  
  private int mPreviousViewPortHeight;
  
  private int mPreviousViewPortWidth;
  
  private int mPreviousViewPortX;
  
  private int mPreviousViewPortY;
  
  protected final int mWidth;
  
  static {
    CLEARCOLOR_CONTAINER = new float[4];
  }
  
  public RenderTexture(TextureManager paramTextureManager, int paramInt1, int paramInt2) {
    this(paramTextureManager, paramInt1, paramInt2, PixelFormat.RGBA_8888, TextureOptions.NEAREST);
  }
  
  public RenderTexture(TextureManager paramTextureManager, int paramInt1, int paramInt2, PixelFormat paramPixelFormat) {
    this(paramTextureManager, paramInt1, paramInt2, paramPixelFormat, TextureOptions.NEAREST);
  }
  
  public RenderTexture(TextureManager paramTextureManager, int paramInt1, int paramInt2, PixelFormat paramPixelFormat, TextureOptions paramTextureOptions) {
    this(paramTextureManager, paramInt1, paramInt2, paramPixelFormat, paramTextureOptions, (ITextureStateListener)null);
  }
  
  public RenderTexture(TextureManager paramTextureManager, int paramInt1, int paramInt2, PixelFormat paramPixelFormat, TextureOptions paramTextureOptions, ITextureStateListener paramITextureStateListener) {
    super(paramTextureManager, paramPixelFormat, paramTextureOptions, paramITextureStateListener);
    this.mWidth = paramInt1;
    this.mHeight = paramInt2;
    this.mPixelFormat = paramPixelFormat;
  }
  
  public RenderTexture(TextureManager paramTextureManager, int paramInt1, int paramInt2, TextureOptions paramTextureOptions) {
    this(paramTextureManager, paramInt1, paramInt2, PixelFormat.RGBA_8888, paramTextureOptions);
  }
  
  public void begin(GLState paramGLState) {
    begin(paramGLState, false, false);
  }
  
  public void begin(GLState paramGLState, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    begin(paramGLState, false, false, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void begin(GLState paramGLState, Color paramColor) {
    begin(paramGLState, paramColor.getRed(), paramColor.getGreen(), paramColor.getBlue(), paramColor.getAlpha());
  }
  
  public void begin(GLState paramGLState, boolean paramBoolean1, boolean paramBoolean2) {
    float f1;
    float f2;
    float f3;
    float f4;
    savePreviousViewport();
    GLES20.glViewport(0, 0, this.mWidth, this.mHeight);
    paramGLState.pushProjectionGLMatrix();
    if (paramBoolean1) {
      f1 = this.mWidth;
      f2 = 0.0F;
    } else {
      f1 = 0.0F;
      f2 = this.mWidth;
    } 
    if (paramBoolean2) {
      f3 = this.mHeight;
      f4 = 0.0F;
    } else {
      f3 = 0.0F;
      f4 = this.mHeight;
    } 
    paramGLState.orthoProjectionGLMatrixf(f1, f2, f4, f3, -1.0F, 1.0F);
    savePreviousFramebufferObjectID(paramGLState);
    paramGLState.bindFramebuffer(this.mFramebufferObjectID);
    paramGLState.pushModelViewGLMatrix();
    paramGLState.loadModelViewGLMatrixIdentity();
  }
  
  public void begin(GLState paramGLState, boolean paramBoolean1, boolean paramBoolean2, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    begin(paramGLState, paramBoolean1, paramBoolean2);
    GLES20.glGetFloatv(3106, CLEARCOLOR_CONTAINER, 0);
    GLES20.glClearColor(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    GLES20.glClear(16384);
    GLES20.glClearColor(CLEARCOLOR_CONTAINER[0], CLEARCOLOR_CONTAINER[1], CLEARCOLOR_CONTAINER[2], CLEARCOLOR_CONTAINER[3]);
  }
  
  public void begin(GLState paramGLState, boolean paramBoolean1, boolean paramBoolean2, Color paramColor) {
    begin(paramGLState, paramBoolean1, paramBoolean2, paramColor.getRed(), paramColor.getGreen(), paramColor.getBlue(), paramColor.getAlpha());
  }
  
  public void destroy(GLState paramGLState) {
    unloadFromHardware(paramGLState);
    paramGLState.deleteFramebuffer(this.mFramebufferObjectID);
    this.mInitialized = false;
  }
  
  public void end(GLState paramGLState) {
    end(paramGLState, false, false);
  }
  
  public void end(GLState paramGLState, boolean paramBoolean1, boolean paramBoolean2) {
    if (paramBoolean2) {
      finish(paramGLState);
    } else if (paramBoolean1) {
      flush(paramGLState);
    } 
    paramGLState.popModelViewGLMatrix();
    restorePreviousFramebufferObjectID(paramGLState);
    paramGLState.popProjectionGLMatrix();
    resotorePreviousViewport();
  }
  
  public void finish(GLState paramGLState) {
    paramGLState.finish();
  }
  
  public void flush(GLState paramGLState) {
    paramGLState.flush();
  }
  
  public Bitmap getBitmap(GLState paramGLState) {
    return getBitmap(paramGLState, 0, 0, this.mWidth, this.mHeight);
  }
  
  public Bitmap getBitmap(GLState paramGLState, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.mPixelFormat != PixelFormat.RGBA_8888)
      throw new IllegalStateException("Currently only 'PixelFormat." + PixelFormat.RGBA_8888 + "' is supported to be retrieved as a Bitmap."); 
    return Bitmap.createBitmap(getPixelsARGB_8888(paramGLState, paramInt1, paramInt2, paramInt3, paramInt4), paramInt3, paramInt4, Bitmap.Config.ARGB_8888);
  }
  
  public int getHeight() {
    return this.mHeight;
  }
  
  public int[] getPixelsARGB_8888(GLState paramGLState) {
    return getPixelsARGB_8888(paramGLState, 0, 0, this.mWidth, this.mHeight);
  }
  
  public int[] getPixelsARGB_8888(GLState paramGLState, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int[] arrayOfInt = new int[paramInt3 * paramInt4];
    IntBuffer intBuffer = IntBuffer.wrap(arrayOfInt);
    intBuffer.position(0);
    begin(paramGLState);
    GLES20.glReadPixels(paramInt1, paramInt2, paramInt3, paramInt4, this.mPixelFormat.getGLFormat(), this.mPixelFormat.getGLType(), intBuffer);
    end(paramGLState);
    return GLHelper.convertRGBA_8888toARGB_8888(arrayOfInt);
  }
  
  public int getWidth() {
    return this.mWidth;
  }
  
  public void init(GLState paramGLState) throws GLFrameBufferException, GLException {
    savePreviousFramebufferObjectID(paramGLState);
    try {
      loadToHardware(paramGLState);
    } catch (IOException iOException) {}
    paramGLState.bindTexture(0);
    this.mFramebufferObjectID = paramGLState.generateFramebuffer();
    paramGLState.bindFramebuffer(this.mFramebufferObjectID);
    GLES20.glFramebufferTexture2D(36160, 36064, 3553, this.mHardwareTextureID, 0);
    try {
      paramGLState.checkFramebufferStatus();
      restorePreviousFramebufferObjectID(paramGLState);
      return;
    } catch (GLException gLException) {
      destroy(paramGLState);
      RenderTextureInitializationException renderTextureInitializationException = new RenderTextureInitializationException();
      this((Throwable)gLException);
      throw renderTextureInitializationException;
    } finally {
      restorePreviousFramebufferObjectID(paramGLState);
    } 
  }
  
  public boolean isInitialized() {
    return this.mInitialized;
  }
  
  protected void resotorePreviousViewport() {
    GLES20.glViewport(this.mPreviousViewPortX, this.mPreviousViewPortY, this.mPreviousViewPortWidth, this.mPreviousViewPortHeight);
  }
  
  protected void restorePreviousFramebufferObjectID(GLState paramGLState) {
    paramGLState.bindFramebuffer(this.mPreviousFramebufferObjectID);
  }
  
  protected void savePreviousFramebufferObjectID(GLState paramGLState) {
    this.mPreviousFramebufferObjectID = paramGLState.getActiveFramebuffer();
  }
  
  protected void savePreviousViewport() {
    GLES20.glGetIntegerv(2978, VIEWPORT_CONTAINER, 0);
    this.mPreviousViewPortX = VIEWPORT_CONTAINER[0];
    this.mPreviousViewPortY = VIEWPORT_CONTAINER[1];
    this.mPreviousViewPortWidth = VIEWPORT_CONTAINER[2];
    this.mPreviousViewPortHeight = VIEWPORT_CONTAINER[3];
  }
  
  protected void writeTextureToHardware(GLState paramGLState) {
    GLES20.glTexImage2D(3553, 0, this.mPixelFormat.getGLInternalFormat(), this.mWidth, this.mHeight, 0, this.mPixelFormat.getGLFormat(), this.mPixelFormat.getGLType(), null);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/texture/render/RenderTexture.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */