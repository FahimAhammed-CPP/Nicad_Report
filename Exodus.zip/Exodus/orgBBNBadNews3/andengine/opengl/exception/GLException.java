package org.andengine.opengl.exception;

import android.opengl.GLU;

public class GLException extends RuntimeException {
  private static final long serialVersionUID = -7494923307858371890L;
  
  private final int mError;
  
  public GLException(int paramInt) {
    this(paramInt, getErrorString(paramInt));
  }
  
  public GLException(int paramInt, String paramString) {
    super(paramString);
    this.mError = paramInt;
  }
  
  private static String getErrorString(int paramInt) {
    String str1 = GLU.gluErrorString(paramInt);
    String str2 = str1;
    if (str1 == null)
      str2 = "Unknown error '0x" + Integer.toHexString(paramInt) + "'."; 
    return str2;
  }
  
  public int getError() {
    return this.mError;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/exception/GLException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */