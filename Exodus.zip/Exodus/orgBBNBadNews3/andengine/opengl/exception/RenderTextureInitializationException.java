package org.andengine.opengl.exception;

import org.andengine.util.exception.AndEngineRuntimeException;

public class RenderTextureInitializationException extends AndEngineRuntimeException {
  private static final long serialVersionUID = -7219303294648252076L;
  
  public RenderTextureInitializationException() {}
  
  public RenderTextureInitializationException(String paramString) {
    super(paramString);
  }
  
  public RenderTextureInitializationException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public RenderTextureInitializationException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/exception/RenderTextureInitializationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */