package org.andengine.opengl.exception;

public class GLFrameBufferException extends GLException {
  private static final long serialVersionUID = -8910272713633644676L;
  
  public GLFrameBufferException(int paramInt) {
    super(paramInt);
  }
  
  public GLFrameBufferException(int paramInt, String paramString) {
    super(paramInt, paramString);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/exception/GLFrameBufferException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */