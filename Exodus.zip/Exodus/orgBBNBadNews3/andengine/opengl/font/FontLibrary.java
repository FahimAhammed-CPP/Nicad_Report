package org.andengine.opengl.font;

import android.util.SparseArray;
import org.andengine.util.adt.map.Library;

public class FontLibrary extends Library<Font> {
  public FontLibrary() {}
  
  public FontLibrary(int paramInt) {
    super(paramInt);
  }
  
  public void loadFonts(FontManager paramFontManager) {
    SparseArray sparseArray = this.mItems;
    for (int i = sparseArray.size() - 1;; i--) {
      if (i < 0)
        return; 
      Font font = (Font)sparseArray.valueAt(i);
      if (font != null)
        paramFontManager.loadFont(font); 
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/font/FontLibrary.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */