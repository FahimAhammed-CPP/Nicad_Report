package org.andengine.opengl.font;

import org.andengine.opengl.font.exception.LetterNotFoundException;
import org.andengine.opengl.texture.ITexture;

public interface IFont {
  Letter getLetter(char paramChar) throws LetterNotFoundException;
  
  float getLineHeight();
  
  ITexture getTexture();
  
  void load();
  
  void unload();
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/font/IFont.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */