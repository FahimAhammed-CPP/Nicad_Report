package org.andengine.opengl.font.exception;

import org.andengine.util.exception.AndEngineRuntimeException;

public class FontException extends AndEngineRuntimeException {
  private static final long serialVersionUID = 2766566088383545102L;
  
  public FontException() {}
  
  public FontException(String paramString) {
    super(paramString);
  }
  
  public FontException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public FontException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/font/exception/FontException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */