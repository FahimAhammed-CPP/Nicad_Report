package org.andengine.opengl.font.exception;

public class LetterNotFoundException extends FontException {
  private static final long serialVersionUID = 5260601170771253529L;
  
  public LetterNotFoundException() {}
  
  public LetterNotFoundException(String paramString) {
    super(paramString);
  }
  
  public LetterNotFoundException(String paramString, Throwable paramThrowable) {
    super(paramString, paramThrowable);
  }
  
  public LetterNotFoundException(Throwable paramThrowable) {
    super(paramThrowable);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/font/exception/LetterNotFoundException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */