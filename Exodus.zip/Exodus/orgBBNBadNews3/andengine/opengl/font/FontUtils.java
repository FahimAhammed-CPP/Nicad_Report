package org.andengine.opengl.font;

import java.util.List;
import org.andengine.entity.text.AutoWrap;
import org.andengine.util.TextUtils;
import org.andengine.util.exception.MethodNotYetImplementedException;

public class FontUtils {
  private static final int UNSPECIFIED = -1;
  
  public static int breakText(IFont paramIFont, CharSequence paramCharSequence, MeasureDirection paramMeasureDirection, float paramFloat, float[] paramArrayOffloat) {
    throw new MethodNotYetImplementedException();
  }
  
  private static float getAdvanceCorrection(IFont paramIFont, CharSequence paramCharSequence, int paramInt) {
    Letter letter = paramIFont.getLetter(paramCharSequence.charAt(paramInt));
    return -(letter.mOffsetX + letter.mWidth) + letter.mAdvance;
  }
  
  public static float measureText(IFont paramIFont, CharSequence paramCharSequence) {
    return measureText(paramIFont, paramCharSequence, null);
  }
  
  public static float measureText(IFont paramIFont, CharSequence paramCharSequence, int paramInt1, int paramInt2) {
    return measureText(paramIFont, paramCharSequence, paramInt1, paramInt2, null);
  }
  
  public static float measureText(IFont paramIFont, CharSequence paramCharSequence, int paramInt1, int paramInt2, float[] paramArrayOffloat) {
    if (paramInt1 == paramInt2)
      return 0.0F; 
    if (paramInt2 - paramInt1 == 1)
      return (paramIFont.getLetter(paramCharSequence.charAt(paramInt1))).mWidth; 
    Letter letter = null;
    float f = 0.0F;
    byte b = 0;
    while (true) {
      float f1 = f;
      if (paramInt1 < paramInt2) {
        Letter letter1 = paramIFont.getLetter(paramCharSequence.charAt(paramInt1));
        f1 = f;
        if (letter != null)
          f1 = f + letter.getKerning(letter1.mCharacter); 
        letter = letter1;
        if (paramInt1 == paramInt2 - 1) {
          f = f1 + letter1.mOffsetX + letter1.mWidth;
        } else {
          f = f1 + letter1.mAdvance;
        } 
        if (paramArrayOffloat != null)
          paramArrayOffloat[b] = f; 
        paramInt1++;
        b++;
        continue;
      } 
      return f1;
    } 
  }
  
  public static float measureText(IFont paramIFont, CharSequence paramCharSequence, float[] paramArrayOffloat) {
    return measureText(paramIFont, paramCharSequence, 0, paramCharSequence.length(), paramArrayOffloat);
  }
  
  public static <L extends List<CharSequence>> L splitLines(CharSequence paramCharSequence, L paramL) {
    return (L)TextUtils.split(paramCharSequence, '\n', (List)paramL);
  }
  
  public static <L extends List<CharSequence>> L splitLines(IFont paramIFont, CharSequence paramCharSequence, L paramL, AutoWrap paramAutoWrap, float paramFloat) {
    switch (paramAutoWrap) {
      default:
        throw new IllegalArgumentException("Unexpected " + AutoWrap.class.getSimpleName() + ": '" + paramAutoWrap + "'.");
      case null:
        return (L)splitLinesByLetters(paramIFont, paramCharSequence, (IFont)paramL, paramFloat);
      case null:
        return (L)splitLinesByWords(paramIFont, paramCharSequence, (IFont)paramL, paramFloat);
      case null:
        break;
    } 
    return (L)splitLinesByCJK(paramIFont, paramCharSequence, (IFont)paramL, paramFloat);
  }
  
  private static <L extends List<CharSequence>> L splitLinesByCJK(IFont paramIFont, CharSequence paramCharSequence, L paramL, float paramFloat) {
    int i = paramCharSequence.length();
    int j = 0;
    int k;
    for (k = 0;; k++) {
      if (j >= i || paramCharSequence.charAt(j) != ' ') {
        j = k;
        int m = k;
        label43: while (true) {
          int n = m;
          if (j >= i)
            return paramL; 
          int i1 = 1;
          m = 1;
          int i2 = n;
          for (k = j;; k = i2) {
            j = i2;
            if (k >= i) {
              i1 = j;
              i2 = m;
              continue;
            } 
            k = j;
            while (true) {
              if (k < i && paramCharSequence.charAt(k) == ' ') {
                k++;
                continue;
              } 
              if (k == i) {
                i2 = i1;
                if (n == j)
                  i2 = 0; 
                k = i;
                i1 = j;
              } else {
                i2 = j + 1;
                if (measureText(paramIFont, paramCharSequence, n, i2) > paramFloat) {
                  j = i2;
                  if (n < i2 - 1)
                    j = i2 - 1; 
                  paramL.add(paramCharSequence.subSequence(n, j));
                  i2 = 0;
                  k = j;
                  i1 = j;
                } else {
                  break;
                } 
              } 
              j = k;
              m = i1;
              if (i2 != 0) {
                paramL.add(paramCharSequence.subSequence(n, i1));
                j = k;
                m = i1;
                continue label43;
              } 
              continue label43;
            } 
          } 
          break;
        } 
        break;
      } 
      j++;
    } 
  }
  
  private static <L extends List<CharSequence>> L splitLinesByLetters(IFont paramIFont, CharSequence paramCharSequence, L paramL, float paramFloat) {
    int i = paramCharSequence.length();
    int j = 0;
    int k = 0;
    int m = 0;
    boolean bool = false;
    int n = 0;
    while (true) {
      if (n >= i)
        return paramL; 
      boolean bool1 = bool;
      int i1 = k;
      int i2 = j;
      if (paramCharSequence.charAt(n) != ' ')
        if (bool) {
          m = n + 1;
          i2 = j;
          i1 = k;
          bool1 = bool;
        } else {
          bool1 = true;
          i2 = n;
          m = i2 + 1;
          i1 = m;
        }  
      bool = bool1;
      j = n;
      k = i1;
      if (bool1) {
        float f = measureText(paramIFont, paramCharSequence, i2, m);
        if (n == i - 1) {
          k = 1;
        } else {
          k = 0;
        } 
        if (k != 0) {
          if (f <= paramFloat) {
            paramL.add(paramCharSequence.subSequence(i2, m));
            k = i1;
            j = n;
            bool = bool1;
          } else {
            paramL.add(paramCharSequence.subSequence(i2, i1));
            bool = bool1;
            j = n;
            k = i1;
            if (i2 != n) {
              paramL.add(paramCharSequence.subSequence(n, m));
              bool = bool1;
              j = n;
              k = i1;
            } 
          } 
        } else if (f <= paramFloat) {
          k = m;
          bool = bool1;
          j = n;
        } else {
          paramL.add(paramCharSequence.subSequence(i2, i1));
          j = i1 - 1;
          bool = false;
          k = i1;
        } 
      } 
      n = j + 1;
      j = i2;
    } 
  }
  
  private static <L extends List<CharSequence>> L splitLinesByWords(IFont paramIFont, CharSequence paramCharSequence, L paramL, float paramFloat) {
    int i = paramCharSequence.length();
    if (i != 0) {
      float f1 = (paramIFont.getLetter(' ')).mAdvance;
      byte b1 = -1;
      byte b2 = -1;
      byte b3 = -1;
      float f2 = paramFloat;
      boolean bool = true;
      byte b = 0;
      while (true) {
        if (b < i) {
          byte b5;
          float f;
          for (byte b4 = 0;; b4++) {
            if (b >= i || paramCharSequence.charAt(b) != ' ') {
              b5 = b;
              byte b6 = b2;
              if (b2 == -1) {
                b6 = b;
                b5 = b;
              } 
              while (true) {
                float f3;
                if (b5 >= i || paramCharSequence.charAt(b5) == ' ') {
                  if (b == b5) {
                    if (!bool)
                      paramL.add(paramCharSequence.subSequence(b6, b3)); 
                    return paramL;
                  } 
                } else {
                  b5++;
                  continue;
                } 
                f = measureText(paramIFont, paramCharSequence, b, b5);
                if (bool) {
                  f3 = f;
                } else {
                  f3 = b4 * f1 + f;
                } 
                if (f3 <= f2) {
                  if (bool) {
                    bool = false;
                  } else {
                    f2 -= getAdvanceCorrection(paramIFont, paramCharSequence, b1 - 1);
                  } 
                  f2 -= f3;
                  b1 = b5;
                  b4 = b5;
                  b = b5;
                  b3 = b4;
                  b2 = b6;
                  if (b5 == i) {
                    paramL.add(paramCharSequence.subSequence(b6, b4));
                    // Byte code: goto -> 13
                  } 
                  continue;
                } 
                if (bool) {
                  if (f >= paramFloat) {
                    paramL.add(paramCharSequence.subSequence(b, b5));
                    f2 = paramFloat;
                    continue;
                  } 
                  f2 = paramFloat - f;
                  if (b5 == i) {
                    paramL.add(paramCharSequence.subSequence(b, b5));
                    // Byte code: goto -> 13
                  } 
                  bool = true;
                  b1 = -1;
                  b2 = -1;
                  b3 = -1;
                  b = b5;
                  continue;
                } 
                paramL.add(paramCharSequence.subSequence(b6, b3));
                if (b5 == i) {
                  paramL.add(paramCharSequence.subSequence(b, b5));
                  return paramL;
                } 
                break;
              } 
              break;
            } 
            b++;
          } 
          f2 = paramFloat - f;
          bool = false;
          b1 = b5;
          b2 = b;
          b3 = b5;
          b = b5;
          continue;
        } 
        // Byte code: goto -> 13
      } 
    } 
    return paramL;
  }
  
  public enum MeasureDirection {
    BACKWARDS, FORWARDS;
    
    static {
    
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/font/FontUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */