package org.andengine.opengl.font;

import android.util.SparseIntArray;

public class Letter {
  public final float mAdvance;
  
  public final char mCharacter;
  
  public final int mHeight;
  
  private SparseIntArray mKernings;
  
  public final float mOffsetX;
  
  public final float mOffsetY;
  
  public final int mTextureX;
  
  public final int mTextureY;
  
  public final float mU;
  
  public final float mU2;
  
  public final float mV;
  
  public final float mV2;
  
  private final boolean mWhitespace;
  
  public final int mWidth;
  
  Letter(char paramChar, float paramFloat) {
    this(paramChar, true, 0, 0, 0, 0, 0.0F, 0.0F, paramFloat, 0.0F, 0.0F, 0.0F, 0.0F);
  }
  
  Letter(char paramChar, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    this(paramChar, false, paramInt1, paramInt2, paramInt3, paramInt4, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6, paramFloat7);
  }
  
  private Letter(char paramChar, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7) {
    this.mCharacter = (char)paramChar;
    this.mWhitespace = paramBoolean;
    this.mWidth = paramInt3;
    this.mHeight = paramInt4;
    this.mTextureX = paramInt1;
    this.mTextureY = paramInt2;
    this.mOffsetX = paramFloat1;
    this.mOffsetY = paramFloat2;
    this.mAdvance = paramFloat3;
    this.mU = paramFloat4;
    this.mV = paramFloat5;
    this.mU2 = paramFloat6;
    this.mV2 = paramFloat7;
  }
  
  void addKerning(int paramInt1, int paramInt2) {
    if (this.mKernings == null)
      this.mKernings = new SparseIntArray(); 
    this.mKernings.put(paramInt1, paramInt2);
  }
  
  public boolean equals(Object paramObject) {
    boolean bool = true;
    if (this != paramObject) {
      if (paramObject == null)
        return false; 
      if (getClass() != paramObject.getClass())
        return false; 
      paramObject = paramObject;
      if (this.mCharacter != ((Letter)paramObject).mCharacter)
        bool = false; 
    } 
    return bool;
  }
  
  public int getKerning(int paramInt) {
    boolean bool = false;
    return (this.mKernings == null) ? bool : this.mKernings.get(paramInt, 0);
  }
  
  public int hashCode() {
    return this.mCharacter + 31;
  }
  
  public boolean isWhitespace() {
    return this.mWhitespace;
  }
  
  public String toString() {
    return String.valueOf(getClass().getSimpleName()) + "[Character=" + this.mCharacter + ", Whitespace=" + this.mWhitespace + ", TextureX=" + this.mTextureX + ", TextureY=" + this.mTextureY + ", Width=" + this.mWidth + ", Height=" + this.mHeight + ", OffsetX=" + this.mOffsetX + ", OffsetY=" + this.mOffsetY + ", Advance=" + this.mAdvance + ", U=" + this.mU + ", V=" + this.mV + ", U2=" + this.mU2 + ", V2=" + this.mV2 + ", Kernings=" + this.mKernings + "]";
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/font/Letter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */