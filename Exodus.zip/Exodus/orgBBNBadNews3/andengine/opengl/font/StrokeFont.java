package org.andengine.opengl.font;

import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.FloatMath;
import org.andengine.opengl.texture.ITexture;
import org.andengine.util.color.Color;

public class StrokeFont extends Font {
  private final boolean mStrokeOnly;
  
  private final Paint mStrokePaint;
  
  private final float mStrokeWidth;
  
  public StrokeFont(FontManager paramFontManager, ITexture paramITexture, Typeface paramTypeface, float paramFloat1, boolean paramBoolean, int paramInt1, float paramFloat2, int paramInt2) {
    this(paramFontManager, paramITexture, paramTypeface, paramFloat1, paramBoolean, paramInt1, paramFloat2, paramInt2, false);
  }
  
  public StrokeFont(FontManager paramFontManager, ITexture paramITexture, Typeface paramTypeface, float paramFloat1, boolean paramBoolean1, int paramInt1, float paramFloat2, int paramInt2, boolean paramBoolean2) {
    super(paramFontManager, paramITexture, paramTypeface, paramFloat1, paramBoolean1, paramInt1);
    this.mStrokeWidth = paramFloat2;
    this.mStrokePaint = new Paint();
    this.mStrokePaint.setTypeface(paramTypeface);
    this.mStrokePaint.setStyle(Paint.Style.STROKE);
    this.mStrokePaint.setStrokeWidth(paramFloat2);
    this.mStrokePaint.setColor(paramInt2);
    this.mStrokePaint.setTextSize(paramFloat1);
    this.mStrokePaint.setAntiAlias(paramBoolean1);
    this.mStrokeOnly = paramBoolean2;
  }
  
  public StrokeFont(FontManager paramFontManager, ITexture paramITexture, Typeface paramTypeface, float paramFloat1, boolean paramBoolean, Color paramColor1, float paramFloat2, Color paramColor2) {
    this(paramFontManager, paramITexture, paramTypeface, paramFloat1, paramBoolean, paramColor1.getARGBPackedInt(), paramFloat2, paramColor2.getARGBPackedInt());
  }
  
  public StrokeFont(FontManager paramFontManager, ITexture paramITexture, Typeface paramTypeface, float paramFloat1, boolean paramBoolean1, Color paramColor1, float paramFloat2, Color paramColor2, boolean paramBoolean2) {
    this(paramFontManager, paramITexture, paramTypeface, paramFloat1, paramBoolean1, paramColor1.getARGBPackedInt(), paramFloat2, paramColor2.getARGBPackedInt(), paramBoolean2);
  }
  
  protected void drawLetter(String paramString, float paramFloat1, float paramFloat2) {
    if (!this.mStrokeOnly)
      super.drawLetter(paramString, paramFloat1, paramFloat2); 
    this.mCanvas.drawText(paramString, paramFloat1 + 1.0F, 1.0F + paramFloat2, this.mStrokePaint);
  }
  
  protected void updateTextBounds(String paramString) {
    this.mStrokePaint.getTextBounds(paramString, 0, 1, this.mTextBounds);
    int i = -((int)FloatMath.floor(this.mStrokeWidth * 0.5F));
    this.mTextBounds.inset(i, i);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/font/StrokeFont.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */