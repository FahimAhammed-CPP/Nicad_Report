package org.andengine.opengl.font;

import android.content.res.AssetManager;
import android.graphics.Typeface;
import org.andengine.opengl.texture.ITexture;
import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.atlas.bitmap.BitmapTextureAtlas;
import org.andengine.opengl.texture.bitmap.BitmapTextureFormat;
import org.andengine.util.color.Color;

public class FontFactory {
  private static final boolean ANTIALIAS_DEFAULT = true;
  
  private static final int COLOR_DEFAULT = Color.BLACK_ARGB_PACKED_INT;
  
  private static String sAssetBasePath = "";
  
  public static Font create(FontManager paramFontManager, ITexture paramITexture, float paramFloat) {
    return create(paramFontManager, paramITexture, paramFloat, true, COLOR_DEFAULT);
  }
  
  public static Font create(FontManager paramFontManager, ITexture paramITexture, float paramFloat, int paramInt) {
    return create(paramFontManager, paramITexture, paramFloat, true, paramInt);
  }
  
  public static Font create(FontManager paramFontManager, ITexture paramITexture, float paramFloat, boolean paramBoolean) {
    return create(paramFontManager, paramITexture, paramFloat, paramBoolean, COLOR_DEFAULT);
  }
  
  public static Font create(FontManager paramFontManager, ITexture paramITexture, float paramFloat, boolean paramBoolean, int paramInt) {
    return create(paramFontManager, paramITexture, Typeface.create(Typeface.DEFAULT, 0), paramFloat, paramBoolean, paramInt);
  }
  
  public static Font create(FontManager paramFontManager, ITexture paramITexture, Typeface paramTypeface, float paramFloat, boolean paramBoolean, int paramInt) {
    return new Font(paramFontManager, paramITexture, paramTypeface, paramFloat, paramBoolean, paramInt);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, float paramFloat, boolean paramBoolean, int paramInt3) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, TextureOptions.DEFAULT, paramFloat, paramBoolean, paramInt3);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, Typeface paramTypeface, float paramFloat) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, TextureOptions.DEFAULT, paramTypeface, paramFloat, true, COLOR_DEFAULT);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, Typeface paramTypeface, float paramFloat, int paramInt3) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, TextureOptions.DEFAULT, paramTypeface, paramFloat, true, paramInt3);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, Typeface paramTypeface, float paramFloat, boolean paramBoolean) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, TextureOptions.DEFAULT, paramTypeface, paramFloat, paramBoolean, COLOR_DEFAULT);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, Typeface paramTypeface, float paramFloat, boolean paramBoolean, int paramInt3) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, TextureOptions.DEFAULT, paramTypeface, paramFloat, paramBoolean, paramInt3);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, TextureOptions paramTextureOptions, float paramFloat, boolean paramBoolean, int paramInt3) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, paramTextureOptions, Typeface.create(Typeface.DEFAULT, 0), paramFloat, paramBoolean, paramInt3);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, TextureOptions paramTextureOptions, Typeface paramTypeface, float paramFloat) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, paramTextureOptions, paramTypeface, paramFloat, true, COLOR_DEFAULT);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, TextureOptions paramTextureOptions, Typeface paramTypeface, float paramFloat, int paramInt3) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, paramTextureOptions, paramTypeface, paramFloat, true, paramInt3);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, TextureOptions paramTextureOptions, Typeface paramTypeface, float paramFloat, boolean paramBoolean) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, paramTextureOptions, paramTypeface, paramFloat, paramBoolean, COLOR_DEFAULT);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, TextureOptions paramTextureOptions, Typeface paramTypeface, float paramFloat, boolean paramBoolean, int paramInt3) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, BitmapTextureFormat.RGBA_8888, paramTextureOptions, paramTypeface, paramFloat, paramBoolean, paramInt3);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions, Typeface paramTypeface, float paramFloat) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat, paramTextureOptions, paramTypeface, paramFloat, true, COLOR_DEFAULT);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions, Typeface paramTypeface, float paramFloat, int paramInt3) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat, paramTextureOptions, paramTypeface, paramFloat, true, paramInt3);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions, Typeface paramTypeface, float paramFloat, boolean paramBoolean) {
    return create(paramFontManager, paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat, paramTextureOptions, paramTypeface, paramFloat, paramBoolean, COLOR_DEFAULT);
  }
  
  public static Font create(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions, Typeface paramTypeface, float paramFloat, boolean paramBoolean, int paramInt3) {
    return create(paramFontManager, (ITexture)new BitmapTextureAtlas(paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat, paramTextureOptions), paramTypeface, paramFloat, paramBoolean, paramInt3);
  }
  
  public static Font createFromAsset(FontManager paramFontManager, ITexture paramITexture, AssetManager paramAssetManager, String paramString, float paramFloat, boolean paramBoolean, int paramInt) {
    return new Font(paramFontManager, paramITexture, Typeface.createFromAsset(paramAssetManager, String.valueOf(sAssetBasePath) + paramString), paramFloat, paramBoolean, paramInt);
  }
  
  public static Font createFromAsset(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, AssetManager paramAssetManager, String paramString, float paramFloat, boolean paramBoolean, int paramInt3) {
    return createFromAsset(paramFontManager, paramTextureManager, paramInt1, paramInt2, TextureOptions.DEFAULT, paramAssetManager, paramString, paramFloat, paramBoolean, paramInt3);
  }
  
  public static Font createFromAsset(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, TextureOptions paramTextureOptions, AssetManager paramAssetManager, String paramString, float paramFloat, boolean paramBoolean, int paramInt3) {
    return createFromAsset(paramFontManager, paramTextureManager, paramInt1, paramInt2, BitmapTextureFormat.RGBA_8888, paramTextureOptions, paramAssetManager, paramString, paramFloat, paramBoolean, paramInt3);
  }
  
  public static Font createFromAsset(FontManager paramFontManager, TextureManager paramTextureManager, int paramInt1, int paramInt2, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions, AssetManager paramAssetManager, String paramString, float paramFloat, boolean paramBoolean, int paramInt3) {
    return new Font(paramFontManager, (ITexture)new BitmapTextureAtlas(paramTextureManager, paramInt1, paramInt2, paramBitmapTextureFormat, paramTextureOptions), Typeface.createFromAsset(paramAssetManager, String.valueOf(sAssetBasePath) + paramString), paramFloat, paramBoolean, paramInt3);
  }
  
  public static StrokeFont createStroke(FontManager paramFontManager, ITexture paramITexture, Typeface paramTypeface, float paramFloat1, boolean paramBoolean, int paramInt1, float paramFloat2, int paramInt2) {
    return new StrokeFont(paramFontManager, paramITexture, paramTypeface, paramFloat1, paramBoolean, paramInt1, paramFloat2, paramInt2);
  }
  
  public static StrokeFont createStroke(FontManager paramFontManager, ITexture paramITexture, Typeface paramTypeface, float paramFloat1, boolean paramBoolean1, int paramInt1, float paramFloat2, int paramInt2, boolean paramBoolean2) {
    return new StrokeFont(paramFontManager, paramITexture, paramTypeface, paramFloat1, paramBoolean1, paramInt1, paramFloat2, paramInt2, paramBoolean2);
  }
  
  public static StrokeFont createStrokeFromAsset(FontManager paramFontManager, ITexture paramITexture, AssetManager paramAssetManager, String paramString, float paramFloat1, boolean paramBoolean, int paramInt1, float paramFloat2, int paramInt2) {
    return new StrokeFont(paramFontManager, paramITexture, Typeface.createFromAsset(paramAssetManager, String.valueOf(sAssetBasePath) + paramString), paramFloat1, paramBoolean, paramInt1, paramFloat2, paramInt2);
  }
  
  public static StrokeFont createStrokeFromAsset(FontManager paramFontManager, ITexture paramITexture, AssetManager paramAssetManager, String paramString, float paramFloat1, boolean paramBoolean1, int paramInt1, float paramFloat2, int paramInt2, boolean paramBoolean2) {
    return new StrokeFont(paramFontManager, paramITexture, Typeface.createFromAsset(paramAssetManager, String.valueOf(sAssetBasePath) + paramString), paramFloat1, paramBoolean1, paramInt1, paramFloat2, paramInt2, paramBoolean2);
  }
  
  public static String getAssetBasePath() {
    return sAssetBasePath;
  }
  
  public static void onCreate() {
    setAssetBasePath("");
  }
  
  public static void setAssetBasePath(String paramString) {
    if (paramString.endsWith("/") || paramString.length() == 0) {
      sAssetBasePath = paramString;
      return;
    } 
    throw new IllegalStateException("pAssetBasePath must end with '/' or be lenght zero.");
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/font/FontFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */