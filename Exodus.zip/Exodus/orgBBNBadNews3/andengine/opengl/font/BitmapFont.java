package org.andengine.opengl.font;

import android.content.res.AssetManager;
import android.util.SparseArray;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import org.andengine.opengl.font.exception.FontException;
import org.andengine.opengl.font.exception.LetterNotFoundException;
import org.andengine.opengl.texture.ITexture;
import org.andengine.opengl.texture.TextureManager;
import org.andengine.opengl.texture.TextureOptions;
import org.andengine.opengl.texture.bitmap.BitmapTexture;
import org.andengine.opengl.texture.bitmap.BitmapTextureFormat;
import org.andengine.util.StreamUtils;
import org.andengine.util.TextUtils;
import org.andengine.util.adt.io.in.AssetInputStreamOpener;
import org.andengine.util.adt.io.in.IInputStreamOpener;

public class BitmapFont implements IFont {
  private static final String TAG_CHAR = "char";
  
  private static final String TAG_CHARS = "chars";
  
  private static final int TAG_CHARS_ATTRIBUTECOUNT = 1;
  
  private static final String TAG_CHARS_ATTRIBUTE_COUNT = "count";
  
  private static final int TAG_CHARS_ATTRIBUTE_COUNT_INDEX = 1;
  
  private static final int TAG_CHAR_ATTRIBUTECOUNT = 10;
  
  private static final String TAG_CHAR_ATTRIBUTE_HEIGHT = "height";
  
  private static final int TAG_CHAR_ATTRIBUTE_HEIGHT_INDEX = 5;
  
  private static final String TAG_CHAR_ATTRIBUTE_ID = "id";
  
  private static final int TAG_CHAR_ATTRIBUTE_ID_INDEX = 1;
  
  private static final String TAG_CHAR_ATTRIBUTE_PAGE = "page";
  
  private static final int TAG_CHAR_ATTRIBUTE_PAGE_INDEX = 9;
  
  private static final String TAG_CHAR_ATTRIBUTE_WIDTH = "width";
  
  private static final int TAG_CHAR_ATTRIBUTE_WIDTH_INDEX = 4;
  
  private static final String TAG_CHAR_ATTRIBUTE_X = "x";
  
  private static final String TAG_CHAR_ATTRIBUTE_XADVANCE = "xadvance";
  
  private static final int TAG_CHAR_ATTRIBUTE_XADVANCE_INDEX = 8;
  
  private static final String TAG_CHAR_ATTRIBUTE_XOFFSET = "xoffset";
  
  private static final int TAG_CHAR_ATTRIBUTE_XOFFSET_INDEX = 6;
  
  private static final int TAG_CHAR_ATTRIBUTE_X_INDEX = 2;
  
  private static final String TAG_CHAR_ATTRIBUTE_Y = "y";
  
  private static final String TAG_CHAR_ATTRIBUTE_YOFFSET = "yoffset";
  
  private static final int TAG_CHAR_ATTRIBUTE_YOFFSET_INDEX = 7;
  
  private static final int TAG_CHAR_ATTRIBUTE_Y_INDEX = 3;
  
  private static final String TAG_COMMON = "common";
  
  private static final int TAG_COMMON_ATTRIBUTECOUNT = 6;
  
  private static final String TAG_COMMON_ATTRIBUTE_BASE = "base";
  
  private static final int TAG_COMMON_ATTRIBUTE_BASE_INDEX = 2;
  
  private static final String TAG_COMMON_ATTRIBUTE_LINEHEIGHT = "lineHeight";
  
  private static final int TAG_COMMON_ATTRIBUTE_LINEHEIGHT_INDEX = 1;
  
  private static final String TAG_COMMON_ATTRIBUTE_PACKED = "packed";
  
  private static final int TAG_COMMON_ATTRIBUTE_PACKED_INDEX = 6;
  
  private static final String TAG_COMMON_ATTRIBUTE_PAGES = "pages";
  
  private static final int TAG_COMMON_ATTRIBUTE_PAGES_INDEX = 5;
  
  private static final String TAG_COMMON_ATTRIBUTE_SCALEHEIGHT = "scaleH";
  
  private static final int TAG_COMMON_ATTRIBUTE_SCALEHEIGHT_INDEX = 4;
  
  private static final String TAG_COMMON_ATTRIBUTE_SCALEWIDTH = "scaleW";
  
  private static final int TAG_COMMON_ATTRIBUTE_SCALEWIDTH_INDEX = 3;
  
  private static final String TAG_INFO = "info";
  
  private static final int TAG_INFO_ATTRIBUTECOUNT = 11;
  
  private static final String TAG_INFO_ATTRIBUTE_ANTIALIASED = "aa";
  
  private static final int TAG_INFO_ATTRIBUTE_ANTIALIASED_INDEX = 9;
  
  private static final String TAG_INFO_ATTRIBUTE_BOLD = "bold";
  
  private static final int TAG_INFO_ATTRIBUTE_BOLD_INDEX = 3;
  
  private static final String TAG_INFO_ATTRIBUTE_CHARSET = "charset";
  
  private static final int TAG_INFO_ATTRIBUTE_CHARSET_INDEX = 5;
  
  private static final String TAG_INFO_ATTRIBUTE_FACE = "face";
  
  private static final int TAG_INFO_ATTRIBUTE_FACE_INDEX = 1;
  
  private static final String TAG_INFO_ATTRIBUTE_ITALIC = "italic";
  
  private static final int TAG_INFO_ATTRIBUTE_ITALIC_INDEX = 4;
  
  private static final String TAG_INFO_ATTRIBUTE_PADDING = "padding";
  
  private static final int TAG_INFO_ATTRIBUTE_PADDING_INDEX = 10;
  
  private static final String TAG_INFO_ATTRIBUTE_SIZE = "size";
  
  private static final int TAG_INFO_ATTRIBUTE_SIZE_INDEX = 2;
  
  private static final String TAG_INFO_ATTRIBUTE_SMOOTH = "smooth";
  
  private static final int TAG_INFO_ATTRIBUTE_SMOOTH_INDEX = 8;
  
  private static final String TAG_INFO_ATTRIBUTE_SPACING = "spacing";
  
  private static final int TAG_INFO_ATTRIBUTE_SPACING_INDEX = 11;
  
  private static final String TAG_INFO_ATTRIBUTE_STRETCHHEIGHT = "stretchH";
  
  private static final int TAG_INFO_ATTRIBUTE_STRETCHHEIGHT_INDEX = 7;
  
  private static final String TAG_INFO_ATTRIBUTE_UNICODE = "unicode";
  
  private static final int TAG_INFO_ATTRIBUTE_UNICODE_INDEX = 6;
  
  private static final String TAG_KERNING = "kerning";
  
  private static final String TAG_KERNINGS = "kernings";
  
  private static final int TAG_KERNINGS_ATTRIBUTECOUNT = 1;
  
  private static final String TAG_KERNINGS_ATTRIBUTE_COUNT = "count";
  
  private static final int TAG_KERNINGS_ATTRIBUTE_COUNT_INDEX = 1;
  
  private static final int TAG_KERNING_ATTRIBUTECOUNT = 3;
  
  private static final String TAG_KERNING_ATTRIBUTE_AMOUNT = "amount";
  
  private static final int TAG_KERNING_ATTRIBUTE_AMOUNT_INDEX = 3;
  
  private static final String TAG_KERNING_ATTRIBUTE_FIRST = "first";
  
  private static final int TAG_KERNING_ATTRIBUTE_FIRST_INDEX = 1;
  
  private static final String TAG_KERNING_ATTRIBUTE_SECOND = "second";
  
  private static final int TAG_KERNING_ATTRIBUTE_SECOND_INDEX = 2;
  
  private static final String TAG_PAGE = "page";
  
  private static final int TAG_PAGE_ATTRIBUTECOUNT = 2;
  
  private static final String TAG_PAGE_ATTRIBUTE_FILE = "file";
  
  private static final int TAG_PAGE_ATTRIBUTE_FILE_INDEX = 2;
  
  private static final String TAG_PAGE_ATTRIBUTE_ID = "id";
  
  private static final int TAG_PAGE_ATTRIBUTE_ID_INDEX = 1;
  
  private final int mBase;
  
  private final BitmapFontInfo mBitmapFontInfo;
  
  private final BitmapFontOptions mBitmapFontOptions;
  
  private final int mBitmapFontPageCount;
  
  private final BitmapFontPage[] mBitmapFontPages;
  
  private final BitmapTextureFormat mBitmapTextureFormat;
  
  private final SparseArray<Letter> mCharacterToLetterMap;
  
  private final int mLineHeight;
  
  private final boolean mPacked;
  
  private final int mScaleHeight;
  
  private final int mScaleWidth;
  
  private final TextureManager mTextureManager;
  
  private final TextureOptions mTextureOptions;
  
  public BitmapFont(TextureManager paramTextureManager, AssetManager paramAssetManager, String paramString) {
    this(paramTextureManager, paramAssetManager, paramString, BitmapTextureFormat.RGBA_8888, TextureOptions.DEFAULT, BitmapFontOptions.DEFAULT);
  }
  
  public BitmapFont(TextureManager paramTextureManager, AssetManager paramAssetManager, String paramString, TextureOptions paramTextureOptions) {
    this(paramTextureManager, paramAssetManager, paramString, BitmapTextureFormat.RGBA_8888, paramTextureOptions, BitmapFontOptions.DEFAULT);
  }
  
  public BitmapFont(TextureManager paramTextureManager, AssetManager paramAssetManager, String paramString, BitmapTextureFormat paramBitmapTextureFormat) {
    this(paramTextureManager, paramAssetManager, paramString, paramBitmapTextureFormat, TextureOptions.DEFAULT, BitmapFontOptions.DEFAULT);
  }
  
  public BitmapFont(TextureManager paramTextureManager, AssetManager paramAssetManager, String paramString, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions) {
    this(paramTextureManager, paramAssetManager, paramString, paramBitmapTextureFormat, paramTextureOptions, BitmapFontOptions.DEFAULT);
  }
  
  public BitmapFont(TextureManager paramTextureManager, AssetManager paramAssetManager, String paramString, BitmapTextureFormat paramBitmapTextureFormat, TextureOptions paramTextureOptions, BitmapFontOptions paramBitmapFontOptions) {
    InputStream inputStream1;
    InputStream inputStream2;
    FontException fontException4;
    this.mCharacterToLetterMap = new SparseArray();
    this.mTextureManager = paramTextureManager;
    this.mBitmapTextureFormat = paramBitmapTextureFormat;
    this.mTextureOptions = paramTextureOptions;
    this.mBitmapFontOptions = paramBitmapFontOptions;
    paramTextureManager = null;
    paramBitmapTextureFormat = null;
    try {
      InputStream inputStream = paramAssetManager.open(paramString);
      inputStream2 = inputStream;
      inputStream1 = inputStream;
      BufferedReader bufferedReader = new BufferedReader();
      inputStream2 = inputStream;
      inputStream1 = inputStream;
      InputStreamReader inputStreamReader = new InputStreamReader();
      inputStream2 = inputStream;
      inputStream1 = inputStream;
      this(inputStream);
      inputStream2 = inputStream;
      inputStream1 = inputStream;
      this(inputStreamReader, 8192);
      inputStream2 = inputStream;
      inputStream1 = inputStream;
      if (paramString.indexOf('/') == -1) {
        String str1 = "";
      } else {
        inputStream2 = inputStream;
        inputStream1 = inputStream;
        String str1 = paramString.substring(0, paramString.lastIndexOf('/') + 1);
      } 
      inputStream2 = inputStream;
      inputStream1 = inputStream;
      BitmapFontInfo bitmapFontInfo = new BitmapFontInfo();
      inputStream2 = inputStream;
      inputStream1 = inputStream;
      this(this, bufferedReader.readLine());
      inputStream2 = inputStream;
      inputStream1 = inputStream;
      this.mBitmapFontInfo = bitmapFontInfo;
      inputStream2 = inputStream;
      inputStream1 = inputStream;
      String str = bufferedReader.readLine();
    } catch (IOException iOException) {
      inputStream1 = inputStream2;
      fontException4 = new FontException();
      inputStream1 = inputStream2;
      StringBuilder stringBuilder = new StringBuilder();
      inputStream1 = inputStream2;
      this("Failed loading BitmapFont. AssetPath: ");
      inputStream1 = inputStream2;
      this(stringBuilder.append(paramString).toString(), iOException);
      inputStream1 = inputStream2;
      throw fontException4;
    } finally {
      StreamUtils.close(inputStream1);
    } 
    FontException fontException3 = fontException4;
    FontException fontException1 = fontException4;
    FontException fontException2 = new FontException();
    fontException3 = fontException4;
    fontException1 = fontException4;
    this("Expected: 'common' attributes.");
    fontException3 = fontException4;
    fontException1 = fontException4;
    throw fontException2;
  }
  
  private static String getAttribute(String[] paramArrayOfString, int paramInt, String paramString) {
    String str = paramArrayOfString[paramInt];
    int i = paramString.length();
    if (!str.startsWith(paramString))
      throw new FontException("Expected '" + paramString + "' at position '" + paramInt + "', but found: '" + str + "'."); 
    return str.substring(i + 1);
  }
  
  private static boolean getBooleanAttribute(String[] paramArrayOfString, int paramInt, String paramString) {
    String str = paramArrayOfString[paramInt];
    int i = paramString.length();
    if (!str.startsWith(paramString) || str.charAt(i) != '=')
      throw new FontException("Expected '" + paramString + "' at position '" + paramInt + "', but found: '" + str + "'."); 
    return (Integer.parseInt(str.substring(i + 1)) != 0);
  }
  
  private static char getCharAttribute(String[] paramArrayOfString, int paramInt, String paramString) {
    return (char)getIntAttribute(paramArrayOfString, paramInt, paramString);
  }
  
  private static int getIntAttribute(String[] paramArrayOfString, int paramInt, String paramString) {
    String str = paramArrayOfString[paramInt];
    int i = paramString.length();
    if (!str.startsWith(paramString) || str.charAt(i) != '=')
      throw new FontException("Expected '" + paramString + "' at position '" + paramInt + "', but found: '" + str + "'."); 
    return Integer.parseInt(str.substring(i + 1));
  }
  
  private static String getStringAttribute(String[] paramArrayOfString, int paramInt, String paramString) {
    String str = paramArrayOfString[paramInt];
    int i = paramString.length();
    if (!str.startsWith(paramString) || str.charAt(i) != '=')
      throw new FontException("Expected '" + paramString + "' at position '" + paramInt + "', but found: '" + str + "'."); 
    return str.substring(i + 2, str.length() - 1);
  }
  
  private void parseCharacters(int paramInt, BufferedReader paramBufferedReader) throws IOException {
    paramInt--;
    while (true) {
      if (paramInt < 0)
        return; 
      String str = paramBufferedReader.readLine();
      String[] arrayOfString = TextUtils.SPLITPATTERN_SPACES.split(str, 11);
      if (arrayOfString.length - 1 != 10)
        throw new FontException("Expected: '10' char attributes, found: '" + (arrayOfString.length - 1) + "'."); 
      if (!arrayOfString[0].equals("char"))
        throw new FontException("Expected: 'char' attributes."); 
      char c = getCharAttribute(arrayOfString, 1, "id");
      int i = this.mBitmapFontOptions.mTextureOffsetX + getIntAttribute(arrayOfString, 2, "x");
      int j = this.mBitmapFontOptions.mTextureOffsetY + getIntAttribute(arrayOfString, 3, "y");
      int k = getIntAttribute(arrayOfString, 4, "width");
      int m = getIntAttribute(arrayOfString, 5, "height");
      int n = getIntAttribute(arrayOfString, 6, "xoffset");
      int i1 = getIntAttribute(arrayOfString, 7, "yoffset");
      int i2 = getIntAttribute(arrayOfString, 8, "xadvance");
      int i3 = getIntAttribute(arrayOfString, 9, "page");
      ITexture iTexture = this.mBitmapFontPages[i3].getTexture();
      float f1 = iTexture.getWidth();
      float f2 = iTexture.getHeight();
      float f3 = i / f1;
      float f4 = j / f2;
      f1 = (i + k) / f1;
      f2 = (j + m) / f2;
      this.mCharacterToLetterMap.put(c, new Letter(c, i, j, k, m, n, i1, i2, f3, f4, f1, f2));
      paramInt--;
    } 
  }
  
  private void parseKernings(int paramInt, BufferedReader paramBufferedReader) throws IOException {
    paramInt--;
    while (true) {
      if (paramInt < 0)
        return; 
      String str = paramBufferedReader.readLine();
      String[] arrayOfString = TextUtils.SPLITPATTERN_SPACES.split(str, 4);
      if (arrayOfString.length - 1 != 3)
        throw new FontException("Expected: '3' kerning attributes, found: '" + (arrayOfString.length - 1) + "'."); 
      if (!arrayOfString[0].equals("kerning"))
        throw new FontException("Expected: 'kerning' attributes."); 
      int i = getIntAttribute(arrayOfString, 1, "first");
      int j = getIntAttribute(arrayOfString, 2, "second");
      int k = getIntAttribute(arrayOfString, 3, "amount");
      ((Letter)this.mCharacterToLetterMap.get(i)).addKerning(j, k);
      paramInt--;
    } 
  }
  
  public int getBase() {
    return this.mBase;
  }
  
  public BitmapFontInfo getBitmapFontInfo() {
    return this.mBitmapFontInfo;
  }
  
  public BitmapFontPage getBitmapFontPage(int paramInt) {
    return this.mBitmapFontPages[paramInt];
  }
  
  public int getBitmapFontPageCount() {
    return this.mBitmapFontPageCount;
  }
  
  public BitmapFontPage[] getBitmapFontPages() {
    return this.mBitmapFontPages;
  }
  
  public Letter getLetter(char paramChar) throws LetterNotFoundException {
    Letter letter = (Letter)this.mCharacterToLetterMap.get(paramChar);
    if (letter == null)
      throw new LetterNotFoundException("Letter '" + paramChar + "' not found."); 
    return letter;
  }
  
  public float getLineHeight() {
    return this.mLineHeight;
  }
  
  public int getScaleHeight() {
    return this.mScaleHeight;
  }
  
  public int getScaleWidth() {
    return this.mScaleWidth;
  }
  
  public ITexture getTexture() {
    return this.mBitmapFontPages[0].getTexture();
  }
  
  public boolean isPacked() {
    return this.mPacked;
  }
  
  public void load() {
    loadTextures();
  }
  
  public void loadTextures() {
    BitmapFontPage[] arrayOfBitmapFontPage = this.mBitmapFontPages;
    int i = arrayOfBitmapFontPage.length;
    for (byte b = 0;; b++) {
      if (b >= i)
        return; 
      arrayOfBitmapFontPage[b].getTexture().load();
    } 
  }
  
  public void unload() {
    unloadTextures();
  }
  
  public void unloadTextures() {
    BitmapFontPage[] arrayOfBitmapFontPage = this.mBitmapFontPages;
    int i = arrayOfBitmapFontPage.length;
    for (byte b = 0;; b++) {
      if (b >= i)
        return; 
      arrayOfBitmapFontPage[b].getTexture().unload();
    } 
  }
  
  public class BitmapFontInfo {
    private static final int PADDING_BOTTOM_INDEX = 3;
    
    private static final int PADDING_LEFT_INDEX = 0;
    
    private static final int PADDING_RIGHT_INDEX = 2;
    
    private static final int PADDING_TOP_INDEX = 1;
    
    private static final int SPACING_X_INDEX = 0;
    
    private static final int SPACING_Y_INDEX = 1;
    
    private final boolean mAntiAliased;
    
    private final boolean mBold;
    
    private final String mCharset;
    
    private final String mFace;
    
    private final boolean mItalic;
    
    private final int mPaddingBottom;
    
    private final int mPaddingLeft;
    
    private final int mPaddingRight;
    
    private final int mPaddingTop;
    
    private final int mSize;
    
    private final boolean mSmooth;
    
    private final int mSpacingX;
    
    private final int mSpacingY;
    
    private final int mStretchHeight;
    
    private final int mUnicode;
    
    public BitmapFontInfo(String param1String) throws FontException {
      if (param1String == null)
        throw new FontException("pData must not be null."); 
      String[] arrayOfString2 = TextUtils.SPLITPATTERN_SPACE.split(param1String, 12);
      if (arrayOfString2.length - 1 != 11)
        throw new FontException("Expected: '11' info attributes, found: '" + (arrayOfString2.length - 1) + "'."); 
      if (!arrayOfString2[0].equals("info"))
        throw new FontException("Expected: 'info' attributes."); 
      this.mFace = BitmapFont.getStringAttribute(arrayOfString2, 1, "face");
      this.mSize = BitmapFont.getIntAttribute(arrayOfString2, 2, "size");
      this.mBold = BitmapFont.getBooleanAttribute(arrayOfString2, 3, "bold");
      this.mItalic = BitmapFont.getBooleanAttribute(arrayOfString2, 4, "italic");
      this.mCharset = BitmapFont.getStringAttribute(arrayOfString2, 5, "charset");
      this.mUnicode = BitmapFont.getIntAttribute(arrayOfString2, 6, "unicode");
      this.mStretchHeight = BitmapFont.getIntAttribute(arrayOfString2, 7, "stretchH");
      this.mSmooth = BitmapFont.getBooleanAttribute(arrayOfString2, 8, "smooth");
      this.mAntiAliased = BitmapFont.getBooleanAttribute(arrayOfString2, 9, "aa");
      param1String = BitmapFont.getAttribute(arrayOfString2, 10, "padding");
      String[] arrayOfString3 = TextUtils.SPLITPATTERN_COMMA.split(param1String, 4);
      this.mPaddingLeft = Integer.parseInt(arrayOfString3[0]);
      this.mPaddingTop = Integer.parseInt(arrayOfString3[1]);
      this.mPaddingRight = Integer.parseInt(arrayOfString3[2]);
      this.mPaddingBottom = Integer.parseInt(arrayOfString3[3]);
      String str = BitmapFont.getAttribute(arrayOfString2, 11, "spacing");
      String[] arrayOfString1 = TextUtils.SPLITPATTERN_COMMA.split(str, 2);
      this.mSpacingX = Integer.parseInt(arrayOfString1[0]);
      this.mSpacingY = Integer.parseInt(arrayOfString1[1]);
    }
    
    public String getCharset() {
      return this.mCharset;
    }
    
    public String getFace() {
      return this.mFace;
    }
    
    public int getPaddingBottom() {
      return this.mPaddingBottom;
    }
    
    public int getPaddingLeft() {
      return this.mPaddingLeft;
    }
    
    public int getPaddingRight() {
      return this.mPaddingRight;
    }
    
    public int getPaddingTop() {
      return this.mPaddingTop;
    }
    
    public int getSize() {
      return this.mSize;
    }
    
    public int getSpacingX() {
      return this.mSpacingX;
    }
    
    public int getSpacingY() {
      return this.mSpacingY;
    }
    
    public int getStretchHeight() {
      return this.mStretchHeight;
    }
    
    public int getUnicode() {
      return this.mUnicode;
    }
    
    public boolean isAntiAliased() {
      return this.mAntiAliased;
    }
    
    public boolean isBold() {
      return this.mBold;
    }
    
    public boolean isItalic() {
      return this.mItalic;
    }
    
    public boolean isSmooth() {
      return this.mSmooth;
    }
  }
  
  public static class BitmapFontOptions {
    public static final BitmapFontOptions DEFAULT = new BitmapFontOptions(0, 0);
    
    private final int mTextureOffsetX;
    
    private final int mTextureOffsetY;
    
    public BitmapFontOptions(int param1Int1, int param1Int2) {
      this.mTextureOffsetX = param1Int1;
      this.mTextureOffsetY = param1Int2;
    }
    
    public int getTextureOffsetX() {
      return this.mTextureOffsetX;
    }
    
    public int getTextureOffsetY() {
      return this.mTextureOffsetY;
    }
  }
  
  public class BitmapFontPage {
    private int mID;
    
    private final ITexture mTexture;
    
    public BitmapFontPage(AssetManager param1AssetManager, String param1String1, String param1String2) throws IOException {
      String[] arrayOfString = TextUtils.SPLITPATTERN_SPACE.split(param1String2, 3);
      if (arrayOfString.length - 1 != 2)
        throw new FontException("Expected: '2' page attributes, found: '" + (arrayOfString.length - 1) + "'."); 
      if (!arrayOfString[0].equals("page"))
        throw new FontException("Expected: 'page' attributes."); 
      this.mID = BitmapFont.getIntAttribute(arrayOfString, 1, "id");
      String str = BitmapFont.getStringAttribute(arrayOfString, 2, "file");
      param1String1 = String.valueOf(param1String1) + str;
      this.mTexture = (ITexture)new BitmapTexture(BitmapFont.this.mTextureManager, (IInputStreamOpener)new AssetInputStreamOpener(param1AssetManager, param1String1), BitmapFont.this.mBitmapTextureFormat, BitmapFont.this.mTextureOptions);
    }
    
    public int getID() {
      return this.mID;
    }
    
    public ITexture getTexture() {
      return this.mTexture;
    }
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/font/BitmapFont.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */