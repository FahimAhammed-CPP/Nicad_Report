package org.andengine.opengl.font;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.SparseArray;
import java.util.ArrayList;
import org.andengine.opengl.font.exception.FontException;
import org.andengine.opengl.texture.ITexture;
import org.andengine.opengl.util.GLState;
import org.andengine.util.adt.map.SparseArrayUtils;
import org.andengine.util.color.Color;

public class Font implements IFont {
  protected static final int LETTER_TEXTURE_PADDING = 1;
  
  private final Paint mBackgroundPaint;
  
  protected final Canvas mCanvas = new Canvas();
  
  private int mCurrentTextureX = 1;
  
  private int mCurrentTextureY = 1;
  
  private int mCurrentTextureYHeightMax;
  
  private final FontManager mFontManager;
  
  protected final Paint.FontMetrics mFontMetrics;
  
  private final ArrayList<Letter> mLettersPendingToBeDrawnToTexture = new ArrayList<Letter>();
  
  private final SparseArray<Letter> mManagedCharacterToLetterMap = new SparseArray();
  
  protected final Paint mPaint;
  
  protected final Rect mTextBounds = new Rect();
  
  protected final float[] mTextWidthContainer = new float[1];
  
  private final ITexture mTexture;
  
  private final int mTextureHeight;
  
  private final int mTextureWidth;
  
  public Font(FontManager paramFontManager, ITexture paramITexture, Typeface paramTypeface, float paramFloat, boolean paramBoolean, int paramInt) {
    this.mFontManager = paramFontManager;
    this.mTexture = paramITexture;
    this.mTextureWidth = paramITexture.getWidth();
    this.mTextureHeight = paramITexture.getHeight();
    this.mBackgroundPaint = new Paint();
    this.mBackgroundPaint.setColor(Color.TRANSPARENT_ARGB_PACKED_INT);
    this.mBackgroundPaint.setStyle(Paint.Style.FILL);
    this.mPaint = new Paint();
    this.mPaint.setTypeface(paramTypeface);
    this.mPaint.setColor(paramInt);
    this.mPaint.setTextSize(paramFloat);
    this.mPaint.setAntiAlias(paramBoolean);
    this.mFontMetrics = this.mPaint.getFontMetrics();
  }
  
  public Font(FontManager paramFontManager, ITexture paramITexture, Typeface paramTypeface, float paramFloat, boolean paramBoolean, Color paramColor) {
    this(paramFontManager, paramITexture, paramTypeface, paramFloat, paramBoolean, paramColor.getARGBPackedInt());
  }
  
  private Letter createLetter(char paramChar) throws FontException {
    boolean bool;
    String str = String.valueOf(paramChar);
    float f1 = this.mTextureWidth;
    float f2 = this.mTextureHeight;
    updateTextBounds(str);
    int i = this.mTextBounds.left;
    int j = this.mTextBounds.top;
    int k = this.mTextBounds.width();
    int m = this.mTextBounds.height();
    float f3 = getLetterAdvance(str);
    if (!Character.isWhitespace(paramChar) && k != 0 && m != 0) {
      bool = false;
    } else {
      bool = true;
    } 
    if (bool)
      return new Letter(paramChar, f3); 
    if ((this.mCurrentTextureX + 1 + k) >= f1) {
      this.mCurrentTextureX = 0;
      this.mCurrentTextureY += this.mCurrentTextureYHeightMax + 2;
      this.mCurrentTextureYHeightMax = 0;
    } 
    if ((this.mCurrentTextureY + m) >= f2)
      throw new FontException("Not enough space for " + Letter.class.getSimpleName() + ": '" + paramChar + "' on the " + this.mTexture.getClass().getSimpleName() + ". Existing Letters: " + SparseArrayUtils.toString(this.mManagedCharacterToLetterMap)); 
    this.mCurrentTextureYHeightMax = Math.max(m, this.mCurrentTextureYHeightMax);
    this.mCurrentTextureX++;
    float f4 = this.mCurrentTextureX / f1;
    float f5 = this.mCurrentTextureY / f2;
    f1 = (this.mCurrentTextureX + k) / f1;
    f2 = (this.mCurrentTextureY + m) / f2;
    Letter letter = new Letter(paramChar, this.mCurrentTextureX - 1, this.mCurrentTextureY - 1, k, m, i, j - getAscent(), f3, f4, f5, f1, f2);
    this.mCurrentTextureX += k + 1;
    return letter;
  }
  
  private float getLetterAdvance(String paramString) {
    this.mPaint.getTextWidths(paramString, this.mTextWidthContainer);
    return this.mTextWidthContainer[0];
  }
  
  protected void drawLetter(String paramString, float paramFloat1, float paramFloat2) {
    this.mCanvas.drawText(paramString, paramFloat1 + 1.0F, 1.0F + paramFloat2, this.mPaint);
  }
  
  public float getAscent() {
    return this.mFontMetrics.ascent;
  }
  
  public float getDescent() {
    return this.mFontMetrics.descent;
  }
  
  public float getLeading() {
    return this.mFontMetrics.leading;
  }
  
  public Letter getLetter(char paramChar) throws FontException {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mManagedCharacterToLetterMap : Landroid/util/SparseArray;
    //   6: iload_1
    //   7: invokevirtual get : (I)Ljava/lang/Object;
    //   10: checkcast org/andengine/opengl/font/Letter
    //   13: astore_2
    //   14: aload_2
    //   15: astore_3
    //   16: aload_2
    //   17: ifnonnull -> 44
    //   20: aload_0
    //   21: iload_1
    //   22: invokespecial createLetter : (C)Lorg/andengine/opengl/font/Letter;
    //   25: astore_3
    //   26: aload_0
    //   27: getfield mLettersPendingToBeDrawnToTexture : Ljava/util/ArrayList;
    //   30: aload_3
    //   31: invokevirtual add : (Ljava/lang/Object;)Z
    //   34: pop
    //   35: aload_0
    //   36: getfield mManagedCharacterToLetterMap : Landroid/util/SparseArray;
    //   39: iload_1
    //   40: aload_3
    //   41: invokevirtual put : (ILjava/lang/Object;)V
    //   44: aload_0
    //   45: monitorexit
    //   46: aload_3
    //   47: areturn
    //   48: astore_3
    //   49: aload_0
    //   50: monitorexit
    //   51: aload_3
    //   52: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	48	finally
    //   20	44	48	finally
  }
  
  protected Bitmap getLetterBitmap(Letter paramLetter) throws FontException {
    char c = paramLetter.mCharacter;
    Bitmap bitmap = Bitmap.createBitmap(paramLetter.mWidth + 2, paramLetter.mHeight + 2, Bitmap.Config.ARGB_8888);
    this.mCanvas.setBitmap(bitmap);
    this.mCanvas.drawRect(0.0F, 0.0F, bitmap.getWidth(), bitmap.getHeight(), this.mBackgroundPaint);
    drawLetter(String.valueOf(c), -paramLetter.mOffsetX, -(paramLetter.mOffsetY + getAscent()));
    return bitmap;
  }
  
  public float getLineHeight() {
    return -getAscent() + getDescent();
  }
  
  public ITexture getTexture() {
    return this.mTexture;
  }
  
  public void invalidateLetters() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mLettersPendingToBeDrawnToTexture : Ljava/util/ArrayList;
    //   6: astore_1
    //   7: aload_0
    //   8: getfield mManagedCharacterToLetterMap : Landroid/util/SparseArray;
    //   11: astore_2
    //   12: aload_2
    //   13: invokevirtual size : ()I
    //   16: istore_3
    //   17: iinc #3, -1
    //   20: iload_3
    //   21: ifge -> 27
    //   24: aload_0
    //   25: monitorexit
    //   26: return
    //   27: aload_1
    //   28: aload_2
    //   29: iload_3
    //   30: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   33: checkcast org/andengine/opengl/font/Letter
    //   36: invokevirtual add : (Ljava/lang/Object;)Z
    //   39: pop
    //   40: iinc #3, -1
    //   43: goto -> 20
    //   46: astore_1
    //   47: aload_0
    //   48: monitorexit
    //   49: aload_1
    //   50: athrow
    // Exception table:
    //   from	to	target	type
    //   2	17	46	finally
    //   27	40	46	finally
  }
  
  public void load() {
    this.mTexture.load();
    this.mFontManager.loadFont(this);
  }
  
  public void prepareLetters(char... paramVarArgs) throws FontException {
    int i = paramVarArgs.length;
    for (byte b = 0;; b++) {
      if (b >= i)
        return; 
      getLetter(paramVarArgs[b]);
    } 
  }
  
  public void unload() {
    this.mTexture.unload();
    this.mFontManager.unloadFont(this);
  }
  
  public void update(GLState paramGLState) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mTexture : Lorg/andengine/opengl/texture/ITexture;
    //   6: invokeinterface isLoadedToHardware : ()Z
    //   11: ifeq -> 80
    //   14: aload_0
    //   15: getfield mLettersPendingToBeDrawnToTexture : Ljava/util/ArrayList;
    //   18: astore_2
    //   19: aload_2
    //   20: invokevirtual size : ()I
    //   23: ifle -> 80
    //   26: aload_0
    //   27: getfield mTexture : Lorg/andengine/opengl/texture/ITexture;
    //   30: aload_1
    //   31: invokeinterface bind : (Lorg/andengine/opengl/util/GLState;)V
    //   36: aload_0
    //   37: getfield mTexture : Lorg/andengine/opengl/texture/ITexture;
    //   40: invokeinterface getPixelFormat : ()Lorg/andengine/opengl/texture/PixelFormat;
    //   45: astore_3
    //   46: aload_0
    //   47: getfield mTexture : Lorg/andengine/opengl/texture/ITexture;
    //   50: invokeinterface getTextureOptions : ()Lorg/andengine/opengl/texture/TextureOptions;
    //   55: getfield mPreMultiplyAlpha : Z
    //   58: istore #4
    //   60: aload_2
    //   61: invokevirtual size : ()I
    //   64: iconst_1
    //   65: isub
    //   66: istore #5
    //   68: iload #5
    //   70: ifge -> 83
    //   73: aload_2
    //   74: invokevirtual clear : ()V
    //   77: invokestatic gc : ()V
    //   80: aload_0
    //   81: monitorexit
    //   82: return
    //   83: aload_2
    //   84: iload #5
    //   86: invokevirtual get : (I)Ljava/lang/Object;
    //   89: checkcast org/andengine/opengl/font/Letter
    //   92: astore #6
    //   94: aload #6
    //   96: invokevirtual isWhitespace : ()Z
    //   99: ifne -> 195
    //   102: aload_0
    //   103: aload #6
    //   105: invokevirtual getLetterBitmap : (Lorg/andengine/opengl/font/Letter;)Landroid/graphics/Bitmap;
    //   108: astore #7
    //   110: aload #7
    //   112: invokevirtual getWidth : ()I
    //   115: invokestatic isPowerOfTwo : (I)Z
    //   118: ifeq -> 201
    //   121: aload #7
    //   123: invokevirtual getHeight : ()I
    //   126: invokestatic isPowerOfTwo : (I)Z
    //   129: ifeq -> 201
    //   132: aload_3
    //   133: getstatic org/andengine/opengl/texture/PixelFormat.RGBA_8888 : Lorg/andengine/opengl/texture/PixelFormat;
    //   136: if_acmpne -> 201
    //   139: iconst_1
    //   140: istore #8
    //   142: iload #8
    //   144: ifne -> 154
    //   147: sipush #3317
    //   150: iconst_1
    //   151: invokestatic glPixelStorei : (II)V
    //   154: iload #4
    //   156: ifeq -> 207
    //   159: sipush #3553
    //   162: iconst_0
    //   163: aload #6
    //   165: getfield mTextureX : I
    //   168: aload #6
    //   170: getfield mTextureY : I
    //   173: aload #7
    //   175: invokestatic texSubImage2D : (IIIILandroid/graphics/Bitmap;)V
    //   178: iload #8
    //   180: ifne -> 190
    //   183: sipush #3317
    //   186: iconst_4
    //   187: invokestatic glPixelStorei : (II)V
    //   190: aload #7
    //   192: invokevirtual recycle : ()V
    //   195: iinc #5, -1
    //   198: goto -> 68
    //   201: iconst_0
    //   202: istore #8
    //   204: goto -> 142
    //   207: aload_1
    //   208: sipush #3553
    //   211: iconst_0
    //   212: aload #6
    //   214: getfield mTextureX : I
    //   217: aload #6
    //   219: getfield mTextureY : I
    //   222: aload #7
    //   224: aload_3
    //   225: invokevirtual glTexSubImage2D : (IIIILandroid/graphics/Bitmap;Lorg/andengine/opengl/texture/PixelFormat;)V
    //   228: goto -> 178
    //   231: astore_1
    //   232: aload_0
    //   233: monitorexit
    //   234: aload_1
    //   235: athrow
    // Exception table:
    //   from	to	target	type
    //   2	68	231	finally
    //   73	80	231	finally
    //   83	139	231	finally
    //   147	154	231	finally
    //   159	178	231	finally
    //   183	190	231	finally
    //   190	195	231	finally
    //   207	228	231	finally
  }
  
  protected void updateTextBounds(String paramString) {
    this.mPaint.getTextBounds(paramString, 0, 1, this.mTextBounds);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/font/Font.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */