package org.andengine.opengl.font;

import java.util.ArrayList;
import org.andengine.opengl.util.GLState;

public class FontManager {
  private final ArrayList<Font> mFontsManaged = new ArrayList<Font>();
  
  public void loadFont(Font paramFont) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 23
    //   6: new java/lang/IllegalArgumentException
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'pFont must not be null!'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: aload_1
    //   17: athrow
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    //   23: aload_0
    //   24: getfield mFontsManaged : Ljava/util/ArrayList;
    //   27: aload_1
    //   28: invokevirtual add : (Ljava/lang/Object;)Z
    //   31: pop
    //   32: aload_0
    //   33: monitorexit
    //   34: return
    // Exception table:
    //   from	to	target	type
    //   6	18	18	finally
    //   23	32	18	finally
  }
  
  public void loadFonts(Font... paramVarArgs) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore_2
    //   4: aload_1
    //   5: arraylength
    //   6: istore_3
    //   7: iload_2
    //   8: iload_3
    //   9: if_icmplt -> 15
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: aload_0
    //   16: aload_1
    //   17: iload_2
    //   18: aaload
    //   19: invokevirtual loadFont : (Lorg/andengine/opengl/font/Font;)V
    //   22: iinc #2, 1
    //   25: goto -> 4
    //   28: astore_1
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_1
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   4	7	28	finally
    //   15	22	28	finally
  }
  
  public void onCreate() {}
  
  public void onDestroy() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mFontsManaged : Ljava/util/ArrayList;
    //   6: astore_1
    //   7: aload_1
    //   8: invokevirtual size : ()I
    //   11: iconst_1
    //   12: isub
    //   13: istore_2
    //   14: iload_2
    //   15: ifge -> 28
    //   18: aload_0
    //   19: getfield mFontsManaged : Ljava/util/ArrayList;
    //   22: invokevirtual clear : ()V
    //   25: aload_0
    //   26: monitorexit
    //   27: return
    //   28: aload_1
    //   29: iload_2
    //   30: invokevirtual get : (I)Ljava/lang/Object;
    //   33: checkcast org/andengine/opengl/font/Font
    //   36: invokevirtual invalidateLetters : ()V
    //   39: iinc #2, -1
    //   42: goto -> 14
    //   45: astore_1
    //   46: aload_0
    //   47: monitorexit
    //   48: aload_1
    //   49: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	45	finally
    //   18	25	45	finally
    //   28	39	45	finally
  }
  
  public void onReload() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mFontsManaged : Ljava/util/ArrayList;
    //   6: astore_1
    //   7: aload_1
    //   8: invokevirtual size : ()I
    //   11: istore_2
    //   12: iinc #2, -1
    //   15: iload_2
    //   16: ifge -> 22
    //   19: aload_0
    //   20: monitorexit
    //   21: return
    //   22: aload_1
    //   23: iload_2
    //   24: invokevirtual get : (I)Ljava/lang/Object;
    //   27: checkcast org/andengine/opengl/font/Font
    //   30: invokevirtual invalidateLetters : ()V
    //   33: iinc #2, -1
    //   36: goto -> 15
    //   39: astore_1
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_1
    //   43: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	39	finally
    //   22	33	39	finally
  }
  
  public void unloadFont(Font paramFont) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnonnull -> 23
    //   6: new java/lang/IllegalArgumentException
    //   9: astore_1
    //   10: aload_1
    //   11: ldc 'pFont must not be null!'
    //   13: invokespecial <init> : (Ljava/lang/String;)V
    //   16: aload_1
    //   17: athrow
    //   18: astore_1
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_1
    //   22: athrow
    //   23: aload_0
    //   24: getfield mFontsManaged : Ljava/util/ArrayList;
    //   27: aload_1
    //   28: invokevirtual remove : (Ljava/lang/Object;)Z
    //   31: pop
    //   32: aload_0
    //   33: monitorexit
    //   34: return
    // Exception table:
    //   from	to	target	type
    //   6	18	18	finally
    //   23	32	18	finally
  }
  
  public void unloadFonts(Font... paramVarArgs) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore_2
    //   4: aload_1
    //   5: arraylength
    //   6: istore_3
    //   7: iload_2
    //   8: iload_3
    //   9: if_icmplt -> 15
    //   12: aload_0
    //   13: monitorexit
    //   14: return
    //   15: aload_0
    //   16: aload_1
    //   17: iload_2
    //   18: aaload
    //   19: invokevirtual unloadFont : (Lorg/andengine/opengl/font/Font;)V
    //   22: iinc #2, 1
    //   25: goto -> 4
    //   28: astore_1
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_1
    //   32: athrow
    // Exception table:
    //   from	to	target	type
    //   4	7	28	finally
    //   15	22	28	finally
  }
  
  public void updateFonts(GLState paramGLState) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield mFontsManaged : Ljava/util/ArrayList;
    //   6: astore_2
    //   7: aload_2
    //   8: invokevirtual size : ()I
    //   11: istore_3
    //   12: iload_3
    //   13: ifle -> 23
    //   16: iinc #3, -1
    //   19: iload_3
    //   20: ifge -> 26
    //   23: aload_0
    //   24: monitorexit
    //   25: return
    //   26: aload_2
    //   27: iload_3
    //   28: invokevirtual get : (I)Ljava/lang/Object;
    //   31: checkcast org/andengine/opengl/font/Font
    //   34: aload_1
    //   35: invokevirtual update : (Lorg/andengine/opengl/util/GLState;)V
    //   38: iinc #3, -1
    //   41: goto -> 19
    //   44: astore_1
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    // Exception table:
    //   from	to	target	type
    //   2	12	44	finally
    //   26	38	44	finally
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/font/FontManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */