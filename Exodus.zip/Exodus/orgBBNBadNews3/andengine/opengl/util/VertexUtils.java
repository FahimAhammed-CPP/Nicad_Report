package org.andengine.opengl.util;

public class VertexUtils {
  public static float getVertex(float[] paramArrayOffloat, int paramInt1, int paramInt2, int paramInt3) {
    return paramArrayOffloat[paramInt3 * paramInt2 + paramInt1];
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/VertexUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */