package org.andengine.opengl.util;

import android.graphics.Bitmap;
import android.opengl.GLES20;
import android.opengl.Matrix;
import java.nio.Buffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import javax.microedition.khronos.egl.EGLConfig;
import org.andengine.engine.options.RenderOptions;
import org.andengine.opengl.exception.GLException;
import org.andengine.opengl.exception.GLFrameBufferException;
import org.andengine.opengl.texture.PixelFormat;
import org.andengine.opengl.view.ConfigChooser;
import org.andengine.util.debug.Debug;

public class GLState {
  public static final int GL_UNPACK_ALIGNMENT_DEFAULT = 4;
  
  private boolean mBlendEnabled = false;
  
  private boolean mCullingEnabled = false;
  
  private int mCurrentActiveTextureIndex = 0;
  
  private int mCurrentArrayBufferID = -1;
  
  private final int[] mCurrentBoundTextureIDs = new int[31];
  
  private int mCurrentDestinationBlendMode = -1;
  
  private int mCurrentFramebufferID = -1;
  
  private int mCurrentIndexBufferID = -1;
  
  private int mCurrentShaderProgramID = -1;
  
  private int mCurrentSourceBlendMode = -1;
  
  private boolean mDepthTestEnabled = true;
  
  private boolean mDitherEnabled = true;
  
  private String mExtensions;
  
  private final int[] mHardwareIDContainer = new int[1];
  
  private float mLineWidth = 1.0F;
  
  private int mMaximumFragmentShaderUniformVectorCount;
  
  private int mMaximumTextureSize;
  
  private int mMaximumTextureUnits;
  
  private int mMaximumVertexAttributeCount;
  
  private int mMaximumVertexShaderUniformVectorCount;
  
  private final float[] mModelViewGLMatrix = new float[16];
  
  private final GLMatrixStack mModelViewGLMatrixStack = new GLMatrixStack();
  
  private final float[] mModelViewProjectionGLMatrix = new float[16];
  
  private final float[] mProjectionGLMatrix = new float[16];
  
  private final GLMatrixStack mProjectionGLMatrixStack = new GLMatrixStack();
  
  private String mRenderer;
  
  private boolean mScissorTestEnabled = false;
  
  private String mVersion;
  
  public void activeTexture(int paramInt) {
    if (paramInt != this.mCurrentActiveTextureIndex) {
      this.mCurrentActiveTextureIndex = paramInt - 33984;
      GLES20.glActiveTexture(paramInt);
    } 
  }
  
  public void bindArrayBuffer(int paramInt) {
    if (this.mCurrentArrayBufferID != paramInt) {
      this.mCurrentArrayBufferID = paramInt;
      GLES20.glBindBuffer(34962, paramInt);
    } 
  }
  
  public void bindFramebuffer(int paramInt) {
    GLES20.glBindFramebuffer(36160, paramInt);
  }
  
  public void bindIndexBuffer(int paramInt) {
    if (this.mCurrentIndexBufferID != paramInt) {
      this.mCurrentIndexBufferID = paramInt;
      GLES20.glBindBuffer(34963, paramInt);
    } 
  }
  
  public void bindTexture(int paramInt) {
    if (this.mCurrentBoundTextureIDs[this.mCurrentActiveTextureIndex] != paramInt) {
      this.mCurrentBoundTextureIDs[this.mCurrentActiveTextureIndex] = paramInt;
      GLES20.glBindTexture(3553, paramInt);
    } 
  }
  
  public void blendFunction(int paramInt1, int paramInt2) {
    if (this.mCurrentSourceBlendMode != paramInt1 || this.mCurrentDestinationBlendMode != paramInt2) {
      this.mCurrentSourceBlendMode = paramInt1;
      this.mCurrentDestinationBlendMode = paramInt2;
      GLES20.glBlendFunc(paramInt1, paramInt2);
    } 
  }
  
  public void checkError() throws GLException {
    int i = GLES20.glGetError();
    if (i != 0)
      throw new GLException(i); 
  }
  
  public void checkFramebufferStatus() throws GLFrameBufferException, GLException {
    int i = getFramebufferStatus();
    switch (i) {
      default:
        throw new GLFrameBufferException(i);
      case 36061:
        throw new GLFrameBufferException(i, "GL_FRAMEBUFFER_UNSUPPORTED");
      case 36054:
        throw new GLFrameBufferException(i, "GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT");
      case 36057:
        throw new GLFrameBufferException(i, "GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS");
      case 36055:
        throw new GLFrameBufferException(i, "GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT");
      case 0:
        checkError();
      case 36053:
        break;
    } 
  }
  
  public void clearError() {
    GLES20.glGetError();
  }
  
  public void deleteArrayBuffer(int paramInt) {
    if (this.mCurrentArrayBufferID == paramInt)
      this.mCurrentArrayBufferID = -1; 
    this.mHardwareIDContainer[0] = paramInt;
    GLES20.glDeleteBuffers(1, this.mHardwareIDContainer, 0);
  }
  
  public void deleteFramebuffer(int paramInt) {
    if (this.mCurrentFramebufferID == paramInt)
      this.mCurrentFramebufferID = -1; 
    this.mHardwareIDContainer[0] = paramInt;
    GLES20.glDeleteFramebuffers(1, this.mHardwareIDContainer, 0);
  }
  
  public void deleteIndexBuffer(int paramInt) {
    if (this.mCurrentIndexBufferID == paramInt)
      this.mCurrentIndexBufferID = -1; 
    this.mHardwareIDContainer[0] = paramInt;
    GLES20.glDeleteBuffers(1, this.mHardwareIDContainer, 0);
  }
  
  public void deleteProgram(int paramInt) {
    if (this.mCurrentShaderProgramID == paramInt)
      this.mCurrentShaderProgramID = -1; 
    GLES20.glDeleteProgram(paramInt);
  }
  
  public void deleteTexture(int paramInt) {
    if (this.mCurrentBoundTextureIDs[this.mCurrentActiveTextureIndex] == paramInt)
      this.mCurrentBoundTextureIDs[this.mCurrentActiveTextureIndex] = -1; 
    this.mHardwareIDContainer[0] = paramInt;
    GLES20.glDeleteTextures(1, this.mHardwareIDContainer, 0);
  }
  
  public boolean disableBlend() {
    boolean bool = false;
    if (this.mBlendEnabled) {
      this.mBlendEnabled = false;
      GLES20.glDisable(3042);
      bool = true;
    } 
    return bool;
  }
  
  public boolean disableCulling() {
    boolean bool = false;
    if (this.mCullingEnabled) {
      this.mCullingEnabled = false;
      GLES20.glDisable(2884);
      bool = true;
    } 
    return bool;
  }
  
  public boolean disableDepthTest() {
    boolean bool = false;
    if (this.mDepthTestEnabled) {
      this.mDepthTestEnabled = false;
      GLES20.glDisable(2929);
      bool = true;
    } 
    return bool;
  }
  
  public boolean disableDither() {
    boolean bool = false;
    if (this.mDitherEnabled) {
      this.mDitherEnabled = false;
      GLES20.glDisable(3024);
      bool = true;
    } 
    return bool;
  }
  
  public boolean disableScissorTest() {
    boolean bool = false;
    if (this.mScissorTestEnabled) {
      this.mScissorTestEnabled = false;
      GLES20.glDisable(3089);
      bool = true;
    } 
    return bool;
  }
  
  public boolean enableBlend() {
    boolean bool = true;
    if (!this.mBlendEnabled) {
      this.mBlendEnabled = true;
      GLES20.glEnable(3042);
      bool = false;
    } 
    return bool;
  }
  
  public boolean enableCulling() {
    boolean bool = true;
    if (!this.mCullingEnabled) {
      this.mCullingEnabled = true;
      GLES20.glEnable(2884);
      bool = false;
    } 
    return bool;
  }
  
  public boolean enableDepthTest() {
    boolean bool = true;
    if (!this.mDepthTestEnabled) {
      this.mDepthTestEnabled = true;
      GLES20.glEnable(2929);
      bool = false;
    } 
    return bool;
  }
  
  public boolean enableDither() {
    boolean bool = true;
    if (!this.mDitherEnabled) {
      this.mDitherEnabled = true;
      GLES20.glEnable(3024);
      bool = false;
    } 
    return bool;
  }
  
  public boolean enableScissorTest() {
    boolean bool = true;
    if (!this.mScissorTestEnabled) {
      this.mScissorTestEnabled = true;
      GLES20.glEnable(3089);
      bool = false;
    } 
    return bool;
  }
  
  public void finish() {
    GLES20.glFinish();
  }
  
  public void flush() {
    GLES20.glFlush();
  }
  
  public int generateArrayBuffer(int paramInt1, int paramInt2) {
    GLES20.glGenBuffers(1, this.mHardwareIDContainer, 0);
    int i = this.mHardwareIDContainer[0];
    bindArrayBuffer(i);
    GLES20.glBufferData(34962, paramInt1, null, paramInt2);
    bindArrayBuffer(0);
    return i;
  }
  
  public int generateBuffer() {
    GLES20.glGenBuffers(1, this.mHardwareIDContainer, 0);
    return this.mHardwareIDContainer[0];
  }
  
  public int generateFramebuffer() {
    GLES20.glGenFramebuffers(1, this.mHardwareIDContainer, 0);
    return this.mHardwareIDContainer[0];
  }
  
  public int generateIndexBuffer(int paramInt1, int paramInt2) {
    GLES20.glGenBuffers(1, this.mHardwareIDContainer, 0);
    int i = this.mHardwareIDContainer[0];
    bindIndexBuffer(i);
    GLES20.glBufferData(34963, paramInt1, null, paramInt2);
    bindIndexBuffer(0);
    return i;
  }
  
  public int generateTexture() {
    GLES20.glGenTextures(1, this.mHardwareIDContainer, 0);
    return this.mHardwareIDContainer[0];
  }
  
  public int getActiveFramebuffer() {
    return getInteger(36006);
  }
  
  public int getActiveTexture() {
    return this.mCurrentActiveTextureIndex + 33984;
  }
  
  public int getError() {
    return GLES20.glGetError();
  }
  
  public String getExtensions() {
    return this.mExtensions;
  }
  
  public int getFramebufferStatus() {
    return GLES20.glCheckFramebufferStatus(36160);
  }
  
  public int getInteger(int paramInt) {
    GLES20.glGetIntegerv(paramInt, this.mHardwareIDContainer, 0);
    return this.mHardwareIDContainer[0];
  }
  
  public int getMaximumFragmentShaderUniformVectorCount() {
    return this.mMaximumFragmentShaderUniformVectorCount;
  }
  
  public int getMaximumTextureSize() {
    return this.mMaximumTextureSize;
  }
  
  public int getMaximumTextureUnits() {
    return this.mMaximumTextureUnits;
  }
  
  public int getMaximumVertexAttributeCount() {
    return this.mMaximumVertexAttributeCount;
  }
  
  public int getMaximumVertexShaderUniformVectorCount() {
    return this.mMaximumVertexShaderUniformVectorCount;
  }
  
  public float[] getModelViewGLMatrix() {
    this.mModelViewGLMatrixStack.getMatrix(this.mModelViewGLMatrix);
    return this.mModelViewGLMatrix;
  }
  
  public float[] getModelViewProjectionGLMatrix() {
    Matrix.multiplyMM(this.mModelViewProjectionGLMatrix, 0, this.mProjectionGLMatrixStack.mMatrixStack, this.mProjectionGLMatrixStack.mMatrixStackOffset, this.mModelViewGLMatrixStack.mMatrixStack, this.mModelViewGLMatrixStack.mMatrixStackOffset);
    return this.mModelViewProjectionGLMatrix;
  }
  
  public float[] getProjectionGLMatrix() {
    this.mProjectionGLMatrixStack.getMatrix(this.mProjectionGLMatrix);
    return this.mProjectionGLMatrix;
  }
  
  public String getRenderer() {
    return this.mRenderer;
  }
  
  public String getVersion() {
    return this.mVersion;
  }
  
  public void glTexImage2D(int paramInt1, int paramInt2, Bitmap paramBitmap, int paramInt3, PixelFormat paramPixelFormat) {
    Buffer buffer = GLHelper.getPixels(paramBitmap, paramPixelFormat, ByteOrder.BIG_ENDIAN);
    GLES20.glTexImage2D(paramInt1, paramInt2, paramPixelFormat.getGLInternalFormat(), paramBitmap.getWidth(), paramBitmap.getHeight(), paramInt3, paramPixelFormat.getGLFormat(), paramPixelFormat.getGLType(), buffer);
  }
  
  public void glTexSubImage2D(int paramInt1, int paramInt2, int paramInt3, int paramInt4, Bitmap paramBitmap, PixelFormat paramPixelFormat) {
    Buffer buffer = GLHelper.getPixels(paramBitmap, paramPixelFormat, ByteOrder.BIG_ENDIAN);
    GLES20.glTexSubImage2D(paramInt1, paramInt2, paramInt3, paramInt4, paramBitmap.getWidth(), paramBitmap.getHeight(), paramPixelFormat.getGLFormat(), paramPixelFormat.getGLType(), buffer);
  }
  
  public boolean isBlendEnabled() {
    return this.mBlendEnabled;
  }
  
  public boolean isCullingEnabled() {
    return this.mCullingEnabled;
  }
  
  public boolean isDepthTestEnabled() {
    return this.mDepthTestEnabled;
  }
  
  public boolean isDitherEnabled() {
    return this.mDitherEnabled;
  }
  
  public boolean isScissorTestEnabled() {
    return this.mScissorTestEnabled;
  }
  
  public boolean isTexture(int paramInt) {
    return GLES20.glIsTexture(paramInt);
  }
  
  public void lineWidth(float paramFloat) {
    if (this.mLineWidth != paramFloat) {
      this.mLineWidth = paramFloat;
      GLES20.glLineWidth(paramFloat);
    } 
  }
  
  public void loadModelViewGLMatrixIdentity() {
    this.mModelViewGLMatrixStack.glLoadIdentity();
  }
  
  public void loadProjectionGLMatrixIdentity() {
    this.mProjectionGLMatrixStack.glLoadIdentity();
  }
  
  public void orthoModelViewGLMatrixf(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    this.mModelViewGLMatrixStack.glOrthof(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void orthoProjectionGLMatrixf(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    this.mProjectionGLMatrixStack.glOrthof(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void popModelViewGLMatrix() {
    this.mModelViewGLMatrixStack.glPopMatrix();
  }
  
  public void popProjectionGLMatrix() {
    this.mProjectionGLMatrixStack.glPopMatrix();
  }
  
  public void pushModelViewGLMatrix() {
    this.mModelViewGLMatrixStack.glPushMatrix();
  }
  
  public void pushProjectionGLMatrix() {
    this.mProjectionGLMatrixStack.glPushMatrix();
  }
  
  public void reset(RenderOptions paramRenderOptions, ConfigChooser paramConfigChooser, EGLConfig paramEGLConfig) {
    this.mVersion = GLES20.glGetString(7938);
    this.mRenderer = GLES20.glGetString(7937);
    this.mExtensions = GLES20.glGetString(7939);
    this.mMaximumVertexAttributeCount = getInteger(34921);
    this.mMaximumVertexShaderUniformVectorCount = getInteger(36347);
    this.mMaximumFragmentShaderUniformVectorCount = getInteger(36349);
    this.mMaximumTextureUnits = getInteger(34930);
    this.mMaximumTextureSize = getInteger(3379);
    Debug.d("VERSION: " + this.mVersion);
    Debug.d("RENDERER: " + this.mRenderer);
    Debug.d("EGLCONFIG: " + EGLConfig.class.getSimpleName() + "(Red=" + paramConfigChooser.getRedSize() + ", Green=" + paramConfigChooser.getGreenSize() + ", Blue=" + paramConfigChooser.getBlueSize() + ", Alpha=" + paramConfigChooser.getAlphaSize() + ", Depth=" + paramConfigChooser.getDepthSize() + ", Stencil=" + paramConfigChooser.getStencilSize() + ")");
    Debug.d("EXTENSIONS: " + this.mExtensions);
    Debug.d("MAX_VERTEX_ATTRIBS: " + this.mMaximumVertexAttributeCount);
    Debug.d("MAX_VERTEX_UNIFORM_VECTORS: " + this.mMaximumVertexShaderUniformVectorCount);
    Debug.d("MAX_FRAGMENT_UNIFORM_VECTORS: " + this.mMaximumFragmentShaderUniformVectorCount);
    Debug.d("MAX_TEXTURE_IMAGE_UNITS: " + this.mMaximumTextureUnits);
    Debug.d("MAX_TEXTURE_SIZE: " + this.mMaximumTextureSize);
    this.mModelViewGLMatrixStack.reset();
    this.mProjectionGLMatrixStack.reset();
    this.mCurrentArrayBufferID = -1;
    this.mCurrentIndexBufferID = -1;
    this.mCurrentShaderProgramID = -1;
    Arrays.fill(this.mCurrentBoundTextureIDs, -1);
    this.mCurrentFramebufferID = -1;
    this.mCurrentActiveTextureIndex = 0;
    this.mCurrentSourceBlendMode = -1;
    this.mCurrentDestinationBlendMode = -1;
    enableDither();
    enableDepthTest();
    disableBlend();
    disableCulling();
    GLES20.glEnableVertexAttribArray(0);
    GLES20.glEnableVertexAttribArray(1);
    GLES20.glEnableVertexAttribArray(3);
    this.mLineWidth = 1.0F;
  }
  
  public void resetGLMatrixStacks() {
    this.mModelViewGLMatrixStack.reset();
    this.mProjectionGLMatrixStack.reset();
  }
  
  public void resetModelViewGLMatrixStack() {
    this.mModelViewGLMatrixStack.reset();
  }
  
  public void resetProjectionGLMatrixStack() {
    this.mProjectionGLMatrixStack.reset();
  }
  
  public void rotateModelViewGLMatrixf(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.mModelViewGLMatrixStack.glRotatef(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void rotateProjectionGLMatrixf(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    this.mProjectionGLMatrixStack.glRotatef(paramFloat1, paramFloat2, paramFloat3, paramFloat4);
  }
  
  public void scaleModelViewGLMatrixf(float paramFloat1, float paramFloat2, int paramInt) {
    this.mModelViewGLMatrixStack.glScalef(paramFloat1, paramFloat2, paramInt);
  }
  
  public void scaleProjectionGLMatrixf(float paramFloat1, float paramFloat2, float paramFloat3) {
    this.mProjectionGLMatrixStack.glScalef(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public boolean setBlendEnabled(boolean paramBoolean) {
    return paramBoolean ? enableBlend() : disableBlend();
  }
  
  public boolean setCullingEnabled(boolean paramBoolean) {
    return paramBoolean ? enableCulling() : disableCulling();
  }
  
  public boolean setDepthTestEnabled(boolean paramBoolean) {
    return paramBoolean ? enableDepthTest() : disableDepthTest();
  }
  
  public boolean setDitherEnabled(boolean paramBoolean) {
    return paramBoolean ? enableDither() : disableDither();
  }
  
  public boolean setScissorTestEnabled(boolean paramBoolean) {
    return paramBoolean ? enableScissorTest() : disableScissorTest();
  }
  
  public void skewModelViewGLMatrixf(float paramFloat1, float paramFloat2) {
    this.mModelViewGLMatrixStack.glSkewf(paramFloat1, paramFloat2);
  }
  
  public void skewProjectionGLMatrixf(float paramFloat1, float paramFloat2) {
    this.mProjectionGLMatrixStack.glSkewf(paramFloat1, paramFloat2);
  }
  
  public void translateModelViewGLMatrixf(float paramFloat1, float paramFloat2, float paramFloat3) {
    this.mModelViewGLMatrixStack.glTranslatef(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void translateProjectionGLMatrixf(float paramFloat1, float paramFloat2, float paramFloat3) {
    this.mProjectionGLMatrixStack.glTranslatef(paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void useProgram(int paramInt) {
    if (this.mCurrentShaderProgramID != paramInt) {
      this.mCurrentShaderProgramID = paramInt;
      GLES20.glUseProgram(paramInt);
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/GLState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */