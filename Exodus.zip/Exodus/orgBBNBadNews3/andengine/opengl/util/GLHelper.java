package org.andengine.opengl.util;

import android.graphics.Bitmap;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import org.andengine.opengl.texture.PixelFormat;

public class GLHelper {
  public static byte[] convertARGB_8888toA_8(int[] paramArrayOfint) {
    byte[] arrayOfByte = new byte[paramArrayOfint.length];
    for (int i = paramArrayOfint.length - 1;; i--) {
      if (i < 0)
        return arrayOfByte; 
      arrayOfByte[i] = (byte)(byte)(paramArrayOfint[i] >> 24 & 0xFF);
    } 
  }
  
  public static short[] convertARGB_8888toRGBA_4444(int[] paramArrayOfint) {
    return convertARGB_8888toRGBA_4444(paramArrayOfint, ByteOrder.nativeOrder());
  }
  
  public static short[] convertARGB_8888toRGBA_4444(int[] paramArrayOfint, ByteOrder paramByteOrder) {
    short[] arrayOfShort = new short[paramArrayOfint.length];
    if (paramByteOrder == ByteOrder.LITTLE_ENDIAN) {
      int j = paramArrayOfint.length - 1;
      while (true) {
        if (j >= 0) {
          int k = paramArrayOfint[j];
          arrayOfShort[j] = (short)(short)(k >> 16 & 0xF0 | k >> 12 & 0xF | k << 8 & 0xF000 | k >> 20 & 0xF00);
          j--;
          continue;
        } 
        return arrayOfShort;
      } 
    } 
    int i = paramArrayOfint.length - 1;
    while (true) {
      if (i >= 0) {
        int j = paramArrayOfint[i];
        arrayOfShort[i] = (short)(short)(j >> 8 & 0xF000 | j >> 4 & 0xF00 | j & 0xF0 | j >> 28 & 0xF);
        i--;
        continue;
      } 
      return arrayOfShort;
    } 
  }
  
  public static int[] convertARGB_8888toRGBA_8888(int[] paramArrayOfint) {
    return convertARGB_8888toRGBA_8888(paramArrayOfint, ByteOrder.nativeOrder());
  }
  
  public static int[] convertARGB_8888toRGBA_8888(int[] paramArrayOfint, ByteOrder paramByteOrder) {
    if (paramByteOrder == ByteOrder.LITTLE_ENDIAN) {
      int j = paramArrayOfint.length - 1;
      while (true) {
        if (j >= 0) {
          int k = paramArrayOfint[j];
          paramArrayOfint[j] = 0xFF00FF00 & k | k << 16 & 0xFF0000 | k >> 16 & 0xFF;
          j--;
          continue;
        } 
        return paramArrayOfint;
      } 
    } 
    int i = paramArrayOfint.length - 1;
    while (true) {
      if (i >= 0) {
        int j = paramArrayOfint[i];
        paramArrayOfint[i] = j << 8 & 0xFFFFFF00 | j >> 24 & 0xFF;
        i--;
        continue;
      } 
      return paramArrayOfint;
    } 
  }
  
  public static short[] convertARGB_8888toRGB_565(int[] paramArrayOfint) {
    return convertARGB_8888toRGB_565(paramArrayOfint, ByteOrder.nativeOrder());
  }
  
  public static short[] convertARGB_8888toRGB_565(int[] paramArrayOfint, ByteOrder paramByteOrder) {
    short[] arrayOfShort = new short[paramArrayOfint.length];
    if (paramByteOrder == ByteOrder.LITTLE_ENDIAN) {
      int j = paramArrayOfint.length - 1;
      while (true) {
        if (j >= 0) {
          int k = paramArrayOfint[j];
          arrayOfShort[j] = (short)(short)(k >> 16 & 0xF8 | k >> 13 & 0x7 | k << 3 & 0xE000 | k << 5 & 0x1F00);
          j--;
          continue;
        } 
        return arrayOfShort;
      } 
    } 
    int i = paramArrayOfint.length - 1;
    while (true) {
      if (i >= 0) {
        int j = paramArrayOfint[i];
        arrayOfShort[i] = (short)(short)(j >> 8 & 0xF800 | j >> 5 & 0x7E0 | j >> 3 & 0x1F);
        i--;
        continue;
      } 
      return arrayOfShort;
    } 
  }
  
  public static int[] convertRGBA_8888toARGB_8888(int[] paramArrayOfint) {
    return convertRGBA_8888toARGB_8888(paramArrayOfint, ByteOrder.nativeOrder());
  }
  
  public static int[] convertRGBA_8888toARGB_8888(int[] paramArrayOfint, ByteOrder paramByteOrder) {
    if (paramByteOrder == ByteOrder.LITTLE_ENDIAN) {
      int j = paramArrayOfint.length - 1;
      while (true) {
        if (j >= 0) {
          int k = paramArrayOfint[j];
          paramArrayOfint[j] = 0xFF00FF00 & k | k << 16 & 0xFF0000 | k >> 16 & 0xFF;
          j--;
          continue;
        } 
        return paramArrayOfint;
      } 
    } 
    int i = paramArrayOfint.length - 1;
    while (true) {
      if (i >= 0) {
        int j = paramArrayOfint[i];
        paramArrayOfint[i] = j >> 8 & 0xFFFFFF | j << 24 & 0xFF000000;
        i--;
        continue;
      } 
      return paramArrayOfint;
    } 
  }
  
  public static int[] convertRGBA_8888toARGB_8888_FlippedVertical(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    return convertRGBA_8888toARGB_8888_FlippedVertical(paramArrayOfint, paramInt1, paramInt2, ByteOrder.nativeOrder());
  }
  
  public static int[] convertRGBA_8888toARGB_8888_FlippedVertical(int[] paramArrayOfint, int paramInt1, int paramInt2, ByteOrder paramByteOrder) {
    int[] arrayOfInt = new int[paramInt1 * paramInt2];
    if (paramByteOrder == ByteOrder.LITTLE_ENDIAN) {
      byte b1 = 0;
      label24: while (true) {
        if (b1 < paramInt2) {
          for (byte b2 = 0;; b2++) {
            if (b2 >= paramInt1) {
              b1++;
              continue label24;
            } 
            int i = paramArrayOfint[b1 * paramInt1 + b2];
            arrayOfInt[(paramInt2 - b1 - 1) * paramInt1 + b2] = 0xFF00FF00 & i | i << 16 & 0xFF0000 | i >> 16 & 0xFF;
          } 
          break;
        } 
        return arrayOfInt;
      } 
    } 
    byte b = 0;
    label25: while (true) {
      if (b < paramInt2) {
        for (byte b1 = 0;; b1++) {
          if (b1 >= paramInt1) {
            b++;
            continue label25;
          } 
          int i = paramArrayOfint[b * paramInt1 + b1];
          arrayOfInt[(paramInt2 - b - 1) * paramInt1 + b1] = i >> 8 & 0xFFFFFF | i << 24 & 0xFF000000;
        } 
        break;
      } 
      return arrayOfInt;
    } 
  }
  
  public static Buffer getPixels(Bitmap paramBitmap, PixelFormat paramPixelFormat) {
    return getPixels(paramBitmap, paramPixelFormat, ByteOrder.nativeOrder());
  }
  
  public static Buffer getPixels(Bitmap paramBitmap, PixelFormat paramPixelFormat, ByteOrder paramByteOrder) {
    ByteOrder byteOrder;
    int[] arrayOfInt = getPixelsARGB_8888(paramBitmap);
    switch (paramPixelFormat) {
      default:
        throw new IllegalArgumentException("Unexpected " + PixelFormat.class.getSimpleName() + ": '" + paramPixelFormat + "'.");
      case null:
        return ShortBuffer.wrap(convertARGB_8888toRGB_565(arrayOfInt, paramByteOrder));
      case null:
        if (paramByteOrder == ByteOrder.LITTLE_ENDIAN) {
          byteOrder = ByteOrder.BIG_ENDIAN;
        } else {
          byteOrder = ByteOrder.LITTLE_ENDIAN;
        } 
        return IntBuffer.wrap(convertARGB_8888toRGBA_8888(arrayOfInt, byteOrder));
      case null:
        return ShortBuffer.wrap(convertARGB_8888toRGBA_4444(arrayOfInt, paramByteOrder));
      case null:
        break;
    } 
    return ByteBuffer.wrap(convertARGB_8888toA_8(arrayOfInt));
  }
  
  public static int[] getPixelsARGB_8888(Bitmap paramBitmap) {
    int i = paramBitmap.getWidth();
    int j = paramBitmap.getHeight();
    int[] arrayOfInt = new int[i * j];
    paramBitmap.getPixels(arrayOfInt, 0, i, 0, 0, i, j);
    return arrayOfInt;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/GLHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */