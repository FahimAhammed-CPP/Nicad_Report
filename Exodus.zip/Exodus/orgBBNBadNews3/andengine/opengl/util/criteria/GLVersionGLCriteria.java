package org.andengine.opengl.util.criteria;

import org.andengine.opengl.util.GLState;
import org.andengine.util.adt.data.operator.StringOperator;

public class GLVersionGLCriteria extends StringGLCriteria {
  public GLVersionGLCriteria(StringOperator paramStringOperator, String paramString) {
    super(paramStringOperator, paramString);
  }
  
  protected String getActualCriteria(GLState paramGLState) {
    return paramGLState.getVersion();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/criteria/GLVersionGLCriteria.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */