package org.andengine.opengl.util.criteria;

import org.andengine.opengl.util.GLState;
import org.andengine.util.adt.data.operator.IntOperator;

public abstract class IntGLCriteria implements IGLCriteria {
  private final int mCriteria;
  
  private final IntOperator mIntOperator;
  
  public IntGLCriteria(IntOperator paramIntOperator, int paramInt) {
    this.mCriteria = paramInt;
    this.mIntOperator = paramIntOperator;
  }
  
  protected abstract int getActualCriteria(GLState paramGLState);
  
  public boolean isMet(GLState paramGLState) {
    return this.mIntOperator.check(getActualCriteria(paramGLState), this.mCriteria);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/criteria/IntGLCriteria.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */