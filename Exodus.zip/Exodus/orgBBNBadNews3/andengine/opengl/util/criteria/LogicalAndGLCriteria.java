package org.andengine.opengl.util.criteria;

import org.andengine.opengl.util.GLState;

public class LogicalAndGLCriteria implements IGLCriteria {
  private final IGLCriteria[] mGLCriterias;
  
  public LogicalAndGLCriteria(IGLCriteria... paramVarArgs) {
    this.mGLCriterias = paramVarArgs;
  }
  
  public boolean isMet(GLState paramGLState) {
    boolean bool = false;
    IGLCriteria[] arrayOfIGLCriteria = this.mGLCriterias;
    int i = arrayOfIGLCriteria.length;
    byte b = 0;
    while (true) {
      if (b >= i)
        return true; 
      boolean bool1 = bool;
      if (arrayOfIGLCriteria[b].isMet(paramGLState)) {
        b++;
        continue;
      } 
      return bool1;
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/criteria/LogicalAndGLCriteria.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */