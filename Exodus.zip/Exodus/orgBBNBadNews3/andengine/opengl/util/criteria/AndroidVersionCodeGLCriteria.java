package org.andengine.opengl.util.criteria;

import android.os.Build;
import org.andengine.opengl.util.GLState;
import org.andengine.util.adt.data.operator.IntOperator;

public class AndroidVersionCodeGLCriteria extends IntGLCriteria {
  public AndroidVersionCodeGLCriteria(IntOperator paramIntOperator, int paramInt) {
    super(paramIntOperator, paramInt);
  }
  
  protected int getActualCriteria(GLState paramGLState) {
    return Build.VERSION.SDK_INT;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/criteria/AndroidVersionCodeGLCriteria.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */