package org.andengine.opengl.util.criteria;

import org.andengine.opengl.util.GLState;
import org.andengine.util.adt.data.operator.StringOperator;

public class GLExtensionsGLCriteria extends StringGLCriteria {
  public GLExtensionsGLCriteria(StringOperator paramStringOperator, String paramString) {
    super(paramStringOperator, paramString);
  }
  
  protected String getActualCriteria(GLState paramGLState) {
    return paramGLState.getExtensions();
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/criteria/GLExtensionsGLCriteria.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */