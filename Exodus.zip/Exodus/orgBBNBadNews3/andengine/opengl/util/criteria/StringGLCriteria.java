package org.andengine.opengl.util.criteria;

import org.andengine.opengl.util.GLState;
import org.andengine.util.adt.data.operator.StringOperator;

public abstract class StringGLCriteria implements IGLCriteria {
  private final String mCriteria;
  
  private final StringOperator mStringOperator;
  
  public StringGLCriteria(StringOperator paramStringOperator, String paramString) {
    this.mCriteria = paramString;
    this.mStringOperator = paramStringOperator;
  }
  
  protected abstract String getActualCriteria(GLState paramGLState);
  
  public boolean isMet(GLState paramGLState) {
    return this.mStringOperator.check(getActualCriteria(paramGLState), this.mCriteria);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/criteria/StringGLCriteria.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */