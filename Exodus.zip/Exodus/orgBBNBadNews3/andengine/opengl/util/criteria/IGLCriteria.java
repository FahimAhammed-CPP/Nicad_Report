package org.andengine.opengl.util.criteria;

import org.andengine.opengl.util.GLState;

public interface IGLCriteria {
  boolean isMet(GLState paramGLState);
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/criteria/IGLCriteria.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */