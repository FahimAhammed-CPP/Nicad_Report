package org.andengine.opengl.util.criteria;

import org.andengine.opengl.util.GLState;

public class LogicalOrGLCriteria implements IGLCriteria {
  private final IGLCriteria[] mGLCriterias;
  
  public LogicalOrGLCriteria(IGLCriteria... paramVarArgs) {
    this.mGLCriterias = paramVarArgs;
  }
  
  public boolean isMet(GLState paramGLState) {
    boolean bool = false;
    IGLCriteria[] arrayOfIGLCriteria = this.mGLCriterias;
    int i = arrayOfIGLCriteria.length;
    byte b = 0;
    while (true) {
      if (b < i) {
        if (arrayOfIGLCriteria[b].isMet(paramGLState))
          return true; 
        b++;
        continue;
      } 
      return bool;
    } 
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/criteria/LogicalOrGLCriteria.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */