package org.andengine.opengl.util;

import android.opengl.Matrix;
import org.andengine.util.exception.AndEngineRuntimeException;

public class GLMatrixStack {
  private static final int GLMATRIXSTACKOFFSET_OVERFLOW = 512;
  
  private static final int GLMATRIXSTACKOFFSET_UNDERFLOW = -16;
  
  public static final int GLMATRIXSTACK_DEPTH_MAX = 32;
  
  public static final int GLMATRIX_SIZE = 16;
  
  final float[] mMatrixStack = new float[512];
  
  int mMatrixStackOffset;
  
  private final float[] mTemp = new float[32];
  
  public GLMatrixStack() {
    glLoadIdentity();
  }
  
  private static void setSkewM(float[] paramArrayOffloat, int paramInt, float paramFloat1, float paramFloat2) {
    paramArrayOffloat[paramInt + 0] = 1.0F;
    paramArrayOffloat[paramInt + 1] = (float)Math.tan((-0.017453292F * paramFloat2));
    paramArrayOffloat[paramInt + 2] = 0.0F;
    paramArrayOffloat[paramInt + 3] = 0.0F;
    paramArrayOffloat[paramInt + 4] = (float)Math.tan((-0.017453292F * paramFloat1));
    paramArrayOffloat[paramInt + 5] = 1.0F;
    paramArrayOffloat[paramInt + 6] = 0.0F;
    paramArrayOffloat[paramInt + 7] = 0.0F;
    paramArrayOffloat[paramInt + 8] = 0.0F;
    paramArrayOffloat[paramInt + 9] = 0.0F;
    paramArrayOffloat[paramInt + 10] = 1.0F;
    paramArrayOffloat[paramInt + 11] = 0.0F;
    paramArrayOffloat[paramInt + 12] = 0.0F;
    paramArrayOffloat[paramInt + 13] = 0.0F;
    paramArrayOffloat[paramInt + 14] = 0.0F;
    paramArrayOffloat[paramInt + 15] = 1.0F;
  }
  
  public void getMatrix(float[] paramArrayOffloat) {
    System.arraycopy(this.mMatrixStack, this.mMatrixStackOffset, paramArrayOffloat, 0, 16);
  }
  
  public void glLoadIdentity() {
    Matrix.setIdentityM(this.mMatrixStack, this.mMatrixStackOffset);
  }
  
  public void glOrthof(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
    Matrix.orthoM(this.mMatrixStack, this.mMatrixStackOffset, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
  }
  
  public void glPopMatrix() {
    if (this.mMatrixStackOffset - 16 <= -16)
      throw new GLMatrixStackUnderflowException(); 
    this.mMatrixStackOffset -= 16;
  }
  
  public void glPushMatrix() throws GLMatrixStackOverflowException {
    if (this.mMatrixStackOffset + 16 >= 512)
      throw new GLMatrixStackOverflowException(); 
    System.arraycopy(this.mMatrixStack, this.mMatrixStackOffset, this.mMatrixStack, this.mMatrixStackOffset + 16, 16);
    this.mMatrixStackOffset += 16;
  }
  
  public void glRotatef(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    Matrix.setRotateM(this.mTemp, 0, paramFloat1, paramFloat2, paramFloat3, paramFloat4);
    System.arraycopy(this.mMatrixStack, this.mMatrixStackOffset, this.mTemp, 16, 16);
    Matrix.multiplyMM(this.mMatrixStack, this.mMatrixStackOffset, this.mTemp, 16, this.mTemp, 0);
  }
  
  public void glScalef(float paramFloat1, float paramFloat2, float paramFloat3) {
    Matrix.scaleM(this.mMatrixStack, this.mMatrixStackOffset, paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void glSkewf(float paramFloat1, float paramFloat2) {
    setSkewM(this.mTemp, 0, paramFloat1, paramFloat2);
    System.arraycopy(this.mMatrixStack, this.mMatrixStackOffset, this.mTemp, 16, 16);
    Matrix.multiplyMM(this.mMatrixStack, this.mMatrixStackOffset, this.mTemp, 16, this.mTemp, 0);
  }
  
  public void glTranslatef(float paramFloat1, float paramFloat2, float paramFloat3) {
    Matrix.translateM(this.mMatrixStack, this.mMatrixStackOffset, paramFloat1, paramFloat2, paramFloat3);
  }
  
  public void reset() {
    this.mMatrixStackOffset = 0;
    glLoadIdentity();
  }
  
  public static class GLMatrixStackOverflowException extends AndEngineRuntimeException {
    private static final long serialVersionUID = -800847781599300100L;
  }
  
  public static class GLMatrixStackUnderflowException extends AndEngineRuntimeException {
    private static final long serialVersionUID = -3268021423136372954L;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/GLMatrixStack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */