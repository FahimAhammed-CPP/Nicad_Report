package org.andengine.opengl.util;

import java.nio.ByteBuffer;

public class BufferUtils {
  private static final boolean NATIVE_LIB_LOADED;
  
  private static final boolean WORKAROUND_BYTEBUFFER_ALLOCATE_DIRECT;
  
  private static final boolean WORKAROUND_BYTEBUFFER_PUT_FLOATARRAY;
  
  static {
    // Byte code:
    //   0: ldc 'andengine'
    //   2: invokestatic loadLibrary : (Ljava/lang/String;)V
    //   5: iconst_1
    //   6: istore_0
    //   7: iload_0
    //   8: putstatic org/andengine/opengl/util/BufferUtils.NATIVE_LIB_LOADED : Z
    //   11: getstatic org/andengine/opengl/util/BufferUtils.NATIVE_LIB_LOADED : Z
    //   14: ifeq -> 64
    //   17: bipush #11
    //   19: bipush #13
    //   21: invokestatic isAndroidVersion : (II)Z
    //   24: ifeq -> 50
    //   27: iconst_1
    //   28: putstatic org/andengine/opengl/util/BufferUtils.WORKAROUND_BYTEBUFFER_ALLOCATE_DIRECT : Z
    //   31: bipush #8
    //   33: invokestatic isAndroidVersionOrLower : (I)Z
    //   36: ifeq -> 57
    //   39: iconst_1
    //   40: putstatic org/andengine/opengl/util/BufferUtils.WORKAROUND_BYTEBUFFER_PUT_FLOATARRAY : Z
    //   43: return
    //   44: astore_1
    //   45: iconst_0
    //   46: istore_0
    //   47: goto -> 7
    //   50: iconst_0
    //   51: putstatic org/andengine/opengl/util/BufferUtils.WORKAROUND_BYTEBUFFER_ALLOCATE_DIRECT : Z
    //   54: goto -> 31
    //   57: iconst_0
    //   58: putstatic org/andengine/opengl/util/BufferUtils.WORKAROUND_BYTEBUFFER_PUT_FLOATARRAY : Z
    //   61: goto -> 43
    //   64: iconst_0
    //   65: putstatic org/andengine/opengl/util/BufferUtils.WORKAROUND_BYTEBUFFER_ALLOCATE_DIRECT : Z
    //   68: bipush #11
    //   70: bipush #13
    //   72: invokestatic isAndroidVersion : (II)Z
    //   75: ifeq -> 106
    //   78: new java/lang/StringBuilder
    //   81: dup
    //   82: ldc 'Creating a '
    //   84: invokespecial <init> : (Ljava/lang/String;)V
    //   87: ldc java/nio/ByteBuffer
    //   89: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   92: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: ldc ' will actually allocate 4x the memory than requested!'
    //   97: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   100: invokevirtual toString : ()Ljava/lang/String;
    //   103: invokestatic w : (Ljava/lang/String;)V
    //   106: iconst_0
    //   107: putstatic org/andengine/opengl/util/BufferUtils.WORKAROUND_BYTEBUFFER_PUT_FLOATARRAY : Z
    //   110: goto -> 43
    // Exception table:
    //   from	to	target	type
    //   0	5	44	java/lang/UnsatisfiedLinkError
  }
  
  public static ByteBuffer allocateDirectByteBuffer(int paramInt) {
    return WORKAROUND_BYTEBUFFER_ALLOCATE_DIRECT ? jniAllocateDirect(paramInt) : ByteBuffer.allocateDirect(paramInt);
  }
  
  public static void freeDirectByteBuffer(ByteBuffer paramByteBuffer) {
    if (WORKAROUND_BYTEBUFFER_ALLOCATE_DIRECT)
      jniFreeDirect(paramByteBuffer); 
  }
  
  public static short getUnsignedByte(ByteBuffer paramByteBuffer) {
    return (short)(paramByteBuffer.get() & 0xFF);
  }
  
  public static short getUnsignedByte(ByteBuffer paramByteBuffer, int paramInt) {
    return (short)(paramByteBuffer.get(paramInt) & 0xFF);
  }
  
  public static long getUnsignedInt(ByteBuffer paramByteBuffer) {
    return paramByteBuffer.getInt() & 0xFFFFFFFFL;
  }
  
  public static long getUnsignedInt(ByteBuffer paramByteBuffer, int paramInt) {
    return paramByteBuffer.getInt(paramInt) & 0xFFFFFFFFL;
  }
  
  public static int getUnsignedShort(ByteBuffer paramByteBuffer) {
    return paramByteBuffer.getShort() & 0xFFFF;
  }
  
  public static int getUnsignedShort(ByteBuffer paramByteBuffer, int paramInt) {
    return paramByteBuffer.getShort(paramInt) & 0xFFFF;
  }
  
  private static native ByteBuffer jniAllocateDirect(int paramInt);
  
  private static native void jniFreeDirect(ByteBuffer paramByteBuffer);
  
  private static native void jniPut(ByteBuffer paramByteBuffer, float[] paramArrayOffloat, int paramInt1, int paramInt2);
  
  public static void put(ByteBuffer paramByteBuffer, float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    if (WORKAROUND_BYTEBUFFER_PUT_FLOATARRAY) {
      jniPut(paramByteBuffer, paramArrayOffloat, paramInt1, paramInt2);
    } else {
      int i = paramInt2;
      while (true) {
        if (i < paramInt2 + paramInt1) {
          paramByteBuffer.putFloat(paramArrayOffloat[i]);
          i++;
          continue;
        } 
        paramByteBuffer.position(0);
        paramByteBuffer.limit(paramInt1 << 2);
        return;
      } 
    } 
    paramByteBuffer.position(0);
    paramByteBuffer.limit(paramInt1 << 2);
  }
  
  public static void putUnsignedByte(ByteBuffer paramByteBuffer, int paramInt) {
    paramByteBuffer.put((byte)(paramInt & 0xFF));
  }
  
  public static void putUnsignedByte(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2) {
    paramByteBuffer.put(paramInt1, (byte)(paramInt2 & 0xFF));
  }
  
  public static void putUnsignedInt(ByteBuffer paramByteBuffer, int paramInt, long paramLong) {
    paramByteBuffer.putInt(paramInt, (short)(int)(0xFFFFFFFFL & paramLong));
  }
  
  public static void putUnsignedInt(ByteBuffer paramByteBuffer, long paramLong) {
    paramByteBuffer.putInt((int)(0xFFFFFFFFL & paramLong));
  }
  
  public static void putUnsignedShort(ByteBuffer paramByteBuffer, int paramInt) {
    paramByteBuffer.putShort((short)(0xFFFF & paramInt));
  }
  
  public static void putUnsignedShort(ByteBuffer paramByteBuffer, int paramInt1, int paramInt2) {
    paramByteBuffer.putShort(paramInt1, (short)(0xFFFF & paramInt2));
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/util/BufferUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */