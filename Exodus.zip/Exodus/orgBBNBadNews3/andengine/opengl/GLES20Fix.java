package org.andengine.opengl;

import android.opengl.GLES20;

public class GLES20Fix {
  private static boolean NATIVE_LIB_LOADED;
  
  private static final boolean WORKAROUND_MISSING_GLES20_METHODS;
  
  static {
    // Byte code:
    //   0: ldc 'andengine'
    //   2: invokestatic loadLibrary : (Ljava/lang/String;)V
    //   5: iconst_1
    //   6: istore_0
    //   7: iload_0
    //   8: putstatic org/andengine/opengl/GLES20Fix.NATIVE_LIB_LOADED : Z
    //   11: bipush #8
    //   13: invokestatic isAndroidVersionOrLower : (I)Z
    //   16: ifeq -> 44
    //   19: iload_0
    //   20: ifeq -> 34
    //   23: iconst_1
    //   24: putstatic org/andengine/opengl/GLES20Fix.WORKAROUND_MISSING_GLES20_METHODS : Z
    //   27: return
    //   28: astore_1
    //   29: iconst_0
    //   30: istore_0
    //   31: goto -> 7
    //   34: new org/andengine/util/exception/AndEngineRuntimeException
    //   37: dup
    //   38: ldc 'Inherently incompatible device detected.'
    //   40: invokespecial <init> : (Ljava/lang/String;)V
    //   43: athrow
    //   44: iconst_0
    //   45: putstatic org/andengine/opengl/GLES20Fix.WORKAROUND_MISSING_GLES20_METHODS : Z
    //   48: goto -> 27
    // Exception table:
    //   from	to	target	type
    //   0	5	28	java/lang/UnsatisfiedLinkError
  }
  
  public static native void glDrawElements(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static void glDrawElementsFix(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (WORKAROUND_MISSING_GLES20_METHODS) {
      glDrawElements(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    GLES20.glDrawElements(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static native void glVertexAttribPointer(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, int paramInt5);
  
  public static void glVertexAttribPointerFix(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, int paramInt5) {
    if (WORKAROUND_MISSING_GLES20_METHODS) {
      glVertexAttribPointerFix(paramInt1, paramInt2, paramInt3, paramBoolean, paramInt4, paramInt5);
      return;
    } 
    GLES20.glVertexAttribPointer(paramInt1, paramInt2, paramInt3, paramBoolean, paramInt4, paramInt5);
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/opengl/GLES20Fix.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */