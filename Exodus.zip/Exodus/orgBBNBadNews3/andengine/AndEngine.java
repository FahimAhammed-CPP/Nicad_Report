package org.andengine;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import org.andengine.opengl.view.ConfigChooser;
import org.andengine.util.exception.DeviceNotSupportedException;
import org.andengine.util.system.SystemUtils;

public class AndEngine {
  private static void checkCodePathSupport() throws DeviceNotSupportedException {
    if (SystemUtils.isAndroidVersionOrLower(8))
      try {
        System.loadLibrary("andengine");
        return;
      } catch (UnsatisfiedLinkError unsatisfiedLinkError) {
        throw new DeviceNotSupportedException(DeviceNotSupportedException.DeviceNotSupportedCause.CODEPATH_INCOMPLETE, unsatisfiedLinkError);
      }  
  }
  
  public static void checkDeviceSupported() throws DeviceNotSupportedException {
    checkCodePathSupport();
    checkOpenGLSupport();
  }
  
  private static void checkEGLConfigChooserSupport() throws DeviceNotSupportedException {
    EGL10 eGL10 = (EGL10)EGLContext.getEGL();
    EGLDisplay eGLDisplay = eGL10.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
    eGL10.eglInitialize(eGLDisplay, new int[2]);
    ConfigChooser configChooser = new ConfigChooser(false);
    try {
      configChooser.chooseConfig(eGL10, eGLDisplay);
      return;
    } catch (IllegalArgumentException illegalArgumentException) {
      throw new DeviceNotSupportedException(DeviceNotSupportedException.DeviceNotSupportedCause.EGLCONFIG_NOT_FOUND, illegalArgumentException);
    } 
  }
  
  private static void checkOpenGLSupport() throws DeviceNotSupportedException {
    checkEGLConfigChooserSupport();
  }
  
  public static boolean isDeviceSupported() {
    boolean bool;
    try {
      checkDeviceSupported();
      bool = true;
    } catch (DeviceNotSupportedException deviceNotSupportedException) {
      bool = false;
    } 
    return bool;
  }
}


/* Location:              /home/fahim/Desktop/BreakBottleNeckBadNews-dex2jar.jar!/org/andengine/AndEngine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */